import sys
import importlib
import importlib.util
from importlib.abc import MetaPathFinder, Loader
from importlib.machinery import ModuleSpec
from packaging import version
from qbcompiler.logging import get_logger

logger = get_logger(__name__)

_REAL_PKG = "transformers"
_SHIM_PKG = __name__
try:
    _real_tf = importlib.import_module(_REAL_PKG)
    _HF_VER = version.parse(_real_tf.__version__)

    _IMPORT_STRUCTURE = getattr(_real_tf, "_import_structure", {})
    _CLASS_TO_MODULE = {
        sym: submod for submod, syms in _IMPORT_STRUCTURE.items() for sym in syms
    }

    # (symbol or submodule, new_mod, old_mod, version threshold)
    _VERSION_FALLBACK = {
        # "AutoTokenizer": ("models.test1", "models.test2", "4.20.0"),
        # "models.albert.configuration_albert": ("models.albert1.config1", "models.albert2.config2", "4.20.0"),
    }

    __all__ = list(set(_CLASS_TO_MODULE) | set(_VERSION_FALLBACK))

    __path__ = _real_tf.__path__
    _spec = _real_tf.__spec__
    if hasattr(_spec, "submodule_search_locations"):
        __spec__.submodule_search_locations = _spec.submodule_search_locations
except:
    logger.info(
        "The transformers library isn’t installed. Please verify the transformers version in the qbcompiler docker image and install it."
    )
    # raise ModuleNotFoundError(
    #     "The transformers library isn’t installed. Please verify the transformers version in the qbcompiler docker image and install it."
    # )


# transformer module
def __getattr__(name: str):
    if name in globals():
        return globals()[name]

    if name in _VERSION_FALLBACK:
        new_mod, old_mod, thresh = _VERSION_FALLBACK[name]
        submod = new_mod if _HF_VER >= version.parse(thresh) else old_mod
    else:
        submod = _CLASS_TO_MODULE.get(name)
        if submod is None:
            # Should we display a warning message?
            return None

    full_mod = f"{_REAL_PKG}.{submod}"
    if importlib.util.find_spec(full_mod) is None:
        # Should we display a warning message?
        return None
    module = importlib.import_module(full_mod)
    return getattr(module, name)


# for transformer submodule
class CompatFinder(MetaPathFinder, Loader):
    def find_spec(self, fullname, path, target=None):
        if not fullname.startswith(_SHIM_PKG):
            return None

        suffix = fullname[len(_SHIM_PKG) :].lstrip(".")
        parts = suffix.split(".") if suffix else []

        real_submod = None
        for i in range(len(parts), 0, -1):
            prefix = ".".join(parts[:i])
            if prefix in _VERSION_FALLBACK:
                new_mod, old_mod, thresh = _VERSION_FALLBACK[prefix]
                chosen = new_mod if _HF_VER >= version.parse(thresh) else old_mod
                rest = parts[i:]
                real_submod = ".".join([chosen] + rest) if rest else chosen
                break

        if real_submod is None:
            real_submod = suffix

        real_fullname = f"{_REAL_PKG}.{real_submod}" if real_submod else _REAL_PKG
        try:
            real_spec = importlib.util.find_spec(real_fullname)
        except (ImportError, ModuleNotFoundError, ValueError) as e:
            real_spec = None
        if real_spec is None:
            spec = ModuleSpec(name=fullname, loader=self, origin=None)
            spec.submodule_search_locations = []
            return spec

        spec = ModuleSpec(
            name=fullname,
            loader=self,
            origin=real_spec.origin,
            is_package=bool(real_spec.submodule_search_locations),
        )
        spec.submodule_search_locations = real_spec.submodule_search_locations
        return spec

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        real_name = module.__spec__.name.replace(_SHIM_PKG, _REAL_PKG, 1)

        def __getattr__(name):
            # Should we display a warning message?
            return None

        try:
            real_mod = importlib.import_module(real_name)
            module.__dict__.update(real_mod.__dict__)
            module.__all__ = list(getattr(real_mod, "__all__", []))
            module.__getattr__ = __getattr__
        except (ImportError, ModuleNotFoundError):
            pass


sys.meta_path.insert(0, CompatFinder())
