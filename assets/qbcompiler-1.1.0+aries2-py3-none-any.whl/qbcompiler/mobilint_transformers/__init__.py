try:
    from . import compat_transformers
except Exception as e:
    print(e)
