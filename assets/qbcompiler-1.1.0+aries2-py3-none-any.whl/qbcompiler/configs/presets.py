"""Auto-generated preset definitions from config_schema.yaml."""

from typing import Dict, List
from .models import CompileConfig

# Preset definitions
PRESETS: Dict[str, dict] = {
    "classification": {
        "description": "Image classification models (ResNet, EfficientNet, ViT, etc.)",
        "config": {"calibration": {"mode": 1, "output": 0}},
    },
    "detection": {
        "description": "Object detection models (YOLO, SSD, DETR, etc.)",
        "config": {"calibration": {"mode": 1, "output": 1}},
    },
    "classification_torchvision": {
        "description": "Torchvision classification models with standard preprocessing",
        "extends": "classification",
        "config": {
            "uint8Input": {"apply": True, "inputs": []},
            "imageChannels": 3,
            "preprocessing": {
                "apply": True,
                "autoConvertFormat": True,
                "pipeline": [
                    {"op": "resize", "height": 256, "width": 256, "mode": "bilinear"},
                    {"op": "centerCrop", "height": 224, "width": 224},
                    {
                        "op": "normalize",
                        "mean": [0.485, 0.456, 0.406],
                        "std": [0.229, 0.224, 0.225],
                        "scaleToUint8": True,
                        "fuseIntoFirstLayer": True,
                    },
                ],
                "inputConfigs": {},
            },
        },
    },
    "yolo_640": {
        "description": "YOLO detection models with 640x640 letterbox preprocessing",
        "extends": "detection",
        "config": {
            "uint8Input": {"apply": True, "inputs": []},
            "imageChannels": 3,
            "preprocessing": {
                "apply": True,
                "autoConvertFormat": True,
                "pipeline": [
                    {"op": "letterbox", "height": 640, "width": 640, "padValue": 114}
                ],
                "inputConfigs": {},
            },
        },
    },
    "yolo_1280": {
        "description": "YOLO detection models with 1280x1280 letterbox preprocessing",
        "extends": "detection",
        "config": {
            "uint8Input": {"apply": True, "inputs": []},
            "imageChannels": 3,
            "preprocessing": {
                "apply": True,
                "autoConvertFormat": True,
                "pipeline": [
                    {"op": "letterbox", "height": 1280, "width": 1280, "padValue": 114}
                ],
                "inputConfigs": {},
            },
        },
    },
    "llm": {
        "description": "Large Language Models (LLaMA, Qwen, Gemma, etc.)",
        "config": {
            "llm": {
                "apply": True,
                "attributes": {"maxSequenceLength": 4096, "maxCacheLength": 4096},
            },
            "calibration": {"mode": 0, "output": 0},
        },
    },
    "llm_fast": {
        "description": "LLM with faster compilation (less accuracy optimization)",
        "extends": "llm",
        "config": {
            "optq": {"apply": False},
            "equivalentTransformation": {
                "QK": {"apply": True},
                "UD": {"apply": True},
                "VO": {"apply": True},
                "SpinR1": {"apply": True},
                "SpinR2": {"apply": True},
                "OptimizeFFN": {"apply": True},
            },
            "llm": {
                "apply": True,
                "attributes": {"calibration": {"useFullSeqLength": True}},
            },
        },
    },
    "vision_transformer": {
        "description": "Vision Transformer models (ViT, DeiT, Swin, etc.)",
        "config": {
            "calibration": {"method": 1, "mode": 0},
            "bit": {"transformer": {"activation": {"output": 16, "ffn": 16}}},
        },
    },
    "multimodal": {
        "description": "Multimodal models (CLIP, BLIP, LLaVA, etc.)",
        "config": {"calibration": {"method": 3}, "llm": {"apply": True}},
    },
}


def list_presets() -> List[str]:
    """List available preset names."""
    return list(PRESETS.keys())


def get_preset(name: str) -> CompileConfig:
    """Get a CompileConfig from a preset name."""
    if name not in PRESETS:
        available = ", ".join(list_presets())
        raise ValueError(f"Unknown preset '{name}'. Available: {available}")

    preset = PRESETS[name]
    config_data = preset["config"].copy()

    # Handle inheritance
    if "extends" in preset:
        base = get_preset(preset["extends"])
        base_data = base.model_dump(by_alias=True, exclude_none=True)
        # Deep merge
        _deep_merge(base_data, config_data)
        config_data = base_data

    return CompileConfig.model_validate(config_data)


def _deep_merge(base: dict, override: dict) -> None:
    """Deep merge override into base (mutates base)."""
    for key, value in override.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value


class Preset:
    """Preset utility class."""

    @staticmethod
    def list() -> List[str]:
        """List available preset names."""
        return list_presets()

    @staticmethod
    def get(name: str) -> CompileConfig:
        """Get a preset by name."""
        return get_preset(name)

    @staticmethod
    def describe(name: str) -> str:
        """Get preset description."""
        if name not in PRESETS:
            raise ValueError(f"Unknown preset: {name}")
        return PRESETS[name].get("description", "")
