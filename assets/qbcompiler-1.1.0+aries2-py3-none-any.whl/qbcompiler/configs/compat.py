"""
Auto-generated compatibility layer for C++ quantizer JSON format.

Provides to_cpp_dict() methods that generate the exact JSON structure
expected by the C++ quantizer.
"""

from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .models import (
        Uint8InputConfig,
        PreprocessingConfig,
        ResourceManagementConfig,
        CalibrationConfig,
        BitConfig,
        OptqConfig,
        ModConfig,
        LlmConfig,
        EquivalentTransformationConfig,
        SearchWeightScaleConfig,
        RuntimeOptions,
        SaveSampleConfig,
        CompileConfig,
    )


def uint8_input_to_cpp_dict(config: "Uint8InputConfig") -> Dict[str, Any]:
    """Convert Uint8InputConfig to C++ quantizer JSON format."""
    return {
        "apply": config.apply,
        "inputs": config.inputs,
        "divisionFactor": config.division_factor,
    }


def preprocessing_to_cpp_dict(config: "PreprocessingConfig") -> Dict[str, Any]:
    """Convert PreprocessingConfig to C++ quantizer JSON format."""
    return {
        "apply": config.apply,
        "autoConvertFormat": config.auto_convert_format,
        "pipeline": config.pipeline,
        "inputConfigs": config.input_configs,
    }


def resource_management_to_cpp_dict(
    config: "ResourceManagementConfig",
) -> Dict[str, Any]:
    """Convert ResourceManagementConfig to C++ quantizer JSON format."""
    return {
        "weightDtype": config.weight_dtype,
        "useGPUOnlyForCalibration": config.use_gpu_only_for_calibration,
        "weightMemory": {"method": config.weight_memory.method},
    }


def calibration_to_cpp_dict(config: "CalibrationConfig") -> Dict[str, Any]:
    """Convert CalibrationConfig to C++ quantizer JSON format."""
    return {
        "methodList": config.method_list,
        "method": config.method,
        "outputList": config.output_list,
        "output": config.output,
        "modeList": config.mode_list,
        "mode": config.mode,
        "clusteringMethodsList": config.clustering_methods_list,
        "clusteringMethods": config.clustering_methods,
        "actScaleMin": config.act_scale_min,
        "act16ScaleMin": config.act16_scale_min,
        "weightScaleMin": config.weight_scale_min,
        "weight16ScaleMin": config.weight16_scale_min,
        "minClipRatio": config.min_clip_ratio,
        "maxPercentile": {
            "percentile": config.max_percentile.percentile,
            "topKRatio": config.max_percentile.topk_ratio,
            "maxEach": config.max_percentile.max_each,
            "maxTotal": config.max_percentile.max_total,
            "perChDivisor": config.max_percentile.per_ch_divisor,
        },
        "fastDist": {
            "sizeCali": config.fast_dist.size_cali,
            "kernelSize": config.fast_dist.kernel_size,
            "stackSize": config.fast_dist.stack_size,
        },
        "histogram": {
            "percentile": config.histogram.percentile,
            "useGPU": config.histogram.use_gpu,
            "numBins": config.histogram.num_bins,
            "numSamples": config.histogram.num_samples,
            "bufferSize": config.histogram.buffer_size,
            "minBinWidth": config.histogram.min_bin_width,
            "searchPercentileMin": config.histogram.search_percentile_min,
            "searchPercentileMax": config.histogram.search_percentile_max,
            "numSearch": config.histogram.num_search,
            "searchType": config.histogram.search_type,
        },
        "layerOverrides": {"actScaleMin": config.layer_overrides.act_scale_min},
        "statistics": {
            "apply": config.statistics.apply,
            "savePath": config.statistics.save_path,
            "loadPath": config.statistics.load_path,
            "percentiles": config.statistics.percentiles,
            "percentileIndex": config.statistics.percentile_index,
        },
    }


def bit_to_cpp_dict(config: "BitConfig") -> Dict[str, Any]:
    """Convert BitConfig to C++ quantizer JSON format."""
    return {
        "transformer": {
            "activation": {
                "query": config.transformer.activation.query,
                "key": config.transformer.activation.key,
                "value": config.transformer.activation.value,
                "output": config.transformer.activation.output,
                "ffn": config.transformer.activation.ffn,
                "head": config.transformer.activation.head,
            },
            "weight": {
                "query": config.transformer.weight.query,
                "key": config.transformer.weight.key,
                "value": config.transformer.weight.value,
                "output": config.transformer.weight.output,
                "ffn": config.transformer.weight.ffn,
                "head": config.transformer.weight.head,
            },
            "mixedPrecision": {
                "apply": config.transformer.mixed_precision.apply,
                "typeWise": config.transformer.mixed_precision.type_wise,
                "prune": config.transformer.mixed_precision.prune,
                "bit2": config.transformer.mixed_precision.bit_2,
                "bit4": config.transformer.mixed_precision.bit_4,
                "bit8": config.transformer.mixed_precision.bit_8,
                "importanceThreshold_low": config.transformer.mixed_precision.importance_threshold_low,
                "importanceThreshold_high": config.transformer.mixed_precision.importance_threshold_high,
            },
        },
        "saveInfo": {
            "savePath": config.save_info.save_path,
            "loadPath": config.save_info.load_path,
        },
        "layerOverrides": {
            "activation16Bits": config.layer_overrides.activation_16bits,
            "weight16Bits": config.layer_overrides.weight_16bits,
        },
    }


def optq_to_cpp_dict(config: "OptqConfig") -> Dict[str, Any]:
    """Convert OptqConfig to C++ quantizer JSON format."""
    return {
        "apply": config.apply,
        "attributes": {
            "actOrder": config.attributes.act_order,
            "blockSize": config.attributes.block_size,
            "percDamp": config.attributes.perc_damp,
            "applyLayers": config.attributes.apply_layers,
            "excludeLayers": config.attributes.exclude_layers,
        },
    }


def mod_to_cpp_dict(config: "ModConfig") -> Dict[str, Any]:
    """Convert ModConfig to C++ quantizer JSON format."""
    return {
        "apply": config.apply,
        "attributes": {
            "epochs": config.attributes.epochs,
            "warmupEpochs": config.attributes.warmup_epochs,
            "lrMinRatio": config.attributes.lr_min_ratio,
            "saveDir": config.attributes.save_dir,
            "seed": config.attributes.seed,
            "applyLayers": config.attributes.apply_layers,
            "excludeLayers": config.attributes.exclude_layers,
            "modAfterLayerName": config.attributes.mod_after_layer_name,
            "anchors": config.attributes.anchors,
            "useXYXY": config.attributes.use_xyxy,
            "learningRates": {
                "actScale": config.attributes.learning_rates.act_scale,
                "zeropoint": config.attributes.learning_rates.zeropoint,
                "weightScale": config.attributes.learning_rates.weight_scale,
                "weight": config.attributes.learning_rates.weight,
                "bias": config.attributes.learning_rates.bias,
            },
            "training": {
                "batchSize": config.attributes.training.batch_size,
                "qDrop": config.attributes.training.q_drop,
                "quantizeWeight": config.attributes.training.quantize_weight,
                "weightScaleInit": config.attributes.training.weight_scale_init,
                "downresolMode": config.attributes.training.downresol_mode,
                "schedulerType": config.attributes.training.scheduler_type,
            },
            "loss": {
                "type": config.attributes.loss.type,
                "useOutputs": config.attributes.loss.use_outputs,
                "KLTemperature": config.attributes.loss.kl_temperature,
                "reconProb": config.attributes.loss.recon_prob,
                "reconCoeff": config.attributes.loss.recon_coeff,
                "lambda0": config.attributes.loss.lambda_0,
                "lambda1": config.attributes.loss.lambda_1,
                "lambda2": config.attributes.loss.lambda_2,
                "lambda3": config.attributes.loss.lambda_3,
                "customLossJITPath": config.attributes.loss.custom_loss_jit_path,
            },
            "postProcessing": {
                "post": config.attributes.post_processing.post,
                "boxConfThres": config.attributes.post_processing.box_conf_thres,
                "boxIoUThres": config.attributes.post_processing.box_iou_thres,
            },
        },
    }


def llm_to_cpp_dict(config: "LlmConfig") -> Dict[str, Any]:
    """Convert LlmConfig to C++ quantizer JSON format."""
    return {
        "apply": config.apply,
        "attributes": {
            "maxDataLength": config.attributes.max_data_length,
            "maxSequenceLength": config.attributes.max_sequence_length,
            "maxCacheLength": config.attributes.max_cache_length,
            "maxCoreDataLength": config.attributes.max_core_data_length,
            "calibration": {
                "randomSeqLength": config.attributes.calibration.random_seq_length,
                "useFullSeqLength": config.attributes.calibration.use_full_seq_length,
                "useCustomMaskInput": config.attributes.calibration.use_custom_mask_input,
            },
            "runtime": {
                "useGlobalCore": config.attributes.runtime.use_global_core,
                "batchSize": config.attributes.runtime.batch_size,
                "npuCoreIds": config.attributes.runtime.npu_core_ids,
                "dynamicRope": config.attributes.runtime.dynamic_rope,
            },
            "debug": {
                "apply": config.attributes.debug.apply,
                "batchDebugBundleSize": config.attributes.debug.batch_debug_bundle_size,
            },
        },
    }


def equivalent_transformation_to_cpp_dict(
    config: "EquivalentTransformationConfig",
) -> Dict[str, Any]:
    """Convert EquivalentTransformationConfig to C++ quantizer JSON format."""
    return {
        "seed": config.seed,
        "applyHadamardRotationMatrix": config.apply_hadamard_rotation_matrix,
        "NormConv": {
            "apply": config.norm_conv.apply,
            "learn": config.norm_conv.learn,
            "smoothingFactor": config.norm_conv.smoothing_factor,
            "minGamma": config.norm_conv.min_gamma,
            "maxGamma": config.norm_conv.max_gamma,
        },
        "QK": {
            "apply": config.qk.apply,
            "smoothingFactor": config.qk.smoothing_factor,
            "minGamma": config.qk.min_gamma,
            "maxGamma": config.qk.max_gamma,
        },
        "UD": {
            "apply": config.ud.apply,
            "learn": config.ud.learn,
            "smoothingFactor": config.ud.smoothing_factor,
            "minGamma": config.ud.min_gamma,
            "maxGamma": config.ud.max_gamma,
        },
        "VO": {
            "apply": config.vo.apply,
            "smoothingFactor": config.vo.smoothing_factor,
            "minGamma": config.vo.min_gamma,
            "maxGamma": config.vo.max_gamma,
        },
        "FeedForwardMultiLUT": {
            "apply": config.feed_forward_multi_lut.apply,
            "breakpoints": config.feed_forward_multi_lut.breakpoints,
        },
        "SpinR1": {
            "apply": config.spin_r1.apply,
            "matrixPath": config.spin_r1.matrix_path,
        },
        "HeadOutChRotation": {
            "apply": config.head_out_ch_rotation.apply,
            "matrixPath": config.head_out_ch_rotation.matrix_path,
        },
        "InRotation": {
            "apply": config.in_rotation.apply,
            "matrixPath": config.in_rotation.matrix_path,
            "inputNames": config.in_rotation.input_names,
        },
        "SpinR2": {
            "apply": config.spin_r2.apply,
            "learn": config.spin_r2.learn,
            "matrixPath": config.spin_r2.matrix_path,
        },
        "QKRotation": {
            "apply": config.qk_rotation.apply,
            "matrixPath": config.qk_rotation.matrix_path,
        },
        "FlattenQuant": {
            "apply": config.flatten_quant.apply,
            "learn": config.flatten_quant.learn,
            "applyThreshold": config.flatten_quant.apply_threshold,
            "maxOverhead": config.flatten_quant.max_overhead,
        },
        "OptimizeFFN": {
            "apply": config.optimize_ffn.apply,
            "chPerFFN": config.optimize_ffn.ch_per_ffn,
        },
    }


def search_weight_scale_to_cpp_dict(
    config: "SearchWeightScaleConfig",
) -> Dict[str, Any]:
    """Convert SearchWeightScaleConfig to C++ quantizer JSON format."""
    return {
        "apply": config.apply,
        "transformer": {
            "query": config.transformer.query,
            "key": config.transformer.key,
            "value": config.transformer.value,
            "out": config.transformer.out,
            "ffn": config.transformer.ffn,
        },
    }


def runtime_options_to_cpp_dict(config: "RuntimeOptions") -> Dict[str, Any]:
    """Convert RuntimeOptions to C++ quantizer JSON format."""
    return {"version": config.version}


def save_sample_to_cpp_dict(config: "SaveSampleConfig") -> Dict[str, Any]:
    """Convert SaveSampleConfig to C++ quantizer JSON format."""
    return {
        "apply": config.apply,
        "mode": config.mode,
        "batchSize": config.batch_size,
        "batchSeqLens": config.batch_seq_lens,
        "saveFolder": config.save_folder,
        "dtype": config.dtype,
    }


def compile_config_to_cpp_dict(
    config: "CompileConfig",
) -> Dict[str, Any]:
    """
    Convert CompileConfig to C++ quantizer JSON format.

    This produces the exact JSON structure expected by the C++ quantizer.
    """

    # Build result
    result = {}

    result["uint8Input"] = (
        uint8_input_to_cpp_dict(config.uint8_input)
        if config.uint8_input
        else {"apply": False}
    )

    result["preprocessing"] = (
        preprocessing_to_cpp_dict(config.preprocessing)
        if config.preprocessing
        else {"apply": False}
    )

    if config.resource_management:
        result["resourceManagement"] = resource_management_to_cpp_dict(
            config.resource_management
        )
    else:
        result["resourceManagement"] = {
            "weightDtype": "float32",
            "useGPUOnlyForCalibration": True,
            "weightMemory": {"method": 0, "methodList": []},
        }

    result["quantization"] = {
        "calibration": calibration_to_cpp_dict(config.calibration)
        if config.calibration
        else {},
        "bit": bit_to_cpp_dict(config.bit) if config.bit else {},
    }

    result["advancedQuantization"] = {
        "optq": optq_to_cpp_dict(config.optq)
        if config.optq
        else {"apply": False, "attributes": {}},
        "mod": mod_to_cpp_dict(config.mod)
        if config.mod
        else {"apply": False, "attributes": {}},
        "EquivalentTransformation": equivalent_transformation_to_cpp_dict(
            config.equivalent_transformation
        )
        if config.equivalent_transformation
        else {},
        "searchWeightScale": search_weight_scale_to_cpp_dict(config.search_weight_scale)
        if config.search_weight_scale
        else {"apply": False},
    }

    result["llm"] = (
        llm_to_cpp_dict(config.llm)
        if config.llm
        else {"apply": False, "attributes": {}}
    )

    result["runtimeOptions"] = (
        runtime_options_to_cpp_dict(config.runtime_options)
        if config.runtime_options
        else {}
    )

    result["saveSample"] = (
        save_sample_to_cpp_dict(config.save_sample)
        if config.save_sample
        else {"apply": False}
    )

    result["modelPaths"] = config.model_paths
    result["calibDataPaths"] = config.calib_data_path
    result["savePaths"] = config.save_paths
    result["useRandomCalib"] = config.use_random_calib
    result["saveMsgpackName"] = config.save_msgpack_name
    result["inferenceScheme"] = config.inference_scheme
    result["cpuOffload"] = config.cpu_offload
    result["forceNpuInputReposition"] = config.force_npu_input_reposition
    result["forceNpuOutputReposition"] = config.force_npu_output_reposition
    result["optimizeOption"] = config.optimize_option
    result["bufferMode"] = config.buffer_mode
    result["inputShapeDict"] = config.input_shape_dict
    result["device"] = config.device
    result["dtype"] = config.dtype
    result["imageChannels"] = config.image_channels
    result["configVersion"] = config.config_version

    return result


# Monkey-patch the models to add to_cpp_dict methods
def patch_models():
    """Add to_cpp_dict() methods to generated model classes."""
    from . import models

    # Add to_cpp_dict to CompileConfig
    models.CompileConfig.to_cpp_dict = lambda self: compile_config_to_cpp_dict(self)

    # Add to_cpp_dict to Uint8InputConfig
    models.Uint8InputConfig.to_cpp_dict = lambda self: uint8_input_to_cpp_dict(self)

    # Add to_cpp_dict to PreprocessingConfig
    models.PreprocessingConfig.to_cpp_dict = lambda self: preprocessing_to_cpp_dict(
        self
    )

    # Add to_cpp_dict to ResourceManagementConfig
    models.ResourceManagementConfig.to_cpp_dict = (
        lambda self: resource_management_to_cpp_dict(self)
    )

    # Add to_cpp_dict to CalibrationConfig
    models.CalibrationConfig.to_cpp_dict = lambda self: calibration_to_cpp_dict(self)

    # Add to_cpp_dict to BitConfig
    models.BitConfig.to_cpp_dict = lambda self: bit_to_cpp_dict(self)

    # Add to_cpp_dict to OptqConfig
    models.OptqConfig.to_cpp_dict = lambda self: optq_to_cpp_dict(self)

    # Add to_cpp_dict to ModConfig
    models.ModConfig.to_cpp_dict = lambda self: mod_to_cpp_dict(self)

    # Add to_cpp_dict to LlmConfig
    models.LlmConfig.to_cpp_dict = lambda self: llm_to_cpp_dict(self)

    # Add to_cpp_dict to EquivalentTransformationConfig
    models.EquivalentTransformationConfig.to_cpp_dict = (
        lambda self: equivalent_transformation_to_cpp_dict(self)
    )

    # Add to_cpp_dict to SearchWeightScaleConfig
    models.SearchWeightScaleConfig.to_cpp_dict = (
        lambda self: search_weight_scale_to_cpp_dict(self)
    )

    # Add to_cpp_dict to RuntimeOptions
    models.RuntimeOptions.to_cpp_dict = lambda self: runtime_options_to_cpp_dict(self)

    # Add to_cpp_dict to SaveSampleConfig
    models.SaveSampleConfig.to_cpp_dict = lambda self: save_sample_to_cpp_dict(self)


# Auto-patch on import
patch_models()
