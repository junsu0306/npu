"""Auto-generated enum definitions from config_schema.yaml."""

from enum import Enum


class Device(str, Enum):
    gpu = "gpu"
    cpu = "cpu"

    def __str__(self) -> str:
        return self.value


class InferenceScheme(str, Enum):
    single = "single"
    multi = "multi"
    _global = "global"
    global4 = "global4"
    global8 = "global8"
    all = "all"

    def __str__(self) -> str:
        return self.value


class LutClusteringMethod(str, Enum):
    Scale = "Scale"
    Scale2D = "Scale2D"
    ReparameterizedL2 = "ReparameterizedL2"
    SubgraphIoU = "SubgraphIoU"
    DomainAwareL2 = "DomainAwareL2"
    OverlapWeightedL2 = "OverlapWeightedL2"

    def __str__(self) -> str:
        return self.value


class Method(str, Enum):
    DeleteFloat = "DeleteFloat"
    SaveFloat = "SaveFloat"
    MoveFloat = "MoveFloat"
    KeepFloat = "KeepFloat"
    KeepAll = "KeepAll"

    def __str__(self) -> str:
        return self.value


class QuantMethod(str, Enum):
    WChALayer = "WChALayer"
    WChAMulti = "WChAMulti"
    WChALayerZeropoint = "WChALayerZeropoint"
    WChAMultiZeropoint = "WChAMultiZeropoint"

    def __str__(self) -> str:
        return self.value


class QuantMode(str, Enum):
    Max = "Max"
    MaxPercentile = "MaxPercentile"
    Histogram = "Histogram"

    def __str__(self) -> str:
        return self.value


class QuantOutput(str, Enum):
    Layer = "Layer"
    Ch = "Ch"
    Sigmoid = "Sigmoid"

    def __str__(self) -> str:
        return self.value


class SearchType(str, Enum):
    Percentile = "Percentile"
    MSE = "MSE"
    KL = "KL"

    def __str__(self) -> str:
        return self.value
