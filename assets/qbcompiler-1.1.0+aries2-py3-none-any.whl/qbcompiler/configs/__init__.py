"""Auto-generated config module from config_schema.yaml."""

from .models import (
    CompileConfig,
    Uint8InputConfig,
    PreprocessingConfig,
    ResourceManagementConfig,
    CalibrationConfig,
    BitConfig,
    OptqConfig,
    ModConfig,
    LlmConfig,
    EquivalentTransformationConfig,
    SearchWeightScaleConfig,
    RuntimeOptions,
    SaveSampleConfig,
    SCHEMA_VERSION,
)
from .presets import Preset, get_preset, list_presets
from .enums import (
    Device,
    InferenceScheme,
    LutClusteringMethod,
    Method,
    QuantMethod,
    QuantMode,
    QuantOutput,
    SearchType,
)

# Import compat to patch models with to_cpp_dict() methods
from . import compat  # noqa: F401

# Legacy compatibility: QuantizationConfig is now split into CalibrationConfig + BitConfig
# For new code, use CalibrationConfig and BitConfig directly
QuantizationConfig = CalibrationConfig  # Alias for backward compatibility


# Factory function for backward compatibility
def get_compile_config(**kwargs) -> CompileConfig:
    """Create a CompileConfig with the given parameters.

    This is a compatibility wrapper. For new code, use CompileConfig directly
    or CompileConfig.from_preset() for preset-based configuration.
    """
    return CompileConfig(**kwargs)


__all__ = [
    # Main config
    "CompileConfig",
    "get_compile_config",
    # Sub-configs
    "Uint8InputConfig",
    "PreprocessingConfig",
    "ResourceManagementConfig",
    "CalibrationConfig",
    "BitConfig",
    "OptqConfig",
    "ModConfig",
    "LlmConfig",
    "EquivalentTransformationConfig",
    "SearchWeightScaleConfig",
    "RuntimeOptions",
    "SaveSampleConfig",
    # Legacy alias
    "QuantizationConfig",
    # Presets
    "Preset",
    "get_preset",
    "list_presets",
    # Enums
    "Device",
    "InferenceScheme",
    "LutClusteringMethod",
    "Method",
    "QuantMethod",
    "QuantMode",
    "QuantOutput",
    "SearchType",
    # Version
    "SCHEMA_VERSION",
]
