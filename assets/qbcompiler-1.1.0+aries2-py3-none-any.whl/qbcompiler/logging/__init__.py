import logging

DEFAULT_LOG_LEVEL = logging.WARN
DEFAULT_FORMAT = "[%(asctime)s] %(name)s : [%(levelname)s] %(message)s"
DEBUG_FORMAT = "[%(asctime)s] %(filename)s %(funcName)s: [%(levelname)s] %(message)s"
LOG_ENV_VAR = "QBCOMPILER_LOGS"


def get_logger(name, level=logging.INFO):
    log = logging.getLogger(name)
    if level is not None:
        log.setLevel(level)

    if level == logging.DEBUG:
        formatter = logging.Formatter(DEBUG_FORMAT, datefmt="%Y-%m-%d %H:%M:%S")
    else:
        formatter = logging.Formatter(DEFAULT_FORMAT, datefmt="%Y-%m-%d %H:%M:%S")

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    log.addHandler(stream_handler)

    # prevent the log messages from being passed to the root logger
    log.propagate = False

    return log


# if __name__ == "__main__":
#     # Option 1. Set root log level
#     logging.basicConfig(level=logging.INFO)
#     log = get_logger("option 1")
#     log.debug("debug test (root)")  # not printed
#     log.info("info test (root)")
#     log.warning("warn test (root)")
#     log.error("error test (root)")

#     # Option 2. Set log level manually
#     log = get_logger("option 2", logging.DEBUG)
#     log.debug("debug test")
#     log.info("info test")
#     log.warning("warn test")
#     log.error("error test")

#     # Option 3. Set log level manually...