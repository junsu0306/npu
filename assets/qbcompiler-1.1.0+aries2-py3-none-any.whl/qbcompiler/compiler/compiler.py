import ctypes
import copy
import importlib
import multiprocessing
import os
import pathlib
import traceback
import uuid
import torch
import numpy
import threading
import itertools
import sys
import time

from typing import Dict, List, Union
from collections.abc import Mapping, Sequence
from contextlib import contextmanager
from pathlib import Path

from qbcompiler.configs import CompileConfig
from qbcompiler.compiler.utils import _to_list
from qbcompiler.model_dict.common import SubGraph
from qbcompiler.model_dict.common.device import DeviceType_LIST
from qbcompiler.model_dict.parser.graph_transform import OperatorGraphTransform
from qbcompiler.model_dict.parser.parser import (
    ModelParser as LegacyModelParser,
    ParserConfig,
)
from qbcompiler.model_dict.parser.transform_operator import (
    InputOutputReshapeFuse,
    ReshapeRuleSet,
    BodyonlyRuleSet,
    MarkUnsupported,
)
from qbcompiler.model_dict.parser.backend.hf.util import (
    DefaultInputsCaptureContainer,
    InputCaptureCtxManager,
)
from qbcompiler.model_dict.parser.backend.torch.util import wrap_tensor
from qbcompiler.model_dict.parser.backend.torch.object_wrapper import set_attention_mask
from qbcompiler.model_dict.serialize import SerializeMeta, ChainedByteObj
from qbcompiler.logging import get_logger
from qbcompiler.version import __version__

try:
    CURRENT_PATH = os.path.dirname(os.path.abspath(__file__))
    PARENT_PATH = os.path.dirname(CURRENT_PATH)

    lib_path = os.path.join(PARENT_PATH, "libmfu_wrapper.so")
    if not os.path.exists(lib_path):
        raise OSError(f"Required library not found: {lib_path}")

    os.environ[
        "LD_LIBRARY_PATH"
    ] = f"{PARENT_PATH}:{os.environ.get('LD_LIBRARY_PATH', '')}"

    try:
        ctypes.cdll.LoadLibrary(lib_path)
    except OSError as e:
        raise OSError(f"Failed to load library: {e}")

    try:
        import qbcompiler.mmc as mmc
    except ImportError as e:
        raise ImportError(f"Failed to import qbcompiler.mmc: {e}")

    IMPORTMMC = True

except (OSError, ImportError) as e:
    print(f"Failed to initialize MMC: {e}")
    IMPORTMMC = False

logger = get_logger(__name__)


@contextmanager
def _cleanup_mblt_path(parsed):
    try:
        yield
    finally:
        if isinstance(parsed, (str, pathlib.Path)):
            _rm_tree(parsed)
        elif isinstance(parsed, list):
            for p in parsed:
                _rm_tree(p)


def _rm_tree(p: pathlib.Path | str):
    if isinstance(p, str):
        p = pathlib.Path(p)
    if p.exists() and p.is_dir():
        for child in p.iterdir():
            if child.is_file():
                child.unlink()
            else:
                _rm_tree(child)
        p.rmdir()


def _spinner_task(stop_event: threading.Event, task_name: str):
    spinner = itertools.cycle(["⣾", "⣽", "⣻", "⢿", "⡿", "⣟", "⣯", "⣷"])
    dot_count = 0
    interval = 0.2
    try:
        while not stop_event.is_set():
            ch = next(spinner)
            dot_count = (dot_count + 1) % 4
            dots = "." * dot_count
            msg = f"[{ch}] {task_name}{dots}"
            sys.stdout.write(f"\r{msg}\033[K")
            sys.stdout.flush()
            stop_event.wait(interval)
    finally:
        sys.stdout.write(f"\r✔ {task_name} Done!          \n")
        sys.stdout.flush()


def _print_ram(header):
    import psutil

    mem = psutil.virtual_memory()
    total_ram = mem.total / (1024**2)  # MB 단위 변환
    used_ram = mem.used / (1024**2)
    available_ram = mem.available / (1024**2)

    bar = "**********************************************************"
    hbar = f"** [RAM] {header} "
    hbar += "*" * (len(bar) - len(hbar))
    print(hbar)
    print(f"  USED     : {used_ram:.2f}/{total_ram:.2f} MB")
    print(f"  AVAILABLE: {available_ram:.2f}/{total_ram:.2f} MB")
    print(f"{bar}\n")


def _is_multi_shape_format(input_shape_dict):
    """Check if dict uses {"multi_shape0": {"axis": N, "values": [...]}} format.

    Returns True if the input_shape_dict uses the new multi-shape format,
    False if it's empty or uses the legacy format.
    """
    if not input_shape_dict:
        return False
    first_val = next(iter(input_shape_dict.values()))
    return isinstance(first_val, dict) and "axis" in first_val and "values" in first_val


def _build_multi_shape_parse_tasks(input_shape_dict):
    """Build parse tasks from multi-shape input_shape_dict.

    Args:
        input_shape_dict: Dict in format {"multi_shape0": {"axis": N, "values": [...]}, ...}

    Returns:
        List of (idx, dynamic_info) tuples where dynamic_info is a dict like:
        {"multi_shape0": {"axis": 1, "value": 100}, "multi_shape1": {"axis": 2, "value": 50}}

    Example:
        input_shape_dict = {
            "multi_shape0": {"axis": 1, "values": [100, 200]},
            "multi_shape1": {"axis": 2, "values": [50, 100]},
        }
        Returns:
            [(0, {"multi_shape0": {"axis": 1, "value": 100}, "multi_shape1": {"axis": 2, "value": 50}}),
             (1, {"multi_shape0": {"axis": 1, "value": 200}, "multi_shape1": {"axis": 2, "value": 100}})]
    """
    # Collect all multi_shapeN entries, sorted by key name
    multi_shape_keys = sorted(
        [k for k in input_shape_dict.keys() if k.startswith("multi_shape")]
    )

    # Extract axes and values for each multi_shape entry
    axes = {k: input_shape_dict[k]["axis"] for k in multi_shape_keys}
    values_lists = [input_shape_dict[k]["values"] for k in multi_shape_keys]

    # Zip values together - each parse task gets one value from each multi_shape
    parse_tasks = []
    for idx, zipped_values in enumerate(zip(*values_lists)):
        dynamic_info = {
            key: {"axis": axes[key], "value": val}
            for key, val in zip(multi_shape_keys, zipped_values)
        }
        parse_tasks.append((idx, dynamic_info))

    return parse_tasks


def _use_new_parser_pipeline(backend: str) -> bool:
    return backend == "onnx"


def _resolve_output_subgraph_path(output_subgraph_path: str, save_path: str):
    if not output_subgraph_path:
        p = pathlib.Path(save_path)
        mblt_filename = f"{str(p.stem)}.mblt"
        if str(p.parent) != ".":
            output_subgraph_path = str(p.parent.joinpath(mblt_filename))
        else:
            output_subgraph_path = mblt_filename
    output_path = pathlib.Path(output_subgraph_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    return str(output_path)


def _make_new_parser_config(parser_config, target_device: str, backend: str):
    from qbcompiler.model_dict_new.parser import (
        get_parser_config as get_new_parser_config,
    )

    cfg = get_new_parser_config(backend=backend)
    cfg.target_device = target_device
    cfg.large_model = getattr(parser_config, "large_model", cfg.large_model)
    return cfg


def _create_parser(
    *,
    model,
    path_to_model,
    backend,
    target_device,
    parser_config,
    feed_dict,
    in_dformats,
    dynamic_axes,
    yolo_decode_include,
    use_custom_mask,
    exclude_first_subgraph,
    mblt_write_path=None,
):
    if _use_new_parser_pipeline(backend):
        from qbcompiler.model_dict_new.parser import ModelParser as NewModelParser

        return NewModelParser(
            model=model,
            path_to_model=path_to_model,
            backend=backend,
            parser_config=_make_new_parser_config(
                parser_config=parser_config,
                target_device=target_device,
                backend=backend,
            ),
            mblt_write_path=mblt_write_path,
            yolo_decode_include=yolo_decode_include,
        )

    return LegacyModelParser(
        model=model,
        path_to_model=path_to_model,
        backend=backend,
        target_device=target_device,
        parser_config=parser_config,
        feed_dict=feed_dict,
        in_dformats=in_dformats,
        dynamic_axes=dynamic_axes,
        yolo_decode_include=yolo_decode_include,
        use_custom_mask=use_custom_mask,
        exclude_first_subgraph=exclude_first_subgraph,
    )


def _run_new_parser_pipeline(
    *,
    parser,
    feed_dict,
    dynamic_axes,
    cpu_offload: bool,
    exclude_first_subgraph: bool,
    save_subgraph_type: int,
    output_subgraph_path: str,
    save_path: str,
    mblt_temp_file_path: str,
):
    def _normalize_new_parser_dynamic_axes(dynamic_axes):
        if dynamic_axes is None or not isinstance(dynamic_axes, Mapping):
            return dynamic_axes

        normalized = {}
        for input_name, axes in dynamic_axes.items():
            if isinstance(axes, Mapping):
                axis_list = []
                for axis in axes.keys():
                    normalized_axis = int(axis)
                    if normalized_axis not in axis_list:
                        axis_list.append(normalized_axis)
                normalized[input_name] = axis_list
            elif isinstance(axes, Sequence) and not isinstance(axes, (str, bytes)):
                normalized[input_name] = list(axes)
            else:
                normalized[input_name] = axes
        return normalized

    largest_supported_only = not cpu_offload
    dynamic_axes = _normalize_new_parser_dynamic_axes(dynamic_axes)

    parsed_model_dict = parser.parse(
        device_alloc=False,
        feed_dict=feed_dict,
        dynamic_axes=dynamic_axes,
        write_mblt=False,
    )

    if save_subgraph_type > 0:
        export_model_dict = copy.deepcopy(parsed_model_dict)
        if save_subgraph_type in (3, 4):
            export_model_dict = parser.allocate_to_devices(
                export_model_dict,
                largest_supported_only=False,
                exclude_first_subgraph=exclude_first_subgraph,
            )
        export_path = _resolve_output_subgraph_path(output_subgraph_path, save_path)
        parser.write_mblt_model(
            export_model_dict,
            export_path,
            ignore_weight=save_subgraph_type in (1, 3),
        )

    final_model_dict = copy.deepcopy(parsed_model_dict)
    if parser.cfg.device_alloc:
        final_model_dict = parser.allocate_to_devices(
            final_model_dict,
            largest_supported_only=largest_supported_only,
            exclude_first_subgraph=exclude_first_subgraph,
        )

    temp_path = pathlib.Path(mblt_temp_file_path)
    temp_path.parent.mkdir(parents=True, exist_ok=True)
    parser.write_mblt_model(final_model_dict, str(temp_path), ignore_weight=False)
    return str(temp_path)


def _save_visualize_subgraph(
    parser, save_subgraph_type: int, output_subgraph_path: str, save_path
):
    # fmt:off
    assert save_subgraph_type in (
        0, 1, 2, 3, 4
    ), f"save_subgraph_type must be in (0,1,2,3,4) but is {save_subgraph_type}"
    # fmt:on

    if save_subgraph_type > 0:
        output_subgraph_path = _resolve_output_subgraph_path(
            output_subgraph_path, save_path
        )
        ignore_weight = save_subgraph_type in (1, 3)
        md, wd = parser.get_md_wd_for_export_subgraph()
        _save_mblt(md, wd, output_subgraph_path, ignore_weight=ignore_weight)


def _serialize_model(model_dict, weight_dict, ignore_weight=False, buffer_mode=1):
    meta = SerializeMeta(mode=buffer_mode)
    return meta.serialize(model_dict, weight_dict, ignore_weight)


def _save_mblt(model_dict, weight_dict, mblt_path, ignore_weight=False):
    barr = _serialize_model(model_dict, weight_dict, ignore_weight)
    _write_mblt(path_to_mblt=mblt_path, barr=barr)
    logger.debug(f"write model subgraphs at {mblt_path}")
    return barr


def _output_transpose_postprocess(parser, model_dict, weight_dict):
    main_sg: SubGraph = model_dict.sg_main()
    rules = InputOutputReshapeFuse.get(["OutputTransposeFuse"])
    OperatorGraphTransform(rules).process(main_sg, weight_dict, {})
    main_sg.update_graph_in_out()
    main_sg.update_next_operator()

    changed = True
    while changed:
        changed = False
        main_sg.update_op_act_connectivity()
        for op in main_sg.operators:
            if 0 == sum(
                len(main_sg.activations[x].consumer_ops) for x in op.options.outputs
            ):
                op.valid = False
                changed = True
        main_sg.operators = [op for op in main_sg.operators if op.valid]
    main_sg.remove_dangling_tensors()
    main_sg.remove_dangling_activations()
    main_sg.update_graph_in_out()
    main_sg.update_next_operator()
    MarkUnsupported(
        main_sg,
        wd=weight_dict,
        target_device=parser.target_device,
        yolo_decode_include=parser._yolo_decode_include,
    ).process()

    if len(model_dict.subgraphs) == 1:
        sg = model_dict.subgraphs[0]
        name_to_idx = {sg.activations[idx].name: idx for idx in sg.outputs}
        if set(name_to_idx.keys()) == set(model_dict.outputs):
            sg.outputs = [name_to_idx[name] for name in model_dict.outputs]
        else:
            # If out names were changed after output transpose poseprocess rule
            model_dict.outputs = list(name_to_idx.keys())

    if len(model_dict.subgraphs) == 1:
        sg = model_dict.subgraphs[0]
        name_to_idx = {sg.activations[idx].name: idx for idx in sg.outputs}
        if set(name_to_idx.keys()) == set(model_dict.outputs):
            sg.outputs = [name_to_idx[name] for name in model_dict.outputs]
        else:
            # If out names were changed after output transpose poseprocess rule
            model_dict.outputs = list(name_to_idx.keys())

    return model_dict, weight_dict


def _write_mblt(path_to_mblt, barr):
    with pathlib.Path(path_to_mblt).open("wb") as f:
        if isinstance(barr, bytes):
            f.write(barr)
        else:
            barr.write(f)


def _run_parsing_in_subprocess(**kwargs):
    with multiprocessing.Pool(1) as pool:
        return pool.apply(_parsing_task, kwds=kwargs)


def _resolve_tokenizer_source(path_to_model, model):
    if model is None:
        return None

    if isinstance(path_to_model, str) and len(path_to_model) > 0:
        return path_to_model

    val = getattr(model, "name_or_path", None)
    if val:
        return val

    cfg = getattr(model, "config", None)
    if cfg is None:
        return None
    return getattr(cfg, "_name_or_path", None) or getattr(cfg, "name_or_path", None)


def _parsing_task(
    model,
    path_to_model,
    backend,
    target_device,
    parser_config,
    feed_dict,
    in_dformats,
    dynamic_axes,
    yolo_decode_include,
    use_custom_mask,
    exclude_first_subgraph,
    save_path: str = None,
    save_subgraph_type: int = 0,
    output_subgraph_path="",
    cpu_offload=False,
    buffer_mode=1,
    mblt_temp_file_path="",
    **kwargs,
):
    if not IMPORTMMC:
        raise ImportError("Fail to import mmc!!")

    hf_config = kwargs.get("hf_config", None)
    if backend == "torch" and hf_config is not None:
        logger.warning(
            "Trying to parse HF-based LLMs and multimodal generative models. "
            "If the Torch model isn’t an LLM/VLM, please don't use hf_config."
        )

        if not isinstance(hf_config, dict):
            raise ValueError("hf_config must be a dict for HF-based parsing.")

        hf_lib = hf_config.get("library", "transformers")

        if model is None:
            loader = hf_config.get("loader")
            if not loader:
                raise ValueError("To load LLMs, hf_config needs 'loader'.")

            module = importlib.import_module(hf_lib)
            try:
                loader_cls = getattr(module, loader)
            except AttributeError as e:
                raise AttributeError(f"'{hf_lib}' has no loader '{loader}'.") from e

            model_args = hf_config.get("model_args", ())
            model_kwargs = hf_config.get("model_kwargs", {})

            if isinstance(path_to_model, str):
                try:
                    model = loader_cls.from_pretrained(
                        path_to_model, *model_args, **model_kwargs
                    )
                except Exception as e:
                    raise RuntimeError(
                        f"Failed to load model via {hf_lib}.{loader}.from_pretrained('{path_to_model}'). "
                        f"Check repo id/path, HF access, and model_kwargs. Original error: {e}"
                    ) from e
            else:
                raise ValueError(
                    "path_to_model must be a string (repo id or local path) when model is None."
                )

        tok_src = _resolve_tokenizer_source(path_to_model, model)
        if not tok_src:
            raise ValueError(
                "Failed to resolve tokenizer source. "
                "Provide a valid path_to_model or ensure model.name_or_path is set."
            )

        tokenizer_args = hf_config.get("tokenizer_args", ())
        tokenizer_kwargs = hf_config.get("tokenizer_kwargs", {})

        tokenizer = None
        tok_name = hf_config.get("tokenizer", None)

        if tok_name:
            module = importlib.import_module(hf_lib)
            try:
                tokenizer_cls = getattr(module, tok_name)
            except AttributeError as e:
                raise AttributeError(
                    f"'{hf_lib}' has no tokenizer '{tok_name}'."
                ) from e
            try:
                tokenizer = tokenizer_cls.from_pretrained(
                    tok_src, *tokenizer_args, **tokenizer_kwargs
                )
            except Exception as e:
                raise RuntimeError(
                    f"Failed to load tokenizer via {hf_lib}.{tok_name}.from_pretrained('{tok_src}'). "
                    f"Check tokenizer files/deps and tokenizer_kwargs. Original error: {e}"
                ) from e
        else:
            try:
                from transformers import AutoTokenizer
            except ImportError as e:
                raise ImportError(
                    "AutoTokenizer fallback import failed (couldn’t `from transformers import AutoTokenizer`). "
                    "Please check that `transformers` is installed/updated and provides AutoTokenizer, "
                    "or explicitly specify the tokenizer class in hf_config."
                ) from e
            try:
                tokenizer = AutoTokenizer.from_pretrained(
                    tok_src, *tokenizer_args, **tokenizer_kwargs
                )
            except Exception as e:
                raise RuntimeError(
                    f"AutoTokenizer.from_pretrained('{tok_src}') failed. "
                    f"Check repo id/path and tokenizer deps. Original error: {e}"
                ) from e

        chat = [
            {"role": "system", "content": "You are a helpful assistant."},
            {
                "role": "user",
                "content": "Give me a short introduction to large language model.",
            },
        ]
        inputs = tokenizer.apply_chat_template(
            chat, add_generation_prompt=True, return_dict=True, return_tensors="pt"
        )

        inputs_container = DefaultInputsCaptureContainer()
        max_call_limit = 1

        target = model
        with InputCaptureCtxManager(
            target,
            max_call_limit,
            inputs_container,
        ) as f:
            output_ids = model.generate(
                **inputs, max_new_tokens=50, temperature=0.2, top_p=0.9, do_sample=True
            )

        feed_dict = inputs_container.captured_kwargs[-1]
        fd_inputs = {}
        for k, v in feed_dict.items():
            if isinstance(v, torch.Tensor):
                wrapped = wrap_tensor(k, v.to(model.device))
                fd_inputs[k] = wrapped
            else:
                fd_inputs[k] = v

        if "input_ids" in fd_inputs:
            fd_inputs["input_ids"].src_shape[-1].set_dynamic(True)
        if "attention_mask" in fd_inputs:
            fd_inputs["attention_mask"].src_shape[-1].set_dynamic(True)
            set_attention_mask(fd_inputs["attention_mask"], "causal_mask")
        if "position_ids" in fd_inputs:
            fd_inputs["position_ids"].src_shape[-1].set_dynamic(True)
        if "cache_position" in fd_inputs:
            fd_inputs["cache_position"].src_shape[0].set_dynamic(True)
        if "past_key_values" not in fd_inputs:
            try:
                from transformers import DynamicCache
            except:
                raise ImportError(
                    "Failed to import transformers. Please refer to the Mobilint Docker environment and install an appropriate version of transformers."
                )
            fd_inputs["past_key_values"] = DynamicCache()
        if "logits_to_keep" not in fd_inputs or (
            "logits_to_keep" in fd_inputs and fd_inputs["logits_to_keep"] != 1
        ):
            fd_inputs["logits_to_keep"] = 1

        if hf_config.get("output_meta", None) is None:
            kwargs["output_meta"] = {
                "type": "list",
                "keys": [0],
            }
        else:
            kwargs["output_meta"] = hf_config.get("output_meta", None)
        feed_dict = fd_inputs

    parser = _create_parser(
        model=model,
        path_to_model=path_to_model,
        backend=backend,
        target_device=target_device,
        parser_config=parser_config,
        feed_dict=feed_dict,
        in_dformats=in_dformats,
        dynamic_axes=dynamic_axes,
        yolo_decode_include=yolo_decode_include,
        use_custom_mask=use_custom_mask,
        exclude_first_subgraph=exclude_first_subgraph,
        mblt_write_path=mblt_temp_file_path,
    )

    if _use_new_parser_pipeline(backend):
        return _run_new_parser_pipeline(
            parser=parser,
            feed_dict=feed_dict,
            dynamic_axes=dynamic_axes,
            cpu_offload=cpu_offload,
            exclude_first_subgraph=exclude_first_subgraph,
            save_subgraph_type=save_subgraph_type,
            output_subgraph_path=output_subgraph_path,
            save_path=save_path,
            mblt_temp_file_path=mblt_temp_file_path,
        )

    if not parser.parse_finished:
        parser.parse(
            in_dformats=in_dformats,
            feed_dict=feed_dict,
            dynamic_axes=dynamic_axes,
            save_subgraph_type=save_subgraph_type,
            **kwargs,
        )

    _save_visualize_subgraph(
        parser, save_subgraph_type, output_subgraph_path, save_path
    )

    # model, weight for quantization
    model_dict, weight_dict = parser.get_md_wd(body_only=not cpu_offload)
    if not cpu_offload:
        model_dict, weight_dict = _output_transpose_postprocess(
            parser, model_dict, weight_dict
        )

    _model_name = Path(path_to_model).stem if path_to_model else "model"
    parser.print_ops(_model_name)
    barr = _serialize_model(
        model_dict, weight_dict, ignore_weight=False, buffer_mode=buffer_mode
    )

    mblt_temp_file_path = pathlib.Path(mblt_temp_file_path)
    if not mblt_temp_file_path.parent.exists():
        mblt_temp_file_path.parent.mkdir(parents=True)

    mblt_temp_file_path = str(mblt_temp_file_path)

    try:
        _write_mblt(mblt_temp_file_path, barr)
        logger.info(f"write intermediate file: {mblt_temp_file_path} done.")
        barr_or_path = mblt_temp_file_path
    except Exception as e:
        logger.info(f"write intermediate file: {mblt_temp_file_path} failed.")
        if not isinstance(barr, bytes):
            barr = bytes(barr)
        barr_or_path = barr
    parser.delete_tmp_dir()

    return barr_or_path


def _get_target_device_name(target_device: str = None):
    if IMPORTMMC:
        hw_name = mmc.Compiler().get_hw_type()
    else:
        hw_name = target_device

    if hw_name.lower() not in DeviceType_LIST:
        raise NotImplementedError(f"Not implemented hardware name={hw_name}")
    else:
        return hw_name


def _quantization_task(
    model_paths: Union[str, List[str]],
    compile_config: CompileConfig,
    compile_nde: bool = False,
) -> None:
    compiler = mmc.Compiler()
    compile_config.runtime_options.version = __version__
    compile_config.model_paths = _to_list(model_paths)

    compile_dict = compile_config.to_cpp_dict()
    compiler.set_quantizer_config(compile_dict)

    if compile_nde:
        if not isinstance(compile_config.save_msgpack_name, str):
            raise ValueError(
                "save_msgpack_name must be set as a string for the compile_nde"
            )
        compiler.compile_nde()
    else:
        compiler.compile()


def _torchscript_to_onnx(
    torch_script_path: str, tmp_dir: Path, feed_dict: Dict[str, numpy.ndarray]
):
    if not tmp_dir.exists():
        tmp_dir.mkdir(parents=True)
    if not feed_dict:
        raise ValueError("feed_dict")
    dummy_inputs = [torch.from_numpy(value) for value in feed_dict.values()]
    dummy_input_names = [key for key in feed_dict.keys()]
    name = Path(torch_script_path).stem
    onnx_path = os.path.join(tmp_dir, name + ".onnx")
    try:
        model = torch.jit.load(torch_script_path)
        model.eval()
        torch.onnx.export(
            model,
            dummy_inputs,
            onnx_path,
            input_names=dummy_input_names,
            export_params=True,
        )
        return onnx_path
    except:
        raise ValueError(
            "torchscript can not be exported to onnx, please check feed_dict format or use a onnx file instead of torchscript"
        )


class Compiler:
    def __init__(
        self,
        model,
        backend="onnx",
        target_device: str = None,
        device="cpu",  # todo: fix. argument `device` is confusing with `target_device`.
        feed_dict=None,
        in_dformats=None,
        dynamic_axes=None,
        parser_config=None,
        yolo_decode_include=None,
        use_custom_mask=False,
        exclude_first_subgraph=False,
        **kwargs,
    ):
        self.device = device
        self.feed_dict = feed_dict
        self.in_dformats = in_dformats
        self.dynamic_axes = dynamic_axes
        frontend_base_dir = pathlib.Path("/tmp/qbcompiler/frontend")
        if frontend_base_dir.exists():
            for item in frontend_base_dir.iterdir():
                if item.is_dir():
                    _rm_tree(item)
                else:
                    item.unlink()
        else:
            frontend_base_dir.mkdir(parents=True, exist_ok=True)
        self._mblt_tempfile_dir = frontend_base_dir.joinpath(str(uuid.uuid4()))
        target_device = _get_target_device_name(target_device)

        if parser_config is None:
            parser_config = ParserConfig.default_config(target_device)

        self.path_to_model = None
        self.model = model

        if isinstance(model, str):
            self.path_to_model = model
            self.model = None

        self.kwargs = kwargs

        self.backend = backend
        self.target_device = target_device
        self.parser_config = parser_config
        self.yolo_decode_include = yolo_decode_include
        self.use_custom_mask = use_custom_mask
        self.exclude_first_subgraph = exclude_first_subgraph

        self.parser = None
        # self.parser = ModelParser(
        #     model=model,
        #     path_to_model=path_to_model,
        #     backend=backend,
        #     target_device=target_device,
        #     parser_config=parser_config,
        #     feed_dict=feed_dict,
        #     in_dformats=in_dformats,
        #     yolo_decode_include=yolo_decode_include,
        # )

        if backend == "torchscript":
            self.path_to_model = _torchscript_to_onnx(
                self.path_to_model, self._mblt_tempfile_dir, self.feed_dict
            )
            self.backend = "onnx"

    def parse(
        self, in_dformats=None, feed_dict=None, debug=False, save_subgraph_type: int = 0
    ):
        self.parser.parse(
            in_dformats=in_dformats,
            feed_dict=feed_dict,
            save_subgraph_type=save_subgraph_type,
            debug=debug,
        )

    def parser_inferences(
        self,
        save_all_inference_outputs=False,
        compare_result_output_path="",
        inference_all_outputs_write_path="",
        use_value_dict_data_for_next_input=False,
        quantizer_save=False,
        **kwargs,
    ):
        self.parser.run_inference_and_compare_output_value(
            save_all_inference_outputs=save_all_inference_outputs,
            compare_result_output_path=compare_result_output_path,
            inference_all_outputs_write_path=inference_all_outputs_write_path,
            use_value_dict_data_for_next_input=use_value_dict_data_for_next_input,
            quantizer_save=quantizer_save,
            **kwargs,
        )

    def clear_temp_dir(self):
        self.parser.delete_tmp_dir()

        _rm_tree(pathlib.Path(self._mblt_tempfile_dir))

    def save_visualize_subgraph(
        self, save_subgraph_type: int, output_subgraph_path: str, save_path
    ):
        return _save_visualize_subgraph(
            self.parser, save_subgraph_type, output_subgraph_path, save_path
        )

    def output_transpose_postprocess(self, model_dict, weight_dict):
        return _output_transpose_postprocess(self.parser, model_dict, weight_dict)

    def serialize_model(self, model_dict, weight_dict, ignore_weight=False):
        return _serialize_model(model_dict, weight_dict, ignore_weight)

    def compile(
        self,
        save_subgraph_type: int = 0,
        output_subgraph_path="",
        compile_nde: bool = False,
        compile_config: CompileConfig = None,
        **kwargs,
    ):
        if not IMPORTMMC:
            raise ImportError("Fail to import mmc!!")

        if compile_config is None:
            compile_config = CompileConfig()

        save_paths = compile_config.save_paths
        save_path = save_paths[0] if isinstance(save_paths, list) else save_paths

        mblt_temp_file_path = str(
            pathlib.Path(self._mblt_tempfile_dir).joinpath("model.mblt")
        )
        _kw = {
            "model": self.model,
            "path_to_model": self.path_to_model,
            "backend": self.backend,
            "target_device": self.target_device,
            "parser_config": self.parser_config,
            "feed_dict": self.feed_dict,
            "in_dformats": self.in_dformats,
            "dynamic_axes": self.dynamic_axes,
            "yolo_decode_include": self.yolo_decode_include,
            "use_custom_mask": self.use_custom_mask,
            "exclude_first_subgraph": self.exclude_first_subgraph,
            "save_path": save_path,
            "save_subgraph_type": save_subgraph_type,
            "output_subgraph_path": output_subgraph_path,
            "cpu_offload": compile_config.cpu_offload,
            "buffer_mode": compile_config.buffer_mode,
            "mblt_temp_file_path": mblt_temp_file_path,
            "hf_config": self.kwargs.get("hf_config"),
            "target": self.kwargs.get(
                "target"
            ),  # Pass target (e.g., synthesizer_trn0, synthesizer_trn1)
        }

        stop_event = threading.Event()
        spinner_thread = threading.Thread(
            target=_spinner_task,
            args=(stop_event, "Parsing deep learning model..."),
            daemon=True,
        )
        spinner_thread.start()

        # Build list of parse tasks based on input_shape_dict format
        # New format: {"multi_shape0": {"axis": N, "values": [...]}, "multi_shape1": {...}, ...}
        # Legacy: empty dict (single-shape compile)
        input_shape_dict = compile_config.input_shape_dict

        if _is_multi_shape_format(input_shape_dict):
            parse_tasks = _build_multi_shape_parse_tasks(input_shape_dict)
        else:
            # Legacy: single-shape compile
            parse_tasks = [(0, None)]

        mblt_temp_file_path = []
        try:
            for idx, dynamic_info in parse_tasks:
                # Generate unique file path for each shape
                mblt_filename = (
                    f"model_{idx}.mblt" if len(parse_tasks) > 1 else "model.mblt"
                )
                _kw["mblt_temp_file_path"] = str(
                    pathlib.Path(self._mblt_tempfile_dir).joinpath(mblt_filename)
                )

                # Pass dynamic axis info to parser if multi-shape
                if dynamic_info is not None:
                    # Pass each multi_shape entry as its own kwarg
                    # E.g., _kw["multi_shape0"] = {"axis": 1, "value": 100}
                    for key, val in dynamic_info.items():
                        _kw[key] = val

                # HF models run in subprocess for automatic memory release
                use_subprocess = _kw.get("hf_config") and _kw.get("model") is None
                if use_subprocess:
                    result_path = _run_parsing_in_subprocess(**_kw)
                else:
                    result_path = _parsing_task(**_kw)
                mblt_temp_file_path.append(result_path)

        except Exception:
            tb = traceback.format_exc()
            print(f"Error occurred in parsing task!\n{tb}")
            raise
        finally:
            stop_event.set()
            spinner_thread.join()

        with _cleanup_mblt_path(mblt_temp_file_path):
            _quantization_task(
                mblt_temp_file_path,
                compile_config=compile_config,
                compile_nde=compile_nde,
            )

        _rm_tree(self._mblt_tempfile_dir)

    def mblt_compile(
        self, model, mblt_save_path: str, backend="onnx", cpu_offload=False, **kwargs
    ):
        if isinstance(model, str):
            self.path_to_model = model
            self.model = None

        parser = _create_parser(
            model=self.model,
            path_to_model=self.path_to_model,
            backend=backend,
            target_device=self.target_device,
            parser_config=self.parser_config,
            feed_dict=self.feed_dict,
            in_dformats=self.in_dformats,
            dynamic_axes=self.dynamic_axes,
            yolo_decode_include=self.yolo_decode_include,
            use_custom_mask=self.use_custom_mask,
            exclude_first_subgraph=self.exclude_first_subgraph,
            mblt_write_path=mblt_save_path,
        )
        if _use_new_parser_pipeline(backend):
            parser.cfg.largest_supported_only = not cpu_offload
            _run_new_parser_pipeline(
                parser=parser,
                feed_dict=self.feed_dict,
                dynamic_axes=self.dynamic_axes,
                cpu_offload=cpu_offload,
                exclude_first_subgraph=self.exclude_first_subgraph,
                save_subgraph_type=0,
                output_subgraph_path="",
                save_path=mblt_save_path,
                mblt_temp_file_path=mblt_save_path,
            )
            return
        # fixme: in case of blip, whisper, we use `target`, and `target_sg_state`.
        parser.parse(
            debug=False,
            in_dformats=self.in_dformats,
            feed_dict=self.feed_dict,
            dynamic_axes=self.dynamic_axes,
            **kwargs,
        )

        if cpu_offload:
            md, wd = parser._model_dict, parser._weight_dict
        else:
            md, wd = parser.get_body_md_wd()
            md, wd = _output_transpose_postprocess(parser, md, wd)

        meta = SerializeMeta()
        barr = meta.serialize(md, wd, ignore_weight=False)

        with open(mblt_save_path, "wb") as f:
            if isinstance(barr, bytes):
                f.write(barr)
            elif isinstance(barr, ChainedByteObj):
                barr.write(f)
            print(f"write: {mblt_save_path}")
