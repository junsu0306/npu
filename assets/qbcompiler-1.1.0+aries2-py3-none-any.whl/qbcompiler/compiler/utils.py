def _to_list(val) -> list:
    """Normalize a path parameter to a list of strings."""
    if val is None:
        return []
    if isinstance(val, str):
        return [val] if val else []
    return list(val)
