from typing import List, Optional, Union, Dict, Callable, Tuple
from tqdm import tqdm

from pathlib import Path
from enum import Enum

import PIL.Image
import PIL
import torchvision
import shutil
import numpy as np
import torch
import os
import random, math
import time
import json
import msgpack

Image = PIL.Image.Image
Tensor = torch.Tensor
GeneralTensor = Union[np.ndarray, torch.Tensor]

# Supported calibration file extensions
NUMPY_EXTENSIONS = (".npy",)
TORCH_EXTENSIONS = (".pt", ".pth")
IMAGE_EXTENSIONS = (
    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".bmp",
    ".tga",
    ".psd",
    ".hdr",
    ".pic",
    ".pgm",
    ".ppm",
)
CALIB_EXTENSIONS = NUMPY_EXTENSIONS + TORCH_EXTENSIONS + IMAGE_EXTENSIONS


def is_valid_path(path_str: str, ext=None):
    """Check given path is valid. In detail, it checks
        1. Directory of the path exists. (The path itself does not have to be existing path.)
        2. The given path ends with the given extension if ext is not None.

    Args:
        path_str (str): _description_
        ext (_type_, optional): _description_. Defaults to None.

    Returns:
        _type_: _description_
    """
    if not isinstance(path_str, str):
        raise ValueError("path_str is not string. path_str=", path_str)

    # Check parent directory
    dir_candidate = os.path.dirname(path_str)
    if not os.path.isdir(dir_candidate):
        return False

    res = True if ext is None else path_str.endswith(ext)
    return res


def is_existing_directory(dir_path: str):
    return isinstance(dir_path, str) and os.path.isdir(dir_path)


def make_dir(dir_path: str, parents=True, exist_ok=True):
    Path(dir_path).mkdir(parents=parents, exist_ok=exist_ok)


def get_img_paths_from_dir(dir_path: str, img_ext=["jpg", "jpeg", "png"]):
    if not is_existing_directory(dir_path):
        raise ValueError(f"Given dir_path is not a directory: ", dir_path)

    candidates = os.listdir(dir_path)
    return [
        os.path.join(dir_path, y)
        for y in candidates
        if any([y.lower().endswith(e) for e in img_ext])
    ]


def is_valid_path(path_str: str, ext=None):
    """Check given path is valid. In detail, it checks
        1. Directory of the path exists. (The path itself does not have to be existing path.)
        2. The given path ends with the given extension if ext is not None.

    Args:
        path_str (str): _description_
        ext (_type_, optional): _description_. Defaults to None.

    Returns:
        _type_: _description_
    """
    if not isinstance(path_str, str):
        raise ValueError("path_str is not string. path_str=", path_str)

    # Check parent directory
    dir_candidate = os.path.dirname(path_str)
    if not os.path.isdir(dir_candidate):
        return False

    res = True if ext is None else path_str.endswith(ext)
    return res


class CalibType(Enum):
    SINGLE_DIR = 0
    SINGLE_TXT = 1
    MULTI_DIR = 2
    MULTI_JSON = 3
    MULTI_SHAPE = 4


def _is_multi_shape_format(input_shape_dict):
    """Check if dict uses {"multi_shape0": {"axis": N, "values": [...]}} format."""
    if not input_shape_dict:
        return False
    first_val = next(iter(input_shape_dict.values()))
    return isinstance(first_val, dict) and "axis" in first_val and "values" in first_val


def get_calib_paths_for_multi_shape(
    calib_data_dir: str,
    input_shape_dict: Dict[str, List[tuple]],
    calib_file_name: str = "calib.txt",
    folder_pattern: Optional[str] = None,
) -> List[str]:
    """Get calibration file paths for multi-shape compilation by matching shapes.

    Supports new multi-shape format:
        {"multi_shape0": {"axis": N, "values": [100, 200, 300, ...]}}

    Calibration folders should have trailing numbers matching the values:
        trn0_100/, trn0_200/, 101/, 201/, etc.

    Args:
        calib_data_dir: Base directory containing calibration data
        input_shape_dict: Dict in new multi-shape format
                          e.g., {"multi_shape0": {"axis": 1, "values": [100, 200, 300]}}
        calib_file_name: Name of calibration file in each subdirectory (default: "calib.txt")
        folder_pattern: Optional regex pattern to filter folders (e.g., "trn0_" to only match trn0_* folders)

    Returns:
        List of calibration file paths ordered to match input_shape_dict values

    Raises:
        ValueError: If a matching calibration file cannot be found for a value
    """
    import re

    # Check if using new multi-shape format
    if not _is_multi_shape_format(input_shape_dict):
        raise ValueError(
            "input_shape_dict must use new multi-shape format: "
            '{"multi_shape0": {"axis": N, "values": [...]}}'
        )

    # Extract values from multi_shape0
    axis_spec = input_shape_dict["multi_shape0"]
    values = axis_spec["values"]

    # Check for folder_pattern in input_shape_dict (overrides parameter)
    if folder_pattern is None and "folder_pattern" in axis_spec:
        folder_pattern = axis_spec["folder_pattern"]

    # Pattern to extract trailing number from folder names (e.g., trn0_100 -> 100, or just 101)
    trailing_num_pattern = re.compile(r"_?(\d+)$")

    # Optional pattern to filter folders
    folder_filter = re.compile(folder_pattern) if folder_pattern else None

    # Map values to folders
    value_to_folder = {}
    for entry in os.listdir(calib_data_dir):
        subdir = os.path.join(calib_data_dir, entry)
        if not os.path.isdir(subdir):
            continue

        # Apply folder pattern filter if specified
        if folder_filter and not folder_filter.search(entry):
            continue

        # Try to extract value from folder name
        match = trailing_num_pattern.search(entry)
        if match:
            folder_value = int(match.group(1))
            value_to_folder[folder_value] = subdir

    # Build calibration paths ordered by values
    calib_paths = []
    for val in values:
        if val not in value_to_folder:
            raise ValueError(
                f"No calibration folder found for value={val}. "
                f"Available values: {sorted(value_to_folder.keys())}"
            )

        folder = value_to_folder[val]

        # Look for JSON file first, then txt file
        json_files = [f for f in os.listdir(folder) if f.endswith(".json")]
        txt_files = [f for f in os.listdir(folder) if f.endswith(".txt")]

        if json_files:
            calib_paths.append(os.path.join(folder, json_files[0]))
        elif txt_files:
            calib_paths.append(os.path.join(folder, txt_files[0]))
        elif os.path.exists(os.path.join(folder, calib_file_name)):
            calib_paths.append(os.path.join(folder, calib_file_name))
        else:
            raise ValueError(f"No calibration file found in folder: {folder}")

    return calib_paths


def is_valid_shape(shape: List[int]) -> Tuple[bool, str, Optional[List[int]]]:
    """Check if a shape is valid and determine the dynamic dimensions that are explicitly defined as -1.

    A valid shape must:
    - Not be empty
    - Contain only integers
    - Have positive values for non-dynamic dimensions

    Args:
        shape (List[int]): Shape to check

    Returns:
        Tuple[bool, str, Optional[List[int]]]:
            - bool: True if shape is valid, False otherwise
            - str: The error message if shape is invalid, empty string otherwise
            - Optional[List[int]]: List of dynamic dimension indices if any exist, None otherwise

    Examples:
        >>> is_valid_shape([1, 2, 3])
        (True, "", None)
        >>> is_valid_shape([1, -1, 3])
        (True, "", [1])
        >>> is_valid_shape([1, -1, -1])
        (True, "", [1, 2])
        >>> is_valid_shape([1, 0, 3])
        (False, "Shape [1, 0, 3] has a non-positive dimension.", None)
    """
    # Check if shape is empty
    if not shape:
        return False, "Shape cannot be empty.", None

    # Check if all elements are integers
    if not all(isinstance(dim, int) for dim in shape):
        return False, f"Shape {shape} contains non-integer values.", None

    dynamic_dims = []
    for i, dim in enumerate(shape):
        if dim == -1:
            dynamic_dims.append(i)
        elif dim <= 0:
            return False, f"Shape {shape} has a non-positive dimension.", None

    return True, "", dynamic_dims if dynamic_dims else None


def are_shapes_compatible(
    shape1: List[int], shape2: List[int], dynamic_dims: Optional[List[int]] = None
) -> Tuple[bool, str, Optional[List[int]]]:
    """Check if two shapes are compatible - either exactly same or differ only in dynamic dimensions.
    If dynamic_dims is provided, shapes must vary only in these dimensions.
    If dynamic_dims is not provided, shapes can differ in any dimensions. These dimensions will be
    returned as the new dynamic dimensions.

    Args:
        shape1 (List[int]): First shape to compare
        shape2 (List[int]): Second shape to compare
        dynamic_dims (Optional[List[int]], optional): Known dynamic dimensions from previous comparisons.
            Defaults to None.

    Returns:
        Tuple[bool, str, Optional[List[int]]]:
            - bool: True if shapes are compatible, False otherwise
            - str: The error message if shapes are incompatible, empty string otherwise
            - Optional[List[int]]: List of dynamic dimension indices if any exist, None otherwise.
              Will return existing dynamic_dims if valid dynamic_dims is provided.
              Will return new dynamic_dims if shapes differ in some dimensions.
              Will return None if shapes are incompatible.

    Examples:
        >>> are_shapes_compatible([5, 6, -1], [5, 6, -1], None)
        (True, "", [2])
        >>> are_shapes_compatible([5, 6, -1], [5, 6, 7], None)
        (True, "", [2])
        >>> are_shapes_compatible([5, 6, -1], [5, 6, 7], [2])
        (True, "", [2])
        >>> are_shapes_compatible([5, 6, -1], [5, 6, 7], [1])
        (False, "Shapes [5, 6, -1] and [5, 6, 7] must differ only in dynamic dimensions [1], but differ in [2].", [1])
        >>> are_shapes_compatible([5, 6, 7], [5, 6, 8], None)
        (True, "", [2])
        >>> are_shapes_compatible([5, 6, 7], [5, 6, 8], [2])
        (True, "", [2])
        >>> are_shapes_compatible([5, 6, 7], [5, 6, 8], [1])
        (False, "Shapes [5, 6, 7] and [5, 6, 8] must differ only in dynamic dimensions [1], but differ in [2].", [1])
        >>> are_shapes_compatible([1, -1, -1], [1, 5, 10], None)
        (True, "", [1, 2])
        >>> are_shapes_compatible([1, 5, 10], [1, 6, 12], [1, 2])
        (True, "", [1, 2])
    """
    # Check if shapes have same number of dimensions
    if len(shape1) != len(shape2):
        err_msg = f"Shapes {shape1} and {shape2} have different number of dimensions."
        return False, err_msg, dynamic_dims

    # Determine dynamic dimensions of each shape that are explicitly defined as -1
    is_valid, err_msg, exp_dynamic_dims1 = is_valid_shape(shape1)
    if not is_valid:
        return False, err_msg, dynamic_dims

    is_valid, err_msg, exp_dynamic_dims2 = is_valid_shape(shape2)
    if not is_valid:
        return False, err_msg, dynamic_dims

    # If both shapes have explicit dynamic dimensions (-1)
    if (
        exp_dynamic_dims1 is not None
        and exp_dynamic_dims2 is not None
        and set(exp_dynamic_dims1) != set(exp_dynamic_dims2)
    ):
        err_msg = f"Shapes {shape1} and {shape2} have different dynamic dimensions."
        return False, err_msg, dynamic_dims

    # If one or both shapes have explicit dynamic dimensions (-1)
    if exp_dynamic_dims1 is not None or exp_dynamic_dims2 is not None:
        exp_dynamic_dims = (
            exp_dynamic_dims1 if exp_dynamic_dims1 is not None else exp_dynamic_dims2
        )
        if dynamic_dims is not None and set(exp_dynamic_dims) != set(dynamic_dims):
            err_msg = (
                f"Provided dynamic_dims={dynamic_dims} is not consistent with "
                f"the dynamic dimensions {exp_dynamic_dims} of shapes {shape1} and {shape2}."
            )
            return False, err_msg, dynamic_dims

        # Make sure that dynamic dimensions are set to -1 and compare the shapes
        shape1_copy, shape2_copy = shape1.copy(), shape2.copy()
        for dim in exp_dynamic_dims:
            shape1_copy[dim] = -1
            shape2_copy[dim] = -1
        if shape1_copy != shape2_copy:
            err_msg = f"Shapes {shape1} and {shape2} differ in dimensions other than the dynamic dimensions."
            return False, err_msg, dynamic_dims
        return True, "", exp_dynamic_dims

    # If both shapes have no explicit dynamic dimension (-1)
    # If shapes are exactly same
    if shape1 == shape2:
        return True, "", dynamic_dims

    # Find dimensions that differ
    diff_dims = [i for i in range(len(shape1)) if shape1[i] != shape2[i]]

    if dynamic_dims is not None:
        # If dynamic_dims already known, shapes must vary only in those dimensions
        if not set(diff_dims).issubset(set(dynamic_dims)):
            err_msg = (
                f"Shapes {shape1} and {shape2} must differ only in dynamic "
                f"dimensions {dynamic_dims}, but differ in {diff_dims}."
            )
            return False, err_msg, dynamic_dims
        return True, "", dynamic_dims
    else:
        # No dynamic_dims yet - these become the dynamic dimensions
        return True, "", diff_dims if diff_dims else None


def get_subdir_paths(dir_path: str) -> List[str]:
    """Get all subdirectories in a directory.

    Args:
        dir_path (str): Directory path to search for subdirectories

    Returns:
        List[str]: List of subdirectory paths
    """
    all_subdirs = []
    for subdir in sorted(os.listdir(dir_path)):
        subdir_path = os.path.join(dir_path, subdir)
        if os.path.isdir(subdir_path):
            all_subdirs.append(subdir_path)
    return all_subdirs


def get_npy_paths(dir_path: str) -> List[str]:
    """Get all valid numpy file paths in a directory.

    Args:
        dir_path (str): Directory path to search for numpy files

    Returns:
        List[str]: List of valid numpy file paths
    """
    return [
        os.path.join(dir_path, t)
        for t in sorted(os.listdir(dir_path))
        if is_valid_np_file(os.path.join(dir_path, t))
    ]


def get_calib_paths(dir_path: str) -> List[str]:
    """Get all valid calibration file paths in a directory (numpy, torch, or image).

    Args:
        dir_path (str): Directory path to search for calibration files

    Returns:
        List[str]: List of valid calibration file paths
    """
    return [
        os.path.join(dir_path, t)
        for t in sorted(os.listdir(dir_path))
        if is_valid_calib_file(os.path.join(dir_path, t))
    ]


def get_file_shape(file_path: str) -> List[int]:
    """Get shape from a calibration file (numpy, torch, or image).

    Args:
        file_path (str): Path to calibration file

    Returns:
        List[int]: Shape of the data in the file

    Raises:
        ValueError: If file extension is not supported
    """
    lower_path = file_path.lower()

    if lower_path.endswith(NUMPY_EXTENSIONS):
        return list(np.load(file_path).shape)
    elif lower_path.endswith(TORCH_EXTENSIONS):
        tensor = torch.load(file_path, weights_only=True)
        return list(tensor.shape)
    elif lower_path.endswith(IMAGE_EXTENSIONS):
        with PIL.Image.open(file_path) as img:
            width, height = img.size
            channels = len(img.getbands())
            return [height, width, channels]  # HWC format
    else:
        raise ValueError(f"Unsupported file extension for shape detection: {file_path}")


def get_calib_shapes(dir_path: str) -> List[List[int]]:
    """Get shapes of all valid calibration files in a directory (numpy, torch, or image).

    Args:
        dir_path (str): Directory path to search for calibration files

    Returns:
        List[List[int]]: List of shapes for each calibration file
    """
    calib_paths = get_calib_paths(dir_path)
    return [get_file_shape(calib_path) for calib_path in calib_paths]


def get_npy_shapes(dir_path: str) -> List[Tuple[int, ...]]:
    """Get all valid numpy file shapes in a directory.

    Args:
        dir_path (str): Directory path to search for numpy files

    Returns:
        List[Tuple[int, ...]]: List of numpy file shapes
    """
    npy_paths = get_npy_paths(dir_path)
    return [list(np.load(npy_path).shape) for npy_path in npy_paths]


def build_calib_dict_for_multi_input(
    dir_path: str,
    verbose: bool = False,
    input_names: Optional[List[str]] = None,
    input_shapes: Optional[List[List[int]]] = None,
) -> Tuple[bool, str, Dict]:
    """Build a calibration dictionary for multi-input models.

    The function scans a directory containing calibration data for multi-input models and builds
    a standardized dictionary format. Supports numpy (.npy), torch (.pt, .pth), and image files.
    The expected directory structure is:

    root_dir/
    ├── sample_1/
    │   ├── input1.npy  # Shape compatible with model input 1 (or .pt, .pth, image)
    │   ├── input2.npy  # Shape compatible with model input 2 (or .pt, .pth, image)
    │   └── ...
    ├── sample_2/
    │   ├── input1.npy
    │   ├── input2.npy
    │   └── ...
    └── ...

    Each subdirectory represents one calibration sample and should contain preprocessed
    calibration files for each model input.

    Args:
        dir_path (str): Root directory containing calibration data subdirectories
        verbose (bool, optional): Enable verbose logging of shape updates and auto-generated names
        input_names (Optional[List[str]], optional): List of model input names. If None,
            names will be auto-generated as "input1", "input2", etc.
        input_shapes (Optional[List[List[int]]], optional): Expected shapes for each input.
            If None, shapes will be inferred from first subdirectory.

    Returns:
        Tuple[bool, str, Dict]:
            - bool: Success status (True if dictionary built successfully)
            - str: Error message if failed, empty string if successful
            - Dict: Calibration dictionary with format:
                {
                    "info": {
                        "input names": List[str],  # Input names
                        "input shapes": List[List[int]]  # Input shapes with dynamic dims as -1
                    },
                    "calib paths": List[List[str]]  # Paths to calibration files, grouped by sample
                }

    Raises:
        No exceptions raised - all errors returned via return tuple

    Notes:
        - Input shapes can contain dynamic dimensions marked as -1
        - All calibration files in each subdirectory must be compatible with provided/inferred shapes
        - Files are matched to inputs by comparing shapes and names
        - The first subdirectory is used as reference if input_names or input_shapes are None
        - Supported file types: numpy (.npy), torch (.pt, .pth), images (.jpg, .png, etc.)
    """

    if not os.path.isdir(dir_path):
        err_msg = f'Directory does not exist: "{dir_path}"'
        return False, err_msg, {}

    # Get absolute path to the target directory
    dir_path = os.path.abspath(dir_path)
    all_subdirs = get_subdir_paths(dir_path)
    if len(all_subdirs) == 0:
        err_msg = f'"{dir_path}" does not contain any subdirectories'
        return False, err_msg, {}
    first_subdir = all_subdirs[0]

    if input_names is not None:
        # Check if provided input_names are unique
        if len(input_names) != len(set(input_names)):
            err_msg = f"Input names are not unique: {input_names}"
            return False, err_msg, {}
    else:
        # Construct input names from first subdirectory
        calib_paths_first = get_calib_paths(first_subdir)
        input_names = [f"input{i+1}" for i in range(len(calib_paths_first))]
        if verbose:
            print(
                f"Input names were not provided, constructed new input names: {input_names}"
            )

    if input_shapes is None:
        # Construct input shapes from first subdirectory
        calib_shapes_first = get_calib_shapes(first_subdir)
        input_shapes = calib_shapes_first
        if verbose:
            print(
                f"Input shapes were not provided, constructed new input shapes: {input_shapes}"
            )

    # Check if input_shapes are valid and determine explicit dynamic dimensions (-1)
    dynamic_dims_list = []
    for shape in input_shapes:
        is_valid, err_msg, dyn_dims = is_valid_shape(shape)
        if not is_valid:
            return False, err_msg, {}
        dynamic_dims_list.append(dyn_dims)

    # Check if input_names and input_shapes have the same size
    if len(input_names) != len(input_shapes):
        err_msg = (
            f"Mismatch between number of input names ({len(input_names)}) "
            f"and input shapes ({len(input_shapes)})"
        )
        return False, err_msg, {}

    # Add validation for empty inputs
    if not input_names or not input_shapes:
        err_msg = "Input names and shapes cannot be empty"
        return False, err_msg, {}

    # Collect paths to all calibration files in all subdirectories
    calib_paths = []
    for subdir in all_subdirs:
        subdir_paths = get_calib_paths(subdir)
        subdir_shapes = get_calib_shapes(subdir)
        if len(subdir_paths) != len(input_names):
            err_msg = (
                f"Subdirectory '{os.path.basename(subdir)}' contains {len(subdir_paths)} files "
                f"but {len(input_names)} inputs are expected"
            )
            return False, err_msg, {}

        # Match model inputs to calibration files
        remaining_names = set(input_names)
        map_names_to_paths: Dict[str, str] = {}
        for file_path, file_shape in zip(subdir_paths, subdir_shapes):
            matched = False
            for input_idx, (name, shape) in enumerate(zip(input_names, input_shapes)):
                if name not in remaining_names:
                    continue

                is_compatible, err_msg, dyn_dims = are_shapes_compatible(
                    shape, file_shape, dynamic_dims_list[input_idx]
                )
                if is_compatible:
                    map_names_to_paths[name] = file_path
                    dynamic_dims_list[input_idx] = dyn_dims
                    remaining_names.remove(name)
                    matched = True
                    break

            if not matched:
                err_msg = (
                    f"No matching input found for calibration file '{os.path.basename(file_path)}' "
                    f"with shape {file_shape}"
                )
                return False, err_msg, {}

        # Create a list of paths for each input name
        calib_paths.append([map_names_to_paths[inp_name] for inp_name in input_names])

    # Update input_shapes to include dynamic dimensions
    for i, shape in enumerate(input_shapes):
        if dynamic_dims_list[i] is not None:
            old_shape = shape.copy()
            for dim_idx in dynamic_dims_list[i]:
                shape[dim_idx] = -1
            if verbose:
                print(
                    f"Updated input shape {old_shape} to {shape} for input '{input_names[i]}'"
                )

    # Create a dictionary of input names to paths
    calib_dict = {
        "info": {"input names": input_names, "input shapes": input_shapes},
        "calib paths": calib_paths,
    }
    return True, "", calib_dict


def check_multi_dir_has_same_number_and_shape(
    dir_path: str, verbose: bool = False
) -> bool:
    """Check if a directory structure is valid for multi-input model calibration.

    Supports numpy (.npy), torch (.pt, .pth), and image files.

    For multi-input model calibration, the directory structure should be:
    root_dir/
    ├── sample_1/
    │   ├── input1.npy  # Shape compatible with model input 1 (or .pt, .pth, image)
    │   ├── input2.npy  # Shape compatible with model input 2 (or .pt, .pth, image)
    │   └── ...
    ├── sample_2/
    │   ├── input1.npy
    │   ├── input2.npy
    │   └── ...
    └── ...

    This function validates that:
    1. The directory contains subdirectories (each representing one calibration sample)
    2. Each subdirectory contains the same number of calibration files
    3. Calibration files across subdirectories have shapes compatible with model inputs

    Args:
        dir_path (str): Root directory containing calibration data subdirectories
        verbose (bool, optional): Enable verbose logging of validation results and warnings.
            Defaults to False.

    Returns:
        bool: True if directory structure is valid for calibration,
              False if any validation fails

    Notes:
        - The first subdirectory is used as reference for expected number of files
          and their shapes
        - Compatible shapes means either identical shapes or shapes that differ only
          in designated dynamic dimensions (-1)
    """
    is_valid, _, _ = build_calib_dict_for_multi_input(dir_path, verbose=verbose)
    return is_valid


# Alias for backward compatibility
check_multi_dir_has_same_number_and_shape_npy = (
    check_multi_dir_has_same_number_and_shape
)


def check_calib_data(calib_data_path: str, input_shape_dict: dict = None):
    if os.path.isfile(calib_data_path):
        if calib_data_path.endswith(".txt"):
            return CalibType.SINGLE_TXT
        elif calib_data_path.endswith(".json"):
            return CalibType.MULTI_JSON
        else:
            raise ValueError(
                f"Error! Calib meta file must be either of txt or json format, but got calib_data_path={calib_data_path}."
            )
    elif os.path.isdir(calib_data_path):
        entries = os.listdir(calib_data_path)
        # Check for calibration files (numpy, torch, or image)
        has_calib_file = any(
            is_valid_calib_file(os.path.join(calib_data_path, t)) for t in entries
        )
        has_sub_dir = any(
            os.path.isdir(os.path.join(calib_data_path, t)) for t in entries
        )

        # Check for new multi-shape format FIRST: {"multi_shape0": {"axis": N, "values": [...]}}
        # This must take precedence over SINGLE_DIR to ensure multi-shape compilation works
        if _is_multi_shape_format(input_shape_dict) and has_sub_dir:
            return CalibType.MULTI_SHAPE
        elif has_calib_file:
            return CalibType.SINGLE_DIR
        elif has_sub_dir and check_multi_dir_has_same_number_and_shape(calib_data_path):
            return CalibType.MULTI_DIR

        raise ValueError(
            f"Error! Got unsupported calibration data directory format, "
            f"calib_data_path={calib_data_path}."
        )
    elif calib_data_path == None:
        raise ValueError(
            f"calib_data_path was not defined. please set the calib_data_path"
        )
    else:
        raise ValueError(f"Error! Got unsupported calib_data_path={calib_data_path}.")


def make_calib_data_from_image_dir(
    calib_image_dir: str,
    save_npy_dir: str,
    calib_data_txt: str,
    pre_process_ftn: Callable[[Image], GeneralTensor],
):
    """Make calibartion dataset from given image directory and pre-process function. This is for models with single input. Note that this does not search subdirectories, i.e., conduct only level 1 search.

    Args:
        calib_image_dir (str): Directory of images to use for calibration.
        save_npy_dir (str): Directory to save the preprocessed numpy arrays. This function makes directory if it does not exist.
        calib_data_txt (str): Txt file path that contains the above numpy array paths. This is going to be the input of quantize or compile function.
        pre_process_ftn (Callable[[Image], GeneralTensor]): Pre-processing function. Output tensor layout must be BCHW.
    """
    # Check calib_image_dir
    if not is_existing_directory(calib_image_dir):
        raise ValueError(f"Given calib_image_dir is not a directory: ", calib_image_dir)

    img_path_list = get_img_paths_from_dir(calib_image_dir)

    # Check save_dir
    make_dir(save_npy_dir)
    if len(os.listdir(save_npy_dir)) > 0:
        raise ValueError(f"Given save_dir is not empty.")

    # Check calib_data_txt
    if not is_valid_path(calib_data_txt, ".txt"):
        raise ValueError(
            f"calib_data_txt must be path for txt file but got {calib_data_txt}."
        )

    save_pre_processed_npy_from_img_path_list(
        img_path_list, pre_process_ftn, save_npy_dir
    )
    list_calib_files_in_txt(save_npy_dir, calib_data_txt)


def save_pre_processed_npy_from_img_path_list(
    img_path_list: List[str],
    pre_process_ftn: Callable[[Image], GeneralTensor],
    save_npy_dir: str,
):
    """Save pre-processed images as numpy arrays w/ HWC layout.

    Args:
        img_path_list (List[str]): Image path list
        pre_process_ftn (Callable[[Image], GeneralTensor]): Pre-processing function. Output tensor layout must be BCHW.
        save_npy_dir (str): Directory to save the preprocessed numpy arrays. This function makes directory if it does not exist.
    """
    for img_path in tqdm(img_path_list, desc="Making Numpy Files"):
        pil_image = PIL.Image.open(img_path).convert("RGB")
        out = pre_process_ftn(pil_image)
        if isinstance(out, (list, tuple)) and len(out) == 1:
            out = out[0]
        if isinstance(out, torch.Tensor):
            out = out.numpy()
        elif isinstance(out, np.ndarray):
            pass
        else:
            raise NotImplementedError(f"Got unexpected tensor type: {type(out)}.", out)

        save_npy = out.astype(np.float32)
        # We use HWC layout in calibration; BCHW -> HWC
        save_npy = np.transpose(save_npy.squeeze(), axes=(1, 2, 0))
        fname = os.path.basename(img_path)
        img_name = Path(fname).stem
        save_path = os.path.join(save_npy_dir, img_name + ".npy")
        np.save(save_path, save_npy)


def is_valid_np_file(array_path, verbose: bool = False):
    """
    Make sure that given array_path is actually path to the NumPy file

    :arg1 array_path: path to the NumPy file
    """
    if not os.path.isfile(array_path):
        if verbose:
            print(f'Warning! "{array_path}" is not file. Skipping it.')

        return False
    if not array_path.endswith(".npy"):
        if verbose:
            print(f'Warning! "{array_path}" is not NumPy file. Skipping it.')

        return False
    return True


def is_valid_calib_file(file_path: str, verbose: bool = False) -> bool:
    """Check if file is a valid calibration file (numpy, torch, or image).

    Args:
        file_path (str): Path to the file to check
        verbose (bool, optional): Print warning messages. Defaults to False.

    Returns:
        bool: True if file is a valid calibration file, False otherwise
    """
    if not os.path.isfile(file_path):
        if verbose:
            print(f'Warning! "{file_path}" is not a file. Skipping it.')
        return False

    lower_path = file_path.lower()
    if not any(lower_path.endswith(ext) for ext in CALIB_EXTENSIONS):
        if verbose:
            print(
                f'Warning! "{file_path}" is not a supported calibration file. Skipping it.'
            )
        return False
    return True


def list_calib_files_in_txt(dir_path: str, save_txt_path: str):
    """Prepare calibration txt file from directory with numpy, torch, or image files.

    Unlike numpy-only version, this does NOT validate shapes (quantizer handles that).

    Args:
        dir_path: path to the directory where calibration files are saved
        save_txt_path: path to the txt file where paths to calibration files will be saved

    Raises:
        ValueError: if dir_path does not exist or does not contain any calibration files
    """
    if not os.path.isdir(dir_path):
        raise ValueError(f'Directory does not exist: "{dir_path}"')
    if not save_txt_path.endswith(".txt"):
        raise ValueError(f'File extension should be txt: "{save_txt_path}"')

    dir_path = os.path.abspath(dir_path)
    save_txt_path = os.path.abspath(save_txt_path)

    all_calib_paths = get_calib_paths(dir_path)

    if len(all_calib_paths) == 0:
        raise ValueError(f'"{dir_path}" does not contain any calibration files')

    number_of_lines = len(all_calib_paths)
    with open(save_txt_path, "w") as f:
        for i, calib_path in enumerate(
            tqdm(all_calib_paths, desc="Preparing Calibration TXT File")
        ):
            if i < number_of_lines - 1:
                f.write(f"{calib_path}\n")
            else:
                f.write(f"{calib_path}")


def list_calib_files_in_json(
    dir_path: str,
    save_json_path: str,
    input_names: Optional[List[str]] = None,
    input_shapes: Optional[List[List[int]]] = None,
) -> None:
    """Create a calibration JSON file for multi-input model calibration.

    The function scans a directory containing calibration data and creates
    a JSON file with standardized format. Each subdirectory represents one calibration
    sample and files must in one of the following formats:
    - NumPy files(.npy)
    - Torch files(.pt)
    - Image files(.jpg, .jpeg, .png, .gif, and etc.)

    Expected directory structure:
    root_dir/
    ├── sample_1/                     # First calibration sample
    │   ├── input1.npy               # NumPy file for model input 1
    │   ├── input2.npy               # NumPy file for model input 2
    │   └── ...
    ├── sample_2/                     # Second calibration sample
    │   ├── input1.npy               # NumPy file for model input 1
    │   ├── input2.npy               # NumPy file for model input 2
    │   └── ...
    └── ...

    The generated JSON file will have the format:
    {
        "info": {
            "input names": List[str],  # Model input names
            "input shapes": List[List[int]]  # Input shapes with dynamic dims as -1
        },
        "calib paths": List[List[str]]  # Paths to calibration files, grouped by sample
    }

    Args:
        dir_path (str): Root directory containing calibration data subdirectories
        save_json_path (str): Path where the calibration JSON file will be saved
        input_names (Optional[List[str]], optional): List of model input names. If None,
            names will be auto-generated as "input1", "input2", etc.
        input_shapes (Optional[List[List[int]]], optional): Expected shapes for each input.
            If None, shapes will be inferred from first subdirectory.

    Raises:
        ValueError: If directory doesn't exist or has invalid structure
        ValueError: If save path doesn't end with .json
        ValueError: If calibration files are incompatible with input shapes
        ValueError: If any validation from build_calib_dict_for_multi_input fails

    Notes:
        - All calibration files must have shapes compatible with model inputs
        - The first subdirectory is used as reference if input_names or input_shapes are None
        - Compatible shapes means either identical shapes or shapes that differ only
          in designated dynamic dimensions (-1)
    """
    if not os.path.isdir(dir_path):
        raise ValueError(f'Directory does not exist: "{dir_path}"')
    if not save_json_path.endswith(".json"):
        raise ValueError(f'File extension should be json: "{save_json_path}"')
    save_json_path = os.path.abspath(save_json_path)

    is_valid, err_msg, calib_dict = build_calib_dict_for_multi_input(
        dir_path, verbose=True, input_names=input_names, input_shapes=input_shapes
    )
    if not is_valid:
        raise ValueError(err_msg)
    with open(save_json_path, "w") as f:
        json.dump(calib_dict, f, indent=4)
    print(f"Calibration JSON file is saved to: {save_json_path}")


def make_random_calib(
    input_names: List[str],
    input_shapes: List[List[int]],
    save_json_path: str,
    dir_path: str,
    num_data: int = 1,
):
    """Make json files of random calibration dataset

    Args:
        input_names (List[str]): model input names
        input_shapes (List[List[int]]): model input shapes, (H, W, C)
        save_json_path (str): calibration dataset json file path
        dir_path (str): calibration dataset dir
        num_data (int, optional): size of calibration dataset Defaults to 1.
    """
    assert os.path.isdir(dir_path), f"{dir_path} is not a directory."
    for n in range(num_data):
        dir_t = os.path.join(dir_path, f"{n}")
        if not os.path.isdir(dir_t):
            os.mkdir(path=dir_t)

        for input_name, input_shape in zip(input_names, input_shapes):
            filename_t = os.path.join(dir_t, f"{input_name}.npy")
            h, w, c = input_shape
            x = np.random.rand(h, w, c).astype(np.float32)
            np.save(file=filename_t, arr=x)

    list_calib_files_in_json(dir_path, save_json_path, input_names, input_shapes)


def get_cal_tensor_list(
    data_pth: str,
    model_input_names: Optional[List[str]] = None,
    model_input_shapes: Optional[List[List[int]]] = None,
    max_num_calib: Optional[int] = 500,
) -> Union[List[Tensor], List[List[Tensor]]]:
    """
    Higher level function to load calibration data.

    Args:
        data_path: path to txt or json file where paths to calibration data are saved
        model_input_names: names of the inputs to the model
        model_input_shapes: shapes of the inputs to the model
        max_num_calib: maximum number of calibration data that will be used

    Return:
        A list, where each tensor is preprocessed calibration image
    """
    try:
        return get_cal_tensor_list_txt(data_pth, max_num_calib)
    except ValueError:
        return get_cal_tensor_list_json(
            data_pth, model_input_names, model_input_shapes, max_num_calib
        )


def get_cal_tensor_list_txt(
    data_pth: str, max_num_calib: Optional[int] = 500
) -> List[Tensor]:
    """Load calibration data from TXT file.

    Args:
        data_path: path to txt file where paths to calibration data are saved
        max_num_calib: maximum number of calibration data that will be used

    Return:
        A list of tensors, where each tensor is preprocessed calibration image

    Raises:
        ValueError: if path saved in txt file is not a path to a file
        ValueError: if fails to load NumPy array
    """

    start = time.time()
    if not os.path.isfile(data_pth):
        raise ValueError(f"File does not exist: {data_pth}")
    if not data_pth.endswith(".txt"):
        raise ValueError(f"File should be in .txt format: {data_pth}")

    with open(data_pth) as f:
        calib_paths = f.readlines()

    if len(calib_paths) > max_num_calib:
        calib_paths = calib_paths[:max_num_calib]
        print(
            f"Warning! Number of calibration data in JSON file is more than {max_num_calib}, "
            f"only {max_num_calib} will be used for calibration."
        )

    success, fail = 0, 0
    cal_tensor_list = []
    for file_path in tqdm(calib_paths, desc="Loading Calibration Files from TXT"):
        if file_path[-1] == "\n":
            file_path = file_path[:-1]

        if not os.path.isfile(file_path):
            raise ValueError(f"{file_path} is not a file.")

        try:
            cal_tensor = np.load(file_path)
        except ValueError:
            print(f"Failed to load NumPy file: {file_path}. Skipping it")
            fail += 1
            continue

        cal_tensor = torch.from_numpy(cal_tensor)
        cal_tensor = cal_tensor.unsqueeze(0).permute(0, 3, 1, 2)
        cal_tensor_list.append(cal_tensor)
        success += 1

    cal_load_time = round(time.time() - start, 6)
    print(
        f"Completed to load calibration data in {cal_load_time} seconds. "
        f"Success = {success}, Fail = {fail}"
    )
    return cal_tensor_list


def get_cal_tensor_list_json(
    data_pth: str,
    model_input_names: List[str],
    model_input_shapes: List[List[int]],
    max_num_calib: Optional[int] = 500,
) -> List[List[Tensor]]:
    """Load calibration data from JSON file.

    Args:
        data_path: path to json file where paths to calibration data are saved
        model_input_names: names of the inputs to the model
        model_input_shapes: shapes of the inputs to the model
        max_num_calib: maximum number of calibration data that will be used

    Return:
        A list of lists of tensors, where each tensor is preprocessed calibration image

    Raises:
        ValueError: input shapes given in model and json file are not mappable
        ValueError: if path saved in json file is not a path to a file
        ValueError: if fails to load NumPy array
    """
    start = time.time()
    if not os.path.isfile(data_pth):
        raise ValueError(f"File does not exist: {data_pth}")
    if not data_pth.endswith(".json"):
        raise ValueError(f"File should be in .json format: {data_pth}")

    with open(data_pth) as f:
        json_data = json.load(f)
    json_input_names = json_data["info"]["input names"]
    json_input_shapes = json_data["info"]["input shapes"]
    calib_paths = json_data["calib paths"]

    if len(calib_paths) > max_num_calib:
        calib_paths = calib_paths[:max_num_calib]
        print(
            f"Warning! Number of calibration data in JSON file is more than {max_num_calib}, "
            f"only {max_num_calib} will be used for calibration."
        )

    if (
        not len(model_input_names)
        == len(model_input_shapes)
        == len(json_input_names)
        == len(json_input_shapes)
    ):
        raise ValueError(
            "Size of model_input_names, model_input_shapes, json_input_names and "
            f"json_input_shapes are not equal, {len(model_input_names)} vs "
            f"{len(model_input_shapes)} vs {len(json_input_names)} vs {len(json_input_shapes)}."
        )

    # change format(expand_dim, transpose) of input shape: [224,224,3] => [1,3,224,224]
    json_input_shapes = [
        [1] + ishape[-1:] + ishape[:-1] for ishape in json_input_shapes
    ]

    # Inputs in model and json might be in different order. Make one-to-one mapping according
    #   to input shapes to correctly access calibration numpy files
    map_model_json = {}
    for i, model_ishape in enumerate(model_input_shapes):
        for j, json_ishape in enumerate(json_input_shapes):
            if model_ishape == json_ishape and j not in map_model_json.values():
                map_model_json[i] = j
                break
    if len(map_model_json) != len(model_input_shapes):
        raise ValueError(
            "Input shapes given in model and json file are not same, "
            f"they cant be mapped {model_input_shapes} vs {json_input_shapes}"
        )

    # If multiple inputs have the same shape, name will be used to make correct mapping
    for ishape in set(tuple(tmpshp) for tmpshp in model_input_shapes):
        # get indices that correspond to ishape
        ishape_ids = [
            i for i, tmpshp in enumerate(model_input_shapes) if tmpshp == list(ishape)
        ]

        if len(ishape_ids) <= 1:
            continue

        # get input names from both model and json file that correspond to ishape
        model_inames = [model_input_names[idx] for idx in ishape_ids]
        json_inames = [json_input_names[map_model_json[idx]] for idx in ishape_ids]

        if sorted(model_inames) != sorted(json_inames):
            print(
                f"Warning! Input names that correspond to {ishape} in model and json file "
                f"are not same, {sorted(model_inames)} vs {sorted(json_inames)}. "
                f"Thus, these inputs will be mapped sequentially from model to json."
            )
            continue

        for i in ishape_ids:
            if model_input_names[i] != json_input_names[map_model_json[i]]:
                for j in range(json_input_names):
                    if (
                        model_input_names[i] == json_input_names[j]
                        and model_input_shapes[i] == json_input_shapes[i]
                    ):
                        map_model_json[i] = j
                        break

    # load calibration data from JSON file
    success, fail = 0, 0
    cal_tensor_list = []
    for paths_list in tqdm(calib_paths, desc="Loading Calibration Files from JSON"):
        name_tensor_dict = {}
        is_fail = False
        for i in range(len(paths_list)):
            file_path = paths_list[map_model_json[i]]

            if not os.path.isfile(file_path):
                raise ValueError(f"{file_path} is not a file.")

            try:
                cal_tensor = np.load(file_path)
            except ValueError:
                print(f"Failed to load NumPy file: {file_path}. Skipping it.")
                is_fail = True
                break

            cal_tensor = torch.from_numpy(cal_tensor)
            cal_tensor = cal_tensor.unsqueeze(0).permute(0, 3, 1, 2)
            name_tensor_dict[model_input_names[i]] = cal_tensor

        if is_fail:
            fail += 1
            break

        success += 1
        cal_tensor_list.append([name_tensor_dict[iname] for iname in model_input_names])

    cal_load_time = round(time.time() - start, 6)
    print(
        f"Completed to load calibration data in {cal_load_time} seconds. "
        f"Success = {success}, Fail = {fail}"
    )
    return cal_tensor_list


def read_structure(base_path: str) -> list:
    """
    Description:
        Read the foldering structure of dataset.
        Recursively read and store image path and return the list of all image path.
        * Dataset should be one of the types below;
            1. All images stored in base_path.
            2. All images are categorized by folders.

            ex) If base_path contains sample images and folders categorizing sample images at the same time,
                One of (images type)/(folders typ) which is smaller will be ignored.

    Args:
        base_path: root directory of dataset.

    Returns:
        List of dataset's image path.
    """
    img_ext = ["jpg", "jpeg", "png"]
    candidates = os.listdir(base_path)
    folders = [
        os.path.join(base_path, x)
        for x in candidates
        if os.path.isdir(os.path.join(base_path, x))
    ]
    images = [
        os.path.join(base_path, y)
        for y in candidates
        if any([y.lower().endswith(e) for e in img_ext])
    ]

    path_list = []

    if len(folders) > len(images):
        for folder in folders:
            path_list_sub = read_structure(folder)
            path_list.extend(sorted(path_list_sub))
    elif len(folders) < len(images):
        path_list.extend(sorted(images))
    else:
        raise AssertionError(
            f"Cannot figure out how dataset is constructed; {base_path}"
        )

    return path_list


def get_balanced_ids_coco(
    json_path: str,
    path_list: list,
    max_value: int,
    fname_format: str = "%012d.jpg",
    seed=2023,
) -> list:
    """
    Description:
        Read Annotation json file for COCO format and randomly select samples considering class balance.
        For the general use, image filename format need to be provided.
        If maximum value of subset is smaller than the number of the class, just randomly select subset without considering balance.
        * This function is separated from read_structure function for general use of it.
          Functions for other dataset format will be updated continuously.

    Args:
        json_path: Path for annnotation json file.
        path_list: List of all image path.
        max_value: maximum size of subset. (Final Calibration dataset size)
        fname_format: filename format using image_idx.

    Returns:
        List of ramdomly sampled subset of calibration dataset.
    """
    try:
        from pycocotools.coco import COCO
    except:
        raise ImportError(f"pycocotools is required to use COCO-format annotations.")

    try:
        data = COCO(json_path)
    except:
        raise AssertionError(
            f"Invalid annotation file. Currently COCO-format annotation file is supported; {json_path}"
        )
    categories = data.getCatIds()
    random.seed(seed)
    target_ids = []
    ids_list = []

    if max_value >= len(categories):
        num_sample_cat = math.ceil(max_value / len(categories))
    else:
        if max_value > 0 and len(categories) > max_value:
            categories = random.sample(categories, max_value)
        num_sample_cat = 1
        print(
            f"WARNING:: max_value (={max_value}) is too small for {len(categories)} categories.\
                \nTarget Categories are randomly chosen; {categories}"
        )

    for id in categories:
        candidates = [fname_format % idx for idx in data.getImgIds(catIds=id)]
        if len(candidates) > num_sample_cat:
            target_ids.extend(random.sample(candidates, num_sample_cat))
            ids_list.extend([id] * num_sample_cat)
        else:
            target_ids.extend(candidates)
            ids_list.extend([id] * len(candidates))

    res = []
    res_ids = []
    for path in path_list:
        if os.path.basename(path) in target_ids:
            res.append(path)
            res_ids.append(ids_list[target_ids.index(os.path.basename(path))])

    if max_value > 0 and len(res) > max_value:
        res = random.sample(res, max_value)

    return res, res_ids


def numpylist_ascontiguous(npy_list: List[np.ndarray]):
    return [
        (
            np.ascontiguousarray(npy_data).tolist()
            if npy_data.flags["C_CONTIGUOUS"]
            else npy_data.tolist()
        )
        for npy_data in npy_list
    ]


def make_calib_dict(
    img_path_list: List[str],
    fname_list: List[str],
    npy_list: List[np.ndarray],
    dataname: str,
    label_list: Optional[List[str]],
):
    calib_dict = {}
    if label_list:
        assert (
            len(img_path_list) == len(fname_list) == len(npy_list) == len(label_list)
        ), f"the length of the lists are different, img_path_list: {len(img_path_list)}, \
            fname_list: {len(fname_list)}, npy_list: {len(npy_list)}, label_list: {len(label_list)}"
        calib_dict["label"] = label_list
    else:
        assert (
            len(img_path_list) == len(fname_list) == len(npy_list)
        ), f"the length of the lists are different, img_path_list: {len(img_path_list)}, \
            fname_list: {len(fname_list)}, npy_list: {len(npy_list)}"

    calib_dict["dataname"] = dataname
    calib_dict["data_path"] = img_path_list
    calib_dict["fname"] = fname_list
    calib_dict["num_calib"] = len(npy_list)
    calib_dict["shape"] = list(npy_list[0].shape)
    calib_dict["npy_data"] = numpylist_ascontiguous(npy_list)

    return calib_dict


def save_calib_to_msgpack(calib_dict: dict, save_path: str = None):
    packed = msgpack.packb(calib_dict)
    if save_path is None:
        save_path = get_msg_fname(calib_dict)
    else:
        if save_path.split(".")[-1] != "msgpack":
            save_path = save_path + ".msgpack"
    with open(save_path, "wb") as outfile:
        outfile.write(packed)

    print("Completely save to calibration msgpack")


def get_msg_fname(calib_dict: dict):
    return (
        "_".join(
            [
                calib_dict["dataname"],
                "num" + str(calib_dict["num_calib"]),
                ",".join([str(shape) for shape in calib_dict["shape"]]),
            ]
        )
        + ".msgpack"
    )


def get_cali_dataloader(
    calib_data_path: str, device: torch.device, batch_size: int = 1
):
    if calib_data_path.endswith(".txt"):
        get_cali_dataloader_from_txt(calib_data_path, device, batch_size)
    elif calib_data_path.endswith(".json"):
        get_cali_dataloader_from_json(calib_data_path, device, batch_size)
    else:
        raise ValueError(f"Got unexpected calib_data_path={calib_data_path}.")


def get_cali_dataloader_from_txt(
    calib_data_path: str, device: torch.device, batch_size: int = 1
):
    assert os.path.isfile(
        calib_data_path
    ), f"Failed to find calibration data path from {calib_data_path}."
    assert calib_data_path.endswith(
        ".txt"
    ), f"Got unexpected calib_data_path={calib_data_path}."

    # Generate dataset
    dataset = SingleInputDataset(calib_data_path, device)
    return torch.utils.data.DataLoader(dataset, batch_size=batch_size)


def get_cali_dataloader_from_json(
    calib_data_path: str, device: torch.device, batch_size: int = 1
):
    assert os.path.isfile(
        calib_data_path
    ), f"Failed to find calibration data path from {calib_data_path}."
    assert calib_data_path.endswith(
        ".json"
    ), f"Got unexpected calib_data_path={calib_data_path}."
    raise NotImplementedError("")


class SingleInputDataset(torch.utils.data.Dataset):
    def __init__(
        self, path_txt: str, device: torch.device = None, exclude_batch: bool = False
    ):
        super().__init__()
        with open(path_txt, "r") as f:
            self.paths = [
                t.rstrip("\n") for t in f.readlines() if t.rstrip("\n").endswith(".npy")
            ]

        self.device = device
        self.exclude_batch = exclude_batch

    def __getitem__(self, index):
        x_npy = np.load(self.paths[index])
        if self.exclude_batch:
            x_npy = x_npy[0]

        if self.device is None:
            return torch.from_numpy(x_npy)
        else:
            return torch.from_numpy(x_npy).to(self.device)

    def __len__(self):
        return len(self.paths)


class SingleInputNumpyDataset(torch.utils.data.Dataset):
    """
    Require txt file wich includes paths to the pre-processed calibration data (numpy).
    """

    def __init__(
        self,
        paths: List[str] = None,
        path_txt: str = None,
        device: torch.device = None,
        exclude_batch: bool = False,
    ):
        super().__init__()
        assert (paths is not None) != (
            path_txt is not None
        ), f"Either one of paths and path_txt should be not None, but got paths={paths}, path_txt={path_txt}."
        if path_txt is not None:
            with open(path_txt, "r") as f:
                self.paths = [
                    t.rstrip("\n")
                    for t in f.readlines()
                    if t.rstrip("\n").endswith(".npy")
                ]
        elif paths is not None:
            self.paths = paths

        self.device = device
        self.exclude_batch = exclude_batch

    def __getitem__(self, index):
        # print("path: ", self.paths)
        # print("[DEBUG-CALIB] path: ", self.paths[index])
        x_npy = np.load(self.paths[index]).transpose([2, 0, 1])
        if self.exclude_batch:
            x_npy = x_npy[0]

        if self.device is None:
            return torch.from_numpy(x_npy)
        else:
            return torch.from_numpy(x_npy).to(self.device)

    def __len__(self):
        return len(self.paths)


class SingleImageInputDataset(torch.utils.data.Dataset):
    def __init__(
        self,
        preprocess: Callable[[str], torch.Tensor] = None,
        paths: Union[List[str], Tuple[str]] = None,
        path_txt: str = None,
        device: torch.device = None,
    ):
        super().__init__()
        assert (paths is not None) != (
            path_txt is not None
        ), f"Either of paths or path_txt should not be None, but got paths={paths}, path_txt={path_txt}."

        IMG_EXT = ["jpg", "jpeg", "png"]
        if isinstance(paths, (list, tuple)):
            self.paths = [
                t for t in paths if any([t.lower().endswith(e) for e in IMG_EXT])
            ]
        elif isinstance(path_txt, str):
            with open(path_txt, "r") as f:
                self.paths = [
                    t.rstrip("\n")
                    for t in f.readlines()
                    if any([t.rstrip("\n").lower().endswith(e) for e in IMG_EXT])
                ]
        else:
            raise ValueError(f"Got unexpected paths={paths}, path_txt={path_txt}.")

        self.device = device
        if preprocess is None:

            def default_pre(path: str) -> torch.Tensor:
                return torchvision.transforms.functional.pil_to_tensor(
                    PIL.Image.open(path)
                )

            self.preprocess = default_pre
        else:
            self.preprocess = preprocess

    def __getitem__(self, index):
        x_torch = self.preprocess(self.paths[index])
        if self.device is not None:
            return x_torch.to(self.device)
        else:
            return x_torch

    def __len__(self):
        return len(self.paths)


def sample_imageNet(imageNet_dir: str, num_samples: int, save_dir: str, seed: int = 0):
    """Sample some images from given imageNet dataset directory and copy them to given save_dir.

    Args:
        imageNet_dir (str): ImageNet root directory, each subdirectory corresponds to each class.
        num_data (int): Number of samples.
        For example,
        imageNet_dir consists of
        |
        |
        --- n01440764/
        --- n01443537/
        ...

        Result can be different from the given num_data, because of the total number of the images under the root directory.
        save_dir (str): Sampled images are copied to the save_dir.
        seed (int, optional): Random seed. Defaults to 0.
    """
    # TODO: Sample more representative data by investigating feature distribution on the data.
    assert os.path.isdir(imageNet_dir), f"Failed to find directory={imageNet_dir}."
    assert num_samples > 0, f"num_data must be postive, but got {num_samples}."
    if os.path.isdir(save_dir):
        print(f"WARNING: {save_dir} already exists.")
    else:
        os.makedirs(save_dir, exist_ok=True)

    # Check subdirectory
    IMANET_CLS_NUM = 1000
    sub_dir_list = [
        os.path.join(imageNet_dir, t.name)
        for t in os.scandir(imageNet_dir)
        if t.is_dir()
    ]
    assert (
        len(sub_dir_list) == IMANET_CLS_NUM
    ), f"Expected {IMANET_CLS_NUM} sub-directories, but found {len(sub_dir_list)} under {imageNet_dir}."

    # Initialize num_each_cls
    num_samples_each_cls = [
        int(num_samples // IMANET_CLS_NUM) for _ in range(IMANET_CLS_NUM)
    ]

    # Add remainder
    remainder = num_samples % IMANET_CLS_NUM
    if remainder != 0:
        random.seed(seed)
        cls_to_pick_more_samples = random.sample(range(IMANET_CLS_NUM), remainder)
        for i in cls_to_pick_more_samples:
            num_samples_each_cls[i] += 1

    # Consider the number of images in each sub-directory. This may affect the total number of samples.
    for i, sub_dir in enumerate(sub_dir_list):
        num_samples_each_cls[i] = min(
            num_samples_each_cls[i], len(get_img_paths_from_dir(sub_dir))
        )

    paths = []
    for sub_dir, num_samples in zip(sub_dir_list, num_samples_each_cls):
        img_paths = get_img_paths_from_dir(sub_dir)
        paths.extend(random.sample(img_paths, num_samples))

    for path in tqdm(paths, desc="Copying samples..."):
        shutil.copy(path, save_dir)


def parse_calib_data(
    data_dir: str = None,
    calib_data_path: str = None,
    preprocess: Callable[[str], torch.Tensor] = None,
) -> SingleInputNumpyDataset:
    assert (
        data_dir is not None != calib_data_path is not None
    ), f"Expected either of data_dir or calib_data_path is not None, but got data_dir={data_dir}, calib_data_path={calib_data_path}."

    # Get image paths
    if isinstance(data_dir, str):
        assert os.path.isdir(data_dir), f"Failed to find directory={data_dir}."
        img_paths = get_img_paths_from_dir(data_dir)

    elif isinstance(calib_data_path, str):
        assert os.path.isfile(
            calib_data_path
        ), f"Failed to find file={calib_data_path}."

    else:
        raise ValueError(
            f"Got unexpected data_dir={data_dir}, calib_data_path={calib_data_path}"
        )
