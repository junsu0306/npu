from typing import Tuple, Union, List, Optional

import numpy as np
import torch
import torchvision.transforms.functional as F
import inspect

TORCH_INTERP_CODES = {
    "nearest": F.InterpolationMode.NEAREST,
    "bilinear": F.InterpolationMode.BILINEAR,
    "bicubic": F.InterpolationMode.BICUBIC,
    "box": F.InterpolationMode.BOX,
    "hamming": F.InterpolationMode.HAMMING,
    "lanczos": F.InterpolationMode.LANCZOS,
}


def has_same_type(x):
    type_c = type(x[0])
    if any(type(t) != type_c for t in x):
        return False
    else:
        return True


def imgpad_to_multiple(
    img: np.ndarray,
    divisor: int,
    pad_val: Union[float, int] = 0.0,
    right_bottom: bool = False,
) -> np.ndarray:
    # Note that it just pads to right and bottom.
    pad_h = int(np.ceil(img.shape[0] / divisor)) * divisor
    pad_w = int(np.ceil(img.shape[1] / divisor)) * divisor
    return impad(img, shape=(pad_h, pad_w), pad_val=pad_val, right_bottom=right_bottom)


def impad(
    img: np.ndarray,
    *,
    shape: Optional[Tuple[int, int]] = None,
    padding: Union[int, tuple, None] = None,
    pad_val: Union[float, List] = 0,
    padding_mode: str = "constant",
    right_bottom: bool = False,
) -> np.ndarray:
    """Pad the given image to a certain shape or pad on all sides with
    specified padding mode and padding value.

    Args:
        img (ndarray): Image to be padded.
        shape (tuple[int]): Expected padding shape (h, w). Default: None.
        padding (int or tuple[int]): Padding on each border. If a single int is
            provided this is used to pad all borders. If tuple of length 2 is
            provided this is the padding on left/right and top/bottom
            respectively. If a tuple of length 4 is provided this is the
            padding for the left, top, right and bottom borders respectively.
            Default: None. Note that `shape` and `padding` can not be both
            set.
        pad_val (Number | Sequence[Number]): Values to be filled in padding
            areas when padding_mode is 'constant'. Default: 0.
        padding_mode (str): Type of padding. Should be: constant, edge,
            reflect or symmetric. Default: constant.
            - constant: pads with a constant value, this value is specified
              with pad_val.
            - edge: pads with the last value at the edge of the image.
            - reflect: pads with reflection of image without repeating the last
              value on the edge. For example, padding [1, 2, 3, 4] with 2
              elements on both sides in reflect mode will result in
              [3, 2, 1, 2, 3, 4, 3, 2].
            - symmetric: pads with reflection of image repeating the last value
              on the edge. For example, padding [1, 2, 3, 4] with 2 elements on
              both sides in symmetric mode will result in
              [2, 1, 1, 2, 3, 4, 4, 3]
        right_bottom (bool): If True, it only pads to right and bottom.

    Returns:
        ndarray: The padded image.
    """

    assert (shape is not None) ^ (padding is not None)
    if shape is not None:
        padding = get_padding_from_shapes(
            img.shape[0], img.shape[1], shape[0], shape[1], right_bottom
        )

    # check pad_val
    if isinstance(pad_val, (list, tuple)):
        assert len(pad_val) == img.shape[-1]
    elif not isinstance(pad_val, (float, int)):
        raise TypeError(
            "pad_val must be a int or a tuple. " f"But received {type(pad_val)}"
        )

    # check padding
    if isinstance(padding, (list, tuple)) and len(padding) in [2, 4]:
        if len(padding) == 2:
            padding = (padding[0], padding[1], padding[0], padding[1])
    elif isinstance(padding, (float, int)):
        padding = (padding, padding, padding, padding)
    else:
        raise ValueError(
            "Padding must be a int or a 2, or 4 element tuple."
            f"But received {padding}"
        )

    # check padding mode
    assert padding_mode in ["constant", "edge", "reflect", "symmetric"]

    border_type = {
        "constant": cv2.BORDER_CONSTANT,
        "edge": cv2.BORDER_REPLICATE,
        "reflect": cv2.BORDER_REFLECT_101,
        "symmetric": cv2.BORDER_REFLECT,
    }
    img = cv2.copyMakeBorder(
        img,
        padding[1],
        padding[3],
        padding[0],
        padding[2],
        border_type[padding_mode],
        value=pad_val,
    )

    return img


def normalize_(img: np.ndarray, mean: np.ndarray, std: np.ndarray):
    # img: shape (h, w, c)
    # mean: shape (c,)
    # std: shape (c,)
    img -= mean
    img /= std


def type_check(obj, class_input: List):
    if isinstance(class_input, list):
        for class_ in class_input:
            if not inspect.isclass(class_):
                raise TypeError(
                    f"class_input must be a class or list of class, but got {type(class_)} in the list."
                )

        if not any([isinstance(obj, class_) for class_ in class_input]):
            class_list = set([t.__name__ for t in class_input])
            raise TypeError(
                f"Expected one of {class_list} input, but got: {type(obj)}."
            )
    else:
        if not inspect.isclass(class_input):
            raise TypeError(
                f"class_input must be a class or list of class, but got {type(class_input)}."
            )

        if not isinstance(obj, class_input):
            raise TypeError(f"Got unexpected type: {type(obj)}.")


def img_npy_to_torch_tensor(x: np.ndarray):
    type_check(x, np.ndarray)
    # x: shape(H, W, C) -> torch.Tensor (1, C, H, W)
    return torch.from_numpy(x).permute(2, 0, 1).unsqueeze(0)


def torch_tensor_to_img_npy(x: torch.Tensor):
    type_check(x, torch.Tensor)
    return np.ascontiguousarray(x.squeeze(0).permute(1, 2, 0).numpy())


def rescale_size(
    old_size: Tuple[int, int],
    scale: Union[float, int, Union[List[int], Tuple[int]]],
    return_scale: bool = False,
) -> Tuple[int, int]:
    """Calculate the new size to be rescaled to.

    Args:
        old_size (Tuple[int, int]): The old size (w, h) of image.
        scale (float | int | List[int] | Tuple[int]): The scaling factor or maximum size.
        If it is a float number, then the image will be rescaled by this factor, else if it is a tuple of 2 integers, then the image will be rescaled as large as possible within the scale.
        return_scale (bool): Whether to return the scaling factor besides the rescaled image size.

    Returns:
        Tuple[int]: The new rescaled image size.
    """
    w, h = old_size
    if isinstance(scale, (float, int)):
        if scale <= 0:
            raise ValueError(f"Invalid scale {scale}, must be positive.")
        scale_factor = scale
    elif isinstance(scale, (list, tuple)):
        max_long_edge = max(scale)
        max_short_edge = min(scale)
        scale_factor = min(max_long_edge / max(h, w), max_short_edge / min(h, w))
    else:
        raise TypeError(
            f"Scale must be a number or tuple of int, but got {type(scale)}"
        )

    new_size = _scale_size((w, h), scale_factor)

    if return_scale:
        return new_size, scale_factor
    else:
        return new_size


def _scale_size(
    size: Tuple[int, int],
    scale: Union[float, int, Tuple[float, float], Tuple[int, int]],
) -> Tuple[int, int]:
    """Rescale a size by a ratio.

    Args:
        size (Tuple[int, int]): (w, h).
        scale (float | int): Scaling factor.

    Returns:
        Tuple[int, int]: scaled size.
    """
    if isinstance(scale, (float, int)):
        scale = (scale, scale)
    w, h = size
    return int(w * float(scale[0]) + 0.5), int(h * float(scale[1]) + 0.5)


def imrescale(
    img: np.ndarray,
    scale: Union[float, Tuple[int, int]],
    return_scale: bool = False,
    interpolation: str = "bilinear",
) -> Union[np.ndarray, Tuple[np.ndarray, float]]:
    """Resize image while keeping the aspect ratio.

    Args:
        img (ndarray): The input image.
        scale (float | tuple[int]): The scaling factor or maximum size (h,).
            If it is a float number, then the image will be rescaled by this
            factor, else if it is a tuple of 2 integers, then the image will
            be rescaled as large as possible within the scale.
        return_scale (bool): Whether to return the scaling factor besides the
            rescaled image.
        interpolation (str): Same as :func:`resize`.

    Returns:
        ndarray: The rescaled image.
    """
    h, w = img.shape[:2]
    new_size, scale_factor = rescale_size((w, h), scale, return_scale=True)
    resized_img = imresize(img, new_size, interpolation=interpolation)
    if return_scale:
        return resized_img, scale_factor
    else:
        return resized_img


def imresize(
    img: np.ndarray,
    size: Union[List[int], Tuple[int]],
    return_scale: bool = False,
    interpolation: str = "bilinear",
) -> Union[Tuple[np.ndarray, float, float], np.ndarray]:
    try:
        import cv2
    except:
        raise ImportError(
            "Please install Python OpenCV (cv2) to use the resize preprocessing."
        )
    CV2_INTERP_CODES = {
        "nearest": cv2.INTER_NEAREST,
        "bilinear": cv2.INTER_LINEAR,
        "bicubic": cv2.INTER_CUBIC,
        "area": cv2.INTER_AREA,
        "lanczos": cv2.INTER_LANCZOS4,
    }
    """Resize image to a given size.

    Args:
        img (ndarray): The input image.
        size (Tuple[int] | List[int]): Target size (w, h).
        return_scale (bool): Whether to return `w_scale` and `h_scale`.
        interpolation (str): Interpolation method, accepted values are
            "nearest", "bilinear", "bicubic", "area", "lanczos" for 'cv2'
            backend, "nearest", "bilinear" for 'pillow' backend.

    Returns:
        tuple | ndarray: (`resized_img`, `w_scale`, `h_scale`) or
        `resized_img`.
    """
    if not isinstance(size, (List, Tuple)):
        raise TypeError(f"Expected list or tuple size, but got {type(size)}.")

    h, w = img.shape[:2]
    resized_img = cv2.resize(img, size, interpolation=CV2_INTERP_CODES[interpolation])
    if not return_scale:
        return resized_img
    else:
        w_scale = size[0] / w
        h_scale = size[1] / h
        return resized_img, w_scale, h_scale


def get_padding_from_shapes(
    h: int, w: int, h_target: int, w_target: int, right_bottom: bool
):
    width = max(w_target - w, 0)
    height = max(h_target - h, 0)
    if right_bottom:
        # pad only right and bottom (make restoring coordination easier in visualization)
        pad_left = 0
        pad_top = 0
    else:
        pad_left = width // 2
        pad_top = height // 2

    return (pad_left, pad_top, width - pad_left, height - pad_top)
