import atexit
import collections
import copy
import functools
import itertools
import json
import logging
import os
import pathlib
import signal
import sys
import uuid
from typing import Union, List, Dict, Optional, Iterable

import torch

from qbcompiler.logging import get_logger
from qbcompiler.model_dict.common import (
    LayerType,
    DataFormat,
    SubGraph,
    Operator,
    ActivationSpec,
    DimValue,
)
from qbcompiler.model_dict.common.device import DeviceType, get_device_from_str
from qbcompiler.model_dict.common.model_dict import ModelDict, WeightDict, ValueDict
from qbcompiler.model_dict.inference.model import ModelInference, OperatorInference
from qbcompiler.model_dict.parser.transform_operator.fold_constant import (
    FoldConstant,
    FoldConstant2,
)
from .backend import get_parser
from .device_alloc import DeviceAllocator2
from .graph_transform import OperatorGraphTransform, ActivationTracer
from .old_model_dict_utils import load_all_tensors
from .transform_operator import (
    ReplaceOperatorRuleSet,
    UnfuseOperatorRuleSet,
    MarkUnsupported,
    ReplaceOperatorDependRuleSet,
    FuseOperatorsRuleSet,
    ReshapeRuleSet,
    AddBatchDimRuleSet,
    ActFuncRuleSet,
    TransposeRuleSet,
    NCToNHWCRuleSet,
    GemmConstantRuleSet,
    NXCToNHWCRuleSet,
    DataFlowTransformRuleSet,
    RemoveTemporaryRuleSet,
    FillOptionsRuleSet,
    InsertInputConstLayer,
    BiOpWithInputconstShapeFix,
    SplitSupportedConcat,
    SequenceModelParseRuleSet,
    BatchSplitRuleSet,
    NCXToNXCRuleSet,
    InputOutputReshapeFuse,
    SpecialOperatorPostRuleSet,
    SliceRepositionRuleSet,
    SwapTransposeAndOperatorRuleSet,
    NormallizeShapeRuleSet,
    ReinterpretSliceRuleSet,
    CSERuleSet,
    OperatorSinkingRuleSet,
    AttentionMaskInputRuleSet,
    TensorShapeFoldRuleSet,
    KVCacheInputRuleSet,
    InputConstFoldingRuleSet,
    HFPatchedRuleSet,
    NormFuseRuleSet,
    OrderedPatchifyRuleSet,
    DynamicDimToWRuleSet,
    FuseSpecialBlockRuleSet,
    SliceReinterpretRuleSet,
    HeaderViewRuleSet,
    DataFlowPostRuleSet,
    ShapeNormallizeRuleSet,
    FuseConvolutionAndOpsRuleSet,
    LlmUnwrapRuleSet,
    CustomMaskRuleSet,
)
from .transform_operator.dataflow import (
    TensorReshapeTransformRuleSet,
    ReshapeAndTransposeRuleSet,
)
from .transform_operator.dataflow._rulesets import DataFlowRuleSet
from .transform_operator.parse_seq_model import (
    MakeRNNSubGraph,
    MakeGRUSubGraph,
    MakeLSTMSubGraph2,
)
from .transform_operator.post_process import ReplaceOpPostRuleSet
from ..common.parserabc import MobilintParserInputs
from ..inference.shape_inference import GraphShapeInference

logger = get_logger(__name__)


def rm_tree(path: pathlib.Path):
    if path.exists() and path.is_dir():
        for child in path.iterdir():
            if child.is_file():
                child.unlink()
            else:
                rm_tree(child)
        path.rmdir()


def print_step_wrapper(routine):
    @functools.wraps(routine)
    def _wrapped(self, **kwargs):
        loop_cnt = kwargs.get("loop_cnt", "")
        logger.debug(f"[{loop_cnt}]-> {routine.__qualname__}: start")
        result = routine(self, **kwargs)
        logger.debug(f"[{loop_cnt}]-> {routine.__qualname__}: finished")
        return result

    return _wrapped


def format_table(header, rows, summary, header_format, row_format, title=""):
    col_sep = "|"
    format_map = {"i": "{:>{}}", "f": "{:>{}.2f}", "s": "{:<{}}"}
    header_map = {"i": "{:>{}}", "f": "{:>{}.2f}", "s": "{:^{}}"}
    row_format = [format_map[i.lower()] for i in row_format]
    header_format = [header_map[i.lower()] for i in header_format]

    table = [header] + rows + [summary]
    table_format = [header_format] + [row_format] * (len(table) - 1)
    col_widths = [0] * len(table[0])
    for row, rformat in zip(table, table_format):
        for idx, (item, item_format) in enumerate(zip(row, rformat)):
            col_widths[idx] = max(len(item_format.format(item, 0)), col_widths[idx])
    col_widths = [c + 2 for c in col_widths]

    row_sep = "+".join("-" * cw for cw in col_widths)
    tb_top_bottom = "=".join("=" * cw for cw in col_widths)

    table_width = sum(col_widths) + len(header)

    def gen_row():
        yield tb_top_bottom
        if title:
            yield "{:^{}}".format(title, table_width)
        yield tb_top_bottom
        for idx, (row, rformat) in enumerate(zip(table, table_format)):
            yield col_sep.join(
                fmt.format(cell_data, col_width)
                for fmt, cell_data, col_width in zip(rformat, row, col_widths)
            )
            if idx == 0 or idx == len(table) - 2:
                yield row_sep
        yield tb_top_bottom

    return "\n".join(gen_row())


def onnx_path_from_torchscript(torchscript_path: str, example_input):
    """Create model dict from torchscript model
    After loading the torchscript model, it is converted to ONNX model and then converted to model dict.

    Args:
        torchscript_path (str): model path of torchscript model
        example_input (torch.Tensor): Dummy input for converting torchscript model to ONNX model
    """
    if example_input is None:
        raise ValueError(
            f"Example input is not set, we can not export onnx from torchscript"
        )
    net = torch.jit.load(torchscript_path)
    net.eval()
    onnx_file_path = os.path.splitext(torchscript_path)[0] + ".onnx"
    torch.onnx.export(
        net, example_input, onnx_file_path, training=torch.onnx.TrainingMode.EVAL
    )
    return onnx_file_path


class ParserConfig:
    def __init__(
        self,
        allocate_to_devices=True,
        fold_const=True,
        operator_transform=True,
        split_supported_concat=True,
        make_inputconst_layer=True,
        make_lstm_subgraph=True,
        strip_lstm_node_as_subgraph=True,
        large_model=False,
    ):
        # config
        self.allocate_to_devices = allocate_to_devices
        self.fold_const = fold_const
        self.operator_transform = operator_transform
        self.split_supported_concat = split_supported_concat
        self.make_inputconst_layer = make_inputconst_layer
        self.make_lstm_subgraph = make_lstm_subgraph
        self.strip_lstm_node_as_subgraph = strip_lstm_node_as_subgraph
        self.large_model = large_model

        # parsing algorithms
        self.actfunc_targets = None
        self.unfuse_multi_output_func_targets = None
        self.unfuse_split_func_targets = None
        self.replace_operator_targets = None
        self.replace_operator_depend_targets = None
        self.fuse_operator_targets = None
        self.collapse_reshape_targets = None
        self.device_bridge_targets = None
        self.transpose_targets = None

    def __repr__(self):
        return (
            f"{self.__class__.__name__}("
            f"allocate_to_devices={self.allocate_to_devices}, "
            f"fold_const={self.fold_const}, "
            f"operator_transform={self.operator_transform}, "
            f"split_supported_concat={self.split_supported_concat}, "
            f"make_inputconst_layer={self.make_inputconst_layer}, "
            f"make_lstm_subgraph={self.make_lstm_subgraph}, "
            f"strip_lstm_node_as_subgraph={self.strip_lstm_node_as_subgraph}, "
            f"large_model={self.large_model})"
        )

    def dict(self):
        dct = {}
        for k, v in self.__dict__.items():
            dct[k] = v
        return dct

    @staticmethod
    def default_config(target_device: str | DeviceType, large_model=False):
        if isinstance(target_device, str):
            target_device = get_device_from_str(target_device)

        cfg = ParserConfig()
        cfg.large_model = large_model
        cfg.actfunc_targets = ActFuncRuleSet.get_all_names()
        cfg.unfuse_multi_output_func_targets = set(
            UnfuseOperatorRuleSet.get_all_names()
        )

        cfg.transpose_targets = TransposeRuleSet.get_all_names()
        cfg.batch_split_targets = BatchSplitRuleSet.get_all_names()

        cfg.unfuse_split_func_targets = []
        if "SplitV2Rule" in cfg.unfuse_multi_output_func_targets:
            cfg.unfuse_multi_output_func_targets.remove("SplitV2Rule")
            cfg.unfuse_split_func_targets = ["SplitV2Rule"]

        cfg.replace_operator_targets = ReplaceOperatorRuleSet.get_all_names()
        cfg.replace_operator_depend_targets = (
            ReplaceOperatorDependRuleSet.get_all_names()
        )
        cfg.fuse_operator_targets = FuseOperatorsRuleSet.get_all_names()
        cfg.collapse_reshape_targets = ReshapeRuleSet.get_all_names()

        return cfg


class ModelParser:
    def __init__(
        self,
        model=None,
        path_to_model: Optional[str] = None,
        backend: str = "onnx",
        target_device: str | DeviceType = "aries2",
        parser_config: ParserConfig = None,
        feed_dict: Dict | None = None,
        in_dformats: Dict | None = None,
        dynamic_axes: Dict | None = None,
        yolo_decode_include: bool = False,
        use_custom_mask: bool = False,
        exclude_first_subgraph: bool = False,
        seed=12435,
    ):
        atexit.register(self.cleanup)
        self.model = model
        self.path_to_model = path_to_model
        self._temp_dir = str(
            pathlib.Path(
                os.getcwd() if self.path_to_model is None else self.path_to_model
            ).parent.joinpath(str(uuid.uuid4()))
        )
        if not pathlib.Path(self._temp_dir).exists():
            pathlib.Path(self._temp_dir).mkdir(parents=True, exist_ok=True)

        self._parser = None
        self.backend: str = backend

        if isinstance(target_device, str):
            target_device = get_device_from_str(target_device)
        self.target_device: DeviceType = target_device
        self._seed = seed
        self.parse_finished = False
        self._feed_dict = feed_dict
        self._in_dformats = in_dformats
        self._dynamic_axes = dynamic_axes
        self._yolo_decode_include = yolo_decode_include
        self._use_custom_mask = use_custom_mask
        self._exclude_first_subgraph = exclude_first_subgraph

        self._model_dict: ModelDict | None = None
        self._weight_dict: WeightDict | None = None
        self._value_dict: ValueDict | None = None
        self._weight_dict_for_export_subgraph: WeightDict | None = None
        self.activation_tracer: ActivationTracer | None = None
        self.init_model_state = None
        self.sequential_model_subgraphs = []

        if parser_config is None:
            self.cfg: ParserConfig = ParserConfig.default_config(target_device)
        else:
            self.cfg = parser_config

        self.unsuported_post_proc = False
        self._setup_signal_handlers()

    def __repr__(self):
        return f"backend={self.backend}, path_to_model={self.path_to_model}, model={self.model}"

    def _make_filtered_weight_dict(
        self, md: ModelDict, src_wd: WeightDict | None = None
    ) -> WeightDict:
        if src_wd is None:
            src_wd = self._weight_dict
        filtered_wd = WeightDict()
        tensor_names = set()
        for sg in md.subgraphs:
            for ts in sg.tensors:
                tensor_names.add(ts.name)
        for ts_name in tensor_names:
            filtered_wd.add_weight(ts_name, src_wd.get_weight_by_name(ts_name))
        return filtered_wd

    def print_info(self):
        info = {"backend": self.backend, "config": self.cfg.dict()}
        logger.info("[Parser Info]")
        jd = json.dumps(info, indent=4)
        logger.info(jd)

    def _remove_dangling_and_update_graph_io(self):
        sg_main = self._model_dict.sg_main()
        sg_main.remove_dangling_tensors()
        sg_main.remove_dangling_activations()
        sg_main.update_graph_in_out()

    def allocate_graph_to_devices(
        self,
        model_dict,
        strip_lstm_node_as_subgraph=True,
        activation_tracer=None,
        **kwargs,
    ):
        def allocate_cache_names(sg_new, sg_old):
            cache_attrs = {
                name: value
                for name, value in sg_old.__dict__.items()
                if "cache_names" in name
            }
            sg_new.__dict__.update(cache_attrs)

        sg_main = model_dict.sg_main()
        sg_main.idx = model_dict._main_sg_idx
        non_main_subgraphs = model_dict.subgraphs[1:]
        sg_main.update_op_act_connectivity()
        sg_main.update_next_operator()
        self._mark_unsupported(self.target_device, subgraphs=[sg_main])
        alloc_subgraphs, partial_order = DeviceAllocator2(
            strip_lstm_node_as_subgraph
        ).allocate(sg_main, activation_tracer)

        sg_inputs = set()
        sg_outputs = set()
        for sg in alloc_subgraphs:
            inames = [sg.activations[x].name for x in sg.inputs]
            onames = [sg.activations[x].name for x in sg.outputs]
            # fixme: why do we need the following line?
            onames = [x for x in onames if x not in inames]
            sg_inputs.update(inames)
            sg_outputs.update(onames)
            allocate_cache_names(sg, sg_main)

        pre_condition = {}
        for sg_idx, next_sg_idx in partial_order.items():
            for nsi in next_sg_idx:
                if nsi in pre_condition:
                    pre_condition[nsi].append(sg_idx)
                else:
                    pre_condition[nsi] = [sg_idx]

        graph_order = []
        q = collections.deque()
        for sg_idx in partial_order.keys():
            if sg_idx not in pre_condition:
                q.append(sg_idx)

        while q:
            now = q.popleft()
            if now in graph_order:
                continue
            graph_order.append(now)
            for nsi in partial_order[now]:
                if all(x in graph_order for x in pre_condition[nsi]):
                    q.append(nsi)

        for order in graph_order:
            name_idx = len(graph_order) - order - 1
            alloc_subgraphs[order].name = f"sg{name_idx}"

        for sg in alloc_subgraphs:
            targets = (
                LayerType.StatefulLSTMWrapper,
                LayerType.StatefulGRUWrapper,
                LayerType.StatefulRNNWrapper,
            )
            sg.stateful = any(op.layertype in targets for op in sg.operators)

        model_dict.graph_order = graph_order
        for i, sg in enumerate(non_main_subgraphs):
            sg.idx = len(alloc_subgraphs) + i
        model_dict.subgraphs = alloc_subgraphs + non_main_subgraphs

        return model_dict

    def _fill_missing_fields(self):
        return OperatorGraphTransform(
            FillOptionsRuleSet.get(FillOptionsRuleSet.get_all_names())
        ).process(self._model_dict.subgraphs[0], self._weight_dict, self._value_dict)

    def _strip_unused_operators(self, subgraph=None):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        changed = True
        while changed:
            changed = False
            subgraph.update_op_act_connectivity()
            for op in subgraph.operators:
                if 0 == sum(
                    len(subgraph.activations[x].consumer_ops)
                    for x in op.options.outputs
                ):
                    op.valid = False
                    changed = True
            subgraph.operators = [op for op in subgraph.operators if op.valid]
        subgraph.remove_dangling_tensors()
        subgraph.remove_dangling_activations()

    def _make_lstm_subgraphs(self, model_dict):
        # for transform_class in ( MakeRNNSubGraph, MakeGRUSubGraph):
        for transform_class in (MakeLSTMSubGraph2, MakeRNNSubGraph, MakeGRUSubGraph):
            transform = transform_class(self.target_device)
            sequential_model_subgraphs = []
            num_sg = len(model_dict.subgraphs)
            for sg in model_dict.subgraphs:
                sequential_model_subgraphs += transform.process(sg, self._weight_dict)
            for i, sg in enumerate(sequential_model_subgraphs):
                sg.idx = num_sg + i
            model_dict.subgraphs += sequential_model_subgraphs
            self.sequential_model_subgraphs += sequential_model_subgraphs

    def update_config(self):
        self.cfg.allocate_to_devices = True
        self.cfg.fold_const = True
        self.cfg.operator_transform = True
        self.cfg.split_supported_concat = True
        self.cfg.make_inputconst_layer = True
        self.cfg.make_lstm_subgraph = True
        self.cfg.strip_lstm_node_as_subgraph = True

    def _post_graph_transform(self, md, device_alloc, activation_tracer=None):
        self._mark_unsupported(self.target_device, md.subgraphs)
        self._fill_empty_op_act_names(md)
        if device_alloc:
            md = self.allocate_graph_to_devices(
                md, self.cfg.strip_lstm_node_as_subgraph, activation_tracer
            )
        else:
            for sg in md.subgraphs:
                sg.sort_operators()

        if self.cfg.make_inputconst_layer:
            for sg in md.subgraphs:
                if not sg.unsupported:
                    self._insert_inputconst_layer(sg)
                    sg.sort_operators()
        if self.cfg.split_supported_concat:
            for sg in md.subgraphs:
                if not sg.unsupported:
                    self._split_supported_concats(sg)
        if self.cfg.make_lstm_subgraph:
            self._make_lstm_subgraphs(md)
            self._mark_unsupported(
                self.target_device, subgraphs=self.sequential_model_subgraphs
            )
        self.parse_post_process(md, activation_tracer=activation_tracer)

    def _handle_sparse_moe(self, md: ModelDict, wd: WeightDict):
        from qbcompiler.model_dict.parser.sparse_moe import start_check, end_check, KIND
        from qbcompiler.model_dict.parser.graph_scope import SubGraphScopeProcessor

        processor = SubGraphScopeProcessor(
            md=md, wd=wd, start_check=start_check, end_check=end_check, kind=KIND
        )
        new_subgraphs = processor.process()
        if new_subgraphs is not None:
            for sg in new_subgraphs[1:]:
                logger.info(f"sparse_moe_subgraph: {sg.name}")
                self.transform_graph_for_moe_subgraph_call(sg)
            md.subgraphs = new_subgraphs
        else:
            logger.info("sparse_moe_subgraph: not found")

    def parse(
        self,
        in_dformats=None,
        in_shapes=None,
        feed_dict=None,
        dynamic_axes=None,
        save_subgraph_type: int = 0,
        debug=False,
        **kwargs,
    ):
        self.post_proc = False

        if debug:
            # 전체 로거를 load하고 log level을 변경
            # logger_name은 각 파일 이름이기 때문에 특정 파일은 제외할 수 있음
            for logger_name, _logger in logging.root.manager.loggerDict.items():
                if isinstance(_logger, logging.Logger):
                    _logger.setLevel(logging.DEBUG)
        if feed_dict is not None:
            self._feed_dict = feed_dict
        parser = get_parser(
            backend=self.backend,
            model=self.model,
            model_path=self.path_to_model,
            large_model=self.cfg.large_model,
            temp_dir=self._temp_dir,
            seed=self._seed,
        )
        parser_inputs = MobilintParserInputs(
            model=self.model,
            in_dformats=in_dformats,
            in_shapes=in_shapes,
            feed_dict=self._feed_dict,
            dynamic_axes=dynamic_axes,
            # output_meta=kwargs.get("output_meta", None),
        )
        parsed = parser.parse(parser_inputs, **kwargs)
        md = parsed.model_dict
        cd = parsed.const_dict
        vd = parsed.value_dict
        self._origin_input_list = parsed.origin_input_names
        self._origin_output_list = parsed.origin_output_names

        if hasattr(parsed, "init_model_state"):
            md.init_model_state = parsed.init_model_state

        md.set_hw_device(self.target_device)
        md.set_output_value_reference(value_dict=vd)

        self._model_dict: ModelDict = md
        self._model_dict_before_alloc: ModelDict = md
        self._value_dict: ValueDict = vd
        self._weight_dict = WeightDict()
        self._weight_dict.set_weights(cd)
        self._set_dformat(in_dformats=in_dformats, target_device=self.target_device)
        self._set_dformat_vd()
        logger.info("[parser] Load and set dformat model done.")

        self.print_model_stats(stage="Model Loaded")
        self.activation_tracer = ActivationTracer(self._model_dict.sg_main())

        self._strip_unused_operators()

        self._handle_sparse_moe(md, self._weight_dict)

        if self.cfg.fold_const:
            self._mark_unsupported(self.target_device)
            # For efficientformer, where InputConstFolding and
            # FoldConstant are both required several times
            changed = True
            while changed:
                changed = False
                changed |= self._fold_operators()
                self._fold_constant()
            # self._fold_operators()
            # self._fold_constant()
            self._fold_attention_mask_input()

        self._handle_sequence_model(
            debug=debug, activation_tracer=self.activation_tracer
        )

        initial_shape_inference_succeeded = False
        try:
            self.shape_inference()
        except Exception as e:
            logger.info(e)
        else:
            initial_shape_inference_succeeded = True

        self._init_transform_graph()
        self._mark_unsupported(self.target_device)
        self._update_model_inout(
            self.activation_tracer,
            self._origin_input_list,
            self._origin_output_list,
        )
        self._fill_missing_fields()

        self._set_dformat()
        self._process_norm_func(activation_tracer=self.activation_tracer)
        self._process_act_func(activation_tracer=self.activation_tracer)
        self._process_llm_unwrap(activation_tracer=self.activation_tracer)

        self._unfuse_multi_output_operators(activation_tracer=self.activation_tracer)
        self._collapse_reshape(activation_tracer=self.activation_tracer)
        self._set_dformat()

        if self.cfg.operator_transform:
            self.transform_graph(
                debug=debug,
                activation_tracer=self.activation_tracer,
                do_shape_inference=initial_shape_inference_succeeded,
            )
            self._set_dformat()
            self._mark_unsupported(self.target_device)

        self._inout_unsupported_status_update()
        self._strip_unused_operators()
        self._remove_dangling_and_update_graph_io()

        if initial_shape_inference_succeeded:
            try:
                self.shape_inference()
            except Exception as e:
                logger.info(e)
        self._process_after_shape_inference(activation_tracer=self.activation_tracer)

        self._update_model_inout(
            self.activation_tracer,
            self._origin_input_list,
            self._origin_output_list,
        )
        self._mark_unsupported(self.target_device)
        self._inout_unsupported_status_update()
        self.print_dformat_stats()

        def _copy_model_dict(md):
            init_model_state = None
            if hasattr(md, "init_model_state"):
                init_model_state = getattr(md, "init_model_state")
                md.init_model_state = None
            copied = copy.deepcopy(md)
            copied.init_model_state = init_model_state
            md.init_model_state = init_model_state
            return copied

        self.unsuported_post_proc = True

        if save_subgraph_type > 0:
            md_for_export_subgraph = _copy_model_dict(self._model_dict)
            device_alloc = save_subgraph_type in (3, 4)
            self._post_graph_transform(
                md_for_export_subgraph,
                device_alloc=device_alloc,
                activation_tracer=self.activation_tracer,
            )
            self._md_for_export_subgraph = md_for_export_subgraph
            if save_subgraph_type in (2, 4):
                self._weight_dict_for_export_subgraph = self._make_filtered_weight_dict(
                    md_for_export_subgraph
                )
            else:
                self._weight_dict_for_export_subgraph = None

        model_dict_alloc = _copy_model_dict(self._model_dict)

        self._post_graph_transform(
            model_dict_alloc,
            device_alloc=self.cfg.allocate_to_devices,
            activation_tracer=self.activation_tracer,
        )
        self._model_dict = model_dict_alloc  # default is allocated model dict
        self.print_model_stats(
            stage=f"HL compilation done. Device={self.target_device.name}"
        )

    def shape_inference(self):
        sg_main = self._model_dict.sg_main()
        graph_shape_inference = GraphShapeInference(sg_main, self.weight_dict)
        input_shapes = {}
        logger.debug("[parser] Shape inference start")

        def match_shape_static_parts(
            a_shape: Iterable[DimValue], b_shape: Iterable[DimValue]
        ) -> bool:
            if len(a_shape) != len(b_shape):
                return False

            for ad, bd in zip(a_shape, b_shape):
                if bd.dynamic:
                    continue  # If a dimension in b is dynamic, skip comparing that dimension's value
                if ad != bd:
                    return False

            return True

        try:
            graph_shape_inference.do_inference(input_shapes)
        except Exception as e:
            logger.debug(e)
        finally:
            for a, b in graph_shape_inference.inferred_shapes.items():
                if (
                    len(a.src_shape) == len(b) == 4
                    and a.src_shape[:2] == (1, 1)
                    and a.src_shape[2].dynamic
                    and b[:3] == (1, 1, 1)
                    and a.src_shape[3] == b[3]
                ):
                    a.src_shape = b
                    a.shape = (-1, -1, -1)
                elif match_shape_static_parts(a.src_shape, b):  # To handle the NMS node
                    a.src_shape = b
                    a.shape = (-1, -1, -1)
                elif a.get_act_src_shape() != b:
                    raise ValueError(
                        f"{a.name}, input_shapes={input_shapes}, given_shape={a}, inferred_shape={b}, {a.producer_op.layertype if a.producer_op else None}"
                    )
                else:
                    a.src_shape = b
                    a.shape = (-1, -1, -1)
        logger.debug("[parser] Shape inference finished")

    def delete_tmp_dir(self):
        rm_tree(pathlib.Path(self._temp_dir))

    def _set_dformat(
        self,
        subgraph=None,
        in_dformats: Dict[str, str] = None,
        target_device: DeviceType = None,
    ):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        subgraph.update_op_act_connectivity()
        subgraph.update_graph_in_out()
        for act in subgraph.activations:
            if act.src_dim == 4:
                act.dataformat = DataFormat.NHWC
            if act.src_dim != 4 and act.dataformat == DataFormat.NHWC:
                act.dataformat = DataFormat.UNKNOWN

    def _set_dformat_vd(self):
        if not self.value_dict:
            return
        sg_main = self._model_dict.sg_main()
        for op in sg_main.operators:
            oact = sg_main.activations[op.options.outputs[0]]
            if oact.name in self._value_dict and oact.dataformat != DataFormat.UNKNOWN:
                if self._value_dict[oact.name].shape == oact.get_act_src_shape():
                    self._value_dict.update_dataformat(oact.name, oact.dataformat)

    def _init_transform_graph(self):
        for sg in self._model_dict.subgraphs:
            sg.update_op_act_connectivity()

    def _fold_constant(self, **kwargs):
        FoldConstant(self._model_dict.sg_main(), wd=self._weight_dict).process()
        FoldConstant2(self._model_dict.sg_main(), wd=self._weight_dict).process()

    @print_step_wrapper
    def _fold_operators(self, **kwargs):
        proc_args = (self._model_dict.sg_main(), self._weight_dict, self._value_dict)

        rules = InputConstFoldingRuleSet.get_all_names()
        rules.remove("FloatCastFold")
        rules = InputConstFoldingRuleSet.get(rules)
        r = OperatorGraphTransform(rules).process(*proc_args, **kwargs)
        is_changed = [r]

        rules = InputConstFoldingRuleSet.get("FloatCastFold")
        r = OperatorGraphTransform(rules).process(*proc_args, **kwargs)
        is_changed.append(r)
        rulesets = [
            TensorShapeFoldRuleSet,
            KVCacheInputRuleSet,
            AttentionMaskInputRuleSet,
            HFPatchedRuleSet,
        ]
        for ruleset in rulesets:
            rules = ruleset.get(ruleset.get_all_names())
            r = OperatorGraphTransform(rules).process(*proc_args, **kwargs)
            is_changed.append(r)
        return any(is_changed)

    @print_step_wrapper
    def _fold_attention_mask_input(self, **kwargs):
        rules = AttentionMaskInputRuleSet.get(AttentionMaskInputRuleSet.get_all_names())
        rules += ReshapeRuleSet.get(ReshapeRuleSet.get_all_names())
        return OperatorGraphTransform(rules).process(
            self._model_dict.sg_main(), self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _replace_operators(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        rules = ReplaceOperatorRuleSet.get(self.cfg.replace_operator_targets)
        return OperatorGraphTransform(rules).process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _replace_operators_depend(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        rules = ReplaceOperatorDependRuleSet.get(
            self.cfg.replace_operator_depend_targets
        ) + GemmConstantRuleSet.get(GemmConstantRuleSet.get_all_names())
        return OperatorGraphTransform(rules).process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _unfuse_multi_output_operators(self, **kwargs):
        rules = UnfuseOperatorRuleSet.get(self.cfg.unfuse_multi_output_func_targets)
        return OperatorGraphTransform(rules).process(
            self._model_dict.sg_main(), self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _unfuse_split_operators(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        return OperatorGraphTransform(
            UnfuseOperatorRuleSet.get(self.cfg.unfuse_split_func_targets)
        ).process(subgraph, self._weight_dict, self._value_dict, **kwargs)

    @print_step_wrapper
    def _process_norm_func(self, **kwargs):
        rules = NormFuseRuleSet.get(NormFuseRuleSet.get_all_names())
        return OperatorGraphTransform(rules).process(
            self._model_dict.sg_main(), self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _process_act_func(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        rules = ActFuncRuleSet.get(self.cfg.actfunc_targets)
        rules += NormFuseRuleSet.get(NormFuseRuleSet.get_all_names())
        return OperatorGraphTransform(rules).process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _process_llm_unwrap(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        rules = LlmUnwrapRuleSet.get(LlmUnwrapRuleSet.get_all_names())
        return OperatorGraphTransform(rules).process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _process_after_shape_inference(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        rules = SpecialOperatorPostRuleSet.get("HeaderViewRevertConvolution")
        return OperatorGraphTransform(rules).process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    def _mark_unsupported(self, target_device, subgraphs: List[SubGraph] = None):
        if subgraphs is None:
            subgraphs = self._model_dict.subgraphs
        for sg in subgraphs:
            MarkUnsupported(
                sg,
                wd=self._weight_dict,
                target_device=target_device,
                yolo_decode_include=self._yolo_decode_include,
                post_proc=self.unsuported_post_proc,
            ).process()

    def _inout_unsupported_status_update(self):
        sg_main = self._model_dict.subgraphs[0]
        for op in sg_main.operators:
            if op.layertype == LayerType.Input:
                op_out = sg_main.activations[op.options.outputs[0]]
                if any(not cop.unsupported for cop in op_out.consumer_ops):
                    op.unsupported = False
            elif op.layertype == LayerType.Output:
                opin = sg_main.activations[op.options.inputs[0]]
                pop = opin.producer_op
                op.unsupported = pop.unsupported

    def _fill_empty_op_act_names(self, md: ModelDict):
        # model dict must be in the state before applying device_alloc
        def _underscore_generator(prefix: str):
            for i in itertools.count():
                yield f"{prefix}_{i}"

        def _get_unique_name(sg, component: Union[ActivationSpec, Operator]):
            all_names = [conp.name for conp in sg.operators + sg.activations]

            if isinstance(component, Operator):
                base_name = component.layertype.name.lower()
                name_gen = _underscore_generator(base_name)
            elif isinstance(component, ActivationSpec):
                producer_op = component.producer_op
                base_name = "default"
                if producer_op is not None:
                    base_name = producer_op.layertype.name.lower()
                name_gen = _underscore_generator(base_name)
            else:
                raise ValueError

            for new_name in name_gen:
                if new_name not in all_names:
                    return new_name

        subgraph = md.subgraphs[0]
        for conponent in subgraph.operators + subgraph.activations:
            if conponent.name == "":
                conponent.name = _get_unique_name(subgraph, conponent)

    @print_step_wrapper
    def _collapse_reshape(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        return OperatorGraphTransform(
            ReshapeRuleSet.get(self.cfg.collapse_reshape_targets)
            + DataFlowRuleSet.get("IdentityOperators")
        ).process(subgraph, self._weight_dict, self._value_dict, **kwargs)

    @print_step_wrapper
    def _fuse_operators(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        return OperatorGraphTransform(
            FuseOperatorsRuleSet.get(
                self.cfg.fuse_operator_targets, backend=self.backend
            )
        ).process(subgraph, self._weight_dict, self._value_dict, **kwargs)

    @print_step_wrapper
    def _transpose_fuse(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        rules = TransposeRuleSet.get(self.cfg.transpose_targets)
        rules += DataFlowTransformRuleSet.get("TransposeTranspose")
        return OperatorGraphTransform(rules).process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _cse(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        return OperatorGraphTransform(
            CSERuleSet.get(CSERuleSet.get_all_names())
        ).process(subgraph, self._weight_dict, self._value_dict, **kwargs)

    @print_step_wrapper
    def _operator_sinking(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        return OperatorGraphTransform(
            OperatorSinkingRuleSet.get(OperatorSinkingRuleSet.get_all_names())
        ).process(subgraph, self._weight_dict, self._value_dict, **kwargs)

    @print_step_wrapper
    def _batch_split_operators(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        return OperatorGraphTransform(
            BatchSplitRuleSet.get(self.cfg.batch_split_targets)
        ).process(subgraph, self._weight_dict, self._value_dict, **kwargs)

    @print_step_wrapper
    def _process_ordered_patchfy(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        return OperatorGraphTransform(
            OrderedPatchifyRuleSet.get(OrderedPatchifyRuleSet.get_all_names())
        ).process(subgraph, self._weight_dict, self._value_dict, **kwargs)

    @print_step_wrapper
    def _expand_dims(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        rules = NCToNHWCRuleSet.get(NCToNHWCRuleSet.get_all_names())
        transform = OperatorGraphTransform(rules)
        return transform.process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _add_batch_dims(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        rules = AddBatchDimRuleSet.get(AddBatchDimRuleSet.get_all_names())
        transform = OperatorGraphTransform(rules)
        return transform.process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _fuse_dataflow(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        rules = DataFlowTransformRuleSet.get(DataFlowTransformRuleSet.get_all_names())
        rules += DataFlowRuleSet.get(DataFlowRuleSet.get_all_names())
        rules += TensorReshapeTransformRuleSet.get(
            TensorReshapeTransformRuleSet.get_all_names()
        )
        rules += ReshapeAndTransposeRuleSet.get(
            ReshapeAndTransposeRuleSet.get_all_names()
        )
        rules += FuseSpecialBlockRuleSet.get(FuseSpecialBlockRuleSet.get_all_names())
        rules += SliceReinterpretRuleSet.get(SliceReinterpretRuleSet.get_all_names())
        rules += FuseConvolutionAndOpsRuleSet.get(
            FuseConvolutionAndOpsRuleSet.get_all_names()
        )
        transform = OperatorGraphTransform(rules)
        return transform.process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _slice_reposition(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        rules = ReinterpretSliceRuleSet.get(ReinterpretSliceRuleSet.get_all_names())
        rules += SliceRepositionRuleSet.get(SliceRepositionRuleSet.get_all_names())
        transform = OperatorGraphTransform(rules)
        return transform.process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _transpose_reposition(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        rules = SwapTransposeAndOperatorRuleSet.get(
            SwapTransposeAndOperatorRuleSet.get_all_names()
        )
        trans_rule = TransposeRuleSet.get_all_names()
        rules += TransposeRuleSet.get(trans_rule)
        rules += DataFlowTransformRuleSet.get("TransposeTranspose")
        transform = OperatorGraphTransform(rules)
        return transform.process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _ncx_to_nxc(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        rules = NCXToNXCRuleSet.get(NCXToNXCRuleSet.get_all_names())
        transform = OperatorGraphTransform(rules)
        return transform.process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _normalize_shape(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        rules = NormallizeShapeRuleSet.get(NormallizeShapeRuleSet.get_all_names())
        rules += ShapeNormallizeRuleSet.get(ShapeNormallizeRuleSet.get_all_names())
        transform = OperatorGraphTransform(rules)
        return transform.process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _nxc_to_nhwc(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        rules = NXCToNHWCRuleSet.get(NXCToNHWCRuleSet.get_all_names())
        transform = OperatorGraphTransform(rules)
        return transform.process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _remove_temporary_operators(self, **kwargs):
        rules = RemoveTemporaryRuleSet.get(RemoveTemporaryRuleSet.get_all_names())
        transform = OperatorGraphTransform(rules)
        return transform.process(
            self._model_dict.sg_main(), self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _input_transpose_or_reshape_fuse(self, **kwargs):
        rules = InputOutputReshapeFuse.get(InputOutputReshapeFuse.get_all_names())
        rules += ReshapeRuleSet.get(self.cfg.collapse_reshape_targets)
        rules += CSERuleSet.get(CSERuleSet.get_all_names())
        transform = OperatorGraphTransform(rules)
        return transform.process(
            self._model_dict.sg_main(), self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _special_operator_post(self, **kwargs):
        rules = ReshapeAndTransposeRuleSet.get("Reshape")
        rules += DataFlowTransformRuleSet.get("TransposeTranspose")
        rules += ReshapeRuleSet.get(ReshapeRuleSet.get_all_names())
        special_operator_post_rule_names = set(
            SpecialOperatorPostRuleSet.get_all_names()
        )
        if self.target_device == DeviceType.Aries:
            special_operator_post_rule_names.discard("ConvolutionReshapeHeaderView")
        rules += SpecialOperatorPostRuleSet.get(special_operator_post_rule_names)
        rules += HeaderViewRuleSet.get(HeaderViewRuleSet.get_all_names())
        transform = OperatorGraphTransform(rules)
        return transform.process(
            self._model_dict.sg_main(), self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _mask_to_custom_mask(self, **kwargs):
        rules = CustomMaskRuleSet.get(CustomMaskRuleSet.get_all_names())
        transform = OperatorGraphTransform(rules)
        return transform.process(
            self._model_dict.sg_main(), self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _dataflow_post(self, **kwargs):
        rules = ReshapeRuleSet.get(ReshapeRuleSet.get_all_names())
        rules += ReplaceOpPostRuleSet.get(ReplaceOpPostRuleSet.get_all_names())
        rules += ReshapeAndTransposeRuleSet.get("Reshape")
        rules += ReshapeAndTransposeRuleSet.get("ReshapeTranspose")
        rules += DataFlowTransformRuleSet.get("TransposeTranspose")
        rules += DataFlowPostRuleSet.get(DataFlowPostRuleSet.get_all_names())
        transform = OperatorGraphTransform(rules)
        return transform.process(
            self._model_dict.sg_main(), self._weight_dict, self._value_dict, **kwargs
        )

    def _split_supported_concats(self, sg, **kwargs):
        transform = SplitSupportedConcat()
        transform.process(sg)

    def _insert_inputconst_layer(self, sg, **kwargs):
        transform = InsertInputConstLayer()
        transform.process(sg, self._weight_dict)

        transform = BiOpWithInputconstShapeFix()
        transform.process(sg, self._weight_dict)

    @print_step_wrapper
    def _handle_sequence_model(self, **kwargs):
        rules = SequenceModelParseRuleSet.get(SequenceModelParseRuleSet.get_all_names())
        transform = OperatorGraphTransform(rules)
        return transform.process(
            self._model_dict.sg_main(), self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _dynamic_axis_to_w(self, subgraph=None, **kwargs):
        if subgraph is None:
            subgraph = self._model_dict.sg_main()
        rules = DynamicDimToWRuleSet.get(DynamicDimToWRuleSet.get_all_names())
        transform = OperatorGraphTransform(rules)
        return transform.process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    @print_step_wrapper
    def _sparse_moe_process(self, subgraph, **kwargs):
        from qbcompiler.model_dict.parser.sparse_moe import SparseMoeRuleSet

        assert subgraph is not None
        rules = SparseMoeRuleSet.get(SparseMoeRuleSet.get_all_names())
        transform = OperatorGraphTransform(rules)
        return transform.process(
            subgraph, self._weight_dict, self._value_dict, **kwargs
        )

    def transform_graph_for_moe_subgraph_call(self, subgraph, debug=False, **kwargs):
        activation_tracer = kwargs.get("activation_tracer", None)
        self._mark_unsupported(self.target_device, [subgraph])
        self._replace_operators(
            debug=debug, subgraph=subgraph, activation_tracer=activation_tracer
        )
        self._mark_unsupported(self.target_device, [subgraph])
        self._set_dformat(subgraph=subgraph, in_dformats=None)
        changed = True
        kw = {"debug": debug, "activation_tracer": activation_tracer, "loop_cnt": 0}
        while changed:
            self._strip_unused_operators()
            logger.debug(f"[transform_graph step={kw['loop_cnt']}]")
            changed = False
            self._mark_unsupported(self.target_device, [subgraph])
            changed |= self._process_act_func(subgraph=subgraph)
            changed |= self._replace_operators_depend(subgraph=subgraph, **kw)
            changed |= self._sparse_moe_process(subgraph=subgraph, **kw)
            # changed |= self._dynamic_axis_to_w(subgraph=subgraph, **kw)
            changed |= self._unfuse_split_operators(subgraph=subgraph, **kw)
            changed |= self._collapse_reshape(subgraph=subgraph, **kw)
            changed |= self._fuse_operators(subgraph=subgraph, **kw)
            changed |= self._collapse_reshape(subgraph=subgraph, **kw)
            changed |= self._expand_dims(subgraph=subgraph, **kw)
            changed |= self._add_batch_dims(subgraph=subgraph, **kw)
            changed |= self._fuse_dataflow(subgraph=subgraph, **kw)
            changed |= self._collapse_reshape(subgraph=subgraph, **kw)
            changed |= self._slice_reposition(subgraph=subgraph, **kw)
            changed |= self._collapse_reshape(subgraph=subgraph, **kw)
            changed |= self._transpose_reposition(subgraph=subgraph, **kw)
            changed |= self._normalize_shape(subgraph=subgraph, **kw)
            changed |= self._nxc_to_nhwc(subgraph=subgraph, **kw)
            changed |= self._batch_split_operators(subgraph=subgraph, **kw)
            changed |= self._transpose_fuse(subgraph=subgraph, **kw)
            changed |= self._cse(subgraph=subgraph, **kw)
            changed |= self._operator_sinking(subgraph=subgraph, **kw)
            self._set_dformat(subgraph=subgraph, in_dformats=None)
            kw["loop_cnt"] += 1
        # if self._use_custom_mask:
        #     self._mask_to_custom_mask(debug=debug)
        self._remove_temporary_operators(debug=debug)
        # self._special_operator_post(debug=debug)
        # self._dataflow_post(debug=debug)
        self._mark_unsupported(self.target_device)
        # self._input_transpose_or_reshape_fuse(**kw)

    def transform_graph(self, debug=False, **kwargs):
        activation_tracer = kwargs.get("activation_tracer", None)
        do_shape_inference = kwargs.get("do_shape_inference", True)
        self._mark_unsupported(self.target_device)
        self._replace_operators(debug=debug, activation_tracer=activation_tracer)
        self._mark_unsupported(self.target_device)
        self._set_dformat(in_dformats=None)
        kw = {"debug": debug, "activation_tracer": activation_tracer, "loop_cnt": 0}

        outer_changed = True
        outer_cnt = 0
        MAX_OUTER = 50

        while outer_changed and outer_cnt < MAX_OUTER:
            outer_changed = False
            changed = True
            kw["loop_cnt"] = 0

            if do_shape_inference:
                try:
                    self.shape_inference()
                except Exception as e:
                    logger.info(e)

            while changed:
                self._strip_unused_operators()
                logger.debug(f"[transform_graph step={kw['loop_cnt']}]")
                changed = False

                self._mark_unsupported(self.target_device)
                changed |= self._process_act_func()
                changed |= self._process_ordered_patchfy(**kw)
                changed |= self._replace_operators_depend(**kw)
                changed |= self._dynamic_axis_to_w(**kw)
                changed |= self._unfuse_split_operators(**kw)
                changed |= self._collapse_reshape(**kw)
                changed |= self._fuse_operators(**kw)
                changed |= self._collapse_reshape(**kw)
                changed |= self._expand_dims(**kw)
                changed |= self._add_batch_dims(**kw)
                changed |= self._fuse_dataflow(**kw)
                changed |= self._collapse_reshape(**kw)
                changed |= self._slice_reposition(**kw)
                changed |= self._collapse_reshape(**kw)
                changed |= self._transpose_reposition(**kw)
                changed |= self._collapse_reshape(**kw)
                changed |= self._ncx_to_nxc(**kw)
                changed |= self._normalize_shape(**kw)
                changed |= self._nxc_to_nhwc(**kw)
                changed |= self._batch_split_operators(**kw)
                changed |= self._transpose_fuse(**kw)
                changed |= self._cse(**kw)
                changed |= self._operator_sinking(**kw)

                self._set_dformat(in_dformats=None)
                kw["loop_cnt"] += 1

            post_changed = False
            if self._use_custom_mask:
                post_changed |= self._mask_to_custom_mask(debug=debug)
            post_changed |= self._remove_temporary_operators(debug=debug)
            post_changed |= self._special_operator_post(debug=debug)
            post_changed |= self._dataflow_post(debug=debug)

            outer_changed |= post_changed
            outer_cnt += 1

        self._mark_unsupported(self.target_device)
        self._input_transpose_or_reshape_fuse(**kw)

    def post_duplicated_name_fix(self, model_dict: ModelDict):
        all_names = []
        sg_inout = []
        for sg in model_dict.subgraphs:
            sg_inout.extend(
                [act for act in sg.input_activations() + sg.output_activations()]
            )
        for sg in model_dict.subgraphs:
            for act in sg.activations:
                name = act.name
                if name in all_names:
                    idx = 1
                    new_name = f"{name}_{idx}"
                    while new_name in all_names:
                        idx += 1
                        new_name = f"{name}_{idx}"
                    if act in sg_inout:
                        pass
                    else:
                        act.name = new_name
                        all_names.append(new_name)
                else:
                    all_names.append(name)

    def parse_post_process(self, model_dict: ModelDict, activation_tracer=None):
        self.post_duplicated_name_fix(model_dict)
        for sg in model_dict.subgraphs:
            sg.remove_dangling_tensors()
            sg.remove_dangling_activations()
            sg.opname_to_outactname()
            sg.update_actiavtion_shape_info()
            sg.update_next_operator()
            # 여기서 update_graph_in_out을 하면 unsupported subgraph의 경우 output layer가 없기 때문에 output이 사라질 수 있음.
            # sg.update_graph_in_out()
            sg.check_activations_dataformat(self.target_device)
            sg.sg_supported()
            sg.fill_supported_actshape()
            sg.fix_axis()

        if self.init_model_state:
            new_state = {
                i: self.init_model_state[order]
                for i, order in enumerate(model_dict.graph_order)
                if order in self.init_model_state
            }
            self.init_model_state = new_state
        model_dict.rearrange_subgraphs()
        model_dict.single_subgraph_inout_order()

        self.check_match_dtype(model_dict)
        self.weight_fp64_fp32(model_dict)

        if activation_tracer:
            for k, v in activation_tracer.act_trace.items():
                if v.trace_type == 0:  # from original model
                    model_dict.activation_trace[k] = (v.name, v.src_shape)
        self.parse_finished = True

        #     fixme: 임시로 고쳐놓음. unsuqueeze와 squeeze 등이 있어야 dynamic dimension이 2개 이상에 대해서도 가능함.
        for sg in model_dict.subgraphs:
            for op in sg.operators:
                if op.layertype == LayerType.Reshape:
                    if op.options.new_shape is None:
                        new_shape = sg.activations[
                            op.options.outputs[0]
                        ].get_act_src_shape()
                        new_shape = tuple(
                            -1 if x.dynamic else int(x) for x in new_shape
                        )
                        op.options.new_shape = new_shape

        if self._exclude_first_subgraph:
            self.remove_first_unsupported_subgraph_for_offloading(model_dict)

    def remove_first_unsupported_subgraph_for_offloading(self, model_dict: ModelDict):
        md = model_dict

        if len(md.subgraphs) <= 1:
            return None

        new_subgraphs = []
        first_sg = md.subgraphs[md.graph_order[0]]
        if not first_sg.unsupported:
            return None

        first_sg_inputs = [first_sg.activations[iidx].name for iidx in first_sg.inputs]
        first_sg_outputs = [
            first_sg.activations[oidx].name for oidx in first_sg.outputs
        ]
        md.inputs = [
            input_name for input_name in md.inputs if input_name not in first_sg_inputs
        ]
        md.inputs = first_sg_outputs + md.inputs

        for idx, gorder in enumerate(md.graph_order[1:]):
            sg = md.subgraphs[gorder]
            sg.idx = idx
            new_subgraphs.append(sg)
        md.subgraphs = new_subgraphs
        md.graph_order = [sg.idx for sg in md.subgraphs]

    def check_match_dtype(self, model_dict: ModelDict):
        for sg in model_dict.subgraphs:
            for ts in sg.tensors:
                if ts.name in self._weight_dict:
                    dtype_tensor = ts.dtype
                    dtype_weight_dict = str(
                        self._weight_dict.get_weight_by_name(ts.name).dtype
                    )
                    if dtype_tensor == dtype_weight_dict:
                        pass
                    else:
                        if isinstance(dtype_tensor, str):
                            dtype_tensor = dtype_tensor.lower()
                        self._weight_dict._weight_dict[
                            ts.name
                        ] = self._weight_dict._weight_dict[ts.name].astype(dtype_tensor)
                        logger.info(
                            f"Tensor dtype: {dtype_tensor}, weight dtype: {dtype_weight_dict}, weight were automatically casted to tensor dtype"
                        )
                else:
                    raise ValueError("tensor name in a subgraph is not in weight dict")

    def weight_fp64_fp32(self, model_dict: ModelDict):
        for sg in model_dict.subgraphs:
            for ts in sg.tensors:
                if ts.name in self._weight_dict:
                    dtype_weight = str(
                        self._weight_dict.get_weight_by_name(ts.name).dtype
                    )
                    if dtype_weight == "float64":
                        default_dtype = "float32"
                        self._weight_dict._weight_dict[
                            ts.name
                        ] = self._weight_dict._weight_dict[ts.name].astype(
                            default_dtype
                        )
                        ts.dtype = default_dtype

    def get_body_md_wd(self):
        return self._model_dict.get_body_model_dict(self._weight_dict)

    def get_all_seperated_model_dicts(self):
        return self._model_dict.get_all_seperated_model_dicts(self._weight_dict)

    def _get_stats(self):
        # _exclude = [LayerType.Input, LayerType.Output, LayerType.DeviceBridge]
        _exclude = []
        md = self._model_dict
        op_cnt = {}
        for idx, sg in enumerate(md.subgraphs):
            for op in sg.operators:
                if op.layertype in _exclude:
                    continue
                if op.layertype not in op_cnt:
                    op_cnt[op.layertype] = [0, 0]
                if op.unsupported:
                    op_cnt[op.layertype][0] += 1
                else:
                    op_cnt[op.layertype][1] += 1
        rows = []
        for k, v in op_cnt.items():
            rows.append([k.name, sum(v), v[0], v[1] / sum(v) * 100])
        rows = sorted(rows, key=lambda x: x[0], reverse=False)
        num_all_ops = sum(sum(v) for v in op_cnt.values())
        num_all_unsupported = sum(v[0] for v in op_cnt.values())
        coverage = (num_all_ops - num_all_unsupported) / num_all_ops * 100
        summary = ["All", num_all_ops, num_all_unsupported, coverage]
        dct = {
            "backend": self.backend,
            "header": ["OpType", "Count", "Unsupported", "Supported(%)"],
            "rows": rows,
            "summary": summary,
            "num_subgraphs": len(md.subgraphs),
        }
        return dct

    def print_model_stats(self, stage=""):
        stats = self._get_stats()
        title = f"Summary by Operator Type"
        if stage:
            title += f"[{stage}]"
        tb = format_table(
            header=stats["header"],
            rows=stats["rows"],
            summary=stats["summary"],
            header_format="s" * len(stats["header"]),
            row_format="siif",
            title=title,
        )

        stateful_lstm_sg = {}
        for sg in self._model_dict.subgraphs:
            for op in sg.operators:
                if op.layertype == LayerType.StatefulLSTMWrapper:
                    stateful_lstm_sg[op.options.subgraph] = -1
        for sg in self._model_dict.subgraphs:
            if sg.name in stateful_lstm_sg:
                stateful_lstm_sg[sg.name] = sg.idx

        logger.info("[parser]\n" + tb)

        inputs = []
        for x in self._model_dict.inputs:
            inputs += self._get_act_info_str(x)
        outputs = []
        for x in self._model_dict.outputs:
            outputs += self._get_act_info_str(x)

        msg = [
            f"Number of Subgraphs: {stats['num_subgraphs']}",
            f"graph order: {self.model_dict.graph_order}",
            f"stateful_lstm_subgraphs: {dict((v, k) for k, v in stateful_lstm_sg.items())}",
            # f"num ops: To be implemented.",
            f"backend: {stats['backend']}",
            f"model inputs: {inputs}",
            f"model outputs: {outputs}",
        ]
        logger.info("[parser]\n" + "\n".join(msg))
        logger.info("outputs:")
        print()

    def _get_act_info_str(self, act_name):
        lst = []
        for sg in self._model_dict.subgraphs:
            for act in sg.activations:
                if act.name == act_name:
                    lst.append(
                        f"name: {act.name}, src_shape: {str(act.src_shape).replace(' ', '')}, dataformat: {act.dataformat.name}, origin_name: {self._model_dict.get_act_origin_name(act.name, '')}",
                    )
        return lst

    def _update_model_inout(
        self, activation_tracer, origin_input_list, origin_output_list
    ):
        temp_inputs = []
        temp_outputs = []

        for sg in self._model_dict.subgraphs:
            for iidx in sg.inputs:
                tracer_name = activation_tracer.get(
                    sg.activations[iidx].name, sg.activations[iidx]
                ).name
                actual_name = sg.activations[iidx].name
                shape = sg.activations[iidx].get_act_src_shape()
                temp_inputs.append((tracer_name, actual_name, shape))
            for oidx in sg.outputs:
                tracer_name = activation_tracer.get(
                    sg.activations[oidx].name, sg.activations[oidx]
                ).name
                actual_name = sg.activations[oidx].name
                if not any(
                    op.layertype == LayerType.Output
                    for op in sg.activations[oidx].consumer_ops
                ):
                    continue
                shape = sg.activations[oidx].get_act_src_shape()

                temp_outputs.append((tracer_name, actual_name, shape))
        # The inputs and outputs of model_dict are sorted first by the order of origin_input_list (immediately after parsing) and then by shape.
        if origin_input_list:
            temp_inputs.sort(
                key=lambda x: (
                    (
                        origin_input_list.index(x[0])
                        if x[0] in origin_input_list
                        else float("inf")
                    ),
                    tuple(x[2]),
                )
            )
        if origin_output_list:
            temp_outputs.sort(
                key=lambda x: (
                    (
                        origin_output_list.index(x[0])
                        if x[0] in origin_output_list
                        else float("inf")
                    ),
                    tuple(x[2]),
                )
            )

        model_inputs = [actual for _, actual, _ in temp_inputs]
        model_outputs = [actual for _, actual, _ in temp_outputs]

        self._model_dict.inputs = model_inputs
        self._model_dict.outputs = model_outputs

    def print_dformat_stats(self):
        lst = []
        for sg in self._model_dict.subgraphs:
            for act in sg.activations:
                if act.dataformat == DataFormat.UNKNOWN and not self._weight_dict.isin(
                    act.name
                ):
                    lst.append(act)
        logger.debug("========= print dformat_stats =========")
        logger.debug(f"Number of unknown dataformat: {len(lst)}")
        for a in lst:
            if a.producer_op:
                logger.debug(f"  layername: {a.name}, type:{a.producer_op.layertype}")
            else:
                logger.debug(f"  layername: {a.name}, type: NA")
        logger.debug("=======================================================\n\n")

    @property
    def model_dict(self):
        return self._model_dict

    @property
    def weight_dict(self):
        return self._weight_dict

    @property
    def value_dict(self):
        return self._value_dict

    @value_dict.setter
    def value_dict(self, value_dict):
        self._value_dict = value_dict

    def run_inference_and_compare_output_value(
        self,
        save_all_inference_outputs=False,
        compare_result_output_path="",
        inference_all_outputs_write_path="",
        test_type=None,
        inference_save_targets=None,
        value_dict_dir_path=None,
        **kwargs,
    ):
        logger.info("[parser] run inference and compare values.")
        if test_type is None:
            pass
        elif test_type in ["py", "python"]:
            kwargs["use_value_dict_data_for_next_input"] = True
            kwargs["quantizer_save"] = False
        elif test_type in ["c++", "quantizer"]:
            kwargs["use_value_dict_data_for_next_input"] = False
            kwargs["quantizer_save"] = True
        else:
            raise NotImplementedError("Notimplemented test type")

        if (
            hasattr(self.model_dict, "init_model_state")
            and self.model_dict.init_model_state
        ):
            kwargs["init_model_state"] = self.model_dict.init_model_state

        if value_dict_dir_path:
            self.value_dict = load_all_tensors(value_dict_dir_path)

        model_inference = ModelInference(
            model_dict=self.model_dict,
            weight_dict=self.weight_dict,
            value_dict=self.value_dict,
            activation_tracer=self.activation_tracer,
            save_all_outputs=save_all_inference_outputs,
            inference_all_outputs_write_path=inference_all_outputs_write_path,
            compare_result_output_path=compare_result_output_path,
        )

        model_inference.run_inference(
            inference_save_targets=inference_save_targets, **kwargs
        )
        model_inference.print_result()
        error_occur = model_inference.check_error()

        return error_occur

    def ops(self, md=None, wd=None):
        ops_dict = dict()
        num_unsupported_ops = 0
        num_supported_ops = 0

        if md is None:
            md = self.model_dict
        if wd is None:
            wd = self._weight_dict

        error_ops = set()
        for subgraph in md.subgraphs:
            name = subgraph.name
            ops = 0
            for op in subgraph.operators:
                if op.layertype in (
                    LayerType.StatefulLSTMWrapper,
                    LayerType.StatefulGRUWrapper,
                    LayerType.StatefulRNNWrapper,
                ):
                    logger.info(
                        f"Recurent layer is included in model, ops calculation is implemented yet"
                    )
                else:
                    in_acts = [subgraph.activations[x] for x in op.options.inputs]
                    out_acts = [subgraph.activations[x] for x in op.options.outputs]
                    try:
                        layer_inference = OperatorInference(
                            op.options,
                            layer_name=op.name,
                            inputs=in_acts,
                            outputs=out_acts,
                            subgraph=subgraph,
                            weight_dict=wd,
                        )
                        ops += layer_inference.get_ops()
                    except Exception:
                        if op.layertype not in error_ops:
                            error_ops.add(op.layertype)
                            logger.info(
                                f"Failed to get ops for {op.layertype}. This does not affect model compilation."
                            )
            ops_dict[name] = int(ops) / 1e9
            if subgraph.unsupported:
                num_unsupported_ops += ops_dict[name]
            else:
                num_supported_ops += ops_dict[name]

        return ops_dict, num_supported_ops, num_unsupported_ops

    def print_ops(self, model_name):
        _, num_supported_ops, num_unsupported_ops = self.ops()
        total_ops = num_supported_ops + num_unsupported_ops
        logger.info(
            f"{model_name} model's number of operations {total_ops:.4f} GOPS, {total_ops / 2:.4f} MACs"
        )
        logger.info("=" * 80)
        logger.info(
            f"  Supported: {num_supported_ops:.4f} GOPS, {num_supported_ops / 2:.4f} MACs"
        )
        logger.info(
            f"  Unsupported: {num_unsupported_ops:.4f} GOPS, {num_unsupported_ops / 2:.4f} MACs"
        )
        logger.info("=" * 80)

    def _setup_signal_handlers(self):
        signals = [
            signal.SIGINT,  # Ctrl+C (Interrupt)
            signal.SIGTERM,  # Termination request
            signal.SIGHUP,  # Hangup detected
            signal.SIGQUIT,  # Quit (Ctrl+\)
            signal.SIGABRT,  # Abort
            signal.SIGTSTP,  # Ctrl+Z (Stop typed at terminal)
        ]

        for sig in signals:
            signal.signal(sig, self._handle_signal)

    def _handle_signal(self, signum, frame):
        self.cleanup()
        sys.exit(1)

    def cleanup(self):
        self.delete_tmp_dir()

    def __del__(self):
        self.cleanup()

    def get_md_wd_for_export_subgraph(self):
        export_md = self._md_for_export_subgraph
        src_wd = self._weight_dict_for_export_subgraph
        if src_wd is None:
            src_wd = self._make_filtered_weight_dict(export_md, self.weight_dict)
        return export_md, src_wd

    def get_md_wd(self, body_only=False):
        if body_only:
            return self._model_dict.get_body_model_dict(self._weight_dict)
        return self.model_dict, self.weight_dict
