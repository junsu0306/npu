import collections
import copy
import dataclasses
import itertools
from typing import List, Dict

from qbcompiler.model_dict.common import SubGraph, LayerType, Operator, DataFormat
from qbcompiler.model_dict.common.options import (
    InputOptions,
    OutputOptions,
    DeviceBridgeOptions,
)
from qbcompiler.model_dict.parser.graph_transform import ActivationTracer

_LAST_TERMINAL_LAYERTYPES = (
    LayerType.Softmax,
    LayerType.Sigmoid,
    LayerType.Transpose,
    LayerType.Reshape,
)


def _is_merge_two_components_circular(edges):
    in_degree = {k: 0 for k in edges.keys()}
    q = collections.deque()
    visited = 0
    for k, nbrs in edges.items():
        for nbr in nbrs:
            in_degree[nbr] += 1
    for k, cnt in in_degree.items():
        if cnt == 0:
            q.append(k)
    while q:
        u = q.popleft()
        visited += 1
        for nbr in edges[u]:
            in_degree[nbr] -= 1
            if in_degree[nbr] == 0:
                q.append(nbr)

    return visited != len(edges)


class _SGItems:
    def __init__(self):
        self.ts_map = {}
        self.act_map = {}
        self.activations = []
        self.tensors = []
        self.ops = []
        self.sg_inputs = set()
        self.sg_outputs = set()

    def as_subgraph(self, sg_idx, unsupported):
        sg = SubGraph(
            idx=sg_idx,
            operators=self.ops,
            inputs=list(self.sg_inputs),
            outputs=list(self.sg_outputs),
            tensors=self.tensors,
            activations=self.activations,
            unsupported=unsupported,
        )
        return sg

    def update_act_map(self, act_idx_main, sg_main):
        if act_idx_main not in self.act_map:
            self.act_map[act_idx_main] = len(self.activations)
            act = sg_main.activations[act_idx_main].copy()
            self.activations.append(act)

    def get_act_idx_from_main(self, act_idx_main):
        return self.act_map[act_idx_main]

    def _get_new_option(self, op_main: Operator, sg_main):
        kw = {}
        for fname, tidx in op_main.options.iter_tensorindex():
            if tidx == -1:
                kw[fname] = tidx
                continue
            ts = sg_main.tensors[tidx]
            if ts.name not in self.ts_map:
                self.ts_map[ts.name] = len(self.tensors)
                self.tensors.append(ts.copy())
            else:
                if self.tensors[self.ts_map[ts.name]] != ts:
                    raise ValueError(f"tensors have the same name but are different")
            kw[fname] = self.ts_map[ts.name]
        kw["inputs"] = tuple(self.act_map[x] for x in op_main.options.inputs)
        kw["outputs"] = tuple(self.act_map[x] for x in op_main.options.outputs)
        return dataclasses.replace(op_main.options, **kw)

    def update_sg_input(self, inact_idx):
        self.sg_inputs.update(self.act_map[x] for x in inact_idx)

    def update_sg_output(self, out_idx):
        self.sg_outputs.update(self.act_map[x] for x in out_idx)

    def add_input_ops(self, add_input_candidates, unsupported):
        for act_idx_main in add_input_candidates:
            act_idx = self.act_map[act_idx_main]
            self.ops.append(
                Operator(
                    self.activations[act_idx].name,
                    options=InputOptions((act_idx,), (act_idx,)),
                    unsupported=unsupported,
                )
            )

    def add_output_ops(self, add_output_candidates, unsupported):
        for act_idx_main in add_output_candidates:
            act_idx = self.act_map[act_idx_main]
            self.ops.append(
                Operator(
                    self.activations[act_idx].name,
                    options=OutputOptions((act_idx,), (act_idx,)),
                    unsupported=unsupported,
                )
            )

    def add_op(self, op_main, sg_main, unsupported):
        new_opt = self._get_new_option(op_main, sg_main)
        op_name = self.activations[new_opt.outputs[0]].name
        new_op = Operator(
            op_name,
            options=new_opt,
            unsupported=unsupported,
            output_value_reference=op_main.output_value_reference,
        )
        if hasattr(op_main, "custom_fn"):
            new_op.custom_fn = op_main.custom_fn
        self.ops.append(new_op)

    def _get_bridge_layer_act(
        self, ref_act, bridge_name, activation_tracer: ActivationTracer | None = None
    ):
        bridge_act = ref_act.copy(name=bridge_name)
        if activation_tracer:
            trace = activation_tracer.get(ref_act.name)
            if trace is not None:
                activation_tracer.act_trace[bridge_act.name] = trace
        bridge_act_idx = len(self.activations)
        self.activations.append(bridge_act)
        return bridge_act, bridge_act_idx

    def _get_bridge_layer_name(self, ref_name, bridge_layer_names):
        cnt = 0
        bridge_name = f"bridge{cnt};{ref_name}"
        while bridge_name in bridge_layer_names:
            bridge_name = f"bridge{cnt};{ref_name}"
            cnt += 1
        return bridge_name

    def add_bridge_in_ops(
        self,
        bridge_in_candidates,
        bridge_layer_names,
        sg_main,
        unsupported,
        activation_tracer,
    ):
        for act_idx_main in bridge_in_candidates:
            bridge_inact_idx = self.act_map[act_idx_main]
            bridge_inact = self.activations[bridge_inact_idx]
            bridge_name = self._get_bridge_layer_name(
                bridge_inact.name, bridge_layer_names
            )
            bridge_layer_names.append(bridge_name)
            bridge_oact, bridge_oact_idx = self._get_bridge_layer_act(
                bridge_inact, bridge_name, activation_tracer
            )
            self.act_map[act_idx_main] = bridge_oact_idx
            inop = Operator(
                bridge_inact.name,
                options=InputOptions(
                    inputs=(bridge_inact_idx,), outputs=(bridge_inact_idx,)
                ),
                unsupported=unsupported,
                output_value_reference=sg_main.activations[
                    act_idx_main
                ].producer_op.output_value_reference,
            )
            bridge_inact.producer_op = inop
            bridge = Operator(
                bridge_oact.name,
                options=DeviceBridgeOptions(
                    inputs=(bridge_inact_idx,),
                    outputs=(bridge_oact_idx,),
                    squeeze_axes=(),
                    unsqueeze_axes=(),
                    permute_axes=(),
                    device="npu",
                ),
                unsupported=unsupported,
                output_value_reference=sg_main.activations[
                    act_idx_main
                ].producer_op.output_value_reference,  # only shape change
            )
            self.ops.extend([inop, bridge])

    def add_bridge_out_ops(
        self,
        bridge_out_candidates,
        bridge_layer_names,
        sg_main,
        unsupported,
        activation_tracer,
    ):
        for act_idx_main in bridge_out_candidates:
            bridge_oact_idx = self.act_map[act_idx_main]
            bridge_oact = self.activations[bridge_oact_idx]
            bridge_name = self._get_bridge_layer_name(
                bridge_oact.name, bridge_layer_names
            )
            bridge_layer_names.append(bridge_name)
            bridge_inact, bridge_inact_idx = self._get_bridge_layer_act(
                bridge_oact, bridge_name, activation_tracer
            )
            self.act_map[act_idx_main] = bridge_inact_idx
            bridge = Operator(
                bridge_oact.name,
                options=DeviceBridgeOptions(
                    inputs=(bridge_inact_idx,),
                    outputs=(bridge_oact_idx,),
                    squeeze_axes=(),
                    unsqueeze_axes=(),
                    permute_axes=(),
                    device="npu",
                ),
                unsupported=unsupported,
            )
            self.ops.append(bridge)


class DeviceAllocator2:
    def __init__(self, strip_lstm_node_as_subgraph=True):
        self.sg_main: SubGraph = None
        self.components = {}
        self.partial_order = {}
        self.preconditions = {}
        self.comp_in = {}
        self.comp_out = {}
        self.bridge_layer_names = []
        self.strip_lstm_node_as_subgraph = strip_lstm_node_as_subgraph
        if self.strip_lstm_node_as_subgraph:
            self._STATEFUL_NODES_TYPES = [
                LayerType.StatefulLSTMWrapper,
                LayerType.StatefulRNNWrapper,
                LayerType.StatefulGRUWrapper,
            ]
        else:
            self._STATEFUL_NODES_TYPES = []

    def _reindex_subgraphs(self):
        remap = {k: i for i, k in enumerate(self.components.keys())}
        comp = {}
        po_remap = {}
        for k, v in self.components.items():
            for op in v:
                self.sg_main.operators[op].subgraph_idx = remap[k]
            comp[remap[k]] = v
        for k, v in self.partial_order.items():
            po_remap[remap[k]] = [remap[x] for x in v]
        self.components = comp
        self.partial_order = po_remap

    def _fix_terminal_speical_op_unsupported(self):
        changed = True
        while changed:
            changed = False
            for op in self.sg_main.operators:
                if op.layertype not in _LAST_TERMINAL_LAYERTYPES:
                    continue
                if op.unsupported:
                    continue
                if all(
                    self.sg_main.operators[nop_idx].unsupported
                    for nop_idx in op.next_operators
                ):
                    op.unsupported = True
                    changed = True

    def allocate(
        self,
        sg_main: SubGraph,
        activation_tracer: ActivationTracer | None = None,
        **kwargs,
    ):
        self.sg_main = sg_main
        self._fix_terminal_speical_op_unsupported()
        self._color_graph()

        self._merge_components()
        self._reindex_subgraphs()
        self._get_componenet_inout()
        subgraphs = self._get_subgraphs(activation_tracer)
        for sg in subgraphs:
            if sg.unsupported:
                self._update_device_bridge_options(sg)

        # remove unnecessary identity device bridge
        removed_map = {}
        for sg in subgraphs:
            if sg.unsupported:
                removed_bridge_out_map = self._remove_identity_device_bridge(sg)
                removed_map.update(removed_bridge_out_map)

        for sg in subgraphs:
            for op in sg.operators:
                if op.layertype != LayerType.Input:
                    continue
                oact = sg.activations[op.options.outputs[0]]
                if oact.name in removed_map:
                    oact.name = removed_map[oact.name]

        # remove unnecessary input layer
        for sg in subgraphs:
            if sg.unsupported:
                self._remove_unnecessary_input_layer(sg)

        # remove danglings
        for sg in subgraphs:
            sg.remove_dangling_activations()
            sg.update_op_act_connectivity()

        return subgraphs, self.partial_order

    def _remove_identity_device_bridge(self, sg: SubGraph) -> Dict:
        def _is_identity_bridge(op):
            return op.layertype == LayerType.DeviceBridge and not (
                op.options.permute_axes
                or op.options.squeeze_axes
                or op.options.unsqueeze_axes
            )

        removed_bridge_out_map = {}

        for op in sg.operators:
            op.valid = True
            if not _is_identity_bridge(op):
                continue

            bridge_iidx = op.options.inputs[0]
            bridge_oidx = op.options.outputs[0]
            bridge_inact = sg.activations[bridge_iidx]
            bridge_outact = sg.activations[bridge_oidx]

            if bridge_inact.producer_op.layertype == LayerType.Input:
                for cop in bridge_outact.consumer_ops:
                    new_inputs = [
                        bridge_iidx if i == bridge_oidx else i
                        for i in cop.options.inputs
                    ]
                    cop.options = dataclasses.replace(cop.options, inputs=new_inputs)
                op.valid = False
            elif not bridge_outact.consumer_ops:
                removed_bridge_out_map[bridge_outact.name] = bridge_inact.name
                # removed_bridge_out_map[bridge_oidx] = bridge_iidx
                sg.outputs = [x for x in sg.outputs if x != bridge_oidx]
                if bridge_iidx not in sg.outputs:
                    sg.outputs.append(bridge_iidx)
                op.valid = False

        sg.operators = [op for op in sg.operators if op.valid]
        sg.update_op_act_connectivity()
        return removed_bridge_out_map

    def _remove_unnecessary_input_layer(self, sg: SubGraph):
        model_input_names = [
            self.sg_main.activations[x].name for x in self.sg_main.inputs
        ]
        for op in sg.operators:
            op.valid = not (
                op.layertype == LayerType.Input
                and not sg.activations[op.options.outputs[0]].name in model_input_names
            )
        sg.operators = [op for op in sg.operators if op.valid]
        sg.update_op_act_connectivity()
        for iidx in sg.inputs:
            sg.activations[iidx].producer_op = None

    def _update_device_bridge_options(self, sg: SubGraph):
        def _is_bridge_options_empty(op):
            return not (
                op.options.permute_axes
                or op.options.squeeze_axes
                or op.options.unsqueeze_axes
            )

        def _is_fuse_transpose_next(next_op):
            return (
                next_op.layertype == LayerType.Transpose
                and next_op.options.transpose_axes == (0, 3, 1, 2)
            )

        def _is_fuse_reshape_nc_next(next_op):
            inact = sg.activations[next_op.options.inputs[0]]
            if inact.src_shape == (-1, -1, -1):
                inact_src_shape = (1,) + inact.src_shape
            else:
                inact_src_shape = inact.src_shape
            outact = sg.activations[next_op.options.outputs[0]]
            return (
                next_op.layertype == LayerType.Reshape
                and outact.dataformat == DataFormat.NC
                and inact_src_shape == (outact.src_shape[0], 1, 1, outact.src_shape[-1])
            )

        def _is_fuse_transpose_prev(prev_op):
            return (
                prev_op.layertype == LayerType.Transpose
                and prev_op.options.transpose_axes == (0, 2, 3, 1)
            )

        for op in sg.operators:
            if op.layertype != LayerType.DeviceBridge:
                continue
            if op.options.inputs[0] in sg.inputs:
                device_outact = sg.activations[op.options.outputs[0]]
                if len(device_outact.consumer_ops) != 1:
                    continue
                if device_outact.dataformat != DataFormat.NHWC:
                    continue

                next_op = device_outact.consumer_ops[0]
                if _is_fuse_transpose_next(next_op) and _is_bridge_options_empty(op):
                    op.options = dataclasses.replace(
                        op.options,
                        permute_axes=next_op.options.transpose_axes,
                        outputs=(next_op.options.outputs[0],),
                    )
                    sg.activations[next_op.options.outputs[0]].producer_op = op
                    next_op.valid = False
                elif _is_fuse_reshape_nc_next(next_op) and _is_bridge_options_empty(op):
                    op.options = dataclasses.replace(
                        op.options,
                        squeeze_axes=(1, 2),
                        outputs=(next_op.options.outputs[0],),
                    )
                    sg.activations[next_op.options.outputs[0]].producer_op = op
                    next_op.valid = False
            if op.options.outputs[0] in sg.outputs:
                device_inact = sg.activations[op.options.inputs[0]]
                if len(device_inact.consumer_ops) != 1:
                    continue
                if device_inact.dataformat != DataFormat.NHWC:
                    continue
                prev_op = device_inact.producer_op
                if _is_fuse_transpose_prev(prev_op) and _is_bridge_options_empty(op):
                    op.options = dataclasses.replace(
                        op.options,
                        permute_axes=prev_op.options.transpose_axes,
                        inputs=(prev_op.options.inputs[0],),
                    )
                    sg.activations[prev_op.options.inputs[0]].consumer_ops = [op]
                    prev_op.valid = False

        sg.operators = [x for x in sg.operators if x.valid]

    def _prepare_subgraph_supported(
        self, operator_indicies: List[int], inact_idx, outact_idx, activation_tracer
    ):
        sg_items = _SGItems()
        add_input_candidates = inact_idx.copy()
        add_output_candidates = outact_idx.copy()
        for op_i in operator_indicies:
            op = self.sg_main.operators[op_i]
            if op.layertype == LayerType.Input:
                add_input_candidates.remove(op.options.outputs[0])
            elif op.layertype == LayerType.Output:
                add_output_candidates.remove(op.options.inputs[0])
            for i in itertools.chain(op.options.inputs, op.options.outputs):
                sg_items.update_act_map(i, self.sg_main)
            sg_items.add_op(op, self.sg_main, False)
        sg_items.update_sg_input(inact_idx)
        sg_items.update_sg_output(outact_idx)
        sg_items.add_input_ops(add_input_candidates, False)
        sg_items.add_output_ops(add_output_candidates, False)

        return sg_items

    def _prepare_subgraph_unsupported(
        self,
        operator_indicies: List[int],
        inact_idx,
        outact_idx,
        activation_tracer: ActivationTracer | None = None,
    ):
        sg_items = _SGItems()
        bridge_in_candidates = inact_idx.copy()
        bridge_out_candidates = outact_idx.copy()
        for op_i in operator_indicies:
            op = self.sg_main.operators[op_i]
            if op.layertype == LayerType.Input:
                bridge_in_candidates.remove(op.options.outputs[0])
            elif op.layertype == LayerType.Output:
                bridge_out_candidates.remove(op.options.inputs[0])
            for i in itertools.chain(op.options.inputs, op.options.outputs):
                sg_items.update_act_map(i, self.sg_main)
        sg_items.update_sg_input(inact_idx)
        sg_items.update_sg_output(outact_idx)
        sg_items.add_bridge_in_ops(
            bridge_in_candidates,
            self.bridge_layer_names,
            self.sg_main,
            unsupported=True,
            activation_tracer=activation_tracer,
        )
        sg_items.add_bridge_out_ops(
            bridge_out_candidates,
            self.bridge_layer_names,
            self.sg_main,
            unsupported=True,
            activation_tracer=activation_tracer,
        )

        for op_i in operator_indicies:
            op = self.sg_main.operators[op_i]
            sg_items.add_op(op, self.sg_main, unsupported=True)
        return sg_items

    def _get_subgraphs(self, activation_tracer: ActivationTracer | None = None):
        subgraphs = []
        sg_main_input_acts = [self.sg_main.activations[x] for x in self.sg_main.inputs]

        for sg_idx, op_indices in self.components.items():
            # op_indices = self.components[sg_idx]
            inact_idx = self.comp_in[sg_idx]
            outact_idx = self.comp_out[sg_idx]
            unsupported = self.sg_main.operators[op_indices[0]].unsupported
            if unsupported:
                sg_items = self._prepare_subgraph_unsupported(
                    op_indices, inact_idx, outact_idx, activation_tracer
                )
            else:
                sg_items = self._prepare_subgraph_supported(
                    op_indices, inact_idx, outact_idx, activation_tracer
                )

            sg = sg_items.as_subgraph(sg_idx, unsupported=unsupported)
            sg.update_op_act_connectivity()
            sg.sort_operators()
            sg.update_graph_in_out()

            #     add output_value_reference if input layer is regerated.
            for x in sg.inputs:
                inact = sg.activations[x]
                if (
                    inact.producer_op.layertype == LayerType.Input
                    and inact.producer_op.output_value_reference is None
                ):
                    input_layer = inact.producer_op
                    for ia in sg_main_input_acts:
                        if (
                            ia.producer_op is not None
                            and ia.producer_op.layertype == LayerType.Input
                            and input_layer.name == ia.producer_op.name
                        ):
                            input_layer.output_value_reference = (
                                ia.producer_op.output_value_reference
                            )

            subgraphs.append(sg)
        return subgraphs

    def _get_componenet_inout(self):
        comp_in = {}  # graph input activations
        comp_out = {}  # graph output activations
        comp_acts = {}  # all activations related with this graph component
        # intermediate activations during this graph computations
        comp_generated_acts = {}

        for sg_idx, op_indicies in self.components.items():
            inputs = set()  # input activation indices except input/output layers.
            in_layer_act = set()  # activation indices of input layers.
            outputs = set()  # output activation indices except input/output layers.
            out_layer_act = set()  # activation indices of output layers.
            acts = set()
            generated_acts = set()

            for op_idx in op_indicies:
                op = self.sg_main.operators[op_idx]
                if op.layertype == LayerType.Input:
                    in_layer_act.add(op.options.outputs[0])
                elif op.layertype == LayerType.Output:
                    out_layer_act.add(op.options.inputs[0])
                    generated_acts.add(op.options.inputs[0])
                elif op.layertype == LayerType.StatefulLSTMWrapper:
                    for iidx in op.options.inputs:
                        inputs.add(iidx)
                        acts.add(iidx)
                    for oidx, mask in zip(op.options.outputs, "ohc"):
                        if mask in op.options.output_mask:
                            outputs.add(oidx)
                        acts.add(oidx)
                        generated_acts.add(oidx)
                else:
                    for iidx in op.options.inputs:
                        inputs.add(iidx)
                        acts.add(iidx)
                    for oidx in op.options.outputs:
                        outputs.add(oidx)
                        acts.add(oidx)
                        generated_acts.add(oidx)
            comp_in[sg_idx] = inputs - outputs
            comp_in[sg_idx].update(in_layer_act)
            comp_out[sg_idx] = outputs - inputs
            comp_out[sg_idx].update(out_layer_act)
            comp_acts[sg_idx] = acts
            comp_generated_acts[sg_idx] = generated_acts

        for sg_idx, next_sg_indices in self.partial_order.items():
            for nsi in next_sg_indices:
                for act_idx in comp_in[nsi]:
                    if (
                        act_idx in comp_generated_acts[sg_idx]
                        and act_idx not in comp_out[sg_idx]
                    ):
                        comp_out[sg_idx].add(act_idx)

        self.comp_in = comp_in
        self.comp_out = comp_out

    def _is_comp_unsupported(self, sg_idx):
        return self.sg_main.operators[self.components[sg_idx][0]].unsupported

    def _is_comp_stateful(self, sg_idx):
        return any(
            self.sg_main.operators[op_idx].layertype in self._STATEFUL_NODES_TYPES
            for op_idx in self.components[sg_idx]
        )

    def _find_and_merge_unconditioned(self):
        supported_sg_indices = []
        unsupported_sg_indices = []
        stateful_sg_indices = []
        for sg_idx in self.components.keys():
            if self.preconditions[sg_idx]:
                continue
            if self._is_comp_stateful(sg_idx):
                stateful_sg_indices.append(sg_idx)
            elif self._is_comp_unsupported(sg_idx):
                unsupported_sg_indices.append(sg_idx)
            else:
                supported_sg_indices.append(sg_idx)
        if len(unsupported_sg_indices) > 1:
            self._merge_unconditioned(unsupported_sg_indices)
        if len(supported_sg_indices) > 1:
            self._merge_unconditioned(supported_sg_indices)

    def _merge_unconditioned(self, sg_indices):
        new_sg_idx = min(sg_indices)
        comp_new = []
        po_new = []
        for sg_idx in sg_indices:
            comp_new += self.components.pop(sg_idx)
            po_old = self.partial_order.pop(sg_idx)
            for next_sg_idx in po_old:
                if next_sg_idx not in po_new:
                    po_new.append(next_sg_idx)
                if sg_idx in self.preconditions[next_sg_idx]:
                    self.preconditions[next_sg_idx].remove(sg_idx)
                    self.preconditions[next_sg_idx].add(new_sg_idx)
        for sg_idx in sg_indices:
            if sg_idx != new_sg_idx:
                self.preconditions.pop(sg_idx)
        self.components[new_sg_idx] = comp_new
        self.partial_order[new_sg_idx] = po_new

    def _find_and_merge_terminal(self):
        supported_sg_indices, unsupported_sg_indices = [], []
        for sg_idx in self.components.keys():
            if self.partial_order[sg_idx]:
                continue
            if self._is_comp_unsupported(sg_idx):
                unsupported_sg_indices.append(sg_idx)
            else:
                supported_sg_indices.append(sg_idx)
        if len(unsupported_sg_indices) > 1:
            self._merge_terminal(unsupported_sg_indices)
        if len(supported_sg_indices) > 1:
            self._merge_terminal(supported_sg_indices)

    def _merge_terminal2(self, sg_indices, components, partial_order, preconditions):
        mgd_sg_idx = max(sg_indices)
        comp_new = []
        pre_new = []
        for sg_idx in sg_indices:
            comp_new += components.pop(sg_idx)
            pre_old = preconditions.pop(sg_idx)
            for pre_sg_idx in pre_old:
                if pre_sg_idx not in pre_new:
                    pre_new.append(pre_sg_idx)
                if sg_idx in partial_order[pre_sg_idx]:
                    partial_order[pre_sg_idx].remove(sg_idx)
                if mgd_sg_idx not in partial_order[pre_sg_idx]:
                    partial_order[pre_sg_idx].append(mgd_sg_idx)
        for sg_idx in sg_indices:
            if sg_idx != mgd_sg_idx:
                for i in partial_order.pop(sg_idx):
                    if i not in partial_order[mgd_sg_idx]:
                        partial_order[mgd_sg_idx].append(i)
        components[mgd_sg_idx] = comp_new
        preconditions[mgd_sg_idx] = pre_new

    def _post_find_and_merge_terminal(self):
        components = copy.deepcopy(self.components)
        partial_order = copy.deepcopy(self.partial_order)
        preconditions = copy.deepcopy(self.preconditions)
        components_new = dict()
        partial_order_new = dict()
        preconditions_new = dict()
        removed_sg_idx = set()
        while components:
            supported_sg_indices = []
            unsupported_sg_indices = []
            stateful_sg_indicies = []
            for sg_idx in components.keys():
                if set(partial_order[sg_idx]).difference(removed_sg_idx):
                    continue
                if self._is_comp_stateful(sg_idx):
                    stateful_sg_indicies.append(sg_idx)
                elif self._is_comp_unsupported(sg_idx):
                    unsupported_sg_indices.append(sg_idx)
                else:
                    supported_sg_indices.append(sg_idx)
            if len(unsupported_sg_indices) > 1:
                self._merge_terminal2(
                    unsupported_sg_indices, components, partial_order, preconditions
                )
            elif len(unsupported_sg_indices) == 1:
                target = unsupported_sg_indices[0]
                components_new[target] = components.pop(target)
                partial_order_new[target] = partial_order.pop(target)
                preconditions_new[target] = preconditions.pop(target)
                removed_sg_idx.add(target)
            if len(supported_sg_indices) > 1:
                self._merge_terminal2(
                    supported_sg_indices, components, partial_order, preconditions
                )
            elif len(supported_sg_indices) == 1:
                target = supported_sg_indices[0]
                components_new[target] = components.pop(target)
                partial_order_new[target] = partial_order.pop(target)
                preconditions_new[target] = preconditions.pop(target)
                removed_sg_idx.add(target)
            if stateful_sg_indicies:
                for target in stateful_sg_indicies:
                    components_new[target] = components.pop(target)
                    partial_order_new[target] = partial_order.pop(target)
                    preconditions_new[target] = preconditions.pop(target)
                    removed_sg_idx.add(target)

        self.components = components_new
        self.partial_order = partial_order_new
        self.preconditions = preconditions_new

    def _merge_terminal(self, sg_indices):
        new_sg_idx = max(sg_indices)
        comp_new = []
        pre_new = []
        for sg_idx in sg_indices:
            comp_new += self.components.pop(sg_idx)
            pre_old = self.preconditions.pop(sg_idx)
            for pre_sg_idx in pre_old:
                if pre_sg_idx not in pre_new:
                    pre_new.append(pre_sg_idx)
                if sg_idx in self.partial_order[pre_sg_idx]:
                    self.partial_order[pre_sg_idx].remove(sg_idx)
                if new_sg_idx not in self.partial_order[pre_sg_idx]:
                    self.partial_order[pre_sg_idx].append(new_sg_idx)
        for sg_idx in sg_indices:
            if sg_idx != new_sg_idx:
                self.partial_order.pop(sg_idx)
        self.components[new_sg_idx] = comp_new
        self.preconditions[new_sg_idx] = pre_new

    def _find_and_merge_input_constant_op(self):
        # fixme: input const는 나머지 다 처리하고 후처리 하는게 나아보임.
        for op in self.sg_main.operators:
            if op.layertype in (
                LayerType.InputConstant,
                LayerType.AttentionMaskInput,
                LayerType.KVCacheInput,
            ):
                outact = self.sg_main.activations[op.options.outputs[0]]
                # if len(outact.consumer_ops) != 1:
                #     raise NotImplementedError
                consumer_op = outact.consumer_ops[0]
                if (
                    consumer_op.layertype not in self._STATEFUL_NODES_TYPES
                    and op.subgraph_idx != consumer_op.subgraph_idx
                ):
                    op_idx = op.idx
                    original_subgraph_idx = op.subgraph_idx
                    new_subgraph_idx = consumer_op.subgraph_idx
                    self.components[original_subgraph_idx].remove(op_idx)
                    if not self.components[original_subgraph_idx]:
                        self.components.pop(original_subgraph_idx)
                        partial_order = self.partial_order.pop(original_subgraph_idx)
                        for po in partial_order:
                            if (
                                po != new_subgraph_idx
                                and po not in self.partial_order[new_subgraph_idx]
                            ):
                                self.partial_order[new_subgraph_idx].append(po)

                    self.components[new_subgraph_idx].append(op_idx)
                    op.subgraph_idx = new_subgraph_idx

    def _merge_components(self):
        self._find_and_merge_input_constant_op()

        self.preconditions = {k: set() for k in self.partial_order.keys()}
        for next_sg_idx, next_indices in self.partial_order.items():
            for ni in next_indices:
                self.preconditions[ni].add(next_sg_idx)

        self._find_and_merge_unconditioned()

        q = collections.deque()  # queue of subgraph index
        for next_sg_idx, pre in self.preconditions.items():
            if not pre:
                q.append(next_sg_idx)

        checked_edges = set()

        while q:
            curr_sg_idx = q.popleft()
            if curr_sg_idx not in self.components:
                continue
            curr_state = self._is_comp_unsupported(curr_sg_idx)
            next_sg_indices = [x for x in self.partial_order[curr_sg_idx]]
            for next_sg_idx in next_sg_indices:
                if (curr_sg_idx, next_sg_idx) in checked_edges:
                    continue
                checked_edges.add((curr_sg_idx, next_sg_idx))

                # not merge
                if (
                    self._is_comp_unsupported(next_sg_idx) != curr_state
                    or self._is_comp_stateful(curr_sg_idx)
                    or self._is_comp_stateful(next_sg_idx)
                ):
                    q.append(next_sg_idx)
                    continue

                # merge
                new_edges = dict()
                for k, v in self.partial_order.items():
                    if k == next_sg_idx:
                        continue
                    if k == curr_sg_idx:
                        lst = set(v + self.partial_order[next_sg_idx]) - {next_sg_idx}
                    else:
                        lst = set([i if i != next_sg_idx else curr_sg_idx for i in v])
                    new_edges[k] = sorted(list(lst))
                if _is_merge_two_components_circular(new_edges):
                    q.append(next_sg_idx)
                    continue
                target_op_indicies = self.components.pop(next_sg_idx)
                for opidx in target_op_indicies:
                    self.sg_main.operators[opidx].subgraph_idx = curr_sg_idx
                self.components[curr_sg_idx].extend(target_op_indicies)
                self.partial_order = new_edges
                q.append(curr_sg_idx)

        self.preconditions = {k: set() for k in self.partial_order.keys()}
        for next_sg_idx, next_indices in self.partial_order.items():
            for ni in next_indices:
                self.preconditions[ni].add(next_sg_idx)

        self._post_find_and_merge_terminal()
        if len(self.sg_main.operators) != sum(len(c) for c in self.components.values()):
            raise Exception

    def _color_graph(self):
        """generate as many subgraphs as needed"""
        components = {}
        partial_order: Dict[int, List] = {}

        def _as_new_subgraph(op, next_sg_idx):
            op.subgraph_idx = next_sg_idx
            components[op.subgraph_idx] = [op.idx]
            partial_order[op.subgraph_idx] = []
            return next_sg_idx + 1

        def _extend_queue(q, op):
            for oidx in op.options.outputs:
                q.extend(self.sg_main.activations[oidx].consumer_ops)

        def _is_make_new_sg_comp(curr_op: Operator, prev_sg_ref_op):
            if curr_op.layertype == LayerType.Output:
                return (
                    self.sg_main.activations[
                        curr_op.options.inputs[0]
                    ].producer_op.layertype
                    not in self._STATEFUL_NODES_TYPES
                )
            if curr_op.layertype in self._STATEFUL_NODES_TYPES:
                return True
            if prev_sg_ref_op.unsupported == curr_op.unsupported:
                return prev_sg_ref_op.layertype in self._STATEFUL_NODES_TYPES
            return True

        for idx, op in enumerate(self.sg_main.operators):
            op.subgraph_idx = -1
            op.idx = idx

        def _is_model_input_op_unsupported(op: Operator):
            act = self.sg_main.activations[op.options.outputs[0]]
            if not act.consumer_ops:
                return True
            if any(x.unsupported for x in act.consumer_ops):
                return True
            if any(x.layertype in self._STATEFUL_NODES_TYPES for x in act.consumer_ops):
                return True
            return False

        for idx, op in enumerate(self.sg_main.operators):
            op.subgraph_idx = -1
            op.idx = idx

        next_sg_idx = 0
        q = collections.deque()
        for iidx in self.sg_main.inputs:
            inact = self.sg_main.activations[iidx]
            if inact.producer_op.layertype != LayerType.Input:
                if inact.producer_op.layertype == LayerType.StatefulLSTMWrapper:
                    pass
                else:
                    raise Exception("model input requires Input Layer.")
            # determine input layer is unsupported or not.
            input_op = inact.producer_op
            input_op.unsupported = _is_model_input_op_unsupported(input_op)
            next_sg_idx = _as_new_subgraph(input_op, next_sg_idx)
            _extend_queue(q, input_op)
        for op in self.sg_main.operators:
            if op.layertype not in (
                LayerType.InputConstant,
                LayerType.AttentionMaskInput,
                LayerType.KVCacheInput,
            ):
                continue
            op.unsupported = _is_model_input_op_unsupported(op)
            next_sg_idx = _as_new_subgraph(op, next_sg_idx)
            _extend_queue(q, op)

        while q:
            curr_op = q.popleft()
            if curr_op.subgraph_idx != -1:
                continue
            prev_state = {}
            for i in curr_op.options.inputs:
                pop = self.sg_main.activations[i].producer_op
                prev_state[pop.subgraph_idx] = pop

            # unable to execute curr_op for the moment.
            if -1 in prev_state:
                continue
            sg_idx_candidate = max(prev_state.keys())

            if _is_make_new_sg_comp(curr_op, prev_state[sg_idx_candidate]):
                next_sg_idx = _as_new_subgraph(curr_op, next_sg_idx)
                for i in curr_op.options.inputs:
                    pop = self.sg_main.activations[i].producer_op
                    k = pop.subgraph_idx
                    if (
                        k != curr_op.subgraph_idx
                        and curr_op.subgraph_idx not in partial_order[k]
                    ):
                        if (
                            pop.layertype != LayerType.Input
                            or curr_op.layertype in self._STATEFUL_NODES_TYPES
                        ):
                            partial_order[k].append(curr_op.subgraph_idx)

            else:
                curr_op.subgraph_idx = sg_idx_candidate
                components[sg_idx_candidate].append(curr_op.idx)
                for k in prev_state.keys():
                    if k == sg_idx_candidate:
                        continue
                    if sg_idx_candidate not in partial_order[k]:
                        partial_order[k].append(sg_idx_candidate)
            _extend_queue(q, curr_op)

        self.components = components
        self.partial_order = partial_order

        if len(self.sg_main.operators) != sum(len(c) for c in self.components.values()):
            raise Exception("some operators are missing during coloring.")
