import abc
import collections
from functools import wraps
from typing import Tuple, Dict, Any

import torch


class InputsConatainerABC(abc.ABC):
    def __init__(self):
        self.captured_args = []
        self.captured_kwargs = []

    def __call__(self, *args, **kwargs):
        self.captured_args.append(self._capture_args(*args, **kwargs))
        self.captured_kwargs.append(self._capture_kwargs(*args, **kwargs))

    @abc.abstractmethod
    def _capture_args(self, *args, **kwargs) -> Tuple[Any]:
        ...

    @abc.abstractmethod
    def _capture_kwargs(self, *args, **kwargs) -> Dict[str, Any]:
        ...


class DefaultInputsCaptureContainer(InputsConatainerABC):
    def _capture_args(self, *args, **kwargs) -> Tuple[Any]:
        return args

    def _capture_kwargs(self, *args, **kwargs) -> Dict[str, Any]:
        dct = {}
        for k, v in kwargs.items():
            if isinstance(v, torch.Tensor):
                dct[k] = v.clone().detach().cpu()
            else:
                dct[k] = v
        return dct


class InputCaptureCtxManager:
    def __init__(
        self, model, max_call_limit, inputs_container, target_fn_name="forward"
    ):
        self.model = model
        self.max_call_limit = max_call_limit
        self.inputs_container = inputs_container
        self._call_count = 0
        self._target_fn_name = target_fn_name
        self._target_fn = getattr(model, target_fn_name)

    def __call__(self, *args, **kwargs):
        self.inputs_container(*args, **kwargs)
        self._call_count += 1
        if self._call_count >= self.max_call_limit:
            raise RuntimeError("max num call limit reached.")
        return self._target_fn(*args, **kwargs)

    def __enter__(self):
        # to keep original function's signature
        @wraps(self._target_fn)
        def wrapper(*args, **kwargs):
            return self(*args, **kwargs)

        setattr(self.model, self._target_fn_name, wrapper)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            setattr(self.model, self._target_fn_name, self._target_fn)
            return True
        return False


class OrderedNamespace:
    def __init__(self):
        self._data = collections.OrderedDict()

    def __getattr__(self, name):
        if name in self._data:
            return self._data[name]
        raise AttributeError(
            f"'{type(self).__name__}' object has no attribute '{name}'"
        )

    def __setattr__(self, name, value):
        if name == "_data":  # Protect internal _data attribute
            super().__setattr__(name, value)
        else:
            self._data[name] = value

    def __delattr__(self, name):
        if name in self._data:
            del self._data[name]
        else:
            raise AttributeError(
                f"'{type(self).__name__}' object has no attribute '{name}'"
            )

    def __getitem__(self, index):
        """Get the element by its insertion order index."""
        if isinstance(index, str):
            inner_dict = dict(self.items())
            return inner_dict[index]
        if isinstance(index, int):
            if index < 0 or index >= len(self._data):
                raise IndexError("Index out of range.")
            key = list(self._data.keys())[index]
            return self._data[key]
        else:
            raise TypeError("Index must be an integer.")

    def __setitem__(self, key, value):
        raise NotImplementedError("this is ambiguous. do not use it.")

    def __delitem__(self, key):
        raise NotImplementedError("this is ambiguous. do not use it.")

    def get_by_index(self, index):
        """Access by insertion order index."""
        if index < 0 or index >= len(self._data):
            raise IndexError("Index out of range.")
        key = list(self._data.keys())[index]
        return key, self._data[key]

    def __repr__(self):
        return f"{type(self).__name__}({self._data})"

    def items(self):
        """Expose OrderedDict items."""
        return self._data.items()

    def keys(self):
        """Expose OrderedDict keys."""
        return self._data.keys()

    def values(self):
        """Expose OrderedDict values."""
        return self._data.values()
