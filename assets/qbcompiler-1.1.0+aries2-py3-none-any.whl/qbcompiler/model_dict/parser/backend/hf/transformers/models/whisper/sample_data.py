from datasets import load_dataset


def get_sample_data(model_id):
    try:
        from transformers import AutoProcessor
    except:
        raise ImportError(
            "Failed to import transformers. To compile whisper model, please refer to the Mobilint Docker environment and install an appropriate version of transformers."
        )
    dataset = load_dataset(
        "distil-whisper/librispeech_long", "clean", split="validation"
    )
    processor = AutoProcessor.from_pretrained(model_id)
    sample = dataset[0]["audio"]

    sample.pop("path", None)
    _inputs = sample.pop("array")
    inputs = _inputs

    feature_extractor = processor.feature_extractor
    processed = feature_extractor(
        inputs,
        sampling_rate=feature_extractor.sampling_rate,
        trunctaion=False,
        padding="longest",
        return_tensors="pt",
    )
    return processed
