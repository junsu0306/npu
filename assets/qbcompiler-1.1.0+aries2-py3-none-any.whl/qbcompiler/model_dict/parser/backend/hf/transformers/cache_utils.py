class DynamicCache:
    def __init__(self, past_seq_len=0):
        self.past_seq_len = past_seq_len

    def get_updated(self, seq_len):
        return DynamicCache(self.past_seq_len + seq_len)
