from typing import Optional

import numpy
import torch

import qbcompiler.mobilint_transformers.compat_transformers.models.qwen2.modeling_qwen2 as hf_qwen2

from qbcompiler.model_dict.common import ModelDict
from qbcompiler.model_dict.common import DimValue, ActivationSpec, DataFormat
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.common.parserabc import (
    MobilintParserInputs,
    MobilintParserOutputs,
)
from qbcompiler.model_dict.parser.backend.hf.transformers.cache_utils import (
    DynamicCache,
)
from qbcompiler.model_dict.parser.backend.hf.transformers.models.qwen2.modeling_qwen2 import (
    Qwen2ForCausalLM,
)

__all__ = ["parse_qwen2_for_causal_lm"]

from qbcompiler.model_dict.parser.backend.hf.util import (
    InputsConatainerABC,
    InputCaptureCtxManager,
)

from qbcompiler.model_dict.parser.util.subgraph_builder import SubGraphBuilder


def _input_activation(builder, name, dtype, src_shape, dataformat):
    act = ActivationSpec(name, dtype=dtype, src_shape=src_shape, dataformat=dataformat)
    builder.add_activation(act)
    builder.make_input(act)
    return act


class Qwen2ForCausalLMInputsContainer(InputsConatainerABC):
    def _capture_args(self, *args, **kwargs):
        return args

    def _capture_kwargs(self, *args, **kwargs):
        dct = {}
        for k, v in kwargs.items():
            if k == "past_key_values":
                dct[k] = {
                    "_seen_tokens": v._seen_tokens,
                    "key_cache": [t.clone() for t in v.key_cache],
                    "value_cache": [t.clone() for t in v.value_cache],
                }
            elif isinstance(v, torch.Tensor):
                dct[k] = v.clone()
            else:
                dct[k] = v

        return dct


def _make_feed_dict(model, target_sg_state=0):
    from transformers import AutoTokenizer

    model_id = model.config._name_or_path
    tokenizer = AutoTokenizer.from_pretrained(model_id)
    prompt = "Who are you?"
    messages = [
        {
            "role": "system",
            "content": "You are Qwen, created by Alibaba Cloud. You are a helpful assistant.",
        },
        {"role": "user", "content": prompt},
    ]
    text = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )
    model_inputs = tokenizer([text], return_tensors="pt").to(model.device)

    inputs_container = Qwen2ForCausalLMInputsContainer()
    with InputCaptureCtxManager(
        model, max_call_limit=target_sg_state + 1, inputs_container=inputs_container
    ) as f:
        generated_ids = model.generate(
            **model_inputs, max_new_tokens=512, repetition_penalty=1.2
        )

    input_ids = inputs_container.captured_kwargs[target_sg_state]["input_ids"]
    past_key_values = inputs_container.captured_kwargs[target_sg_state][
        "past_key_values"
    ]

    feed_dict = {}
    for k, v in inputs_container.captured_kwargs[target_sg_state].items():
        feed_dict[k] = v

    return feed_dict


def parse_qwen2_for_causal_lm(
    model,
    parser_inputs: MobilintParserInputs,
    seq_len: int = 39,
    past_seq_len: int = 0,
    make_value_dict=True,
    feed_dict=None,
    slice_seq_last_n: Optional[int] = None,
    **kwargs
):
    if not feed_dict:
        feed_dict = _make_feed_dict(model)

    input_ids = feed_dict["input_ids"]
    past_key_values = feed_dict["past_key_values"]
    if past_key_values["key_cache"]:
        past_seq_len = past_key_values["key_cache"][0].shape[2]
    else:
        past_seq_len = 0

    const_dict = {}
    qwen2_builder = SubGraphBuilder(global_weight_dict=const_dict, builder_name="qwen2")
    seq_len = DimValue(input_ids.shape[-1], dynamic=True)
    input_ids = _input_activation(
        qwen2_builder, "input_ids", "int64", (1, seq_len), DataFormat.UNKNOWN
    )
    attention_mask = _input_activation(
        qwen2_builder, "attention_mask", "int64", (1, seq_len), DataFormat.UNKNOWN
    )
    position_ids = _input_activation(
        qwen2_builder, "position_ids", "int64", (1, seq_len), DataFormat.UNKNOWN
    )
    cache_position = _input_activation(
        qwen2_builder, "cache_position", "int64", (seq_len,), DataFormat.UNKNOWN
    )

    qwen2_for_causal_lm = Qwen2ForCausalLM(model)
    qwen2_for_causal_lm.set_builder(qwen2_builder, recursive=True)

    past_key_values = DynamicCache(past_seq_len=past_seq_len)

    logits = qwen2_for_causal_lm(
        input_ids=input_ids,
        attention_mask=attention_mask,
        position_ids=position_ids,
        cache_position=cache_position,
        past_key_values=past_key_values,
        slice_seq_last_n=slice_seq_last_n,
    )

    qwen2_builder.make_output(logits.logits)

    sg = qwen2_builder.build(name="Qwen2ForCausalLm")

    md = ModelDict()
    md.subgraphs = [sg]
    for idx, sg in enumerate(md.subgraphs):
        sg.idx = idx

    md.graph_order = [0]
    for iidx in sg.inputs:
        inact = sg.activations[iidx]
        md.inputs.append(inact.name)
    for oidx in sg.outputs:
        outact = sg.activations[oidx]
        md.outputs.append(outact.name)
    md.model_backend = "hf"
    md.set_main_sg(0)

    md.init_model_state = {
        sg.name: {
            "seen_tokens": past_seq_len,
            "past_key_values": {"_seen_tokens": past_seq_len},
        }
    }

    if make_value_dict:
        value_dict = {}
        value_dict["input_ids"] = feed_dict["input_ids"]
        qwen2_for_causal_lm.set_value_dict(value_dict)
        qwen2_for_causal_lm.register_forward_hook()

        fd = {}
        for k, v in feed_dict.items():
            if k == "past_key_values":
                cache_ = hf_qwen2.DynamicCache()
                cache_.key_cache = [t.clone() for t in v["key_cache"]]
                cache_.value_cache = [t.clone() for t in v["value_cache"]]
                cache_._seen_tokens = v["_seen_tokens"]
                fd[k] = cache_
            else:
                fd[k] = v

        qwen2_for_causal_lm.torch_compute(**fd)

        _value_dict = ValueDict()
        for k, v in value_dict.items():
            if isinstance(v, torch.Tensor):
                if v.dtype == torch.bfloat16:
                    v = v.to(torch.float32)
                v = v.detach().cpu().numpy()
            if isinstance(v, numpy.ndarray):
                _value_dict[k] = v
        value_dict = _value_dict
    else:
        value_dict = ValueDict()

    out = MobilintParserOutputs()
    out.model_dict = md
    out.const_dict = const_dict
    out.value_dict = value_dict

    return out
