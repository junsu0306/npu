from qbcompiler.model_dict.parser.backend.hf.util import OrderedNamespace


class BaseModelOutputWithPast(OrderedNamespace):
    def __init__(
        self,
        last_hidden_state=None,
        past_key_values=None,
        hidden_states=None,
        attentions=None,
    ):
        super().__init__()
        self.last_hidden_state = last_hidden_state
        self.past_key_values = past_key_values
        self.hidden_states = hidden_states
        self.attentions = attentions


class BaseModelOutputWithPastAndCrossAttentions(OrderedNamespace):
    def __init__(
        self,
        last_hidden_state=None,
        past_key_values=None,
        hidden_states=None,
        attentions=None,
        cross_attentions=None,
    ):
        super().__init__()
        self.last_hidden_state = last_hidden_state
        self.past_key_values = past_key_values
        self.hidden_states = hidden_states
        self.attentions = attentions
        self.cross_attentions = cross_attentions


class BaseModelOutputWithPoolingAndCrossAttentions(OrderedNamespace):
    def __init__(
        self,
        last_hidden_state=None,
        pooler_output=None,
        hidden_states=None,
        past_key_values=None,
        attentions=None,
        cross_attentions=None,
    ):
        super().__init__()
        self.last_hidden_state = last_hidden_state
        self.pooler_output = pooler_output
        self.hidden_states = hidden_states
        self.past_key_values = past_key_values
        self.attentions = attentions
        self.cross_attentions = cross_attentions


class MaskedLMOutput(OrderedNamespace):
    def __init__(self, loss=None, logits=None, hidden_states=None, attentions=None):
        super().__init__()
        self.loss = loss
        self.logits = logits
        self.hidden_states = hidden_states
        self.attentions = attentions


class CausalLMOutputWithPast(OrderedNamespace):
    def __init__(
        self,
        loss=None,
        logits=None,
        past_key_values=None,
        hidden_states=None,
        attentions=None,
    ):
        super().__init__()
        self.loss = loss
        self.logits = logits
        self.past_key_values = past_key_values
        self.hidden_states = hidden_states
        self.attentions = attentions
