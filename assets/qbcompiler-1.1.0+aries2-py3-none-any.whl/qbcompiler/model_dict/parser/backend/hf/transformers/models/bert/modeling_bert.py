import abc
from typing import Any, Type, Optional, Tuple, Union, List

import numpy
import torch
import qbcompiler.mobilint_transformers.compat_transformers.models.bert.modeling_bert as hf_transformers_bert_modeling_bert

from qbcompiler.model_dict.common import ActivationSpec, DataFormat, DimValue
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase
from qbcompiler.model_dict.parser.backend.hf.make_modules import make_dynamic_object
from qbcompiler.model_dict.parser.backend.hf.transformers.modeling_outputs import (
    BaseModelOutputWithPoolingAndCrossAttentions,
    BaseModelOutputWithPastAndCrossAttentions,
    MaskedLMOutput,
)
from qbcompiler.model_dict.parser.backend.hf.transformers.pytorch_utils import (
    apply_chunking_to_forward,
)
from qbcompiler.model_dict.parser.util.subgraph_builder import SubGraphBuilder


class ModelingBertBase(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name, make_module_func=make_dynamic_object)


class BertModel(ModelingBertBase):
    __slots__ = (
        "config",
        "embeddings",
        "attn_implementation",
        "position_embedding_type",
        "encoder",
        "pooler",
        "embeddings",
    )

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_bert_modeling_bert.BertModel

    def forward(
        self,
        input_ids: Optional[ActivationSpec] = None,
        attention_mask: Optional[ActivationSpec] = None,
        token_type_ids: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,
        inputs_embeds: Optional[ActivationSpec] = None,
        encoder_hidden_states: Optional[ActivationSpec] = None,
        encoder_attention_mask: Optional[ActivationSpec] = None,
        past_key_values: Optional[List[ActivationSpec]] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ) -> Union[Tuple[ActivationSpec], BaseModelOutputWithPoolingAndCrossAttentions]:
        # input_ids torch.Size([1, 16])
        # attention_mask torch.Size([1, 16]) [1,1,1,...]
        # token_type_ids torch.Size([1, 16]) [0,0,0,...]

        output_attentions = (
            output_attentions
            if output_attentions is not None
            else self.config.output_attentions
        )
        output_hidden_states = (
            output_hidden_states
            if output_hidden_states is not None
            else self.config.output_hidden_states
        )
        return_dict = (
            return_dict if return_dict is not None else self.config.use_return_dict
        )

        if self.config.is_decoder:
            use_cache = use_cache if use_cache is not None else self.config.use_cache
        else:
            use_cache = False

        if input_ids is not None and inputs_embeds is not None:
            raise ValueError(
                "You cannot specify both input_ids and inputs_embeds at the same time"
            )
        elif input_ids is not None:
            # self.warn_if_padding_and_no_attention_mask(input_ids, attention_mask)
            # input_shape = input_ids.size()  # (1,16)
            input_shape = input_ids.get_act_src_shape()
        elif inputs_embeds is not None:
            raise NotImplementedError
            # input_shape = inputs_embeds.size()[:-1]
        else:
            raise ValueError("You have to specify either input_ids or inputs_embeds")

        batch_size, seq_length = input_shape
        # device = input_ids.device if input_ids is not None else inputs_embeds.device

        # past_key_values_length
        past_key_values_length = (
            past_key_values[0][0].shape[2] if past_key_values is not None else 0
        )

        if token_type_ids is None:
            raise NotImplementedError
            # if hasattr(self.embeddings, "token_type_ids"):
            #     buffered_token_type_ids = self.embeddings.token_type_ids[:, :seq_length]
            #     buffered_token_type_ids_expanded = buffered_token_type_ids.expand(batch_size, seq_length)
            #     token_type_ids = buffered_token_type_ids_expanded
            # else:
            #     token_type_ids = torch.zeros(input_shape, dtype=torch.long, device=device)

        # we will skip this part
        # embedding_output = self.embeddings(
        #     input_ids=input_ids,
        #     position_ids=position_ids,
        #     token_type_ids=token_type_ids,
        #     inputs_embeds=inputs_embeds,
        #     past_key_values_length=past_key_values_length,
        # )
        # torch.Size([1, 16, 768])
        embedding_dim = self.reference_model.embeddings.word_embeddings.embedding_dim
        embedding_output = ActivationSpec(
            "embeddings",
            src_shape=(batch_size, seq_length, embedding_dim),
            dataformat=DataFormat.UNKNOWN,
            dtype="float32",
        )
        self.builder.add_activation(embedding_output)
        self.builder.make_input(embedding_output)

        if attention_mask is None:
            raise NotImplementedError
            # attention_mask = torch.ones((batch_size, seq_length + past_key_values_length), device=device)

        use_sdpa_attention_masks = (
            self.attn_implementation == "sdpa"
            and self.position_embedding_type == "absolute"
            and head_mask is None
            and not output_attentions
        )  # true

        # Expand the attention mask
        if use_sdpa_attention_masks:
            # Expand the attention mask for SDPA.
            # [bsz, seq_len] -> [bsz, 1, seq_len, seq_len]
            if self.config.is_decoder:
                raise NotImplementedError
                # extended_attention_mask = _prepare_4d_causal_attention_mask_for_sdpa(
                #     attention_mask,
                #     input_shape,
                #     embedding_output,
                #     past_key_values_length,
                # )
            else:
                # extended_attention_mask = _prepare_4d_attention_mask_for_sdpa(
                #     attention_mask, embedding_output.dtype, tgt_len=seq_length
                # )
                # attention_mask == 1 for all elements
                extended_attention_mask = None
        else:
            raise NotImplementedError
            # We can provide a self-attention mask of dimensions [batch_size, from_seq_length, to_seq_length]
            # ourselves in which case we just need to make it broadcastable to all heads.
            # extended_attention_mask = self.get_extended_attention_mask(attention_mask, input_shape)

        # If a 2D or 3D attention mask is provided for the cross-attention
        # we need to make broadcastable to [batch_size, num_heads, seq_length, seq_length]
        if self.config.is_decoder and encoder_hidden_states is not None:
            raise NotImplementedError
            # encoder_batch_size, encoder_sequence_length, _ = encoder_hidden_states.size()
            # encoder_hidden_shape = (encoder_batch_size, encoder_sequence_length)
            # if encoder_attention_mask is None:
            #     encoder_attention_mask = torch.ones(encoder_hidden_shape, device=device)
            #
            # if use_sdpa_attention_masks:
            #     # Expand the attention mask for SDPA.
            #     # [bsz, seq_len] -> [bsz, 1, seq_len, seq_len]
            #     encoder_extended_attention_mask = _prepare_4d_attention_mask_for_sdpa(
            #         encoder_attention_mask, embedding_output.dtype, tgt_len=seq_length
            #     )
            # else:
            #     encoder_extended_attention_mask = self.invert_attention_mask(encoder_attention_mask)
        else:
            encoder_extended_attention_mask = None

        # Prepare head mask if needed
        # 1.0 in head_mask indicate we keep the head
        # attention_probs has shape bsz x n_heads x N x N
        # input head_mask has shape [num_heads] or [num_hidden_layers x num_heads]
        # and head_mask is converted to shape [num_hidden_layers x batch x num_heads x seq_length x seq_length]
        # head_mask = self.get_head_mask(head_mask, self.config.num_hidden_layers)
        head_mask = [None] * self.config.num_hidden_layers

        encoder_outputs = self.encoder(
            embedding_output,
            attention_mask=extended_attention_mask,
            head_mask=head_mask,
            encoder_hidden_states=encoder_hidden_states,
            encoder_attention_mask=encoder_extended_attention_mask,
            past_key_values=past_key_values,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
        )
        sequence_output = encoder_outputs[0]  # torch.Size([1, 16, 768])
        pooled_output = (
            self.pooler(sequence_output) if self.pooler is not None else None
        )

        if not return_dict:
            return (sequence_output, pooled_output) + encoder_outputs[1:]

        return BaseModelOutputWithPoolingAndCrossAttentions(
            last_hidden_state=sequence_output,
            pooler_output=pooled_output,
            past_key_values=encoder_outputs.past_key_values,
            hidden_states=encoder_outputs.hidden_states,
            attentions=encoder_outputs.attentions,
            cross_attentions=encoder_outputs.cross_attentions,
        )


class BertPredictionHeadTransform(ModelingBertBase):
    __slots__ = ("dense", "transform_act_fn", "LayerNorm")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_bert_modeling_bert.BertPredictionHeadTransform

    def forward(self, hidden_states: ActivationSpec) -> ActivationSpec:
        hidden_states = self.dense(hidden_states)
        hidden_states = self.transform_act_fn(hidden_states)
        hidden_states = self.LayerNorm(hidden_states)
        return hidden_states


class BertLayer(ModelingBertBase):
    __slots__ = ("attention", "is_decoder", "chunk_size_feed_forward", "seq_len_dim")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_bert_modeling_bert.BertLayer

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,
        encoder_hidden_states: Optional[ActivationSpec] = None,
        encoder_attention_mask: Optional[ActivationSpec] = None,
        past_key_value: Optional[Tuple[Tuple[ActivationSpec]]] = None,
        output_attentions: Optional[bool] = False,
    ) -> Tuple[ActivationSpec]:
        # decoder uni-directional self-attention cached key/values tuple is at positions 1,2
        self_attn_past_key_value = (
            past_key_value[:2] if past_key_value is not None else None
        )
        self_attention_outputs = self.attention(
            hidden_states,
            attention_mask,
            head_mask,
            output_attentions=output_attentions,
            past_key_value=self_attn_past_key_value,
        )
        attention_output = self_attention_outputs[0]  # torch.Size([1, 16, 768])

        # if decoder, the last output is tuple of self-attn cache
        if self.is_decoder:
            raise NotImplementedError
            # outputs = self_attention_outputs[1:-1]
            # present_key_value = self_attention_outputs[-1]
        else:
            outputs = self_attention_outputs[
                1:
            ]  # add self attentions if we output attention weights
            # ()

        cross_attn_present_key_value = None
        if self.is_decoder and encoder_hidden_states is not None:
            raise NotImplementedError
            if not hasattr(self, "crossattention"):
                raise ValueError(
                    f"If `encoder_hidden_states` are passed, {self} has to be instantiated with cross-attention layers"
                    " by setting `config.add_cross_attention=True`"
                )
            #
            # # cross_attn cached key/values tuple is at positions 3,4 of past_key_value tuple
            # cross_attn_past_key_value = past_key_value[-2:] if past_key_value is not None else None
            # cross_attention_outputs = self.crossattention(
            #     attention_output,
            #     attention_mask,
            #     head_mask,
            #     encoder_hidden_states,
            #     encoder_attention_mask,
            #     cross_attn_past_key_value,
            #     output_attentions,
            # )
            # attention_output = cross_attention_outputs[0]
            # outputs = outputs + cross_attention_outputs[1:-1]  # add cross attentions if we output attention weights
            #
            # # add cross-attn cache to positions 3,4 of present_key_value tuple
            # cross_attn_present_key_value = cross_attention_outputs[-1]
            # present_key_value = present_key_value + cross_attn_present_key_value

        layer_output = apply_chunking_to_forward(
            self.feed_forward_chunk,
            self.chunk_size_feed_forward,
            self.seq_len_dim,
            attention_output,
        )  # torch.Size([1, 16, 768])
        outputs = (layer_output,) + outputs

        # if decoder, return the attn key/values as the last output
        if self.is_decoder:
            outputs = outputs + (present_key_value,)

        return outputs

    def feed_forward_chunk(self, attention_output):
        intermediate_output = self.intermediate(attention_output)
        layer_output = self.output(intermediate_output, attention_output)
        return layer_output


class BertSdpaSelfAttention(ModelingBertBase):
    __slots__ = (
        "position_embedding_type",
        "num_attention_heads",
        "attention_head_size",
        "is_decoder",
        "require_contiguous_qkv",
        "all_head_size",
    )

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_bert_modeling_bert.BertSdpaSelfAttention

    def transpose_for_scores(self, x: ActivationSpec) -> ActivationSpec:
        # new_x_shape = x.size()[:-1] + (self.num_attention_heads, self.attention_head_size)
        # x = x.view(new_x_shape)
        new_x_shape = x.get_act_src_shape()[:-1] + (
            self.num_attention_heads,
            self.attention_head_size,
        )
        x = self.builder.make_reshape(x, shape=new_x_shape)
        # return x.permute(0, 2, 1, 3)
        return self.builder.make_transpose(x, (0, 2, 1, 3))

    # Adapted from BertSelfAttention
    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,
        encoder_hidden_states: Optional[ActivationSpec] = None,
        encoder_attention_mask: Optional[ActivationSpec] = None,
        past_key_value: Optional[Tuple[Tuple[ActivationSpec]]] = None,
        output_attentions: Optional[bool] = False,
    ) -> Tuple[ActivationSpec]:
        if (
            self.position_embedding_type != "absolute"
            or output_attentions
            or head_mask is not None
        ):
            raise NotImplementedError
            # # TODO: Improve this warning with e.g. `model.config._attn_implementation = "manual"` once implemented.
            # logger.warning_once(
            #     "BertSdpaSelfAttention is used but `torch.nn.functional.scaled_dot_product_attention` does not support "
            #     "non-absolute `position_embedding_type` or `output_attentions=True` or `head_mask`. Falling back to "
            #     "the manual attention implementation, but specifying the manual implementation will be required from "
            #     "Transformers version v5.0.0 onwards. This warning can be removed using the argument "
            #     '`attn_implementation="eager"` when loading the model.'
            # )
            # return super().forward(
            #     hidden_states,
            #     attention_mask,
            #     head_mask,
            #     encoder_hidden_states,
            #     encoder_attention_mask,
            #     past_key_value,
            #     output_attentions,
            # )

        # bsz, tgt_len, _ = hidden_states.size()  # _768,bsz=1, tgt_len=16
        bsz, tgt_len, _ = hidden_states.get_act_src_shape()

        query_layer = self.transpose_for_scores(
            self.query(hidden_states)
        )  # torch.Size([1, 12, 16, 64])

        # If this is instantiated as a cross-attention module, the keys and values come from an encoder; the attention
        # mask needs to be such that the encoder's padding tokens are not attended to.
        is_cross_attention = encoder_hidden_states is not None

        current_states = (
            encoder_hidden_states if is_cross_attention else hidden_states
        )  # torch.Size([1, 16, 768])
        attention_mask = (
            encoder_attention_mask if is_cross_attention else attention_mask
        )

        # Check `seq_length` of `past_key_value` == `len(current_states)` to support prefix tuning
        if (
            is_cross_attention
            and past_key_value
            and past_key_value[0].shape[2] == current_states.shape[1]
        ):
            raise NotImplementedError
            # key_layer, value_layer = past_key_value
        else:
            key_layer = self.transpose_for_scores(
                self.key(current_states)
            )  # torch.Size([1, 12, 16, 64])
            value_layer = self.transpose_for_scores(
                self.value(current_states)
            )  # torch.Size([1, 12, 16, 64])
            if past_key_value is not None and not is_cross_attention:
                raise NotImplementedError
                # key_layer = torch.cat([past_key_value[0], key_layer], dim=2)
                # value_layer = torch.cat([past_key_value[1], value_layer], dim=2)

        if self.is_decoder:
            # if cross_attention save Tuple(torch.Tensor, torch.Tensor) of all cross attention key/value_states.
            # Further calls to cross_attention layer can then reuse all cross-attention
            # key/value_states (first "if" case)
            # if uni-directional self-attention (decoder) save Tuple(torch.Tensor, torch.Tensor) of
            # all previous decoder key/value_states. Further calls to uni-directional self-attention
            # can concat previous decoder key/value_states to current projected key/value_states (third "elif" case)
            # if encoder bi-directional self-attention `past_key_value` is always `None`
            past_key_value = (key_layer, value_layer)

        # SDPA with memory-efficient backend is broken in torch==2.1.2 when using non-contiguous inputs and a custom
        # attn_mask, so we need to call `.contiguous()` here. This was fixed in torch==2.2.0.
        # Reference: https://github.com/pytorch/pytorch/issues/112577
        # if self.require_contiguous_qkv and query_layer.device.type == "cuda" and attention_mask is not None:
        #     query_layer = query_layer.contiguous()
        #     key_layer = key_layer.contiguous()
        #     value_layer = value_layer.contiguous()

        # We dispatch to SDPA's Flash Attention or Efficient kernels via this `is_causal` if statement instead of an inline conditional assignment
        # in SDPA to support both torch.compile's dynamic shapes and full graph options. An inline conditional prevents dynamic shapes from compiling.
        # The tgt_len > 1 is necessary to match with AttentionMaskConverter.to_causal_4d that does not create
        # a causal mask in case tgt_len == 1.
        is_causal = (
            True
            if self.is_decoder
            and not is_cross_attention
            and attention_mask is None
            and tgt_len > 1
            else False
        )

        # attn_output = torch.nn.functional.scaled_dot_product_attention(
        #     query_layer,
        #     key_layer,
        #     value_layer,
        #     attn_mask=attention_mask,
        #     dropout_p=self.dropout_prob if self.training else 0.0,
        #     is_causal=is_causal,
        # )  # torch.Size([1, 12, 16, 64])
        # attn_output = attn_output.transpose(1, 2)
        # attn_output = attn_output.reshape(bsz, tgt_len, self.all_head_size)  # torch.Size([1, 16, 768])
        attn_output = self.builder.make_torch_scaled_dot_product_attention(
            query_layer,
            key_layer,
            value_layer,
            attn_mask=attention_mask,
            is_causal=is_causal,
            opname=self.module_name,
        )
        attn_output = self.builder.make_transpose(attn_output, (0, 2, 1, 3))
        attn_output = self.builder.make_reshape(
            attn_output, (bsz, tgt_len, self.all_head_size)
        )

        outputs = (attn_output,)
        if self.is_decoder:
            outputs = outputs + (past_key_value,)
        return outputs


class BertSelfOutput(ModelingBertBase):
    __slots__ = (
        "dense",
        "dropout",
        "LayerNorm",
    )

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_bert_modeling_bert.BertSelfOutput

    def forward(
        self, hidden_states: ActivationSpec, input_tensor: ActivationSpec
    ) -> ActivationSpec:
        hidden_states = self.dense(hidden_states)
        hidden_states = self.dropout(hidden_states)
        hidden_states = self.LayerNorm(
            self.builder.make_add(hidden_states, input_tensor)
        )
        return hidden_states


class BertIntermediate(ModelingBertBase):
    __slots__ = ("dense", "intermediate_act_fn")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_bert_modeling_bert.BertIntermediate

    def forward(self, hidden_states: ActivationSpec) -> ActivationSpec:
        hidden_states = self.dense(hidden_states)
        hidden_states = self.intermediate_act_fn(hidden_states)
        return hidden_states


class BertOutput(ModelingBertBase):
    __slots__ = (
        "dense",
        "dropout",
        "LayerNorm",
    )

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_bert_modeling_bert.BertOutput

    def forward(
        self, hidden_states: ActivationSpec, input_tensor: ActivationSpec
    ) -> ActivationSpec:
        hidden_states = self.dense(hidden_states)
        hidden_states = self.dropout(hidden_states)
        # hidden_states = self.LayerNorm(hidden_states + input_tensor)
        hidden_states = self.LayerNorm(
            self.builder.make_add(hidden_states, input_tensor)
        )
        return hidden_states


class BertAttention(ModelingBertBase):
    __slots__ = ("self", "output")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_bert_modeling_bert.BertAttention

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,
        encoder_hidden_states: Optional[ActivationSpec] = None,
        encoder_attention_mask: Optional[ActivationSpec] = None,
        past_key_value: Optional[Tuple[Tuple[ActivationSpec]]] = None,
        output_attentions: Optional[bool] = False,
    ) -> Tuple[ActivationSpec]:
        self_outputs = self.self(
            hidden_states,
            attention_mask,
            head_mask,
            encoder_hidden_states,
            encoder_attention_mask,
            past_key_value,
            output_attentions,
        )  # (torch.Size([1, 16, 768]), )
        attention_output = self.output(self_outputs[0], hidden_states)  # [1, 16, 768])
        outputs = (attention_output,) + self_outputs[
            1:
        ]  # add attentions if we output them
        return outputs


class BertLMPredictionHead(ModelingBertBase):
    __slots__ = ("decoder", "transform")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_bert_modeling_bert.BertLMPredictionHead

    def _tie_weights(self):
        self.decoder.bias = self.bias

    def forward(self, hidden_states):
        hidden_states = self.transform(hidden_states)
        hidden_states = self.decoder(hidden_states)
        return hidden_states


class BertOnlyMLMHead(ModelingBertBase):
    @property
    def target_module_type(self) -> Type:
        return hf_transformers_bert_modeling_bert.BertOnlyMLMHead

    def forward(self, sequence_output: ActivationSpec) -> ActivationSpec:
        prediction_scores = self.predictions(sequence_output)
        return prediction_scores


class BertEmbeddings(ModelingBertBase):
    @property
    def target_module_type(self) -> Type:
        return hf_transformers_bert_modeling_bert.BertEmbeddings

    def forward(
        self,
        input_ids: Optional[ActivationSpec] = None,
        token_type_ids: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        inputs_embeds: Optional[ActivationSpec] = None,
        past_key_values_length: int = 0,
    ) -> ActivationSpec:
        if input_ids is not None:
            # input_shape = input_ids.size()
            input_shape = input_ids.get_act_src_shape()
        else:
            # input_shape = inputs_embeds.size()[:-1]
            input_shape = inputs_embeds.get_act_src_shape()[:-1]

        seq_length = input_shape[1]

        if position_ids is None:
            position_ids = self.position_ids[
                :, past_key_values_length : seq_length + past_key_values_length
            ]

        # Setting the token_type_ids to the registered buffer in constructor where it is all zeros, which usually occurs
        # when its auto-generated, registered buffer helps users when tracing the model without passing token_type_ids, solves
        # issue #5664
        if token_type_ids is None:
            if hasattr(self, "token_type_ids"):
                buffered_token_type_ids = self.token_type_ids[:, :seq_length]
                buffered_token_type_ids_expanded = buffered_token_type_ids.expand(
                    input_shape[0], seq_length
                )
                token_type_ids = buffered_token_type_ids_expanded
            else:
                # token_type_ids = torch.zeros(input_shape, dtype=torch.long, device=self.position_ids.device)
                ...

        if inputs_embeds is None:
            inputs_embeds = self.word_embeddings(input_ids)
        token_type_embeddings = self.token_type_embeddings(token_type_ids)

        embeddings = inputs_embeds + token_type_embeddings
        if self.position_embedding_type == "absolute":
            position_embeddings = self.position_embeddings(position_ids)
            embeddings += position_embeddings
        embeddings = self.LayerNorm(embeddings)
        embeddings = self.dropout(embeddings)
        return embeddings


class BertEncoder(ModelingBertBase):
    __slots__ = ("gradient_checkpointing", "training", "config", "layer")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_bert_modeling_bert.BertEncoder

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,
        encoder_hidden_states: Optional[ActivationSpec] = None,
        encoder_attention_mask: Optional[ActivationSpec] = None,
        past_key_values: Optional[Tuple[Tuple[ActivationSpec]]] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = False,
        output_hidden_states: Optional[bool] = False,
        return_dict: Optional[bool] = True,
    ) -> Union[Tuple[ActivationSpec], "BaseModelOutputWithPastAndCrossAttentions"]:
        all_hidden_states = () if output_hidden_states else None
        all_self_attentions = () if output_attentions else None
        all_cross_attentions = (
            () if output_attentions and self.config.add_cross_attention else None
        )

        if self.gradient_checkpointing and self.training:
            raise NotImplementedError
            # if use_cache:
            #     logger.warning_once(
            #         "`use_cache=True` is incompatible with gradient checkpointing. Setting `use_cache=False`..."
            #     )
            #     use_cache = False

        next_decoder_cache = () if use_cache else None
        for i, layer_module in enumerate(self.layer):
            if output_hidden_states:
                all_hidden_states = all_hidden_states + (hidden_states,)

            layer_head_mask = head_mask[i] if head_mask is not None else None
            past_key_value = past_key_values[i] if past_key_values is not None else None

            if self.gradient_checkpointing and self.training:
                raise NotImplementedError
                # layer_outputs = self._gradient_checkpointing_func(
                #     layer_module.__call__,
                #     hidden_states,
                #     attention_mask,
                #     layer_head_mask,
                #     encoder_hidden_states,
                #     encoder_attention_mask,
                #     past_key_value,
                #     output_attentions,
                # )
            else:
                layer_outputs = layer_module(
                    hidden_states,
                    attention_mask,
                    layer_head_mask,
                    encoder_hidden_states,
                    encoder_attention_mask,
                    past_key_value,
                    output_attentions,
                )  # (torch.Size([1, 16, 768]), )

            hidden_states = layer_outputs[0]
            if use_cache:
                next_decoder_cache += (layer_outputs[-1],)
            if output_attentions:
                all_self_attentions = all_self_attentions + (layer_outputs[1],)
                if self.config.add_cross_attention:
                    all_cross_attentions = all_cross_attentions + (layer_outputs[2],)

        if output_hidden_states:
            all_hidden_states = all_hidden_states + (hidden_states,)

        if not return_dict:
            return tuple(
                v
                for v in [
                    hidden_states,
                    next_decoder_cache,
                    all_hidden_states,
                    all_self_attentions,
                    all_cross_attentions,
                ]
                if v is not None
            )
        return BaseModelOutputWithPastAndCrossAttentions(
            last_hidden_state=hidden_states,
            past_key_values=next_decoder_cache,
            hidden_states=all_hidden_states,
            attentions=all_self_attentions,
            cross_attentions=all_cross_attentions,
        )


class BertForMaskedLM(ModelingBertBase):
    __slots__ = ("config", "bert", "cls")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_bert_modeling_bert.BertForMaskedLM

    def forward(
        self,
        input_ids: Optional[ActivationSpec] = None,
        attention_mask: Optional[ActivationSpec] = None,
        token_type_ids: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,
        inputs_embeds: Optional[ActivationSpec] = None,
        encoder_hidden_states: Optional[ActivationSpec] = None,
        encoder_attention_mask: Optional[ActivationSpec] = None,
        labels: Optional[ActivationSpec] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ) -> Union[Tuple[ActivationSpec], "MaskedLMOutput"]:
        return_dict = (
            return_dict if return_dict is not None else self.config.use_return_dict
        )

        outputs = self.bert(
            input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            encoder_hidden_states=encoder_hidden_states,
            encoder_attention_mask=encoder_attention_mask,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
        )

        sequence_output = outputs[0]
        prediction_scores = self.cls(sequence_output)

        masked_lm_loss = None
        if labels is not None:
            raise NotImplementedError
            # loss_fct = CrossEntropyLoss()  # -100 index = padding token
            # masked_lm_loss = loss_fct(prediction_scores.view(-1, self.config.vocab_size), labels.view(-1))

        if not return_dict:
            output = (prediction_scores,) + outputs[2:]
            return (
                ((masked_lm_loss,) + output) if masked_lm_loss is not None else output
            )

        return MaskedLMOutput(
            loss=masked_lm_loss,
            logits=prediction_scores,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )

    def get_inputs(self, **kwargs):
        # feed_dict = {"input_ids": input_ids,
        #              "token_type_ids": token_type_ids,
        #              "attention_mask": attention_mask,
        #              "output_hidden_states": output_hidden_states}
        inputs = {}
        if "input_ids" in kwargs:
            input_ids = kwargs["input_ids"]
            if len(input_ids.shape) != 2:
                raise ValueError()
            inputs["input_ids"] = ActivationSpec(
                name="input_ids",
                src_shape=(1, DimValue(input_ids.shape[-1], dynamic=True)),
                dtype=str(input_ids.dtype).split(".")[1],
                dataformat=DataFormat.UNKNOWN,
            )
        if "attention_mask" in kwargs:
            attention_mask = kwargs["attention_mask"]
            inputs["attention_mask"] = ActivationSpec(
                name="attention_mask",
                dtype=str(attention_mask.dtype).split(".")[1],
                src_shape=(1, DimValue(attention_mask.shape[-1], dynamic=True)),
                dataformat=DataFormat.UNKNOWN,
            )
        if "token_type_ids" in kwargs:
            token_type_ids = kwargs["token_type_ids"]
            inputs["token_type_ids"] = ActivationSpec(
                name="token_type_ids",
                dtype=str(token_type_ids.dtype).split(".")[1],
                src_shape=(1, DimValue(token_type_ids.shape[-1], dynamic=True)),
                dataformat=DataFormat.UNKNOWN,
            )

        inputs["output_hidden_states"] = kwargs.get("output_hidden_states", False)
        return inputs

    def parse(self, make_value_dict=True, feed_dict=None, **kwargs):
        self.const_dict = {}
        self.value_dict = {}

        inputs = self.get_inputs(**feed_dict)
        self.bert_builder = SubGraphBuilder(
            global_weight_dict=self.const_dict, builder_name="bert"
        )
        self.set_builder(self.bert_builder, recursive=True)

        out = self.forward(**inputs)
        target_output_hidden_state = kwargs.get("target_output_hidden_states", None)
        if target_output_hidden_state:
            if isinstance(target_output_hidden_state, int):
                target_output_hidden_state = [target_output_hidden_state]
            for idx in target_output_hidden_state:
                self.builder.make_output(out["hidden_states"][idx])

        if make_value_dict:
            self.set_value_dict(self.value_dict)
            self.register_forward_hook()

            fd = {}
            for k, v in feed_dict.items():
                if isinstance(v, torch.Tensor):
                    fd[k] = v.to(self.reference_model.device)
                else:
                    fd[k] = v

            self.torch_compute(**fd)

            _value_dict = ValueDict()
            for k, v in self.value_dict.items():
                if isinstance(v, torch.Tensor):
                    if v.dtype == torch.bfloat16:
                        v = v.to(torch.float32)
                    v = v.detach().cpu().numpy()
                if isinstance(v, numpy.ndarray):
                    _value_dict[k] = v
            self.value_dict = _value_dict

        sg_bert = self.builder.build()
        return sg_bert, self.const_dict, self.value_dict
