from typing import Callable

from qbcompiler.model_dict.common import ActivationSpec


def apply_chunking_to_forward(
    forward_fn: Callable[..., ActivationSpec],
    chunk_size: int,
    chunk_dim: int,
    *input_tensors
) -> ActivationSpec:
    if chunk_size > 0:
        raise NotImplementedError
        # tensor_shape = input_tensors[0].shape[chunk_dim]
        # for input_tensor in input_tensors:
        #     if input_tensor.shape[chunk_dim] != tensor_shape:
        #         raise ValueError(
        #             f"All input tenors have to be of the same shape: {tensor_shape}, "
        #             f"found shape {input_tensor.shape[chunk_dim]}"
        #         )
        #
        # if input_tensors[0].shape[chunk_dim] % chunk_size != 0:
        #     raise ValueError(
        #         f"The dimension to be chunked {input_tensors[0].shape[chunk_dim]} has to be a multiple of the chunk "
        #         f"size {chunk_size}"
        #     )
        #
        # num_chunks = input_tensors[0].shape[chunk_dim] // chunk_size
        #
        # # chunk input tensor into tuples
        # input_tensors_chunks = tuple(input_tensor.chunk(num_chunks, dim=chunk_dim) for input_tensor in input_tensors)
        # # apply forward fn to every tuple
        # output_chunks = tuple(forward_fn(*input_tensors_chunk) for input_tensors_chunk in zip(*input_tensors_chunks))
        # # concatenate output at same dimension
        # return torch.cat(output_chunks, dim=chunk_dim)

    return forward_fn(*input_tensors)
