import abc
from typing import Any, Type, Optional

import numpy
import qbcompiler.mobilint_transformers.compat_transformers.models.clip.modeling_clip as hf_transformers_clip_modeling_clip

from qbcompiler.model_dict.common import ActivationSpec, DataFormat
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase
from qbcompiler.model_dict.parser.backend.hf.make_modules import make_dynamic_object
from qbcompiler.model_dict.parser.backend.hf.util import OrderedNamespace


class ModelingClipBase(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(self, model: Any, module_name: str = ""):
        # super().__init__(model, module_name, make_transformer_sd3_module)
        super().__init__(model, module_name, make_module_func=make_dynamic_object)


class CLIPTextEmbeddings(ModelingClipBase):
    __slots__ = ("position_ids", "token_embedding", "position_embedding")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_clip_modeling_clip.CLIPTextEmbeddings

    def forward(
        self,
        input_ids: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        inputs_embeds: Optional[ActivationSpec] = None,
    ) -> ActivationSpec:
        # seq_length = input_ids.shape[-1] if input_ids is not None else inputs_embeds.shape[-2]
        if input_ids is not None:
            seq_length = int(input_ids.get_act_src_shape()[-1])
        else:
            raise NotImplementedError

        if position_ids is None:
            position_ids = self.position_ids[:, :seq_length]
            # position_ids = input_ids.copy(
            #     name="position_ids", src_shape=tuple(position_ids.shape)
            # )
            n, x = position_ids.shape
            position_ids = position_ids.reshape(n, 1, 1, x)
            position_ids = self.builder.make_inputconst(
                position_ids, opname="position_ids"
            )
            position_ids = self.builder.make_reshape(
                position_ids, shape=(n, x), new_dataformat=DataFormat.NX
            )
            # self.builder.add_activation(position_ids)
            # self.builder.make_input(position_ids)

        if inputs_embeds is None:
            inputs_embeds = self.token_embedding(input_ids)
            self.builder.set_output_value_reference(inputs_embeds)

        position_embeddings = self.position_embedding(position_ids)
        self.builder.set_output_value_reference(position_embeddings)
        # embeddings = inputs_embeds + position_embeddings
        embeddings = self.builder.make_add(inputs_embeds, position_embeddings)

        return embeddings


class CLIPSdpaAttention(ModelingClipBase):
    __slots__ = ("q_proj", "k_proj", "v_proj", "num_heads", "head_dim", "scale")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_clip_modeling_clip.CLIPSdpaAttention

    def qkv_reshape_transpose(
        self, states: ActivationSpec, new_shape, transpose_axes=(0, 2, 1, 3)
    ):
        states = self.builder.make_reshape(
            states,
            shape=new_shape,
            new_dataformat=DataFormat.NHWC,
        )
        return self.builder.make_transpose(
            states, transpose_axes=transpose_axes, opname=states.name + "/transpose"
        )

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        causal_attention_mask: Optional[ActivationSpec] = None,
        output_attentions: Optional[bool] = False,
    ):
        if output_attentions:
            raise NotImplementedError
            # TODO: Improve this warning with e.g. `model.config.attn_implementation = "manual"` once this is implemented.
            # logger.warning_once(
            #     "CLIPModel is using CLIPSdpaAttention, but `torch.nn.functional.scaled_dot_product_attention` does not "
            #     "support `output_attentions=True`. Falling back to the manual attention implementation, but specifying "
            #     "the manual implementation will be required from Transformers version v5.0.0 onwards. This warning can "
            #     'be removed using the argument `attn_implementation="eager"` when loading the model.'
            # )
            # return super().forward(
            #     hidden_states=hidden_states,
            #     attention_mask=attention_mask,
            #     causal_attention_mask=causal_attention_mask,
            #     output_attentions=output_attentions,
            # )

        # CLIP text model uses both `causal_attention_mask` and `attention_mask`
        if attention_mask is not None and causal_attention_mask is not None:
            raise NotImplementedError
            # attn_mask = attention_mask + causal_attention_mask
        elif causal_attention_mask is not None:
            attn_mask = causal_attention_mask  # torch.Size([1, 1, 77, 77])
        else:
            attn_mask = attention_mask

        # bsz, tgt_len, embed_dim = hidden_states.size() # bsz=1, embed_dim=768, tgt_len=77
        bsz, tgt_len, embed_dim = hidden_states.get_act_src_shape()

        query_states = self.q_proj(hidden_states)  # torch.Size([1, 77, 768])
        self.builder.set_output_value_reference(
            query_states, output_value_reference=self.q_proj.module_name
        )
        key_states = self.k_proj(hidden_states)  # torch.Size([1, 77, 768])
        self.builder.set_output_value_reference(
            key_states, output_value_reference=self.k_proj.module_name
        )
        value_states = self.v_proj(hidden_states)  # torch.Size([1, 77, 768])
        self.builder.set_output_value_reference(
            value_states, output_value_reference=self.v_proj.module_name
        )

        # query_states = query_states.view(
        #     bsz, -1, self.num_heads, self.head_dim
        # ).transpose(1, 2) # torch.Size([1, 12, 77, 64])
        # key_states = key_states.view(bsz, -1, self.num_heads, self.head_dim).transpose(
        #     1, 2
        # )  # torch.Size([1, 12, 77, 64])
        # value_states = value_states.view(
        #     bsz, -1, self.num_heads, self.head_dim
        # ).transpose(1, 2)  # torch.Size([1, 12, 77, 64])
        query_states = self.qkv_reshape_transpose(
            query_states, new_shape=(bsz, -1, self.num_heads, self.head_dim)
        )
        key_states = self.qkv_reshape_transpose(
            key_states, new_shape=(bsz, -1, self.num_heads, self.head_dim)
        )
        value_states = self.qkv_reshape_transpose(
            value_states, new_shape=(bsz, -1, self.num_heads, self.head_dim)
        )

        # CLIP text model uses both `causal_attention_mask` and `attention_mask` sequentially.
        # attn_output = torch.nn.functional.scaled_dot_product_attention(
        #     query_states,
        #     key_states,
        #     value_states,
        #     attn_mask=attn_mask,
        #     dropout_p=self.dropout if self.training else 0.0,
        #     scale=self.scale,
        # )  # torch.Size([1, 12, 77, 64])
        attn_output = self.builder.make_torch_scaled_dot_product_attention(
            query_states,
            key_states,
            value_states,
            attn_mask=attn_mask,
            past_seq_len=0,
            is_causal=False,
            opname=self.module_name,
        )

        # attn_output = attn_output.transpose(1, 2)  # torch.Size([1, 77, 12, 64])
        # attn_output = attn_output.reshape(
        #     bsz, tgt_len, embed_dim
        # )  # torch.Size([1, 77, 768])
        attn_output = self.builder.make_transpose(attn_output, (0, 2, 1, 3))
        _, q_len, w, c = attn_output.get_act_src_shape()
        attn_output = self.builder.make_reshape(
            attn_output, (bsz, q_len, w * c), new_dataformat=DataFormat.NXC
        )

        attn_output = self.out_proj(attn_output)  # torch.Size([1, 77, 768])
        self.builder.set_output_value_reference(
            attn_output, output_value_reference=self.out_proj.module_name
        )

        return attn_output, None


class CLIPMLP(ModelingClipBase):
    __slots__ = ("fc1", "activation_fn", "fc2")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_clip_modeling_clip.CLIPMLP

    def forward(self, hidden_states: ActivationSpec) -> ActivationSpec:
        hidden_states = self.fc1(hidden_states)
        self.builder.set_output_value_reference(hidden_states, self.fc1.module_name)
        hidden_states = self.activation_fn(hidden_states)
        self.builder.set_output_value_reference(
            hidden_states, self.activation_fn.module_name
        )
        hidden_states = self.fc2(hidden_states)
        self.builder.set_output_value_reference(hidden_states, self.fc2.module_name)
        return hidden_states


class CLIPEncoderLayer(ModelingClipBase):
    __slots__ = ("layer_norm1", "layer_norm2", "mlp")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_clip_modeling_clip.CLIPEncoderLayer

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: ActivationSpec,
        causal_attention_mask: ActivationSpec,
        output_attentions: Optional[bool] = False,
    ):
        """
        Args:
            hidden_states (`torch.FloatTensor`): input to the layer of shape `(batch, seq_len, embed_dim)`
            attention_mask (`torch.FloatTensor`): attention mask of size
                `(batch, 1, tgt_len, src_len)` where padding elements are indicated by very large negative values.
                `(config.encoder_attention_heads,)`.
            output_attentions (`bool`, *optional*):
                Whether or not to return the attentions tensors of all attention layers. See `attentions` under
                returned tensors for more detail.
        """
        residual = hidden_states  # torch.Size([1, 77, 768])

        hidden_states = self.layer_norm1(hidden_states)
        self.builder.set_output_value_reference(hidden_states)
        hidden_states, attn_weights = self.self_attn(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            causal_attention_mask=causal_attention_mask,
            output_attentions=output_attentions,
        )
        # hidden_states = residual + hidden_states  # torch.Size([1, 77, 768])
        hidden_states = self.builder.make_add(
            residual, hidden_states, opname=self.module_name + ".add0"
        )

        residual = hidden_states
        hidden_states = self.layer_norm2(hidden_states)  # torch.Size([1, 77, 768])
        self.builder.set_output_value_reference(
            hidden_states, self.layer_norm2.module_name
        )
        hidden_states = self.mlp(hidden_states)  # torch.Size([1, 77, 768])
        self.builder.set_output_value_reference(hidden_states, self.mlp.module_name)
        # hidden_states = residual + hidden_states
        hidden_states = self.builder.make_add(
            residual, hidden_states, opname=self.module_name + ".add1"
        )

        outputs = (hidden_states,)

        if output_attentions:
            raise NotImplementedError
            # outputs += (attn_weights,)

        return outputs


class CLIPEncoder(ModelingClipBase):
    __slots__ = ("config",)

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_clip_modeling_clip.CLIPEncoder

    def forward(
        self,
        inputs_embeds,
        attention_mask: Optional[ActivationSpec] = None,
        causal_attention_mask: Optional[ActivationSpec] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ):
        r"""
        Args:
            inputs_embeds (`torch.FloatTensor` of shape `(batch_size, sequence_length, hidden_size)`):
                Optionally, instead of passing `input_ids` you can choose to directly pass an embedded representation.
                This is useful if you want more control over how to convert `input_ids` indices into associated vectors
                than the model's internal embedding lookup matrix.
            attention_mask (`torch.Tensor` of shape `(batch_size, sequence_length)`, *optional*):
                Mask to avoid performing attention on padding token indices. Mask values selected in `[0, 1]`:

                - 1 for tokens that are **not masked**,
                - 0 for tokens that are **masked**.

                [What are attention masks?](../glossary#attention-mask)
            causal_attention_mask (`torch.Tensor` of shape `(batch_size, sequence_length)`, *optional*):
                Causal mask for the text model. Mask values selected in `[0, 1]`:

                - 1 for tokens that are **not masked**,
                - 0 for tokens that are **masked**.

                [What are attention masks?](../glossary#attention-mask)
            output_attentions (`bool`, *optional*):
                Whether or not to return the attentions tensors of all attention layers. See `attentions` under
                returned tensors for more detail.
            output_hidden_states (`bool`, *optional*):
                Whether or not to return the hidden states of all layers. See `hidden_states` under returned tensors
                for more detail.
            return_dict (`bool`, *optional*):
                Whether or not to return a [`~utils.ModelOutput`] instead of a plain tuple.
        """
        output_attentions = (
            output_attentions
            if output_attentions is not None
            else self.config.output_attentions
        )
        output_hidden_states = (
            output_hidden_states
            if output_hidden_states is not None
            else self.config.output_hidden_states
        )
        return_dict = (
            return_dict if return_dict is not None else self.config.use_return_dict
        )

        encoder_states = () if output_hidden_states else None
        all_attentions = () if output_attentions else None

        hidden_states = inputs_embeds  # torch.Size([1, 77, 768])
        for idx, encoder_layer in enumerate(self.layers):
            if output_hidden_states:  # True
                encoder_states = encoder_states + (
                    hidden_states,
                )  # tuple( # torch.Size([1, 77, 768]))
            # if self.gradient_checkpointing and self.training:
            #     layer_outputs = self._gradient_checkpointing_func(
            #         encoder_layer.__call__,
            #         hidden_states,
            #         attention_mask,
            #         causal_attention_mask,
            #         output_attentions,
            #     )
            # else:
            #     layer_outputs = encoder_layer(
            #         hidden_states,
            #         attention_mask,
            #         causal_attention_mask,
            #         output_attentions=output_attentions,
            #     )
            layer_outputs = encoder_layer(
                hidden_states,
                attention_mask,
                causal_attention_mask,
                output_attentions=output_attentions,
            )

            hidden_states = layer_outputs[0]  # torch.Size([1, 77, 768])

            if output_attentions:
                raise NotImplementedError
                # all_attentions = all_attentions + (layer_outputs[1],)

        if output_hidden_states:
            encoder_states = encoder_states + (hidden_states,)

        if not return_dict:
            raise NotImplementedError
            # return tuple(v for v in [hidden_states, encoder_states, all_attentions] if v is not None)

        # return BaseModelOutput(
        #     last_hidden_state=hidden_states, hidden_states=encoder_states, attentions=all_attentions
        # )
        ns = OrderedNamespace()
        ns.last_hidden_state = hidden_states
        ns.hidden_states = encoder_states
        ns.attentions = all_attentions
        return ns


class CLIPTextTransformer(ModelingClipBase):
    __slots__ = ("config", "eos_token_id", "encoder", "embeddings")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_clip_modeling_clip.CLIPTextTransformer

    def forward(
        self,
        input_ids: Optional[ActivationSpec] = None,
        attention_mask: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ):
        output_attentions = (
            output_attentions
            if output_attentions is not None
            else self.config.output_attentions
        )
        output_hidden_states = (
            output_hidden_states
            if output_hidden_states is not None
            else self.config.output_hidden_states
        )
        return_dict = (
            return_dict if return_dict is not None else self.config.use_return_dict
        )

        if input_ids is None:
            raise ValueError("You have to specify input_ids")

        # input_shape = input_ids.shape # (1,77)
        # input_ids = input_ids.view(-1, input_shape[-1]) # torch.Size([1, 77])
        input_shape = input_ids.get_act_src_shape()

        hidden_states = self.embeddings(
            input_ids=input_ids, position_ids=position_ids
        )  # torch.Size([1, 77, 768])
        self.builder.set_output_value_reference(
            hidden_states, output_value_reference=self.embeddings.module_name
        )

        # # CLIP's text model uses causal mask, prepare it here.
        # # https://github.com/openai/CLIP/blob/cfcffb90e69f37bf2ff1e988237a0fbe41f33c04/clip/model.py#L324
        # causal_attention_mask = _create_4d_causal_attention_mask(
        #     input_shape, hidden_states.dtype, device=hidden_states.device
        # ) # torch.Size([1, 1, 77, 77])
        causal_attention_mask = ActivationSpec(
            name="causal_attention_mask",
            src_shape=(input_shape[0], 1, input_shape[-1], input_shape[-1]),
            dtype="float32",
        )

        # # expand attention_mask
        # if attention_mask is not None and not self._use_flash_attention_2:
        #     # [bsz, seq_len] -> [bsz, 1, tgt_seq_len, src_seq_len]
        #     attention_mask = _prepare_4d_attention_mask(
        #         attention_mask, hidden_states.dtype
        #     )
        #
        encoder_outputs = self.encoder(
            inputs_embeds=hidden_states,
            attention_mask=attention_mask,
            causal_attention_mask=causal_attention_mask,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
        )

        # last_hidden_state = encoder_outputs[0]  # torch.Size([1, 77, 768])
        last_hidden_state = encoder_outputs[0]
        last_hidden_state = self.final_layer_norm(
            last_hidden_state
        )  # torch.Size([1, 77, 768])
        self.builder.set_output_value_reference(
            last_hidden_state, self.final_layer_norm.module_name
        )

        if self.eos_token_id == 2:
            # The `eos_token_id` was incorrect before PR #24773: Let's keep what have been done here.
            # A CLIP model with such `eos_token_id` in the config can't work correctly with extra new tokens added
            # ------------------------------------------------------------
            # text_embeds.shape = [batch_size, sequence_length, transformer.width]
            # take features from the eot embedding (eot_token is the highest number in each sequence)
            # casting to torch.int for onnx compatibility: argmax doesn't support int64 inputs with opset 14
            # pooled_output = last_hidden_state[
            #     torch.arange(
            #         last_hidden_state.shape[0], device=last_hidden_state.device
            #     ),
            #     input_ids.to(dtype=torch.int, device=last_hidden_state.device).argmax(
            #         dim=-1
            #     ),
            # ] #torch.Size([1, 768])

            # We can do the above slicing operations as in the following:
            # indices = input_ids.argmax(dim=-1, keepdims=True)  # Shape: (1,1)
            # indices_expanded = indices.unsqueeze(-1).expand(-1, -1, last_hidden_state.size(-1))  # Shape: (1, 1, 768)
            # pooled_output = torch.gather(last_hidden_state, dim=1, index=indices_expanded).squeeze(1)  # Shape: (1, 768)

            indices = self.builder.make_argmax(input_ids, axis=-1, keepdims=True)
            expand_shape = numpy.array(
                [1, 1, int(last_hidden_state.get_act_src_shape()[-1])]
            )
            indices_expanded = self.builder.make_unsqueeze(indices, axis=-1)
            indices_expanded = self.builder.make_expand(
                indices_expanded, constant=expand_shape
            )
            pooled_output = self.builder.make_gather(
                last_hidden_state, indices_expanded, axis=1
            )
            pooled_output = self.builder.make_squeeze(pooled_output, squeeze_axes=(1,))

        else:
            raise NotImplementedError
            # The config gets updated `eos_token_id` from PR #24773 (so the use of exta new tokens is possible)
            # pooled_output = last_hidden_state[
            #     torch.arange(
            #         last_hidden_state.shape[0], device=last_hidden_state.device
            #     ),
            #     # We need to get the first position of `eos_token_id` value (`pad_token_ids` might equal to `eos_token_id`)
            #     # Note: we assume each sequence (along batch dim.) contains an  `eos_token_id` (e.g. prepared by the tokenizer)
            #     (
            #         input_ids.to(dtype=torch.int, device=last_hidden_state.device)
            #         == self.eos_token_id
            #     )
            #     .int()
            #     .argmax(dim=-1),
            # ]

        if not return_dict:
            raise NotImplementedError
            # return (last_hidden_state, pooled_output) + encoder_outputs[1:]

        # return BaseModelOutputWithPooling(
        #     last_hidden_state=last_hidden_state,
        #     pooler_output=pooled_output,
        #     hidden_states=encoder_outputs.hidden_states,
        #     attentions=encoder_outputs.attentions,
        # )

        ns = OrderedNamespace()
        ns.last_hidden_state = last_hidden_state
        ns.pooler_output = pooled_output
        ns.hidden_states = encoder_outputs.hidden_states
        ns.attentions = encoder_outputs.attentions
        return ns


class CLIPTextModelWithProjection(ModelingClipBase):
    __slots__ = ("text_model", "text_projection", "config")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_clip_modeling_clip.CLIPTextModelWithProjection

    def forward(
        self,
        input_ids: Optional[ActivationSpec] = None,
        attention_mask: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ):
        return_dict = (
            return_dict if return_dict is not None else self.config.use_return_dict
        )

        text_outputs = self.text_model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
        )  # BaseModelOutputWithPooling(
        #     last_hidden_state=last_hidden_state,
        #     pooler_output=pooled_output,
        #     hidden_states=encoder_outputs.hidden_states,
        #     attentions=encoder_outputs.attentions,
        # )

        pooled_output = text_outputs[1]  # torch.Size([1, 768])

        text_embeds = self.text_projection(pooled_output)  # torch.Size([1, 768])

        if not return_dict:
            raise NotImplementedError
            # outputs = (text_embeds, text_outputs[0]) + text_outputs[2:]
            # return tuple(output for output in outputs if output is not None)

        # return CLIPTextModelOutput(
        #     text_embeds=text_embeds,
        #     last_hidden_state=text_outputs.last_hidden_state,
        #     hidden_states=text_outputs.hidden_states,
        #     attentions=text_outputs.attentions,
        # )
        ns = OrderedNamespace()
        ns.text_embeds = text_embeds
        ns.last_hidden_state = text_outputs.last_hidden_state
        ns.hidden_states = text_outputs.hidden_states
        ns.attentions = text_outputs.attentions
        return ns
