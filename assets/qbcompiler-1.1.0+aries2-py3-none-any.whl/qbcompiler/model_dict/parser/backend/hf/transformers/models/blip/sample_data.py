import pathlib
import io

from PIL import Image


def get_sample_data(conditional_image_captioning=True):
    try:
        from transformers import BlipProcessor
    except:
        raise ImportError(
            "Failed to import transformers. Please refer to the Mobilint Docker environment and install an appropriate version of transformers."
        )
    path = pathlib.Path(__file__).parent.joinpath("data/raw_data.bin")
    raw_data = path.read_bytes()
    raw_image = Image.open(io.BytesIO(raw_data))
    processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-large")

    if conditional_image_captioning:
        text = "a photography of"
        return processor(images=raw_image, text=text, return_tensors="pt").to("cpu")
    else:
        return processor(images=raw_image, return_tensors="pt").to("cpu")
