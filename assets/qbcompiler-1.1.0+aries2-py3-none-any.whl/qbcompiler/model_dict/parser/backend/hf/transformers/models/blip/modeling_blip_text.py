import abc
import math
from typing import Any, Type, Optional, Tuple, Union

import numpy
import torch
import qbcompiler.mobilint_transformers.compat_transformers.models.blip.modeling_blip_text as hf_transformers_blip_modeling_blip_text

from qbcompiler.model_dict.common import ActivationSpec, DataFormat
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase
from qbcompiler.model_dict.parser.backend.hf.make_modules import make_dynamic_object
from qbcompiler.model_dict.parser.backend.hf.transformers.pytorch_utils import (
    apply_chunking_to_forward,
)
from qbcompiler.model_dict.parser.backend.hf.util import OrderedNamespace


class ModelingBlipTextBase(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name, make_module_func=make_dynamic_object)


class BlipTextLMHeadModel(ModelingBlipTextBase):
    __slots__ = ("bert", "label_smoothing", "cls", "config")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip_text.BlipTextLMHeadModel

    def forward(
        self,
        input_ids: Optional[ActivationSpec] = None,
        attention_mask: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,
        inputs_embeds: Optional[ActivationSpec] = None,
        encoder_hidden_states: Optional[ActivationSpec] = None,
        encoder_attention_mask: Optional[ActivationSpec] = None,
        labels: Optional[ActivationSpec] = None,
        past_key_values: Optional[Any] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        return_logits: Optional[bool] = False,
        is_decoder: Optional[bool] = True,
        reduction: Optional[str] = "mean",
    ):
        # input_ids: torch.Size([1, 1])
        # attention_mask: torch.Size([1, 1])
        # encoder_hidden_states: torch.Size([1, 577, 1024])
        # encoder_attention_mask: torch.Size([1, 577])
        return_dict = (
            return_dict if return_dict is not None else self.config.use_return_dict
        )
        if labels is not None:
            use_cache = False

        outputs = self.bert(
            input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            encoder_hidden_states=encoder_hidden_states,
            encoder_attention_mask=encoder_attention_mask,
            past_key_values=past_key_values,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            is_decoder=is_decoder,
        )

        sequence_output = outputs[0]  # torch.Size([1, 1, 768])
        prediction_scores = self.cls(sequence_output)  # torch.Size([1, 1, 30524])

        if return_logits:
            return prediction_scores[:, :-1, :].contiguous()

        lm_loss = None
        if labels is not None:
            raise NotImplementedError
            # we are doing next-token prediction; shift prediction scores and input ids by one
            # shifted_prediction_scores = prediction_scores[:, :-1, :].contiguous()
            # labels = labels[:, 1:].contiguous().to(shifted_prediction_scores.device)
            # loss_fct = CrossEntropyLoss(
            #     reduction=reduction, label_smoothing=self.label_smoothing
            # )
            # lm_loss = loss_fct(
            #     shifted_prediction_scores.view(-1, self.config.vocab_size),
            #     labels.view(-1),
            # )
            # if reduction == "none":
            #     lm_loss = lm_loss.view(prediction_scores.size(0), -1).sum(1)

        if not return_dict:
            raise NotImplementedError
            # output = (prediction_scores,) + outputs[2:]
            # return ((lm_loss,) + output) if lm_loss is not None else output

        # return CausalLMOutputWithCrossAttentions(
        #     loss=lm_loss,
        #     logits=prediction_scores,
        #     past_key_values=outputs.past_key_values,
        #     hidden_states=outputs.hidden_states,
        #     attentions=outputs.attentions,
        #     cross_attentions=outputs.cross_attentions,
        # )
        ns = OrderedNamespace()
        ns.loss = lm_loss
        ns.logits = prediction_scores
        ns.past_key_values = outputs.past_key_values
        ns.hidden_states = outputs.hidden_states
        ns.attentions = outputs.attentions
        ns.cross_attentions = outputs.cross_attentions
        return ns


class BlipTextModel(ModelingBlipTextBase):
    __slots__ = ("config", "encoder", "pooler")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip_text.BlipTextModel

    def forward(
        self,
        input_ids: Optional[ActivationSpec] = None,
        attention_mask: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,
        inputs_embeds: Optional[ActivationSpec] = None,
        encoder_embeds: Optional[ActivationSpec] = None,
        encoder_hidden_states: Optional[ActivationSpec] = None,
        encoder_attention_mask: Optional[ActivationSpec] = None,
        past_key_values: Optional[Any] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        is_decoder: Optional[bool] = False,
    ):
        # input_ids # torch.Size([1, 1])
        # attention_mask: torch.Size([1, 1])
        # encoder_hidden_states  torch.Size([1, 577, 1024])
        # encoder_attention_mask torch.Size([1, 577])

        output_attentions = (
            output_attentions
            if output_attentions is not None
            else self.config.output_attentions
        )
        output_hidden_states = (
            output_hidden_states
            if output_hidden_states is not None
            else self.config.output_hidden_states
        )
        return_dict = (
            return_dict if return_dict is not None else self.config.use_return_dict
        )

        if is_decoder:
            use_cache = use_cache if use_cache is not None else self.config.use_cache
        else:
            raise NotImplementedError
            # use_cache = False

        if input_ids is not None and inputs_embeds is not None:
            raise ValueError(
                "You cannot specify both input_ids and inputs_embeds at the same time"
            )
        elif input_ids is not None:
            # self.warn_if_padding_and_no_attention_mask(input_ids, attention_mask)
            # input_shape = input_ids.size()  # (1,1)
            input_shape = input_ids.get_act_src_shape()
            batch_size, seq_length = input_shape
            # device = input_ids.device
        elif inputs_embeds is not None:
            raise NotImplementedError
            # input_shape = inputs_embeds.size()[:-1]
            # batch_size, seq_length = input_shape
            # device = inputs_embeds.device
        elif encoder_embeds is not None:
            raise NotImplementedError
            # input_shape = encoder_embeds.size()[:-1]
            # batch_size, seq_length = input_shape
            # device = encoder_embeds.device
        else:
            raise ValueError(
                "You have to specify either input_ids or inputs_embeds or encoder_embeds"
            )

        # past_key_values_length
        # past_key_values_length = (
        #     past_key_values[0][0].shape[2] if past_key_values is not None else 0
        # )
        past_key_values_length = 0
        if past_key_values is not None:
            past_key_values_length = past_key_values.past_seqlen

        if attention_mask is None:
            raise NotImplementedError
            # attention_mask = torch.ones(
            #     ((batch_size, seq_length + past_key_values_length))
            # ).to(device)

        # We can provide a self-attention mask of dimensions [batch_size, from_seq_length, to_seq_length]
        # ourselves in which case we just need to make it broadcastable to all heads.
        extended_attention_mask = self.get_extended_attention_mask(
            attention_mask, input_shape, "device", is_decoder
        )  # torch.Size([1, 1, 1, 1]), [[[[.0]]]]

        # If a 2D or 3D attention mask is provided for the cross-attention
        # we need to make broadcastable to [batch_size, num_heads, seq_length, seq_length]
        if encoder_hidden_states is not None:
            if isinstance(encoder_hidden_states, list):
                raise NotImplementedError
                # encoder_batch_size, encoder_sequence_length, _ = encoder_hidden_states[0].size()
            else:
                (
                    encoder_batch_size,
                    encoder_sequence_length,
                    _,
                ) = encoder_hidden_states.get_act_src_shape()  # (1, 577)
            encoder_hidden_shape = (encoder_batch_size, encoder_sequence_length)

            if isinstance(encoder_attention_mask, list):
                raise NotImplementedError
                # encoder_extended_attention_mask = [
                #     self.invert_attention_mask(mask) for mask in encoder_attention_mask
                # ]
            elif encoder_attention_mask is None:
                raise NotImplementedError
                # encoder_attention_mask = torch.ones(encoder_hidden_shape, device=device)
                # encoder_extended_attention_mask = self.invert_attention_mask(
                #     encoder_attention_mask
                # )
            else:
                # encoder_extended_attention_mask = self.invert_attention_mask(
                #     encoder_attention_mask
                # )  # torch.Size([1, 1, 1, 577])
                a, b = encoder_attention_mask.get_act_src_shape()
                encoder_extended_attention_mask = self.builder.make_temporary_operator(
                    (attention_mask,),
                    output_src_shape=(a, 1, 1, b),
                    output_dtype="float32",
                    description="self.invert_attention_mask of BlipTextModel",
                    opname="encoder_extended_attention_mask",
                )
        else:
            raise NotImplementedError
            # encoder_extended_attention_mask = None

        # Prepare head mask if needed
        # 1.0 in head_mask indicate we keep the head
        # attention_probs has shape bsz x n_heads x N x N
        # input head_mask has shape [num_heads] or [num_hidden_layers x num_heads]
        # and head_mask is converted to shape [num_hidden_layers x batch x num_heads x seq_length x seq_length]
        head_mask = self.get_head_mask(
            head_mask, self.config.num_hidden_layers
        )  # [None] * 12

        if encoder_embeds is None:
            embedding_output = self.embeddings(
                input_ids=input_ids,
                position_ids=position_ids,
                inputs_embeds=inputs_embeds,
                past_key_values_length=past_key_values_length,
            )  # torch.Size([1, 1, 768])
        else:
            raise NotImplementedError
            # embedding_output = encoder_embeds

        encoder_outputs = self.encoder(
            embedding_output,
            attention_mask=extended_attention_mask,
            head_mask=head_mask,
            encoder_hidden_states=encoder_hidden_states,
            encoder_attention_mask=encoder_extended_attention_mask,
            past_key_values=past_key_values,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
        )
        sequence_output = encoder_outputs[0]  # torch.Size([1, 1, 768])
        pooled_output = (
            self.pooler(sequence_output) if self.pooler is not None else None
        )  # None

        if not return_dict:
            raise NotImplementedError
            # return (sequence_output, pooled_output) + encoder_outputs[1:]

        # return BaseModelOutputWithPoolingAndCrossAttentions(
        #     last_hidden_state=sequence_output,
        #     pooler_output=pooled_output,
        #     past_key_values=encoder_outputs.past_key_values,
        #     hidden_states=encoder_outputs.hidden_states,
        #     attentions=encoder_outputs.attentions,
        #     cross_attentions=encoder_outputs.cross_attentions,

        # )
        ns = OrderedNamespace()
        ns.last_hidden_state = sequence_output
        ns.pooler_output = pooled_output
        ns.past_key_values = encoder_outputs.past_key_values
        ns.hidden_states = encoder_outputs.hidden_states
        ns.attentions = encoder_outputs.attentions
        ns.cross_attentions = encoder_outputs.cross_attentions
        return ns

    def invert_attention_mask(
        self, encoder_attention_mask: ActivationSpec
    ) -> ActivationSpec:
        """
        Invert an attention mask (e.g., switches 0. and 1.).

        Args:
            encoder_attention_mask (`torch.Tensor`): An attention mask.

        Returns:
            `torch.Tensor`: The inverted attention mask.
        """
        if encoder_attention_mask.src_dim == 3:
            encoder_extended_attention_mask = encoder_attention_mask[:, None, :, :]
        if encoder_attention_mask.src_dim == 2:
            encoder_extended_attention_mask = encoder_attention_mask[:, None, None, :]
        # T5 has a mask that can compare sequence ids, we can simulate this here with this transposition
        # Cf. https://github.com/tensorflow/mesh/blob/8d2465e9bc93129b913b5ccc6a59aa97abd96ec6/mesh_tensorflow
        # /transformer/transformer_layers.py#L270
        # encoder_extended_attention_mask = (encoder_extended_attention_mask ==
        # encoder_extended_attention_mask.transpose(-1, -2))
        encoder_extended_attention_mask = encoder_extended_attention_mask.to(
            dtype=self.dtype
        )  # fp16 compatibility
        encoder_extended_attention_mask = (
            1.0 - encoder_extended_attention_mask
        ) * torch.finfo(self.dtype).min

        return encoder_extended_attention_mask

    def get_head_mask(
        self,
        head_mask: Optional[ActivationSpec],
        num_hidden_layers: int,
        is_attention_chunked: bool = False,
    ) -> ActivationSpec:
        """
        Prepare the head mask if needed.

        Args:
            head_mask (`ActivationSpec` with shape `[num_heads]` or `[num_hidden_layers x num_heads]`, *optional*):
                The mask indicating if we should keep the heads or not (1.0 for keep, 0.0 for discard).
            num_hidden_layers (`int`):
                The number of hidden layers in the model.
            is_attention_chunked (`bool`, *optional*, defaults to `False`):
                Whether or not the attentions scores are computed by chunks or not.

        Returns:
            `ActivationSpec` with shape `[num_hidden_layers x batch x num_heads x seq_length x seq_length]` or list with
            `[None]` for each layer.
        """
        if head_mask is not None:
            raise NotImplementedError
            # head_mask = self._convert_head_mask_to_5d(head_mask, num_hidden_layers)
            # if is_attention_chunked is True:
            #     head_mask = head_mask.unsqueeze(-1)
        else:
            head_mask = [None] * num_hidden_layers

        return head_mask

    def _convert_head_mask_to_5d(self, head_mask, num_hidden_layers):
        """-> [num_hidden_layers x batch x num_heads x seq_length x seq_length]"""
        if head_mask.src_dim == 1:
            head_mask = head_mask.unsqueeze(0).unsqueeze(0).unsqueeze(-1).unsqueeze(-1)
            head_mask = head_mask.expand(num_hidden_layers, -1, -1, -1, -1)
        elif head_mask.src_dim == 2:
            head_mask = (
                head_mask.unsqueeze(1).unsqueeze(-1).unsqueeze(-1)
            )  # We can specify head_mask for each layer
        assert head_mask.dim() == 5, f"head_mask.dim != 5, instead {head_mask.dim()}"
        head_mask = head_mask.to(
            dtype=self.dtype
        )  # switch to float if need + fp16 compatibility
        return head_mask

    def get_extended_attention_mask(
        self,
        attention_mask: ActivationSpec,
        input_shape: Tuple[int],
        device: "device",
        is_decoder: bool,
    ) -> ActivationSpec:
        device = "cpu"
        # We can provide a self-attention mask of dimensions [batch_size, from_seq_length, to_seq_length]
        # ourselves in which case we just need to make it broadcastable to all heads.
        if attention_mask.src_dim == 3:
            raise NotImplementedError
            # extended_attention_mask = attention_mask[:, None, :, :]
        elif attention_mask.src_dim == 2:
            # Provided a padding mask of dimensions [batch_size, seq_length]
            # - if the model is a decoder, apply a causal mask in addition to the padding mask
            # - if the model is an encoder, make the mask broadcastable to [batch_size, num_heads, seq_length, seq_length]
            if is_decoder:
                batch_size, seq_length = input_shape  # (1, 4), (1,1)
                batch_size = int(batch_size)
                seq_length = int(seq_length)
                seq_ids = torch.arange(seq_length, device=device)  # [0,1,3,4]
                causal_mask = (
                    seq_ids[None, None, :].repeat(batch_size, seq_length, 1)
                    <= seq_ids[None, :, None]
                )
                # in case past_key_values are used we need to add a prefix ones mask to the causal mask
                # causal and attention masks must have same type with pytorch version < 1.3
                causal_mask = causal_mask.to(torch.int64)  # [[[1]]]
                # tensor([[[1, 0, 0, 0],
                #          [1, 1, 0, 0],
                #          [1, 1, 1, 0],
                #          [1, 1, 1, 1]]])
                # tensor([[[1]]])

                if causal_mask.shape[1] < int(attention_mask.get_act_src_shape()[1]):
                    prefix_seq_len = (
                        int(attention_mask.get_act_src_shape()[1])
                        - causal_mask.shape[1]
                    )
                    causal_mask = torch.cat(
                        [
                            torch.ones(
                                (batch_size, seq_length, prefix_seq_len),
                                device=device,
                                dtype=causal_mask.dtype,
                            ),
                            causal_mask,
                        ],
                        axis=-1,
                    )
                    # tensor([[[1, 1, 1, 1, 1]]])
                # extended_attention_mask = causal_mask[:, None, :, :] * attention_mask[:, None, None, :])
                # tensor([[[[1, 0, 0, 0],
                #           [1, 1, 0, 0],
                #           [1, 1, 1, 0],
                #           [1, 1, 1, 1]]]])
                a, b = attention_mask.get_act_src_shape()
                extended_attention_mask_src_shape = tuple(
                    max(a, b)
                    for a, b in zip(
                        causal_mask[:, None, :, :].shape, [int(a), 1, 1, int(b)]
                    )
                )
            else:
                raise NotImplementedError
                # extended_attention_mask = attention_mask[:, None, None, :]
        else:
            raise ValueError(
                "Wrong shape for input_ids (shape {}) or attention_mask (shape {})".format(
                    input_shape, attention_mask.shape
                )
            )

        # Since attention_mask is 1.0 for positions we want to attend and 0.0 for
        # masked positions, this operation will create a tensor which is 0.0 for
        # positions we want to attend and -10000.0 for masked positions.
        # Since we are adding it to the raw scores before the softmax, this is
        # effectively the same as removing these entirely.
        # extended_attention_mask = extended_attention_mask.to(dtype=self.dtype)  # fp16 compatibility
        # extended_attention_mask = (1.0 - extended_attention_mask) * -10000.0
        # tensor([[[[-0., -10000., -10000., -10000.],
        #           [-0., -0., -10000., -10000.],
        #           [-0., -0., -0., -10000.],
        #           [-0., -0., -0., -0.]]]])
        # tensor([[[[-0., -0., -0., -0., -0.]]]])
        # return extended_attention_mask
        return self.builder.make_temporary_operator(
            (attention_mask,),
            output_src_shape=extended_attention_mask_src_shape,
            output_dtype="float32",
            description="self.get_extended_attention_mask of BlipTextModel",
            opname=self.module_name + ".extended_attention_mask",
        )


class BlipTextOnlyMLMHead(ModelingBlipTextBase):
    __slots__ = ("predictions",)

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip_text.BlipTextOnlyMLMHead

    def forward(self, sequence_output: torch.Tensor) -> torch.Tensor:
        prediction_scores = self.predictions(sequence_output)
        return prediction_scores


class BlipTextLMPredictionHead(ModelingBlipTextBase):
    __slots__ = ("transform", "decoder")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip_text.BlipTextLMPredictionHead

    def forward(self, hidden_states):
        hidden_states = self.transform(hidden_states)
        hidden_states = self.decoder(hidden_states)
        return hidden_states


class BlipTextPredictionHeadTransform(ModelingBlipTextBase):
    __slots__ = ("dense", "transform_act_fn", "LayerNorm")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip_text.BlipTextPredictionHeadTransform

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        hidden_states = self.dense(hidden_states)
        hidden_states = self.transform_act_fn(hidden_states)
        hidden_states = self.LayerNorm(hidden_states)
        return hidden_states


class BlipTextEncoder(ModelingBlipTextBase):
    __slots__ = ("config", "layer")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip_text.BlipTextEncoder

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,
        encoder_hidden_states: Optional[ActivationSpec] = None,
        encoder_attention_mask: Optional[ActivationSpec] = None,
        past_key_values: Optional[Tuple[Tuple[ActivationSpec]]] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = False,
        output_hidden_states: Optional[bool] = False,
        return_dict: Optional[bool] = True,
    ) -> Union[Tuple[ActivationSpec], Any]:
        # if self.gradient_checkpointing and self.training:
        #     if use_cache:
        #         logger.warning(
        #             "`use_cache=True` is incompatible with gradient checkpointing. Setting `use_cache=False`..."
        #         )
        #         use_cache = False
        all_hidden_states = () if output_hidden_states else None
        all_self_attentions = () if output_attentions else None
        all_cross_attentions = (
            () if output_attentions and self.config.is_decoder else None
        )

        next_decoder_cache = () if use_cache else None

        for i in range(self.config.num_hidden_layers):
            is_last_block = i == self.config.num_hidden_layers - 1
            layer_module = self.layer[i]
            if output_hidden_states:
                all_hidden_states = all_hidden_states + (hidden_states,)

            layer_head_mask = head_mask[i] if head_mask is not None else None
            # past_key_value = past_key_values[i] if past_key_values is not None else None

            layer_outputs = layer_module(
                hidden_states,
                attention_mask,
                layer_head_mask,
                encoder_hidden_states,
                encoder_attention_mask,
                past_key_values,
                output_attentions,
                is_last_block=is_last_block,
            )

            hidden_states = layer_outputs[0]  # torch.Size([1, 1, 768])
            if use_cache:
                next_decoder_cache += (layer_outputs[-1],)
            if output_attentions:
                raise NotImplementedError
                # all_self_attentions = all_self_attentions + (layer_outputs[1],)
                # all_cross_attentions = all_cross_attentions + (layer_outputs[2],)

        if output_hidden_states:
            raise NotImplementedError
            # all_hidden_states = all_hidden_states + (hidden_states,)

        if not return_dict:
            raise NotImplementedError
            # return tuple(
            #     v
            #     for v in [
            #         hidden_states,
            #         next_decoder_cache,
            #         all_hidden_states,
            #         all_self_attentions,
            #         all_cross_attentions,
            #     ]
            #     if v is not None
            # )
        # return BaseModelOutputWithPastAndCrossAttentions(
        #     last_hidden_state=hidden_states,
        #     past_key_values=next_decoder_cache,
        #     hidden_states=all_hidden_states,
        #     attentions=all_self_attentions,
        #     cross_attentions=all_cross_attentions,
        # )
        ns = OrderedNamespace()
        ns.last_hidden_state = hidden_states
        ns.past_key_values = next_decoder_cache
        ns.hidden_states = all_hidden_states
        ns.attentions = all_self_attentions
        ns.cross_attentions = all_cross_attentions
        return ns


class BlipTextAttention(ModelingBlipTextBase):
    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip_text.BlipTextAttention

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,
        encoder_hidden_states: Optional[ActivationSpec] = None,
        encoder_attention_mask: Optional[ActivationSpec] = None,
        past_key_value: Optional[Tuple[Tuple[ActivationSpec]]] = None,
        output_attentions: Optional[bool] = False,
    ) -> Tuple[ActivationSpec]:
        self_outputs = self.self(
            hidden_states,
            attention_mask,
            head_mask,
            encoder_hidden_states,
            encoder_attention_mask,
            past_key_value,
            output_attentions,
        )  # (1,1,768), kvcache
        attention_output = self.output(
            self_outputs[0], hidden_states
        )  # torch.Size([1, 1, 768])
        outputs = (attention_output,) + self_outputs[
            1:
        ]  # add attentions if we output them
        return outputs


class BlipTextSelfAttention(ModelingBlipTextBase):
    __slots__ = (
        "num_attention_heads",
        "attention_head_size",
        "position_embedding_type",
        "all_head_size",
        "key",
        "value",
    )

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip_text.BlipTextSelfAttention

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,
        encoder_hidden_states: Optional[ActivationSpec] = None,
        encoder_attention_mask: Optional[ActivationSpec] = None,
        past_key_value: Optional[Any] = None,
        output_attentions: Optional[bool] = False,
    ) -> Tuple[ActivationSpec]:
        mixed_query_layer = self.query(hidden_states)  # torch.Size([1, 1, 768])

        # If this is instantiated as a cross-attention module, the keys
        # and values come from an encoder; the attention mask needs to be
        # such that the encoder's padding tokens are not attended to.
        is_cross_attention = encoder_hidden_states is not None

        curr_seqlen = int(hidden_states.get_act_src_shape()[1])

        if is_cross_attention:
            key_layer = self.transpose_for_scores(self.key(encoder_hidden_states))
            value_layer = self.transpose_for_scores(self.value(encoder_hidden_states))
            # attention_mask = encoder_attention_mask
            attention_mask = None  # 이거 encoder_attention_mask는 계속 전체 다 보는 것 같음.
        elif past_key_value is not None:
            key_layer = self.transpose_for_scores(self.key(hidden_states))
            value_layer = self.transpose_for_scores(self.value(hidden_states))
            # key_layer = torch.cat([past_key_value[0], key_layer], dim=2)
            # value_layer = torch.cat([past_key_value[1], value_layer], dim=2)
            key_layer = self.builder.make_stateful_kvcache_wrapper(
                key_layer,
                key_layer.name,
                past_key_value.past_seqlen,
                opname=key_layer.name + "/cache",
            )
            value_layer = self.builder.make_stateful_kvcache_wrapper(
                value_layer,
                value_layer.name,
                past_key_value.past_seqlen,
                opname=value_layer.name + "/cache",
            )
        else:
            key_layer = self.transpose_for_scores(
                self.key(hidden_states)
            )  # torch.Size([1, 12, 1, 64])
            value_layer = self.transpose_for_scores(
                self.value(hidden_states)
            )  # torch.Size([1, 12, 1, 64])

        query_layer = self.transpose_for_scores(
            mixed_query_layer
        )  # torch.Size([1, 12, 1, 64])

        # past_key_value = (key_layer, value_layer)
        # if past_key_value is not None:
        #     past_key_value = past_key_value.get_updated(curr_seqlen)

        # Take the dot product between "query" and "key" to get the raw attention scores.
        # attention_scores = torch.matmul(query_layer, key_layer.transpose(-1, -2))  # torch.Size([1, 12, 1, 1])
        attention_scores = self.builder.make_matmul(
            query_layer,
            self.builder.make_transpose(key_layer, transpose_axes=(0, 1, 3, 2)),
        )

        if (
            self.position_embedding_type == "relative_key"
            or self.position_embedding_type == "relative_key_query"
        ):
            raise NotImplementedError
            # seq_length = hidden_states.size()[1]
            # position_ids_l = torch.arange(seq_length, dtype=torch.long, device=hidden_states.device).view(-1, 1)
            # position_ids_r = torch.arange(seq_length, dtype=torch.long, device=hidden_states.device).view(1, -1)
            # distance = position_ids_l - position_ids_r
            # positional_embedding = self.distance_embedding(distance + self.max_position_embeddings - 1)
            # positional_embedding = positional_embedding.to(dtype=query_layer.dtype)  # fp16 compatibility
            #
            # if self.position_embedding_type == "relative_key":
            #     relative_position_scores = torch.einsum("bhld,lrd->bhlr", query_layer, positional_embedding)
            #     attention_scores = attention_scores + relative_position_scores
            # elif self.position_embedding_type == "relative_key_query":
            #     relative_position_scores_query = torch.einsum("bhld,lrd->bhlr", query_layer, positional_embedding)
            #     relative_position_scores_key = torch.einsum("bhrd,lrd->bhlr", key_layer, positional_embedding)
            #     attention_scores = attention_scores + relative_position_scores_query + relative_position_scores_key

        # attention_scores = attention_scores / math.sqrt(
        #     self.attention_head_size
        # )  # torch.Size([1, 12, 1, 1])
        attention_scores = self.builder.make_mul(
            attention_scores, 1.0 / math.sqrt(self.attention_head_size)
        )

        if attention_mask is not None:
            # Apply the attention mask is (precomputed for all layers in BlipTextModel forward() function)
            # attention_scores = attention_scores + attention_mask.to(
            #     attention_scores.device
            # )
            # attention_scores = self.builder.make_add(attention_scores, attention_mask)
            attention_scores = self.builder.apply_attention_mask(
                attention_scores, attention_mask
            )

        # Normalize the attention scores to probabilities.
        # attention_probs = nn.Softmax(dim=-1)(attention_scores)  # torch.Size([1, 12, 1, 1])
        attention_probs = self.builder.make_softmax(attention_scores)

        # This is actually dropping out entire tokens to attend to, which might
        # seem a bit unusual, but is taken from the original Transformer paper.
        attention_probs_dropped = self.dropout(
            attention_probs
        )  # torch.Size([1, 12, 1, 1])

        # # Mask heads if we want to
        if head_mask is not None:
            raise NotImplementedError
            # attention_probs_dropped = attention_probs_dropped * head_mask
            # attention_probs_dropped = self.builder.make_mul(
            #     attention_probs_dropped, head_mask
            # )

        # context_layer = torch.matmul(attention_probs_dropped, value_layer)  # torch.Size([1, 12, 1, 64])
        context_layer = self.builder.make_matmul(attention_probs_dropped, value_layer)

        # context_layer = context_layer.permute(0, 2, 1, 3).contiguous()  # torch.Size([1, 1, 12, 64])
        context_layer = self.builder.make_transpose(
            context_layer, transpose_axes=(0, 2, 1, 3)
        )

        # new_context_layer_shape = context_layer.size()[:-2] + (self.all_head_size,)
        new_context_layer_shape = context_layer.get_act_src_shape()[:-2] + (
            self.all_head_size,
        )
        # context_layer = context_layer.view(*new_context_layer_shape)  # (1,1,768)
        context_layer = self.builder.make_reshape(
            context_layer, new_context_layer_shape
        )  # (1,1,768)

        outputs = (
            (context_layer, attention_probs) if output_attentions else (context_layer,)
        )

        outputs = outputs + (past_key_value,)
        return outputs

    def transpose_for_scores(self, x):
        # new_x_shape = x.size()[:-1] + (
        #     self.num_attention_heads,
        #     self.attention_head_size,
        # )
        # x = x.view(*new_x_shape)
        new_x_shape = x.get_act_src_shape()[:-1] + (
            self.num_attention_heads,
            self.attention_head_size,
        )
        x = self.builder.make_reshape(x, new_x_shape)
        # return x.permute(0, 2, 1, 3)
        return self.builder.make_transpose(x, (0, 2, 1, 3))


class BlipTextSelfOutput(ModelingBlipTextBase):
    __slots__ = ("dense", "dropout", "LayerNorm")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip_text.BlipTextSelfOutput

    def forward(
        self, hidden_states: torch.Tensor, input_tensor: torch.Tensor
    ) -> torch.Tensor:
        hidden_states = self.dense(hidden_states)
        hidden_states = self.dropout(hidden_states)
        hidden_states = self.LayerNorm(
            self.builder.make_add(hidden_states, input_tensor)
        )
        return hidden_states


class BlipTextIntermediate(ModelingBlipTextBase):
    __slots__ = ("dense", "intermediate_act_fn")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip_text.BlipTextIntermediate

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        hidden_states = self.dense(hidden_states)
        hidden_states = self.intermediate_act_fn(hidden_states)
        return hidden_states


class BlipTextOutput(ModelingBlipTextBase):
    __slots__ = ("dense", "dropout", "LayerNorm")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip_text.BlipTextOutput

    def forward(
        self, hidden_states: torch.Tensor, input_tensor: torch.Tensor
    ) -> torch.Tensor:
        hidden_states = self.dense(hidden_states)
        hidden_states = self.dropout(hidden_states)
        hidden_states = self.LayerNorm(
            self.builder.make_add(hidden_states, input_tensor)
        )
        return hidden_states


class BlipTextLayer(ModelingBlipTextBase):
    __slots__ = (
        "crossattention",
        "intermediate",
        "output",
        "chunk_size_feed_forward",
        "seq_len_dim",
    )

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip_text.BlipTextLayer

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,
        encoder_hidden_states: Optional[ActivationSpec] = None,
        encoder_attention_mask: Optional[ActivationSpec] = None,
        past_key_value: Optional[Tuple[Tuple[ActivationSpec]]] = None,
        output_attentions: Optional[bool] = False,
        is_last_block=False,
    ) -> Tuple[ActivationSpec]:
        # decoder uni-directional self-attention cached key/values tuple is at positions 1,2
        # self_attn_past_key_value = (
        #     past_key_value[:2] if past_key_value is not None else None
        # )
        self_attention_outputs = self.attention(
            hidden_states,
            attention_mask,
            head_mask,
            output_attentions=output_attentions,
            past_key_value=past_key_value,
        )
        attention_output = self_attention_outputs[0]  # torch.Size([1, 1, 768])
        if is_last_block:
            attention_output = self.builder.make_slice(
                attention_output,
                axis=(1,),
                start=(-1,),
                end=(int(numpy.iinfo(numpy.int32).max),),
                step=(1,),
            )
            for x in attention_output.src_shape:
                if x.dynamic:
                    x._dynamic = False

        outputs = self_attention_outputs[1:-1]
        present_key_value = self_attention_outputs[-1]

        if encoder_hidden_states is not None:
            cross_attention_outputs = self.crossattention(
                attention_output,
                attention_mask,
                head_mask,
                encoder_hidden_states,
                encoder_attention_mask,
                output_attentions=output_attentions,
            )
            attention_output = cross_attention_outputs[0]  # torch.Size([1, 1, 768])
            outputs = (
                outputs + cross_attention_outputs[1:-1]
            )  # add cross attentions if we output attention weights
        layer_output = apply_chunking_to_forward(
            self.feed_forward_chunk,
            self.chunk_size_feed_forward,
            self.seq_len_dim,
            attention_output,
        )  # torch.Size([1, 1, 768]),
        outputs = (layer_output,) + outputs

        outputs = outputs + (present_key_value,)

        return outputs

    def feed_forward_chunk(self, attention_output):
        intermediate_output = self.intermediate(attention_output)
        layer_output = self.output(intermediate_output, attention_output)
        return layer_output


class BlipTextEmbeddings(ModelingBlipTextBase):
    __slots__ = (
        "position_ids",
        "word_embeddings",
        "position_embedding_type",
        "LayerNorm",
        "dropout",
    )

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip_text.BlipTextEmbeddings

    def forward(
        self,
        input_ids: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        inputs_embeds: Optional[ActivationSpec] = None,
        past_key_values_length: int = 0,
    ) -> ActivationSpec:
        if input_ids is not None:
            input_shape = input_ids.get_act_src_shape()
        else:
            raise NotImplementedError
            # input_shape = inputs_embeds.size()[:-1]

        seq_length = int(input_shape[1])

        if position_ids is None:
            # position_ids = self.position_ids[
            #     :, past_key_values_length : seq_length + past_key_values_length
            # ]
            position_ids = self.builder.make_inputconst(
                self.position_ids[:, None, None, :],
                opname=self.module_name + ".position_ids",
            )
            position_ids = self.builder.make_reshape(
                position_ids,
                tuple(self.position_ids.shape),
                new_dataformat=DataFormat.NX,
            )
            position_ids = self.builder.make_slice(
                position_ids,
                axis=(1,),
                start=(past_key_values_length,),
                end=(seq_length + past_key_values_length,),
            )

        if inputs_embeds is None:
            # input_ids = input_ids.to(self.word_embeddings.weight.device)
            inputs_embeds = self.word_embeddings(input_ids)
            self.builder.set_output_value_reference(
                inputs_embeds, output_value_reference=""
            )  # delete output_value_reference

        embeddings = inputs_embeds

        if self.position_embedding_type == "absolute":
            position_embeddings = self.position_embeddings(position_ids)
            # embeddings += position_embeddings
            embeddings = self.builder.make_add(embeddings, position_embeddings)

        embeddings = self.LayerNorm(embeddings)
        embeddings = self.dropout(embeddings)
        self.builder.set_output_value_reference(embeddings, self.module_name)
        return embeddings
