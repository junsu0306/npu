import abc
import math
from typing import Tuple, Any, Optional, Union, List

import numpy
import torch
import qbcompiler.mobilint_transformers.compat_transformers.models.llama.modeling_llama as hf_modeling_llama

import qbcompiler.model_dict.common.options as layer_options
from qbcompiler.model_dict.common import (
    ActivationSpec,
    DataFormat,
    Operator,
)
from qbcompiler.model_dict.parser.backend.hf.make_modules import make_dynamic_object
from qbcompiler.model_dict.parser.backend.hf.transformers.modeling_outputs import (
    CausalLMOutputWithPast,
    BaseModelOutputWithPast,
)
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase
from qbcompiler.model_dict.parser.backend.modeling_torch.module_registry import Registry

__all__ = ["LlamaForCausalLM"]


llama_registry = Registry(name="llama_registry")


class ModelingLlamaBase(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name, make_module_func=make_dynamic_object)


@llama_registry.add_to_registry(hf_modeling_llama.LlamaRotaryEmbedding)
class LlamaRotaryEmbedding(ModelingLlamaBase):
    """This module is intentionally designed as a singleton to reuse ROPE weight."""

    __slots__ = ("rope_type",)
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)
        self.inv_freq = model.inv_freq
        self.num_head = model.config.num_attention_heads
        self.attention_scaling = model.attention_scaling
        self.rope_max_seqlen = 8192
        self.cos = None
        self.sin = None

    def make_rope_inputconst(self):
        # fmt: off
        if self.cos is None:
            device = self.inv_freq.device
            position_ids = torch.arange(self.rope_max_seqlen, dtype=torch.int64).unsqueeze(0).to(device)
            inv_freq_expanded = self.inv_freq[None, :, None].float().expand(position_ids.shape[0], -1, 1)
            position_ids_expanded = position_ids[:, None, :].float()
            freqs = (inv_freq_expanded.float() @ position_ids_expanded.float()).transpose(1, 2)
            emb = torch.cat((freqs, freqs), dim=-1)
            emb_cos = (emb.cos() * self.attention_scaling).unsqueeze(1)
            emb_sin = (emb.sin() * self.attention_scaling).unsqueeze(1)
            self.cos = self.builder.make_inputconst(emb_cos, self.module_name + ".cos")
            self.sin = self.builder.make_inputconst(emb_sin, self.module_name + ".sin")
        # fmt: on
        return self.cos, self.sin

    def forward(self, x: ActivationSpec, position_ids: Optional[ActivationSpec] = None):
        if "dynamic" in self.rope_type:
            raise NotImplementedError
        if position_ids is None:
            return self.make_rope_inputconst()
        else:
            raise NotImplementedError


@llama_registry.add_to_registry(hf_modeling_llama.LlamaAttention)
class LlamaAttention(ModelingLlamaBase, abc.ABC):
    def apply_rotary_pos_emb(
        self,
        q: ActivationSpec,
        k: ActivationSpec,
        cos: ActivationSpec,
        sin: ActivationSpec,
    ):
        q_rope = self.builder.make_stateful_rope_wrapper(
            q, cos, sin, self.module_name + "/q_rope"
        )
        k_rope = self.builder.make_stateful_rope_wrapper(
            k, cos, sin, self.module_name + "/k_rope"
        )
        return q_rope, k_rope

    def past_kv_update(
        self, key: ActivationSpec, value: ActivationSpec, past_key_value
    ):
        updates = []
        for x in (key, value):
            updates.append(
                self.builder.make_stateful_kvcache_wrapper(
                    x, x.name, past_key_value.past_seq_len, opname=x.name + "/cache"
                )
            )
        return tuple(updates)

    def repeat_kv(self, hidden_states: ActivationSpec, num_repeat):
        return self.builder.make_repeat_n(hidden_states, num_repeat)

    def apply_attention_mask(
        self,
        attn_weight: ActivationSpec,
        attn_mask: ActivationSpec,
        past_seq_len: int = 0,
    ):
        masked = attn_weight.copy(name=self.module_name + "/attn_mask")
        outact_idx = self.builder.add_activation(masked)
        inidx = self.builder.get_activation_index(attn_weight)
        op_attn_mask = Operator(
            name=masked.name,
            options=layer_options.StatefulAttentionMaskWrapperOptions(
                inputs=(inidx,),
                outputs=(outact_idx,),
                past_seqlen=past_seq_len,
            ),
        )
        self.builder.add_operator(op_attn_mask)
        return masked

    def scaled_dot_product_attention(
        self,
        query: ActivationSpec,
        key: ActivationSpec,
        value: ActivationSpec,
        attn_mask: Optional[ActivationSpec] = None,
        is_causal=True,
        past_seq_len: int = 0,
        opname="",
    ):
        if not opname:
            opname = "scaled_dot_product_attention"

        scale_factor = 1 / math.sqrt(int(query.get_act_src_shape()[-1]))

        k_transpose = self.builder.make_transpose(
            key, (0, 1, 3, 2), opname + "/transpose_k"
        )
        attn_weight = self.builder.make_matmul(
            query, k_transpose, opname + "/attn_weight"
        )
        attn_weight = self.builder.make_mul(
            attn_weight, scale_factor, opname=opname + "/scale"
        )
        if is_causal or attn_mask is not None:
            attn_weight = self.apply_attention_mask(
                attn_weight, attn_mask, past_seq_len=past_seq_len
            )

        attn_weight = self.builder.make_softmax(
            attn_weight, axis=-1, beta=0, opname=opname + "/softmax"
        )

        return self.builder.make_matmul(attn_weight, value, opname + "/attn_value")


@llama_registry.add_to_registry(hf_modeling_llama.LlamaSdpaAttention)
class LlamaSdpaAttention(LlamaAttention):
    __slots__ = (
        "q_proj",
        "v_proj",
        "k_proj",
        "o_proj",
        "num_heads",
        "head_dim",
        "num_key_value_heads",
        "rotary_emb",
        "num_key_value_groups",
    )

    # fmt:off
    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        past_key_value: Optional["Cache"] = None,
        output_attentions: bool = False,
        use_cache: bool = False,
        cache_position: Optional[ActivationSpec] = None,
        position_embeddings: Optional[Tuple[ActivationSpec, ActivationSpec]] = None,  # will become mandatory in v4.46
        slice_seq_last_n: Optional[int] = None,
        **kwargs,
    ):
        # fmt:on
        bsz, q_len, _ = hidden_states.get_act_src_shape()

        query_states = self.q_proj(hidden_states) # (1,56, 3072)
        key_states = self.k_proj(hidden_states) # (1, 56, 1024)
        value_states = self.v_proj(hidden_states) # (1, 56, 1024)

        # fmt:off
        query_states = self.qkv_reshape_transpose(query_states, (bsz, q_len, self.num_heads, self.head_dim), (0, 2, 1, 3)) # (1,24,56,128)
        key_states = self.qkv_reshape_transpose(key_states, (bsz, q_len, self.num_key_value_heads, self.head_dim), (0, 2, 1, 3)) # (1,8,56,128)
        value_states = self.qkv_reshape_transpose(value_states, (bsz, q_len, self.num_key_value_heads, self.head_dim), (0, 2, 1, 3)) # (1,8,56,128)
        # fmt:on

        if position_embeddings is None:
            cos, sin = self.rotary_emb(value_states,None)
        else:
            cos, sin = position_embeddings
        query_states, key_states = self.apply_rotary_pos_emb(
            query_states, key_states, cos, sin
        )
        if slice_seq_last_n is not None:
            query_states = self.builder.make_slice(
                query_states,
                axis=(2,),
                start=(-slice_seq_last_n,),
                end=(int(numpy.iinfo(numpy.int32).max),),
                step=(1,),
            )
            for x in query_states.src_shape:
                if x.dynamic:
                    x._dynamic = False

        key_states, value_states = self.past_kv_update(
            key_states, value_states, past_key_value
        )

        key_states = self.repeat_kv(key_states, self.num_key_value_groups) # (1,24,56,128)
        value_states = self.repeat_kv(value_states, self.num_key_value_groups) # (1,24,56,128)

        causal_mask = attention_mask
        if attention_mask is not None:  # no matter the length, we just slice it
            raise NotImplementedError
            # causal_mask = attention_mask[:, :, :, : key_states.shape[-2]]

        # We dispatch to SDPA's Flash Attention or Efficient kernels via this `is_causal` if statement instead of an inline conditional assignment
        # in SDPA to support both torch.compile's dynamic shapes and full graph options. An inline conditional prevents dynamic shapes from compiling.
        is_causal = True if causal_mask is None and q_len > 1 else False

        # attn_output = torch.nn.functional.scaled_dot_product_attention(
        #     query_states,
        #     key_states,
        #     value_states,
        #     attn_mask=causal_mask,
        #     dropout_p=self.attention_dropout if self.training else 0.0,
        #     is_causal=is_causal,
        # )
        attn_output = self.builder.make_torch_scaled_dot_product_attention(
            query_states,
            key_states,
            value_states,
            attn_mask=causal_mask,
            is_causal   =is_causal,
            past_seq_len=past_key_value.past_seq_len,
        ) # (1,24,56,128)

        # attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = self.builder.make_transpose(attn_output, (0, 2, 1, 3))  # (1,56,24,128)
        # attn_output = attn_output.view(bsz, q_len, -1)
        if slice_seq_last_n is not None:
            q_len = slice_seq_last_n
        attn_output = self.builder.make_reshape(attn_output,(bsz, q_len,-1)) # (1,56,3072)
        attn_output = self.o_proj(attn_output) # (1,56,3072)

        return attn_output, None, past_key_value


    def qkv_reshape_transpose(
        self, states: ActivationSpec, new_shape, transpose_axes=(0, 2, 1, 3)
    ):
        states = self.builder.make_reshape(
            states, new_shape, new_dataformat=DataFormat.NHWC
        )
        return self.builder.make_transpose(states, transpose_axes=transpose_axes)


@llama_registry.add_to_registry(hf_modeling_llama.LlamaMLP)
class LlamaMLP(ModelingLlamaBase):
    __slots__ = ("down_proj", "up_proj", "gate_proj", "act_fn")

    def forward(self, x: ActivationSpec):
        gate_proj = self.gate_proj(x)
        up_proj = self.up_proj(x)
        act_fn = self.act_fn(gate_proj)
        mul = self.builder.make_mul(act_fn, up_proj)
        down_proj = self.down_proj(mul)
        return down_proj


@llama_registry.add_to_registry(hf_modeling_llama.LlamaRMSNorm)
class LlamaRMSNorm(ModelingLlamaBase):
    __slots__ = ("variance_epsilon", "weight")

    def forward(self, hidden_states: ActivationSpec):
        return self.builder.make_rmsnorm(
            hidden_states,
            epsilon=self.variance_epsilon,
            scale=self.weight,
            opname=self.module_name,
        )


@llama_registry.add_to_registry(hf_modeling_llama.LlamaDecoderLayer)
class LlamaDecoderLayer(ModelingLlamaBase):
    __slots__ = ("input_layernorm", "self_attn", "post_attention_layernorm", "mlp")

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    def _get_self_attn(self, self_attn, module_name):
        if isinstance(self_attn, hf_modeling_llama.LlamaSdpaAttention):
            return LlamaSdpaAttention(self_attn, module_name)
        else:
            raise NotImplementedError(f"self_attention_type={type(self_attn)}")

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        past_key_value: Optional["Cache"] = None,
        output_attentions: Optional[bool] = False,
        use_cache: Optional[bool] = False,
        cache_position: Optional[ActivationSpec] = None,
        position_embeddings: Optional[
            Tuple[ActivationSpec, ActivationSpec]
        ] = None,  # will become mandatory in v4.46
        slice_seq_last_n: Optional[int] = None,
        **kwargs,
    ) -> Tuple[
        torch.FloatTensor, Optional[Tuple[torch.FloatTensor, torch.FloatTensor]]
    ]:
        residual = hidden_states  # torch.Size([1, 56, 3072])

        hidden_states = self.input_layernorm(hidden_states)  # torch.Size([1, 56, 3072])

        # Self Attention
        hidden_states, self_attn_weights, present_key_value = self.self_attn(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_value=past_key_value,
            output_attentions=output_attentions,
            use_cache=use_cache,
            cache_position=cache_position,
            position_embeddings=position_embeddings,
            slice_seq_last_n=slice_seq_last_n,
            **kwargs,
        )

        if slice_seq_last_n is not None:
            residual = self.builder.make_slice(
                residual,
                axis=(1,),
                start=(-slice_seq_last_n,),
                end=(int(numpy.iinfo(numpy.int32).max),),
                step=(1,),
            )
            for x in residual.src_shape:
                if x.dynamic:
                    x._dynamic = False

        hidden_states = self.builder.make_add(
            residual, hidden_states, opname=self.module_name + "/add0"
        )

        # Fully Connected
        residual = hidden_states
        hidden_states = self.post_attention_layernorm(
            hidden_states
        )  # torch.Size([1, 56, 3072])
        hidden_states = self.mlp(hidden_states)  # torch.Size([1, 56, 3072])
        hidden_states = self.builder.make_add(
            residual, hidden_states, opname=self.module_name + "/add1"
        )  # torch.Size([1, 56, 3072])

        outputs = (hidden_states,)
        if output_attentions:
            outputs += (self_attn_weights,)

        if use_cache:
            outputs += (present_key_value,)

        return outputs


@llama_registry.add_to_registry(hf_modeling_llama.LlamaModel)
class LlamaModel(ModelingLlamaBase):
    __slots__ = ("embed_tokens", "norm", "rotary_emb", "layers", "config")

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)
        # configs
        self.rope_max_seqlen = 8192
        self.block_selection = list(range(len(self.layers)))  # for development purpose

    def forward(
        self,
        input_ids: ActivationSpec = None,
        attention_mask: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        past_key_values: Optional[Union["Cache", List[torch.FloatTensor]]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[ActivationSpec] = None,
        **kwargs,
    ) -> Union[Tuple, BaseModelOutputWithPast]:
        output_attentions = (
            output_attentions
            if output_attentions is not None
            else self.config.output_attentions
        )
        output_hidden_states = (
            output_hidden_states
            if output_hidden_states is not None
            else self.config.output_hidden_states
        )
        use_cache = use_cache if use_cache is not None else self.config.use_cache
        return_dict = (
            return_dict if return_dict is not None else self.config.use_return_dict
        )

        if (input_ids is None) ^ (inputs_embeds is not None):
            raise ValueError(
                "You must specify exactly one of input_ids or inputs_embeds"
            )

        seq_len = input_ids.get_act_src_shape()[-1]

        # if self.gradient_checkpointing and self.training and use_cache:
        #     logger.warning_once(
        #         "`use_cache=True` is incompatible with gradient checkpointing. Setting `use_cache=False`."
        #     )
        #     use_cache = False

        if inputs_embeds is None:
            inputs_embeds = self.embed_tokens(input_ids)  # (1,56,3072)
        # kept for BC (non `Cache` `past_key_values` inputs)

        return_legacy_cache = False
        # if use_cache and not isinstance(past_key_values, Cache):
        #     return_legacy_cache = True
        #     if past_key_values is None:
        #         past_key_values = DynamicCache()
        #     else:
        #         past_key_values = DynamicCache.from_legacy_cache(past_key_values)
        #         logger.warning_once(
        #             "We detected that you are passing `past_key_values` as a tuple of tuples. This is deprecated and "
        #             "will be removed in v4.47. Please convert your cache or use an appropriate `Cache` class "
        #             "(https://huggingface.co/docs/transformers/kv_cache#legacy-cache-format)"
        #         )

        if cache_position is None:
            raise NotImplementedError
            # past_seen_tokens = past_key_values.get_seq_length() if past_key_values is not None else 0
            # cache_position = torch.arange(
            #     past_seen_tokens, past_seen_tokens + inputs_embeds.shape[1], device=inputs_embeds.device
            # )
        if position_ids is None:
            raise NotImplementedError
            # position_ids = cache_position.unsqueeze(0)

        # causal_mask = self._update_causal_mask(
        #     attention_mask, inputs_embeds, cache_position, past_key_values, output_attentions
        # )
        causal_mask = None

        hidden_states = inputs_embeds  # torch.Size([1, 56, 3072])

        # create position embeddings to be shared across the decoder layers
        position_embeddings = self.rotary_emb(hidden_states, position_ids=None)

        # decoder layers
        all_hidden_states = () if output_hidden_states else None
        all_self_attns = () if output_attentions else None
        next_decoder_cache = None

        # decoder layers
        decoders = [self.layers[idx] for idx in self.block_selection]

        for idx, decoder_layer in enumerate(decoders):
            slice_seq_last_n = None
            if idx == len(decoders) - 1:
                slice_seq_last_n = kwargs.get("slice_seq_last_n", None)

            layer_outputs = decoder_layer(
                hidden_states,
                attention_mask=causal_mask,
                position_ids=position_ids,
                past_key_value=past_key_values,
                output_attentions=output_attentions,
                use_cache=use_cache,
                cache_position=cache_position,
                position_embeddings=position_embeddings,
                slice_seq_last_n=slice_seq_last_n,
            )
            hidden_states = layer_outputs[0]  # torch.Size([1, 56, 3072])

            if use_cache:
                next_decoder_cache = layer_outputs[2 if output_attentions else 1]

            if output_attentions:
                all_self_attns += (layer_outputs[1],)

        hidden_states = self.norm(hidden_states)  # torch.Size([1, 56, 3072])

        # add hidden states from the last decoder layer
        if output_hidden_states:
            all_hidden_states += (hidden_states,)

        next_cache = None
        if use_cache:
            next_cache = past_key_values.get_updated(int(seq_len))
        if return_legacy_cache:
            raise NotImplementedError
            # next_cache = next_cache.to_legacy_cache()

        if not return_dict:
            return tuple(
                v
                for v in [hidden_states, next_cache, all_hidden_states, all_self_attns]
                if v is not None
            )
        return BaseModelOutputWithPast(
            last_hidden_state=hidden_states,
            past_key_values=next_cache,
            hidden_states=all_hidden_states,
            attentions=all_self_attns,
        )


@llama_registry.add_to_registry(hf_modeling_llama.LlamaForCausalLM)
class LlamaForCausalLM(ModelingLlamaBase):
    __slots__ = ("model", "lm_head", "config")

    def forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[ActivationSpec] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Any] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        num_logits_to_keep: int = 0,
        **kwargs,
    ) -> Union[Tuple, CausalLMOutputWithPast]:
        # fmt: off
        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = (
            output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        )
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict
        # fmt: on

        slice_seq_last_n = kwargs.get("slice_seq_last_n", None)
        # decoder outputs consists of (dec_features, layer_state, dec_hidden, dec_attn)
        outputs = self.model(
            input_ids=input_ids,  # (1,56)
            attention_mask=attention_mask,  # (1,56)
            position_ids=position_ids,  # (1,56)
            past_key_values=past_key_values,  # DynamicCache()
            inputs_embeds=inputs_embeds,  # None
            use_cache=use_cache,  # True
            output_attentions=output_attentions,  # False
            output_hidden_states=output_hidden_states,  # False
            return_dict=return_dict,  # True
            cache_position=cache_position,  # (56,)
            slice_seq_last_n=slice_seq_last_n,
        )
        hidden_states = outputs[0]
        if self.config.pretraining_tp > 1:
            raise NotImplementedError
            # lm_head_slices = self.lm_head.weight.split(self.vocab_size // self.config.pretraining_tp, dim=0)
            # logits = [F.linear(hidden_states, lm_head_slices[i]) for i in range(self.config.pretraining_tp)]
            # logits = torch.cat(logits, dim=-1)
        else:
            # Only compute necessary logits, and do not upcast them to float if we are not computing the loss
            if num_logits_to_keep > 0:
                raise NotImplementedError
                # logits = self.lm_head(hidden_states[:, -num_logits_to_keep:, :])
            else:
                logits = self.lm_head(hidden_states)

        loss = None
        if labels is not None:
            raise NotImplementedError
            # loss = self.loss_function(logits=logits, labels=labels, vocab_size=self.config.vocab_size, **loss_kwargs)

        if not return_dict:
            output = (logits,) + outputs[1:]
            return (loss,) + output if loss is not None else output

        return CausalLMOutputWithPast(
            loss=loss,
            logits=logits,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )
