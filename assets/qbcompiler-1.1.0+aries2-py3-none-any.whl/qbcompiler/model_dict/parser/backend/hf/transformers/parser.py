import importlib

from qbcompiler.model_dict.common.parserabc import (
    ParserABC,
    MobilintParserInputs,
    MobilintParserOutputs,
)

# fmt: off
_HF_TRANSFORMERS_BASE_PATH = "qbcompiler.model_dict.parser.backend.hf.transformers.models"
_HF_TRANSFORMERS_MODELS = {
    ("transformers.models.bert.modeling_bert", "BertModel"): ("bert", "parse_bert_model"),
    ("transformers.models.bert.modeling_bert", "BertForMaskedLM"): ("bert", "parse_bert_for_masked_lm"),
    ("transformers.models.qwen2.modeling_qwen2", "Qwen2ForCausalLM"): ("qwen2", "parse_qwen2_for_causal_lm"),
    ("transformers.models.llama.modeling_llama", "LlamaForCausalLM"): ("llama", "parse_llama_for_causal_lm"),
    ("transformers.models.exaone.modeling_exaone", "ExaoneForCausalLM"): ("exaone", "parse_exaone_for_causal_lm"),
}
# fmt: on


"""
todo: 
    2. 각 모델 파싱할 때 파싱용 인풋 등을 어떻게 다룰지 일관성 있는 방법 구상.
    3. 여기 class 없애고 간단한 함수 하나로.
"""


class HFTransformersParser(ParserABC):
    def __init__(self, model, temp_dir: str, seed: int = 12345, **kwargs):
        super().__init__("", "hf", seed)
        self.model = model
        self._temp_dir = temp_dir

    def parse(
        self, parser_inputs: MobilintParserInputs, **kwargs
    ) -> MobilintParserOutputs:
        module_name = self.model.__class__.__module__
        cls_name = self.model.__class__.__name__
        parse_module_path = parse_fn_name = None
        if (module_name, cls_name) not in _HF_TRANSFORMERS_MODELS:
            for tm in _HF_TRANSFORMERS_MODELS:
                if cls_name == tm[1]:
                    parse_module_path, parse_fn_name = _HF_TRANSFORMERS_MODELS[tm]
                    break
        else:
            parse_module_path, parse_fn_name = _HF_TRANSFORMERS_MODELS[
                (module_name, cls_name)
            ]
        if parse_module_path is None:
            raise NotImplementedError(f"{type(self.model)} not implemented")
        parser_module = importlib.import_module(
            ".".join([_HF_TRANSFORMERS_BASE_PATH, parse_module_path])
        )
        parse_fn = getattr(parser_module, parse_fn_name)
        return parse_fn(self.model, parser_inputs, **kwargs)
