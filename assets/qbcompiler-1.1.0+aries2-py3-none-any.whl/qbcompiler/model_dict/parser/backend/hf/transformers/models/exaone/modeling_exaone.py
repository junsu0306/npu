import abc
from typing import Any, Optional, Union, Tuple

import numpy
import torch

from qbcompiler.model_dict.common import ActivationSpec, DataFormat
from qbcompiler.model_dict.parser.backend.hf.transformers.modeling_outputs import (
    BaseModelOutputWithPast,
    CausalLMOutputWithPast,
)
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase
from qbcompiler.model_dict.parser.backend.modeling_torch.util import MakeDynamicObject

_EXAONE_MODULE_PATH = (
    "qbcompiler/model_dict/parser/backend/hf/transformers/models/exaone/modeling_exaone"
)
_DYN_MODULE_PATH = {}

_MODULE_CLASS_PATH = {
    "ExaoneForCausalLM": _EXAONE_MODULE_PATH,
    "ExaoneModel": _EXAONE_MODULE_PATH,
    "ExaoneBlock": _EXAONE_MODULE_PATH,
    "ExaoneRMSNorm": _EXAONE_MODULE_PATH,
    "ExaoneRotaryEmbedding": _EXAONE_MODULE_PATH,
    "ExaoneAttention": _EXAONE_MODULE_PATH,
    "ExaoneGatedMLP": _EXAONE_MODULE_PATH,
    "ExaoneSdpaAttention": _EXAONE_MODULE_PATH,
}

make_dynamic_object = MakeDynamicObject(_DYN_MODULE_PATH, _MODULE_CLASS_PATH)


class ModelingExaoneBase(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(self, model: Any, module_name: str = "", make_module_func=None):
        super().__init__(model, module_name, make_module_func=make_dynamic_object)


class ExaoneModel(ModelingExaoneBase):
    __slots__ = ("config", "training", "drop", "rotary", "wte", "h")

    def forward(
        self,
        input_ids: Optional[ActivationSpec] = None,
        attention_mask: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        past_key_values: Optional["Cache"] = None,
        inputs_embeds: Optional[ActivationSpec] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[ActivationSpec] = None,
        **kwargs,
    ) -> Union[Tuple[ActivationSpec], BaseModelOutputWithPast]:
        output_attentions = (
            output_attentions
            if output_attentions is not None
            else self.config.output_attentions
        )
        output_hidden_states = (
            output_hidden_states
            if output_hidden_states is not None
            else self.config.output_hidden_states
        )
        use_cache = use_cache if use_cache is not None else self.config.use_cache
        return_dict = (
            return_dict if return_dict is not None else self.config.use_return_dict
        )

        if input_ids is not None and inputs_embeds is not None:
            raise ValueError(
                "You cannot specify both input_ids and inputs_embeds at the same time"
            )
        elif input_ids is not None:
            # batch_size, seq_length = input_ids.shape[:2]  # 1, 42
            batch_size, seq_length = input_ids.get_act_src_shape()[:2]
        elif inputs_embeds is not None:
            batch_size, seq_length = inputs_embeds.get_act_src_shape()[:2]
        else:
            raise ValueError("You have to specify either input_ids or inputs_embeds")

        return_legacy_cache = False
        # if (
        #     use_cache and not isinstance(past_key_values, Cache) and not self.training
        # ):  # kept for BC (non `Cache` `past_key_values` inputs)
        #     return_legacy_cache = True
        #     past_key_values = DynamicCache.from_legacy_cache(past_key_values)
        #     logger.warning_once(
        #         "We detected that you are passing `past_key_values` as a tuple and this is deprecated and will be removed in v4.43. "
        #         "Please use an appropriate `Cache` class (https://huggingface.co/docs/transformers/v4.41.3/en/internal/generation_utils#transformers.Cache)"
        #     )

        if inputs_embeds is None:
            inputs_embeds = self.wte(input_ids)  # torch.Size([1, 42, 2560])

        if cache_position is None:
            past_seen_tokens = (
                past_key_values.get_seq_length() if past_key_values is not None else 0
            )
            cache_position = torch.arange(
                past_seen_tokens,
                past_seen_tokens + inputs_embeds.shape[1],
                device=inputs_embeds.device,
            )
        if position_ids is None:
            position_ids = cache_position.unsqueeze(0)

        # causal_mask = self._update_causal_mask(
        #     attention_mask,
        #     inputs_embeds,
        #     cache_position,
        #     past_key_values,
        #     output_attentions,
        # )  # None
        causal_mask = None

        hidden_states = inputs_embeds  # torch.Size([1, 42, 2560])
        hidden_states = self.drop(hidden_states)

        position_embeddings = self.rotary(
            hidden_states, None
        )  # (torch.Size([1, 42, 80]), torch.Size([1, 42, 80]))

        all_hidden_states = () if output_hidden_states else None
        all_self_attns = () if output_attentions else None
        next_decoder_cache = None

        for idx, block in enumerate(self.h):
            if output_hidden_states:
                all_hidden_states = all_hidden_states + (hidden_states,)
            slice_seq_last_n = None
            if idx == len(self.h) - 1:
                slice_seq_last_n = kwargs.get("slice_seq_last_n", None)

            outputs = block(
                hidden_states,
                attention_mask=causal_mask,
                position_ids=position_ids,
                past_key_value=past_key_values,
                output_attentions=output_attentions,
                use_cache=use_cache,
                cache_position=cache_position,
                position_embeddings=position_embeddings,
                slice_seq_last_n=slice_seq_last_n,
            )

            hidden_states = outputs[0]
            if use_cache:
                next_decoder_cache = outputs[2 if output_attentions else 1]

            if output_attentions:
                all_self_attns += (outputs[1],)

        hidden_states = self.ln_f(hidden_states)  # torch.Size([1, 1, 2560])
        # Add last hidden state
        if output_hidden_states:
            all_hidden_states += (hidden_states,)

        next_cache = None
        if use_cache:
            # next_cache = (
            #     next_decoder_cache.to_legacy_cache()
            #     if return_legacy_cache
            #     else next_decoder_cache
            # )
            next_cache = past_key_values.get_updated(int(seq_length))
        if not return_dict:
            return tuple(
                v
                for v in [hidden_states, next_cache, all_hidden_states, all_self_attns]
                if v is not None
            )

        return BaseModelOutputWithPast(
            last_hidden_state=hidden_states,
            past_key_values=next_cache,
            hidden_states=all_hidden_states,
            attentions=all_self_attns,
        )

    # def _update_causal_mask(
    #     self,
    #     attention_mask: torch.Tensor,
    #     input_tensor: torch.Tensor,
    #     cache_position: torch.Tensor,
    #     past_key_values: "Cache",
    #     output_attentions: bool,
    # ):
    #     # TODO: As of torch==2.2.0, the `attention_mask` passed to the model in `generate` is 2D and of dynamic length even when the static
    #     # KV cache is used. This is an issue for torch.compile which then recaptures cudagraphs at each decode steps due to the dynamic shapes.
    #     # (`recording cudagraph tree for symint key 13`, etc.), which is VERY slow. A workaround is `@torch.compiler.disable`, but this prevents using
    #     # `fullgraph=True`. See more context in https://github.com/huggingface/transformers/pull/29114
    #
    #     if self.config._attn_implementation == "flash_attention_2":
    #         if attention_mask is not None and 0.0 in attention_mask:
    #             return attention_mask
    #         return None
    #
    #     # For SDPA, when possible, we will rely on its `is_causal` argument instead of its `attn_mask` argument, in
    #     # order to dispatch on Flash Attention 2. This feature is not compatible with static cache, as SDPA will fail
    #     # to infer the attention mask.
    #     past_seen_tokens = (
    #         past_key_values.get_seq_length() if past_key_values is not None else 0
    #     )
    #     using_static_cache = isinstance(past_key_values, StaticCache)
    #
    #     # When output attentions is True, sdpa implementation's forward method calls the eager implementation's forward
    #     if (
    #         self.config._attn_implementation == "sdpa"
    #         and not using_static_cache
    #         and not output_attentions
    #     ):
    #         if AttentionMaskConverter._ignore_causal_mask_sdpa(
    #             attention_mask,
    #             inputs_embeds=input_tensor,
    #             past_key_values_length=past_seen_tokens,
    #             is_training=self.training,
    #         ):
    #             return None
    #
    #     dtype, device = input_tensor.dtype, input_tensor.device
    #     min_dtype = torch.finfo(dtype).min
    #     sequence_length = input_tensor.shape[1]
    #     if using_static_cache:
    #         target_length = past_key_values.get_max_length()
    #     else:
    #         target_length = (
    #             attention_mask.shape[-1]
    #             if isinstance(attention_mask, torch.Tensor)
    #             else past_seen_tokens + sequence_length + 1
    #         )
    #
    #     # In case the provided `attention` mask is 2D, we generate a causal mask here (4D).
    #     causal_mask = _prepare_4d_causal_attention_mask_with_cache_position(
    #         attention_mask,
    #         sequence_length=sequence_length,
    #         target_length=target_length,
    #         dtype=dtype,
    #         device=device,
    #         min_dtype=min_dtype,
    #         cache_position=cache_position,
    #         batch_size=input_tensor.shape[0],
    #     )
    #
    #     if (
    #         self.config._attn_implementation == "sdpa"
    #         and attention_mask is not None
    #         and attention_mask.device.type == "cuda"
    #         and not output_attentions
    #     ):
    #         # Attend to all tokens in fully masked rows in the causal_mask, for example the relevant first rows when
    #         # using left padding. This is required by F.scaled_dot_product_attention memory-efficient attention path.
    #         # Details: https://github.com/pytorch/pytorch/issues/110213
    #         causal_mask = AttentionMaskConverter._unmask_unattended(
    #             causal_mask, min_dtype
    #         )
    #
    #     return causal_mask


class ExaoneForCausalLM(ModelingExaoneBase):
    __slots__ = ("config", "transformer", "lm_head")

    def __init__(self, model: Any, module_name: str = "", make_module_func=None):
        super().__init__(model, module_name, make_module_func)

    def forward(
        self,
        input_ids: Optional[ActivationSpec] = None,
        attention_mask: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        past_key_values: Optional["Cache"] = None,
        inputs_embeds: Optional[ActivationSpec] = None,
        labels: Optional[ActivationSpec] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[ActivationSpec] = None,
        **kwargs,
    ) -> Union[Tuple[ActivationSpec], BaseModelOutputWithPast]:
        output_attentions = (
            output_attentions
            if output_attentions is not None
            else self.config.output_attentions
        )
        output_hidden_states = (
            output_hidden_states
            if output_hidden_states is not None
            else self.config.output_hidden_states
        )
        return_dict = (
            return_dict if return_dict is not None else self.config.use_return_dict
        )

        slice_seq_last_n = kwargs.get("slice_seq_last_n", None)
        transformer_outputs = self.transformer(
            input_ids,
            attention_mask=attention_mask,
            past_key_values=past_key_values,
            position_ids=position_ids,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            cache_position=cache_position,
            slice_seq_last_n=slice_seq_last_n,
        )
        hidden_states = transformer_outputs[0]  # torch.Size([1, 1, 2560])
        lm_logits = self.lm_head(hidden_states)  # torch.Size([1, 1, 102400])
        # lm_logits = lm_logits.float()
        loss = None
        if labels is not None:
            raise NotImplementedError
        #     lm_logits = lm_logits.to(torch.float32)
        #
        #     # Shift so that tokens < n predict n
        #     shift_logits = lm_logits[..., :-1, :].contiguous()
        #     shift_labels = labels[..., 1:].contiguous()
        #     # Flatten the tokens
        #     loss_fct = CrossEntropyLoss()
        #     loss = loss_fct(
        #         shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1)
        #     )
        #
        #     lm_logits = lm_logits.to(hidden_states.dtype)
        #     loss = loss.to(hidden_states.dtype)

        if not return_dict:
            output = (lm_logits,) + transformer_outputs[1:]
            return ((loss,) + output) if loss is not None else output

        return CausalLMOutputWithPast(
            loss=loss,
            logits=lm_logits,
            past_key_values=transformer_outputs.past_key_values,
            hidden_states=transformer_outputs.hidden_states,
            attentions=transformer_outputs.attentions,
        )


class ExaoneBlock(ModelingExaoneBase):
    __slots__ = ("ln_1", "attn", "ln_2", "mlp")

    def __init__(self, model: Any, module_name: str = "", make_module_func=None):
        super().__init__(model, module_name, make_module_func)

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        past_key_value: Optional["Cache"] = None,
        output_attentions: Optional[bool] = False,
        use_cache: Optional[bool] = False,
        cache_position: Optional[ActivationSpec] = None,
        position_embeddings: Optional[Tuple[ActivationSpec, ActivationSpec]] = None,
        slice_seq_last_n: Optional[int] = None,
        **kwargs,
    ) -> Tuple[
        torch.FloatTensor, Optional[Tuple[torch.FloatTensor, torch.FloatTensor]]
    ]:
        residual = hidden_states  # torch.Size([1, 42, 2560])
        hidden_states = self.ln_1(hidden_states)  # torch.Size([1, 42, 2560])

        hidden_states, self_attn_weights, present_key_value = self.attn(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_value=past_key_value,
            output_attentions=output_attentions,
            use_cache=use_cache,
            cache_position=cache_position,
            position_embeddings=position_embeddings,
            slice_seq_last_n=slice_seq_last_n,
            **kwargs,
        )  # torch.Size([1, 42, 2560]), None
        if slice_seq_last_n is not None:
            residual = self.builder.make_slice(
                residual,
                axis=(1,),
                start=(-slice_seq_last_n,),
                end=(int(numpy.iinfo(numpy.int32).max),),
                step=(1,),
            )
            for x in residual.src_shape:
                if x.dynamic:
                    x._dynamic = False

        # residual connection
        # hidden_states = residual + hidden_states
        hidden_states = self.builder.make_add(
            residual, hidden_states, opname=self.module_name + "/add0"
        )

        residual = hidden_states
        hidden_states = self.ln_2(hidden_states)  # torch.Size([1, 42, 2560])
        hidden_states = self.mlp(hidden_states)  # torch.Size([1, 42, 2560])

        # hidden_states = residual + hidden_states
        hidden_states = self.builder.make_add(
            residual, hidden_states, opname=self.module_name + "/add1"
        )
        outputs = (hidden_states,)

        if output_attentions:
            outputs += (self_attn_weights,)

        if use_cache:
            outputs += (present_key_value,)

        return outputs


def apply_rotary_pos_emb(q, k, cos, sin, unsqueeze_dim=1):
    """Applies Rotary Position Embedding to the query and key tensors.

    Args:
        q (`torch.Tensor`): The query tensor.
        k (`torch.Tensor`): The key tensor.
        cos (`torch.Tensor`): The cosine part of the rotary embedding.
        sin (`torch.Tensor`): The sine part of the rotary embedding.
        unsqueeze_dim (`int`, *optional*, defaults to 1):
            The 'unsqueeze_dim' argument specifies the dimension along which to unsqueeze cos[position_ids] and
            sin[position_ids] so that they can be properly broadcasted to the dimensions of q and k. For example, note
            that cos[position_ids] and sin[position_ids] have the shape [batch_size, seq_len, head_dim]. Then, if q and
            k have the shape [batch_size, heads, seq_len, head_dim], then setting unsqueeze_dim=1 makes
            cos[position_ids] and sin[position_ids] broadcastable to the shapes of q and k. Similarly, if q and k have
            the shape [batch_size, seq_len, heads, head_dim], then set unsqueeze_dim=2.
    Returns:
        `tuple(torch.Tensor)` comprising of the query and key tensors rotated using the Rotary Position Embedding.
    """
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


def rotate_half(x):
    """Rotates half the hidden dims of the input."""
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2 :]
    return torch.cat((-x2, x1), dim=-1)


class ExaoneAttention(ModelingExaoneBase):
    __slots__ = ("attention",)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value: Optional["Cache"] = None,
        output_attentions: Optional[bool] = False,
        use_cache: Optional[bool] = False,
        cache_position: Optional[torch.LongTensor] = None,
        position_embeddings: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        slice_seq_last_n: Optional[int] = None,
        **kwargs,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
        return self.attention(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_value=past_key_value,
            output_attentions=output_attentions,
            use_cache=use_cache,
            cache_position=cache_position,
            position_embeddings=position_embeddings,
            slice_seq_last_n=slice_seq_last_n,
            **kwargs,
        )


def repeat_kv(self, hidden_states: ActivationSpec, num_repeat):
    return self.builder.make_repeat_n(hidden_states, num_repeat)


class ExaoneSelfAttention(ModelingExaoneBase):
    def repeat_kv(self, hidden_states: ActivationSpec, num_repeat):
        return self.builder.make_repeat_n(hidden_states, num_repeat)

    def qkv_reshape_transpose(self, states, new_shape, transpose_axes=(0, 2, 1, 3)):
        states = self.builder.make_reshape(
            states, new_shape, new_dataformat=DataFormat.NHWC
        )
        return self.builder.make_transpose(states, transpose_axes)

    def apply_rotary_pos_emb(
        self,
        q: ActivationSpec,
        k: ActivationSpec,
        cos: ActivationSpec,
        sin: ActivationSpec,
    ):
        q_rope = self.builder.make_stateful_rope_wrapper(
            q, cos, sin, self.module_name + "/q_rope"
        )
        k_rope = self.builder.make_stateful_rope_wrapper(
            k, cos, sin, self.module_name + "/k_rope"
        )
        return q_rope, k_rope

    def past_kv_update(
        self, key: ActivationSpec, value: ActivationSpec, past_key_value: "DynamicCache"
    ):
        updates = []
        for x in (key, value):
            updates.append(
                self.builder.make_stateful_kvcache_wrapper(
                    x, x.name, past_key_value.past_seq_len, opname=x.name + "/cache"
                )
            )
        return tuple(updates)


class ExaoneSdpaAttention(ExaoneSelfAttention):
    __slots__ = (
        "q_proj",
        "k_proj",
        "v_proj",
        "num_heads",
        "head_dim",
        "num_key_value_heads",
        "num_key_value_groups",
        "layer_idx",
        "embed_dim",
    )

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value: Optional["Cache"] = None,
        output_attentions: Optional[bool] = False,
        use_cache: Optional[bool] = False,
        cache_position: Optional[torch.LongTensor] = None,
        position_embeddings: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        slice_seq_last_n: Optional[int] = None,
        **kwargs,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
        if output_attentions:
            raise NotImplementedError
            # logger.warning_once(
            #     "ExaoneModel is using ExaoneSdpaAttention, but `torch.nn.functional.scaled_dot_product_attention` does not support `output_attentions=True`. Falling back to the manual attention implementation, "
            #     'but specifying the manual implementation will be required from Transformers version v5.0.0 onwards. This warning can be removed using the argument `attn_implementation="eager"` when loading the model.'
            # )
            # return super().forward(
            #     hidden_states=hidden_states,
            #     attention_mask=attention_mask,
            #     position_ids=position_ids,
            #     past_key_value=past_key_value,
            #     output_attentions=output_attentions,
            #     use_cache=use_cache,
            #     cache_position=cache_position,
            #     position_embeddings=position_embeddings,
            #     **kwargs,
            # )

        # bsz, q_len, _ = hidden_states.size()  # 1, 42, 2560
        bsz, q_len, _ = hidden_states.get_act_src_shape()

        query_states = self.q_proj(hidden_states)  # torch.Size([1, 42, 2560])
        key_states = self.k_proj(hidden_states)  # torch.Size([1, 42, 640])
        value_states = self.v_proj(hidden_states)  # torch.Size([1, 42, 640])

        # fmt:off
        # query_states = query_states.view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)  # torch.Size([1, 32, 42, 80])
        # key_states = key_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)  # torch.Size([1, 8, 42, 80])
        # value_states = value_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)  # torch.Size([1, 8, 42, 80])
        query_states = self.qkv_reshape_transpose(query_states, (bsz, q_len, self.num_heads, self.head_dim), (0, 2, 1, 3))
        key_states = self.qkv_reshape_transpose(key_states,(bsz, q_len, self.num_key_value_heads, self.head_dim),(0, 2, 1, 3))
        value_states = self.qkv_reshape_transpose(value_states,(bsz, q_len, self.num_key_value_heads, self.head_dim),(0, 2, 1, 3))
        # fmt:on

        if position_embeddings is None:
            # cos, sin = self.rotary(value_states, position_ids=position_ids)
            cos, sin = self.rotary(value_states, position_ids=None)
        else:
            cos, sin = position_embeddings
        query_states, key_states = self.apply_rotary_pos_emb(
            query_states, key_states, cos, sin
        )
        if slice_seq_last_n is not None:
            query_states = self.builder.make_slice(
                query_states,
                axis=(2,),
                start=(-slice_seq_last_n,),
                end=(int(numpy.iinfo(numpy.int32).max),),
                step=(1,),
            )
            for x in query_states.src_shape:
                if x.dynamic:
                    x._dynamic = False

        # if past_key_value is not None:
        #     # sin and cos are specific to RoPE models; cache_position needed for the static cache
        #     cache_kwargs = {"sin": sin, "cos": cos, "cache_position": cache_position}
        #     key_states, value_states = past_key_value.update(
        #         key_states, value_states, self.layer_idx, cache_kwargs
        #     )
        key_states, value_states = self.past_kv_update(
            key_states, value_states, past_key_value
        )

        # key_states = repeat_kv(key_states, self.num_key_value_groups)  # torch.Size([1, 32, 42, 80])
        # value_states = repeat_kv(value_states, self.num_key_value_groups)  # torch.Size([1, 32, 42, 80])
        key_states = self.repeat_kv(key_states, self.num_key_value_groups)
        value_states = self.repeat_kv(value_states, self.num_key_value_groups)

        causal_mask = attention_mask  # None
        if attention_mask is not None:
            raise NotImplementedError
            # causal_mask = causal_mask[:, :, :, : key_states.shape[-2]]

        # SDPA with memory-efficient backend is currently (torch==2.1.2) bugged with non-contiguous inputs with custom attn_mask,
        # Reference: https://github.com/pytorch/pytorch/issues/112577.
        # if query_states.device.type == "cuda" and causal_mask is not None:
        #     query_states = query_states.contiguous()
        #     key_states = key_states.contiguous()
        #     value_states = value_states.contiguous()

        # We dispatch to SDPA's Flash Attention or Efficient kernels via this `is_causal` if statement instead of an inline conditional assignment
        # in SDPA to support both torch.compile's dynamic shapes and full graph options. An inline conditional prevents dynamic shapes from compiling.
        is_causal = True if causal_mask is None and q_len > 1 else False  # True

        # attn_output = torch.nn.functional.scaled_dot_product_attention(
        #     query_states,
        #     key_states,
        #     value_states,
        #     attn_mask=causal_mask,
        #     dropout_p=self.attention_dropout_rate if self.training else 0.0,
        #     is_causal=is_causal,
        # )  # torch.Size([1, 32, 42, 80])
        attn_output = self.builder.make_torch_scaled_dot_product_attention(
            query_states,
            key_states,
            value_states,
            attn_mask=attention_mask,
            is_causal=is_causal,
            past_seq_len=past_key_value.past_seq_len,
        )

        # attn_output = attn_output.transpose(1, 2).contiguous()
        # attn_output = attn_output.reshape(bsz, q_len, self.embed_dim).contiguous()
        attn_output = self.builder.make_transpose(attn_output, (0, 2, 1, 3))
        if slice_seq_last_n is not None:
            q_len = slice_seq_last_n
        attn_output = self.builder.make_reshape(
            attn_output, (bsz, q_len, self.embed_dim)
        )

        attn_output = self.out_proj(attn_output)  # torch.Size([1, 42, 2560])

        return attn_output, None, past_key_value


class ExaoneRMSNorm(ModelingExaoneBase):
    __slots__ = ("eps", "weight")

    def forward(self, hidden_states):
        # input_dtype = hidden_states.dtype
        # hidden_states = hidden_states.to(torch.float32)
        # variance = hidden_states.pow(2).mean(-1, keepdim=True)
        # hidden_states = hidden_states * torch.rsqrt(variance + self.eps)
        # return self.weight * hidden_states.to(input_dtype)
        return self.builder.make_rmsnorm(
            hidden_states,
            epsilon=self.eps,
            scale=self.weight,
            opname=self.module_name,
        )


class ExaoneRotaryEmbedding(ModelingExaoneBase):
    """This module is intentionally designed as a singleton to reuse ROPE weight."""

    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, model: Any, module_name: str = "", *args, **kwargs):
        super().__init__(model, module_name)
        self.cos = None
        self.sin = None
        self.inv_freq = model.inv_freq
        self.num_head = model.config.num_attention_heads
        self.attention_scaling = model.attention_scaling
        self.rope_max_seqlen = 8192

    def make_rope_inputconst(self):
        # fmt: off
        if self.cos is None:
            device = self.inv_freq.device
            position_ids = torch.arange(self.rope_max_seqlen, dtype=torch.int64).unsqueeze(0).to(device)
            inv_freq_expanded = self.inv_freq[None, :, None].float().expand(position_ids.shape[0], -1, 1)
            position_ids_expanded = position_ids[:, None, :].float()
            freqs = (inv_freq_expanded.float() @ position_ids_expanded.float()).transpose(1, 2)
            emb = torch.cat((freqs, freqs), dim=-1)
            emb_cos = (emb.cos() * self.attention_scaling).unsqueeze(1)
            emb_sin = (emb.sin() * self.attention_scaling).unsqueeze(1)
            self.cos = self.builder.make_inputconst(emb_cos, self.module_name + ".cos")
            self.sin = self.builder.make_inputconst(emb_sin, self.module_name + ".sin")
        # fmt: on
        return self.cos, self.sin

    def forward(self, x, position_ids):
        if position_ids is None:
            return self.make_rope_inputconst()
        else:
            raise NotImplementedError


class ExaoneGatedMLP(ModelingExaoneBase):
    __slots__ = ("c_proj", "c_fc_0", "c_fc_1", "act")

    def forward(self, hidden_states):
        # output_proj = self.c_proj(
        #     self.act(self.c_fc_0(hidden_states)) * self.c_fc_1(hidden_states)
        # )
        # return output_proj
        gate_proj = self.c_fc_0(hidden_states)
        up_proj = self.c_fc_1(hidden_states)
        act_fn = self.act(gate_proj)
        mul = self.builder.make_mul(act_fn, up_proj)
        down_proj = self.c_proj(mul)
        return down_proj
