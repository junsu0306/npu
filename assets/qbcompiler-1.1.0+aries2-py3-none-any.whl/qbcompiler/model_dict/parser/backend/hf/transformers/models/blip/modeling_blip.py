import abc
from typing import Any, Type, Optional, Union, Tuple

import numpy
import torch
import qbcompiler.mobilint_transformers.compat_transformers.models.blip.modeling_blip as hf_transformers_blip_modeling_blip

from qbcompiler.model_dict.common import ActivationSpec, DataFormat, ModelDict
from qbcompiler.model_dict.common.item_specs import DimValue
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.common.parserabc import MobilintParserOutputs
from qbcompiler.model_dict.parser.backend.hf.make_modules import make_dynamic_object
from qbcompiler.model_dict.parser.backend.hf.transformers.models.blip.sample_data import (
    get_sample_data,
)
from qbcompiler.model_dict.parser.backend.hf.util import (
    OrderedNamespace,
    DefaultInputsCaptureContainer,
    InputCaptureCtxManager,
)
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase
from qbcompiler.model_dict.parser.util.subgraph_builder import SubGraphBuilder


class KVCache:
    def __init__(self, past_seqlen=0):
        self.past_seqlen = past_seqlen

    def get_updated(self, seq_len):
        return KVCache(self.past_seqlen + seq_len)


class ModelingBlipBase(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name, make_module_func=make_dynamic_object)


class BlipForConditionalGeneration(ModelingBlipBase):
    __slots__ = (
        "config",
        "vision_model",
        "text_decoder",
        "decoder_input_ids",
        "decoder_pad_token_id",
    )

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip.BlipForConditionalGeneration

    def forward(
        self,
        pixel_values: ActivationSpec,
        input_ids: Optional[ActivationSpec] = None,
        attention_mask: Optional[ActivationSpec] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        labels: Optional[ActivationSpec] = None,
        return_dict: Optional[bool] = None,
        interpolate_pos_encoding: bool = False,
    ) -> Union[Tuple, Any]:
        raise NotImplementedError

    def _make_feed_dict(self, target, max_call_limit=1):
        inputs = get_sample_data()
        inputs_container = DefaultInputsCaptureContainer()

        target_ref_model = getattr(self.reference_model, target)
        if hasattr(self.reference_model, "device"):
            inputs = inputs.to(self.reference_model.device)
        target_fn_name = "forward"
        with InputCaptureCtxManager(
            target_ref_model,
            max_call_limit,
            inputs_container,
            target_fn_name=target_fn_name,
        ) as ctx:
            outputs = self.reference_model.generate(**inputs)
        fd = {}
        kw = {}
        if inputs_container.captured_args:
            captured_args = inputs_container.captured_args[-1]
        else:
            captured_args = []
        if inputs_container.captured_kwargs:
            captured_kwargs = inputs_container.captured_kwargs[-1]
        else:
            captured_kwargs = {}

        for k, v in captured_kwargs.items():
            if isinstance(v, torch.Tensor):
                fd[k] = v
            if k == "past_key_values":
                fd[k] = v
        kw.update(captured_kwargs)
        return fd, kw

    def _parse_with_target(self, target, interpolate_pos_encoding, feed_dict):
        if target == "vision_model":
            vision_model_builder = SubGraphBuilder({}, "vision_model")
            self.set_builder(vision_model_builder, recursive=False)
            self.vision_model.set_builder(vision_model_builder)
            if feed_dict is not None:
                _, c, h, w = feed_dict["pixel_values"].shape
            else:
                c, h, w = 3, 384, 384
            pixel_values = ActivationSpec(
                name="pixel_values",
                src_shape=(1, c, h, w),
                dtype="float32",
                dataformat=DataFormat.NCHW,
            )
            vision_model_builder.add_activation(pixel_values)
            vision_model_builder.make_input(pixel_values)

            vision_outputs = self.vision_model(
                pixel_values=pixel_values,
                interpolate_pos_encoding=interpolate_pos_encoding,
            )  # torch.Size([1, 577, 1024]), torch.Size([1, 1024]), None, None
            image_embeds = vision_outputs[0]
            self.builder.make_output(image_embeds)
        elif target == "text_decoder":
            text_decoder_builder = SubGraphBuilder({}, "text_decoder")
            self.set_builder(text_decoder_builder, recursive=False)
            self.text_decoder.set_builder(text_decoder_builder)

            encoder_hidden_states_src_shape = (
                1,
                577,
                1024,
            )  # blip_large # 768 for base
            encoder_attention_mask_src_shape = None
            past_seq_len = 0
            input_ids_src_shape = (1, DimValue(4, True))
            attention_mask_src_shape = (1, DimValue(4, True))
            if feed_dict is not None:
                encoder_hidden_states_src_shape = tuple(
                    feed_dict["encoder_hidden_states"].shape
                )
                input_ids_src_shape = (
                    1,
                    DimValue(feed_dict["input_ids"].shape[1], True),
                )
                attention_mask_src_shape = (
                    1,
                    DimValue(feed_dict["attention_mask"].shape[1], True),
                )
                if "encoder_attention_mask" in feed_dict:
                    encoder_attention_mask_src_shape = tuple(
                        feed_dict["encoder_attention_mask"].shape
                    )
                if (
                    "past_key_values" in feed_dict
                    and feed_dict["past_key_values"] is not None
                ):
                    past_seq_len = feed_dict["past_key_values"][0][0].shape[2]

            input_ids = ActivationSpec(
                name="input_ids",
                src_shape=input_ids_src_shape,
                dtype="int64",
                dataformat=DataFormat.NX,
            )
            text_decoder_builder.add_activation(input_ids)
            text_decoder_builder.make_input(input_ids)

            attention_mask = ActivationSpec(
                name="attention_mask",
                src_shape=attention_mask_src_shape,
                dtype="int64",
            )
            text_decoder_builder.add_activation(attention_mask)
            text_decoder_builder.make_input(attention_mask)

            encoder_hidden_states = ActivationSpec(
                name="encoder_hidden_states",
                src_shape=encoder_hidden_states_src_shape,
                dtype="float32",
            )
            text_decoder_builder.add_activation(encoder_hidden_states)
            text_decoder_builder.make_input(encoder_hidden_states)

            encoder_attention_mask = None
            if encoder_attention_mask_src_shape is not None:
                encoder_attention_mask = ActivationSpec(
                    name="encoder_attention_mask",
                    src_shape=encoder_attention_mask_src_shape,
                    dtype="int64",
                )
                text_decoder_builder.add_activation(encoder_attention_mask)
                text_decoder_builder.make_input(encoder_attention_mask)

            past_key_values = KVCache(past_seq_len)

            # BlipTextLMHeadModel
            outputs = self.text_decoder.forward(
                input_ids=input_ids,
                attention_mask=attention_mask,
                encoder_hidden_states=encoder_hidden_states,
                encoder_attention_mask=encoder_attention_mask,
                past_key_values=past_key_values,
            )
            logits = outputs.logits
            text_decoder_builder.make_output(logits)

        md = ModelDict()
        target_builder = self.get_builder(target)
        sg_target = target_builder.build(target, unsupported=False)
        sg_target.idx = 0
        md.subgraphs.append(sg_target)
        const_dict = target_builder._weights

        for iidx in md.sg_main().inputs:
            inact = md.sg_main().activations[iidx]
            md.inputs.append(inact.name)
        for oidx in md.sg_main().outputs:
            outact = md.sg_main().activations[oidx]
            md.outputs.append(outact.name)

        out = MobilintParserOutputs()
        out.model_dict = md
        out.value_dict = self.value_dict
        out.const_dict = const_dict
        return out

    def _make_value_dict(self, target, feed_dict, eval_kwargs):
        vd = {}
        vd.update(feed_dict)
        target_module = getattr(self, target)
        target_module.set_value_dict(vd)
        target_module.register_forward_hook()

        kw = {}
        kw.update(feed_dict)
        kw.update(eval_kwargs)

        _value_dict = ValueDict()

        for k, v in kw.items():
            if isinstance(v, torch.Tensor):
                kw[k] = v.to(target_module.reference_model.device)

        target_module.torch_compute(**kw)
        for k, v in vd.items():
            if isinstance(v, torch.Tensor):
                if v.dtype == torch.bfloat16:
                    v = v.to(torch.float32)
                v = v.detach().cpu().numpy()
            if isinstance(v, numpy.ndarray):
                _value_dict[k] = v

        return _value_dict

    def parse(
        self,
        target,
        make_value_dict=False,
        pixel_values: ActivationSpec = None,
        input_ids: Optional[ActivationSpec] = None,
        attention_mask: Optional[ActivationSpec] = None,
        interpolate_pos_encoding: bool = False,
        **kwargs,
    ) -> ActivationSpec:
        # torch.Size([1, 3, 384, 384]) (batch_size, num_channels, height, width)
        # torch.Size([1, 5]) (batch_size, seq_length)
        # torch.Size([1, 5]) (batch_size, seq_length) values selected in 0, 1

        # make feed_dict
        max_call_limit = kwargs.pop("target_sg_state", 0) + 1
        if "feed_dict" in kwargs:
            eval_kwargs = {}
            feed_dict = kwargs.pop("feed_dict")
        else:
            feed_dict, eval_kwargs = self._make_feed_dict(
                target=target, max_call_limit=max_call_limit
            )
        if "small_input_size" in kwargs:
            if "pixel_values" in feed_dict:
                feed_dict["pixel_values"] = feed_dict["pixel_values"][:, :, :64, :64]
            else:
                feed_dict["encoder_hidden_states"] = feed_dict["encoder_hidden_states"][
                    :, :17, ...
                ]
                feed_dict["encoder_attention_mask"] = feed_dict[
                    "encoder_attention_mask"
                ][:, :17]

        out = self._parse_with_target(
            target=target,
            interpolate_pos_encoding=interpolate_pos_encoding,
            feed_dict=feed_dict,
        )

        if make_value_dict:
            out.value_dict = self._make_value_dict(target, feed_dict, eval_kwargs)
        else:
            vd = ValueDict()
            vd._value_dict.update(feed_dict)
            out.value_dict = vd

        if "past_key_values" in feed_dict:
            past_key_values = feed_dict["past_key_values"]
            if past_key_values is not None:
                raise NotImplementedError
            else:
                past_seq_len = 0
            out.init_model_state = {
                0: {},
                1: {
                    "seen_tokens": past_seq_len,
                    "past_key_values": past_key_values,
                },
                2: {},
            }

        return out


class BlipVisionModel(ModelingBlipBase):
    __slots__ = ("config", "embeddings", "encoder")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip.BlipVisionModel

    def forward(
        self,
        pixel_values: Optional[ActivationSpec] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        interpolate_pos_encoding: bool = False,
    ) -> Union[Tuple, Any]:
        output_attentions = (
            output_attentions
            if output_attentions is not None
            else self.config.output_attentions
        )
        output_hidden_states = (
            output_hidden_states
            if output_hidden_states is not None
            else self.config.output_hidden_states
        )
        return_dict = (
            return_dict if return_dict is not None else self.config.use_return_dict
        )

        if pixel_values is None:
            raise ValueError("You have to specify pixel_values")

        hidden_states = self.embeddings(
            pixel_values, interpolate_pos_encoding=interpolate_pos_encoding
        )  # torch.Size([1, 577, 1024])

        encoder_outputs = self.encoder(
            inputs_embeds=hidden_states,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
        )
        #
        last_hidden_state = encoder_outputs[0]  # torch.Size([1, 577, 1024])
        last_hidden_state = self.post_layernorm(
            last_hidden_state
        )  # torch.Size([1, 577, 1024])
        self.builder.set_output_value_reference(
            last_hidden_state, output_value_reference=""
        )

        # pooled_output = last_hidden_state[:, 0, :] # torch.Size([1, 1024])
        pooled_output = self.builder.make_squeeze(
            self.builder.make_slice(last_hidden_state, axis=(1,), start=(0,), end=(1,)),
            squeeze_axes=(1,),
        )
        pooled_output = self.post_layernorm(pooled_output)  # torch.Size([1, 1024])
        self.builder.set_output_value_reference(
            pooled_output, output_value_reference="vision_model.post_layernorm"
        )

        if not return_dict:
            raise NotImplementedError
            # return (last_hidden_state, pooled_output) + encoder_outputs[1:]

        #     last_hidden_state=last_hidden_state,
        #     pooler_output=pooled_output,
        #     hidden_states=encoder_outputs.hidden_states,
        #     attentions=encoder_outputs.attentions,
        # )
        ns = OrderedNamespace()
        ns.last_hidden_state = last_hidden_state
        ns.pooler_output = pooled_output
        ns.hidden_states = encoder_outputs.hidden_states
        ns.attentions = encoder_outputs.attentions
        return ns


class BlipVisionEmbeddings(ModelingBlipBase):
    __slots__ = ("patch_embedding", "class_embedding", "position_embedding")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip.BlipVisionEmbeddings

    def forward(
        self, pixel_values: ActivationSpec, interpolate_pos_encoding: bool = False
    ):
        # batch_size, _, height, width = pixel_values.shape
        batch_size, _, height, width = pixel_values.get_act_src_shape()

        # target_dtype = self.patch_embedding.weight.dtype
        # patch_embeds = self.patch_embedding(
        #     pixel_values.to(dtype=target_dtype)
        # )  # shape = [*, width, grid, grid]
        # patch_embeds = patch_embeds.flatten(2).transpose(1, 2) # (1,576,1024)
        # pixel_values = self.builder.make_transpose(pixel_values, (0, 2, 3, 1))
        patch_embeds = self.patch_embedding(pixel_values)  # conv2d
        # n, h, w, c = patch_embeds.get_act_src_shape()
        n, c, h, w = patch_embeds.get_act_src_shape()
        patch_embeds = self.builder.make_reshape(patch_embeds, (n, c, h * w))
        patch_embeds = self.builder.make_transpose(patch_embeds, (0, 2, 1))
        # class_embeds = self.class_embedding.expand(batch_size, 1, -1).to(target_dtype) # (1,1,1024)
        class_embeds = self.builder.make_inputconst(
            self.class_embedding.unsqueeze(1),
            opname=self.module_name + ".class_embedding",
        )
        n, h, w, c = class_embeds.get_act_src_shape()
        class_embeds = self.builder.make_reshape(class_embeds, (n, w, c))

        # embeddings = torch.cat([class_embeds, patch_embeds], dim=1) # torch.Size([1, 577, 1024])
        embeddings = self.builder.make_concatenate([class_embeds, patch_embeds], dim=1)
        if interpolate_pos_encoding:
            raise NotImplementedError()
            # position_embedding = self.interpolate_pos_encoding(
            #     embeddings, height, width
            # )
        else:
            # position_embedding = self.position_embedding  # torch.Size([1, 577, 1024])
            position_embedding = self.builder.make_inputconst(
                self.position_embedding.unsqueeze(1),
                self.module_name + ".position_embedding",
            )
            n, h, w, c = position_embedding.get_act_src_shape()
            position_embedding = self.builder.make_reshape(
                position_embedding, (n, w, c)
            )
        # embeddings = embeddings + position_embedding[:, : embeddings.size(1), :].to(
        #     target_dtype
        # )

        position_embedding = self.builder.make_slice(
            position_embedding,
            axis=(1,),
            start=(0,),
            end=(int(embeddings.get_act_src_shape()[1]),),
        )
        embeddings = self.builder.make_add(embeddings, position_embedding)
        return embeddings  # torch.Size([1, 577, 1024])


class BlipEncoder(ModelingBlipBase):
    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip.BlipEncoder

    def forward(
        self,
        inputs_embeds,
        attention_mask: Optional[ActivationSpec] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ) -> Union[Tuple, Any]:
        output_attentions = (
            output_attentions
            if output_attentions is not None
            else self.config.output_attentions
        )
        output_hidden_states = (
            output_hidden_states
            if output_hidden_states is not None
            else self.config.output_hidden_states
        )
        return_dict = (
            return_dict if return_dict is not None else self.config.use_return_dict
        )

        encoder_states = () if output_hidden_states else None
        all_attentions = () if output_attentions else None

        hidden_states = inputs_embeds  # torch.Size([1, 577, 1024])
        for idx, encoder_layer in enumerate(self.layers):
            if output_hidden_states:
                encoder_states = encoder_states + (hidden_states,)
            layer_outputs = encoder_layer(
                hidden_states,
                attention_mask,
                output_attentions=output_attentions,
            )

            hidden_states = layer_outputs[0]

            if output_attentions:
                raise NotImplementedError
                # all_attentions = all_attentions + (layer_outputs[1],)

        if output_hidden_states:
            raise NotImplementedError
            # encoder_states = encoder_states + (hidden_states,)

        if not return_dict:
            raise NotImplementedError
            # return tuple(v for v in [hidden_states, encoder_states, all_attentions] if v is not None)

        # return BaseModelOutput(
        #     last_hidden_state=hidden_states, hidden_states=encoder_states, attentions=all_attentions
        # )
        ns = OrderedNamespace()
        ns.last_hidden_state = hidden_states
        ns.hidden_states = encoder_states
        ns.attentions = all_attentions
        return ns


class BlipEncoderLayer(ModelingBlipBase):
    __slots__ = ("layer_norm1", "self_attn")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip.BlipEncoderLayer

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: ActivationSpec,
        output_attentions: Optional[bool] = False,
    ) -> Tuple[ActivationSpec]:
        """
        Args:
            hidden_states (`torch.FloatTensor`): input to the layer of shape `(batch, seq_len, embed_dim)`
            attention_mask (`torch.FloatTensor`): attention mask of size
                `(batch, 1, tgt_len, src_len)` where padding elements are indicated by very large negative values.
                `(config.encoder_attention_heads,)`.
            output_attentions (`bool`, *optional*):
                Whether or not to return the attentions tensors of all attention layers. See `attentions` under
                returned tensors for more detail.
        """
        residual = hidden_states  # torch.Size([1, 577, 1024])

        hidden_states = self.layer_norm1(hidden_states)
        hidden_states, attn_weights = self.self_attn(
            hidden_states=hidden_states,
            head_mask=attention_mask,
            output_attentions=output_attentions,
        )  # torch.Size([1, 577, 1024]), None
        # hidden_states = hidden_states + residual  # torch.Size([1, 577, 1024])
        hidden_states = self.builder.make_add(hidden_states, residual)
        residual = hidden_states  # torch.Size([1, 577, 1024])
        hidden_states = self.layer_norm2(hidden_states)  # torch.Size([1, 577, 1024])
        hidden_states = self.mlp(hidden_states)  # torch.Size([1, 577, 1024])

        # hidden_states = hidden_states + residual
        hidden_states = self.builder.make_add(hidden_states, residual)

        outputs = (hidden_states,)

        if output_attentions:
            outputs += (attn_weights,)

        return outputs


class BlipMLP(ModelingBlipBase):
    __slots__ = ("fc1", "activation_fn", "fc2")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip.BlipMLP

    def forward(self, hidden_states: ActivationSpec) -> ActivationSpec:
        hidden_states = self.fc1(hidden_states)
        hidden_states = self.activation_fn(hidden_states)
        hidden_states = self.fc2(hidden_states)
        return hidden_states


class BlipAttention(ModelingBlipBase):
    __slots__ = ("qkv", "num_heads", "scale", "embed_dim")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_blip_modeling_blip.BlipAttention

    def forward(
        self,
        hidden_states: ActivationSpec,
        head_mask: Optional[ActivationSpec] = None,
        output_attentions: Optional[bool] = False,
    ) -> Tuple[
        ActivationSpec, Optional[ActivationSpec], Optional[Tuple[ActivationSpec]]
    ]:
        # hidden_states: torch.Size([1, 577, 1024])

        # bsz, tgt_len, embed_dim = hidden_states.size() #1, 577, 1024
        bsz, tgt_len, embed_dim = hidden_states.get_act_src_shape()

        # mixed_qkv = (
        #     self.qkv(hidden_states)
        #     .reshape(bsz, tgt_len, 3, self.num_heads, embed_dim // self.num_heads)
        #     .permute(2, 0, 3, 1, 4)
        # ) # torch.Size([3, 1, 16, 577, 64])
        mixed_qkv = self.qkv(hidden_states)
        mixed_qkv = self.builder.make_reshape(
            mixed_qkv, (bsz, tgt_len, 3, self.num_heads, embed_dim // self.num_heads)
        )
        mixed_qkv = self.builder.make_transpose(mixed_qkv, (2, 0, 3, 1, 4))

        # query_states, key_states, value_states = mixed_qkv[0], mixed_qkv[1], mixed_qkv[2] # torch.Size([1, 16, 577, 64]),torch.Size([1, 16, 577, 64]),torch.Size([1, 16, 577, 64])
        query_states, key_states, value_states = self.builder.make_chunk(
            mixed_qkv, 3, 0
        )
        query_states, key_states, value_states = [
            self.builder.make_squeeze(x, (0,))
            for x in (query_states, key_states, value_states)
        ]

        # Take the dot product between "query" and "key" to get the raw attention scores.
        # attention_scores = torch.matmul(query_states, key_states.transpose(-1, -2)) #torch.Size([1, 16, 577, 577])
        attention_scores = self.builder.make_matmul(
            query_states, self.builder.make_transpose(key_states, (0, 1, 3, 2))
        )

        # attention_scores = attention_scores * self.scale #torch.Size([1, 16, 577, 577])
        attention_scores = self.builder.make_mul(attention_scores, self.scale)

        # Normalize the attention scores to probabilities.
        # attention_probs = nn.functional.softmax(attention_scores, dim=-1)  #torch.Size([1, 16, 577, 577])
        attention_probs = self.builder.make_softmax(attention_scores, axis=-1)

        # This is actually dropping out entire tokens to attend to, which might
        # seem a bit unusual, but is taken from the original Transformer paper.
        attention_probs = self.dropout(attention_probs)

        # Mask heads if we want to
        if head_mask is not None:
            raise NotImplementedError
            # attention_probs = attention_probs * head_mask

        # context_layer = torch.matmul(attention_probs, value_states).permute(0, 2, 1, 3) torch.Size([1, 577, 16, 64])
        context_layer = self.builder.make_matmul(attention_probs, value_states)
        context_layer = self.builder.make_transpose(context_layer, (0, 2, 1, 3))

        # new_context_layer_shape = context_layer.size()[:-2] + (self.embed_dim,)
        new_context_layer_shape = context_layer.get_act_src_shape()[:-2] + (
            self.embed_dim,
        )
        # context_layer = context_layer.reshape(new_context_layer_shape) #torch.Size([1, 577, 1024])
        context_layer = self.builder.make_reshape(
            context_layer, new_context_layer_shape
        )

        output = self.projection(context_layer)  # torch.Size([1, 577, 1024])

        outputs = (
            (output, attention_probs) if output_attentions else (output, None)
        )  # (torch.Size([1, 577, 1024]), )

        return outputs
