import abc
from typing import Any, Optional, Tuple, List, Union

import numpy
import torch
import qbcompiler.mobilint_transformers.compat_transformers.models.qwen2.modeling_qwen2 as hf_modeling_qwen2

from qbcompiler.model_dict.common import ActivationSpec, DataFormat
from qbcompiler.model_dict.parser.backend.hf.make_modules import make_dynamic_object
from qbcompiler.model_dict.parser.backend.hf.transformers.cache_utils import DynamicCache
from qbcompiler.model_dict.parser.backend.hf.transformers.modeling_outputs import (
    CausalLMOutputWithPast,
    BaseModelOutputWithPast,
)
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase
from qbcompiler.model_dict.parser.backend.modeling_torch.module_registry import Registry

__all__ = ["Qwen2ForCausalLM"]

qwen2_registry = Registry(name="qwen2_registry")


class ModelingQwen2Base(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name, make_module_func=make_dynamic_object)


@qwen2_registry.add_to_registry(hf_modeling_qwen2.Qwen2ForCausalLM)
class Qwen2ForCausalLM(ModelingQwen2Base):
    __slots__ = ("config", "model", "lm_head")

    def forward(
        self,
        input_ids: ActivationSpec = None,
        attention_mask: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        past_key_values: Optional[List[ActivationSpec]] = None,
        inputs_embeds: Optional[ActivationSpec] = None,
        labels: Optional[ActivationSpec] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[ActivationSpec] = None,
        **kwargs,
    ) -> Union[Tuple, CausalLMOutputWithPast]:
        # fmt: off
        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = (
            output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        )
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict
        # fmt: on

        slice_seq_last_n = kwargs.get("slice_seq_last_n", None)
        # decoder outputs consists of (dec_features, layer_state, dec_hidden, dec_attn)
        outputs = self.model(
            input_ids=input_ids,  # (1, 39)
            attention_mask=attention_mask,  # (1, 39)
            position_ids=position_ids,  # (1, 39)
            past_key_values=past_key_values,  # DynamicCache()
            inputs_embeds=inputs_embeds,  # None
            use_cache=use_cache,  # True
            output_attentions=output_attentions,  # False
            output_hidden_states=output_hidden_states,  # False
            return_dict=return_dict,  # True
            cache_position=cache_position,  # (39,)
            slice_seq_last_n=slice_seq_last_n,
        )

        hidden_states = outputs[0]
        logits = self.lm_head(hidden_states)
        # logits = logits.float()

        loss = None
        if labels is not None:
            raise NotImplementedError
            # # Shift so that tokens < n predict n
            # shift_logits = logits[..., :-1, :].contiguous()
            # shift_labels = labels[..., 1:].contiguous()
            # # Flatten the tokens
            # loss_fct = CrossEntropyLoss()
            # shift_logits = shift_logits.view(-1, self.config.vocab_size)
            # shift_labels = shift_labels.view(-1)
            # # Enable model parallelism
            # shift_labels = shift_labels.to(shift_logits.device)
            # loss = loss_fct(shift_logits, shift_labels)

        if not return_dict:
            output = (logits,) + outputs[1:]
            return (loss,) + output if loss is not None else output

        return CausalLMOutputWithPast(
            loss=loss,
            logits=logits,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )


@qwen2_registry.add_to_registry(hf_modeling_qwen2.Qwen2Model)
class Qwen2Model(ModelingQwen2Base):
    __slots__ = ("config", "embed_tokens", "layers", "norm")

    def forward(
        self,
        input_ids: ActivationSpec = None,
        attention_mask: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        past_key_values: Optional[List[ActivationSpec]] = None,
        inputs_embeds: Optional[ActivationSpec] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[ActivationSpec] = None,
        **kwargs,
    ) -> Union[Tuple, BaseModelOutputWithPast]:
        # input_ids # (1,39)
        # attention_mask: # (1,39)
        # position_ids: # (1,39)
        # inputs_embeds: # None
        # cache_position # (39,)
        # fmt: off
        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = (
            output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        )
        use_cache = use_cache if use_cache is not None else self.config.use_cache
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict
        # fmt: on

        seq_len = input_ids.get_act_src_shape()[-1]

        if (input_ids is None) ^ (inputs_embeds is not None):
            raise ValueError(
                "You cannot specify both input_ids and inputs_embeds at the same time, and must specify either one"
            )

        # if self.gradient_checkpointing and self.training:
        #     raise NotImplementedError()
        #     if use_cache:
        #         logger.warning_once(
        #             "`use_cache=True` is incompatible with gradient checkpointing. Setting `use_cache=False`..."
        #         )
        #         use_cache = False
        #
        use_legacy_cache = False
        # if use_cache and not isinstance(past_key_values, Cache) and not self.training:
        #     use_legacy_cache = True
        #     past_key_values = DynamicCache.from_legacy_cache(past_key_values)
        #     logger.warning_once(
        #         "We detected that you are passing `past_key_values` as a tuple and this is deprecated and will be removed in v4.43. "
        #         "Please use an appropriate `Cache` class (https://huggingface.co/docs/transformers/v4.41.3/en/internal/generation_utils#transformers.Cache)"
        #     )

        if inputs_embeds is None:
            inputs_embeds = self.embed_tokens(input_ids)  # (1,39,896)

        if cache_position is None:
            raise NotImplementedError
            # past_seen_tokens = (
            #     past_key_values.get_seq_length() if past_key_values is not None else 0
            # )
            # cache_position = torch.arange(
            #     past_seen_tokens,
            #     past_seen_tokens + inputs_embeds.shape[1],
            #     device=inputs_embeds.device,
            # )
        if position_ids is None:
            raise NotImplementedError
            # position_ids = cache_position.unsqueeze(0)

        # causal_mask = self._update_causal_mask(
        #     attention_mask,
        #     inputs_embeds,
        #     cache_position,
        #     past_key_values,
        #     output_attentions,
        # )  # None
        causal_mask = None
        hidden_states = inputs_embeds  # (1,39,896)

        # decoder layers
        all_hidden_states = () if output_hidden_states else None
        all_self_attns = () if output_attentions else None
        next_decoder_cache = None

        for idx, decoder_layer in enumerate(self.layers):
            if output_hidden_states:
                all_hidden_states += (hidden_states,)

            # if self.gradient_checkpointing and self.training:
            #     raise NotImplementedError
            #     # layer_outputs = self._gradient_checkpointing_func(
            #     #     decoder_layer.__call__,
            #     #     hidden_states,
            #     #     causal_mask,
            #     #     position_ids,
            #     #     past_key_values,
            #     #     output_attentions,
            #     #     use_cache,
            #     #     cache_position,
            #     # )
            # else:
            slice_seq_last_n = None
            if idx == len(self.layers) - 1:
                slice_seq_last_n = kwargs.get("slice_seq_last_n", None)

            layer_outputs = decoder_layer(
                hidden_states,
                attention_mask=causal_mask,
                position_ids=position_ids,
                past_key_value=past_key_values,
                output_attentions=output_attentions,
                use_cache=use_cache,
                cache_position=cache_position,
                slice_seq_last_n=slice_seq_last_n,
            )

            hidden_states = layer_outputs[0]  # torch.Size([1, 39, 896])

            if use_cache:
                next_decoder_cache = layer_outputs[2 if output_attentions else 1]

            if output_attentions:
                all_self_attns += (layer_outputs[1],)

        hidden_states = self.norm(hidden_states)  # (1,1,896)

        # add hidden states from the last decoder layer
        if output_hidden_states:
            all_hidden_states += (hidden_states,)

        next_cache = None
        if use_cache:
            # next_cache = (
            #     next_decoder_cache.to_legacy_cache()
            #     if use_legacy_cache
            #     else next_decoder_cache
            # )
            next_cache = past_key_values.get_updated(int(seq_len))

        if not return_dict:
            return tuple(
                v
                for v in [hidden_states, next_cache, all_hidden_states, all_self_attns]
                if v is not None
            )
        return BaseModelOutputWithPast(
            last_hidden_state=hidden_states,
            past_key_values=next_cache,
            hidden_states=all_hidden_states,
            attentions=all_self_attns,
        )


@qwen2_registry.add_to_registry(hf_modeling_qwen2.Qwen2DecoderLayer)
class Qwen2DecoderLayer(ModelingQwen2Base):
    __slots__ = ("input_layernorm", "self_attn", "post_attention_layernorm", "mlp")

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        past_key_value: Optional[Tuple[ActivationSpec]] = None,
        output_attentions: Optional[bool] = False,
        use_cache: Optional[bool] = False,
        cache_position: Optional[ActivationSpec] = None,
        slice_seq_last_n: Optional[int] = None,
        **kwargs,
    ) -> Tuple[ActivationSpec, Optional[Tuple[ActivationSpec, ActivationSpec]]]:
        residual = hidden_states  # (1,39,896)

        hidden_states = self.input_layernorm(hidden_states)  # (1,39,896)

        # Self Attention
        hidden_states, self_attn_weights, present_key_value = self.self_attn(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_value=past_key_value,
            output_attentions=output_attentions,
            use_cache=use_cache,
            cache_position=cache_position,
            slice_seq_last_n=slice_seq_last_n,
        )
        if slice_seq_last_n is not None:
            residual = self.builder.make_slice(
                residual,
                axis=(1,),
                start=(-slice_seq_last_n,),
                end=(int(numpy.iinfo(numpy.int32).max),),
                step=(1,),
            )
            for x in residual.src_shape:
                if x.dynamic:
                    x._dynamic = False

        # hidden_states = residual + hidden_states  # (1,39,896)
        hidden_states = self.builder.make_add(
            residual, hidden_states, opname=self.module_name + "/add0"
        )

        # Fully Connected
        residual = hidden_states
        hidden_states = self.post_attention_layernorm(
            hidden_states
        )  # torch.Size([1, 39, 896])
        hidden_states = self.mlp(hidden_states)  # torch.Size([1, 39, 896])
        # hidden_states = residual + hidden_states  # torch.Size([1, 39, 896])
        hidden_states = self.builder.make_add(
            residual, hidden_states, opname=self.module_name + "/add1"
        )

        outputs = (hidden_states,)

        if output_attentions:
            outputs += (self_attn_weights,)

        if use_cache:
            outputs += (present_key_value,)

        return outputs


@qwen2_registry.add_to_registry(hf_modeling_qwen2.Qwen2RMSNorm)
class Qwen2RMSNorm(ModelingQwen2Base):
    __slots__ = ("variance_epsilon", "weight")

    def forward(self, hidden_states):
        # input_dtype = hidden_states.dtype
        # # hidden_states = hidden_states.to(torch.float32)  # torch.Size([1, 39, 896])
        # variance = hidden_states.pow(2).mean(-1, keepdim=True)  # torch.Size([1, 39, 1])
        # hidden_states = hidden_states * torch.rsqrt(
        #     variance + self.variance_epsilon
        # )  # torch.Size([1, 39, 896])
        # return self.weight * hidden_states.to(input_dtype)
        return self.builder.make_rmsnorm(
            hidden_states,
            epsilon=self.variance_epsilon,
            scale=self.weight,
            opname=self.module_name,
        )


@qwen2_registry.add_to_registry(hf_modeling_qwen2.Qwen2Attention)
class Qwen2Attention(ModelingQwen2Base):
    def forward(self, *args, **kwargs):
        raise NotImplementedError

    def repeat_kv(self, hidden_states: ActivationSpec, num_repeat):
        return self.builder.make_repeat_n(hidden_states, num_repeat)

    def apply_rotary_pos_emb(
        self,
        q: ActivationSpec,
        k: ActivationSpec,
        cos: ActivationSpec,
        sin: ActivationSpec,
    ):
        q_rope = self.builder.make_stateful_rope_wrapper(
            q, cos, sin, self.module_name + "/q_rope"
        )
        k_rope = self.builder.make_stateful_rope_wrapper(
            k, cos, sin, self.module_name + "/k_rope"
        )
        return q_rope, k_rope

    def past_kv_update(
        self, key: ActivationSpec, value: ActivationSpec, past_key_value: DynamicCache
    ):
        updates = []
        for x in (key, value):
            updates.append(
                self.builder.make_stateful_kvcache_wrapper(
                    x, x.name, past_key_value.past_seq_len, opname=x.name + "/cache"
                )
            )
        return tuple(updates)


# Copied from transformers.models.llama.modeling_llama.rotate_half
def rotate_half(x):
    """Rotates half the hidden dims of the input."""
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2 :]
    return torch.cat((-x2, x1), dim=-1)


# Copied from transformers.models.mixtral.modeling_mixtral.apply_rotary_pos_emb
def apply_rotary_pos_emb(q, k, cos, sin, position_ids, unsqueeze_dim=1):
    """Applies Rotary Position Embedding to the query and key tensors.

    Args:
        q (`torch.Tensor`): The query tensor.
        k (`torch.Tensor`): The key tensor.
        cos (`torch.Tensor`): The cosine part of the rotary embedding.
        sin (`torch.Tensor`): The sine part of the rotary embedding.
        position_ids (`torch.Tensor`):
            The position indices of the tokens corresponding to the query and key tensors. For example, this can be
            used to pass offsetted position ids when working with a KV-cache.
        unsqueeze_dim (`int`, *optional*, defaults to 1):
            The 'unsqueeze_dim' argument specifies the dimension along which to unsqueeze cos[position_ids] and
            sin[position_ids] so that they can be properly broadcasted to the dimensions of q and k. For example, note
            that cos[position_ids] and sin[position_ids] have the shape [batch_size, seq_len, head_dim]. Then, if q and
            k have the shape [batch_size, heads, seq_len, head_dim], then setting unsqueeze_dim=1 makes
            cos[position_ids] and sin[position_ids] broadcastable to the shapes of q and k. Similarly, if q and k have
            the shape [batch_size, seq_len, heads, head_dim], then set unsqueeze_dim=2.
    Returns:
        `tuple(torch.Tensor)` comprising of the query and key tensors rotated using the Rotary Position Embedding.
    """
    cos = cos[position_ids].unsqueeze(unsqueeze_dim)
    sin = sin[position_ids].unsqueeze(unsqueeze_dim)
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


@qwen2_registry.add_to_registry(hf_modeling_qwen2.Qwen2SdpaAttention)
class Qwen2SdpaAttention(Qwen2Attention):
    __slots__ = (
        "q_proj",
        "k_proj",
        "v_proj",
        "o_proj",
        "hidden_size",
        "num_heads",
        "head_dim",
        "num_key_value_heads",
        "layer_idx",
        "rotary_emb",
        "num_key_value_groups",
    )

    def qkv_reshape_transpose(self, states, new_shape, transpose_axes=(0, 2, 1, 3)):
        states = self.builder.make_reshape(
            states, new_shape, new_dataformat=DataFormat.NHWC
        )
        return self.builder.make_transpose(states, transpose_axes)

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        position_ids: Optional[ActivationSpec] = None,
        past_key_value: "Optional[Cache]" = None,
        output_attentions: bool = False,
        use_cache: bool = False,
        cache_position: Optional[ActivationSpec] = None,
        slice_seq_last_n: Optional[int] = None,
    ) -> Tuple[
        ActivationSpec, Optional[ActivationSpec], Optional[Tuple[ActivationSpec]]
    ]:
        if output_attentions:
            raise NotImplementedError
            # TODO: Improve this warning with e.g. `model.config.attn_implementation = "manual"` once this is implemented.
            logger.warning_once(
                "Qwen2Model is using Qwen2SdpaAttention, but `torch.nn.functional.scaled_dot_product_attention` does not support `output_attentions=True`. Falling back to the manual attention implementation, "
                'but specifying the manual implementation will be required from Transformers version v5.0.0 onwards. This warning can be removed using the argument `attn_implementation="eager"` when loading the model.'
            )
            return super().forward(
                hidden_states=hidden_states,
                attention_mask=attention_mask,
                position_ids=position_ids,
                past_key_value=past_key_value,
                output_attentions=output_attentions,
                use_cache=use_cache,
            )

        # bsz, q_len, _ = hidden_states.size()  # (1, 39, 896)
        bsz, q_len, _ = hidden_states.get_act_src_shape()  # (1, 39, 896)

        query_states = self.q_proj(hidden_states)  # torch.Size([1, 39, 896])
        key_states = self.k_proj(hidden_states)  # torch.Size([1, 39, 128])
        value_states = self.v_proj(hidden_states)  # torch.Size([1, 39, 128])

        # fmt:off
        # query_states = query_states.view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)  # torch.Size([1, 14, 39, 64])
        # key_states = key_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)  # torch.Size([1, 2, 39, 64])
        # value_states = value_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)  # torch.Size([1, 2, 39, 64])
        query_states = self.qkv_reshape_transpose(query_states, (bsz, q_len, self.num_heads, self.head_dim),
                                                  (0, 2, 1, 3))
        key_states = self.qkv_reshape_transpose(key_states, (bsz, q_len, self.num_key_value_heads, self.head_dim),
                                                (0, 2, 1, 3))
        value_states = self.qkv_reshape_transpose(value_states, (bsz, q_len, self.num_key_value_heads, self.head_dim),
                                                  (0, 2, 1, 3))
        # fmt:on

        # kv_seq_len = key_states.shape[-2]  # 39
        # kv_seq_len = key_states.get_act_src_shape()[-2]
        # if past_key_value is not None:
        #     kv_seq_len += past_key_value.get_usable_length(kv_seq_len, self.layer_idx)
        # cos, sin = self.rotary_emb(value_states, seq_len=kv_seq_len) # torch.Size([39, 64]), torch.Size([39, 64])
        cos, sin = self.rotary_emb(value_states, seq_len=None)
        query_states, key_states = self.apply_rotary_pos_emb(
            query_states, key_states, cos, sin
        )
        if slice_seq_last_n is not None:
            query_states = self.builder.make_slice(
                query_states,
                axis=(2,),
                start=(-slice_seq_last_n,),
                end=(int(numpy.iinfo(numpy.int32).max),),
                step=(1,),
            )
            for x in query_states.src_shape:
                if x.dynamic:
                    x._dynamic = False

        # if past_key_value is not None:
        #     cache_kwargs = {
        #         "sin": sin,
        #         "cos": cos,
        #         "cache_position": cache_position,
        #     }  # Specific to RoPE models
        #     key_states, value_states = past_key_value.update(
        #         key_states, value_states, self.layer_idx, cache_kwargs
        #     )
        # torch.Size([1, 2, 39, 64]), torch.Size([1, 2, 39, 64])
        key_states, value_states = self.past_kv_update(
            key_states, value_states, past_key_value
        )
        # key_states = repeat_kv(key_states, self.num_key_value_groups)  # torch.Size([1, 14, 39, 64])
        # value_states = repeat_kv(value_states, self.num_key_value_groups)  # torch.Size([1, 14, 39, 64])
        key_states = self.repeat_kv(key_states, self.num_key_value_groups)
        value_states = self.repeat_kv(value_states, self.num_key_value_groups)

        causal_mask = attention_mask
        if attention_mask is not None:  # no matter the length, we just slice it
            raise NotImplementedError
            # causal_mask = attention_mask[:, :, :, : key_states.shape[-2]]

        # SDPA with memory-efficient backend is currently (torch==2.1.2) bugged with non-contiguous inputs with custom attn_mask,
        # Reference: https://github.com/pytorch/pytorch/issues/112577.
        # if query_states.device.type == "cuda" and attention_mask is not None:
        #     query_states = query_states.contiguous()
        #     key_states = key_states.contiguous()
        #     value_states = value_states.contiguous()

        # We dispatch to SDPA's Flash Attention or Efficient kernels via this `is_causal` if statement instead of an inline conditional assignment
        # in SDPA to support both torch.compile's dynamic shapes and full graph options. An inline conditional prevents dynamic shapes from compiling.
        # The q_len > 1 is necessary to match with AttentionMaskConverter.to_causal_4d that does not create a causal mask in case q_len == 1.
        is_causal = True if causal_mask is None and q_len > 1 else False  # True

        # attn_output = torch.nn.functional.scaled_dot_product_attention(
        #     query_states,
        #     key_states,
        #     value_states,
        #     attn_mask=causal_mask,
        #     dropout_p=self.attention_dropout if self.training else 0.0,
        #     is_causal=is_causal,
        # )
        attn_output = self.builder.make_torch_scaled_dot_product_attention(
            query_states,
            key_states,
            value_states,
            attn_mask=attention_mask,
            is_causal=is_causal,
            past_seq_len=past_key_value.past_seq_len,
        )

        # attn_output = attn_output.transpose(1, 2).contiguous()  # torch.Size([1, 39, 14, 64])
        attn_output = self.builder.make_transpose(attn_output, (0, 2, 1, 3))
        # attn_output = attn_output.view(bsz, q_len, self.hidden_size)  # torch.Size([1, 39, 896])
        if slice_seq_last_n is not None:
            q_len = slice_seq_last_n
        attn_output = self.builder.make_reshape(
            attn_output, (bsz, q_len, self.hidden_size)
        )

        attn_output = self.o_proj(attn_output)  # torch.Size([1, 39, 896])

        return attn_output, None, past_key_value


@qwen2_registry.add_to_registry(hf_modeling_qwen2.Qwen2MLP)
class Qwen2MLP(ModelingQwen2Base):
    __slots__ = ("down_proj", "act_fn", "gate_proj", "up_proj")

    def forward(self, hidden_state):
        # return self.down_proj(
        #     self.act_fn(self.gate_proj(hidden_state)) * self.up_proj(hidden_state)
        # )
        gate_proj = self.gate_proj(hidden_state)
        up_proj = self.up_proj(hidden_state)
        act_fn = self.act_fn(gate_proj)
        mul = self.builder.make_mul(act_fn, up_proj)
        down_proj = self.down_proj(mul)
        return down_proj


@qwen2_registry.add_to_registry(hf_modeling_qwen2.Qwen2RotaryEmbedding)
class Qwen2RotaryEmbedding(ModelingQwen2Base):
    """This module is intentionally designed as a singleton to reuse ROPE weight."""

    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)
        self.cos = None
        self.sin = None
        self.inv_freq = model.inv_freq
        self.rope_max_seqlen = 8192

        # fixme: version issue
        if hasattr(model, "config"):
            self.num_head = model.config.num_attention_heads
            self.attention_scaling = model.attention_scaling
        else:
            self.cos_cached = model.cos_cached
            self.sin_cached = model.sin_cached

    def _set_cos_sin_cache(self, seq_len, device, dtype):
        raise NotImplementedError
        self.max_seq_len_cached = seq_len
        t = torch.arange(
            self.max_seq_len_cached, device=device, dtype=torch.int64
        ).type_as(self.inv_freq)

        freqs = torch.outer(t, self.inv_freq)
        # Different from paper, but it uses a different permutation in order to obtain the same calculation
        emb = torch.cat((freqs, freqs), dim=-1)

    def make_rope_inputconst(self):
        # fmt: off
        if self.cos is None:
            if hasattr(self, "cos_cached"):
                emb_cos = self.cos_cached[:self.rope_max_seqlen].unsqueeze(0).unsqueeze(0)
                emb_sin = self.sin_cached[:self.rope_max_seqlen].unsqueeze(0).unsqueeze(0)
            else:
                device = self.inv_freq.device
                position_ids = torch.arange(self.rope_max_seqlen, dtype=torch.int64).unsqueeze(0).to(device)
                inv_freq_expanded = self.inv_freq[None, :, None].float().expand(position_ids.shape[0], -1, 1)
                position_ids_expanded = position_ids[:, None, :].float()
                freqs = (inv_freq_expanded.float() @ position_ids_expanded.float()).transpose(1, 2)
                emb = torch.cat((freqs, freqs), dim=-1)
                emb_cos = (emb.cos() * self.attention_scaling).unsqueeze(1)
                emb_sin = (emb.sin() * self.attention_scaling).unsqueeze(1)
            self.cos = self.builder.make_inputconst(emb_cos, self.module_name + ".cos")
            self.sin = self.builder.make_inputconst(emb_sin, self.module_name + ".sin")
        # fmt: on
        return self.cos, self.sin

    def forward(self, x, seq_len=None):
        # x: [bs, num_attention_heads, seq_len, head_size]
        # if seq_len > self.max_seq_len_cached:
        #     self._set_cos_sin_cache(seq_len=seq_len, device=x.device, dtype=x.dtype)
        #
        # return (
        #     self.cos_cached[:seq_len].to(dtype=x.dtype),
        #     self.sin_cached[:seq_len].to(dtype=x.dtype),
        # )
        if seq_len is None:
            return self.make_rope_inputconst()
        else:
            raise NotImplementedError
