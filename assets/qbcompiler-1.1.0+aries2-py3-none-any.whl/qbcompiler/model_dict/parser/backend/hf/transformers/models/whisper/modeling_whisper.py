import abc
from typing import Any, Type, Optional, Union, Tuple

import numpy
import torch
import qbcompiler.mobilint_transformers.compat_transformers.models.whisper.modeling_whisper as hf_transformers_whisper_modeling_whisper


import qbcompiler.model_dict.common.options as layer_options
from qbcompiler.model_dict.common import (
    ModelDict,
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.common.parserabc import MobilintParserOutputs
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase
from qbcompiler.model_dict.parser.backend.hf.make_modules import make_dynamic_object
from qbcompiler.model_dict.parser.backend.hf.transformers.models.whisper.sample_data import (
    get_sample_data,
)
from qbcompiler.model_dict.parser.backend.hf.util import (
    OrderedNamespace,
    DefaultInputsCaptureContainer,
    InputCaptureCtxManager,
)
from qbcompiler.model_dict.parser.util.subgraph_builder import SubGraphBuilder


class KVCache:
    def __init__(self, past_seqlen=0):
        self.past_seqlen = past_seqlen

    def get_updated(self, seq_len):
        return KVCache(self.past_seqlen + seq_len)


class ModelingWhisperBase(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name, make_module_func=make_dynamic_object)


class WhisperForConditionalGeneration(ModelingWhisperBase):
    __slots__ = ("config", "model", "proj_out")

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_whisper_modeling_whisper.WhisperForConditionalGeneration

    def forward(
        self,
        input_features: Optional[ActivationSpec] = None,
        attention_mask: Optional[ActivationSpec] = None,
        decoder_input_ids: Optional[ActivationSpec] = None,
        decoder_attention_mask: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,
        decoder_head_mask: Optional[ActivationSpec] = None,
        cross_attn_head_mask: Optional[ActivationSpec] = None,
        encoder_outputs: Optional[Tuple[Tuple[ActivationSpec]]] = None,
        past_key_values: Optional[Union[Any, Tuple[ActivationSpec]]] = None,
        decoder_inputs_embeds: Optional[Tuple[ActivationSpec]] = None,
        decoder_position_ids: Optional[Tuple[ActivationSpec]] = None,
        labels: Optional[ActivationSpec] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[ActivationSpec] = None,
    ) -> Union[Tuple[ActivationSpec], Any]:
        raise NotImplementedError

    # Q: How to split the ConditionalGeneration into submodules

    def _make_feed_dict(self, target, max_call_limit=1):
        model_id = self._reference_model.config._name_or_path
        print("reference model id: ", model_id)
        inputs = get_sample_data(model_id)
        inputs_container = DefaultInputsCaptureContainer()

        target_ref_model = getattr(self.reference_model.model, target)
        if hasattr(self.reference_model, "device"):
            inputs = inputs.to(self.reference_model.device)
        target_fn_name = "forward"
        with InputCaptureCtxManager(
            target_ref_model,
            max_call_limit,
            inputs_container,
            target_fn_name=target_fn_name,
        ) as ctx:
            outputs = self.reference_model.generate(**inputs)
        fd = {}
        kw = {}
        if inputs_container.captured_args:
            captured_args = inputs_container.captured_args[-1]
        else:
            captured_args = []
        if inputs_container.captured_kwargs:
            captured_kwargs = inputs_container.captured_kwargs[-1]
        else:
            captured_kwargs = {}

        if target == "encoder":
            fd["input_features"] = captured_args[0]

        for k, v in captured_kwargs.items():
            if isinstance(v, torch.Tensor):
                fd[k] = v.detach()
            if k == "past_key_values":
                fd[k] = v
        kw.update(captured_kwargs)
        return fd, kw

    def _parse_with_target(self, target, feed_dict=None):
        if target == "encoder":
            encoder_builder = SubGraphBuilder({}, "encoder")
            self.set_builder(encoder_builder, recursive=False)
            self.model.set_builder(encoder_builder, recursive=False)
            self.model.encoder.set_builder(encoder_builder)

            if feed_dict is not None:
                b, c, seq_len = feed_dict["input_features"].shape
            else:
                b, c, seq_len = 1, 80, 3000

            input_features = ActivationSpec(
                name="input_features",
                src_shape=(b, c, seq_len),
                dataformat=DataFormat.NCX,  # CHECK,
                dtype="float32",
            )
            encoder_builder.add_activation(input_features)
            encoder_builder.make_input(input_features)

            encoder_outputs = self.model.encoder(
                input_features=input_features,
                output_attentions=False,
                output_hidden_states=False,
            )
            encoder_builder.make_output(encoder_outputs.last_hidden_states)
        elif target == "decoder":
            decoder_builder = SubGraphBuilder({}, "decoder")
            self.set_builder(decoder_builder, recursive=False)
            self.model.set_builder(decoder_builder, recursive=False)
            self.model.decoder.set_builder(decoder_builder)

            if feed_dict is not None:
                num_input_ids = feed_dict["input_ids"].shape[1]
                num_ids = 4

            # input_ids = ActivationSpec(
            #     name="input_ids",
            #     src_shape = (1, DimValue(num_input_ids,dynamic=True)),
            #     dataformat=DataFormat.NX,
            #     dtype="int64"
            # )
            # decoder_builder.add_activation(input_ids)
            # decoder_builder.make_input(input_ids)
            decoder_hidden_states = ActivationSpec(
                name="decoder_hidden_states/add",
                src_shape=(
                    1,
                    DimValue(num_ids, dynamic=True),
                    feed_dict["encoder_hidden_states"].shape[2],
                ),
                dataformat=DataFormat.NXC,
                dtype="float32",
            )
            decoder_builder.add_activation(decoder_hidden_states)
            decoder_builder.make_input(decoder_hidden_states)

            encoder_hidden_states = ActivationSpec(
                name="encoder_hidden_states",
                src_shape=(1, 1500, feed_dict["encoder_hidden_states"].shape[-1]),
                dataformat=DataFormat.NXC,
                dtype="float32",
            )
            decoder_builder.add_activation(encoder_hidden_states)
            decoder_builder.make_input(encoder_hidden_states)

            past_key_values = KVCache(past_seqlen=0)

            decoder_outputs = self.model.decoder(
                # input_ids = input_ids,
                decoder_hidden_states=decoder_hidden_states,
                encoder_hidden_states=encoder_hidden_states,
                past_key_values=past_key_values,
                use_cache=True,
                # cache_position = cache_position,
                output_attentions=False,
                output_hidden_states=False,
            )
            self.proj_out.set_builder(decoder_builder)
            proj_out = self.proj_out(decoder_outputs.last_hidden_state)
            decoder_builder.make_output(proj_out)
        else:
            raise NotImplementedError

        md = ModelDict()
        target_builder = self.get_builder(target)
        sg_target = target_builder.build(target, unsupported=False)
        sg_target.idx = 0

        key_cache_names, value_cache_names = [], []
        for op in sg_target.operators:
            if op.layertype == LayerType.StatefulKVCacheWrapper:
                x = op.name[op.name.find("layers") + 7 :]
                x = int(x[: x.find(".")])
                if "k_proj" in op.name:
                    key_cache_names.append((x, op.options.cache_name))
                if "v_proj" in op.name:
                    value_cache_names.append((x, op.options.cache_name))
        key_cache_names.sort(key=lambda x: x[0])
        value_cache_names.sort(key=lambda x: x[0])
        sg_target.key_cache_names = [x[1] for x in key_cache_names]
        sg_target.value_cache_names = [x[1] for x in value_cache_names]

        md.subgraphs.append(sg_target)
        const_dict = target_builder._weights

        for iidx in md.sg_main().inputs:
            inact = md.sg_main().activations[iidx]
            md.inputs.append(inact.name)

        for oidx in md.sg_main().outputs:
            outact = md.sg_main().activations[oidx]
            md.outputs.append(outact.name)

        # Comment for mxq compile
        # if "past_key_values" in feed_dict:
        #     past_key_values = feed_dict["past_key_values"]
        #     # TODO: set 0 when quantize_save = False
        #     #           1 when quantize_save = True
        #     md.init_model_state = {
        #         "sg0": {"_seen_tokens": 0, "past_key_values": None},
        #         "sg1": {
        #             "_seen_tokens": past_key_values.self_attention_cache._seen_tokens,
        #             "past_key_values": past_key_values.self_attention_cache,
        #         },
        #         "sg2": {"_seen_tokens": 0, "past_key_values": None},
        #     }

        out = MobilintParserOutputs()
        out.model_dict = md
        out.value_dict = self.value_dict
        out.const_dict = const_dict

        return out

    def _make_value_dict(self, target, feed_dict, eval_kwargs):
        vd = {}
        vd.update(feed_dict)
        if target == "encoder" or target == "decoder":
            target_module = getattr(self.model, target)
        else:
            target_module = getattr(self, target)
        target_module.set_value_dict(vd)
        target_module.register_forward_hook()

        kw = {}
        kw.update(feed_dict)
        kw.update(eval_kwargs)

        _value_dict = ValueDict()

        for k, v in kw.items():
            if isinstance(v, torch.Tensor):
                kw[k] = v.to(target_module.reference_model.device)

        target_module.torch_compute(**kw)
        for k, v in vd.items():
            if isinstance(v, torch.Tensor):
                if v.dtype == torch.bfloat16:
                    v = v.to(torch.float32)
                v = v.detach().cpu().numpy()
            if isinstance(v, numpy.ndarray):
                _value_dict[k] = v

        if target == "decoder":
            target_ref_model = getattr(self.reference_model.model, target)
            inputs_embeds = target_ref_model.embed_tokens(feed_dict["input_ids"])
            positions = target_ref_model.embed_positions(
                feed_dict["input_ids"],
                past_key_values_length=feed_dict["cache_position"][0],
                position_ids=feed_dict["cache_position"].unsqueeze(0),
            )
            decoder_hidden_states = inputs_embeds + positions
            _value_dict["decoder_hidden_states/add"] = decoder_hidden_states

        return _value_dict

    def parse(
        self,
        target,
        make_value_dict=True,
        **kwargs,
    ):
        # max_call_limit = kwargs.pop("target_sg_state") + 1

        feed_dict, eval_kwargs = self._make_feed_dict(target=target, max_call_limit=1)

        out = self._parse_with_target(target=target, feed_dict=feed_dict)

        if make_value_dict:
            out.value_dict = self._make_value_dict(target, feed_dict, eval_kwargs)
        else:
            vd = ValueDict()
            vd._value_dict.update(feed_dict)
            out.value_dict = vd

        return out


class WhisperModel(ModelingWhisperBase):
    __slots__ = ("encoder", "decoder", "config")

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_whisper_modeling_whisper.WhisperModel

    def _mask_input_features(
        self, input_features: ActivationSpec, attention_mask: Optional[ActivationSpec]
    ):
        if not getattr(self.config, "apply_spec_augment", True):
            return input_features

        return input_features

    def forward(
        self,
        input_features: Optional[ActivationSpec] = None,
        attention_mask: Optional[ActivationSpec] = None,
        decoder_input_ids: Optional[ActivationSpec] = None,
        decoder_attention_mask: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,
        decoder_head_mask: Optional[ActivationSpec] = None,
        cross_attn_head_mask: Optional[ActivationSpec] = None,
        encoder_outputs: Optional[Tuple[Tuple[ActivationSpec]]] = None,
        past_key_values: Optional[Union[Any, Tuple[ActivationSpec]]] = None,
        decoder_inputs_embeds: Optional[Tuple[ActivationSpec]] = None,
        decoder_position_ids: Optional[Tuple[ActivationSpec]] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[ActivationSpec] = None,
    ) -> Union[Tuple[ActivationSpec], Any]:
        output_attentions = (
            output_attentions
            if output_attentions is not None
            else self.config.output_attentions
        )
        output_hidden_states = (
            output_hidden_states
            if output_hidden_states is not None
            else self.config.output_hidden_states
        )
        use_cache = use_cache if use_cache is not None else self.config.use_cache
        return_dict = (
            return_dict if return_dict is not None else self.config.use_return_dict
        )

        if encoder_outputs is None:
            input_features = self._mask_input_features(
                input_features, attention_mask=attention_mask
            )

            encoder_outputs = self.encoder(
                input_features,
                head_mask=head_mask,
                output_attentions=output_attentions,
                output_hidden_states=output_hidden_states,
                return_dict=return_dict,
            )
        # If the user passed a tuple for encoder_outputs, we wrap it in a BaseModelOutput when return_dict=True
        elif return_dict and not isinstance(encoder_outputs, OrderedNamespace):
            ns = OrderedNamespace()
            ns.last_hidden_state = encoder_outputs.last_hidden_state
            ns.hidden_states = (
                encoder_outputs.hidden_states
                if hasattr(encoder_outputs, "hidden_states")
                else None
            )
            ns.attentions = (
                encoder_outputs.attentions
                if hasattr(encoder_outputs, "attentions")
                else None
            )

        # decoder outputs consists of (dec_features, past_key_value, dec_hidden, dec_attn)
        decoder_outputs = self.decoder(
            input_ids=decoder_input_ids,
            attention_mask=decoder_attention_mask,
            encoder_hidden_states=encoder_outputs,
            head_mask=decoder_head_mask,
            cross_attn_head_mask=cross_attn_head_mask,
            past_key_values=past_key_values,
            inputs_embeds=decoder_inputs_embeds,
            position_ids=decoder_position_ids,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            cache_position=cache_position,
        )

        if not return_dict:
            return decoder_outputs + encoder_outputs

        ns = OrderedNamespace()
        ns.last_hidden_state = decoder_outputs.last_hidden_state
        ns.past_key_values = decoder_outputs.past_key_values
        ns.decoder_hidden_states = decoder_outputs.decoder_hidden_states
        ns.decoder_attentions = decoder_outputs.attentions
        ns.cross_attentions = decoder_outputs.cross_attentions
        ns.encoder_last_hidden_state = encoder_outputs.last_hidden_state
        ns.encoder_hidden_states = encoder_outputs.hidden_states
        ns.encoder_attentions = encoder_outputs.attentions
        return ns


class WhisperEncoder(ModelingWhisperBase):
    __slots__ = (
        "config",
        "conv1",
        "conv2",
        "embed_positions",
        "dropout",
        "training",
        "layers",
        "layer_norm",
    )
    """
    Transformer encoder consisting of *config.encoder_layers* self attention layers. Each layer is a
    [`WhisperEncoderLayer`].

    Args:
        config: WhisperConfig
    """

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_whisper_modeling_whisper.WhisperEncoder

    def forward(
        self,
        input_features: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,
        output_attentions: Optional[bool] = None,  # False
        output_hidden_states: Optional[bool] = None,  # False
    ):
        expected_seq_length = (
            self.config.max_source_positions
            * self.conv1.stride[0]
            * self.conv2.stride[0]
        )
        if input_features.get_act_src_shape()[-1] != expected_seq_length:
            raise ValueError(
                f"Whisper expects the mel input features to be of length {expected_seq_length}, but found {input_features.shape[-1]}. Make sure to pad the input mel features to {expected_seq_length}."
            )

        output_attentions = (
            output_attentions
            if output_attentions is not None
            else self.config.output_attentions
        )
        output_hidden_states = (
            output_hidden_states
            if output_hidden_states is not None
            else self.config.output_hidden_states
        )

        # input_features: [1, 80, 3000]
        # self.conv1(input_features): [1, 384, 3000]
        # NOTE: add transpose for difference of conv between torch and conv
        # input_features = self.builder.make_transpose(input_features, (0, 2, 1))
        inputs_embeds = self.builder.make_act_func(self.conv1(input_features), "gelu")
        inputs_embeds = self.builder.make_act_func(self.conv2(inputs_embeds), "gelu")

        # NOTE: revert additional transpose
        # inputs_embeds = self.builder.make_transpose(inputs_embeds, (0, 2, 1))
        # NOTE: origin transpose
        inputs_embeds = self.builder.make_transpose(inputs_embeds, (0, 2, 1))

        # embed_positions: [1500, 384]
        hidden_states = self.builder.make_add(
            inputs_embeds,
            self.embed_positions.weight,
            opname=f"{self.module_name}/add_0",
        )  # [1, 1500, 384]
        hidden_states = self.builder.make_torch_dropout(
            hidden_states, self.dropout, self.training
        )
        encoder_states = () if output_hidden_states else None
        all_attentions = () if output_attentions else None

        # check if head_mask has a correct number of layers specified if desired
        if head_mask is not None:
            assert head_mask.size()[0] == (
                len(self.layers)
            ), f"The head_mask should be specified for {len(self.layers)} layers, but it is for {head_mask.size()[0]}."

        for idx, encoder_layer in enumerate(self.layers):
            if output_hidden_states:
                encoder_states = encoder_states + (hidden_states,)
            # add LayerDrop (see https://arxiv.org/abs/1909.11556 for description)
            to_drop = False

            if to_drop:
                layer_outputs = (None, None)
            else:
                layer_outputs = encoder_layer(
                    hidden_states,
                    None,
                    layer_head_mask=(head_mask[idx] if head_mask is not None else None),
                    output_attentions=output_attentions,
                )

                hidden_states = layer_outputs[0]

            if output_attentions:
                all_attentions = all_attentions + (layer_outputs[1],)

        hidden_states = self.layer_norm(hidden_states)
        if output_hidden_states:
            encoder_states = encoder_states + (hidden_states,)

        ns = OrderedNamespace()
        ns.last_hidden_states = hidden_states
        ns.hidden_states = encoder_states
        ns.all_attentions = all_attentions
        return ns


class WhisperDecoder(ModelingWhisperBase):
    __slots__ = (
        "config",
        "dropout",
        "training",
        "layerdrop",
        "embed_tokens",
        "embed_positions",
        "layers",
        "layer_norm",
    )

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_whisper_modeling_whisper.WhisperDecoder

    def forward(
        self,
        # input_ids: ActivationSpec=None,
        decoder_hidden_states: ActivationSpec = None,
        attention_mask: Optional[ActivationSpec] = None,  # None
        encoder_hidden_states: Optional[ActivationSpec] = None,
        head_mask: Optional[ActivationSpec] = None,  # None
        cross_attn_head_mask: Optional[ActivationSpec] = None,  # None
        past_key_values: Optional[Any] = None,
        inputs_embeds: Optional[ActivationSpec] = None,  # None
        position_ids: Optional[ActivationSpec] = None,  # None
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,  # False
        output_hidden_states: Optional[bool] = None,  # False
        cache_position: Optional[ActivationSpec] = None,
    ):
        output_attentions = (
            output_attentions
            if output_attentions is not None
            else self.config.output_attentions
        )
        output_hidden_states = (
            output_hidden_states
            if output_hidden_states is not None
            else self.config.output_hidden_states
        )
        use_cache = use_cache if use_cache is not None else self.config.use_cache

        hidden_states = self.builder.make_torch_dropout(
            decoder_hidden_states, p=self.dropout, training=self.training
        )

        if attention_mask is not None:
            raise NotImplementedError()
        causal_mask = None

        all_hidden_states = () if output_hidden_states else None
        all_self_attns = () if output_attentions else None
        all_cross_attentions = (
            () if (output_attentions and encoder_hidden_states is not None) else None
        )

        # check if head_mask/cross_attn_head_mask has a correct number of layers specified if desired
        for attn_mask, mask_name in zip(
            [head_mask, cross_attn_head_mask], ["head_mask", "cross_attn_head_mask"]
        ):
            if attn_mask is not None:
                assert attn_mask.size()[0] == (len(self.layers)), (
                    f"The `{mask_name}` should be specified for {len(self.layers)} layers, but it is for"
                    f" {head_mask.size()[0]}."
                )
        for idx, decoder_layer in enumerate(self.layers):
            # add LayerDrop (see https://arxiv.org/abs/1909.11556 for description)
            is_last_block = idx == len(self.layers) - 1
            if output_hidden_states:
                all_hidden_states += (hidden_states,)

            # NOTE: cross-attn don't use cache.
            #       In cross attn, key and value states are obtained from encoder hidden states.
            layer_outputs = decoder_layer(
                hidden_states,
                attention_mask=causal_mask,
                encoder_hidden_states=encoder_hidden_states,
                layer_head_mask=(head_mask[idx] if head_mask is not None else None),
                cross_attn_layer_head_mask=(
                    cross_attn_head_mask[idx]
                    if cross_attn_head_mask is not None
                    else None
                ),
                self_attn_cache=past_key_values if use_cache else None,
                output_attentions=output_attentions,
                use_cache=use_cache,
                cache_position=cache_position,
                is_last_block=is_last_block,
            )
            hidden_states = layer_outputs[0]

        hidden_states = self.layer_norm(hidden_states)

        next_cache = past_key_values if use_cache else None

        ns = OrderedNamespace()
        ns.last_hidden_state = hidden_states
        ns.past_key_values = next_cache
        ns.hidden_states = all_hidden_states
        ns.attentions = all_self_attns
        ns.cross_attentions = all_cross_attentions
        return ns


class WhisperEncoderLayer(ModelingWhisperBase):
    __slots__ = (
        "self_attn",
        "self_attn_layer_norm",
        "training",
        "dropout",
        "activation_fn",
        "activation_dropout",
        "fc1",
        "fc2",
        "final_layer_norm",
    )

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_whisper_modeling_whisper.WhisperEncoderLayer

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: ActivationSpec,
        layer_head_mask: ActivationSpec,
        output_attentions: bool = False,
    ) -> ActivationSpec:
        """
        Args:
            hidden_states (`ActivationSpec`): input to the layer of shape `(batch, seq_len, embed_dim)`
            attention_mask (`ActivationSpec`): attention mask of size
                `(batch, 1, tgt_len, src_len)` where padding elements are indicated by very large negative values.
            layer_head_mask (`ActivationSpec`): mask for attention heads in a given layer of size
                `(encoder_attention_heads,)`.
            output_attentions (`bool`, *optional*):
                Whether or not to return the attentions tensors of all attention layers. See `attentions` under
                returned tensors for more detail.
        """
        residual = hidden_states
        hidden_states = self.self_attn_layer_norm(
            hidden_states
        )  # hidden_states: [1, 1500, 384]
        hidden_states, attn_weights, _ = self.self_attn(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            layer_head_mask=layer_head_mask,
            output_attentions=output_attentions,
        )
        hidden_states = self.builder.make_torch_dropout(
            hidden_states, p=self.dropout, training=self.training
        )
        hidden_states = self.builder.make_add(
            residual, hidden_states, opname=f"{self.module_name}/add_0"
        )

        residual = hidden_states
        hidden_states = self.final_layer_norm(hidden_states)
        hidden_states = self.activation_fn(self.fc1(hidden_states))
        hidden_states = self.builder.make_torch_dropout(
            hidden_states, p=self.activation_dropout, training=self.training
        )
        hidden_states = self.fc2(hidden_states)
        hidden_states = self.builder.make_torch_dropout(
            hidden_states, p=self.dropout, training=self.training
        )
        hidden_states = self.builder.make_add(
            residual, hidden_states, opname=f"{self.module_name}/add_1"
        )

        if hidden_states.dtype == "float16":
            raise NotImplementedError()

        outputs = (hidden_states,)

        if output_attentions:
            outputs += (attn_weights,)

        return outputs


class WhisperDecoderLayer(ModelingWhisperBase):
    __slots__ = (
        "self_attn",
        "dropout",
        "training",
        "activation_fn",
        "activation_dropout",
        "self_attn_layer_norm",
        "encoder_attn",
        "encoder_attn_layer_norm",
        "fc1",
        "fc2",
        "final_layer_norm",
    )

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_whisper_modeling_whisper.WhisperDecoderLayer

    def forward(
        self,
        hidden_states: ActivationSpec,
        attention_mask: Optional[ActivationSpec] = None,
        encoder_hidden_states: Optional[ActivationSpec] = None,
        encoder_attention_mask: Optional[ActivationSpec] = None,
        layer_head_mask: Optional[ActivationSpec] = None,
        cross_attn_layer_head_mask: Optional[ActivationSpec] = None,
        self_attn_cache: KVCache = None,
        # cross_attn_cache: KVCache = None,
        output_attentions: Optional[bool] = False,
        use_cache: Optional[bool] = True,
        cache_position: Optional[ActivationSpec] = None,
        is_last_block: Optional[bool] = False,
    ) -> ActivationSpec:
        """
        Args:
            hidden_states (`ActivationSpec`): input to the layer of shape `(batch, seq_len, embed_dim)`
            attention_mask (`ActivationSpec`): attention mask of size
                `(batch, 1, tgt_len, src_len)` where padding elements are indicated by very large negative values.
            encoder_hidden_states (`ActivationSpec`):
                cross attention input to the layer of shape `(batch, seq_len, embed_dim)`
            encoder_attention_mask (`ActivationSpec`): encoder attention mask of size
                `(batch, 1, tgt_len, src_len)` where padding elements are indicated by very large negative values.
            layer_head_mask (`ActivationSpec`): mask for attention heads in a given layer of size
                `(encoder_attention_heads,)`.
            cross_attn_layer_head_mask (`ActivationSpec`): mask for cross-attention heads in a given layer of
                size `(decoder_attention_heads,)`.
            past_key_value (`Tuple(ActivationSpec)`): cached past key and value projection states
            output_attentions (`bool`, *optional*):
                Whether or not to return the attentions tensors of all attention layers. See `attentions` under
                returned tensors for more detail.
        """
        residual = hidden_states
        hidden_states = self.self_attn_layer_norm(hidden_states)

        # Self Attention
        hidden_states, self_attn_weights, present_key_value = self.self_attn(
            hidden_states=hidden_states,
            past_key_value=self_attn_cache,
            attention_mask=attention_mask,
            layer_head_mask=layer_head_mask,
            output_attentions=output_attentions,
            # cache_position=cache_position,
        )

        hidden_states = self.builder.make_torch_dropout(
            hidden_states, p=self.dropout, training=self.training
        )
        hidden_states = self.builder.make_add(
            residual, hidden_states, opname=f"{self.module_name}/add_0"
        )

        if is_last_block:
            hidden_states = self.builder.make_slice(
                hidden_states,
                axis=(1,),
                start=(-1,),
                end=(int(numpy.iinfo(numpy.int32).max),),
                step=(1,),
            )
            for x in hidden_states.src_shape:
                if x.dynamic:
                    x._dynamic = False

        # Cross-Attention Block
        cross_attn_weights = None
        if encoder_hidden_states is not None:
            residual = hidden_states
            hidden_states = self.encoder_attn_layer_norm(hidden_states)
            (
                hidden_states,
                cross_attn_weights,
                cross_attn_present_key_value,
            ) = self.encoder_attn(
                hidden_states=hidden_states,
                key_value_states=encoder_hidden_states,
                attention_mask=encoder_attention_mask,
                layer_head_mask=cross_attn_layer_head_mask,
                output_attentions=output_attentions,
            )
            hidden_states = self.builder.make_torch_dropout(
                hidden_states, p=self.dropout, training=self.training
            )
            hidden_states = self.builder.make_add(
                residual, hidden_states, opname=f"{self.module_name}/add_1"
            )

            # add cross-attn to positions 1 of present_key_value tuple
            present_key_value = (present_key_value, cross_attn_present_key_value)

        # Fully Connected
        residual = hidden_states
        hidden_states = self.final_layer_norm(hidden_states)
        hidden_states = self.activation_fn(self.fc1(hidden_states))
        hidden_states = self.builder.make_torch_dropout(
            hidden_states, p=self.activation_dropout, training=self.training
        )
        hidden_states = self.fc2(hidden_states)
        hidden_states = self.builder.make_torch_dropout(
            hidden_states, p=self.dropout, training=self.training
        )
        hidden_states = self.builder.make_add(
            residual, hidden_states, opname=f"{self.module_name}/add_2"
        )

        outputs = (hidden_states,)

        return outputs


class WhisperPositionalEmbedding(ModelingWhisperBase):
    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)
        self.num_embeddings = model.num_embeddings
        self.embedding_dim = model.embedding_dim
        self.weight = model.weight

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_whisper_modeling_whisper.WhisperPositionalEmbedding

    def forward(self, input_ids, past_key_values_length=0, position_ids=None):
        constant_ts_idx = self.builder.add_weight(
            self.module_name + "/embedding_weight", self.weight
        )

        if position_ids is None:
            # TODO: Check if this branch is active for large models, and if it is, implement it.
            raise NotImplementedError
        else:
            b, num_pos = position_ids.get_act_src_shape()
            # return self.weight[position_ids]
            gather_const_outact = ActivationSpec(
                name=self.module_name,
                dtype="float32",
                src_shape=(b, num_pos, self.embedding_dim),
                dataformat=DataFormat.NXC,
            )
            gather_const_inact_idx = self.builder.get_activation_index(position_ids)
            gather_const_outact_idx = self.builder.add_activation(gather_const_outact)

            op_gather_const = Operator(
                name=gather_const_outact.name,
                options=layer_options.GatherConstantOptions(
                    inputs=(gather_const_inact_idx,),
                    outputs=(gather_const_outact_idx,),
                    axis=0,
                    constant=constant_ts_idx,
                    is_const_first=True,
                ),
            )

            self.builder.add_operator(op_gather_const)

            return gather_const_outact


class WhisperAttention(ModelingWhisperBase):
    __slots__ = ("num_heads", "head_dim", "is_causal")

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_whisper_modeling_whisper.WhisperAttention

    def past_kv_update(
        self, key: ActivationSpec, value: ActivationSpec, past_key_value: KVCache
    ):
        updates = []
        for x in (key, value):
            updates.append(
                self.builder.make_stateful_kvcache_wrapper(
                    x, x.name, past_key_value.past_seqlen, opname=x.name + "/cache"
                )
            )
        return tuple(updates)

    def qkv_reshape_transpose(
        self, states: ActivationSpec, new_shape, transpose_axes=(0, 2, 1, 3)
    ):
        states = self.builder.make_reshape(
            states,
            shape=new_shape,
            new_dataformat=DataFormat.NHWC,
        )
        return self.builder.make_transpose(
            states, transpose_axes=transpose_axes, opname=states.name + "/transpose"
        )


class WhisperSdpaAttention(WhisperAttention):
    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return hf_transformers_whisper_modeling_whisper.WhisperSdpaAttention

    def forward(
        self,
        hidden_states: ActivationSpec,
        key_value_states: Optional[ActivationSpec] = None,
        past_key_value: Optional[KVCache] = None,
        attention_mask: Optional[ActivationSpec] = None,
        layer_head_mask: Optional[ActivationSpec] = None,
        output_attentions: bool = False,
        cache_position: Optional[ActivationSpec] = None,
    ) -> Tuple[
        ActivationSpec, Optional[ActivationSpec], Optional[Tuple[ActivationSpec]]
    ]:
        """Input shape: Batch x Time x Channel"""

        # if key_value_states are provided this layer is used as a cross-attention layer
        # for the decoder
        is_cross_attention = key_value_states is not None
        bsz, tgt_len, _ = hidden_states.get_act_src_shape()
        # get query proj
        # Question: Are reshape->transpose layers fused into a single layer?

        query_states = self.q_proj(hidden_states)  # [1, -1, 384] -> [1, -1, 384]

        query_states = self.qkv_reshape_transpose(
            query_states, (bsz, tgt_len, self.num_heads, self.head_dim)
        )

        # NOTE Decoder에서는 past_key_value를 항상 넣어주는 형태로 구현

        # use key_value_states if cross attention
        current_states = (
            key_value_states if key_value_states is not None else hidden_states
        )
        key_states = self.k_proj(current_states)
        value_states = self.v_proj(current_states)

        key_seq_len, value_seq_len = (
            key_states.get_act_src_shape()[1],
            value_states.get_act_src_shape()[1],
        )
        key_states = self.qkv_reshape_transpose(
            key_states, (bsz, key_seq_len, self.num_heads, self.head_dim)
        )
        value_states = self.qkv_reshape_transpose(
            value_states, (bsz, value_seq_len, self.num_heads, self.head_dim)
        )

        if not is_cross_attention:
            # `past_key_value` is None in Encoder self-attention
            if past_key_value is not None:
                key_states, value_states = self.past_kv_update(
                    key_states, value_states, past_key_value
                )

        causal_mask = attention_mask
        # Question: Can I remove this line since 'attnetion_mask' is always None?
        # if attention_mask is not None:  # no matter the length, we just slice it
        #     causal_mask = attention_mask[:, :, :, : key_states.shape[-2]]

        is_causal = (
            True if self.is_causal and causal_mask is None and tgt_len > 1 else False
        )

        attn_output = self.builder.make_torch_scaled_dot_product_attention(
            query_states,
            key_states,
            value_states,
            attn_mask=causal_mask,
            is_causal=is_causal,
            past_seq_len=0 if past_key_value is None else past_key_value.past_seqlen,
            opname=self.module_name,
        )

        ob, oh, ot, od = attn_output.get_act_src_shape()

        if (ob, oh, od) != (bsz, self.num_heads, self.head_dim):
            raise ValueError(
                f"`attn_output` should be of size {(bsz, self.num_heads, tgt_len, self.head_dim)}, but is"
                f" {attn_output.get_act_src_shape()}"
            )

        attn_output = self.builder.make_transpose(
            attn_output, (0, 2, 1, 3), opname=attn_output.name + "/transpose"
        )

        _, h, w, c = attn_output.get_act_src_shape()
        attn_output = self.builder.make_reshape(
            attn_output, (bsz, h, w * c), DataFormat.NXC
        )

        attn_output = self.out_proj(attn_output)  # [1, 1500, 384]

        return attn_output, None, past_key_value
