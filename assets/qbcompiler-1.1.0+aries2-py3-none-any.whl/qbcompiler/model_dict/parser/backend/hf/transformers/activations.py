import abc
from collections import OrderedDict
from typing import Any, Type

import qbcompiler.mobilint_transformers.compat_transformers.activations as hf_transformers_activations

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.hf.make_modules import make_dynamic_object
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase


class ActivationsBase(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name, make_module_func=make_dynamic_object)


class GELUActivation(ActivationsBase, abc.ABC):
    @property
    def target_module_type(self) -> Type:
        return hf_transformers_activations.GELUActivation

    def forward(self, input: ActivationSpec) -> ActivationSpec:
        return self.builder.make_gelu(input, approximate=False)


class QuickGELUActivation(ActivationsBase, abc.ABC):
    @property
    def target_module_type(self) -> Type:
        return hf_transformers_activations.QuickGELUActivation

    def forward(self, x: ActivationSpec) -> ActivationSpec:
        # return x * torch.sigmoid(1.702 * x)
        return self.builder.make_mul(
            x, self.builder.make_sigmoid(self.builder.make_mul(x, 1.702))
        )


class ClassInstantier(OrderedDict):
    def __getitem__(self, key):
        content = super().__getitem__(key)
        cls, kwargs = content if isinstance(content, tuple) else (content, {})
        return cls(**kwargs)


ACT2CLS = {
    "gelu": GELUActivation,
    # "gelu_10": (ClippedGELUActivation, {"min": -10, "max": 10}),
    # "gelu_fast": FastGELUActivation,
    # "gelu_new": NewGELUActivation,
    "gelu_python": (GELUActivation, {"use_gelu_python": True}),
    # "gelu_pytorch_tanh": PytorchGELUTanh,
    # "gelu_accurate": AccurateGELUActivation,
    # "laplace": LaplaceActivation,
    # "leaky_relu": nn.LeakyReLU,
    # "linear": LinearActivation,
    # "mish": MishActivation,
    "quick_gelu": QuickGELUActivation,
    # "relu": nn.ReLU,
    # "relu2": ReLUSquaredActivation,
    # "relu6": nn.ReLU6,
    # "sigmoid": nn.Sigmoid,
    # "silu": nn.SiLU,
    # "swish": nn.SiLU,
    # "tanh": nn.Tanh,
}

ACT2FN = ClassInstantier(ACT2CLS)
