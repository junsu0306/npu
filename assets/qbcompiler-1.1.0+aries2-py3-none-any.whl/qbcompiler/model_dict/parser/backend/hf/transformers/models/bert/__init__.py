import numpy
import torch
from transformers import AutoTokenizer

from qbcompiler.model_dict.common import ModelDict
from qbcompiler.model_dict.common import ActivationSpec, DataFormat, DimValue
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.common.parserabc import (
    MobilintParserInputs,
    MobilintParserOutputs,
)
from qbcompiler.model_dict.parser.backend.hf.transformers.models.bert.modeling_bert import (
    BertForMaskedLM,
    BertModel,
)
from qbcompiler.model_dict.parser.backend.hf.util import (
    DefaultInputsCaptureContainer,
    InputCaptureCtxManager,
)

__all__ = ["parse_bert_for_masked_lm", "parse_bert_model"]

from qbcompiler.model_dict.parser.util.subgraph_builder import SubGraphBuilder


def parse_bert_for_masked_lm(model, parser_inputs: MobilintParserInputs, **kwargs):
    model_id = model.config._name_or_path
    tokenizer = AutoTokenizer.from_pretrained(model_id)
    device = model.device
    text = "안녕하세요! 오늘은 날씨가 정말 좋 것 같기도 하고 아닌 것 같기도 하고!"
    inputs = tokenizer(text, return_tensors="pt")
    for i in inputs:
        inputs[i] = inputs[i].to(device)
    max_call_limit = 1
    inputs_container = DefaultInputsCaptureContainer()
    with InputCaptureCtxManager(model, max_call_limit, inputs_container) as f:
        outputs = model(**inputs, output_hidden_states=True)

    target_sg_state = kwargs.pop("target_sg_state", 0)
    input_ids = inputs_container.captured_kwargs[target_sg_state]["input_ids"]
    token_type_ids = inputs_container.captured_kwargs[target_sg_state]["token_type_ids"]
    attention_mask = inputs_container.captured_kwargs[target_sg_state]["attention_mask"]
    output_hidden_states = inputs_container.captured_kwargs[target_sg_state][
        "output_hidden_states"
    ]

    feed_dict = {
        "input_ids": input_ids,
        "token_type_ids": token_type_ids,
        "attention_mask": attention_mask,
        "output_hidden_states": output_hidden_states,
    }

    bert_for_masked_lm = BertForMaskedLM(model).no_check_builder()
    (
        sg_bert,
        const_dict,
        value_dict,
    ) = bert_for_masked_lm.parse(feed_dict=feed_dict, **kwargs)

    md = ModelDict()
    md.subgraphs = [sg_bert]
    for idx, sg in enumerate(md.subgraphs):
        sg.idx = idx
    md.graph_order = [0]
    for iidx in sg_bert.inputs:
        inact = sg_bert.activations[iidx]
        md.inputs.append(inact.name)
    for oidx in sg_bert.outputs:
        outact = sg_bert.activations[oidx]
        md.outputs.append(outact.name)
    md.model_backend = "hf"
    md.set_main_sg(0)

    out = MobilintParserOutputs()
    out.model_dict = md
    out.const_dict = const_dict
    out.value_dict = value_dict
    return out


def _input_activation(builder, name, dtype, src_shape, dataformat=DataFormat.UNKNOWN):
    act = ActivationSpec(name, dtype, src_shape=src_shape, dataformat=dataformat)
    builder.add_activation(act)
    builder.make_input(act)
    return act


def parse_bert_model(
    model,
    parser_inputs: MobilintParserInputs,
    make_value_dict=True,
    feed_dict=None,
    **kwargs
):
    model_id = model.config._name_or_path
    tokenizer = AutoTokenizer.from_pretrained(model_id)
    device = model.device
    text = "introducing this model"

    if not feed_dict:
        inputs = tokenizer(text, return_tensors="pt")
        for i in inputs:
            inputs[i] = inputs[i].to(device)
        max_call_limit = 1
        inputs_container = DefaultInputsCaptureContainer()
        with InputCaptureCtxManager(model, max_call_limit, inputs_container) as f:
            outputs = model(**inputs)
        feed_dict = {}
        for k, v in inputs_container.captured_kwargs[-1].items():
            feed_dict[k] = v

    const_dict = {}
    builder = SubGraphBuilder(global_weight_dict=const_dict, builder_name="bert")

    _inputs = {}
    for k, v in feed_dict.items():
        if isinstance(v, torch.Tensor):
            src_shape = list(v.shape)
            assert len(src_shape) == 2
            src_shape[-1] = DimValue(src_shape[-1], dynamic=True)
            v = _input_activation(
                builder, k, dtype=str(v.dtype).split(".")[1], src_shape=tuple(src_shape)
            )
        _inputs[k] = v

    bert_model = BertModel(model).no_check_builder()
    bert_model.set_builder(builder)

    out = bert_model.forward(**_inputs, **kwargs)
    builder.make_output(out[0])
    sg = builder.build(name="bert")

    md = ModelDict()
    md.subgraphs = [sg]
    for idx, sg in enumerate(md.subgraphs):
        sg.idx = idx

    md.graph_order = [0]
    for iidx in sg.inputs:
        inact = sg.activations[iidx]
        md.inputs.append(inact.name)
    for oidx in sg.outputs:
        outact = sg.activations[oidx]
        md.outputs.append(outact.name)
    md.model_backend = "hf"
    md.set_main_sg(0)

    if make_value_dict:
        value_dict = {}
        for k, v in feed_dict.items():
            value_dict[k] = feed_dict[k]
        bert_model.set_value_dict(value_dict)
        bert_model.register_forward_hook()
        fd = {}
        for k, v in feed_dict.items():
            if isinstance(v, torch.Tensor):
                fd[k] = v.to(device)
            else:
                fd[k] = v
        bert_model.torch_compute(**fd)
        _value_dict = ValueDict()
        for k, v in value_dict.items():
            if isinstance(v, torch.Tensor):
                if v.dtype == torch.bfloat16:
                    v = v.to(torch.float32)
                v = v.detach().cpu().numpy()
            if isinstance(v, numpy.ndarray):
                _value_dict[k] = v
        value_dict = _value_dict
    else:
        value_dict = ValueDict()

    out = MobilintParserOutputs()
    out.model_dict = md
    out.const_dict = const_dict
    out.value_dict = value_dict
    return out
