from qbcompiler.model_dict.parser.backend.hf.parser import HFParser


def get_parser(model, **kwargs):
    return HFParser(model=model, **kwargs)
