import base64
import json
import os
import pathlib
from collections import namedtuple
from typing import Tuple, Dict

import numpy

from qbcompiler.model_dict.common.value_wrapper import ValueProviderABC, ValueWrapper

ArrayFileInfo = namedtuple("ArrayFileInfo", ["shape", "dtype", "path_to_file"])


class TorchInferenceValue(ValueProviderABC):
    def __init__(
        self,
        value: numpy.ndarray | None = None,
        shape: Tuple[int, ...] | None = None,
        dtype: str | None = None,
        base_dir: str | None = None,
        file_name: str | None = None,
    ):
        if value is not None:
            self._available = True
        else:
            self._available = False
            value = ArrayFileInfo(shape, dtype, os.path.join(base_dir, file_name))
        self._value: numpy.ndarray | ArrayFileInfo = value

    @property
    def value(self):
        if isinstance(self._value, numpy.ndarray):
            return self._value
        file_path = pathlib.Path(self._value.path_to_file)
        if not file_path.exists():
            raise FileNotFoundError(f"File does not exist: {file_path}")
        if file_path.stat().st_size == 0:
            raise ValueError(f"File is empty: {file_path}")
        b = file_path.read_bytes()
        return numpy.frombuffer(b, dtype=self.dtype).reshape(self.shape)

    def to_json(self):
        if isinstance(self._value, numpy.ndarray):
            raw_data = self.value.tobytes()
            return {
                "raw_data": base64.b64encode(raw_data).decode("utf-8"),
                "shape": list(self._value.shape),
                "dtype": str(self._value.dtype),
            }
        else:
            return {
                "shape": list(self._value.shape),
                "dtype": str(self._value.dtype),
                "path_to_file": self._value.path_to_file,
            }

    @property
    def value(self):
        if isinstance(self._value, numpy.ndarray):
            return self._value
        file_path = pathlib.Path(self._value.path_to_file)
        if not file_path.exists():
            raise FileNotFoundError(f"File does not exist: {file_path}")
        if file_path.stat().st_size == 0:
            raise ValueError(f"File is empty: {file_path}")
        b = file_path.read_bytes()
        return numpy.frombuffer(b, dtype=self.dtype).reshape(self.shape)

    @property
    def shape(self):
        return self._value.shape

    @property
    def dtype(self):
        return self._value.dtype

    def has_numpy_value(self):
        return isinstance(self._value, numpy.ndarray)

    @property
    def path_to_file(self):
        if isinstance(self._value, numpy.ndarray):
            raise ValueError(
                "The current OnnxInferenceValue instance contains a numpy.ndarray value."
            )
        return self._value.path_to_file

    @property
    def available(self):
        return self._available

    def astype(self, dtype: numpy.dtype):
        if isinstance(numpy.dtype(dtype), numpy.dtype):
            self._value = self._value.astype(dtype)
            return self
        else:
            raise NotImplementedError("Not implemented casting")

    def set_available(self):
        self._available = True


class TorchInferenceValueDict:
    def __init__(self):
        self._container: Dict[str, ValueWrapper] = {}

    def __setitem__(self, key, value):
        self._container[key] = value

    def __getitem__(self, key):
        return self._container[key]

    def __contains__(self, item):
        return item in self._container

    def __len__(self):
        return len(self._container)

    def __iter__(self):
        return iter(self._container)

    def items(self):
        return self._container.items()

    def keys(self):
        return self._container.keys()

    def values(self):
        return self._container.values()

    def update(self, dict: Dict):
        self._container.update(dict)

    def serialize(self, path_to_file: str):
        dct = {}
        for k, v in self._container.items():
            if isinstance(v._value, TorchInferenceValueDict):
                dct[k] = v._value.to_json()
            else:
                raise NotImplementedError(
                    f"Not implemented serializing({type(v._value)})"
                )
        with open(path_to_file, "w") as f:
            json.dump(dct, f)

    @staticmethod
    def deserialize(path_to_file: str) -> "TorchInferenceValueDict":
        obj = TorchInferenceValueDict()
        with open(path_to_file, "r") as f:
            dct = json.load(f)
            for k, v in dct.items():
                if "raw_data" in v:
                    oiv = TorchInferenceValue(
                        value=numpy.frombuffer(
                            base64.b64decode(v["raw_data"]), dtype=v["dtype"]
                        ).reshape(v["shape"])
                    )
                else:
                    oiv = TorchInferenceValue(
                        shape=v["shape"],
                        dtype=v["dtype"],
                        base_dir=os.path.dirname(v["path_to_file"]),
                        file_name=os.path.basename(v["path_to_file"]),
                    )
                obj[k] = ValueWrapper(oiv)
        return obj
