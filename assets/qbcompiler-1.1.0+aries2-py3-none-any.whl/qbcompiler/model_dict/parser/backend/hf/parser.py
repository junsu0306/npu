import pathlib

from qbcompiler.model_dict.common.parserabc import (
    ParserABC,
    MobilintParserInputs,
    MobilintParserOutputs,
)
from qbcompiler.model_dict.parser.backend.hf.make_modules import make_dynamic_object
from qbcompiler.model_dict.parser.backend.hf.transformers.parser import HFTransformersParser


class HFParser(ParserABC):
    def __init__(self, model, temp_dir: str, seed: int = 12345, **kwargs):
        super().__init__("", "hf", seed)
        self.model = model
        self._temp_dir = temp_dir
        self._module_parser = None

    def parse(
        self, parser_inputs: MobilintParserInputs, **kwargs
    ) -> MobilintParserOutputs:
        # todo: blip, whisper를 HFTransformersParser로 이동
        _module_name = self.model.__class__.__module__
        if _module_name.startswith("diffusers."):
            return self._parse_diffusers(parser_inputs, **kwargs)

        if _module_name.startswith(
            "transformers.models.blip.modeling_blip"
        ) or _module_name.startswith("transformers.models.whisper.modeling_whisper"):
            return self._parse_transformers(parser_inputs, **kwargs)

        if _module_name.startswith("transformers."):
            self._module_parser = HFTransformersParser(self.model, self._temp_dir)
        elif _module_name.startswith("transformers_modules."):
            self._module_parser = HFTransformersParser(self.model, self._temp_dir)
        else:
            raise NotImplementedError(f"model type={type(self.model)}")
        return self._module_parser.parse(parser_inputs, **kwargs)

    def _parse_diffusers(self, parser_inputs: MobilintParserInputs, **kwargs):
        _module_name = self.model.__class__.__module__
        value_dict_temp_dir = str(pathlib.Path(self._temp_dir).joinpath("value_dict"))

        if (
            _module_name
            == "diffusers.pipelines.stable_diffusion_3.pipeline_stable_diffusion_3"
        ):
            target = kwargs.pop("target", None)
            if target is None:
                raise Exception("target is None")

            make_value_dict = kwargs.pop("make_value_dict", False)
            module = make_dynamic_object(self.model, "")
            return module.parse(
                target=target,
                make_value_dict=make_value_dict,
                value_dict_temp_dir=value_dict_temp_dir,
                **kwargs,
            )

        raise NotImplementedError(f"model type={type(self.model)}")

    def _parse_transformers(self, parser_inputs: MobilintParserInputs, **kwargs):
        _module_name = self.model.__class__.__module__
        value_dict_temp_dir = str(pathlib.Path(self._temp_dir).joinpath("value_dict"))

        if (
            _module_name == "transformers.models.blip.modeling_blip"
            or _module_name == "transformers.models.whisper.modeling_whisper"
        ):
            target = kwargs.pop("target", None)
            if target is None:
                raise Exception("target is None")

            make_value_dict = kwargs.pop("make_value_dict", False)
            module = make_dynamic_object(self.model, "")
            if parser_inputs.feed_dict:
                return module.parse(
                    target=target,
                    make_value_dict=make_value_dict,
                    value_dict_temp_dir=value_dict_temp_dir,
                    feed_dict=parser_inputs.feed_dict,
                    **kwargs,
                )
            else:
                return module.parse(
                    target=target,
                    make_value_dict=make_value_dict,
                    value_dict_temp_dir=value_dict_temp_dir,
                    **kwargs,
                )
        else:
            raise NotImplementedError(_module_name)
