import functools
from typing import List, Tuple

from ._assets.built_in_options.SubGraph import SubGraph as tflite_SubGraph
from ._assets.util import gen_iter, get_as_list
from ._operator import Operator
from ._options import InputOptions
from ._tensor import TensorSpec, TensorIndex


class SubGraph:
    def __init__(self):
        self._name: str = ""
        self._inputs: List[int] = []  # index to input tensors
        self._outputs: List[int] = []  # index to input tensors
        self._operators: List[Operator] = []
        self._tensors: List[TensorSpec] = []
        self._generated_const = {}
        self._reshape_hint = {}
        self._input_ops = []  # index to input operator.

    @property
    def operators(self) -> List[Operator]:
        return self._operators

    @property
    def name(self) -> str:
        return self._name

    @property
    def inputs(self):
        return self._inputs

    @property
    def outputs(self):
        return self._outputs

    @property
    def input_tensors(self) -> Tuple[TensorSpec, ...]:
        return tuple(self._tensors[x] for x in self._inputs)

    @property
    def output_tensors(self) -> Tuple[TensorSpec, ...]:
        return tuple(self._tensors[x] for x in self._outputs)

    @property
    def tensors(self) -> List[TensorSpec]:
        return self._tensors

    def tensor(self, idx) -> TensorSpec:
        return self._tensors[idx]

    def get_generated_const(self, name: str):
        if name in self._generated_const:
            return self._generated_const[name]
        return None

    @staticmethod
    def get(
        subgraph: tflite_SubGraph,
        operator_list: List[str],
    ) -> "SubGraph":
        obj = SubGraph()
        obj._name = subgraph.Name().decode()
        obj._inputs = get_as_list(subgraph, "Inputs")
        obj._outputs = get_as_list(subgraph, "Outputs")

        ts_getter = functools.partial(TensorSpec.get, name_prepend="")
        obj._tensors = list(map(ts_getter, gen_iter(subgraph, "Tensors")))

        op_getter = functools.partial(Operator.get, operator_list=operator_list)
        obj._operators = list(map(op_getter, gen_iter(subgraph, "Operators")))
        return obj

    def set_tensor_shape_hint(self, value_dict, const_dict):
        def get_shape(tsname):
            if tsname in value_dict:
                return value_dict[tsname].shape
            if tsname in const_dict:
                return const_dict[tsname].shape
            raise KeyError(f"key:{tsname}")

        for idx in self.inputs:
            ts = self._tensors[idx]
            ts.set_shape_hint(get_shape(ts.name))

        for op in self.operators:
            for idx in op.builtin_options.iter_inputs():
                ts = self._tensors[idx]
                ts.set_shape_hint(get_shape(ts.name))
            for output_tensor_idx in op.builtin_options.iter_outputs():
                ts = self._tensors[output_tensor_idx]
                ts.set_shape_hint(get_shape(ts.name))

    def input_as_operator(self):
        _operator = []
        for op in self.operators:
            for iidx in op.builtin_options.iter_inputs():
                if iidx in self.inputs:
                    self._input_ops.append(len(_operator))
                    opt = InputOptions(TensorIndex(iidx), TensorIndex(iidx))
                    _operator.append(Operator("INPUT", builtin_options=opt))
            _operator.append(op)
        self._operators = _operator

    def add_tensor(self, ts: TensorSpec) -> TensorIndex:
        self._tensors.append(ts)
        return TensorIndex(len(self._tensors) - 1)
