import copy
import importlib
import pathlib
from dataclasses import dataclass
from typing import List, Dict, Any

import numpy

import qbcompiler.model_dict.common.model_dict as schema
from qbcompiler.model_dict.common.dataformat import DataFormat as schema_dataformat
from qbcompiler.model_dict.common.parserabc import (
    ParserABC,
    MobilintParserInputs,
    MobilintParserOutputs,
)
from .compat import tflite_subgraph_to_mobilint_subgraph

from ._operator import BuiltinOperator, Operator
from ._subgraph import SubGraph
from ._tensor import TensorMap, TensorSpec, BufferData, DataFormat
from ._assets.util import gen_iter

#
from ._assets.built_in_options.Model import Model as tflite_Model
from ._assets.built_in_options.SignatureDef import SignatureDef as tflite_SignatureDef


@dataclass(frozen=True)
class SignatureDef:
    inputs: List[TensorMap]
    outputs: List[TensorMap]
    subgraph_index: int

    @staticmethod
    def get(sig_def: tflite_SignatureDef):
        return SignatureDef(
            inputs=[TensorMap.get(inp) for inp in gen_iter(sig_def, "Inputs")],
            outputs=[TensorMap.get(outp) for outp in gen_iter(sig_def, "Outputs")],
            subgraph_index=sig_def.SubgraphIndex(),
        )


# noinspection PyBroadException
class TFLiteParser(ParserABC):
    def __init__(self, path_to_model: str, seed=12345, **kwargs):
        super().__init__(path_to_model, "tflite", seed)
        self._schema_version = -1
        self._signature_defs: List[SignatureDef] = []
        self._subgraphs: List[SubGraph] = []
        self._model = None
        self._operator_list: List = []

        self._const_dict = {}
        self._sg_main = None
        self._model_dict = None

        self._feed_dict = None

    def get_const_dict(self):
        return self._const_dict

    def get_model_dict(self):
        return self._model_dict

    def parse(
        self, parser_inputs: MobilintParserInputs, **kwargs
    ) -> MobilintParserOutputs:
        feed_dict = parser_inputs.feed_dict

        self._feed_dict = feed_dict

        self._load_tflite()
        self._load_operator_codes()
        self._load_signature_defs()
        self._load_subgraphs()

        # we do inference to get some missing information.
        self._ensure_feed_dict()

        value_dict_raw = self._get_value_dict()
        const_dict = self._get_const_dict()
        for k, v in const_dict.items():
            const_dict[k] = v.data
        self._sg_main.set_tensor_shape_hint(value_dict_raw, const_dict)
        self._sg_main.input_as_operator()
        model_dict = self._get_model_dict(self._sg_main, value_dict_raw, const_dict)

        value_dict = schema.ValueDict()
        for k, v in value_dict_raw.items():
            if len(v.shape) == 4 and v.shape[0] == 1:
                value_dict.add(k, v, schema_dataformat.NHWC)
            elif len(v.shape) == 2 and v.shape[0] == 1:
                value_dict.add(k, v, schema_dataformat.NC)
            else:
                value_dict.add(k, v, schema_dataformat.UNKNOWN)
        return MobilintParserOutputs(model_dict, const_dict, value_dict)

    def _get_model_dict(self, sg, value_dict, const_dict):
        main_sg = tflite_subgraph_to_mobilint_subgraph(sg, value_dict, const_dict)
        model_inputs = [main_sg.activations[i].name for i in main_sg.inputs]
        model_outputs = [main_sg.activations[i].name for i in main_sg.outputs]
        md = schema.ModelDict()
        md.subgraphs = [main_sg]
        main_sg.idx = 0
        md.graph_order = [0]
        md.inputs = model_inputs
        md.outputs = model_outputs
        md.model_backend = "tflite"
        return md

    def _get_rand_tensor_values(self, shape_, dtype_):
        if dtype_ == numpy.bool_:
            return numpy.full(shape=shape_, fill_value=False)
        if dtype_ == numpy.float32:
            return self._rng.uniform(low=-1.0, high=1.0, size=shape_).astype(dtype_)
        if dtype_ == numpy.uint8:
            return self._rng.integers(low=0, high=256, size=shape_, dtype=dtype_)
        if dtype_ == numpy.int32:
            return self._rng.integers(low=-128, high=128, size=shape_, dtype=dtype_)
        raise NotImplementedError("failed to generate random input.")

    def _get_rand_tensor_values_from_tensor_spec(self, ts: TensorSpec) -> numpy.ndarray:
        return self._get_rand_tensor_values(
            tuple(ts.shape), numpy.dtype(ts.type.lower())
        )

    def _get_feed_dict(self, feed_dict, sg: SubGraph):
        def need_new_input(ts: TensorSpec, fd: Dict):
            if ts.name not in fd:
                return True
            data_ = fd.get(ts.name)
            return tuple(data_.shape) != tuple(ts.shape) or numpy.dtype(
                data_.dtype
            ) != numpy.dtype(ts.type.lower())

        for tensor in sg.input_tensors:
            if need_new_input(tensor, feed_dict):
                feed_dict[tensor.name] = self._get_rand_tensor_values_from_tensor_spec(
                    tensor
                )

    def _ensure_feed_dict(self):
        """
        We have to keep separate feed_dict for each subgraph to avoid tensor name collision.
        """
        if self._feed_dict is None:
            self._feed_dict = {}
        for subgraph in self._subgraphs:
            if subgraph.name not in self._feed_dict:
                self._feed_dict[subgraph.name] = {}
            self._get_feed_dict(self._feed_dict[subgraph.name], subgraph)

    def _get_value_dict(self):
        """
        # This code addresses the indeterministic input/output tensor shape problem
        # for some operations.
        # - `Gather` operation on Batch Axis: the resulting tensor shape only determined at run time.
        # - `Reshape` operation with possibly variable shape information.

        Please refer to the following before you make any changes.
        https://github.com/tensorflow/tensorflow/blob/r2.9/tensorflow/lite/python/interpreter.py
        https://github.com/tensorflow/tensorflow/blob/r2.15/tensorflow/lite/python/interpreter.py

        ver == r2.9
            def get_tensor(self, tensor_index):
        ver >= r2.10
            def get_tensor(self, tensor_index, subgraph_index=0):

        we can also use the following method to avoid making the copy of the data.
        def tensor(tensor_index):
        """

        tf = importlib.import_module("tensorflow")
        interpreter = tf.lite.Interpreter(
            model_path=str(self._path_to_model), experimental_preserve_all_tensors=True
        )
        input_details = interpreter.get_input_details()
        # output_details = interpreter.get_output_details()
        interpreter.allocate_tensors()

        feed_dict_main = self._feed_dict[self._sg_main.name]
        for detail in input_details:
            interpreter.set_tensor(
                tensor_index=detail["index"], value=feed_dict_main[detail["name"]]
            )
        interpreter.invoke()

        _value_dct = {}
        for ts in self._sg_main.input_tensors:
            _value_dct[ts.name] = None

        for op in self._sg_main.operators:
            for idx in op.iter_outputs():
                ts = self._sg_main.tensor(idx)
                if ts.buffer != -1:
                    _value_dct[ts.name] = None
        for ts in self._sg_main.output_tensors:
            _value_dct[ts.name] = None

        tensor_details = interpreter.get_tensor_details()
        for detail in tensor_details:
            if detail["name"] in _value_dct:
                try:
                    # there is no way to check detail['index'] is valid index.
                    _value_dct[detail["name"]] = interpreter.get_tensor(detail["index"])
                except Exception as e:
                    continue
        return _value_dct

    def _load_tflite(self):
        with pathlib.Path(self._path_to_model).open("rb") as f:
            self._buf = bytearray(f.read())
        self._model = tflite_Model.GetRootAs(self._buf, 0)

    def _load_operator_codes(self):
        for x in gen_iter(self._model, "OperatorCodes"):
            self._operator_list.append(BuiltinOperator.name(x.BuiltinCode()))

    def _load_signature_defs(self):
        for x in gen_iter(self._model, "SignatureDefs"):
            self._signature_defs.append(SignatureDef.get(x))

    def _load_subgraphs(self):
        for x in gen_iter(self._model, "Subgraphs"):
            self._subgraphs.append(SubGraph.get(x, self._operator_list))

        for sg in self._subgraphs:
            if sg.name == "main":
                self._sg_main = sg

    def buffer(self, ts: TensorSpec) -> BufferData:
        assert ts.buffer < self._model.BuffersLength()
        buffer = self._model.Buffers(ts.buffer)
        if buffer.Offset() > 0:
            raise NotImplementedError("buffer offset > 0.")

        if buffer.DataLength() == 0 or buffer.DataIsNone():
            return BufferData(name=ts.name, data=None)

        if ts.shape_signature:
            raise NotImplementedError(f"shape_signature={ts.shape_signature}")

        # data are views to the original data when possible. do not alter
        data = numpy.frombuffer(
            buffer.DataAsNumpy(), dtype=numpy.dtype(ts.type.lower())
        ).reshape(ts.buffer_read_shape)

        return BufferData(name=ts.name, data=data)

    def _get_const_dict(self):
        const_dct = {}
        for sg in self._subgraphs:
            const_dct.update(self._get_sg_const_dict(sg))
        return const_dct

    def _get_sg_const_dict(self, sg: SubGraph):
        output_to_op_map = {}
        for op in sg.operators:
            for oidx in op.builtin_options.iter_outputs():
                output_to_op_map[oidx] = op

        dct = {}
        for op_idx, op in enumerate(sg.operators):
            for buffer_data in self._retrieve_operator_consts(sg, op, output_to_op_map):
                if buffer_data.data is None:
                    # skip input, output...
                    continue
                dct[buffer_data.name] = buffer_data
        return dct

    def _tconv_weight_to_ocichw(self, w):
        shape = w.shape
        wcp = copy.deepcopy(w)
        for i in range(shape[2]):
            for j in range(shape[3]):
                wcp[:, :, i, j] = w[:, :, shape[2] - 1 - i, shape[3] - 1 - j]
        return numpy.transpose(wcp, axes=(1, 0, 2, 3))

    def _retrieve_operator_consts(self, sg: SubGraph, op: Operator, output_to_op_map):
        for field_name, ts_idx in op.builtin_options.iter_tensor_index():
            if sg.tensor(ts_idx).buffer != -1:
                bdata = self.buffer(sg.tensor(ts_idx))
                if op.opname == "CONV_2D" and field_name == "weight":
                    bdata.data = self._ochwic_to_ocichw(bdata)
                elif op.opname == "DEPTHWISE_CONV_2D" and field_name == "weight":
                    bdata.data = self._ichwoc_to_ocichw(bdata)
                elif op.opname == "TRANSPOSE_CONV" and field_name == "weight":
                    bdata.data = self._tconv_weight_to_ocichw(
                        self._ochwic_to_icochw(bdata)
                    )
                elif op.opname == "FULLY_CONNECTED" and field_name == "weight":
                    bdata.data = self._fix_fc_weight(bdata, sg, op, output_to_op_map)
                yield bdata

    def _ochwic_to_ocichw(self, buffer_data):
        if buffer_data.data_format == DataFormat.NHWC:
            if len(buffer_data.data.shape) == 4:
                return numpy.transpose(buffer_data.data, axes=(0, 3, 1, 2))
        raise NotImplementedError

    def _ichwoc_to_ocichw(self, buffer_data):
        if buffer_data.data_format == DataFormat.NHWC:
            if len(buffer_data.data.shape) == 4:
                return numpy.transpose(buffer_data.data, axes=(3, 0, 1, 2))
        raise NotImplementedError

    def _ochwic_to_icochw(self, buffer_data):
        if buffer_data.data_format == DataFormat.NHWC:
            if len(buffer_data.data.shape) == 4:
                return numpy.transpose(buffer_data.data, axes=(3, 0, 1, 2))
        raise NotImplementedError

    def _fix_fc_weight(self, buffer_data, sg: SubGraph, fc: Operator, output_to_op_map):
        _weight = buffer_data.data
        prev_op = output_to_op_map.get(fc.builtin_options.input, None)
        if prev_op is not None and prev_op.opname == "FLATTEN":
            _, h, w, c = sg.tensor(prev_op.builtin_options.input).shape
            indexer = (
                numpy.arange(1 * h * w * c)
                .reshape((1, h, w, c))
                .transpose((0, 3, 1, 2))
                .reshape(1 * h * w * c)
            )
            return _weight[:, indexer]
        return _weight
