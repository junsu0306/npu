from qbcompiler.model_dict.parser.backend.tflite.parser import TFLiteParser

__all__ = ["get_parser"]


def get_parser(model_path: str, **kwargs):
    return TFLiteParser(path_to_model=model_path, **kwargs)
