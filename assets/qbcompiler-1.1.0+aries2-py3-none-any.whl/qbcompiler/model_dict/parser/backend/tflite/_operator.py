from dataclasses import dataclass
from typing import Dict, List, Any

from ._options import (
    BuiltinOptions,
    get_option_cls,
    ExtendedOptions,
    get_default_option,
    parse_custom_options,
)
from ._tensor import TensorSpec
from ._assets.built_in_options.BuiltinOperator import (
    BuiltinOperator as tfilie_BuiltinOperator,
)
from ._assets.built_in_options.Operator import Operator as tflite_Operator


class BuiltinOperator:
    _mapping: Dict[int, str] = {}

    @staticmethod
    def name(built_in_code: int):
        if built_in_code not in BuiltinOperator._mapping:
            for k, v in tfilie_BuiltinOperator.__dict__.items():
                if v == built_in_code:
                    BuiltinOperator._mapping[v] = k
                    return k
        return BuiltinOperator._mapping[built_in_code]


_impl_status = {
    "INPUT": {
        "type": "Input",
        "option_type": "InputOptions",
        "implemented": True,
        "supported": True,
    },
    "CAST": {
        "type": "Cast",
        "option_type": "CastOptions",
        "implemented": True,
        "supported": False,
    },
    "WHILE": {
        "type": "While",
        "option_type": "WhileOptions",
        "implemented": False,
        "supported": False,
    },
    "TRANSPOSE_CONV": {
        "type": "TransposeConvolution",
        "option_type": "TransposeConvOptions",
        "implemented": True,
        "supported": True,
    },
    "CONV_2D": {
        "type": "Convolution",
        "option_type": "Conv2DOptions",
        "implemented": True,
        "supported": True,
    },
    "DEPTHWISE_CONV_2D": {
        "type": "DepthwiseConvolution",
        "option_type": "DepthwiseConv2DOptions",
        "implemented": True,
        "supported": True,
    },
    "MAX_POOL_2D": {
        "type": "MaxPool",
        "option_type": "Pool2DOptions",
        "implemented": True,
        "supported": True,
    },
    "AVERAGE_POOL_2D": {
        "type": "AvgPool",
        "option_type": "Pool2DOptions",
        "implemented": True,
        "supported": True,
    },
    "ADD": {
        "type": "Adding",
        "option_type": "AddOptions",
        "implemented": True,
        "supported": True,
    },
    "MEAN": {
        "type": "ReduceMean",
        "option_type": None,
        "implemented": True,
        "supported": False,
    },
    "SOFTMAX": {
        "type": "Softmax",
        "option_type": "SoftmaxOptions",
        "implemented": True,
        "supported": False,
    },
    "RESHAPE": {
        "type": "Reshape",
        "option_type": "ReshapeOptions",
        "implemented": True,
        "supported": False,
    },
    "GEMM": {
        "type": "Gemm",
        "option_type": "GemmConstantOptions",
        "implemented": True,
        "supported": False,
    },
    "FLATTEN": {
        "type": "Flatten",
        "option_type": "FlattenOptions",
        "implemented": True,
        "supported": False,
    },
    "SHAPE": {
        "type": "Shape",
        "option_type": "ShapeOptions",
        "implemented": True,
        "supported": True,
    },
    "STRIDED_SLICE": {
        "type": "StridedSlice",
        "option_type": "StridedSliceOptions",
        "implemented": True,
        "supported": False,
    },
    "UNSQUEEZE": {
        "type": "Unsqueeze",
        "option_type": "UnsqueezeOptions",
        "implemented": False,
        "supported": False,
    },
    "RESIZE_BILINEAR": {
        "type": "Resize",
        "option_type": "ResizeBilinearOptions",
        "implemented": True,
        "supported": True,
    },
    "CONCATENATION": {
        "type": "Concatenate",
        "option_type": "ConcatenationOptions",
        "implemented": True,
        "supported": True,
    },
    "SLICE": {
        "type": "Slice",
        "option_type": "SliceOptions",
        "implemented": True,
        "supported": False,
    },
    "GATHER": {
        "type": "Gather",
        "option_type": "GatherOptions",
        "implemented": True,
        "supported": False,
    },
    "MUL": {
        "type": "Multiply",
        "option_type": "",
        "implemented": True,
        "supported": True,
    },
    "SUB": {
        "type": "Sub",
        "option_type": "SubOptions",
        "implemented": True,
        "supported": True,
    },
    "DIV": {
        "type": "Div",
        "option_type": "DivOptions",
        "implemented": True,
        "supported": False,
    },
    "EXP": {
        "type": "Exp",
        "option_type": "ExpOptions",
        "implemented": True,
        "supported": False,
    },
    "RELU": {
        "type": "Relu",
        "option_type": "ReluOptions",
        "implemented": True,
        "supported": False,
    },
    "RELU6": {
        "type": "Relu6",
        "option_type": "ReluOptions",
        "implemented": True,
        "supported": False,
    },
    "GELU": {
        "type": "Gelu",
        "option_type": "GeluOptions",
        "implemented": True,
        "supported": False,
    },
    "CLIP": {
        "type": "Clip",
        "option_type": "ClipOptions",
        "implemented": True,
        "supported": False,
    },
    "TILE": {
        "type": "Tile",
        "option_type": "TileOptions",
        "implemented": False,
        "supported": False,
    },
    "LOGISTIC": {
        "type": "Sigmoid",
        "option_type": "SigmoidOptions",
        "implemented": True,
        "supported": False,
    },
    "TRANSPOSE": {
        "type": "Transpose",
        "option_type": "TransposeOptions",
        "implemented": True,
        "supported": False,
    },
    "UNPACK": {
        "type": "Unpack",
        "option_type": "UnpackOptions",
        "implemented": True,
        "supported": False,
    },
    "PACK": {
        "type": "Pack",
        "option_type": "PackOptions",
        "implemented": True,
        "supported": False,
    },
    "ROUND": {
        "type": "Round",
        "option_type": "RoundOptions",
        "implemented": False,
        "supported": False,
    },
    "EQUAL": {
        "type": "Equal",
        "option_type": "EqualOptions",
        "implemented": False,
        "supported": False,
    },
    "NOT_EQUAL": {
        "type": "NotEqual",
        "option_type": "NotEqualOptions",
        "implemented": False,
        "supported": False,
    },
    "GREATER": {
        "type": "Greater",
        "option_type": "GreaterOptions",
        "implemented": True,
        "supported": False,
    },
    "GREATER_EQUAL": {
        "type": "GreaterEqual",
        "option_type": "GreaterEqualOptions",
        "implemented": False,
        "supported": False,
    },
    "LESS": {
        "type": "Less",
        "option_type": "LessOptions",
        "implemented": True,
        "supported": False,
    },
    "LESS_EQUAL": {
        "type": "LessEqual",
        "option_type": "LessEqualOptions",
        "implemented": False,
        "supported": False,
    },
    "LOGICAL_AND": {
        "type": "LogicalAnd",
        "option_type": "LogicalAndOptions",
        "implemented": False,
        "supported": False,
    },
    "LOGICAL_OR": {
        "type": "LogicalOr",
        "option_type": "LogicalOrOptions",
        "implemented": False,
        "supported": False,
    },
    "MINIMUM": {
        "type": "Minimum",
        "option_type": "MaximumMinimumOptions",
        "implemented": True,
        "supported": False,
    },
    "MAXIMUM": {
        "type": "Maximum",
        "option_type": "MaximumMinimumOptions",
        "implemented": True,
        "supported": False,
    },
    "TOPK_V2": {
        "type": "TOPK_V2",
        "option_type": "TopKV2Options",
        "implemented": True,
        "supported": False,
    },
    "TopKValues": {
        "type": "TopKValues",
        "option_type": "TopKValuesOptions",
        "implemented": True,
        "supported": False,
    },
    "TopKIndices": {
        "type": "TopKIndices",
        "option_type": "TopKIndicesOptions",
        "implemented": True,
        "supported": False,
    },
    "SELECT": {
        "type": "Select",
        "option_type": "SelectOptions",
        "implemented": False,
        "supported": False,
    },
    "SELECT_V2": {
        "type": "Select",
        "option_type": "SelectV2Options",
        "implemented": False,
        "supported": False,
    },
    "PADV2": {
        "type": "Pad",
        "option_type": "PadV2Options",
        "implemented": True,
        "supported": True,
    },
    "PAD": {
        "type": "Pad",
        "option_type": "PadOptions",
        "implemented": True,
        "supported": True,
    },
    "SQUEEZE": {
        "type": "Squeeze",
        "option_type": "SqueezeOptions",
        "implemented": True,
        "supported": False,
    },
    "SPLIT": {
        "type": "Split",
        "option_type": "SplitOptions",
        "implemented": True,
        "supported": True,
    },
    "GENERATED_SPLIT": {
        "type": "Split",
        "option_type": "GeneratedSplitOptions",
        "implemented": True,
        "supported": True,
    },
    "REDUCE_ANY": {
        "type": "Pad",
        "option_type": "ReducerOptions",
        "implemented": False,
        "supported": False,
    },
    "SUM": {
        "type": "ReduceSum",
        "option_type": "ReducerOptions",
        "implemented": True,
        "supported": False,
    },
    "REDUCE_MAX": {
        "type": "ReduceMax",
        "option_type": "ReducerOptions",
        "implemented": True,
        "supported": False,
    },
    "REDUCE_MIN": {
        "type": "ReduceMin",
        "option_type": "ReducerOptions",
        "implemented": False,
        "supported": False,
    },
    "REDUCE_ALL": {
        "type": "ReduceAll",
        "option_type": "ReducerOptions",
        "implemented": False,
        "supported": False,
    },
    "IDENTITY": {
        "type": "Identity",
        "option_type": "IdentityOptions",
        "implemented": True,
        "supported": True,
    },
    "NON_MAX_SUPPRESSION_V4": {
        "type": "NonMaxSuppression",
        "option_type": "NonMaxSuppressionV5Options",
        "implemented": True,
        "supported": False,
    },
    "NON_MAX_SUPPRESSION_V5": {
        "type": "NonMaxSuppression",
        "option_type": "NonMaxSuppressionV5Options",
        "implemented": True,
        "supported": False,
    },
    "RESIZE_NEAREST_NEIGHBOR": {
        "type": "Resize",
        "option_type": "ResizeNearestNeighborOptions",
        "implemented": True,
        "supported": True,
    },
    "ARG_MAX": {
        "type": "Argmax",
        "option_type": "ArgMaxOptions",
        "implemented": True,
        "supported": False,
    },
    "FusedBatchNormV3": {
        "type": "Batchnorm",
        "option_type": "FusedBatchNormV3Options",
        "implemented": True,
        "supported": False,
    },
    "LEAKY_RELU": {
        "type": "LeakyRelu",
        "option_type": "LeakyReluOptions",
        "implemented": True,
        "supported": True,
    },
    "SPLIT_V": {
        "type": "Split",
        "option_type": "SplitVOptions",
        "implemented": True,
        "supported": False,
    },
    "HARD_SWISH": {
        "type": "H-Swish",
        "option_type": "HardSwishOptions",
        "implemented": True,
        "supported": False,
    },
    "SQUARED_DIFFERENCE": {
        "type": "H-Swish",
        "option_type": "SquaredDifferenceOptions",
        "implemented": False,
        "supported": False,
    },
    "RSQRT": {
        "type": "Rsqrt",
        "option_type": "RsqrtOptions",
        "implemented": True,
        "supported": False,
    },
    "POW": {
        "type": "pow",
        "option_type": "PowOptions",
        "implemented": True,
        "supported": False,
    },
    "MOD": {
        "type": "mod",
        "option_type": "ModOptions",
        "implemented": True,
        "supported": False,
    },
    "FILL": {
        "type": "Fill",
        "option_type": "FillOptions",
        "implemented": True,
        "supported": False,
    },
    "ABS": {
        "type": "Abs",
        "option_type": "AbsOptions",
        "implemented": True,
        "supported": False,
    },
    "FLOOR": {
        "type": "floor",
        "option_type": "FloorOptions",
        "implemented": True,
        "supported": False,
    },
    "FLOOR_DIV": {
        "type": "FloorDiv",
        "option_type": "FloorDivOptions",
        "implemented": True,
        "supported": False,
    },
    "FLOOR_MOD": {
        "type": "FloorMod",
        "option_type": "FloorModOptions",
        "implemented": True,
        "supported": False,
    },
    "SPACE_TO_BATCH_ND": {
        "type": "SpaceToBatch",
        "option_type": "SpaceToBatchNDOptions",
        "implemented": True,
        "supported": False,
    },
    "BATCH_TO_SPACE_ND": {
        "type": "BatchToSpace",
        "option_type": "BatchToSpaceNDOptions",
        "implemented": True,
        "supported": False,
    },
    "TANH": {
        "type": "Tanh",
        "option_type": "TanhOptions",
        "implemented": True,
        "supported": False,
    },
}


def _all_implemented():
    return list(k for k, v in _impl_status.keys() if v["implemented"])


def get_impl_status(opname):
    if opname in _impl_status:
        return _impl_status[opname]
    raise KeyError(
        f"{opname} not found. implemented tflite operator list={_all_implemented()}"
    )


@dataclass(frozen=True)
class Operator:
    opname: str
    builtin_options: Any
    const_casted: bool = False  # helper attribute

    def set_const_casted(self, val):
        super().__setattr__("const_casted", val)

    def iter_inputs(self):
        """Generator[TensorIndex]"""
        yield from self.builtin_options.iter_inputs()

    def iter_outputs(self):
        """Generator[TensorIndex]"""
        yield from self.builtin_options.iter_outputs()

    def iter_tensor_index(self):
        """Generator[Tuple[str, TensorIndex]]"""
        yield from self.builtin_options.iter_tensor_index()

    @staticmethod
    def get(op: tflite_Operator, operator_list: List[str]):
        opname = operator_list[op.OpcodeIndex()]
        opt_type = op.BuiltinOptionsType()
        if opt_type == 0:
            if op.CustomOptionsIsNone():
                # has no options. add default option
                option_name = get_impl_status(opname)["option_type"]
                opt_type = BuiltinOptions.type(option_name)
                if opt_type is None:
                    opt_type = ExtendedOptions.type(option_name)
                option = get_default_option(op, get_option_cls(opt_type))
            else:
                opname, option = parse_custom_options(op)
        else:
            option_cls = get_option_cls(opt_type)
            if hasattr(option_cls, "get"):
                option = option_cls.get(op)
            else:
                option = get_default_option(op, option_cls)

        return Operator(
            opname=opname,
            builtin_options=option,
        )

    def as_dict(self, tensors: List[TensorSpec]):
        rule = get_impl_status(self.opname)
        dct = {"type": rule["type"]}
        kwargs = {"opname": self.opname}
        dct.update(self.builtin_options.as_dict(tensors, **kwargs))
        dct["unsupported"] = not rule["supported"]
        dct["tflite_implemented"] = rule["implemented"]

        return dct
