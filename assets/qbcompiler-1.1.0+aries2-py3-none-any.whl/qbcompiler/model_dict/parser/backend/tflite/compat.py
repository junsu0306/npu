import dataclasses
import itertools
from collections import namedtuple
from typing import Dict

import numpy

import qbcompiler.model_dict.common.item_specs as schema_spec
import qbcompiler.model_dict.common.operator
import qbcompiler.model_dict.common.options as mob_options
import qbcompiler.model_dict.common.subgraph
from qbcompiler.model_dict.common import DataFormat
from qbcompiler.model_dict.common.operator import Operator as mob_Operator
from ._operator import Operator
from ._subgraph import SubGraph as Subgraph
from ._tensor import TensorIndex

_tflite_opname_to_mobilnt_option_name = {
    "INPUT": "Input",
    "CAST": "Cast",
    "CONV_2D": "Convolution",
    "DEPTHWISE_CONV_2D": "DepthwiseConvolution",
    "TRANSPOSE_CONV": "TransposeConvolution",
    "ADD": "Adding",
    "EXP": "Exp",
    "LESS": "LessV2",
    "GREATER": "Greater",
    "MINIMUM": "Minimum",
    "AVERAGE_POOL_2D": "Pooling",
    "FULLY_CONNECTED": "GemmConstant",
    "SOFTMAX": "Softmax",
    "MEAN": "ReduceMean",
    "SQUARED_DIFFERENCE": "SquaredDifference",
    "RSQRT": "Rsqrt",
    "MUL": "Multiply",
    "DIV": "Div",
    "SUB": "Sub",
    "SHAPE": "Shape",
    "GATHER": "Gather",
    "REDUCE_PROD": "ReduceProd",
    "SUM": "ReduceSum",
    "CONCATENATION": "Concatenate",
    "PACK": "Pack",
    "UNPACK": "Unpack",
    "RESHAPE": "Reshape",
    "GELU": "Gelu",
    "RELU": "Relu",
    "RELU6": "Clip",
    "PAD": "PadGeneric",
    "PADV2": "PadGeneric",
    "MAX_POOL_2D": "Pooling",
    "STRIDED_SLICE": "StridedSlice",
    "FILL": "Full",
    "LOGISTIC": "Sigmoid",
    "RESIZE_BILINEAR": "Resize",
    "RESIZE_NEAREST_NEIGHBOR": "Resize",
    "ABS": "Abs",
    "TOPK_V2": "TopK",
    "FLOOR_DIV": "FloorDiv",
    "FLOOR_MOD": "FloorMod",
    "SPLIT": "SplitV2",
    "SPLIT_V": "SplitV2",
    "HARD_SWISH": "HardSwish",
    "LEAKY_RELU": "LeakyRelu",
    "TRANSPOSE": "Transpose",
    "SLICE": "Slice",
    "TANH": "Tanh",
    "SPACE_TO_BATCH_ND": "SpaceToBatchND",
    "BATCH_TO_SPACE_ND": "BatchToSpaceND",
}


_PadValue = namedtuple(
    "_PadValue", ["north_padding", "south_padding", "east_padding", "west_padding"]
)

_HWC = namedtuple("_HWD", "h w c")

_WEIGHT_SHAPE = namedtuple("_WEIGHT_SHAPE", "out_ch in_ch height width")


def _resolve_tconv_padding(
    padding: str,
    kernel_h,
    kernel_w,
    stride_h,
    stride_w,
    padding_list=None,
):
    if padding == "None":
        return _PadValue(0, 0, 0, 0)

    if padding == "VALID":
        return _PadValue(kernel_h - 1, kernel_h - 1, kernel_w - 1, kernel_w - 1)

    if padding == "SAME":
        pad_height = (kernel_h - 1) + (stride_h - 1)
        pad_width = (kernel_w - 1) + (stride_w - 1)
        p_s = int(pad_height // 2)
        p_n = int(pad_height - p_s)
        p_e = int(pad_width // 2)
        p_w = int(pad_width - p_e)
        return _PadValue(  # NPU's north, south is inversed
            north_padding=p_s, south_padding=p_n, east_padding=p_e, west_padding=p_w
        )

    if padding == "EXPLICIT":
        p_n, p_w, p_s, p_e = padding_list
        return _PadValue(  # NPU's north, south is inversed
            north_padding=p_s, south_padding=p_n, east_padding=p_e, west_padding=p_w
        )
    raise NotImplementedError(f"padding={padding}")


def _resolve_conv_padding(
    padding: str,
    input_h,
    input_w,
    kernel_h,
    kernel_w,
    stride_h,
    stride_w,
    dilation_h,
    dilation_w,
    padding_list=None,
) -> _PadValue:
    if padding == "None":
        return _PadValue(0, 0, 0, 0)

    if padding == "VALID":
        dilated_ker_h = (kernel_h - 1) * dilation_h + 1
        dilated_ker_w = (kernel_w - 1) * dilation_w + 1
        p_w, p_e, p_s, p_n = 0, 0, 0, 0
        residual_h = (input_h + p_n + p_s - dilated_ker_h) % stride_h
        residual_w = (input_w + p_w + p_e - dilated_ker_w) % stride_w
        p_s = max(p_s - residual_h, 0)
        p_e = max(p_e - residual_w, 0)
        return _PadValue(  # NPU's north, south is inversed
            north_padding=p_s, south_padding=p_n, east_padding=p_e, west_padding=p_w
        )
    if padding == "SAME":
        output_h = numpy.ceil(float(input_h) / float(stride_h))
        output_w = numpy.ceil(float(input_w) / float(stride_w))
        pad_height = max((output_h - 1) * stride_h + kernel_h - input_h, 0)
        pad_width = max((output_w - 1) * stride_w + kernel_w - input_w, 0)
        p_n = int(pad_height // 2)
        p_s = int(pad_height - p_n)
        p_w = int(pad_width // 2)
        p_e = int(pad_width - p_w)
        return _PadValue(  # NPU's north, south is inversed
            north_padding=p_s, south_padding=p_n, east_padding=p_e, west_padding=p_w
        )

    if padding == "EXPLICIT":
        if padding_list is None or not padding_list:
            raise Exception("padding_list is None or  padding_list is empty")
        # return _PadValue(*padding_list)
    raise NotImplementedError(f"padding={padding}")


def _conv_output_size(
    input_shape: _HWC,
    kernel_h,
    kernel_w,
    dilation_h,
    dilation_w,
    stride_h,
    stride_w,
    pad: _PadValue,
    out_ch,
) -> _HWC:
    dilated_ker_h = (kernel_h - 1) * dilation_h + 1
    dilated_ker_w = (kernel_w - 1) * dilation_w + 1
    output_h = (
        input_shape.h + pad.north_padding + pad.south_padding - dilated_ker_h
    ) // stride_h + 1
    output_w = (
        input_shape.w + pad.east_padding + pad.west_padding - dilated_ker_w
    ) // stride_w + 1
    return _HWC(output_h, output_w, out_ch)


def _sample_input_shape(ts, sample_value_dict):
    ishape = sample_value_dict[ts.name].shape
    if len(ishape) == 4:
        return _HWC(*ishape[1:])
    if len(ishape) == 3:
        return _HWC(*ishape)
    raise NotImplementedError


class _SubGraphToMobilintSubGraph:
    def __init__(self, sg: Subgraph, const_dict, sample_value_dict):
        self.sg = sg
        self.const_dict = const_dict
        self.sample_value_dict = sample_value_dict

        self._mob_acts = None
        self._actname_to_actidx = None
        self._mob_ops = []
        self._mob_tensors = []

    def _get_mob_activations(self):
        act_names = set()
        acts = []
        for op in self.sg.operators:
            for idx in itertools.chain(
                op.builtin_options.iter_inputs(), op.builtin_options.iter_outputs()
            ):
                ts = self.sg.tensor(idx)
                if ts.name not in act_names:
                    act_names.add(ts.name)
                    if ts.name in self.sample_value_dict:
                        src_shape = self.sample_value_dict[ts.name].shape
                    elif ts.name in self.const_dict:
                        src_shape = self.const_dict[ts.name].shape
                    else:
                        raise NotImplementedError("code should not re reached!")
                    maybe_supported_shape = len(ts.shape) == 4 and ts.shape[0] == 1
                    shape = (-1, -1, -1)
                    dformat = DataFormat.UNKNOWN
                    if maybe_supported_shape:
                        shape = tuple(ts.shape[1:])
                        if op.opname in (
                            "INPUT",
                            "TRANSPOSE_CONV",
                            "CONV_2D",
                            "DEPTHWISE_CONV_2D",
                        ):
                            dformat = DataFormat.NHWC
                    acts.append(
                        schema_spec.ActivationSpec(
                            ts.name,
                            ts.type,
                            shape=shape,
                            src_shape=src_shape,
                            dataformat=dformat,
                        )
                    )
        return acts

    def _get_default_options_dct(self, op: Operator):
        def _act_index(tensor_idx):
            return self._actname_to_actidx[self.sg.tensors[tensor_idx].name]

        dct = dataclasses.asdict(op.builtin_options)
        for k in ("input", "input0", "input1", "inputs", "output", "outputs"):
            if k in dct:
                dct.pop(k)
        dct["inputs"] = tuple(_act_index(i) for i in op.builtin_options.iter_inputs())
        dct["outputs"] = tuple(_act_index(i) for i in op.builtin_options.iter_outputs())
        if "pot_scale_int16" in dct:
            dct.pop("pot_scale_int16")
        return dct

    def _conv2d_fix(
        self,
        builtin_options,
        option_dct,
    ):
        input_shape = _sample_input_shape(
            self.sg.tensors[builtin_options.input], self.sample_value_dict
        )
        oc, h, w, ic = self.sg.tensors[builtin_options.weight].shape
        weight_shape = _WEIGHT_SHAPE(oc, ic, h, w)
        pad = _resolve_conv_padding(
            padding=option_dct["padding"],
            input_h=input_shape.h,
            input_w=input_shape.w,
            kernel_h=weight_shape.height,
            kernel_w=weight_shape.width,
            stride_h=option_dct["h_stride"],
            stride_w=option_dct["w_stride"],
            dilation_h=option_dct["h_dilation"],
            dilation_w=option_dct["w_dilation"],
            padding_list=option_dct.get("padding_list", None),
        )
        output_shape = _conv_output_size(
            input_shape,
            kernel_h=weight_shape.height,
            kernel_w=weight_shape.width,
            dilation_h=option_dct["h_dilation"],
            dilation_w=option_dct["w_dilation"],
            stride_h=option_dct["h_stride"],
            stride_w=option_dct["w_stride"],
            pad=pad,
            out_ch=weight_shape.out_ch,
        )
        group_number = int(input_shape.c / weight_shape.in_ch)

        option_dct["h_kernel"] = weight_shape.height
        option_dct["w_kernel"] = weight_shape.width
        option_dct["in_channels"] = input_shape.c
        option_dct["out_channels"] = output_shape.c
        option_dct["group_number"] = group_number
        option_dct.update(pad._asdict())
        option_dct.pop("padding")
        if option_dct["bias"] is None:
            option_dct.pop("bias")
        return option_dct

    def _transpose_conv_fix(self, builtin_options, option_dct):
        oc, h, w, ic = self.sg.tensors[builtin_options.weight].shape
        weight_shape = _WEIGHT_SHAPE(oc, ic, h, w)
        input_shape = _sample_input_shape(
            self.sg.tensors[builtin_options.input], self.sample_value_dict
        )
        pad = _resolve_tconv_padding(
            padding=option_dct["padding"],
            kernel_h=weight_shape.height,
            kernel_w=weight_shape.width,
            stride_h=option_dct["h_stride"],
            stride_w=option_dct["w_stride"],
            padding_list=option_dct.get("padding_list", None),
        )

        option_dct["group_number"] = int(input_shape.c / weight_shape.in_ch)
        option_dct["in_channels"] = weight_shape.in_ch
        option_dct["out_channels"] = weight_shape.out_ch
        option_dct["h_kernel"] = weight_shape.height
        option_dct["w_kernel"] = weight_shape.width
        option_dct["h_dilation"] = 1
        option_dct["w_dilation"] = 1
        option_dct["west_padding"] = pad.west_padding
        option_dct["east_padding"] = pad.east_padding
        # NPU's north, south is inversed
        option_dct["north_padding"] = pad.south_padding
        option_dct["south_padding"] = pad.north_padding

        option_dct.pop("output_size")
        option_dct.pop("padding")
        option_dct.pop("quantized_bias_type")
        if option_dct["bias"] is None:
            option_dct.pop("bias")

        return option_dct

    def _depthwise_conv2d_fix(
        self,
        builtin_options,
        option_dct,
    ):
        input_shape = _sample_input_shape(
            self.sg.tensors[builtin_options.input], self.sample_value_dict
        )
        # oc, h, w, ic = self.sg.tensors[builtin_options.weight].shape
        ic, h, w, oc = self.sg.tensors[builtin_options.weight].shape
        weight_shape = _WEIGHT_SHAPE(oc, ic, h, w)
        pad = _resolve_conv_padding(
            padding=option_dct["padding"],
            input_h=input_shape.h,
            input_w=input_shape.w,
            kernel_h=weight_shape.height,
            kernel_w=weight_shape.width,
            stride_h=option_dct["h_stride"],
            stride_w=option_dct["w_stride"],
            dilation_h=option_dct["h_dilation"],
            dilation_w=option_dct["w_dilation"],
            padding_list=option_dct.get("padding_list", None),
        )
        output_shape = _conv_output_size(
            input_shape,
            kernel_h=weight_shape.height,
            kernel_w=weight_shape.width,
            dilation_h=option_dct["h_dilation"],
            dilation_w=option_dct["w_dilation"],
            stride_h=option_dct["h_stride"],
            stride_w=option_dct["w_stride"],
            pad=pad,
            out_ch=weight_shape.out_ch,
        )
        option_dct["h_kernel"] = weight_shape.height
        option_dct["w_kernel"] = weight_shape.width
        option_dct["in_channels"] = input_shape.c
        option_dct["out_channels"] = output_shape.c
        option_dct["group_number"] = input_shape.c
        option_dct.update(pad._asdict())
        option_dct.pop("padding")
        option_dct.pop("depth_multiplier")
        if option_dct["bias"] is None:
            option_dct.pop("bias")
        return option_dct

    def _reduce_fix(self, builtin_options, option_dct):
        ts = self.sg.tensors[builtin_options.reduce_axes]
        if ts.name in self.const_dict:
            if self.const_dict[ts.name].shape:
                option_dct["reduce_axes"] = tuple(
                    int(x) for x in self.const_dict[ts.name]
                )
            else:
                option_dct["reduce_axes"] = (int(self.const_dict[ts.name]),)
        elif ts.name in self.sample_value_dict:
            option_dct["reduce_axes"] = tuple(
                int(x) for x in self.sample_value_dict[ts.name]
            )
        else:
            raise NotImplementedError
        return option_dct

    def _pool_fix_common(self, builtin_options, option_dct, pool_type):
        input_shape = _sample_input_shape(
            self.sg.tensors[builtin_options.input], self.sample_value_dict
        )
        pad = _resolve_conv_padding(
            padding=option_dct["padding"],
            input_h=input_shape.h,
            input_w=input_shape.w,
            kernel_h=option_dct["h_kernel"],
            kernel_w=option_dct["w_kernel"],
            stride_h=option_dct["h_stride"],
            stride_w=option_dct["w_stride"],
            dilation_h=option_dct["h_dilation"],
            dilation_w=option_dct["w_dilation"],
        )
        option_dct["pad_mode"] = "constant"
        option_dct["pool_type"] = pool_type
        option_dct.update(pad._asdict())
        option_dct.pop("padding")
        option_dct.pop("padding_list")
        option_dct.pop("data_format")
        return option_dct

    def _avgpool2d_fix(self, builtin_options, option_dct):
        return self._pool_fix_common(builtin_options, option_dct, "AvgPool")

    def _maxpool2d_fix(self, builtin_options, option_dct):
        return self._pool_fix_common(builtin_options, option_dct, "MaxPool")

    def _fully_connected_fix(self, builtin_options, option_dct):
        option_dct.pop("weights_format")
        option_dct.pop("keep_num_dims")
        option_dct.pop("asymmetric_quantize_inputs")
        option_dct.pop("quantized_bias_type")
        option_dct["transB"] = True
        option_dct["constant"] = option_dct.pop("weight")
        return option_dct

    def _shape_fix(self, builtin_options, option_dct):
        option_dct.pop("out_type")
        option_dct["start"] = 0
        option_dct["end"] = -1
        return option_dct

    def _reshape_fix(self, builtin_options, option_dct):
        ts_shape_name = self.sg.tensors[builtin_options.shape].name
        if ts_shape_name in self.const_dict:
            option_dct.pop("shape")
            option_dct["new_shape"] = tuple(self.const_dict[ts_shape_name])
        elif ts_shape_name in self.sample_value_dict:
            "will be parsed to ReshapeV2"
            option_dct["inputs"] = (
                option_dct["inputs"][0],
                self._actname_to_actidx[ts_shape_name],
            )
            option_dct.pop("shape")
            option_dct.pop("new_shape")
        else:
            raise NotImplementedError("unable to find shape value.")
        return option_dct

    def _pad_fix(self, builtin_options, option_dct):
        # p_n, p_w, p_s, p_e = new_padding_list
        ts_pad = self.sg.tensors[builtin_options.pad]
        if ts_pad == -1:
            raise NotImplementedError
        ts_val = self.const_dict[ts_pad.name]
        input_shape = self.sg.tensors[builtin_options.input].shape
        pad_begin, pad_ends = [], []
        for ax in ts_val:
            pad_begin.append(int(ax[0]))
            pad_ends.append(int(ax[1]))
        pad_values = pad_begin + pad_ends
        if len(input_shape) * 2 != len(pad_values):
            raise NotImplementedError
        # p_n, p_s = ts_val[1]
        # p_w, p_e = ts_val[2]
        constant = option_dct.pop("constant_values", None)
        if isinstance(constant, TensorIndex):
            constant = self._get_const_val(constant)

        # option_dct["west_padding"] = p_w
        # option_dct["east_padding"] = p_e
        # option_dct["south_padding"] = p_n
        # option_dct["north_padding"] = p_s
        option_dct["constant"] = constant
        option_dct["padding_list"] = pad_values
        option_dct.pop("pad")
        return option_dct

    def _get_const_val(self, tensor_idx):
        return self.const_dict[self.sg.tensors[tensor_idx].name]

    def _strided_slice_fix(self, builtin_options, option_dct):
        option_dct["begin"] = tuple(self._get_const_val(builtin_options.begin))
        option_dct["end"] = tuple(self._get_const_val(builtin_options.end))
        option_dct["stride"] = tuple(self._get_const_val(builtin_options.stride))
        return option_dct

    def _slice_fix(self, builtin_options, option_dct):
        start = self._get_const_val(builtin_options.begin)
        size = self._get_const_val(builtin_options.size)

        axis = list(range(len(size)))
        start = list(start)
        step = [1 for _ in range(len(size))]
        end = [st_ + sz_ for st_, sz_ in zip(start, size)]

        option_dct["axis"] = axis
        option_dct["start"] = start
        option_dct["end"] = end
        option_dct["step"] = step
        option_dct.pop("begin")
        option_dct.pop("size")
        return option_dct

    def _fill_fix(self, builtin_options, option_dct):
        v = self._get_const_val(builtin_options.value)
        option_dct["value"] = v.item()
        return option_dct

    def _cast_fix(self, builtin_options, option_dct):
        option_dct.pop("in_data_type")
        out_data_type = option_dct.pop("out_data_type")
        if out_data_type.lower() == "none":
            out_data_type = self.sg.tensors[builtin_options.output].type
        option_dct["data_type"] = out_data_type
        return option_dct

    def _unpack_fix(self, builtin_options, option_dct):
        option_dct["split_index"] = -1
        return option_dct

    def _resize_bilinear_fix(self, builtin_options, option_dct):
        if (
            builtin_options.axes is not None
            or builtin_options.scales is not None
            or builtin_options.roi is not None
            or builtin_options.keep_aspect_ratio_policy != "stretch"
        ):
            raise NotImplementedError(builtin_options)

        option_dct["sizes"] = tuple(self._get_const_val(builtin_options.sizes))
        option_dct.pop("align_corners")
        option_dct.pop("half_pixel_centers")
        option_dct["resize_type"] = option_dct["resize_mode"]
        return option_dct

    def _resize_nearest_neighbor_fix(self, builtin_options, option_dct):
        if (
            builtin_options.axes is not None
            or builtin_options.scales is not None
            or builtin_options.roi is not None
            or builtin_options.keep_aspect_ratio_policy != "stretch"
        ):
            raise NotImplementedError(builtin_options)
        option_dct["sizes"] = tuple(self._get_const_val(builtin_options.sizes))
        option_dct.pop("align_corners")
        option_dct.pop("half_pixel_centers")
        option_dct["resize_type"] = option_dct["resize_mode"]
        return option_dct

    def _topk_v2_fix(self, builtin_options, option_dct):
        option_dct["inputs"] = (option_dct["inputs"][0],)
        option_dct["constant"] = int(self._get_const_val(builtin_options.input1))
        option_dct["axis"] = -1
        return option_dct

    def _split_fix(self, builtin_options, option_dct):
        axis = int(self._get_const_val(builtin_options.axis))
        split = tuple(
            self.sg.tensors[oidx].shape[axis] for oidx in builtin_options.output
        )
        option_dct["axis"] = axis
        option_dct["split"] = split
        option_dct["num_outputs"] = option_dct.pop("num_splits")
        return option_dct

    def _splitv_fix(self, builtin_options, option_dct):
        axis = int(self._get_const_val(builtin_options.axis))
        input_shape = self.sg.tensors[builtin_options.input].shape
        if not (-len(input_shape) <= axis < len(input_shape)):
            raise ValueError("axis not in range [-rank(value), rank(value)).")
        if axis < 0:
            axis += len(input_shape)
        _split = self._get_const_val(builtin_options.size_splits)
        _split_oshape = tuple(
            self.sg.tensors[oidx].shape[axis] for oidx in builtin_options.output
        )
        split = []
        for os, s in zip(_split_oshape, _split):
            if os == s:
                split.append(s)
            elif s == -1:
                split.append(os)
            else:
                raise ValueError(f"split_size: {_split}")

        if sum(split) != input_shape[axis]:
            raise Exception(
                f"split dimension mismatch! sum({split})!= " f"{input_shape[axis]}"
            )
        option_dct["axis"] = axis
        option_dct["split"] = split
        option_dct["num_outputs"] = option_dct.pop("num_splits")
        option_dct.pop("size_splits")
        return option_dct

    def _leaky_alpha_fix(self, builtin_options, option_dct):
        option_dct["leaky_alpha"] = option_dct.pop("alpha")
        return option_dct

    def _transpose_fix(self, builtin_options, option_dct):
        option_dct["transpose_axes"] = tuple(
            self._get_const_val(builtin_options.transpose_axes)
        )
        return option_dct

    def _space_to_batch_nd_fix(self, builtin_options, option_dct):
        option_dct["inputs"] = (option_dct["inputs"][0],)
        option_dct["block_shape"] = builtin_options.input[1]
        option_dct["paddings"] = builtin_options.input[2]
        return option_dct

    def _batch_to_space_nd_fix(self, builtin_options, option_dct):
        option_dct["inputs"] = (option_dct["inputs"][0],)
        option_dct["block_shape"] = builtin_options.input[1]
        option_dct["crops"] = builtin_options.input[2]
        return option_dct

    def _relu6_fix(self, builtin_options, option_dct):
        option_dct["clip_max_value"] = 6
        option_dct["clip_min_value"] = 0
        return option_dct

    def _get_compat_opt_dct(self, op: Operator):
        _fix = {
            "CONV_2D": self._conv2d_fix,
            "DEPTHWISE_CONV_2D": self._depthwise_conv2d_fix,
            "TRANSPOSE_CONV": self._transpose_conv_fix,
            "AVERAGE_POOL_2D": self._avgpool2d_fix,
            "MAX_POOL_2D": self._maxpool2d_fix,
            "FULLY_CONNECTED": self._fully_connected_fix,
            "MEAN": self._reduce_fix,
            "REDUCE_PROD": self._reduce_fix,
            "SUM": self._reduce_fix,
            "SHAPE": self._shape_fix,
            "RESHAPE": self._reshape_fix,
            "PAD": self._pad_fix,
            "PADV2": self._pad_fix,
            "STRIDED_SLICE": self._strided_slice_fix,
            "SLICE": self._slice_fix,
            "FILL": self._fill_fix,
            "CAST": self._cast_fix,
            "UNPACK": self._unpack_fix,
            "RESIZE_BILINEAR": self._resize_bilinear_fix,
            "RESIZE_NEAREST_NEIGHBOR": self._resize_nearest_neighbor_fix,
            "TOPK_V2": self._topk_v2_fix,
            "SPLIT": self._split_fix,
            "SPLIT_V": self._splitv_fix,
            "LEAKY_RELU": self._leaky_alpha_fix,
            "TRANSPOSE": self._transpose_fix,
            "SPACE_TO_BATCH_ND": self._space_to_batch_nd_fix,
            "BATCH_TO_SPACE_ND": self._batch_to_space_nd_fix,
            "RELU6": self._relu6_fix,
        }
        if op.opname in _fix:
            return _fix[op.opname](
                op.builtin_options, self._get_default_options_dct(op)
            )
        return self._get_default_options_dct(op)

    def _to_compatible_options_dct(self, op: Operator) -> Dict:
        dct = self._get_compat_opt_dct(op)
        if "trace" in dct:
            dct.pop("trace")
        return dct

    def _get_mob_op(self, op: Operator, option_dict):
        if op.opname == "CONV_2D" and option_dict["group_number"] > 1:
            option_cls = mob_options.Registry.getcls("GroupConvolution")
        if op.opname == "RESHAPE" and len(option_dict["inputs"]) > 1:
            option_cls = mob_options.Registry.getcls("ReshapeV2")
        else:
            option_cls = mob_options.Registry.getcls(
                _tflite_opname_to_mobilnt_option_name[op.opname]
            )
        onames = [self.sg.tensor(i).name for i in op.builtin_options.iter_outputs()]
        oact = self._mob_acts[self._actname_to_actidx[onames[0]]]
        fused_act_func = option_dict.pop("fused_activation_function", "None")
        return mob_Operator(
            name=oact.name,
            options=option_cls(**option_dict),
            fused_activation_function=fused_act_func,
        )

    def _get_mob_ops_tensors(self):
        mob_ops = []
        tensor_names = {}
        mob_tensors = []
        outputs_cache = []
        sg_output_acts = self.outputs
        for op in self.sg.operators:
            if op.opname not in _tflite_opname_to_mobilnt_option_name:
                raise NotImplementedError(op.opname)
            opt_dct = self._to_compatible_options_dct(op)
            for k, v in opt_dct.items():
                if isinstance(v, TensorIndex):
                    if v == -1:
                        opt_dct[k] = v
                        continue
                    ts = self.sg.tensor(v)
                    if ts.buffer != -1:
                        if ts.name not in self.const_dict:
                            print(op, opt_dct)
                            raise Exception(k, ts.name)
                        if op.opname in ("CONV_2D", "TRANSPOSE_CONV") and k == "weight":
                            oc, h, w, ic = ts.shape
                            ts_shape = (oc, ic, h, w)
                        elif op.opname == "DEPTHWISE_CONV_2D" and k == "weight":
                            ic, h, w, oc = ts.shape
                            ts_shape = (oc, ic, h, w)
                        else:
                            ts_shape = ts.shape
                        if ts.name not in tensor_names:
                            mob_ts = schema_spec.TensorSpec(
                                name=ts.name, dtype=ts.type.lower(), shape=ts_shape
                            )
                            tensor_names[mob_ts.name] = len(mob_tensors)
                            mob_tensors.append(mob_ts)
                        opt_dct[k] = tensor_names[ts.name]
                    else:
                        opt_dct[k] = None
            mob_op = self._get_mob_op(op, opt_dct)
            for oidx in mob_op.options.outputs:
                if oidx in sg_output_acts:
                    outputs_cache.append((oidx, mob_op))
            mob_ops.append(mob_op)

        for oidx, op in outputs_cache:
            op_output = mob_Operator(
                self._mob_acts[oidx].name,
                options=mob_options.OutputOptions(inputs=(oidx,), outputs=(oidx,)),
            )
            mob_ops.append(op_output)

        return mob_ops, mob_tensors

    def to_mobilint(self):
        self._mob_acts = self._get_mob_activations()
        self._actname_to_actidx = {a.name: i for i, a in enumerate(self._mob_acts)}
        ops, tensors = self._get_mob_ops_tensors()
        self._mob_ops = ops
        self._mob_tensors = tensors

    @property
    def activations(self):
        return self._mob_acts

    @property
    def tensors(self):
        return self._mob_tensors

    @property
    def operators(self):
        return self._mob_ops

    @property
    def inputs(self):
        _inputs = []
        for inp in self.sg.inputs:
            _inputs.append(self._actname_to_actidx[self.sg.tensor(inp).name])
        return _inputs

    @property
    def outputs(self):
        _outputs = []
        for outp in self.sg.outputs:
            _outputs.append(self._actname_to_actidx[self.sg.tensor(outp).name])
        return _outputs


def tflite_subgraph_to_mobilint_subgraph(
    sg: Subgraph, sample_value_dict, const_dict
) -> qbcompiler.model_dict.common.subgraph.SubGraph:
    ptm = _SubGraphToMobilintSubGraph(
        sg, const_dict=const_dict, sample_value_dict=sample_value_dict
    )
    ptm.to_mobilint()
    return qbcompiler.model_dict.common.subgraph.SubGraph(
        name=sg.name,
        operators=ptm.operators,
        tensors=ptm.tensors,
        activations=ptm.activations,
        inputs=ptm.inputs,
        outputs=ptm.outputs,
    )
