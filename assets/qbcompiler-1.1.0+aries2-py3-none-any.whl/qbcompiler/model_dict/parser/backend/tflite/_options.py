import dataclasses
import enum
import functools
import importlib
import itertools
import operator
import struct
from collections import namedtuple
from typing import Tuple, Dict, List, Union, ClassVar, Optional

import flatbuffers.number_types as N
from ._flexbuffers import GetRoot as flexbuffers_GetRoot

import numpy

from ._tensor import TensorType, TensorIndex, TensorSpec

#
from ._assets.util import get_as_tuple
from ._assets.built_in_options.ActivationFunctionType import (
    ActivationFunctionType as tflite_ActivationFunctionType,
)
from ._assets.built_in_options.CustomOptionsFormat import (
    CustomOptionsFormat as tflite_CustomOptionsFormat,
)
from ._assets.built_in_options.BuiltinOptions import (
    BuiltinOptions as tflite_BuiltinOptions,
)
from ._assets.built_in_options.FullyConnectedOptionsWeightsFormat import (
    FullyConnectedOptionsWeightsFormat as tflite_FullyConnectedOptionsWeightsFormat,
)

#
from ._assets.built_in_options.Operator import Operator as tflite_Operator
from ._assets.built_in_options.Padding import Padding as tflite_Padding


class TO_BE_FILLED_I(int):
    def __new__(cls, *args, **kwargs):
        return super(TO_BE_FILLED_I, cls).__new__(cls, 9876543210)


def _inputs(op) -> Tuple[TensorIndex, ...]:
    return tuple(TensorIndex(x) for x in get_as_tuple(op, "Inputs"))


def _outputs(op) -> Tuple[TensorIndex, ...]:
    return tuple(TensorIndex(x) for x in get_as_tuple(op, "Outputs"))


def _to_numpy_dtype(_dtype: str):
    return numpy.dtype(_dtype.lower()).name


class FN_EXTEND:
    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        return _as_dict_wrapper(self, tensors)

    @property
    def option_type(self):
        return type(self).__name__

    def iter_fields(self: dataclasses.dataclass):
        """returns Generator[Tuple[str, TensorIndex]]"""
        yield from map(
            lambda x: (x.name, getattr(self, x.name)), dataclasses.fields(self)
        )

    def iter_tensor_index(self: dataclasses.dataclass):
        """returns Generator[Tuple[str, TensorIndex]]"""
        for field in dataclasses.fields(self):
            v = getattr(self, field.name)
            if isinstance(v, TensorIndex):
                yield field.name, v
            elif isinstance(v, (tuple, list)) and v and isinstance(v[0], TensorIndex):
                yield from zip(itertools.repeat(field.name), v)

    def iter_outputs(self):
        """Generator[TensorIndex]"""
        if hasattr(self, "output"):
            if isinstance(self.output, (tuple, list)):
                yield from self.output
            else:
                yield self.output
        else:
            raise AttributeError(
                f"No output defined({self.__class__.__name__}):{dataclasses.asdict(self)}"
            )

    def iter_inputs(self):
        """Generator[TensorIndex]"""
        if hasattr(self, "inputs"):
            yield from self.inputs
        elif hasattr(self, "input"):
            if isinstance(self.input, (tuple, list)):
                for item in self.input:
                    yield item
            else:
                yield self.input
        elif hasattr(self, "input0") and hasattr(self, "input1"):
            yield self.input0
            yield self.input1
        else:
            raise NotImplementedError


class CustomOptionsFormat:
    _mapping: Dict[int, str] = {}

    @staticmethod
    def name(built_in_code: int):
        if built_in_code not in CustomOptionsFormat._mapping:
            for k, v in tflite_CustomOptionsFormat.__dict__.items():
                if v == built_in_code:
                    CustomOptionsFormat._mapping[built_in_code] = k
                    return k
        return CustomOptionsFormat._mapping[built_in_code]


class BuiltinOptions:
    """
    container for tflite built-in option types.
    """

    _mapping: Dict[int, str] = {}
    _registry = {}

    @staticmethod
    def name(built_in_code: int):
        if built_in_code not in BuiltinOptions._mapping:
            for k, v in tflite_BuiltinOptions.__dict__.items():
                if v == built_in_code:
                    BuiltinOptions._mapping[built_in_code] = k
                    return k
        return BuiltinOptions._mapping[built_in_code]

    @staticmethod
    def type(option_name: str) -> int:
        if option_name not in BuiltinOptions._mapping:
            for k, v in tflite_BuiltinOptions.__dict__.items():
                if k == option_name:
                    BuiltinOptions._mapping[v] = option_name
                    return v
        return getattr(tflite_BuiltinOptions, option_name, None)

    @staticmethod
    def register(cls):
        option_code = getattr(tflite_BuiltinOptions, cls.__name__)
        BuiltinOptions._registry[option_code] = cls
        return cls

    @staticmethod
    def get_option_cls(option_type: int):
        return BuiltinOptions._registry[option_type]

    @staticmethod
    def is_option(option_type: int):
        return option_type in BuiltinOptions._registry


class ExtendedOptions:
    """
    container for tflite built-in option types.
    """

    _next_code = 1000
    _mapping: Dict[int, str] = {}
    _registry = {}

    @staticmethod
    def register(cls):
        ExtendedOptions._mapping[ExtendedOptions._next_code] = cls.__name__
        ExtendedOptions._registry[ExtendedOptions._next_code] = cls
        ExtendedOptions._next_code += 1
        return cls

    @staticmethod
    def name(extended_code: int) -> str:
        return ExtendedOptions._mapping[extended_code]

    @staticmethod
    def type(option_name: str) -> int:
        for k, v in ExtendedOptions._mapping.items():
            if v == option_name:
                return k
        raise NameError(f"Unknown option name: {option_name}")

    @staticmethod
    def get_option_cls(option_type: int):
        return ExtendedOptions._registry[option_type]

    @staticmethod
    def is_option(option_type: int):
        return option_type in ExtendedOptions._registry


def _get_key_from_rev(cls, value: int):
    for k, v in cls.__dict__.items():
        if value == v:
            return k
    raise ValueError("code should not be reached!")


def _trace_add(target, origin):
    if hasattr(origin, "trace"):
        for opt in origin.trace:
            target.trace.append(opt)
    target.trace.append(origin)


class FullyConnectedOptionsWeightsFormat:
    @staticmethod
    def name(built_in_code: int):
        return _get_key_from_rev(
            tflite_FullyConnectedOptionsWeightsFormat, built_in_code
        )


class ActFuncType:
    @staticmethod
    def name(built_in_code: int):
        return _get_key_from_rev(tflite_ActivationFunctionType, built_in_code)


class Padding:
    @staticmethod
    def name(built_in_code: int):
        return _get_key_from_rev(tflite_Padding, built_in_code)


def get_option_cls(option_type: int):
    if BuiltinOptions.is_option(option_type):
        return BuiltinOptions.get_option_cls(option_type)
    if ExtendedOptions.is_option(option_type):
        return ExtendedOptions.get_option_cls(option_type)
    if option_type < 1000:
        for k, v in tflite_BuiltinOptions.__dict__.items():
            if v == option_type:
                raise NotImplementedError(f"Unknown option type {option_type}, {k}")
    raise NotImplementedError(f"Unknown option type {option_type}")


def _off_size(op: tflite_Operator):
    # from Operator.py and flatbuffers.Table.py
    o = N.UOffsetTFlags.py_type(op._tab.Offset(12))
    if o == 0:
        raise NotImplementedError("off set is zero.")
    N.enforce_number(o, N.UOffsetTFlags)
    return op._tab.Get(N.UOffsetTFlags, op._tab.Pos + o)


def _get_opt(op: tflite_Operator, option_type):
    ot = op.BuiltinOptions()
    if ot is not None:
        cls = getattr(
            importlib.import_module(
                f"qbcompiler.model_dict.parser.backend.tflite._assets.built_in_options.{option_type}"
            ),
            option_type,
        )
        return cls.GetRootAs(ot.Bytes, ot.Pos - _off_size(op))
    return None


def _as_dict_wrapper(obj, tensors: List[TensorSpec]):
    dct = dataclasses.asdict(obj)
    for k, v in dct.items():
        if isinstance(v, TensorIndex):
            if v != -1:
                dct[k] = tensors[v].name
            else:
                dct[k] = None
        if isinstance(v, (list, tuple)):
            lst = []
            for item in v:
                if isinstance(item, TensorIndex):
                    if item != -1:
                        item = tensors[item].name
                    else:
                        item = None
                lst.append(item)
            dct[k] = lst

    if hasattr(obj, "input"):
        if isinstance(obj.input, (tuple, list)):
            lst = []
            for x in obj.input:
                _, shape_ = resolve_input_shape(tensors[x])
                lst.append(tuple(shape_))

        else:
            _, input_shape = resolve_input_shape(tensors[obj.input])
            lst = [tuple(input_shape)]
        dct["input_shape"] = lst
    elif hasattr(obj, "input0") and hasattr(obj, "input1"):
        _, input_shape0 = resolve_input_shape(tensors[obj.input0])
        _, input_shape1 = resolve_input_shape(tensors[obj.input1])
        dct["input_shape"] = [tuple(input_shape0), tuple(input_shape1)]

    if hasattr(obj, "output"):
        if isinstance(obj.output, (tuple, list)):
            lst = []
            src_ = []
            for x in obj.output:
                _, shape_ = _resolve_output_shape(tensors[x])
                lst.append(tuple(shape_))
                src_.append(resolve_src_shape(tensors[x]))

        else:
            _, output_shape = _resolve_output_shape(tensors[obj.output])
            src_ = resolve_src_shape(tensors[obj.output])
            lst = [tuple(output_shape)]
        dct["output_shape"] = lst
        dct["src_shape"] = src_

    return dct


def get_default_option(op: tflite_Operator, option_type):
    fields = tuple(field.name for field in dataclasses.fields(option_type))
    #     fixme: this implementation is an inappropriate way to simplify things.
    try:
        return option_type.get(op)
    except Exception as e:
        inputs = _inputs(op)
        outputs = _outputs(op)
        try:
            if "input0" in fields and "input1" in fields and "output" in fields:
                return option_type(
                    input0=inputs[0], input1=inputs[1], output=outputs[0]
                )
            if "input" in fields and "output" in fields:
                return option_type(input=inputs[0], output=outputs[0])
            return option_type(inputs=inputs, outputs=outputs)
        except Exception as e:
            raise e


class CustomOptionField:
    class T(enum.Enum):
        float = 0
        bool = 1
        str = 2
        dtype = 3

    def __init__(self, name, type: "CustomOptionField.T"):
        self.name = name
        self.type = type


def _read_custom_options(bytes, fields: List[CustomOptionField]) -> Dict:
    def _read_field_name(field_name: str, start_idx):
        offset = 0
        if bytes[start_idx + offset] != len(field_name):
            return 0
        offset += 1
        if (
            bytes[start_idx + offset : start_idx + offset + len(field_name)]
            != field_name.encode()
        ):
            return 0
        return offset + len(field_name)

    def _read_float_vector2(start_idx):
        vector_float2 = 0x12
        offset = 0
        if bytes[start_idx + offset] != vector_float2:
            return 0, 0
        offset += 1
        vec_len = bytes[start_idx + offset]
        offset += 1
        return offset, vec_len

    def read_float(field: str, idx):
        # \x07epsilon\x12\x05%o\x12\x05%
        offset = _read_field_name(field, idx)
        if offset == 0:
            return None
        idx += offset

        offset, vec_len = _read_float_vector2(idx)
        if offset == 0:
            return None
        idx += offset

        if bytes[idx] != ord("%"):
            return None
        idx += 1

        num_bytes = vec_len - 1
        if num_bytes % 4 != 0:
            return None
        return struct.unpack("f", bytes[idx : idx + num_bytes])[0]

    def read_boolean(field: str, idx):
        # \x0bis_training\x12\x02(\x00*
        offset = _read_field_name(field, idx)
        if offset == 0:
            return None
        idx += offset

        offset, vec_len = _read_float_vector2(idx)
        if offset == 0:
            return None
        idx += offset

        if bytes[idx] != ord("("):
            return None
        idx += 1

        num_bytes = vec_len - 1
        if num_bytes != 1:
            return None
        return struct.unpack("b", bytes[idx : idx + num_bytes])[0]

    def read_str(field: str, idx):
        # \x0bdata_format\x12\x06\x12\x04NHWC
        offset = _read_field_name(field, idx)
        if offset == 0:
            return None
        idx += offset

        offset, vec_len = _read_float_vector2(idx)
        if offset == 0:
            return None
        idx += offset

        offset, vec_len = _read_float_vector2(idx)
        if offset == 0:
            return None
        idx += offset

        return bytes[idx : idx + vec_len].decode()

    def read_T(field: str, idx):
        #     \x01T\x12\x020\x01
        offset = _read_field_name(field, idx)
        if offset == 0:
            return None
        idx += offset

        offset, vec_len = _read_float_vector2(idx)
        if offset == 0:
            return None
        idx += offset

        data = bytes[idx : idx + vec_len]
        if tuple(data) == (ord("0"), 0x01):
            return "float32"
        else:
            return None

    dct = {}
    targets = sorted(fields, reverse=True, key=lambda x: x.name)
    for idx in range(len(bytes)):
        for field in targets:
            key, dtype = field.name, field.type
            if field.type == CustomOptionField.T.float:
                parsed = read_float(key, idx)
            elif field.type == CustomOptionField.T.bool:
                parsed = read_boolean(key, idx)
            elif field.type == CustomOptionField.T.str:
                parsed = read_str(key, idx)
            elif field.type == CustomOptionField.T.dtype:
                parsed = read_T(key, idx)
            else:
                raise NotImplementedError
            if parsed is not None:
                dct[key] = parsed
                targets.remove(field)
        if not targets:
            break
    return dct


def parse_custom_options(op: tflite_Operator):
    option_format = CustomOptionsFormat.name(op.CustomOptionsFormat())
    if option_format != "FLEXBUFFERS":
        raise NotImplementedError(f"{option_format}")

    arr = op.CustomOptionsAsNumpy().tobytes()
    obj = flexbuffers_GetRoot(arr)
    is_vector = obj.IsVector
    if is_vector:
        # we fails to get obj.AsVector[1].Value
        opname = obj.AsVector[0].Value
        option_type = ExtendedOptions.type(opname + "Options")
        option_cls = get_option_cls(option_type)
        parsed_ = _read_custom_options(
            arr[len(opname) :], option_cls.custom_options_fields
        )
        return opname, FusedBatchNormV3Options.get(op, parsed_)
    return None, None


@dataclasses.dataclass
class _PadValue:
    north_padding: int = 0
    south_padding: int = 0
    east_padding: int = 0
    west_padding: int = 0


def _resolve_conv_padding(
    padding: str,
    input_h,
    input_w,
    kernel_h,
    kernel_w,
    stride_h,
    stride_w,
    dilation_h,
    dilation_w,
    padding_list=None,
) -> _PadValue:
    if padding == "None":
        return _PadValue(0, 0, 0, 0)

    if padding == "VALID":
        dilated_ker_h = (kernel_h - 1) * dilation_h + 1
        dilated_ker_w = (kernel_w - 1) * dilation_w + 1
        p_w, p_e, p_s, p_n = 0, 0, 0, 0
        residual_h = (input_h + p_n + p_s - dilated_ker_h) % stride_h
        residual_w = (input_w + p_w + p_e - dilated_ker_w) % stride_w
        p_s = max(p_s - residual_h, 0)
        p_e = max(p_e - residual_w, 0)
        return _PadValue(p_n, p_s, p_e, p_w)

    if padding == "SAME":
        output_h = numpy.ceil(float(input_h) / float(stride_h))
        output_w = numpy.ceil(float(input_w) / float(stride_w))
        pad_height = max((output_h - 1) * stride_h + kernel_h - input_h, 0)
        pad_width = max((output_w - 1) * stride_w + kernel_w - input_w, 0)
        p_n = int(pad_height // 2)
        p_s = int(pad_height - p_n)
        p_w = int(pad_width // 2)
        p_e = int(pad_width - p_w)
        return _PadValue(p_n, p_s, p_e, p_w)

    if padding == "EXPLICIT":
        if padding_list is None or not padding_list:
            raise Exception("padding_list is None or  padding_list is empty")
        return _PadValue(*padding_list)

    raise NotImplementedError(f"padding={padding}")


_HWC = namedtuple("_HWC", "h w c")
_WEIGHT_SHAPE = namedtuple("_WEIGHT_SHAPE", "out_ch in_ch height width")


def resolve_input_shape(
    input_tensor: Union[TensorSpec, List, Tuple], data_format="NHWC"
) -> Tuple[int, Tuple[int, ...]]:
    # fixme: it doesnt seem to generalize.
    #  maybe we need to implement input shape for each layer type.
    if data_format != "NHWC":
        raise NotImplementedError('data_format != "NHWC"')

    if len(input_tensor.shape) == 4:
        n, input_h, input_w, input_ch = input_tensor.shape
        return n, (input_h, input_w, input_ch)
    if len(input_tensor.shape) == 3:
        h, w, c = input_tensor.shape
        return 1, (h, w, c)

    if len(input_tensor.shape) == 2:
        if input_tensor.shape[0] == 1:
            # e.g, relu input after fully connected
            return 1, (1, 1, input_tensor.shape[1])
        else:
            #  when input shape to fc is (3136, 128)
            return 1, input_tensor.shape

    if len(input_tensor.shape) == 1:
        return 0, (input_tensor.shape[0],)

    if len(input_tensor.shape) == 0:
        return 0, tuple()

    if len(input_tensor.shape) == 5:
        _, dim0, dim1, dim2, dim3 = input_tensor.shape
        return 1, (dim0, dim1, dim2, dim3)

    raise NotImplementedError(f"input_tensor={input_tensor.shape}")


def _resolve_output_shape(
    output_tensor: Union[TensorSpec, List, Tuple], data_format="NHWC"
) -> Tuple[int, Tuple[int, ...]]:
    # fixme: it doesnt seem to generalize.
    #  maybe we need to implement input shape for each layer type.
    if data_format != "NHWC":
        raise NotImplementedError('data_format != "NHWC"')

    if len(output_tensor.shape) == 4:
        n, h, w, c = output_tensor.shape
        return n, (h, w, c)
    if len(output_tensor.shape) == 3:
        n = 1
        h, w, c = output_tensor.shape
        return n, (h, w, c)
    if len(output_tensor.shape) == 2:
        if output_tensor.shape[0] == 1:
            # e.g, reshape
            return 1, (1, 1, output_tensor.shape[1])
        else:
            # reshape input is (56,56,128) and output is (3136,128)
            # fc input is (3136, 128), weight is (512,1288) and output is expected to be (3136, 512)
            return 1, output_tensor.shape
    if len(output_tensor.shape) == 1:
        return 1, (1, 1, output_tensor.shape[0])

    if len(output_tensor.shape) == 0:
        return 0, tuple()

    if len(output_tensor.shape) == 5:
        _, dim0, dim1, dim2, dim3 = output_tensor.shape
        return 1, (dim0, dim1, dim2, dim3)

    raise NotImplementedError(f"output_tensor={output_tensor.shape}")


def resolve_src_shape(input_tensor: TensorSpec, data_format="NHWC") -> Tuple[int, ...]:
    if data_format != "NHWC":
        raise NotImplementedError('data_format != "NHWC"')
    return tuple(input_tensor.shape)


def _conv_output_size(
    input_shape: _HWC,
    kernel_h,
    kernel_w,
    dilation_h,
    dilation_w,
    stride_h,
    stride_w,
    pad: _PadValue,
    out_ch,
) -> _HWC:
    dilated_ker_h = (kernel_h - 1) * dilation_h + 1
    dilated_ker_w = (kernel_w - 1) * dilation_w + 1
    output_h = (
        input_shape.h + pad.north_padding + pad.south_padding - dilated_ker_h
    ) // stride_h + 1
    output_w = (
        input_shape.w + pad.east_padding + pad.west_padding - dilated_ker_w
    ) // stride_w + 1
    return _HWC(output_h, output_w, out_ch)


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class Conv2DOptions(FN_EXTEND):
    input: TensorIndex
    weight: TensorIndex
    bias: TensorIndex
    output: TensorIndex
    padding: str
    w_stride: int
    h_stride: int
    fused_activation_function: str
    w_dilation: int
    h_dilation: int
    # if this field is not empty, this conv is generated from other option type. e.g., gemm
    trace: List = dataclasses.field(default_factory=list)

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "Conv2DOptions")
        inputs = _inputs(op)
        outputs = _outputs(op)

        return Conv2DOptions(
            input=inputs[0],
            weight=inputs[1],
            bias=inputs[2],
            output=outputs[0],
            padding=Padding.name(opt.Padding()),
            w_stride=opt.StrideW(),
            h_stride=opt.StrideH(),
            fused_activation_function=ActFuncType.name(opt.FusedActivationFunction()),
            w_dilation=opt.DilationWFactor(),
            h_dilation=opt.DilationHFactor(),
        )

    def _weight_shape(
        self, weight_tensor: TensorSpec, data_format="NHWC"
    ) -> _WEIGHT_SHAPE:
        if data_format != "NHWC":
            raise NotImplementedError('data_format != "NHWC"')
        if len(weight_tensor.shape) == 4:
            oc, h, w, ic = weight_tensor.shape
            return _WEIGHT_SHAPE(out_ch=oc, in_ch=ic, height=h, width=w)

    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        dct = _as_dict_wrapper(self, tensors)

        data_format = "NHWC"

        N, input_shape = resolve_input_shape(tensors[self.input], data_format)
        input_shape = _HWC(*input_shape)
        weight_shape = self._weight_shape(tensors[self.weight], data_format)
        pad = _resolve_conv_padding(
            padding=dct["padding"],
            input_h=input_shape.h,
            input_w=input_shape.w,
            kernel_h=weight_shape.height,
            kernel_w=weight_shape.width,
            stride_h=dct["h_stride"],
            stride_w=dct["w_stride"],
            dilation_h=dct["h_dilation"],
            dilation_w=dct["w_dilation"],
        )
        output_shape = _conv_output_size(
            input_shape,
            kernel_h=weight_shape.height,
            kernel_w=weight_shape.width,
            dilation_h=dct["h_dilation"],
            dilation_w=dct["w_dilation"],
            stride_h=dct["h_stride"],
            stride_w=dct["w_stride"],
            pad=pad,
            out_ch=weight_shape.out_ch,
        )

        dct["pad_size"] = pad
        dct["data_format"] = data_format
        dct["h_kernel"] = weight_shape.height
        dct["w_kernel"] = weight_shape.width
        dct["input_shape"] = [tuple(input_shape)]
        dct["output_shape"] = tuple(output_shape)
        dct["in_channels"] = input_shape.c
        dct["out_channels"] = output_shape.c
        return dct


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class TransposeConvOptions(FN_EXTEND):
    output_size: TensorIndex  # to prevent `output_shape` key collision.
    weight: TensorIndex
    input: TensorIndex
    bias: Optional[TensorIndex]
    output: TensorIndex

    padding: str
    w_stride: int
    h_stride: int
    fused_activation_function: str
    quantized_bias_type: str

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "TransposeConvOptions")
        inputs = _inputs(op)
        outputs = _outputs(op)

        if len(inputs) == 4:
            output_shape, weight, input_, bias = inputs
        else:
            output_shape, weight, input_ = inputs
            bias = None

        return TransposeConvOptions(
            output_size=output_shape,
            weight=weight,
            input=input_,
            bias=bias,
            output=outputs[0],
            padding=Padding.name(opt.Padding()),
            w_stride=opt.StrideW(),
            h_stride=opt.StrideH(),
            fused_activation_function=ActFuncType.name(opt.FusedActivationFunction()),
            quantized_bias_type=opt.QuantizedBiasType(),
        )

    def _weight_shape(
        self, weight_tensor: TensorSpec, data_format="NHWC"
    ) -> _WEIGHT_SHAPE:
        if data_format != "NHWC":
            raise NotImplementedError('data_format != "NHWC"')
        if len(weight_tensor.shape) == 4:
            oc, h, w, ic = weight_tensor.shape
            return _WEIGHT_SHAPE(out_ch=oc, in_ch=ic, height=h, width=w)

    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        dct = _as_dict_wrapper(self, tensors)

        data_format = "NHWC"
        weight_shape = self._weight_shape(tensors[self.weight], data_format)

        dct["output_shape"] = dct["output_shape"][0]
        dct["data_format"] = data_format
        dct["w_dilation"] = 1
        dct["h_dilation"] = 1
        dct["group_number"] = None
        dct["w_kernel"] = weight_shape.width
        dct["h_kernel"] = weight_shape.height

        return dct


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class Pool2DOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex
    padding: str
    w_stride: int
    h_stride: int
    w_kernel: int
    h_kernel: int
    fused_activation_function: str
    w_dilation: int = 1
    h_dilation: int = 1
    padding_list: Optional[List] = None
    data_format: str = "NHWC"
    is_ceil_mode: int = 0

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "Pool2DOptions")
        inputs = _inputs(op)
        outputs = _outputs(op)

        return Pool2DOptions(
            input=inputs[0],
            output=outputs[0],
            padding=Padding.name(opt.Padding()),
            w_stride=opt.StrideW(),
            h_stride=opt.StrideH(),
            w_kernel=opt.FilterWidth(),
            h_kernel=opt.FilterHeight(),
            fused_activation_function=ActFuncType.name(opt.FusedActivationFunction()),
        )

    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        # there is no way to infer pool_type from pool_options.
        dct = _as_dict_wrapper(self, tensors)
        data_format = "NHWC"

        _, input_shape = resolve_input_shape(tensors[self.input], data_format)
        input_shape = _HWC(*input_shape)
        pad = _resolve_conv_padding(
            padding=dct["padding"],
            input_h=input_shape.h,
            input_w=input_shape.w,
            kernel_h=dct["h_kernel"],
            kernel_w=dct["w_kernel"],
            stride_h=dct["h_stride"],
            stride_w=dct["w_stride"],
            dilation_h=dct["h_dilation"],
            dilation_w=dct["w_dilation"],
        )
        output_shape = _conv_output_size(
            input_shape,
            kernel_h=dct["h_kernel"],
            kernel_w=dct["w_kernel"],
            dilation_h=dct["h_dilation"],
            dilation_w=dct["w_dilation"],
            stride_h=dct["h_stride"],
            stride_w=dct["w_stride"],
            pad=pad,
            out_ch=input_shape.c,
        )
        # dct.update(dataclasses.asdict(pad))
        dct["pad_size"] = pad
        dct["data_format"] = data_format
        dct["input_shape"] = [tuple(input_shape)]
        dct["output_shape"] = tuple(output_shape)

        if kwargs["opname"] == "AVERAGE_POOL_2D":
            dct["count_include_pad"] = False

        return dct


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class FullyConnectedOptions(FN_EXTEND):
    fused_activation_function: str
    weights_format: str
    keep_num_dims: bool
    asymmetric_quantize_inputs: bool
    quantized_bias_type: str
    input: TensorIndex
    weight: TensorIndex
    bias: TensorIndex
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "FullyConnectedOptions")
        inputs = _inputs(op)

        return FullyConnectedOptions(
            input=inputs[0],
            weight=inputs[1],
            bias=inputs[2],
            output=_outputs(op)[0],
            fused_activation_function=ActFuncType.name(opt.FusedActivationFunction()),
            weights_format=FullyConnectedOptionsWeightsFormat.name(opt.WeightsFormat()),
            keep_num_dims=opt.KeepNumDims(),
            asymmetric_quantize_inputs=opt.AsymmetricQuantizeInputs(),
            quantized_bias_type=opt.QuantizedBiasType(),
        )


@ExtendedOptions.register
@dataclasses.dataclass(frozen=True)
class GemmConstantOptions(FN_EXTEND):
    input: TensorIndex
    weight: TensorIndex
    bias: TensorIndex
    output: TensorIndex
    fused_activation_function: str
    weights_format: str
    keep_num_dims: bool
    asymmetric_quantize_inputs: bool
    quantized_bias_type: str
    alpha: float = 1.0
    beta: float = 1.0
    transA: bool = False
    transB: bool = False
    trace: List = dataclasses.field(default_factory=list)


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class StridedSliceOptions(FN_EXTEND):
    input: TensorIndex
    begin: TensorIndex
    end: TensorIndex
    stride: TensorIndex
    output: TensorIndex
    begin_mask: int
    end_mask: int
    ellipsis_mask: int
    new_axis_mask: int
    shrink_axis_mask: int
    offset: bool  # if true, then the end tensor is an offset of the begin tensor.

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "StridedSliceOptions")
        inputs = _inputs(op)
        outputs = _outputs(op)
        return StridedSliceOptions(
            input=inputs[0],
            begin=inputs[1],
            end=inputs[2],
            stride=inputs[3],
            output=outputs[0],
            begin_mask=opt.BeginMask(),
            end_mask=opt.EndMask(),
            ellipsis_mask=opt.EllipsisMask(),
            new_axis_mask=opt.NewAxisMask(),
            shrink_axis_mask=opt.ShrinkAxisMask(),
            offset=opt.Offset(),
        )

    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        dct = _as_dict_wrapper(self, tensors)
        input_tensor = tensors[self.input]
        output_tensor = tensors[self.output]
        dct["input_shape"] = input_tensor.shape
        dct["output_shape"] = output_tensor.shape
        return dct


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class SubOptions(FN_EXTEND):
    fused_activation_function: str
    pot_scale_int16: bool
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "SubOptions")
        inputs = _inputs(op)
        outputs = _outputs(op)
        return SubOptions(
            input0=inputs[0],
            input1=inputs[1],
            output=outputs[0],
            fused_activation_function=ActFuncType.name(opt.FusedActivationFunction()),
            pot_scale_int16=opt.PotScaleInt16(),
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class MulOptions(FN_EXTEND):
    fused_activation_function: str
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "MulOptions")
        inputs = _inputs(op)
        outputs = _outputs(op)
        return MulOptions(
            input0=inputs[0],
            input1=inputs[1],
            output=outputs[0],
            fused_activation_function=ActFuncType.name(opt.FusedActivationFunction()),
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class ResizeBilinearOptions(FN_EXTEND):
    input: TensorIndex
    sizes: TensorIndex
    output: TensorIndex
    align_corners: bool
    half_pixel_centers: bool

    resize_mode: str
    nearest_mode: str
    transform_mode: str

    roi: str = None
    scales: str = None
    cubic_coeff_a: float = 0.75
    exclude_outside: int = 0
    extrapolation_value: float = 0.0
    antialias: int = 0
    axes: int = None
    keep_aspect_ratio_policy: str = "stretch"

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "ResizeBilinearOptions")
        inputs = _inputs(op)

        align_corners = opt.AlignCorners()
        half_pixel_centers = opt.HalfPixelCenters()

        resize_mode = "linear"
        if not align_corners and not half_pixel_centers:
            transform_mode = "asymmetric"
            nearest_mode = "floor"
        elif align_corners and not half_pixel_centers:
            transform_mode = "align_corners"
            nearest_mode = "round_prefer_ceil"
        elif not align_corners and half_pixel_centers:
            transform_mode = "half_pixel"
            nearest_mode = "floor"
        else:
            transform_mode = "half_pixel"
            nearest_mode = "round_prefer_ceil"

        return ResizeBilinearOptions(
            input=inputs[0],
            sizes=inputs[1],
            output=_outputs(op)[0],
            align_corners=align_corners,
            half_pixel_centers=half_pixel_centers,
            resize_mode=resize_mode,
            nearest_mode=nearest_mode,
            transform_mode=transform_mode,
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class DepthwiseConv2DOptions(FN_EXTEND):
    input: TensorIndex
    weight: TensorIndex
    bias: TensorIndex
    output: TensorIndex
    padding: str
    w_stride: int
    h_stride: int
    depth_multiplier: int
    fused_activation_function: str
    w_dilation: int
    h_dilation: int
    padding_list: List[int] = dataclasses.field(default_factory=list)
    trace: List = dataclasses.field(default_factory=list)

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "DepthwiseConv2DOptions")
        inputs = _inputs(op)
        optputs = _outputs(op)
        return DepthwiseConv2DOptions(
            input=inputs[0],
            weight=inputs[1],
            bias=inputs[2],
            output=optputs[0],
            padding=Padding.name(opt.Padding()),
            w_stride=opt.StrideW(),
            h_stride=opt.StrideH(),
            depth_multiplier=opt.DepthMultiplier(),
            fused_activation_function=ActFuncType.name(opt.FusedActivationFunction()),
            w_dilation=opt.DilationWFactor(),
            h_dilation=opt.DilationHFactor(),
        )

    def _weight_shape(
        self, weight_tensor: TensorSpec, data_format="NHWC"
    ) -> _WEIGHT_SHAPE:
        if data_format != "NHWC":
            raise NotImplementedError('data_format != "NHWC"')
        if len(weight_tensor.shape) == 4:
            oc, h, w, ic = weight_tensor.shape
            return _WEIGHT_SHAPE(out_ch=oc, in_ch=ic, height=h, width=w)

    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        dct = _as_dict_wrapper(self, tensors)

        data_format = "NHWC"

        _, input_shape = resolve_input_shape(tensors[self.input], data_format)
        input_shape = _HWC(*input_shape)
        weight_shape = self._weight_shape(tensors[self.weight], data_format)
        pad = _resolve_conv_padding(
            padding=dct["padding"],
            input_h=input_shape.h,
            input_w=input_shape.w,
            kernel_h=weight_shape.height,
            kernel_w=weight_shape.width,
            stride_h=dct["h_stride"],
            stride_w=dct["w_stride"],
            dilation_h=dct["h_dilation"],
            dilation_w=dct["w_dilation"],
            padding_list=dct["padding_list"],
        )
        output_shape = _conv_output_size(
            input_shape,
            kernel_h=weight_shape.height,
            kernel_w=weight_shape.width,
            dilation_h=dct["h_dilation"],
            dilation_w=dct["w_dilation"],
            stride_h=dct["h_stride"],
            stride_w=dct["w_stride"],
            pad=pad,
            out_ch=weight_shape.out_ch,
        )
        dct["pad_size"] = pad
        dct["data_format"] = data_format
        dct["h_kernel"] = weight_shape.height
        dct["w_kernel"] = weight_shape.width
        dct["input_shape"] = [tuple(input_shape)]
        dct["output_shape"] = tuple(output_shape)
        dct["in_channels"] = input_shape.c
        dct["out_channels"] = output_shape.c
        # dct["group_number"] = input_shape.c
        # if dct["group_number"] > 1:
        #     dct["type"] = "GroupConvolution"

        return dct


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class AddOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex
    fused_activation_function: str
    pot_scale_int16: bool

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "AddOptions")
        inputs = _inputs(op)
        outputs = _outputs(op)
        return AddOptions(
            input0=inputs[0],
            input1=inputs[1],
            output=outputs[0],
            fused_activation_function=ActFuncType.name(opt.FusedActivationFunction()),
            pot_scale_int16=opt.PotScaleInt16(),
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class ConcatenationOptions(FN_EXTEND):
    original_axis: int
    fused_activation_function: str
    input: Union[TensorIndex, Tuple[TensorIndex, ...]]
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "ConcatenationOptions")
        return ConcatenationOptions(
            input=_inputs(op),
            output=_outputs(op)[0],
            original_axis=opt.Axis(),
            fused_activation_function=ActFuncType.name(opt.FusedActivationFunction()),
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class ArgMaxOptions(FN_EXTEND):
    input: TensorIndex
    dimension: TensorIndex
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "ArgMaxOptions")
        inputs = _inputs(op)
        return ArgMaxOptions(
            input=inputs[0], dimension=inputs[1], output=_outputs(op)[0]
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class ReducerOptions(FN_EXTEND):
    keep_dims: bool
    input: TensorIndex
    reduce_axes: TensorIndex
    output: TensorIndex
    noop_with_empty_axes: int = 0

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "ReducerOptions")
        inputs = _inputs(op)
        outputs = _outputs(op)
        return ReducerOptions(
            input=inputs[0],
            reduce_axes=inputs[1],
            output=outputs[0],
            keep_dims=opt.KeepDims(),
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class UnpackOptions(FN_EXTEND):
    input: TensorIndex
    num: int
    axis: int
    output: Tuple[TensorIndex, ...]

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "UnpackOptions")
        return UnpackOptions(
            input=_inputs(op)[0],
            num=opt.Num(),
            axis=opt.Axis(),
            output=_outputs(op),
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class ExpOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class PackOptions(FN_EXTEND):
    values_count: int
    axis: int
    input: Tuple[TensorIndex, ...]
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "PackOptions")
        return PackOptions(
            values_count=opt.ValuesCount(),
            axis=opt.Axis(),
            input=_inputs(op),
            output=_outputs(op)[0],
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class GatherOptions(FN_EXTEND):
    input0: TensorIndex  # params
    input1: TensorIndex  # indices
    output: TensorIndex
    axis: int
    batch_dims: int = 0

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "GatherOptions")
        inputs = _inputs(op)
        return GatherOptions(
            input0=inputs[0],
            input1=inputs[1],
            output=_outputs(op)[0],
            axis=opt.Axis(),
            batch_dims=opt.BatchDims(),
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class WhileOptions(FN_EXTEND):
    cond_subgraph_index: int
    body_subgraph_index: int
    inputs: Tuple[TensorIndex, ...]
    outputs: Tuple[TensorIndex, ...]

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "WhileOptions")
        return WhileOptions(
            cond_subgraph_index=opt.CondSubgraphIndex(),
            body_subgraph_index=opt.BodySubgraphIndex(),
            inputs=_inputs(op),
            outputs=_outputs(op),
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class SoftmaxOptions(FN_EXTEND):
    beta: float
    input: TensorIndex
    output: TensorIndex
    #
    axis: int = -1

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "SoftmaxOptions")
        return SoftmaxOptions(
            beta=opt.Beta(),
            input=_inputs(op)[0],
            output=_outputs(op)[0],
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class ShapeOptions(FN_EXTEND):
    out_type: str
    input: TensorIndex
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "ShapeOptions")
        return ShapeOptions(
            out_type=TensorType.name(opt.OutType()),
            input=_inputs(op)[0],
            output=_outputs(op)[0],
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class ExpandDimsOptions(FN_EXTEND):
    inputs: Tuple[TensorIndex, ...]
    outputs: Tuple[TensorIndex, ...]


@ExtendedOptions.register
@dataclasses.dataclass(frozen=True)
class UnsqueezeOptions(FN_EXTEND):
    input: TensorIndex
    axis: TensorIndex
    output: TensorIndex
    trace: List = dataclasses.field(default_factory=list)


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class TopKV2Options(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: Tuple[TensorIndex, ...]

    @staticmethod
    def get(op: tflite_Operator):
        inputs = _inputs(op)
        return TopKV2Options(
            input0=inputs[0],
            input1=inputs[1],
            output=_outputs(op),
        )


@ExtendedOptions.register
@dataclasses.dataclass(frozen=True)
class TopKIndicesOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: Tuple[TensorIndex, ...]


@ExtendedOptions.register
@dataclasses.dataclass(frozen=True)
class TopKValuesOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: Tuple[TensorIndex, ...]


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class SelectOptions(FN_EXTEND):
    inputs: Tuple[TensorIndex, ...]
    outputs: Tuple[TensorIndex, ...]


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class SelectV2Options(FN_EXTEND):
    inputs: Tuple[TensorIndex, ...]
    outputs: Tuple[TensorIndex, ...]


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class DivOptions(FN_EXTEND):
    fused_activation_function: str
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "DivOptions")
        inputs = _inputs(op)
        return DivOptions(
            fused_activation_function=ActFuncType.name(opt.FusedActivationFunction()),
            input0=inputs[0],
            input1=inputs[1],
            output=_outputs(op)[0],
        )


@ExtendedOptions.register
@dataclasses.dataclass(frozen=True)
class ModOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        inputs = _inputs(op)
        return ModOptions(
            input0=inputs[0],
            input1=inputs[1],
            output=_outputs(op)[0],
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class SqueezeOptions(FN_EXTEND):
    squeeze_axes: Tuple[int, ...]
    input: TensorIndex
    output: TensorIndex
    trace: List = dataclasses.field(default_factory=list)

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "SqueezeOptions")
        return SqueezeOptions(
            squeeze_axes=get_as_tuple(opt, "SqueezeDims"),
            input=_inputs(op)[0],
            output=_outputs(op)[0],
        )


@ExtendedOptions.register
@dataclasses.dataclass(frozen=True)
class GeneratedSplitOptions(FN_EXTEND):
    """helper for unpack => split + squeeze unfolding."""

    input: TensorIndex
    output: Tuple[TensorIndex, ...]
    axis: int
    num_splits: int
    trace: List = dataclasses.field(default_factory=list)

    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        dct = _as_dict_wrapper(self, tensors)
        dct["split"] = None
        dct["num_outputs"] = dct.pop("num_splits")
        return dct


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class SplitOptions(FN_EXTEND):
    axis: TensorIndex
    input: TensorIndex
    output: Tuple[TensorIndex, ...]
    num_splits: int

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "SplitOptions")
        inputs = _inputs(op)
        outputs = _outputs(op)
        return SplitOptions(
            axis=inputs[0],
            input=inputs[1],
            num_splits=opt.NumSplits(),
            output=outputs,
        )

    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        dct = _as_dict_wrapper(self, tensors)
        dct["split"] = None
        dct["num_outputs"] = dct.pop("num_splits")
        return dct


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class SelectV2Options(FN_EXTEND):
    inputs: Tuple[TensorIndex, ...]
    outputs: Tuple[TensorIndex, ...]


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class ReshapeOptions(FN_EXTEND):
    input: TensorIndex
    shape: TensorIndex
    output: TensorIndex
    new_shape: tuple = tuple()
    allowzero: int = 0
    trace: List = dataclasses.field(default_factory=list)

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "ReshapeOptions")
        inputs = _inputs(op)
        if opt is None:
            return ReshapeOptions(
                input=inputs[0],
                shape=inputs[1],
                output=_outputs(op)[0],
            )
        return ReshapeOptions(
            input=inputs[0],
            shape=inputs[1],
            output=_outputs(op)[0],
            new_shape=get_as_tuple(opt, "NewShape"),
        )


@ExtendedOptions.register
@dataclasses.dataclass(frozen=True)
class FlattenOptions(FN_EXTEND):
    input: TensorIndex
    shape: TensorIndex
    output: TensorIndex
    axis: int = 0
    trace: List = dataclasses.field(default_factory=list)

    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        dct = _as_dict_wrapper(self, tensors)
        data_format = "NHWC"
        n_batch, input_shape = resolve_input_shape(tensors[self.input], data_format)
        reshape_size = functools.reduce(operator.mul, input_shape)
        output_shape = _HWC(1, 1, reshape_size)

        # dct["input_shape"] = [tuple(input_shape)]
        dct["output_shape"] = tuple(output_shape)

        return dct


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class CastOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex
    in_data_type: str = "None"
    out_data_type: str = "None"

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "CastOptions")
        if opt is None:
            return CastOptions(
                input=_inputs(op)[0],
                output=_outputs(op)[0],
            )
        return CastOptions(
            input=_inputs(op)[0],
            output=_outputs(op)[0],
            in_data_type=TensorType.name(opt.InDataType()),
            out_data_type=TensorType.name(opt.OutDataType()),
        )

    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        dct = _as_dict_wrapper(self, tensors)
        dct["data_type"] = dct.pop("out_data_type")
        return dct


@BuiltinOptions.register
@dataclasses.dataclass
class TransposeOptions(FN_EXTEND):
    input: TensorIndex
    transpose_axes: TensorIndex
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        inputs = _inputs(op)
        outputs = _outputs(op)
        return TransposeOptions(
            input=inputs[0],
            transpose_axes=inputs[1],
            output=outputs[0],
        )


@BuiltinOptions.register
@dataclasses.dataclass
class SliceOptions(FN_EXTEND):
    input: TensorIndex
    begin: TensorIndex
    size: TensorIndex
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        inputs = _inputs(op)
        outputs = _outputs(op)
        return SliceOptions(
            input=inputs[0],
            begin=inputs[1],
            size=inputs[2],
            output=outputs[0],
        )


@BuiltinOptions.register
@dataclasses.dataclass
class EqualOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex


@BuiltinOptions.register
@dataclasses.dataclass
class NotEqualOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex


@BuiltinOptions.register
@dataclasses.dataclass
class GreaterOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex


@BuiltinOptions.register
@dataclasses.dataclass
class GreaterEqualOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex


@BuiltinOptions.register
@dataclasses.dataclass
class LessOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex


@BuiltinOptions.register
@dataclasses.dataclass
class LessEqualOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex


@BuiltinOptions.register
@dataclasses.dataclass
class LogicalAndOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex


@BuiltinOptions.register
@dataclasses.dataclass
class LogicalOrOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex


@BuiltinOptions.register
@dataclasses.dataclass
class MaximumMinimumOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex


@ExtendedOptions.register
@dataclasses.dataclass
class ReluOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex
    trace: List = dataclasses.field(default_factory=list)


@ExtendedOptions.register
@dataclasses.dataclass
class Relu6Options(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex
    trace: List = dataclasses.field(default_factory=list)


@BuiltinOptions.register
@dataclasses.dataclass
class LeakyReluOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex
    alpha: float

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "LeakyReluOptions")
        inputs = _inputs(op)
        outputs = _outputs(op)
        return LeakyReluOptions(input=inputs[0], output=outputs[0], alpha=opt.Alpha())

    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        dct = _as_dict_wrapper(self, tensors)
        dct["leaky_alpha"] = dct.pop("alpha")
        return dct


@ExtendedOptions.register
@dataclasses.dataclass
class ClipOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex
    clip_max_value: float
    clip_min_value: float
    trace: List = dataclasses.field(default_factory=list)


@BuiltinOptions.register
@dataclasses.dataclass
class TileOptions(FN_EXTEND):
    inputs: Tuple[TensorIndex, ...]
    outputs: Tuple[TensorIndex, ...]


@ExtendedOptions.register
@dataclasses.dataclass
class SigmoidOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex


@ExtendedOptions.register
@dataclasses.dataclass
class RoundOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex


@BuiltinOptions.register
@dataclasses.dataclass
class PadOptions(FN_EXTEND):
    input: TensorIndex
    pad: TensorIndex
    output: TensorIndex
    pad_mode: str = "constant"
    constant_values: int = 0

    @staticmethod
    def get(op: tflite_Operator):
        inputs = _inputs(op)
        outputs = _outputs(op)
        return PadOptions(
            input=inputs[0],
            pad=inputs[1],
            output=outputs[0],
        )

    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        dct = _as_dict_wrapper(self, tensors)
        dct["constant"] = dct.pop("constant_values")

        return dct


@BuiltinOptions.register
@dataclasses.dataclass
class PadV2Options(FN_EXTEND):
    input: TensorIndex
    pad: TensorIndex
    output: TensorIndex
    pad_mode: str = "constant"
    constant_values: Union[float, TensorIndex] = 0

    @staticmethod
    def get(op: tflite_Operator):
        inputs = _inputs(op)
        outputs = _outputs(op)
        return PadV2Options(
            input=inputs[0],
            pad=inputs[1],
            constant_values=inputs[2],
            output=outputs[0],
        )

    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        dct = _as_dict_wrapper(self, tensors)
        dct["constant"] = dct.pop("constant_values")
        return dct


@ExtendedOptions.register
@dataclasses.dataclass
class IdentityOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex
    trace: List = dataclasses.field(default_factory=list)


@ExtendedOptions.register
@dataclasses.dataclass
class InputOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex

    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        dct = _as_dict_wrapper(self, tensors)
        dct["dtype"] = _to_numpy_dtype(tensors[self.input].type)
        dct["shape"] = dct["input_shape"][0]
        return dct


@BuiltinOptions.register
@dataclasses.dataclass
class NonMaxSuppressionV4Options(FN_EXTEND):
    input0: TensorIndex  # boxes
    input1: TensorIndex  # scores
    max_output_size: TensorIndex
    iou_threshold: TensorIndex
    score_threshold: TensorIndex
    output: Tuple[TensorIndex, ...]
    pad_to_max_output_size: bool = False
    name: str = ""

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "NonMaxSuppressionV4Options")
        inputs = _inputs(op)
        outputs = _outputs(op)

        return NonMaxSuppressionV4Options(
            input0=inputs[0],
            input1=inputs[1],
            max_output_size=inputs[2],
            iou_threshold=inputs[3],
            score_threshold=inputs[4],
            output=outputs,
        )


@BuiltinOptions.register
@dataclasses.dataclass
class NonMaxSuppressionV5Options(FN_EXTEND):
    input0: TensorIndex  # boxes
    input1: TensorIndex  # scores
    max_output_size: TensorIndex
    iou_threshold: TensorIndex
    score_threshold: TensorIndex
    soft_nms_sigma: TensorIndex
    output: Tuple[TensorIndex, ...]
    pad_to_max_output_size: bool = False
    name: str = ""

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "NonMaxSuppressionV5Options")
        inputs = _inputs(op)
        outputs = _outputs(op)

        return NonMaxSuppressionV5Options(
            input0=inputs[0],
            input1=inputs[1],
            max_output_size=inputs[2],
            iou_threshold=inputs[3],
            score_threshold=inputs[4],
            soft_nms_sigma=inputs[5],
            output=outputs,
        )


@BuiltinOptions.register
@dataclasses.dataclass
class ResizeNearestNeighborOptions(FN_EXTEND):
    input: TensorIndex
    sizes: TensorIndex
    output: TensorIndex
    align_corners: bool
    half_pixel_centers: bool
    #
    resize_mode: str
    nearest_mode: str
    transform_mode: str

    roi: str = None
    scales: str = None
    cubic_coeff_a: float = 0.75
    exclude_outside: int = 0
    extrapolation_value: float = 0.0
    antialias: int = 0
    axes: str = None
    keep_aspect_ratio_policy: str = "stretch"

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "ResizeNearestNeighborOptions")
        inputs = _inputs(op)
        outputs = _outputs(op)

        align_corners = opt.AlignCorners()
        half_pixel_centers = opt.HalfPixelCenters()

        resize_mode = "nearest"
        if not align_corners and not half_pixel_centers:
            transform_mode = "asymmetric"
            nearest_mode = "floor"
        elif align_corners and not half_pixel_centers:
            transform_mode = "align_corners"
            nearest_mode = "round_prefer_ceil"
        elif not align_corners and half_pixel_centers:
            transform_mode = "tf_half_pixel_for_nn"
            nearest_mode = "floor"
        else:
            transform_mode = "tf_half_pixel_for_nn"
            nearest_mode = "round_prefer_ceil"

        return ResizeNearestNeighborOptions(
            input=inputs[0],
            sizes=inputs[1],
            output=outputs[0],
            align_corners=opt.AlignCorners(),
            half_pixel_centers=opt.HalfPixelCenters(),
            resize_mode=resize_mode,
            nearest_mode=nearest_mode,
            transform_mode=transform_mode,
        )


@ExtendedOptions.register
@dataclasses.dataclass
class FusedBatchNormV3Options(FN_EXTEND):
    input: TensorIndex
    output: Tuple[TensorIndex, ...]
    gamma: TensorIndex
    beta: TensorIndex
    moving_mean: TensorIndex
    moving_variance: TensorIndex
    custom_options: Dict

    custom_options_fields: ClassVar[List] = [
        CustomOptionField("epsilon", CustomOptionField.T.float),
        CustomOptionField("exponential_avg_factor", CustomOptionField.T.float),
        CustomOptionField("is_training", CustomOptionField.T.bool),
        CustomOptionField("data_format", CustomOptionField.T.str),
        CustomOptionField("T", CustomOptionField.T.dtype),
    ]

    @staticmethod
    def get(op: tflite_Operator, custom_options: Dict):
        inputs = _inputs(op)
        outputs = _outputs(op)

        return FusedBatchNormV3Options(
            input=inputs[0],
            gamma=inputs[1],
            beta=inputs[2],
            moving_mean=inputs[3],
            moving_variance=inputs[4],
            output=outputs,
            custom_options=custom_options,
        )

    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        dct = _as_dict_wrapper(self, tensors)
        custom_options = dct.pop("custom_options")
        dct["epsilon"] = custom_options["epsilon"]
        dct["moving_var"] = dct.pop("moving_variance")
        dct["training_mode"] = custom_options["is_training"]
        dct["output"] = dct.pop("output")[0]
        dct["src_shape"] = dct.pop("src_shape")[0]
        return dct


@BuiltinOptions.register
@dataclasses.dataclass
class SplitVOptions(FN_EXTEND):
    input: TensorIndex
    size_splits: TensorIndex
    axis: TensorIndex
    num_splits: int
    output: Tuple[TensorIndex, ...]

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "SplitVOptions")
        inputs = _inputs(op)
        outputs = _outputs(op)
        return SplitVOptions(
            input=inputs[0],
            size_splits=inputs[1],
            axis=inputs[2],
            num_splits=opt.NumSplits(),
            output=outputs,
        )

    def as_dict(self, tensors: List[TensorSpec], **kwargs):
        dct = _as_dict_wrapper(self, tensors)
        dct["split"] = dct.pop("size_splits")
        dct["num_outputs"] = dct.pop("num_splits")

        return dct


@BuiltinOptions.register
@dataclasses.dataclass
class HardSwishOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex


@BuiltinOptions.register
@dataclasses.dataclass
class SquaredDifferenceOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        inputs = _inputs(op)
        outputs = _outputs(op)
        return SquaredDifferenceOptions(
            input0=inputs[0],
            input1=inputs[1],
            output=outputs[0],
        )


@ExtendedOptions.register
@dataclasses.dataclass(frozen=True)
class RsqrtOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex


@BuiltinOptions.register
@dataclasses.dataclass
class GeluOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex
    approximate: bool

    @staticmethod
    def get(op: tflite_Operator):
        opt = _get_opt(op, "GeluOptions")
        return GeluOptions(
            input=_inputs(op)[0], output=_outputs(op)[0], approximate=opt.Approximate()
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class PowOptions(FN_EXTEND):
    input: TensorIndex
    exponent: TensorIndex
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        inputs = _inputs(op)
        outputs = _outputs(op)
        return PowOptions(
            input=inputs[0],
            exponent=inputs[1],
            output=outputs[0],
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class FillOptions(FN_EXTEND):
    input: TensorIndex  # dims
    value: TensorIndex  # 0-d tensor
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        inputs = _inputs(op)
        outputs = _outputs(op)
        return FillOptions(input=inputs[0], value=inputs[1], output=outputs[0])


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class AbsOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class FloorDivOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class FloorModOptions(FN_EXTEND):
    input0: TensorIndex
    input1: TensorIndex
    output: TensorIndex


@ExtendedOptions.register
@dataclasses.dataclass(frozen=True)
class FloorOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class SpaceToBatchNDOptions(FN_EXTEND):
    input: Tuple[TensorIndex, ...]
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        inputs = _inputs(op)
        outputs = _outputs(op)
        return SpaceToBatchNDOptions(
            input=inputs,
            output=outputs[0],
        )


@BuiltinOptions.register
@dataclasses.dataclass(frozen=True)
class BatchToSpaceNDOptions(FN_EXTEND):
    input: Tuple[TensorIndex, ...]
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        inputs = _inputs(op)
        outputs = _outputs(op)
        return BatchToSpaceNDOptions(
            input=inputs,
            output=outputs[0],
        )


@ExtendedOptions.register
@dataclasses.dataclass(frozen=True)
class TanhOptions(FN_EXTEND):
    input: TensorIndex
    output: TensorIndex

    @staticmethod
    def get(op: tflite_Operator):
        inputs = _inputs(op)
        outputs = _outputs(op)
        return TanhOptions(
            input=inputs[0],
            output=outputs[0],
        )


# todo: upgrade tensorflow version to support Sign Operator.
# @BuiltinOptions.register
# @dataclasses.dataclass(frozen=True)
# class SignOptions(FN_EXTEND):
#     input: TensorIndex
#     output: TensorIndex
#
#     @staticmethod
#     def get(op: tflite_Operator):
#         inputs = _inputs(op)
#         outputs = _outputs(op)
#         return SignOptions(input=inputs[0], output=outputs[0])
