def gen_iter(iterobj, attr_name):
    """iteration helper"""
    for j in range(getattr(iterobj, attr_name + "Length")()):
        yield getattr(iterobj, attr_name)(j)


def get_as_tuple(iterobj, attr_name):
    return tuple(gen_iter(iterobj, attr_name))


def get_as_list(iterobj, attr_name):
    return list(gen_iter(iterobj, attr_name))
