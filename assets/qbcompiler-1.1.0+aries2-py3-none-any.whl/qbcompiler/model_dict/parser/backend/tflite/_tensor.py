import enum

import numpy

from ._assets.built_in_options.Tensor import Tensor as tflite_Tensor
from ._assets.util import gen_iter
from ._assets.built_in_options.TensorMap import TensorMap as tflite_TensorMap
from ._assets.built_in_options.TensorType import TensorType as tflite_TensorType

from dataclasses import dataclass
from typing import Tuple, Optional, Dict, Any


class TensorType:
    _mapping: Dict[int, str] = {}

    @staticmethod
    def name(built_in_code: int):
        if built_in_code not in TensorType._mapping:
            for k, v in tflite_TensorType.__dict__.items():
                if v == built_in_code:
                    TensorType._mapping[built_in_code] = k
                    return k
        return TensorType._mapping[built_in_code]

    @staticmethod
    def type(type_name: str) -> int:
        if type_name not in TensorType._mapping:
            for k, v in tflite_TensorType.__dict__.items():
                if k == type_name:
                    TensorType._mapping[v] = type_name
                    return v
        return getattr(tflite_TensorType, type_name)


@dataclass(frozen=True)
class QuantizationParameters:
    """
    details will be implemented when it is needed.
    """

    # min:List[float]
    # max:List[float]
    # scale:List[float]
    # zero_point:List[int]
    #
    # # // If this is not none, the other quantization parameters (i.e. min, max,
    # #                                                // scale, zero_point fields above) are ignored and the value of the
    # # // QuantizationDetails union should be used.
    # details:QuantizationDetails;
    #
    # // Specifies the dimension of the Tensor's shape that the scales and
    # // zero_points correspond to. For example, a tensor t, with dims=[4, 3, 2, 1]
    # // with quantization params:
    #     //   scale=[1.0, 2.0, 3.0], zero_point=[1, 2, 3], quantization_dimension=1
    # // will be quantized across the second dimension of t.
    # //   t[:, 0, :, :] will have scale[0]=1.0, zero_point[0]=1
    # //   t[:, 1, :, :] will have scale[1]=2.0, zero_point[0]=2
    # //   t[:, 2, :, :] will have scale[2]=3.0, zero_point[0]=3
    # quantized_dimension:int;
    def get(x):
        return QuantizationParameters()


@dataclass
class SparsityParameters:
    """
    details will be implemented when it is needed.
    """

    def get(x):
        return QuantizationParameters()


@dataclass
class VariantSubType:
    """
    details will be implemented when it is needed.
    """

    def get(x):
        return QuantizationParameters()


class TensorIndex(int):
    def __new__(cls, value, *args, **kwargs):
        return super().__new__(cls, value)

    def __repr__(self):
        return f"TensorIndex({int(self)})"


class DataFormat(enum.Enum):
    NHWC = 0
    OCICHW = 1


@dataclass
class BufferData:
    name: str
    data: Optional[numpy.ndarray]
    data_format: DataFormat = DataFormat.NHWC


@dataclass(frozen=True)
class TensorSpec:
    # The tensor shape. The meaning of each entry is operator-specific but
    # builtin ops use: [batch size, height, width, number of channels] (That's
    # Tensorflow's NHWC).
    shape: Tuple[int, ...]
    buffer_read_shape: Tuple[int, ...]
    type: str
    # An index that refers to the buffers table at the root of the model. Or,
    # if there is no data buffer associated (i.e. intermediate results), then
    # this is 0 (which refers to an always existent empty buffer).
    #
    # The data_buffer itself is an opaque container, with the assumption that the
    # target device is little-endian. In addition, all builtin operators assume
    # the memory is ordered such that if `shape` is [4, 3, 2], then index
    # [i, j, k] maps to data_buffer[i*3*2 + j*2 + k].
    buffer: int
    # For debugging and importing back into tensorflow.
    name: str
    quantization: Optional[QuantizationParameters]
    is_variable: bool
    # Parameters to encode a sparse tensor. See the example in
    # tensorflow/lite/testdata/sparse_tensor.json.
    sparsity: SparsityParameters
    # Encodes `shape` with unknown dimensions. Unknown dimensions are
    # represented with -1.
    shape_signature: Tuple[int, ...]
    # This field is added to distinguish between scalars and tensors of unknown
    # ranks (both of which shape is []).
    # For scalars (rank = 0), shape = [] and has_rank = true.
    # For tensors with known rank (rank > 0) and shape, shape = [...] and
    # has_rank = true.
    # For tensors with unknown rank and shape, shape = [] and has_rank = false.
    has_rank: bool
    # The nested Tensor types for VARIANT type. This is always empty for
    # non-VARIANT types. This is optional because the nested type can be omitted.
    # Currently only 1 subtype is supported. The field is defined as an array for
    # flexibility of supporting multiple subtypes in the future.
    variant_tensors: Tuple[VariantSubType]

    def set_shape_hint(self, hint_):
        if len(hint_) == len(self.shape) and all(
            new_val == val or sig == -1
            for new_val, val, sig in zip(hint_, self.shape, self.shape_signature)
        ):
            super().__setattr__("shape", hint_)
        else:
            raise ValueError(
                f"shape_hint={hint_}, shape={self.shape}, shape_signature={self.shape_signature}"
            )

    @staticmethod
    def get(tensor: tflite_Tensor, name_prepend=""):
        return TensorSpec(
            shape=tuple(gen_iter(tensor, "Shape")),
            buffer_read_shape=tuple(gen_iter(tensor, "Shape")),
            type=TensorType.name(tensor.Type()),
            buffer=tensor.Buffer(),
            name=name_prepend + tensor.Name().decode(),
            quantization=QuantizationParameters.get(tensor.Quantization()),
            is_variable=tensor.IsVariable(),
            sparsity=tensor.Sparsity(),
            shape_signature=tuple(gen_iter(tensor, "ShapeSignature")),
            has_rank=tensor.HasRank(),
            variant_tensors=tuple(gen_iter(tensor, "VariantTensors")),
        )

    @staticmethod
    def get_scalar(name, dtype):
        return TensorSpec(
            shape=tuple(),
            buffer_read_shape=tuple(),
            type=dtype,
            buffer=-1,
            name=name,
            quantization=None,
            is_variable=False,
            sparsity=None,
            shape_signature=tuple(),
            has_rank=False,
            variant_tensors=tuple(),
        )


@dataclass(frozen=True)
class TensorMap:
    name: str
    tensor_index: int

    @staticmethod
    def get(tensor_map: tflite_TensorMap):
        return TensorMap(
            name=tensor_map.Name().decode(), tensor_index=tensor_map.TensorIndex()
        )
