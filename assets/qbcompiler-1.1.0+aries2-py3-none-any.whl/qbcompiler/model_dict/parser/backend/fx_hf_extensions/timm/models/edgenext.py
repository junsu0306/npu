from typing import Optional, Union, Tuple

import torch
import timm.models.edgenext as edgenext

from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HF_PATCHER_CFG,
    HFModelPatcher,
)

def PositionalEncodingFourierforward(self, shape: Tuple[int, int, int]):
    device = self.token_projection.weight.device
    dtype = self.token_projection.weight.dtype
    inv_mask = ~torch.zeros(shape, device=device, dtype=torch.bool)
    y_embed = inv_mask.cumsum(1, dtype=torch.float32)
    x_embed = inv_mask.cumsum(2, dtype=torch.float32)
    eps = 1e-6
    y_embed = y_embed / (y_embed[:, -1:, :] + eps) * self.scale
    x_embed = x_embed / (x_embed[:, :, -1:] + eps) * self.scale

    dim_t = torch.arange(self.hidden_dim, dtype=torch.int64, device=device).to(torch.float32)
    dim_t = self.temperature ** (2 * torch.div(dim_t, 2, rounding_mode='floor') / self.hidden_dim)

    pos_x = x_embed[:, :, :, None] / dim_t
    pos_y = y_embed[:, :, :, None] / dim_t
    pos_x = torch.stack(
        (pos_x[:, :, :, 0::2].sin(),
            pos_x[:, :, :, 1::2].cos()), dim=4).flatten(3)
    pos_y = torch.stack(
        (pos_y[:, :, :, 0::2].sin(),
            pos_y[:, :, :, 1::2].cos()), dim=4).flatten(3)
    pos = torch.cat((pos_y, pos_x), dim=3).permute(0, 3, 1, 2)
    pos = self.token_projection(pos.to(dtype))

    return pos


class EdgeNeXtPatcher(HFModelPatcher):
    def __init__(self, root: torch.nn.Module):
        super().__init__(root)
        self.text_model_rotary_emb = None

    def __enter__(self):
        for stage in self.root.stages:
            for i, layer in enumerate(stage.blocks):
                if isinstance(layer, edgenext.SplitTransposeBlock):
                    if layer.pos_embd is not None:
                        layer.pos_embd.forward = PositionalEncodingFourierforward.__get__(layer.pos_embd, type(layer.pos_embd))

    def __exit__(self, exc_type, exc_val, exc_tb):
        model = self.root

class EdgeNeXtWrapper(torch.nn.Module):
    def __init__(self, timm_model: edgenext.EdgeNeXt) -> None:
        super().__init__()
        self.timm_model = timm_model

    def forward(
        self,
        x
    ):
        return self.timm_model.forward(x)


_AUTOWRAP_FNS = [
]


def get_patcher_cfg():
    # fmt:off
    return HF_PATCHER_CFG(
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
            edgenext.EdgeNeXt:(EdgeNeXtPatcher, EdgeNeXtWrapper)
        }
    )

    # fmt:on
