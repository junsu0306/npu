from typing import Optional, Union, Tuple, List

import torch
import transformers.models.roberta.modeling_roberta as modeling_roberta
from transformers import HybridCache, Cache

from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HFModelPatcher,
    HF_PATCHER_CFG,
)
def RobertaLMHeadForward(self, features, **kwargs):
    x = self.dense(features)
    x = torch.nn.functional.gelu(x)
    x = self.layer_norm(x)
    # project back to size of vocabulary with bias
    x = self.decoder(x)

    return x

class RobertaPatcher(HFModelPatcher):
    def __init__(self, root: torch.nn.Module):
        super().__init__(root)
        self.org_rot_emb = {}

    def __enter__(self):
        if isinstance(self.root, modeling_roberta.RobertaModel):
            text_model = self.root
        elif isinstance(self.root, modeling_roberta.RobertaForMaskedLM):
            text_model = self.root
        else:
            raise NotImplementedError
        text_model.lm_head.forward = RobertaLMHeadForward.__get__(text_model.lm_head, type(text_model.lm_head))

    def __exit__(self, exc_type, exc_val, exc_tb):
        if isinstance(self.root, modeling_roberta.RobertaModel):
            text_model = self.root
        elif isinstance(self.root, modeling_roberta.RobertaForMaskedLM):
            text_model = self.root
        else:
            raise NotImplementedError

class RobertaForMaskedLMWrapper(torch.nn.Module):
    def __init__(self, language_model) -> None:
        super().__init__()
        if isinstance(language_model, modeling_roberta.RobertaForMaskedLM):
            self.language_model = language_model
        else:
            raise NotImplementedError       

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.FloatTensor] = None,
        token_type_ids: Optional[torch.LongTensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        head_mask: Optional[torch.FloatTensor] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        encoder_hidden_states: Optional[torch.FloatTensor] = None,
        encoder_attention_mask: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ):
        return self.language_model.forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            labels=labels,
            encoder_hidden_states=encoder_hidden_states,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            encoder_attention_mask=encoder_attention_mask,
            return_dict=return_dict,
        )

class RobertaModelWrapper(torch.nn.Module):
    def __init__(self, language_model) -> None:
        super().__init__()
        if isinstance(language_model, modeling_roberta.RobertaModel):
            self.language_model = language_model
        else:
            raise NotImplementedError       

    def forward(
        self,
        input_ids: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
        head_mask: Optional[torch.Tensor] = None,
        inputs_embeds: Optional[torch.Tensor] = None,
        encoder_hidden_states: Optional[torch.Tensor] = None,
        encoder_attention_mask: Optional[torch.Tensor] = None,
        past_key_values: Optional[List[torch.FloatTensor]] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ):
        return self.language_model.forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            past_key_values=past_key_values,
            use_cache=use_cache,
            encoder_hidden_states=encoder_hidden_states,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            encoder_attention_mask=encoder_attention_mask,
            return_dict=return_dict,
        )

_AUTOWRAP_FNS = [
]


def get_patcher_cfg():
    # fmt:off
    modelCFG = HF_PATCHER_CFG(
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
            modeling_roberta.RobertaModel: (RobertaPatcher, RobertaModelWrapper)
        },
    )
    maskedLMCFG = HF_PATCHER_CFG(
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
            modeling_roberta.RobertaForMaskedLM: (RobertaPatcher, RobertaForMaskedLMWrapper)
        },
    )
    return [modelCFG, maskedLMCFG]
    # fmt:on
