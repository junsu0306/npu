from typing import Optional, Union, Tuple, List

import math
import torch
import torch.nn as nn
import transformers.models.aya_vision.modeling_aya_vision as modeling_aya_vision

from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HF_PATCHER_CFG,
)

class AyaVisionVisionModelWrapper(torch.nn.Module):
    def __init__(self, vision_model) -> None:
        super().__init__()
        self.vision_model = vision_model

    def forward(
        self,
        pixel_values: torch.FloatTensor,
        vision_feature_layer: Union[int, List[int]],
        vision_feature_select_strategy: str,
        **kwargs,
    ):
        return self.vision_model.get_image_features(
            pixel_values=pixel_values,
            vision_feature_layer=vision_feature_layer,
            vision_feature_select_strategy=vision_feature_select_strategy,
            **kwargs,
        )

_AUTOWRAP_FNS = [
    # get_extended_attention_mask
]

def get_patcher_cfg():
    # fmt:off
    return HF_PATCHER_CFG(
        autowrap_fns=[],
        root_patcher_wrapper={
            modeling_aya_vision.AyaVisionForConditionalGeneration:(None, AyaVisionVisionModelWrapper)
        }
    )
    # fmt:on
