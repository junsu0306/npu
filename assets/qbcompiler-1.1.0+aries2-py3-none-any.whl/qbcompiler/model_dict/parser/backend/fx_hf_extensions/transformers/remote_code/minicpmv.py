from typing import Optional, Union, Tuple, List, Dict

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from qbcompiler.model_dict.parser.backend.torch.fx.proxy import MbltProxy
from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HF_REMOTE_CODE_PATCHER_CFG,
    HFModelPatcher
)

def _canonical_mask(
        mask: Optional[Tensor],
        mask_name: str,
        other_type,
        other_name: str,
        target_type,
        check_other: bool = True,
) -> Optional[Tensor]:

    if mask is not None:
        _mask_dtype = mask.dtype
        _mask_is_float = torch.is_floating_point(mask)
        if _mask_dtype != torch.bool and not _mask_is_float:
            raise AssertionError(
                f"only bool and floating types of {mask_name} are supported")
        if check_other and other_type is not None:
            if _mask_dtype != other_type:
                warnings.warn(
                    f"Support for mismatched {mask_name} and {other_name} "
                    "is deprecated. Use same type for both instead."
                )
        if not _mask_is_float:
            mask = (
                torch.zeros_like(mask).to(target_type)
                .masked_fill_(mask, float("-inf"))
            )
    return mask

def MiniCPMVResamplerForward(
            self,
            query: Tensor,
            key: Tensor,
            value: Tensor,
            key_padding_mask: Optional[Tensor] = None,
            need_weights: bool = True,
            attn_mask: Optional[Tensor] = None,
            average_attn_weights: bool = True,
            is_causal : bool = False) -> Tuple[Tensor, Optional[Tensor]]:
    why_not_fast_path = ''
    if ((attn_mask is not None and torch.is_floating_point(attn_mask))
        or (key_padding_mask is not None) and torch.is_floating_point(key_padding_mask)):
        why_not_fast_path = "floating-point masks are not supported for fast path."

    is_batched = query.dim() == 3

    key_padding_mask = _canonical_mask(
        mask=key_padding_mask,
        mask_name="key_padding_mask",
        other_type=F._none_or_dtype(attn_mask),
        other_name="attn_mask",
        target_type=query.dtype
    )

    attn_mask = _canonical_mask(
        mask=attn_mask,
        mask_name="attn_mask",
        other_type=None,
        other_name="",
        target_type=query.dtype,
        check_other=False,
    )


    if not is_batched:
        why_not_fast_path = f"input not batched; expected query.dim() of 3 but got {query.dim()}"
    elif query is not key or key is not value:
        # When lifting this restriction, don't forget to either
        # enforce that the dtypes all match or test cases where
        # they don't!
        why_not_fast_path = "non-self attention was used (query, key, and value are not the same Tensor)"
    elif self.in_proj_bias is not None and query.dtype != self.in_proj_bias.dtype:
        why_not_fast_path = f"dtypes of query ({query.dtype}) and self.in_proj_bias ({self.in_proj_bias.dtype}) don't match"
    elif self.in_proj_weight is None:
        why_not_fast_path = "in_proj_weight was None"
    elif query.dtype != self.in_proj_weight.dtype:
        # this case will fail anyway, but at least they'll get a useful error message.
        why_not_fast_path = f"dtypes of query ({query.dtype}) and self.in_proj_weight ({self.in_proj_weight.dtype}) don't match"
    elif self.training:
        why_not_fast_path = "training is enabled"
    elif (self.num_heads % 2) != 0:
        why_not_fast_path = "self.num_heads is not even"
    elif not self.batch_first:
        why_not_fast_path = "batch_first was not True"
    elif self.bias_k is not None:
        why_not_fast_path = "self.bias_k was not None"
    elif self.bias_v is not None:
        why_not_fast_path = "self.bias_v was not None"
    elif self.add_zero_attn:
        why_not_fast_path = "add_zero_attn was enabled"
    elif not self._qkv_same_embed_dim:
        why_not_fast_path = "_qkv_same_embed_dim was not True"
    elif query.is_nested and (key_padding_mask is not None or attn_mask is not None):
        why_not_fast_path = "supplying both src_key_padding_mask and src_mask at the same time \
                                is not supported with NestedTensor input"
    elif torch.is_autocast_enabled():
        why_not_fast_path = "autocast is enabled"

    if not why_not_fast_path:
        tensor_args = (
            query,
            key,
            value,
            self.in_proj_weight,
            self.in_proj_bias,
            self.out_proj.weight,
            self.out_proj.bias,
        )
        # We have to use list comprehensions below because TorchScript does not support
        # generator expressions.
        if torch.overrides.has_torch_function(tensor_args):
            why_not_fast_path = "some Tensor argument has_torch_function"
        elif _is_make_fx_tracing():
            why_not_fast_path = "we are running make_fx tracing"
        elif not all(_check_arg_device(x) for x in tensor_args):
            why_not_fast_path = ("some Tensor argument's device is neither one of "
                                    f"cpu, cuda or {torch.utils.backend_registration._privateuse1_backend_name}")
        elif torch.is_grad_enabled() and any(_arg_requires_grad(x) for x in tensor_args):
            why_not_fast_path = ("grad is enabled and at least one of query or the "
                                    "input/output projection weights or biases requires_grad")
        if not why_not_fast_path:
            merged_mask, mask_type = self.merge_masks(attn_mask, key_padding_mask, query)

            if self.in_proj_bias is not None and self.in_proj_weight is not None:
                return torch._native_multi_head_attention(
                    query,
                    key,
                    value,
                    self.embed_dim,
                    self.num_heads,
                    self.in_proj_weight,
                    self.in_proj_bias,
                    self.out_proj.weight,
                    self.out_proj.bias,
                    merged_mask,
                    need_weights,
                    average_attn_weights,
                    mask_type)

    any_nested = query.is_nested or key.is_nested or value.is_nested
    assert not any_nested, ("MultiheadAttention does not support NestedTensor outside of its fast path. " +
                            f"The fast path was not hit because {why_not_fast_path}")

    if self.batch_first and is_batched:
        # make sure that the transpose op does not affect the "is" property
        if key is value:
            if query is key:
                query = key = value = query.transpose(1, 0)
            else:
                query, key = (x.transpose(1, 0) for x in (query, key))
                value = key
        else:
            query, key, value = (x.transpose(1, 0) for x in (query, key, value))
    
    if not self._qkv_same_embed_dim:
        attn_output, attn_output_weights = self.multi_head_attention_forward(
            query, key, value, self.embed_dim, self.num_heads,
            self.in_proj_weight, self.in_proj_bias,
            self.bias_k, self.bias_v, self.add_zero_attn,
            self.dropout, self.out_proj.weight, self.out_proj.bias,
            training=self.training,
            key_padding_mask=key_padding_mask, need_weights=need_weights,
            attn_mask=attn_mask,
            use_separate_proj_weight=True,
            q_proj_weight=self.q_proj_weight, k_proj_weight=self.k_proj_weight,
            v_proj_weight=self.v_proj_weight,
            average_attn_weights=average_attn_weights,
            is_causal=is_causal)
    else:
        attn_output, attn_output_weights = self.multi_head_attention_forward(
            query, key, value, self.embed_dim, self.num_heads,
            self.in_proj_weight, self.in_proj_bias,
            self.bias_k, self.bias_v, self.add_zero_attn,
            self.dropout, self.out_proj.weight, self.out_proj.bias,
            training=self.training,
            key_padding_mask=key_padding_mask,
            need_weights=need_weights,
            attn_mask=attn_mask,
            average_attn_weights=average_attn_weights,
            is_causal=is_causal)
    if self.batch_first and is_batched:
        return attn_output.transpose(1, 0), attn_output_weights
    else:
        return attn_output, attn_output_weights


def MiniCPMVVLLMEmbedding(self, data):
    if 'vision_hidden_states' not in data:
        dtype = self.llm.model.embed_tokens.weight.dtype
        device = self.llm.model.embed_tokens.weight.device
        tgt_sizes = data['tgt_sizes']
        pixel_values_list = data['pixel_values']
        vision_hidden_states = []
        all_pixel_values = []
        img_cnt = []
        for pixel_values in pixel_values_list:
            img_cnt.append(len(pixel_values))
            all_pixel_values.extend([i.flatten(end_dim=1).permute(1, 0) for i in pixel_values])

        # exist image
        if all_pixel_values:
            tgt_sizes = [tgt_size for tgt_size in tgt_sizes if isinstance(tgt_size, MbltProxy)]
            tgt_sizes = torch.vstack(tgt_sizes).type(torch.int32)

            max_patches = max(tgt_sizes[:, 0] * tgt_sizes[:, 1])

            all_pixel_values = torch.nn.utils.rnn.pad_sequence(all_pixel_values, batch_first=True,
                                                                padding_value=0.0)
            B, L, _ = all_pixel_values.shape
            all_pixel_values = all_pixel_values.permute(0, 2, 1).reshape(B, 3, -1, L)

            patch_attn_mask = torch.zeros((B, 1, max_patches), dtype=torch.bool, device=device)
            for i in range(B):
                patch_attn_mask[i, 0, :tgt_sizes[i][0] * tgt_sizes[i][1]] = True

            vision_batch_size = self.config.vision_batch_size
            all_pixel_values = all_pixel_values.type(dtype)
            if B > vision_batch_size:
                hs = []
                for i in range(0, B, vision_batch_size):
                    start_idx = i
                    end_idx = i + vision_batch_size
                    tmp_hs = self.vpm(all_pixel_values[start_idx:end_idx], patch_attention_mask=patch_attn_mask[start_idx:end_idx], tgt_sizes=tgt_sizes[start_idx:end_idx]).last_hidden_state
                    hs.append(tmp_hs)
                vision_embedding = torch.cat(hs, dim=0)
            else:
                vision_embedding = self.vpm(all_pixel_values, patch_attention_mask=patch_attn_mask, tgt_sizes=tgt_sizes).last_hidden_state
            vision_embedding = self.resampler(vision_embedding, tgt_sizes)

            start = 0
            for pixel_values in pixel_values_list:
                img_cnt = len(pixel_values)
                if img_cnt > 0:
                    vision_hidden_states.append(vision_embedding[start: start + img_cnt])
                    start += img_cnt
                else:
                    vision_hidden_states.append([])
        else: # no image
            if self.training:
                dummy_image = torch.zeros(
                    (1, 3, 224, 224),
                    device=device, dtype=dtype
                )
                tgt_sizes = torch.Tensor([[(224 // self.config.patch_size), math.ceil(224 / self.config.patch_size)]]).type(torch.int32)
                dummy_feature = self.resampler(self.vpm(dummy_image).last_hidden_state, tgt_sizes)
            else:
                dummy_feature = []
            for _ in range(len(pixel_values_list)):
                vision_hidden_states.append(dummy_feature)

    else:
        vision_hidden_states = data['vision_hidden_states']

    if hasattr(self.llm.config, 'scale_emb'):
        vllm_embedding = self.llm.model.embed_tokens(data['input_ids']) * self.llm.config.scale_emb
    else:
        vllm_embedding = self.llm.model.embed_tokens(data['input_ids'])
        
    new_vllm_embedding = vllm_embedding.clone()

    vision_hidden_states = [i.type(vllm_embedding.dtype) if isinstance(
        i, torch.Tensor) else i for i in vision_hidden_states]

    bs = len(data['input_ids'])
    for i in range(bs):
        cur_vs_hs = vision_hidden_states[i]
        if len(cur_vs_hs) > 0:
            cur_vllm_emb = vllm_embedding[i]
            cur_image_bound = data['image_bound'][i]
            if len(cur_image_bound) > 0:
                image_indices = torch.stack(
                    [torch.arange(r[0], r[1], dtype=torch.long) for r in cur_image_bound]
                ).to(vllm_embedding.device)

                new_vllm_embedding[i] = cur_vllm_emb.scatter(0, image_indices.view(-1, 1).repeat(1, cur_vllm_emb.shape[-1]),
                                        cur_vs_hs.view(-1, cur_vs_hs.shape[-1]))
            elif self.training:
                new_vllm_embedding[i] += cur_vs_hs[0].mean() * 0

    return new_vllm_embedding, vision_hidden_states


class MiniCPMVPatcher(HFModelPatcher):
    def __init__(self, root: torch.nn.Module):
        super().__init__(root)
        self.vision_model = None

    def __enter__(self):
        model = self.root
        model.get_vllm_embedding = MiniCPMVVLLMEmbedding.__get__(model, type(model))
        model.resampler.attn.forward = MiniCPMVResamplerForward.__get__(model.resampler.attn, type(model.resampler.attn))

    def __exit__(self, exc_type, exc_val, exc_tb):
        model = self.root


class MiniCPMVVisionModelWrapper(torch.nn.Module):
    def __init__(self, vision_model) -> None:
        super().__init__()
        self.vision_model = vision_model

    def forward(
        self,
        input_ids=None,
        pixel_values=None,
        tgt_sizes=None,
        image_bound=None,
    ):
        data = {
            "input_ids": input_ids,
            "image_bound": [image_bound],
        }
        data["pixel_values"] = [pixel_values]
        data['tgt_sizes'] = [tgt_sizes]

        return self.vision_model.get_vllm_embedding(
            data=data,
        )

_AUTOWRAP_FNS = [
    "_canonical_mask"
]

def get_patcher_cfg():
    # fmt:off
    return HF_REMOTE_CODE_PATCHER_CFG(
        target='MiniCPMV',
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
            "modeling_minicpmv.MiniCPMV": (MiniCPMVPatcher, MiniCPMVVisionModelWrapper),
        },
    )
    # fmt:on
