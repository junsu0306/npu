from typing import Optional, Union

import torch
from transformers import DynamicCache
from transformers.modeling_outputs import MoeModelOutputWithPast
from transformers.models.qwen3_moe import modeling_qwen3_moe as modeling_qwen3_moe

from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HFModelPatcher,
    HF_PATCHER_CFG,
)


class CachedQwen3MoeRotaryEmbedding(torch.nn.Module):
    def __init__(self, qwen3_moe_rotary_embedding):
        super().__init__()
        self.batch_size = 1
        self.rope_cache_len = 16384

        inv_freq = qwen3_moe_rotary_embedding.inv_freq
        inv_freq_expanded = (
            inv_freq[None, :, None].float().expand(self.batch_size, -1, 1)
        )
        position_ids = (
            torch.arange(self.rope_cache_len).reshape(1, -1).to(inv_freq.device)
        )
        position_ids_expanded = position_ids[:, None, :].float()
        attention_scaling = qwen3_moe_rotary_embedding.attention_scaling
        with torch.autocast(device_type=inv_freq.device.type, enabled=False):
            freqs = (
                inv_freq_expanded.float() @ position_ids_expanded.float()
            ).transpose(1, 2)
            emb = torch.cat((freqs, freqs), dim=-1)
            cos = emb.cos() * attention_scaling
            sin = emb.sin() * attention_scaling
            self.register_buffer("cos", cos)
            self.register_buffer("sin", sin)

    @torch.no_grad()
    def forward(self, x, position_ids):
        print("cached rope call")
        cos = self.cos[:, position_ids.reshape(-1), :].to(dtype=x.dtype)
        sin = self.sin[:, position_ids.reshape(-1), :].to(dtype=x.dtype)
        return cos, sin


def Qwen3MoeModel_forward(
    self,
    input_ids,
    attention_mask,
    position_ids,
    past_key_values,
    inputs_embeds,
    use_cache,
    cache_position,
    **kwargs,
):
    if (input_ids is None) ^ (inputs_embeds is not None):
        raise ValueError("You must specify exactly one of input_ids or inputs_embeds")

    if use_cache and past_key_values is None:
        past_key_values = DynamicCache(config=self.config)

    if inputs_embeds is None:
        inputs_embeds = self.embed_tokens(input_ids)

    if cache_position is None:
        past_seen_tokens = (
            past_key_values.get_seq_length() if past_key_values is not None else 0
        )
        cache_position = torch.arange(
            past_seen_tokens,
            past_seen_tokens + inputs_embeds.shape[1],
            device=inputs_embeds.device,
        )
    if position_ids is None:
        position_ids = cache_position.unsqueeze(0)

    # 실제 동작에서도 causal_mask는 None임. causal_mask를 None으로 넘겨도 torch.sdpa attention을 호출하므로 동작함.
    # mask_function = (
    #     create_causal_mask
    #     if self.config.sliding_window is None
    #     else create_sliding_window_causal_mask
    # )
    # causal_mask = mask_function(
    #     config=self.config,
    #     input_embeds=inputs_embeds,
    #     attention_mask=attention_mask,
    #     cache_position=cache_position,
    #     past_key_values=past_key_values,
    #     position_ids=position_ids,
    # )
    causal_mask = None

    hidden_states = inputs_embeds

    # create position embeddings to be shared across the decoder layers
    position_embeddings = self.rotary_emb(hidden_states, position_ids)

    for decoder_layer in self.layers[: self.config.num_hidden_layers]:
        hidden_states = decoder_layer(
            hidden_states,
            position_embeddings=position_embeddings,
            attention_mask=causal_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            use_cache=use_cache,
            cache_position=cache_position,
            **kwargs,
        )

    hidden_states = self.norm(hidden_states)

    return MoeModelOutputWithPast(  # only diff with Mistral is the output type, we need MoE
        last_hidden_state=hidden_states,
        past_key_values=past_key_values,
    )


class Qwen3MoeForCausalLMWrapper(torch.nn.Module):
    def __init__(self, causal_lm: modeling_qwen3_moe.Qwen3MoeForCausalLM):
        super().__init__()
        self.causal_lm = causal_lm

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional["Cache"] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_router_logits: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        logits_to_keep: Union[int, torch.Tensor] = 0,
        **kwargs,
    ):
        return self.causal_lm.forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            labels=labels,
            use_cache=use_cache,
            output_router_logits=output_router_logits,
            cache_position=cache_position,
            logits_to_keep=logits_to_keep,
            **kwargs,
        )


def sparse_moe_dispatcher(router_logits, hidden_states, top_k: int, norm_topk_prob):
    routing_weights = torch.nn.functional.softmax(
        router_logits, dim=-1, dtype=torch.float
    )
    topk_vals, topk_idx = torch.topk(routing_weights, top_k, dim=-1)
    threshold = topk_vals[..., -1:]
    routing_weights = torch.where(
        routing_weights >= threshold,
        routing_weights,
        torch.tensor(0.0, dtype=torch.float),
    )
    if norm_topk_prob:
        routing_weights = routing_weights / routing_weights.sum(dim=-1, keepdim=True)
    routing_weights = routing_weights.to(hidden_states.dtype)
    return routing_weights, hidden_states


def sparse_moe_aggregator(routing_weights, expert_results):
    # expert_results: (num_experts, tokens, hidden_dim)
    # routing_weights: (1,1,tokens, num_experts)->(num_experts, tokens, 1)
    expert_results = expert_results.squeeze(0)
    w = routing_weights.squeeze((0, 1)).t().unsqueeze(-1)
    final_hidden_states = (expert_results * w).sum(dim=0, keepdim=True)
    return final_hidden_states.unsqueeze(0)


def sparse_moe(
    experts, router_logits, hidden_states, top_k: int, norm_topk_prob: bool = False
):
    assert (
        hidden_states.ndim == 2
    ), "hidden_states should be (-1, sequence_length) shape"

    routing_weights, hidden_states = sparse_moe_dispatcher(
        router_logits.unsqueeze(0).unsqueeze(0),
        hidden_states.unsqueeze(0).unsqueeze(0),
        top_k,
        norm_topk_prob,
    )  # returns 4-dim

    hidden_states = hidden_states.squeeze((0, 1))

    expert_results = []
    for expert in experts:
        expert_out = expert(hidden_states)
        expert_results.append(expert_out)
    expert_results = torch.stack(expert_results, dim=0)
    expert_results = expert_results.unsqueeze(0)  # to 4-dim

    # returns 4-dim
    final_hidden_states = sparse_moe_aggregator(routing_weights, expert_results)

    final_hidden_states = final_hidden_states.squeeze(0)
    return final_hidden_states


def TracibleQwen3MoeSparseMoeBlock_forward(self, hidden_states):
    batch_size, sequence_length, hidden_dim = hidden_states.shape  # (1, 18, 2048)
    hidden_states = hidden_states.view(-1, hidden_dim)  # (18,2048)
    # router_logits: (batch * sequence_length, n_experts)
    router_logits = self.gate(hidden_states)  # (18,128)
    # hidden_states, router_logits = sparse_moe_dispatcher(
    #     hidden_states, router_logits, self.norm_topk_prob, self.top_k
    # )
    # expert_results = []
    # for expert in self.experts:
    #     expert_out = expert(hidden_states)
    #     expert_results.append(expert_out)
    # expert_results = torch.stack(expert_results, dim=0)
    # final_hidden_states = sparse_moe_aggregator(expert_results, router_logits)
    final_hidden_states = sparse_moe(
        self.experts, router_logits, hidden_states, self.top_k, self.norm_topk_prob
    )
    return final_hidden_states, router_logits


class Qwen3MoePatcher(HFModelPatcher):
    def __init__(self, root: torch.nn.Module):
        super().__init__(root)
        self.text_model_rotary_emb = None

    def __enter__(self):
        if isinstance(self.root, modeling_qwen3_moe.Qwen3MoeForCausalLM):
            text_model = self.root.model
        else:
            raise NotImplementedError
        self.text_model_rotary_emb = text_model.rotary_emb
        text_model.rotary_emb = CachedQwen3MoeRotaryEmbedding(text_model.rotary_emb)
        self.text_model_forward = text_model.forward

        self.lst = [(text_model, text_model.forward)]
        text_model.forward = Qwen3MoeModel_forward.__get__(text_model, type(text_model))

        for decoder_layer in text_model.layers:
            if decoder_layer.mlp.__class__.__name__ == "Qwen3MoeSparseMoeBlock":
                self.lst.append((decoder_layer.mlp, decoder_layer.mlp.forward))
                # decoder_layer.mlp.forward = (
                #     TracibleQwen3MoeSparseMoeBlock_forward.__get__(
                #         decoder_layer.mlp, type(decoder_layer.mlp)
                #     )
                # )
                decoder_layer.mlp.forward = (
                    TracibleQwen3MoeSparseMoeBlock_forward.__get__(
                        decoder_layer.mlp, type(decoder_layer.mlp)
                    )
                )

    def __exit__(self, exc_type, exc_val, exc_tb):
        text_model = self.root.model
        text_model.rotary_emb = self.text_model_rotary_emb
        text_model.forward = self.text_model_forward.__get__(
            text_model, type(text_model)
        )
        for module, orig_forward in self.lst:
            module.forward = orig_forward.__get__(module, type(module))


_AUTOWRAP_FNS = [
    modeling_qwen3_moe.apply_rotary_pos_emb,
    sparse_moe_dispatcher,
    sparse_moe_aggregator,
]


def get_patcher_cfg():
    # fmt:off
    return HF_PATCHER_CFG(
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
            modeling_qwen3_moe.Qwen3MoeForCausalLM:(Qwen3MoePatcher, Qwen3MoeForCausalLMWrapper)
        }
    )

    # fmt:on
