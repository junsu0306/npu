import torch

from typing import Optional, Union, Tuple, List
from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HF_REMOTE_CODE_PATCHER_CFG,
)


class Qwen2ModelWrapper(torch.nn.Module):
    def __init__(self, language_model) -> None:
        super().__init__()
        self.language_model = language_model

    def forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values=None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        **flash_attn_kwargs,
    ):
        return self.language_model.forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            cache_position=cache_position,
            **flash_attn_kwargs,
        )


_AUTOWRAP_FNS = ["modeling_qwen2_kv_rev0.apply_rotary_pos_emb"]


def get_patcher_cfg():
    # fmt:off
    return HF_REMOTE_CODE_PATCHER_CFG(
        target='MobilintQwen2',
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
            "eagle.modeling_qwen2_kv_rev0.Qwen2Model": (None, Qwen2ModelWrapper)
        }
    )
    # fmt:on
