from .patcher_utils import *
from .patcher_fucntions import *

_PATCHER_MAPPER = {
    "transformers.models.llama.modeling_llama.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.llama.modeling_llama.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.gpt_neox.modeling_gpt_neox.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.mistral.modeling_mistral.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.granite.modeling_granite.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.phi.modeling_phi.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.phi3.modeling_phi3.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.qwen2.modeling_qwen2.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.qwen3.modeling_qwen3.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.qwen3_vl.modeling_qwen3_vl.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.qwen2_vl.modeling_qwen2_vl.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.gemma.modeling_gemma.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.gemma2.modeling_gemma2.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.gemma3.modeling_gemma3.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.cohere2.modeling_cohere2.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.mistral.modeling_mistral.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.cohere2.modeling_cohere2.create_causal_mask": mblt_create_causal_mask_return_none,
    "transformers.models.cohere2.modeling_cohere2.create_sliding_window_causal_mask": mblt_create_sliding_window_causal_mask_return_none,
}

VALID_PATCHER_MAPPER = validate_targets(_PATCHER_MAPPER)

__all__ = [
    "VALID_PATCHER_MAPPER",
    "TRANSFORMERS_AUTOWRAP_FNS_FUNC",
    "transformer_function_patcher",
]
