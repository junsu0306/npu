from typing import Optional, Tuple, Union, List

import torch
import transformers.models.mistral.modeling_mistral as modeling_mistral
from transformers import HybridCache

from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HFModelPatcher,
    HF_PATCHER_CFG,
)


class CachedMistralRotaryEmbedding(torch.nn.Module):
    def __init__(self, mistral_rotary_embedding):
        super().__init__()
        self.mistral_rotary_embedding = mistral_rotary_embedding

        batch_size = 1
        inv_freq = mistral_rotary_embedding.inv_freq
        inv_freq_expanded = inv_freq[None, :, None].float().expand(batch_size, -1, 1)
        position_ids = torch.arange(16384).reshape(1, -1).to(inv_freq.device)
        position_ids_expanded = position_ids[:, None, :].float()

        with torch.autocast(
            device_type=inv_freq.device.type, enabled=False
        ):  # Force float32
            freqs = (
                inv_freq_expanded.float() @ position_ids_expanded.float()
            ).transpose(1, 2)
            emb = torch.repeat_interleave(
                freqs, 2, dim=-1
            )  # diff from Llama: we interleave() instead of cat()
            cos = emb.cos() * mistral_rotary_embedding.attention_scaling
            sin = emb.sin() * mistral_rotary_embedding.attention_scaling
            self.register_buffer("cos", cos)
            self.register_buffer("sin", sin)
            print("cos_shape", self.cos.shape)
            print("sin_shape", self.sin.shape)

    @torch.no_grad()
    def forward(self, x, position_ids):
        cos = self.cos[:, position_ids.reshape(-1), :].to(dtype=x.dtype)
        sin = self.sin[:, position_ids.reshape(-1), :].to(dtype=x.dtype)
        return cos, sin


def mistral_sliding_attention_mask(
    attention_mask, effective_seq_len, last_cache_position, sliding_window
):
    # In prefill, we may be larger than sliding window
    # For FA2, the mask is 2D and is of shape [bs, processed_tokens] (not [bs, max_cache_len]),
    # thus we must slice from the right (at most `effective_seq_len` elements)
    # print(
    #     "in",
    #     type(attention_mask),
    #     effective_seq_len,
    #     last_cache_position,
    #     sliding_window,
    # )
    min_dtype = torch.finfo(attention_mask.dtype).min
    sliding_window_mask = torch.tril(
        torch.ones_like(attention_mask, dtype=torch.bool), diagonal=-sliding_window
    )
    attention_mask = torch.where(sliding_window_mask, min_dtype, attention_mask)
    # In case we are beyond the sliding window, we need to correctly offset the mask slicing
    # `last_cache_position` is equivalent to `cache_position[-1]` but without breaking dynamo
    offset = last_cache_position - effective_seq_len
    # Should only be used when beyond the sliding window (i.e. offset > 0)
    offset = max(0, offset)
    attention_mask = attention_mask[:, :, :, offset : offset + effective_seq_len]
    # print("ret", attention_mask)
    return attention_mask


def mistral_causal_attention_mask(attention_mask, sliding_window):
    return attention_mask


def MistralDecoderLayerForward(
    self,
    hidden_states: torch.Tensor,
    position_embeddings: Tuple[torch.Tensor, torch.Tensor],
    attention_mask: Optional[torch.Tensor] = None,
    past_key_value: Optional["Cache"] = None,
    output_attentions: Optional[bool] = False,
    use_cache: Optional[bool] = False,
    cache_position: Optional[torch.LongTensor] = None,
    last_cache_position: int = 0,
    **kwargs,
):
    if self.is_sliding and attention_mask is not None:  # efficient SDPA and no padding
        # In prefill, we may be larger than sliding window
        effective_seq_len = max(cache_position.shape[0], self.sliding_window)
        # For FA2, the mask is 2D and is of shape [bs, processed_tokens] (not [bs, max_cache_len]),
        # thus we must slice from the right (at most `effective_seq_len` elements)
        if self.config._attn_implementation == "flash_attention_2":
            attention_mask = attention_mask[:, -effective_seq_len:]
        # Otherwise, the mask is 4D of shape [bs, 1, query_len, max_cache_len] thus we must slice
        # from the left, with an offset if we are beyond the sliding window
        else:
            attention_mask = mistral_sliding_attention_mask(
                attention_mask,
                effective_seq_len,
                last_cache_position,
                sliding_window=self.sliding_window,
            )
    else:
        attention_mask = mistral_causal_attention_mask(
            attention_mask, self.sliding_window
        )
    residual = hidden_states

    hidden_states = self.input_layernorm(hidden_states)

    # Self Attention
    hidden_states_attention, self_attn_weights = self.self_attn(
        hidden_states=hidden_states,
        position_embeddings=position_embeddings,
        attention_mask=attention_mask,
        past_key_value=past_key_value,
        output_attentions=output_attentions,
        use_cache=use_cache,
        cache_position=cache_position,
        **kwargs,
    )

    # Fully Connected
    hidden_states_mlp = self.mlp(hidden_states)

    # Add everything together
    hidden_states = residual + hidden_states_attention + hidden_states_mlp

    outputs = (hidden_states,)

    if output_attentions:
        outputs += (self_attn_weights,)

    return outputs


class MistralPatcher(HFModelPatcher):
    def __init__(self, root: torch.nn.Module):
        super().__init__(root)

    def __enter__(self):
        if isinstance(self.root, modeling_mistral.MistralForCausalLM):
            text_model = self.root.model
        else:
            raise NotImplementedError
        self.text_model_rotary_emb = text_model.rotary_emb
        text_model.rotary_emb = CachedMistralRotaryEmbedding(text_model.rotary_emb)
        # for idx, layer in enumerate(text_model.layers):
        #     layer.forward = MistralDecoderLayerForward.__get__(layer, type(layer))

    def __exit__(self, exc_type, exc_val, exc_tb):
        text_model = self.root.model
        text_model.rotary_emb = self.text_model_rotary_emb


class MistralForCausalLMWrapper(torch.nn.Module):
    def __init__(self, language_model: modeling_mistral.MistralForCausalLM) -> None:
        super().__init__()
        self.language_model = language_model

    def forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Union[List[torch.FloatTensor]]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        logits_to_keep: Union[int, torch.Tensor] = 0,
        **kwargs,
    ):
        return self.language_model.forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            labels=labels,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            cache_position=cache_position,
            logits_to_keep=logits_to_keep,
            **kwargs,
        )


_AUTOWRAP_FNS = [
    modeling_mistral.apply_rotary_pos_emb,
    # mistral_sliding_attention_mask,
    # mistral_causal_attention_mask,
]


def get_patcher_cfg():
    # fmt:off
    return HF_PATCHER_CFG(
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
            modeling_mistral.MistralForCausalLM: (MistralPatcher, MistralForCausalLMWrapper),

        },
    )


# fmt:on
