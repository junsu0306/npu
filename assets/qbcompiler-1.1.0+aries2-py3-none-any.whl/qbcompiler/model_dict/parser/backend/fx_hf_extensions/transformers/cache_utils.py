import importlib
from typing import Callable

from torch.fx import Node
from transformers import Cache

from qbcompiler.model_dict.parser.backend.torch.fx.proxy import (
    MbltProxy,
    MbltProxyableClassMeta,
)


class HFCacheProxy(MbltProxy):
    """
    Proxy that represents an instance of `transformers.cache_utils.Cache`.
    """

    def __repr__(self):
        if hasattr(self, "node"):
            return f"HFCacheProxy({self.node.name})"
        else:
            return f"HFCacheProxy()"

    def install_orig_cache_cls(self, orig_cache_cls: type[Cache]):
        self._orig_cache_cls = orig_cache_cls

    def install_mblt_cache_cls(self, mblt_cache_cls: type[Cache]):
        self._mblt_cache_cls = mblt_cache_cls

    @property
    def __class__(self):
        # if not hasattr(self, "_orig_cache_cls"):
        #     raise RuntimeError(
        #         "The original Cache class must be installed to the HFCacheProxy."
        #     )
        # return self.tracer.hf_classes_to_patch[self._orig_cache_cls]
        if not hasattr(self, "_mblt_cache_cls"):
            return type(self)
        return self._mblt_cache_cls


def create_hf_cache_proxy_factory_fn(
    orig_cache_cls: type[Cache],
) -> Callable[[Node], HFCacheProxy]:
    def cache_proxy_factory_fn(node: Node) -> HFCacheProxy:
        # dynamic import to prevent circular import.
        lib_trace = importlib.import_module(
            "qbcompiler.model_dict.parser.backend.torch.fx._trace"
        )
        _CURRENT_TRACER = lib_trace._CURRENT_TRACER
        if not isinstance(_CURRENT_TRACER, lib_trace.MbltTracer):
            raise RuntimeError(
                "Cannot create HFCacheProxy because there is no MbltTracer currently tracing."
            )
        cache_proxy = HFCacheProxy(node, _CURRENT_TRACER)
        cache_proxy.install_orig_cache_cls(orig_cache_cls)
        cache_proxy.install_mblt_cache_cls(HF_CACHE_CLASSES_TO_PATCH[orig_cache_cls])
        return cache_proxy

    return cache_proxy_factory_fn


def _maybe_register_cache_class(
    class_name: str,
) -> tuple[type[Cache], type[Cache]] | None:
    transformers_module = importlib.import_module("transformers")
    cache_cls = getattr(transformers_module, class_name, None)
    if cache_cls is None:
        return None

    proxyable_cache_cls = MbltProxyableClassMeta(
        f"HFProxyable{class_name}",
        (cache_cls,),
        {},
        proxy_factory_fn=create_hf_cache_proxy_factory_fn(cache_cls),
    )
    return cache_cls, proxyable_cache_cls


HF_CACHE_CLASSES_TO_PATCH: dict[type[Cache], type[Cache]] = {}

for _cache_class_name in (
    "HybridCache",
    "DynamicCache",
    "EncoderDecoderCache",
):
    _registered = _maybe_register_cache_class(_cache_class_name)
    if _registered is not None:
        _orig_cache_cls, _proxyable_cache_cls = _registered
        HF_CACHE_CLASSES_TO_PATCH[_orig_cache_cls] = _proxyable_cache_cls
