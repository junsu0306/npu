from typing import Optional, Union, Tuple, List, Dict

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from qbcompiler.model_dict.parser.backend.torch.fx.proxy import MbltProxy
from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HF_REMOTE_CODE_PATCHER_CFG,
    HFModelPatcher
)

def _make_causal_mask(
        input_ids_shape: torch.Size, dtype: torch.dtype, device: torch.device, past_key_values_length: int = 0
):
    """
    Make causal mask used for bi-directional self-attention.
    """
    bsz, tgt_len = input_ids_shape
    mask = torch.full((tgt_len, tgt_len), torch.tensor(torch.finfo(dtype).min, device=device), device=device)
    mask_cond = torch.arange(mask.size(-1), device=device)
    mask.masked_fill_(mask_cond < (mask_cond + 1).view(mask.size(-1), 1), 0)
    mask = mask.to(dtype)

    if past_key_values_length > 0:
        mask = torch.cat([torch.zeros(tgt_len, past_key_values_length, dtype=dtype, device=device), mask], dim=-1)
    return mask[None, None, :, :].expand(bsz, 1, tgt_len, tgt_len + past_key_values_length)


# Copied from transformers.models.bart.modeling_bart._expand_mask
def _expand_mask(mask: torch.Tensor, dtype: torch.dtype, tgt_len: Optional[int] = None):
    """
    Expands attention_mask from `[bsz, seq_len]` to `[bsz, 1, tgt_seq_len, src_seq_len]`.
    """
    bsz, src_len = mask.size()
    tgt_len = tgt_len if tgt_len is not None else src_len

    expanded_mask = mask[:, None, None, :].expand(bsz, 1, tgt_len, src_len).to(dtype)

    inverted_mask = 1.0 - expanded_mask

    return inverted_mask.masked_fill(inverted_mask.to(torch.bool), torch.finfo(dtype).min)


def _prepare_decoder_attention_mask(attention_mask, input_shape, inputs_embeds, past_key_values_length):
    # create causal mask
    # [bsz, seq_len] -> [bsz, 1, tgt_seq_len, src_seq_len]
    combined_attention_mask = None
    if input_shape[-1] > 1:
        combined_attention_mask = _make_causal_mask(
            input_shape,
            inputs_embeds.dtype,
            device=inputs_embeds.device,
            past_key_values_length=past_key_values_length,
        )

    if attention_mask is not None:
        # [bsz, seq_len] -> [bsz, 1, tgt_seq_len, src_seq_len]
        expanded_attn_mask = _expand_mask(attention_mask, inputs_embeds.dtype, tgt_len=input_shape[-1]).to(
            inputs_embeds.device
        )
        combined_attention_mask = (
            expanded_attn_mask if combined_attention_mask is None else expanded_attn_mask + combined_attention_mask
        )

    return combined_attention_mask

# Copied from transformers.model.llama.modeling_llama.rotate_half
def rotate_half(x):
    """Rotates half the hidden dims of the input."""
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2:]
    return torch.cat((-x2, x1), dim=-1)

# Copied from transformers.model.llama.modeling_llama.apply_rotary_pos_emb; float 
def apply_rotary_pos_emb(q, k, cos, sin, position_ids, unsqueeze_dim=1):
    """Applies Rotary Position Embedding to the query and key tensors."""
    q_dtype, k_dtype = q.dtype, k.dtype
    q, k = q.float(), k.float()
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed.to(dtype=q_dtype), k_embed.to(dtype=k_dtype)

def repeat_kv(hidden_states: torch.Tensor, n_rep: int) -> torch.Tensor:
    """
    This is the equivalent of torch.repeat_interleave(x, dim=1, repeats=n_rep). The hidden states go from (batch,
    num_key_value_heads, seqlen, head_dim) to (batch, num_attention_heads, seqlen, head_dim)
    """
    batch, num_key_value_heads, slen, head_dim = hidden_states.shape
    if n_rep == 1:
        return hidden_states
    hidden_states = hidden_states[:, :, None, :, :].expand(batch, num_key_value_heads, n_rep, slen, head_dim)
    return hidden_states.reshape(batch, num_key_value_heads * n_rep, slen, head_dim)


def InternLM2AttentionForward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value: Optional[Tuple[torch.Tensor]] = None,
        output_attentions: bool = False,
        use_cache: bool = False,
        **kwargs,
) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
    bsz, q_len, _ = hidden_states.size()

    qkv_states = self.wqkv(hidden_states)
    h_num = (self.num_heads + 2 * self.num_key_value_heads) // (2 + self.num_key_value_groups)
    gs=2 + self.num_key_value_groups
    qkv_states = qkv_states.view(bsz, q_len, h_num, gs, self.head_dim)

    query_states = qkv_states[..., : self.num_key_value_groups, :]
    query_states = query_states.reshape(bsz, q_len, -1, self.head_dim)
    key_states = qkv_states[..., -2, :]
    value_states = qkv_states[..., -1, :]

    query_states = query_states.transpose(1, 2)
    key_states = key_states.transpose(1, 2)
    value_states = value_states.transpose(1, 2)

    kv_seq_len = key_states.shape[-2]
    if past_key_value is not None:
        kv_seq_len += past_key_value[0].shape[-2]
    cos, sin = self.rotary_emb(value_states, position_ids)
    query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin, position_ids)

    if past_key_value is not None:
        # reuse k, v, self_attention
        key_states = torch.cat([past_key_value[0], key_states], dim=2)
        value_states = torch.cat([past_key_value[1], value_states], dim=2)

    past_key_value = (key_states, value_states) if use_cache else None

    key_states = repeat_kv(key_states, self.num_key_value_groups)
    value_states = repeat_kv(value_states, self.num_key_value_groups)

    attn_weights = torch.matmul(query_states, key_states.transpose(2, 3)) / math.sqrt(self.head_dim)

    if attn_weights.size() != (bsz, self.num_heads, q_len, kv_seq_len):
        raise ValueError(
            f'Attention weights should be of size {(bsz, self.num_heads, q_len, kv_seq_len)}, but is'
            f' {attn_weights.size()}'
        )

    if attention_mask is not None:
        if attention_mask.size() != (bsz, 1, q_len, kv_seq_len):
            raise ValueError(
                f'Attention mask should be of size {(bsz, 1, q_len, kv_seq_len)}, but is {attention_mask.size()}'
            )
        attn_weights = attn_weights + attention_mask

    # upcast attention to fp32
    attn_weights = nn.functional.softmax(attn_weights, dim=-1, dtype=torch.float32).to(query_states.dtype)
    attn_output = torch.matmul(attn_weights, value_states)

    if attn_output.size() != (bsz, self.num_heads, q_len, self.head_dim):
        raise ValueError(
            f'`attn_output` should be of size {(bsz, self.num_heads, q_len, self.head_dim)}, but is'
            f' {attn_output.size()}'
        )

    attn_output = attn_output.transpose(1, 2).contiguous()
    attn_output = attn_output.reshape(bsz, q_len, self.hidden_size)

    attn_output = self.wo(attn_output)

    if not output_attentions:
        attn_weights = None

    return attn_output, attn_weights, past_key_value

class CachedInternVLRotaryEmbedding(torch.nn.Module):
    def __init__(self, rotary_embedding):
        super().__init__()
        self.batch_size = 1
        self.rope_cache_len = 16384
        self.max_position_embeddings = rotary_embedding.max_position_embeddings
        def get_cached_emb(base):
            inv_freq = 1.0 / (base ** (torch.arange(0, rotary_embedding.dim, 2, dtype=torch.float32) / rotary_embedding.dim))
            inv_freq_expanded = (
                inv_freq[None, :, None].float().expand(self.batch_size, -1, 1)
            )
            position_ids = (
                torch.arange(self.rope_cache_len).reshape(1, -1).to(inv_freq.device)
            )
            position_ids_expanded = position_ids[:, None, :].float()
            with torch.autocast(
                device_type=inv_freq.device.type,
                enabled=False,
            ):  # Force float32
                freqs = (
                    inv_freq_expanded.float() @ position_ids_expanded.float()
                ).transpose(1, 2)
                emb = torch.cat((freqs, freqs), dim=-1)
                cos = emb.cos()
                sin = emb.sin()
                return cos, sin
        
        base = rotary_embedding.base
        cos, sin = get_cached_emb(base)
        self.register_buffer("cos", cos)
        self.register_buffer("sin", sin)

        if str(type(rotary_embedding)) == "InternLM2DynamicNTKScalingRotaryEmbedding":
            base = self.base * (
                    (self.scaling_factor * self.rope_cache_len / rotary_embedding.max_position_embeddings) - (rotary_embedding.scaling_factor - 1)
            ) ** (self.dim / (self.dim - 2))
            cos, sin = get_cached_emb(base)
            self.register_buffer("cos_ntk", cos)
            self.register_buffer("sin_ntk", sin)

    @torch.no_grad()
    def forward(self, x, position_ids):
        if len(position_ids) > self.max_position_embeddings:
            cos = self.cos_ntk[:, position_ids.reshape(-1), :].to(dtype=x.dtype)
            sin = self.sin_ntk[:, position_ids.reshape(-1), :].to(dtype=x.dtype)
        else:
            cos = self.cos[:, position_ids.reshape(-1), :].to(dtype=x.dtype)
            sin = self.sin[:, position_ids.reshape(-1), :].to(dtype=x.dtype)
        return cos, sin


class InternLM2Patcher(HFModelPatcher):
    def __init__(self, root: torch.nn.Module):
        super().__init__(root)
        self.text_model_rotary_emb = {}

    def __enter__(self):
        text_model = self.root.model
        text_model._prepare_decoder_attention_mask = _prepare_decoder_attention_mask
        self.layers = text_model.layers
        for i, layer in enumerate(self.layers):
            self.text_model_rotary_emb[i] = layer.attention.rotary_emb
            layer.attention.forward = InternLM2AttentionForward.__get__(layer.attention, type(layer.attention))
            layer.attention.rotary_emb = CachedInternVLRotaryEmbedding(layer.attention.rotary_emb)

    def __exit__(self, exc_type, exc_val, exc_tb):
        text_model = self.root.model
        self.layers = text_model.layers
        for i, layer in enumerate(self.layers):
            layer.attention.rotary_emb = self.text_model_rotary_emb[i]

class InternLM2ForCausalLMWrapper(torch.nn.Module):
    def __init__(self, language_model) -> None:
        super().__init__()
        self.language_model = language_model

    def forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[List[torch.FloatTensor]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        **kwargs
    ):
        return self.language_model.forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            labels=labels,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            **kwargs,
        )

_AUTOWRAP_FNS = [
    apply_rotary_pos_emb,
    # _make_causal_mask,
    # _expand_mask,
]

def get_patcher_cfg():
    # fmt:off
    return HF_REMOTE_CODE_PATCHER_CFG(
        target='InternLM2ForCausalLM',
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
            "modeling_internlm2.InternLM2ForCausalLM": (InternLM2Patcher, InternLM2ForCausalLMWrapper),
        },
    )
    # fmt:on
