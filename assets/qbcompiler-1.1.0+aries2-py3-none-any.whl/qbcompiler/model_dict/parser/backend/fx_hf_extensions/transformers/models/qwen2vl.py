import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple
from transformers.models.qwen2_vl import modeling_qwen2_vl
from transformers.models.qwen2_vl.modeling_qwen2_vl import (
    Qwen2VLForConditionalGeneration,
    Qwen2VLCausalLMOutputWithPast,
    Qwen2VLModelOutputWithPast,
)
from transformers.processing_utils import Unpack
from transformers import Cache
from transformers.utils import TransformersKwargs
from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HF_PATCHER_CFG,
)
from einops import rearrange

##############################  Vision Modules  #################################
""" 
PatchedVisionPatchEmbed: Convert 3d patch_embed into 2d patch_embed 

PatchedVisionSdpaAttention: Split single qkv projection, 
                            Remove attention mask generation by cu_seqlens, 
                            Change self.apply_rotary_pos_emb_vision into custom apply_rotary_pos_emb_vision  

PatchedQwen2VLVisionBlock: apply PatchedVisionSdpaAttention
VisionModelForQwen2VL: apply above patch
"""


class PatchedVisionPatchEmbed(nn.Module):
    def __init__(self, patch_embed) -> None:
        super().__init__()
        proj_3d = patch_embed.proj
        assert proj_3d.kernel_size == proj_3d.stride
        self.patch_size = patch_embed.patch_size
        self.temporal_patch_size = patch_embed.temporal_patch_size
        self.in_channels = patch_embed.in_channels
        self.embed_dim = patch_embed.embed_dim

        weight_3d = proj_3d.weight
        self.proj = nn.Conv2d(
            in_channels=weight_3d.size(1) * weight_3d.size(2),
            out_channels=weight_3d.size(0),
            kernel_size=(weight_3d.size(3), weight_3d.size(4)),
            stride=(weight_3d.size(3), weight_3d.size(4)),
            bias=False,
        )
        self.proj.weight.data = proj_3d.weight.data.transpose(1, 2).reshape(
            (
                weight_3d.size(0),
                weight_3d.size(1) * weight_3d.size(2),
                weight_3d.size(3),
                weight_3d.size(4),
            )
        )  # (Cout, T * Cin, H, W)

        self.merge_size = 2

    # def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        bsz = hidden_states.shape[0]
        target_dtype = self.proj.weight.dtype
        hidden_states = self.proj(
            hidden_states.to(dtype=target_dtype)
        )  # (gt=1, Cout, gh * Mh, gw * Mw) -> (1, gt * gh * gw * Mh * Mw, Cout) // (gt gh gw Mh Mw)

        gt, cout, ghmh, gwmw = hidden_states.shape
        hidden_states = hidden_states.permute(0, 2, 3, 1)
        hidden_states = hidden_states.reshape((bsz, -1, self.embed_dim))

        return hidden_states


class PatchedVisionSdpaAttention(nn.Module):
    def __init__(self, vision_attention) -> None:
        super().__init__()
        self.vision_attention = vision_attention

        Cout, Cin = self.vision_attention.qkv.weight.shape
        self.vision_attention.q = nn.Linear(Cin, Cout // 3, bias=True)
        self.vision_attention.k = nn.Linear(Cin, Cout // 3, bias=True)
        self.vision_attention.v = nn.Linear(Cin, Cout // 3, bias=True)

        weight_q, weight_k, weight_v = self.vision_attention.qkv.weight.data.reshape(
            3, Cout // 3, Cin
        ).unbind(0)
        bias_q, bias_k, bias_v = self.vision_attention.qkv.bias.data.reshape(
            3, Cout // 3
        ).unbind(0)

        self.vision_attention.q.weight.data = weight_q
        self.vision_attention.k.weight.data = weight_k
        self.vision_attention.v.weight.data = weight_v
        self.vision_attention.q.bias.data = bias_q
        self.vision_attention.k.bias.data = bias_k
        self.vision_attention.v.bias.data = bias_v
        del self.vision_attention.qkv

    def forward(
        self,
        hidden_states: torch.Tensor,
        cu_seqlens: torch.Tensor,
        rotary_pos_emb: Optional[torch.Tensor] = None,
        position_embeddings: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ) -> torch.Tensor:
        bsz = hidden_states.shape[0]
        seq_length = hidden_states.shape[1]
        q = (
            self.vision_attention.q(hidden_states)
            .reshape(bsz, seq_length, self.vision_attention.num_heads, -1)
            .transpose(1, 2)
        )
        k = (
            self.vision_attention.k(hidden_states)
            .reshape(bsz, seq_length, self.vision_attention.num_heads, -1)
            .transpose(1, 2)
        )
        v = (
            self.vision_attention.v(hidden_states)
            .reshape(bsz, seq_length, self.vision_attention.num_heads, -1)
            .transpose(1, 2)
        )
        cos, sin = position_embeddings

        orig_q_dtype = q.dtype
        orig_k_dtype = k.dtype
        q, k = apply_rotary_pos_emb_vision(q.float(), k.float(), cos, sin)
        q = q.to(orig_q_dtype)
        k = k.to(orig_k_dtype)

        attn_output = F.scaled_dot_product_attention(q, k, v, dropout_p=0.0)
        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.reshape(bsz, seq_length, -1)
        attn_output = self.vision_attention.proj(attn_output)
        return attn_output


class PatchedQwen2VLVisionBlock(nn.Module):
    def __init__(self, vision_block) -> None:
        super().__init__()
        self.vision_block = vision_block
        self.vision_block.attn = PatchedVisionSdpaAttention(self.vision_block.attn)

    def forward(
        self,
        hidden_states: torch.Tensor,
        cu_seqlens: torch.Tensor = None,
        rotary_pos_emb: Optional[torch.Tensor] = None,
        position_embeddings: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ) -> torch.Tensor:
        return self.vision_block(
            hidden_states, cu_seqlens, rotary_pos_emb, position_embeddings
        )


class PatchedPatchMerger(nn.Module):
    def __init__(self, patch_merger) -> None:
        super().__init__()
        self.hidden_size = patch_merger.hidden_size
        self.ln_q = patch_merger.ln_q

        self.ratio = 4
        # self.mlp = nn.Sequential(
        #     nn.Conv2d(self.hidden_size // self.ratio, self.hidden_size, kernel_size=(1, self.ratio), stride=(1, self.ratio)),
        #     nn.GELU(),
        #     nn.Linear(self.hidden_size, self.hidden_size)
        # )

        self.fc1 = nn.Conv2d(
            self.hidden_size // self.ratio,
            self.hidden_size,
            kernel_size=(1, self.ratio),
            stride=(1, self.ratio),
        )
        self.fc1.weight.data = rearrange(
            patch_merger.mlp[0].weight.data,
            "out (ratio in) -> out in 1 ratio",
            ratio=self.ratio,
        )  # out, in
        self.fc1.bias.data = patch_merger.mlp[0].bias.data

        self.act = nn.GELU()
        self.fc2 = patch_merger.mlp[2]

        # self.hidden_size = context_dim * (spatial_merge_size**2)
        # self.ln_q = LayerNorm(context_dim, eps=1e-6)
        # self.mlp = nn.Sequential(
        #     nn.Linear(self.hidden_size, self.hidden_size),
        #
        #     nn.GELU(),
        #     nn.Linear(self.hidden_size, dim),
        # )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.ln_q(x)  # b, n, c
        x = x.unsqueeze(1).permute(0, 3, 1, 2)
        x = self.fc1(x)
        x = self.act(x)
        x = x[:, :, 0].permute(0, 2, 1)
        x = self.fc2(x)[0]
        return x


class VisionModelForQwen2VL(torch.nn.Module):
    def __init__(self, model) -> None:
        super().__init__()
        self.model = model.visual
        self.model.patch_embed = PatchedVisionPatchEmbed(self.model.patch_embed)
        for block_idx, block in enumerate(self.model.blocks):
            self.model.blocks[block_idx] = PatchedQwen2VLVisionBlock(block)
        self.model.merger = PatchedPatchMerger(self.model.merger)

    def set_grid_thw(self, grid_thw):
        rotary_pos_emb = self.model.rot_pos_emb(grid_thw)
        rotary_pos_emb = rotary_pos_emb[None, None]
        emb = torch.cat((rotary_pos_emb, rotary_pos_emb), dim=-1)
        cos = emb.cos()
        sin = emb.sin()
        self.register_buffer("cos", cos)
        self.register_buffer("sin", sin)

    def forward(self, images: torch.Tensor) -> torch.Tensor:
        hidden_states = self.model.patch_embed(images)

        position_embeddings = (self.cos, self.sin)
        cu_seqlens = None

        for blk in self.model.blocks:
            hidden_states = blk(
                hidden_states,
                cu_seqlens=cu_seqlens,
                position_embeddings=position_embeddings,
            )
        # merger
        hidden_states = self.model.merger(hidden_states)
        # hidden_states = self.model.merger.ln_q(hidden_states)
        # hidden_states = hidden_states.view(1, 1, -1, self.model.merger.hidden_size)
        # hidden_states = self.model.merger.mlp(hidden_states)
        return hidden_states


class Qwen2VLModel_get_image_feature(torch.nn.Module):
    def __init__(self, qwen2vl_model) -> None:
        super().__init__()
        self.visual = qwen2vl_model.visual

    def forward(
        self,
        pixel_values: torch.FloatTensor,
        image_grid_thw: Optional[torch.LongTensor] = None,
    ):
        pixel_values = pixel_values.type(self.visual.dtype)
        image_embeds = self.visual(pixel_values, grid_thw=image_grid_thw)
        split_sizes = image_grid_thw.prod(-1) // self.visual.spatial_merge_size**2
        split_sizes = split_sizes.unbind(0)
        split_sizes = [int(s) for s in split_sizes]
        image_embeds = torch.split(image_embeds, split_sizes)
        return image_embeds


############################## Language Modules #################################
"""
CachedQwen2VLTextRotaryEmbedding: Rotary embedding for qwen2vl language decoder 
PatchedQwen2VLSdpaAttention: apply slicing for last layer
PatchedQwen2VLDecoderLayer: apply slicing for last layer
"""


class CachedQwen2VLTextRotaryEmbedding(torch.nn.Module):
    def __init__(self, qwen2_vl_rotary_emb: modeling_qwen2_vl.Qwen2VLRotaryEmbedding):
        super().__init__()
        self.batch_size = 1
        self.rope_cache_len = 16384
        self.model = qwen2_vl_rotary_emb

    def set_rope(self, position_ids):
        if position_ids.shape[0] == 4:
            position_ids = position_ids[1:]

        batch_size = self.batch_size
        rope_cache_len = self.rope_cache_len
        rotary_emb = self.model
        # extend position_ids upto maximum rope cache len
        position_index = position_ids[0, 0, -1].item()
        occupied = position_ids.size(-1)
        extended_position_ids = torch.arange(position_index + 1, rope_cache_len)
        extended_position_ids = extended_position_ids[None, None].repeat(3, 1, 1)
        position_ids = torch.cat((position_ids, extended_position_ids), dim=-1)
        position_ids = position_ids[..., :rope_cache_len]

        # make cos, sin
        inv_freq_expanded = (
            rotary_emb.inv_freq[None, None, :, None]
            .float()
            .expand(3, position_ids.shape[1], -1, 1)
        )
        position_ids_expanded = (
            position_ids[:, :, None, :].float().to(inv_freq_expanded.device)
        )  # shape (3, bs, 1, positions)

        freqs = (inv_freq_expanded.float() @ position_ids_expanded.float()).transpose(
            2, 3
        )
        emb = torch.cat((freqs, freqs), dim=-1)
        cos = emb.cos() * rotary_emb.attention_scaling
        sin = emb.sin() * rotary_emb.attention_scaling

        mrope_section = self.model.config.rope_scaling["mrope_section"]
        mrope_section = mrope_section * 2

        cos = torch.cat(
            [m[i % 3] for i, m in enumerate(cos.split(mrope_section, dim=-1))], dim=-1
        )
        sin = torch.cat(
            [m[i % 3] for i, m in enumerate(sin.split(mrope_section, dim=-1))], dim=-1
        )
        self.register_buffer("cos", cos)
        self.register_buffer("sin", sin)

    @torch.no_grad()
    def forward(self, x, position_ids):
        # todo: flatten position ids
        position_ids = torch.arange(position_ids.shape[-1])
        cos = self.cos[..., position_ids, :].to(dtype=x.dtype)
        sin = self.sin[..., position_ids, :].to(dtype=x.dtype)
        return cos, sin


class PatchedQwen2VLSdpaAttention(nn.Module):
    def __init__(self, qwen2vl_sdpa_attention, slice_last_query=False):
        super().__init__()
        self.qwen2vl_sdpa_attention = qwen2vl_sdpa_attention
        self.slice_last_query = slice_last_query

    # Adapted from Qwen2Attention.forward
    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Cache] = None,
        output_attentions: bool = False,
        use_cache: bool = False,
        cache_position: Optional[torch.LongTensor] = None,
        position_embeddings: Optional[
            Tuple[torch.Tensor, torch.Tensor]
        ] = None,  # necessary, but kept here for BC
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
        bsz, q_len, _ = hidden_states.size()

        query_states = self.qwen2vl_sdpa_attention.q_proj(hidden_states)
        key_states = self.qwen2vl_sdpa_attention.k_proj(hidden_states)
        value_states = self.qwen2vl_sdpa_attention.v_proj(hidden_states)

        query_states = query_states.view(
            bsz, q_len, -1, self.qwen2vl_sdpa_attention.head_dim
        ).transpose(1, 2)
        key_states = key_states.view(
            bsz, q_len, -1, self.qwen2vl_sdpa_attention.head_dim
        ).transpose(1, 2)
        value_states = value_states.view(
            bsz, q_len, -1, self.qwen2vl_sdpa_attention.head_dim
        ).transpose(1, 2)

        cos, sin = position_embeddings
        query_states, key_states = apply_rotary_pos_emb(
            query_states, key_states, cos, sin
        )

        if self.slice_last_query:
            query_states = query_states[:, :, -1:, :]
            q_len = 1

        if past_key_values is not None:
            cache_kwargs = {
                "sin": sin,
                "cos": cos,
                "cache_position": cache_position,
            }  # Specific to RoPE models
            key_states, value_states = past_key_values.update(
                key_states,
                value_states,
                self.qwen2vl_sdpa_attention.layer_idx,
                cache_kwargs,
            )

        key_states = modeling_qwen2_vl.repeat_kv(
            key_states, self.qwen2vl_sdpa_attention.num_key_value_groups
        )
        value_states = modeling_qwen2_vl.repeat_kv(
            value_states, self.qwen2vl_sdpa_attention.num_key_value_groups
        )

        causal_mask = attention_mask
        if attention_mask is not None:  # no matter the length, we just slice it
            causal_mask = attention_mask[:, :, :, : key_states.shape[-2]]

        # SDPA with memory-efficient backend is currently (torch==2.1.2) bugged with non-contiguous inputs with custom attn_mask,
        # Reference: https://github.com/pytorch/pytorch/issues/112577.
        if query_states.device.type == "cuda" and attention_mask is not None:
            query_states = query_states.contiguous()
            key_states = key_states.contiguous()
            value_states = value_states.contiguous()

        # We dispatch to SDPA's Flash Attention or Efficient kernels via this `is_causal` if statement instead of an inline conditional assignment
        # in SDPA to support both torch.compile's dynamic shapes and full graph options. An inline conditional prevents dynamic shapes from compiling.
        # The q_len > 1 is necessary to match with AttentionMaskConverter.to_causal_4d that does not create a causal mask in case q_len == 1.
        is_causal = True if causal_mask is None and q_len > 1 else False

        attn_output = torch.nn.functional.scaled_dot_product_attention(
            query_states,
            key_states,
            value_states,
            attn_mask=causal_mask,
            dropout_p=self.qwen2vl_sdpa_attention.attention_dropout
            if self.qwen2vl_sdpa_attention.training
            else 0.0,
            is_causal=is_causal,
        )

        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.view(
            bsz, q_len, self.qwen2vl_sdpa_attention.hidden_size
        )

        attn_output = self.qwen2vl_sdpa_attention.o_proj(attn_output)

        return attn_output, None


class Projection(torch.nn.Module):
    def __init__(self, language_model, lm_head):
        super().__init__()
        self.language_model = language_model
        for layer in self.language_model.layers:
            layer.self_attn = PatchedQwen2VLSdpaAttention(layer.self_attn)
        self.lm_head = lm_head

    def forward(
        self,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Cache] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        rope_deltas: Optional[torch.LongTensor] = None,
        **kwargs: Unpack[TransformersKwargs],
    ):
        outputs = self.language_model(
            input_ids=None,
            position_ids=position_ids,
            attention_mask=attention_mask,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=True,
            cache_position=cache_position,
            **kwargs,
        )

        outputs = Qwen2VLModelOutputWithPast(
            last_hidden_state=outputs.last_hidden_state,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
            rope_deltas=rope_deltas,
        )

        # output = output if return_dict else output.to_tuple()

        hidden_states = outputs[0]
        logits = self.lm_head(hidden_states)

        return Qwen2VLCausalLMOutputWithPast(
            loss=None,
            logits=logits,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
            rope_deltas=outputs.rope_deltas,
        )


class Qwen2VLForConditionalGenerationWrapper(Qwen2VLForConditionalGeneration):
    def forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Cache] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        pixel_values: Optional[torch.Tensor] = None,
        pixel_values_videos: Optional[torch.FloatTensor] = None,
        image_grid_thw: Optional[torch.LongTensor] = None,
        video_grid_thw: Optional[torch.LongTensor] = None,
        rope_deltas: Optional[torch.LongTensor] = None,
        cache_position: Optional[torch.LongTensor] = None,
        **kwargs: Unpack[TransformersKwargs],
    ):
        qwen2vl_model = self.model

        output_attentions = (
            output_attentions
            if output_attentions is not None
            else qwen2vl_model.config.output_attentions
        )
        output_hidden_states = (
            output_hidden_states
            if output_hidden_states is not None
            else qwen2vl_model.config.output_hidden_states
        )
        return_dict = True

        if inputs_embeds is None:
            inputs_embeds = qwen2vl_model.get_input_embeddings()(input_ids)

        if pixel_values is not None:
            image_embeds = qwen2vl_model.get_image_features(
                pixel_values, image_grid_thw
            )
            image_embeds = torch.cat(image_embeds, dim=0).to(
                inputs_embeds.device, inputs_embeds.dtype
            )
            image_mask, _ = qwen2vl_model.get_placeholder_mask(
                input_ids, inputs_embeds=inputs_embeds, image_features=image_embeds
            )
            inputs_embeds = inputs_embeds.masked_scatter(image_mask, image_embeds)

        if pixel_values_videos is not None:
            video_embeds = qwen2vl_model.get_video_features(
                pixel_values_videos, video_grid_thw
            )
            video_embeds = torch.cat(video_embeds, dim=0).to(
                inputs_embeds.device, inputs_embeds.dtype
            )
            _, video_mask = qwen2vl_model.get_placeholder_mask(
                input_ids, inputs_embeds=inputs_embeds, video_features=video_embeds
            )
            inputs_embeds = inputs_embeds.masked_scatter(video_mask, video_embeds)

        if position_ids is None:
            if (
                qwen2vl_model.rope_deltas is None
                or cache_position is None
                or cache_position[0] == 0
            ):
                position_ids, rope_deltas = qwen2vl_model.get_rope_index(
                    input_ids, image_grid_thw, video_grid_thw, attention_mask
                )
                qwen2vl_model.rope_deltas = rope_deltas
            # then use the prev pre-calculated rope-deltas to get the correct position ids
            else:
                batch_size, seq_length, _ = inputs_embeds.shape
                position_ids = torch.arange(seq_length, device=inputs_embeds.device)
                position_ids = position_ids.view(1, 1, -1).expand(3, batch_size, -1)
                if cache_position is not None:
                    delta = (cache_position[0] + qwen2vl_model.rope_deltas).to(
                        inputs_embeds.device
                    )
                else:
                    delta = torch.zeros(
                        (batch_size, seq_length), device=inputs_embeds.device
                    )
                delta = delta.repeat_interleave(batch_size // delta.shape[0], dim=0)
                position_ids = position_ids + delta.to(position_ids.device)

        kwargs.pop("return_dict", None)
        return self.projection(
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            cache_position=cache_position,
            rope_deltas=qwen2vl_model.rope_deltas,
            **kwargs,
        )


##############################      Utils       #################################
# Copied from transformers.models.llama.modeling_llama.rotate_half
def rotate_half(x):
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2 :]
    return torch.cat((-x2, x1), dim=-1)


def apply_rotary_pos_emb(q, k, cos, sin, position_ids=None, unsqueeze_dim=1):
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


def apply_rotary_pos_emb_vision(q, k, cos, sin):
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


def repreprocess_pixel_values(pixel_values, grid_thw):
    """Reshape hf-preprocessed pixel values to npu format given grid_thw (gt, gh, gw)"""

    gt, gh, gw = grid_thw
    # fix me: some parameters is hard-coded
    c = 3
    pt = 2
    Mh = Mw = 2  # merge size
    ph = pw = int((pixel_values.shape[-1] // (pt * c)) ** 0.5)

    images = rearrange(
        pixel_values,
        "(gt gh gw Mh Mw) (c pt ph pw) -> gt (pt c) (gh gw ph) (Mh Mw pw)",
        gt=gt,
        gh=gh // Mh,
        gw=gw // Mw,
        Mh=Mh,
        Mw=Mw,
        c=c,
        pt=pt,
        ph=ph,
        pw=pw,
    )
    return images


def Qwen2VL_get_image_features(
    self,
    pixel_values: torch.FloatTensor,
    image_grid_thw: Optional[torch.LongTensor] = None,
):
    return self.get_image_feature_class(
        pixel_values=pixel_values, image_grid_thw=image_grid_thw
    )


_AUTOWRAP_FNS = [apply_rotary_pos_emb, apply_rotary_pos_emb_vision]


def get_patcher_cfg():
    # fmt:off
    return HF_PATCHER_CFG(
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
        },
    )
    # fmt:on
