from typing import Optional, Union, Tuple, List, Dict

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from qbcompiler.model_dict.parser.backend.torch.fx.proxy import MbltProxy
from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HF_REMOTE_CODE_PATCHER_CFG,
    HFModelPatcher
)

class InternVLVisionModelWrapper(torch.nn.Module):
    def __init__(self, vision_model) -> None:
        super().__init__()
        self.vision_model = vision_model

    def forward(
        self,
        pixel_values=None,
    ):
        return self.vision_model.extract_feature(
            pixel_values=pixel_values,
        )

_AUTOWRAP_FNS = [
]

def get_patcher_cfg():
    # fmt:off
    return HF_REMOTE_CODE_PATCHER_CFG(
        target='InternVLChatModel',
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
            "modeling_internvl_chat.InternVLChatModel": (None, InternVLVisionModelWrapper),
        },
    )
    # fmt:on
