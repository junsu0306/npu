import torch

from typing import Optional, Union, Tuple, List
from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HF_REMOTE_CODE_PATCHER_CFG,
)
from transformers import Cache


class DraftModelWrapper(torch.nn.Module):
    def __init__(self, language_model) -> None:
        super().__init__()
        self.language_model = language_model

    def forward(
        self,
        input_emb: torch.Tensor,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value: Optional[Cache] = None,
        output_attentions: Optional[bool] = None,
        use_cache: Optional[bool] = None,
        requires_all_features: Optional[bool] = None,
        **kwargs
    ):
        return self.language_model.forward(
            input_emb=input_emb,
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_value=past_key_value,
            output_attentions=output_attentions,
            use_cache=use_cache,
            requires_all_features=requires_all_features,
            **kwargs
        )


_AUTOWRAP_FNS = ["cnets_rev0.apply_rotary_pos_emb"]


def get_patcher_cfg():
    # fmt:off
    return HF_REMOTE_CODE_PATCHER_CFG(
        target='DraftModel',
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
            "eagle.model.cnets_rev0.DraftModel":(None, DraftModelWrapper)
        }
    )
    # fmt:on
