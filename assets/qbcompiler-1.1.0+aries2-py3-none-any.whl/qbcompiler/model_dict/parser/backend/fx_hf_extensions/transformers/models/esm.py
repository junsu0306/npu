from typing import Optional, Union, Tuple, List

import torch
import transformers.models.esm.modeling_esm as modeling_esm
from transformers import HybridCache, Cache

from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HFModelPatcher,
    HF_PATCHER_CFG,
)

def rotate_half(x):
    x1, x2 = x.chunk(2, dim=-1)
    return torch.cat((-x2, x1), dim=-1)


def apply_rotary_pos_emb(x, cos, sin):
    return (x * cos) + (rotate_half(x) * sin)

class CachedEsmRotaryEmbedding(torch.nn.Module):
    def __init__(self, rotary_embedding: modeling_esm.RotaryEmbedding):
        super().__init__()
        self.batch_size = 1
        self.rope_cache_len = 16384

        inv_freq = rotary_embedding.inv_freq
        t = (
            torch.arange(self.rope_cache_len).to(inv_freq.device)
        )
        with torch.autocast(
            device_type=inv_freq.device.type, enabled=False
        ): 
            freqs = torch.outer(t, inv_freq)
            emb = torch.cat((freqs, freqs), dim=-1)
            cos = emb.cos()[None, None, :, :]
            sin = emb.sin()[None, None, :, :]
            self.register_buffer("cos", cos)
            self.register_buffer("sin", sin)

    @torch.no_grad()
    def forward(self, q, k):
        seq_len = q.shape[-2]
        cos = self.cos[..., :seq_len, :].to(dtype=q.dtype)
        sin = self.sin[..., :seq_len, :].to(dtype=q.dtype)

        return (
            apply_rotary_pos_emb(q, cos, sin),
            apply_rotary_pos_emb(k, cos, sin),
        )


class EsmPatcher(HFModelPatcher):
    def __init__(self, root: torch.nn.Module):
        super().__init__(root)
        self.org_rot_emb = {}

    def __enter__(self):
        if isinstance(self.root, modeling_esm.EsmModel):
            text_model = self.root
        elif isinstance(self.root, modeling_esm.EsmForMaskedLM):
            text_model = self.root.model
        else:
            raise NotImplementedError
        for i, layer in enumerate(text_model.encoder.layer):
            self.org_rot_emb[i] = layer.attention.self.rotary_embeddings
            layer.attention.self.rotary_embeddings = CachedEsmRotaryEmbedding(layer.attention.self.rotary_embeddings)

    def __exit__(self, exc_type, exc_val, exc_tb):
        if isinstance(self.root, modeling_esm.EsmModel):
            text_model = self.root
        elif isinstance(self.root, modeling_esm.EsmForMaskedLM):
            text_model = self.root.model
        else:
            raise NotImplementedError
        for i, layer in enumerate(text_model.encoder.layer):
            layer.attention.self.rotary_embeddings = self.org_rot_emb[i]

class EsmForMaskedLMWrapper(torch.nn.Module):
    def __init__(self, language_model) -> None:
        super().__init__()
        if isinstance(language_model, modeling_esm.EsmForMaskedLM):
            self.language_model = language_model
        else:
            raise NotImplementedError       

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        head_mask: Optional[torch.Tensor] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        encoder_hidden_states: Optional[torch.FloatTensor] = None,
        encoder_attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.LongTensor] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ):
        return self.language_model.forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            labels=labels,
            encoder_hidden_states=encoder_hidden_states,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            encoder_attention_mask=encoder_attention_mask,
            return_dict=return_dict,
        )

class EsmModelWrapper(torch.nn.Module):
    def __init__(self, language_model) -> None:
        super().__init__()
        if isinstance(language_model, modeling_esm.EsmModel):
            self.language_model = language_model
        else:
            raise NotImplementedError       

    def forward(
        self,
        input_ids: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
        head_mask: Optional[torch.Tensor] = None,
        inputs_embeds: Optional[torch.Tensor] = None,
        encoder_hidden_states: Optional[torch.Tensor] = None,
        encoder_attention_mask: Optional[torch.Tensor] = None,
        past_key_values: Optional[List[torch.FloatTensor]] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ):
        return self.language_model.forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            past_key_values=past_key_values,
            use_cache=use_cache,
            encoder_hidden_states=encoder_hidden_states,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            encoder_attention_mask=encoder_attention_mask,
            return_dict=return_dict,
        )

_AUTOWRAP_FNS = [
    apply_rotary_pos_emb,

]


def get_patcher_cfg():
    # fmt:off
    modelCFG = HF_PATCHER_CFG(
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
            modeling_esm.EsmModel: (EsmPatcher, EsmModelWrapper)
        },
    )
    maskedLMCFG = HF_PATCHER_CFG(
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
            modeling_esm.EsmForMaskedLM: (EsmPatcher, EsmForMaskedLMWrapper)
        },
    )
    return [modelCFG, maskedLMCFG]
    # fmt:on
