from typing import Optional, Union

import torch
import transformers.models.phi3.modeling_phi3 as modeling_phi3
from transformers import Cache

from qbcompiler.model_dict.parser.backend.fx_hf_extensions.transformers.models.phi3 import(
    CachedPhi3RotaryEmbedding,
    Phi3Patcher,
    Phi3ForCausalLMWrapper
)
from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HF_REMOTE_CODE_PATCHER_CFG,
    HFModelPatcher,
)
class Phi4Patcher(Phi3Patcher):
    def __init__(self, root: torch.nn.Module):
        super().__init__(root)
        self.text_model_rotary_emb = None

    def __enter__(self):
        if type(self.root).__qualname__ == "Phi3ForCausalLM":
            text_model = self.root.model
        else:
            raise NotImplementedError
        self.text_model_rotary_emb = text_model.rotary_emb
        text_model.rotary_emb = CachedPhi3RotaryEmbedding(text_model.rotary_emb)

    def __exit__(self, exc_type, exc_val, exc_tb):
        text_model = self.root.model
        text_model.rotary_emb = self.text_model_rotary_emb


class Phi4ForCausalLMWrapper(Phi3ForCausalLMWrapper):
    def __init__(self, language_model) -> None:
        super().__init__(language_model)

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Cache] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        logits_to_keep: Union[int, torch.Tensor] = 0,
        **kwargs,
    ):
        return super().forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            labels=labels,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            cache_position=cache_position,
            logits_to_keep=logits_to_keep,
            **kwargs,
        )


_AUTOWRAP_FNS = [
    'modeling_phi3.apply_rotary_pos_emb',
]


def get_patcher_cfg():
    # fmt:off
    return HF_REMOTE_CODE_PATCHER_CFG(
        target='Phi3ForCausalLM',
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
            'modeling_phi3.Phi3ForCausalLM':(Phi4Patcher, Phi4ForCausalLMWrapper)
        }
    )

    # fmt:on
