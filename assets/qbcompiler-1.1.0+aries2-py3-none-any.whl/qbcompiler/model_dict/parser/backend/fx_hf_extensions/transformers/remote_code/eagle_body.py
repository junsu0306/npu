import torch

from typing import Optional, Union, Tuple, List
from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HF_REMOTE_CODE_PATCHER_CFG,
)


class LlamaModelWrapper(torch.nn.Module):
    def __init__(self, language_model) -> None:
        super().__init__()
        self.language_model = language_model

    def forward(
        self,
        hidden_states: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values=None,  # [MODIFIED] past_key_value is KVCache class
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        requires_all_features_logits: Optional[bool] = None,
        **kwargs
    ):
        return self.language_model.forward(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            requires_all_features_logits=requires_all_features_logits,
            **kwargs
        )


_AUTOWRAP_FNS = ["modeling_llama_kv_rev0.apply_rotary_pos_emb"]


def get_patcher_cfg():
    # fmt:off
    return HF_REMOTE_CODE_PATCHER_CFG(
        target='MobilintLlama',
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
            "eagle.modeling_llama_kv_rev0.LlamaModel": (None, LlamaModelWrapper)
        }
    )
    # fmt:on
