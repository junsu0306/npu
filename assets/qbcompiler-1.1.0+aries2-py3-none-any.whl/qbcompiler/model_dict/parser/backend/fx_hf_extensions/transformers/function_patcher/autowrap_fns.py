import importlib

from importlib.util import find_spec

_TRANSFORMERS_AUTOWRAP_FNS_STR = []
TRANSFORMERS_AUTOWRAP_FNS_FUNC = []

for full_path in _TRANSFORMERS_AUTOWRAP_FNS_STR:
    try:
        module_path, attr_name = full_path.rsplit(".", 1)
    except ValueError:
        continue

    if find_spec(module_path) is None:
        continue

    try:
        mod = importlib.import_module(module_path)
    except Exception as e:
        continue

    try:
        obj = getattr(mod, attr_name)
    except AttributeError:
        continue

    TRANSFORMERS_AUTOWRAP_FNS_FUNC.append(obj)
