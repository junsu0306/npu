from typing import Optional, Union

import torch
import transformers.models.llama.modeling_llama as modeling_llama
from transformers import Cache


from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HF_PATCHER_CFG,
    HFModelPatcher,
)


class CachedLlamaRotaryEmbedding(torch.nn.Module):
    def __init__(self, llama_rotary_embedding: modeling_llama.LlamaRotaryEmbedding):
        super().__init__()
        self.batch_size = 1
        self.rope_cache_len = 16384

        inv_freq = llama_rotary_embedding.inv_freq
        inv_freq_expanded = (
            inv_freq[None, :, None].float().expand(self.batch_size, -1, 1)
        )
        position_ids = (
            torch.arange(self.rope_cache_len).reshape(1, -1).to(inv_freq.device)
        )
        position_ids_expanded = position_ids[:, None, :].float()
        with torch.autocast(
            device_type=inv_freq.device.type, enabled=False
        ):  # Force float32
            freqs = (
                inv_freq_expanded.float() @ position_ids_expanded.float()
            ).transpose(1, 2)
            emb = torch.cat((freqs, freqs), dim=-1)
            cos = emb.cos() * llama_rotary_embedding.attention_scaling
            sin = emb.sin() * llama_rotary_embedding.attention_scaling
            self.register_buffer("cos", cos)
            self.register_buffer("sin", sin)

    @torch.no_grad()
    def forward(self, x, position_ids):
        cos = self.cos[:, position_ids.reshape(-1), :].to(dtype=x.dtype)
        sin = self.sin[:, position_ids.reshape(-1), :].to(dtype=x.dtype)
        return cos, sin


class LlamalangPatcher(HFModelPatcher):
    def __init__(self, root: torch.nn.Module):
        super().__init__(root)
        self.text_model_rotary_emb: modeling_llama.LlamaRotaryEmbedding | CachedLlamaRotaryEmbedding = (
            None
        )

    def __enter__(self):
        if isinstance(self.root, modeling_llama.LlamaModel):
            pass
        else:
            raise NotImplementedError
        self.text_model_rotary_emb = self.root.rotary_emb
        self.root.rotary_emb = CachedLlamaRotaryEmbedding(self.root.rotary_emb)

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.root.rotary_emb = self.text_model_rotary_emb


class LLamalangLMWrapper(torch.nn.Module):
    def __init__(self, language_model: modeling_llama.LlamaModel) -> None:
        super().__init__()
        self.language_model = language_model

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Cache] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        logits_to_keep: Union[int, torch.Tensor] = 0,
        **kwargs,
    ):
        output = self.language_model.forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            labels=labels,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            cache_position=cache_position,
            logits_to_keep=logits_to_keep,
            **kwargs,
        )
        output.last_hidden_state = output.last_hidden_state[
            :, -1, :
        ]  # slice last component
        return output


_AUTOWRAP_FNS = [
    modeling_llama.apply_rotary_pos_emb,
]


def get_patcher_cfg():
    # fmt:off
    return HF_PATCHER_CFG(
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
            modeling_llama.LlamaModel:(LlamalangPatcher, LLamalangLMWrapper)
        }
    )

    # fmt:on
