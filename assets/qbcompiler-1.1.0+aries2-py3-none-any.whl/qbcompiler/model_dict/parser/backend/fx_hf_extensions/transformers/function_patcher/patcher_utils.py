from __future__ import annotations
from importlib.util import find_spec
from typing import Dict, Tuple, Any, Iterator, Optional, List

import importlib
import contextlib
import inspect


def _split_path(path: str) -> Optional[Tuple[str, str]]:
    """Only last part means function name"""
    path = path.strip()
    if "." not in path:
        return None
    mod_path, attr = path.rsplit(".", 1)
    return mod_path, attr


def _resolve_attr(path: str) -> Optional[Tuple[Any, str, Any]]:
    sp = _split_path(path)
    if sp is None:
        return None
    mod_path, attr = sp
    try:
        if find_spec(mod_path) is None:
            return None
        mod = importlib.import_module(mod_path)
    except Exception:
        return None
    if not hasattr(mod, attr):
        return None
    return mod, attr, getattr(mod, attr)


def validate_targets(
    targets: Dict[str, Any], *, only_functions: bool = True
) -> Dict[str, Any]:
    valid: Dict[str, Any] = {}
    for path, replacement in targets.items():
        if not callable(replacement):
            continue
        resolved = _resolve_attr(path)
        if resolved is None:
            continue
        if only_functions and not inspect.isfunction(replacement):
            continue
        valid[path] = replacement
    return valid


@contextlib.contextmanager
def transformer_function_patcher(
    targets: Dict[str, Any]
) -> Iterator[List[Tuple[Any, str, Any]]]:
    """
    targets: { 'a.b.c.func': new_callable, ... }
    """
    applied: List[Tuple[Any, str, Any]] = []
    try:
        for path, new_obj in targets.items():
            if not callable(new_obj):
                continue
            resolved = _resolve_attr(path)
            if resolved is None:
                continue
            mod, attr, old_obj = resolved
            setattr(mod, attr, new_obj)
            applied.append((mod, attr, old_obj))
        yield applied
    finally:
        for mod, attr, old_obj in reversed(applied):
            setattr(mod, attr, old_obj)
