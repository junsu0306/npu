from typing import Optional, Union, Tuple, List
import torch
from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HF_REMOTE_CODE_PATCHER_CFG,
)

class Florence2VisionModelWrapper(torch.nn.Module):
    def __init__(self, vision_model) -> None:
        super().__init__()
        self.vision_model = vision_model

    def forward(
        self,
        pixel_values: torch.FloatTensor,
        **kwargs,
    ):
        return self.vision_model._encode_image(
            pixel_values=pixel_values,
            **kwargs,
        )

_AUTOWRAP_FNS = [
    # get_extended_attention_mask
]

def get_patcher_cfg():
    # fmt:off
    return HF_REMOTE_CODE_PATCHER_CFG(
        target='Florence2ForConditionalGeneration',
        autowrap_fns=[],
        root_patcher_wrapper={
            "modeling_florence2.Florence2ForConditionalGeneration":(None, Florence2VisionModelWrapper)
        }
    )
    # fmt:on
