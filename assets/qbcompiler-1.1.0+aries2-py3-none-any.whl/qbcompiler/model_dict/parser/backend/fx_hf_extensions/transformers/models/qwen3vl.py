import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple, Union
from transformers import Cache
from transformers.models.qwen3_vl import modeling_qwen3_vl
from transformers.models.qwen3_vl.modeling_qwen3_vl import (
    Qwen3VLForConditionalGeneration,
    Qwen3VLCausalLMOutputWithPast,
    Qwen3VLModelOutputWithPast,
)
from transformers.processing_utils import Unpack
from transformers.utils import TransformersKwargs, is_torchdynamo_compiling
from qbcompiler.model_dict.parser.backend.fx_hf_extensions.model_patcher import (
    HF_PATCHER_CFG,
)
from einops import rearrange

"""
transformers = 4.57.1
"""

###### Vision Modules ######


class PatchedVisionPatchEmbed(nn.Module):
    def __init__(self, patch_embed) -> None:
        super().__init__()
        proj_3d = patch_embed.proj
        assert proj_3d.kernel_size == proj_3d.stride
        self.patch_size = patch_embed.patch_size
        self.temporal_patch_size = patch_embed.temporal_patch_size
        self.in_channels = patch_embed.in_channels
        self.embed_dim = patch_embed.embed_dim

        weight_3d = proj_3d.weight
        self.proj = nn.Conv2d(
            in_channels=weight_3d.size(1) * weight_3d.size(2),
            out_channels=weight_3d.size(0),
            kernel_size=(weight_3d.size(3), weight_3d.size(4)),
            stride=(weight_3d.size(3), weight_3d.size(4)),
            bias=True,
        )
        self.proj.weight.data = proj_3d.weight.data.transpose(1, 2).reshape(
            (
                weight_3d.size(0),
                weight_3d.size(1) * weight_3d.size(2),
                weight_3d.size(3),
                weight_3d.size(4),
            )
        )  # (Cout, T * Cin, H, W)
        self.proj.bias.data = proj_3d.bias.data
        self.merge_size = 2

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        bsz = hidden_states.shape[0]
        target_dtype = self.proj.weight.dtype
        hidden_states = self.proj(
            hidden_states.to(dtype=target_dtype)
        )  # (gt=1, Cout, gh * Mh, gw * Mw) -> (1, gt * gh * gw * Mh * Mw, Cout) // (gt gh gw Mh Mw)

        hidden_states = hidden_states.permute(0, 2, 3, 1)
        hidden_states = hidden_states.reshape((bsz, -1, self.embed_dim))

        return hidden_states


class PatchedVisionSdpaAttention(nn.Module):
    def __init__(self, vision_attention) -> None:
        super().__init__()
        self.vision_attention = vision_attention

        Cout, Cin = self.vision_attention.qkv.weight.shape
        self.vision_attention.q = nn.Linear(Cin, Cout // 3, bias=True)
        self.vision_attention.k = nn.Linear(Cin, Cout // 3, bias=True)
        self.vision_attention.v = nn.Linear(Cin, Cout // 3, bias=True)

        weight_q, weight_k, weight_v = self.vision_attention.qkv.weight.data.reshape(
            3, Cout // 3, Cin
        ).unbind(0)
        bias_q, bias_k, bias_v = self.vision_attention.qkv.bias.data.reshape(
            3, Cout // 3
        ).unbind(0)

        self.vision_attention.q.weight.data = weight_q
        self.vision_attention.k.weight.data = weight_k
        self.vision_attention.v.weight.data = weight_v
        self.vision_attention.q.bias.data = bias_q
        self.vision_attention.k.bias.data = bias_k
        self.vision_attention.v.bias.data = bias_v
        del self.vision_attention.qkv

    def forward(
        self,
        hidden_states: torch.Tensor,
        cu_seqlens: torch.Tensor,
        rotary_pos_emb: Optional[torch.Tensor] = None,
        position_embeddings: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ) -> torch.Tensor:
        bsz = hidden_states.shape[0]
        seq_length = hidden_states.shape[1]
        q = (
            self.vision_attention.q(hidden_states)
            .reshape(bsz, seq_length, self.vision_attention.num_heads, -1)
            .transpose(1, 2)
        )
        k = (
            self.vision_attention.k(hidden_states)
            .reshape(bsz, seq_length, self.vision_attention.num_heads, -1)
            .transpose(1, 2)
        )
        v = (
            self.vision_attention.v(hidden_states)
            .reshape(bsz, seq_length, self.vision_attention.num_heads, -1)
            .transpose(1, 2)
        )
        cos, sin = position_embeddings

        orig_q_dtype = q.dtype
        orig_k_dtype = k.dtype
        q, k = apply_rotary_pos_emb_vision(q.float(), k.float(), cos, sin)
        q = q.to(orig_q_dtype)
        k = k.to(orig_k_dtype)

        attn_output = F.scaled_dot_product_attention(q, k, v, dropout_p=0.0)
        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.reshape(bsz, seq_length, -1)
        attn_output = self.vision_attention.proj(attn_output)
        return attn_output


class PatchedQwen3VLVisionBlock(nn.Module):
    def __init__(self, vision_block) -> None:
        super().__init__()
        self.vision_block = vision_block
        self.vision_block.attn = PatchedVisionSdpaAttention(self.vision_block.attn)

    def forward(
        self,
        hidden_states: torch.Tensor,
        cu_seqlens: torch.Tensor = None,
        rotary_pos_emb: Optional[torch.Tensor] = None,
        position_embeddings: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ) -> torch.Tensor:
        return self.vision_block(
            hidden_states, cu_seqlens, rotary_pos_emb, position_embeddings
        )


class PatchedPatchMerger(nn.Module):
    def __init__(self, patch_merger) -> None:
        super().__init__()
        self.hidden_size = patch_merger.hidden_size
        self.use_postshuffle_norm = patch_merger.use_postshuffle_norm
        self.norm = patch_merger.norm
        self.linear_fc1 = patch_merger.linear_fc1
        self.act_fn = patch_merger.act_fn
        self.linear_fc2 = patch_merger.linear_fc2

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.use_postshuffle_norm:
            x = x.reshape(1, 1, -1, self.hidden_size)
        x = self.norm(x)
        x = x.reshape(-1, self.hidden_size)
        x = self.linear_fc1(x)
        x = self.act_fn(x)
        x = self.linear_fc2(x)
        return x


class VisionModelForQwen3VL(torch.nn.Module):
    def __init__(self, model) -> None:
        super().__init__()
        self.model = model.visual
        self.model.patch_embed = PatchedVisionPatchEmbed(self.model.patch_embed)
        for block_idx, block in enumerate(self.model.blocks):
            self.model.blocks[block_idx] = PatchedQwen3VLVisionBlock(block)
        self.model.merger = PatchedPatchMerger(self.model.merger)

        self.model.deepstack_merger_list = nn.ModuleList(
            [PatchedPatchMerger(merger) for merger in self.model.deepstack_merger_list]
        )

    def set_grid_thw(self, grid_thw):
        self.grid_thw = grid_thw
        pos_embeds = self.model.fast_pos_embed_interpolate(grid_thw)
        self.register_buffer("pos_embeds", pos_embeds, persistent=False)

        rotary = self.model.rot_pos_emb(grid_thw)
        emb = torch.cat((rotary, rotary), dim=-1)
        cos = emb.cos()[None, None]
        sin = emb.sin()[None, None]
        self.register_buffer("cos", cos, persistent=False)
        self.register_buffer("sin", sin, persistent=False)

    def forward(self, images: torch.Tensor):
        hidden_states = self.model.patch_embed(images)
        hidden_states = hidden_states + self.pos_embeds

        position_embeddings = (self.cos, self.sin)
        cu_seqlens = None

        deepstack_feature_lists = []
        for layer_num, blk in enumerate(self.model.blocks):
            hidden_states = blk(
                hidden_states,
                cu_seqlens=cu_seqlens,
                position_embeddings=position_embeddings,
            )
            if layer_num in self.model.deepstack_visual_indexes:
                deepstack_feature = self.model.deepstack_merger_list[
                    self.model.deepstack_visual_indexes.index(layer_num)
                ](hidden_states)
                deepstack_feature_lists.append(deepstack_feature)
        # merger
        hidden_states = self.model.merger(hidden_states)

        return hidden_states, deepstack_feature_lists


class Qwen3VLModel_get_image_feature(torch.nn.Module):
    def __init__(self, qwen3vl_model) -> None:
        super().__init__()
        self.visual = qwen3vl_model.visual

    def forward(
        self,
        pixel_values: torch.FloatTensor,
        image_grid_thw: Optional[torch.LongTensor] = None,
    ):
        pixel_values = pixel_values.type(self.visual.dtype)
        image_embeds, deepstack_image_embeds = self.visual(
            pixel_values, grid_thw=image_grid_thw
        )
        split_sizes = image_grid_thw.prod(-1) // self.visual.spatial_merge_size**2
        split_sizes = split_sizes.unbind(0)
        split_sizes = [int(s) for s in split_sizes]
        image_embeds = torch.split(image_embeds, split_sizes)
        return image_embeds, torch.stack(
            deepstack_image_embeds
        )  # 원본은 List[Tensor] 이나 Tensor로 변경


###### Language Modules ######


class CachedQwen3VLTextRotaryEmbedding(nn.Module):
    def __init__(self, qwen3vl_rotary_embedding):
        super().__init__()
        self.rope_cache_len = 16384

        self.inv_freq = qwen3vl_rotary_embedding.inv_freq
        self.attention_scaling = qwen3vl_rotary_embedding.attention_scaling
        self.mrope_section = qwen3vl_rotary_embedding.mrope_section

        head_dim_half = self.inv_freq.shape[0]
        self.head_dim = head_dim_half * 2
        device = self.inv_freq.device

        half_assignment = torch.zeros(head_dim_half, dtype=torch.long, device=device)

        h_length = self.mrope_section[1] * 3
        h_indices = torch.arange(1, min(h_length, head_dim_half), 3, device=device)
        half_assignment[h_indices] = 1

        w_length = self.mrope_section[2] * 3
        w_indices = torch.arange(2, min(w_length, head_dim_half), 3, device=device)
        half_assignment[w_indices] = 2

        self.register_buffer(
            "axis_assignment",
            torch.cat([half_assignment, half_assignment]),
            persistent=False,
        )

    def set_rope(self, position_ids):
        """
        Prefill 시 호출하여 cos/sin 테이블 생성

        Args:
            position_ids: (3, bs, seq_len) - T/H/W 축별 position
        """
        device = position_ids.device
        rope_cache_len = self.rope_cache_len

        last_pos = position_ids[0, 0, -1].item()
        occupied = position_ids.shape[-1]

        extended = torch.arange(
            last_pos + 1, last_pos + 1 + (rope_cache_len - occupied), device=device
        )[None, None, :].expand(3, 1, -1)

        position_ids = torch.cat([position_ids, extended], dim=-1)
        position_ids = position_ids[..., :rope_cache_len]

        inv_freq = self.inv_freq.float()
        freqs = position_ids.float().squeeze(1).unsqueeze(-1) * inv_freq
        # shape: (3, rope_cache_len, head_dim_half)

        emb = torch.cat([freqs, freqs], dim=-1)
        # shape: (3, rope_cache_len, head_dim)

        cos_all = emb.cos() * self.attention_scaling
        sin_all = emb.sin() * self.attention_scaling

        axis_idx = self.axis_assignment.view(1, 1, -1).expand(1, rope_cache_len, -1)

        cos = torch.gather(cos_all, dim=0, index=axis_idx).squeeze(0)
        sin = torch.gather(sin_all, dim=0, index=axis_idx).squeeze(0)
        # shape: (rope_cache_len, head_dim)

        self.register_buffer("cos", cos.unsqueeze(0), persistent=False)
        self.register_buffer("sin", sin.unsqueeze(0), persistent=False)

    @torch.no_grad()
    def forward(self, x, position_ids):
        position_ids = torch.arange(position_ids.shape[-1], device=x.device)

        cos = self.cos[..., position_ids, :].to(dtype=x.dtype)
        sin = self.sin[..., position_ids, :].to(dtype=x.dtype)

        return cos, sin


class Projection(torch.nn.Module):
    def __init__(self, language_model, lm_head):
        super().__init__()
        self.language_model = language_model
        self.lm_head = lm_head

    def forward(
        self,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Cache] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        cache_position: Optional[torch.LongTensor] = None,
        logits_to_keep: Union[int, torch.Tensor] = 0,
        visual_pos_masks: Optional[torch.Tensor] = None,
        deepstack_visual_embeds: Optional[torch.Tensor] = None,
        rope_deltas: Optional[torch.LongTensor] = None,
        **kwargs: Unpack[TransformersKwargs],
    ):
        outputs = self.language_model(
            input_ids=None,
            position_ids=position_ids,
            attention_mask=attention_mask,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            cache_position=cache_position,
            visual_pos_masks=visual_pos_masks,
            deepstack_visual_embeds=deepstack_visual_embeds,
            **kwargs,
        )

        outputs = Qwen3VLModelOutputWithPast(
            last_hidden_state=outputs.last_hidden_state,
            past_key_values=outputs.past_key_values,
            rope_deltas=rope_deltas,
        )

        hidden_states = outputs[0]
        # Only compute necessary logits, and do not upcast them to float if we are not computing the loss
        slice_indices = (
            slice(-logits_to_keep, None)
            if isinstance(logits_to_keep, int)
            else logits_to_keep
        )
        logits = self.lm_head(hidden_states[:, slice_indices, :])

        return Qwen3VLCausalLMOutputWithPast(
            loss=None,
            logits=logits,
            past_key_values=outputs.past_key_values,
            rope_deltas=outputs.rope_deltas,
        )


class Qwen3VLForConditionalGenerationWrapper(Qwen3VLForConditionalGeneration):
    def forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Cache] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        pixel_values: Optional[torch.Tensor] = None,
        pixel_values_videos: Optional[torch.FloatTensor] = None,
        image_grid_thw: Optional[torch.LongTensor] = None,
        video_grid_thw: Optional[torch.LongTensor] = None,
        cache_position: Optional[torch.LongTensor] = None,
        logits_to_keep: Union[int, torch.Tensor] = 0,
        **kwargs: Unpack[TransformersKwargs],
    ):
        qwen3vl_model = self.model
        if (input_ids is None) ^ (inputs_embeds is not None):
            raise ValueError(
                "You must specify exactly one of input_ids or inputs_embeds"
            )

        if inputs_embeds is None:
            inputs_embeds = qwen3vl_model.get_input_embeddings()(input_ids)

        image_mask = None
        video_mask = None

        if pixel_values is not None:
            image_embeds, deepstack_image_embeds = qwen3vl_model.get_image_features(
                pixel_values, image_grid_thw
            )
            image_embeds = torch.cat(image_embeds, dim=0).to(
                inputs_embeds.device, inputs_embeds.dtype
            )
            image_mask, _ = qwen3vl_model.get_placeholder_mask(
                input_ids, inputs_embeds=inputs_embeds, image_features=image_embeds
            )
            inputs_embeds = inputs_embeds.masked_scatter(image_mask, image_embeds)

        if pixel_values_videos is not None:
            video_embeds, deepstack_video_embeds = qwen3vl_model.get_video_features(
                pixel_values_videos, video_grid_thw
            )
            video_embeds = torch.cat(video_embeds, dim=0).to(
                inputs_embeds.device, inputs_embeds.dtype
            )
            _, video_mask = qwen3vl_model.get_placeholder_mask(
                input_ids, inputs_embeds=inputs_embeds, video_features=video_embeds
            )
            inputs_embeds = inputs_embeds.masked_scatter(video_mask, video_embeds)

        visual_pos_masks = None
        deepstack_visual_embeds = None
        if image_mask is not None and video_mask is not None:
            # aggregate visual_pos_masks and deepstack_visual_embeds
            image_mask = image_mask[..., 0]
            video_mask = video_mask[..., 0]
            visual_pos_masks = image_mask | video_mask
            deepstack_visual_embeds = []
            image_mask_joint = image_mask[visual_pos_masks]
            video_mask_joint = video_mask[visual_pos_masks]
            for img_embed, vid_embed in zip(
                deepstack_image_embeds, deepstack_video_embeds
            ):
                embed_joint = img_embed.new_zeros(
                    visual_pos_masks.sum(), img_embed.shape[-1]
                ).to(img_embed.device)
                embed_joint[image_mask_joint, :] = img_embed
                embed_joint[video_mask_joint, :] = vid_embed
                deepstack_visual_embeds.append(embed_joint)
        elif image_mask is not None:
            image_mask = image_mask[..., 0]
            visual_pos_masks = image_mask
            deepstack_visual_embeds = deepstack_image_embeds
        elif video_mask is not None:
            video_mask = video_mask[..., 0]
            visual_pos_masks = video_mask
            deepstack_visual_embeds = deepstack_video_embeds

        if position_ids is None:
            attention_mask_tensor = (
                attention_mask
                if not isinstance(attention_mask, dict)
                else attention_mask["full_attention"]
            )
            if attention_mask_tensor is not None and attention_mask_tensor.ndim == 4:
                attention_mask_tensor = torch.diagonal(
                    attention_mask_tensor[:, 0], dim1=1, dim2=2
                )
                # Only apply conversion for floating point tensors (inverted masks)
                if attention_mask_tensor.dtype.is_floating_point:
                    attention_mask_tensor = (
                        attention_mask_tensor
                        / torch.finfo(attention_mask_tensor.dtype).min
                    )
                    attention_mask_tensor = (1.0 - attention_mask_tensor).int()

            # Calculate RoPE index once per generation in the pre-fill stage only.
            # When compiling, we can't check tensor values thus we check only input length
            # It is safe to assume that `length!=1` means we're in pre-fill because compiled
            # models currently cannot do asssisted decoding
            prefill_compiled_stage = is_torchdynamo_compiling() and (
                (input_ids is not None and input_ids.shape[1] != 1)
                or (inputs_embeds is not None and inputs_embeds.shape[1] != 1)
            )
            prefill_noncompiled_stage = not is_torchdynamo_compiling() and (
                (cache_position is not None and cache_position[0] == 0)
                or (past_key_values is None or past_key_values.get_seq_length() == 0)
            )
            if (
                prefill_compiled_stage or prefill_noncompiled_stage
            ) or qwen3vl_model.rope_deltas is None:
                position_ids, rope_deltas = qwen3vl_model.get_rope_index(
                    input_ids,
                    image_grid_thw,
                    video_grid_thw,
                    attention_mask=attention_mask_tensor,
                )
                qwen3vl_model.rope_deltas = rope_deltas
            # then use the prev pre-calculated rope-deltas to get the correct position ids
            else:
                batch_size, seq_length, _ = inputs_embeds.shape
                delta = (
                    (cache_position[0] + qwen3vl_model.rope_deltas).to(
                        inputs_embeds.device
                    )
                    if cache_position is not None
                    else 0
                )
                position_ids = torch.arange(seq_length, device=inputs_embeds.device)
                position_ids = position_ids.view(1, -1).expand(batch_size, -1)
                if cache_position is not None:  # otherwise `deltas` is an int `0`
                    delta = delta.repeat_interleave(batch_size // delta.shape[0], dim=0)
                position_ids = position_ids.add(delta)
                position_ids = position_ids.unsqueeze(0).expand(3, -1, -1)

        return self.projection(
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            cache_position=cache_position,
            logits_to_keep=logits_to_keep,
            visual_pos_masks=visual_pos_masks,
            deepstack_visual_embeds=deepstack_visual_embeds,
            rope_deltas=qwen3vl_model.rope_deltas,
            **kwargs,
        )


def rotate_half(x):
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2 :]
    return torch.cat((-x2, x1), dim=-1)


def apply_rotary_pos_emb(q, k, cos, sin, position_ids=None, unsqueeze_dim=1):
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


def apply_rotary_pos_emb_vision(q, k, cos, sin):
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


def repreprocess_pixel_values(pixel_values, grid_thw):
    """Reshape hf-preprocessed pixel values to npu format given grid_thw (gt, gh, gw)"""

    gt, gh, gw = grid_thw
    # fix me: some parameters is hard-coded
    c = 3
    pt = 2
    Mh = Mw = 2  # merge size
    ph = pw = int((pixel_values.shape[-1] // (pt * c)) ** 0.5)

    images = rearrange(
        pixel_values,
        "(gt gh gw Mh Mw) (c pt ph pw) -> gt (pt c) (gh gw ph) (Mh Mw pw)",
        gt=gt,
        gh=gh // Mh,
        gw=gw // Mw,
        Mh=Mh,
        Mw=Mw,
        c=c,
        pt=pt,
        ph=ph,
        pw=pw,
    )
    return images


def Qwen3VL_get_image_features(
    self,
    pixel_values: torch.FloatTensor,
    image_grid_thw: Optional[torch.LongTensor] = None,
):
    return self.get_image_feature_class(
        pixel_values=pixel_values, image_grid_thw=image_grid_thw
    )


def patched_deepstack_process(
    self,
    hidden_states: torch.Tensor,
    visual_pos_masks: torch.Tensor,
    visual_embeds: torch.Tensor,
):
    return hidden_states + visual_embeds


def build_full_visual_embeds(visual_embeds_list, visual_pos_masks):
    L, N_vis, D = visual_embeds_list.shape
    _, T = visual_pos_masks.shape

    device = visual_embeds_list.device
    dtype = visual_embeds_list.dtype

    full_visual = torch.zeros(L, T, D, device=device, dtype=dtype)

    mask = visual_pos_masks.squeeze(0)
    full_visual[:, mask, :] = visual_embeds_list

    return full_visual


_AUTOWRAP_FNS = [modeling_qwen3_vl.apply_rotary_pos_emb, apply_rotary_pos_emb_vision]


def get_patcher_cfg():
    # fmt:off
    return HF_PATCHER_CFG(
        autowrap_fns=_AUTOWRAP_FNS,
        root_patcher_wrapper={
        },
    )
    # fmt:on
