import os
import importlib

from qbcompiler.logging import get_logger
from .transformers.function_patcher.autowrap_fns import TRANSFORMERS_AUTOWRAP_FNS_FUNC

model_dir = os.path.join(os.path.dirname(__file__), "transformers/models")
remote_code_dir = os.path.join(os.path.dirname(__file__), "transformers/remote_code")
timm_model_dir = os.path.join(os.path.dirname(__file__), "timm/models")
_MODELS = [
    f[:-3] for f in os.listdir(model_dir) if f.endswith(".py") and f != "__init__.py"
]
# _MODELS.remove("qwen2_vl")
_TIMM_MODELS = [
    f[:-3]
    for f in os.listdir(timm_model_dir)
    if f.endswith(".py") and f != "__init__.py"
]
_REMOTE_CODE = [
    f[:-3]
    for f in os.listdir(remote_code_dir)
    if f.endswith(".py") and f != "__init__.py"
]

logger = get_logger(__name__)


def get_hf_patcher_configs(target=None):
    all_autowrap_fns = []
    root_patcher_wrappers = {}
    hf_classes_to_patch = {}  # proxyable classes
    # These functions are not tracked through proxy evaluation.
    no_track_static_method = []

    all_autowrap_fns.extend(TRANSFORMERS_AUTOWRAP_FNS_FUNC)
    models_path = (
        "qbcompiler.model_dict.parser.backend.fx_hf_extensions.transformers.models"
    )
    for model_name in _MODELS:
        try:
            module = importlib.import_module(f"{models_path}.{model_name}")
        except Exception as e:
            logger.info(e)
            logger.info(f"failed to import {model_name}")
            continue
        cfg = module.get_patcher_cfg()
        if type(cfg) == list:
            for c in cfg:
                all_autowrap_fns += c.autowrap_fns
                root_patcher_wrappers.update(c.root_patcher_wrapper)
        else:
            all_autowrap_fns += cfg.autowrap_fns
            root_patcher_wrappers.update(cfg.root_patcher_wrapper)

    timms_path = "qbcompiler.model_dict.parser.backend.fx_hf_extensions.timm.models"
    for model_name in _TIMM_MODELS:
        try:
            module = importlib.import_module(f"{timms_path}.{model_name}")
        except Exception as e:
            logger.info(e)
            logger.info(f"failed to import {model_name}")
            continue
        cfg = module.get_patcher_cfg()
        if type(cfg) == list:
            for c in cfg:
                all_autowrap_fns += c.autowrap_fns
                root_patcher_wrappers.update(c.root_patcher_wrapper)
        else:
            all_autowrap_fns += cfg.autowrap_fns
            root_patcher_wrappers.update(cfg.root_patcher_wrapper)

    if target is not None:
        remote_code_path = "qbcompiler.model_dict.parser.backend.fx_hf_extensions.transformers.remote_code"
        for model_name in _REMOTE_CODE:
            patch_module = importlib.import_module(f"{remote_code_path}.{model_name}")
            cfg = patch_module.get_patcher_cfg()
            if type(target).__qualname__ == cfg.target:
                try:
                    module = importlib.import_module(target.__class__.__module__)
                except Exception as e:
                    logger.info(e)
                    logger.info(f"failed to import {model_name}")
                    continue
                module_name = module.__name__.split(".")[-1]  # modeling_exaone
                for fnmame in cfg.autowrap_fns:
                    if isinstance(fnmame, str) and fnmame.startswith(module_name):
                        all_autowrap_fns.append(getattr(module, fnmame.split(".")[-1]))
                    else:
                        all_autowrap_fns += cfg.autowrap_fns
                for k, v in cfg.root_patcher_wrapper.items():
                    root_patcher_wrappers[getattr(module, k.split(".")[-1])] = v

    from .transformers.cache_utils import HF_CACHE_CLASSES_TO_PATCH

    hf_classes_to_patch.update(HF_CACHE_CLASSES_TO_PATCH)

    no_track_static_method.append(
        (
            "transformers.modeling_attn_mask_utils",
            "AttentionMaskConverter",
            "_ignore_causal_mask_sdpa",
        )
    )

    return (
        all_autowrap_fns,
        root_patcher_wrappers,
        hf_classes_to_patch,
        no_track_static_method,
    )
