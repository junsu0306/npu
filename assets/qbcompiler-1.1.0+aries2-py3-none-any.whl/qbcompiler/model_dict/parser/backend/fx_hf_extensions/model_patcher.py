import abc
import dataclasses
from typing import List, Callable, Dict, Type, Tuple

import torch.nn


@dataclasses.dataclass
class HF_PATCHER_CFG:
    autowrap_fns: List[Callable] = dataclasses.field(default_factory=list)
    root_patcher_wrapper: Dict[Type, Tuple[Type, Type]] = dataclasses.field(
        default_factory=dict
    )


@dataclasses.dataclass
class HF_REMOTE_CODE_PATCHER_CFG:
    target: str
    autowrap_fns: List[Callable] = dataclasses.field(default_factory=list)
    root_patcher_wrapper: Dict[Type, Tuple[Type, Type]] = dataclasses.field(
        default_factory=dict
    )


class HFModelPatcher(abc.ABC):
    def __init__(self, root: torch.nn.Module, **kwargs):
        self.root = root

    @abc.abstractmethod
    def __enter__(self):
        ...

    @abc.abstractmethod
    def __exit__(self, exc_type, exc_val, exc_tb):
        ...
