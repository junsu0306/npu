import importlib

from qbcompiler.model_dict.common.parserabc import ParserABC, MobilintParserInputs

# fmt:off
_MISC_BASE_PATH = "qbcompiler.model_dict.parser.backend.misc"
_MISC_MODELS = {
    ("outetts.wav_tokenizer.model", "WavDecoder"): ("oute_ai.outetts", "parse_wav_decoder",),
    ("wenet.transformer.asr_model", "ASRModel"): ("wenet.transformer", "parse_wenet"),
    ("wenet.transformer.encoder", "ConformerEncoder"): ("wenet.transformer", "parse_wenet"),
    ("wenet.transformer.decoder", "BiTransformerDecoder"): ("wenet.transformer", "parse_wenet"),
    ("nemo.collections.asr.models.asr_model", "ASRModel"): ("nemo.collections.asr", "parse_nemo"),
    ("nemo.collections.asr.modules.conformer_encoder", "ConformerEncoder"): ("nemo.collections.asr", "parse_nemo"),
    ("nemo.collections.asr.modules.conv_asr", "ConvASRDecoder"): ("nemo.collections.asr", "parse_nemo"),
    ("nemo.collections.asr.models.ctc_bpe_models", "EncDecCTCModelBPE"): ("nemo.collections.asr", "parse_nemo"),
    ("nemo.collections.asr.parts.utils.activations", "Swish"): ("nemo.collections.asr", "parse_nemo"),
    ("nemo.collections.asr.models.hybrid_rnnt_ctc_bpe_models", "EncDecHybridRNNTCTCBPEModel"): ("nemo.collections.asr", "parse_nemo"),
}
# fmt:on


class MiscModelParser(ParserABC):
    def __init__(
        self,
        model,
        temp_dir: str = "",
        path_to_model: str = "",
        backend: str = "",
        seed: int = 12345,
        **kwargs,
    ):
        super().__init__("", backend, seed)

        self.model = model
        self._temp_dir = temp_dir
        self._module_parser = None

    def parse(self, parser_inputs: MobilintParserInputs, **kwargs):
        module_name = self.model.__class__.__module__
        cls_name = self.model.__class__.__name__
        if (module_name, cls_name) not in _MISC_MODELS:
            raise NotImplementedError(f"{type(self.model)} not implemented")
        parse_module_path, parse_fn_name = _MISC_MODELS[(module_name, cls_name)]
        parser_module = importlib.import_module(
            ".".join([_MISC_BASE_PATH, parse_module_path])
        )
        parse_fn = getattr(parser_module, parse_fn_name)

        return parse_fn(self.model, parser_inputs, **kwargs)
