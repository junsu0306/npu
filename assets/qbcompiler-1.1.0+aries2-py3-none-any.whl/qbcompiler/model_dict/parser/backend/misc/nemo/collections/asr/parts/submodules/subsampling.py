from typing import Any, Optional, Type
import torch
import numpy

from qbcompiler.model_dict.parser.backend.misc.nemo.collections.base import ModelingNemoBase

from qbcompiler.model_dict.common import DataFormat

import nemo.collections.asr.parts.submodules.subsampling as nemo_subsampling


class ConvSubsampling(ModelingNemoBase):
    __slots__ = (
        "_left_padding",
        "_right_padding",
        "_kernel_size",
        "_stride",
        "_ceil_mode",
        "_sampling_num",
        "conv2d_subsampling",
        "conv",
        "out",
    )

    def forward(self, x, lengths):
        if self.conv2d_subsampling:
            x = self.builder.make_unsqueeze(x, 1)  # [1, 10568, 80] -> [1, 1, 10568, 80]
        x = self.builder.make_transpose(x, transpose_axes=(0, 1, 3, 2))
        for key in ("0", "2"):
            self.conv._modules[key].weight = self.conv._modules[key].weight.permute(
                0, 1, 3, 2
            )
        x = self.conv(x)  # [1, 1, 10568, 80] -> [1 512, 2642, 20]

        b, c, t, f = x.get_act_src_shape()
        x = self.builder.make_reshape(
            x, (b, c * t, f)
        )  # [1, 2642, 512, 20] -> [1, 2642, 10240]
        x = self.builder.make_transpose(x, (0, 2, 1))
        x = self.out(x)  # [1, 2642, 10240] -> [1, 2642, 512]

        return x

    @property
    def target_module_type(self) -> Type:
        return nemo_subsampling.ConvSubsampling


def calc_length(lengths, all_paddings, kernel_size, stride, ceil_mode, repeat_num=1):
    """Calculates the output length of a Tensor passed through a convolution or max pooling layer"""
    add_pad: float = all_paddings - kernel_size
    one: float = 1.0
    for i in range(repeat_num):
        lengths = torch.div(lengths.to(dtype=torch.float) + add_pad, stride) + one
        if ceil_mode:
            lengths = torch.ceil(lengths)
        else:
            lengths = torch.floor(lengths)
    return lengths.to(dtype=torch.int)
