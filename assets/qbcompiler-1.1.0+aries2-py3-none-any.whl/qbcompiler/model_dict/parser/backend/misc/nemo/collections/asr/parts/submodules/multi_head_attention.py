import math
import torch
import functools
from typing import Any, Optional, Type

from qbcompiler.model_dict.parser.backend.misc.nemo.collections.base import ModelingNemoBase
from qbcompiler.model_dict.common import DimValue, DataFormat
import nemo.collections.asr.parts.submodules.multi_head_attention as nemo_mha

INF_VAL = 10000.0


class RelPositionalEncoding(ModelingNemoBase):
    __slots__ = ("xscale", "pe", "d_model")

    def create_pe(self, positions, dtype):
        pos_length = positions.size(0)
        pe = torch.zeros(pos_length, self.d_model, device=positions.device)
        div_term = torch.exp(
            torch.arange(
                0, self.d_model, 2, dtype=torch.float32, device=positions.device
            )
            * -(math.log(INF_VAL) / self.d_model)
        )
        pe[:, 0::2] = torch.sin(positions * div_term)
        pe[:, 1::2] = torch.cos(positions * div_term)
        pe = pe.unsqueeze(0).to(dtype)
        self.pe = pe

    def extend_pe(self, length, device=None, dtype=None):
        device = torch.device("cpu")
        dtype = torch.float32
        needed_size = 2 * length - 1
        if hasattr(self, "pe") and self.pe.size(1) >= needed_size:
            return
        positions = torch.arange(
            length - 1, -length, -1, dtype=torch.float32, device=device
        ).unsqueeze(1)
        self.create_pe(positions=positions, dtype=dtype)

    def forward(self, x, cache_len=0):
        x = self.builder.make_mul(x, self.xscale)  # [1, 2642, 512]
        input_len = x.get_act_src_shape()[1] + cache_len  # TODO Check cache_len
        center_pos = self.pe.size(1) // 2 + 1
        # [TODO]: check whther pos is variant
        start_pos = int(center_pos - input_len)
        end_pos = int(center_pos + input_len - 1)
        pos_emb = self.builder.make_inputconst(self.pe[:, None, start_pos:end_pos, :])

        return x, pos_emb

    @property
    def target_module_type(self) -> Type:
        return nemo_mha.RelPositionalEncoding


class RelPositionMultiHeadAttention(ModelingNemoBase):
    __slots__ = (
        "h",
        "d_k",
        "pos_bias_u",
        "pos_bias_v",
        "s_d_k",
    )

    def forward_qkv(self, query, key, value):
        q = self.linear_q(query)
        k = self.linear_k(key)
        v = self.linear_v(value)

        seq_dim = q.get_act_src_shape()[1]
        q = self.builder.make_reshape(q, shape=(1, seq_dim, self.h, self.d_k))
        k = self.builder.make_reshape(k, shape=(1, seq_dim, self.h, self.d_k))
        v = self.builder.make_reshape(v, shape=(1, seq_dim, self.h, self.d_k))
        q = self.builder.make_transpose(q, (0, 2, 1, 3))
        k = self.builder.make_transpose(k, (0, 2, 1, 3))
        v = self.builder.make_transpose(v, (0, 2, 1, 3))

        return q, k, v

    def forward_attention(self, value, scores, mask=None):
        b, h, w, c = scores.get_act_src_shape()
        scores = self.builder.make_softmax(
            scores, axis=-1, beta=0, opname=scores.name + "/softmax"
        )
        x = self.builder.make_matmul(scores, value, opname=scores.name + "/attn_value")
        x = self.builder.make_torch_dropout(x, opname=x.name + "/dropout")
        x = self.builder.make_transpose(
            x, transpose_axes=(0, 2, 1, 3), opname=x.name + "/transpose"
        )
        _, seq_len, h, k = x.get_act_src_shape()
        x = self.builder.make_reshape(x, shape=(1, seq_len, h * k))
        return self.linear_out(x)

    def forward(self, query, key, value, mask, pos_emb, cache=None):
        def custom_fn(
            x: torch.Tensor,
        ):
            b, h, qlen, pos_len = x.size()  # (b, h, t1, t2)
            # need to add a column of zeros on the left side of last dimension to perform the relative shifting
            x = torch.nn.functional.pad(x, pad=(1, 0))  # (b, h, t1, t2+1)
            x = x.view(b, h, -1, qlen)  # (b, h, t2+1, t1)
            # need to drop the first row
            x = x[:, :, 1:].view(b, h, qlen, pos_len)  # (b, h, t1, t2)
            return x

        # [TODO] Check if cache is used
        # key, value, query, cache = self.update_cache(key=key, value=value, query=query, cache=cache)
        opname = query.name
        q, k, v = self.forward_qkv(query, key, value)  # [1, 2642, 512]
        q = self.builder.make_transpose(
            q, (0, 2, 1, 3)
        )  # [1, 8, 2642, 64] -> [1, 2642, 8, 64]

        p = self.linear_pos(pos_emb)
        p = self.builder.make_reshape(
            p, shape=(1, p.get_act_src_shape()[2], self.h, self.d_k)
        )
        p = self.builder.make_transpose(p, (0, 2, 1, 3))

        pos_bias_u = self.builder.make_inputconst(self.pos_bias_u[None, None, :, :])
        q_with_bias_u = self.builder.make_add(q, pos_bias_u)  # [1, 2642, 8, 64]
        q_with_bias_u = self.builder.make_transpose(
            q_with_bias_u, (0, 2, 1, 3)
        )  # [1, 8, 2642, 64]

        pos_bias_v = self.builder.make_inputconst(self.pos_bias_v[None, None, :, :])
        q_with_bias_v = self.builder.make_add(q, pos_bias_v)
        q_with_bias_v = self.builder.make_transpose(q_with_bias_v, (0, 2, 1, 3))

        p = self.builder.make_transpose(
            p, transpose_axes=(0, 1, 3, 2)
        )  # [1, 8, 5283, 64] -> [1, 8, 64, 5283]
        matrix_bd = self.builder.make_matmul(
            q_with_bias_v, p, opname=f"{opname}/attn_weight_bias_v"
        )
        fn_ = functools.partial(
            custom_fn,
        )
        matrix_bd = self.builder.make_rel_shift(matrix_bd)

        k = self.builder.make_transpose(k, (0, 1, 3, 2))
        matrix_ac = self.builder.make_matmul(
            q_with_bias_u, k, opname=f"{opname}/attn_weight"
        )
        matrix_bd.dataformat = DataFormat.NHWC
        scores = self.builder.make_add(matrix_ac, matrix_bd)
        scores = self.builder.make_mul(scores, 1.0 / self.s_d_k)
        out = self.forward_attention(v, scores, mask)

        return out
