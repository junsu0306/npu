from typing import Any, Optional, Type, Tuple, List

from qbcompiler.model_dict.parser.backend.misc.nemo.collections.base import ModelingNemoBase
from qbcompiler.model_dict.common.parserabc import MobilintParserOutputs
from qbcompiler.model_dict.common import (
    ModelDict,
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)


class RNNTDecoder(ModelingNemoBase):
    __slots__ = ("prediction",)

    def forward(
        self,
        y: Optional[ActivationSpec] = None,
        state: Optional[List[ActivationSpec]] = None,
        add_sos: bool = True,
        batch_size: Optional[int] = None,
    ) -> Tuple[ActivationSpec, List[ActivationSpec]]:
        start = None
        g, hid = self.prediction["dec_rnn"](y, state)

        del y, start, state
        return g, hid


class RNNTJoint(ModelingNemoBase):
    (
        "enc",
        "pred",
        "joint_net",
    )

    def project_encoder(self, encoder_output: ActivationSpec) -> ActivationSpec:
        """
        Project the encoder output to the joint hidden dimension.

        Args:
            encoder_output: A torch.Tensor of shape [B, T, D]

        Returns:
            A torch.Tensor of shape [B, T, H]
        """
        return self.enc(encoder_output)

    def project_prednet(self, prednet_output: ActivationSpec) -> ActivationSpec:
        """
        Project the Prediction Network (Decoder) output to the joint hidden dimension.

        Args:
            prednet_output: A torch.Tensor of shape [B, U, D]

        Returns:
            A torch.Tensor of shape [B, U, H]
        """
        return self.pred(prednet_output)

    def joint(self, f: ActivationSpec, g: ActivationSpec) -> ActivationSpec:
        return self.joint_after_projection(
            self.project_encoder(f), self.project_prednet(g)
        )

    def joint_after_projection(
        self, f: ActivationSpec, g: ActivationSpec
    ) -> ActivationSpec:
        inp = self.builder.make_add(f, g)  # (1, 1, 1, 640)
        inp = self.builder.make_unsqueeze(inp, 1)

        res = self.joint_net(inp)

        return res
