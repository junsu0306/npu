import pathlib

import numpy
import torch

from qbcompiler.model_dict.common import DimValue, ActivationSpec, DataFormat
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.common.parserabc import (
    MobilintParserInputs,
    MobilintParserOutputs,
)
from qbcompiler.model_dict.common import (
    ModelDict,
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)
from qbcompiler.model_dict.parser.backend.modeling_torch.util import MakeDynamicObject
from qbcompiler.model_dict.parser.util.subgraph_builder import SubGraphBuilder
from qbcompiler.model_dict.parser.backend.hf.util import (
    DefaultInputsCaptureContainer,
    InputCaptureCtxManager,
)

_NEMO_BASE_PATH = "qbcompiler/model_dict/parser/backend/misc/nemo"
_DYN_MODULE_PATH = {
    "nemo.collections.asr.models.asr_model": _NEMO_BASE_PATH
    + "/collections/asr/models/ctc_bpe_models",
    "nemo.collections.asr.modules.conformer_encoder": _NEMO_BASE_PATH
    + "/collections/asr/modules/conformer_encoder",
    "nemo.collections.asr.modules.multi_head_attention": _NEMO_BASE_PATH
    + "/collections/asr/parts/submodules/multi_head_attention",
    "nemo.collections.asr.modules.conv_asr": _NEMO_BASE_PATH
    + "/collections/asr/modules/conv_asr",
    "nemo.collections.asr.parts.submodules.conformer_modules": _NEMO_BASE_PATH
    + "/collections/asr/parts/submodules/conformer_modules",
    "nemo.collections.asr.parts.submodules.multi_head_attention": _NEMO_BASE_PATH
    + "/collections/asr/parts/submodules/multi_head_attention",
    "nemo.collections.asr.parts.submodules.subsampling": _NEMO_BASE_PATH
    + "/collections/asr/parts/submodules/subsampling",
    "nemo.collections.asr.parts.utils.activations": _NEMO_BASE_PATH
    + "/collections/asr/parts/utils/activations",
    "nemo.collections.asr.parts.submodules.causal_convs": _NEMO_BASE_PATH
    + "/collections/asr/parts/submodules/causal_convs",
    "nemo.collections.asr.modules.rnnt": _NEMO_BASE_PATH
    + "/collections/asr/modules/rnnt",
    "nemo.collections.common.parts.rnn": _NEMO_BASE_PATH + "/collections/common/rnn",
}


def _make_value_dict(target_module, feed_dict, eval_kwargs):
    vd = {}
    vd.update(feed_dict)

    target_module._reference_model

    target_module.set_value_dict(vd)
    target_module.register_forward_hook()
    kw = {}
    kw.update(feed_dict)
    # kw.update(eval_kwargs)

    _value_dict = ValueDict()
    # target_module._reference_model.pre_encode.conv[1] = torch.nn.ReLU(inplace=True)
    # target_module._reference_model.pre_encode.conv[3] = torch.nn.ReLU(inplace=True)
    target_module.torch_compute(**kw)
    for k, v in vd.items():
        if isinstance(v, torch.Tensor):
            if v.dtype == torch.bfloat16:
                v = v.to(torch.float32)
            v = v.detach().cpu().numpy()
        if isinstance(v, numpy.ndarray):
            _value_dict[k] = v

    return _value_dict


def _parse_with_target(
    model, feed_dict=None, eval_kwargs=None, input_shape=(1, 80, 101)
):
    """
    Parse NeMo model with specified target and input shape.

    Args:
        model: NeMo ASR model
        target: Target subgraph ("buffer" or "cache_decoder")
        feed_dict: Optional feed dictionary
        eval_kwargs: Optional evaluation kwargs
        input_shape: Input shape tuple (batch, channels, frames), e.g. (1, 80, 101)
    """

    integrated = False
    encoder_builder = SubGraphBuilder({}, "buffer")
    num_input_frames = input_shape[2]  # Extract frames from input_shape
    if feed_dict is not None:
        pass
    else:
        feed_dict = {}
        processed_signal = torch.randn(size=input_shape).to("cuda")
        processed_signal_length = torch.tensor([num_input_frames]).to("cuda")
        feed_dict["audio_signal"] = processed_signal
        feed_dict["length"] = processed_signal_length

    processed_signal = ActivationSpec(
        name="audio_signal",
        dataformat=DataFormat.NCX,
        src_shape=input_shape,
        dtype="float32",
    )
    # processed_signal_length = ActivationSpec(
    #     name="processed_signal_length",
    #     dataformat=DataFormat.UNKNOWN,
    #     src_shape=(1,),
    #     dtype="int32",
    # )

    module = MakeDynamicObject(dynamic_module_path=_DYN_MODULE_PATH)(model.encoder)
    module.set_builder(encoder_builder, recursive=True)
    encoder_builder.add_activation(processed_signal)
    # encoder_builder.add_activation(processed_signal_length)
    encoder_builder.make_input(processed_signal)
    # encoder_builder.make_input(processed_signal_length)

    encoder_output, _ = module.forward(
        processed_signal,
    )

    if integrated:
        decoder_module = MakeDynamicObject(dynamic_module_path=_DYN_MODULE_PATH)(
            model.decoder
        )
        decoder_module.set_builder(encoder_builder, recursive=True)
        decoder_output = decoder_module(encoder_output)
        encoder_builder.make_output(decoder_output)
    else:
        encoder_builder.make_output(encoder_output)

    sg_target = encoder_builder.build(unsupported=False)
    value_dict = _make_value_dict(module, feed_dict, eval_kwargs)
    const_dict = encoder_builder._weights

    md = ModelDict()
    sg_target.idx = 0
    # if target == "encoder"
    md.subgraphs.append(sg_target)

    for iidx in md.sg_main().inputs:
        inact = md.sg_main().activations[iidx]
        md.inputs.append(inact.name)

    for oidx in md.sg_main().outputs:
        outact = md.sg_main().activations[oidx]
        md.outputs.append(outact.name)

    md.init_model_state = {"sg1": {"slice_len": 5283}}

    out = MobilintParserOutputs()
    out.model_dict = md
    out.value_dict = value_dict  # None -> value_dict
    out.const_dict = const_dict

    return out


def parse_nemo(
    model,
    parser_inputs: MobilintParserInputs,
    make_value_dict: bool = True,
    feed_dict=None,
    **kwargs
):
    # Support new multi-shape format with multi_shapeN kwargs
    # E.g., multi_shape0={"axis": 2, "value": 101}
    multi_shape0 = kwargs.pop("multi_shape0", None)

    if multi_shape0 is not None:
        # New multi-shape format: construct input_shape based on dynamic axis
        dynamic_axis = multi_shape0["axis"]
        dynamic_value = multi_shape0["value"]
        # For nemo, axis 2 is typically the frames dimension
        # Base shape is (1, 80, frames) where frames is the dynamic value
        if dynamic_axis == 2:
            input_shape = (1, 80, dynamic_value)
        elif dynamic_axis == 1:
            input_shape = (1, dynamic_value, 101)  # Fallback
        else:
            input_shape = (1, 80, dynamic_value)  # Default to axis 2
    else:
        # Legacy: use num_input_frames or default
        num_input_frames = kwargs.pop("num_input_frames", 101)
        input_shape = (1, 80, num_input_frames)

    out = _parse_with_target(
        model,
        feed_dict=None,
        eval_kwargs=None,
        input_shape=input_shape,
    )

    return out
