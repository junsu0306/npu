import torch

from typing import Any, Optional, Type

from qbcompiler.model_dict.parser.backend.misc.nemo.collections.base import (
    ModelingNemoBase,
)
from qbcompiler.model_dict.common import ActivationSpec, DataFormat

import nemo.collections.asr.parts.submodules.causal_convs as nemo_causal_convs


class CausalConv1D(ModelingNemoBase):
    __slots__ = (
        "kernel_size",
        "in_channels",
        "out_channels",
        "weight",
        "stride",
        "dilation",
        "groups",
        "weight",
        "bias",
        "_left_padding",
        "_right_padding",
        "cache_drop_size",
        "_max_cache_len",
    )

    def make_identity_conv(self, x):
        ch = int(x.get_act_src_shape()[-1])
        conv_weight = torch.zeros(ch, ch, 1, 1)
        for c in range(ch):
            conv_weight.data[c, c, 0, 0] = 1.0

        x = self.builder.make_conv2d(
            x,
            in_channels=ch,
            out_channels=ch,
            h_kernel=1,
            w_kernel=1,
            h_stride=1,
            w_stride=1,
            h_dilation=1,
            w_dilation=1,
            west_padding=self._left_padding,
            east_padding=self._right_padding,
            north_padding=0,
            south_padding=0,
            group_number=1,
            weight=conv_weight,
            bias=None,
        )

        return x

    def forward(self, x, cache=None):
        if cache is not None:
            x = self.builder.make_stateful_causalconv_cache_wrapper(
                x, cache_name=x.name + "/cache", cache_len=30  # [TODO] Check cache_len
            )
        else:
            x = self.builder.make_unsqueeze(x, axis=1)
            x = self.builder.make_transpose(x, (0, 1, 3, 2))
            x = self.make_identity_conv(x)
            x = self.builder.make_transpose(x, (0, 1, 3, 2))
            x = self.builder.make_squeeze(
                x, squeeze_axes=(1,)
            )  # [1, 1, 512, 2672] -> [1, 512, 2672]
        # qbcompiler: [1, 512, 2642]
        # original: [1, 512, 2672]
        # [TODO] Check dynamic shape
        x = self.builder.make_transpose(
            x, (0, 2, 1)
        )  # [1, 512, 2672] -> [1, 2672, 512]
        x.dataformat = DataFormat.NXC
        x = self.builder.make_conv1d(
            x,
            in_channels=self.in_channels,
            out_channels=self.out_channels,
            kernel=self.kernel_size,
            stride=self.stride,
            dilation=self.dilation,
            west_padding=0,
            east_padding=0,
            group_number=self.groups,
            weight=self.weight,
            bias=self.bias,
            opname=self.module_name,
        )
        x = self.builder.make_transpose(
            x, (0, 2, 1)
        )  # [1, 2642, 512] -> [1, 512, 2642]
        if cache is None:
            return x
        else:
            return x, cache

    @property
    def target_module_type(self) -> Type:
        return nemo_causal_convs.CausalConv1D
