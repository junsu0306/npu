from typing import Any, Optional, Type, Tuple

from qbcompiler.model_dict.parser.backend.misc.nemo.collections.base import ModelingNemoBase
from qbcompiler.model_dict.common.parserabc import MobilintParserOutputs
from qbcompiler.model_dict.common import (
    ModelDict,
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)


class LSTMDropout(ModelingNemoBase):
    __slots__ = ("lstm",)

    def forward(
        self,
        x: ActivationSpec,
        h: Optional[Tuple[ActivationSpec, ActivationSpec]] = None,
    ) -> Tuple[ActivationSpec, Tuple[ActivationSpec, ActivationSpec]]:
        x, h = self.lstm(x, h)

        return x, h
