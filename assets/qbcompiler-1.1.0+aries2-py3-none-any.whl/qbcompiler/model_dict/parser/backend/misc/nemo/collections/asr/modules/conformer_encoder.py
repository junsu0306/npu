from typing import Any, Optional, Type
import torch
import numpy

from qbcompiler.model_dict.parser.backend.misc.nemo.collections.base import ModelingNemoBase
from qbcompiler.model_dict.common.parserabc import MobilintParserOutputs
from qbcompiler.model_dict.common import (
    ModelDict,
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.parser.util.subgraph_builder import SubGraphBuilder
from qbcompiler.model_dict.parser.backend.hf.util import (
    DefaultInputsCaptureContainer,
    InputCaptureCtxManager,
)

import nemo.collections.asr.modules.conformer_encoder as nemo_conformer_encoder


class ConformerEncoder(ModelingNemoBase):
    __slots__ = (
        "att_context_size",
        "layer_drop_probs",
        "layers",
        "pos_enc",
        "out_proj",
        "pos_emb_max_len",
    )

    def __init__(self, model: Any, module_name: str = "", make_func=None):
        super().__init__(model, module_name, make_func=make_func)
        self.set_max_audio_length(self.pos_emb_max_len)

    def set_max_audio_length(self, max_audio_length):
        self.max_audio_length = max_audio_length
        self.pos_enc.extend_pe(max_audio_length)

    def update_max_seq_length(self, seq_length):
        if seq_length > self.max_audio_length:
            self.set_max_audio_length(seq_length)

    def forward_internal(
        self,
        audio_signal: ActivationSpec = None,
        length: ActivationSpec = None,
        cache_last_channel=None,
        cache_last_time=None,
        cache_last_channel_len=None,
    ):
        cur_att_context_size = self.att_context_size
        self.update_max_seq_length(
            seq_length=audio_signal.get_act_src_shape()[2]._value
        )
        audio_signal = self.builder.make_transpose(
            audio_signal, (0, 2, 1)
        )  # [1, 80, 10568] -> [1, 10568, 80]
        audio_signal = self.pre_encode(
            x=audio_signal, lengths=length
        )  # [1, 10568, 80] -> [1, 2642, 512]

        audio_signal, pos_emb = self.pos_enc(
            x=audio_signal, cache_len=0
        )  # [1, 2642, 512] -> [1, 2642, 512]

        for lth, (drop_prob, layer) in enumerate(
            zip(self.layer_drop_probs, self.layers)
        ):
            original_signal = audio_signal
            if cache_last_channel is not None:
                cache_last_channel_cur = cache_last_channel[lth]
                cache_last_time_cur = cache_last_time[lth]
            else:
                cache_last_channel_cur = None
                cache_last_time_cur = None

            audio_signal = layer(
                x=audio_signal,
                att_mask=None,
                pos_emb=pos_emb,
                pad_mask=None,
                cache_last_channel=cache_last_channel_cur,
                cache_last_time=cache_last_time_cur,
            )  # [1, 2642, 512] -> [1, 2642, 512]

        if self.out_proj is not None:
            audio_signal = self.out_proj(audio_signal)

        audio_signal = self.builder.make_transpose(
            audio_signal, (0, 2, 1)
        )  # [1, 2642, 512] -> [1, 512, 2642]

        return audio_signal, None

    def forward(
        self,
        audio_signal: ActivationSpec = None,
        length: ActivationSpec = None,
        cache_last_channel=None,
        cache_last_time=None,
        cache_last_channel_len=None,
    ):
        return self.forward_internal(
            audio_signal=audio_signal,
            length=length,
            cache_last_channel=cache_last_channel,
            cache_last_time=cache_last_time,
            cache_last_channel_len=cache_last_channel_len,
        )

    @property
    def target_module_type(self) -> Type:
        return nemo_conformer_encoder.ConformerEncoder
