from typing import Any, Optional, Type
import torch
import numpy

from qbcompiler.model_dict.parser.backend.misc.nemo.collections.base import ModelingNemoBase
from qbcompiler.model_dict.common import ActivationSpec
import nemo.collections.asr.parts.utils.activations as nemo_activations


class Swish(ModelingNemoBase):
    def forward(self, x: ActivationSpec) -> ActivationSpec:
        return self.builder.make_swish(x)

    @property
    def target_module_type(self) -> Type:
        return nemo_activations.Swish
