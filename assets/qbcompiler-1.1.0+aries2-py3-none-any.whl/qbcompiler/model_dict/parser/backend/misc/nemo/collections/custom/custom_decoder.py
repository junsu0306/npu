import torch
import torch.nn as nn


class NeMoSingleStepDecoder(nn.Module):
    def __init__(self, joint):
        super(NeMoSingleStepDecoder, self).__init__()
        self.pred = joint.pred
        self.enc = joint.enc
        self.joint_net = joint.joint_net

    def forward(self, f, g):
        # x, (h, c) = self.lstm(x, (h, c))
        enc = self.enc(f)
        pred = self.pred(g)
        inp = enc + pred

        x = self.joint_net(inp)
        return x
