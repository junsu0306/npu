from typing import Any, Optional, Type
import torch
import numpy

from qbcompiler.model_dict.parser.backend.misc.nemo.collections.base import ModelingNemoBase
from qbcompiler.model_dict.common.parserabc import MobilintParserOutputs
from qbcompiler.model_dict.common import (
    ModelDict,
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.parser.util.subgraph_builder import SubGraphBuilder
from qbcompiler.model_dict.parser.backend.hf.util import (
    DefaultInputsCaptureContainer,
    InputCaptureCtxManager,
)

import nemo.collections.asr.modules.conv_asr as nemo_conv_asr


class ConvASRDecoder(ModelingNemoBase):
    __slots__ = ("decoder_layers",)

    def forward(self, encoder_output):
        return self.decoder_layers(encoder_output)
