from typing import Any, Optional, Type
import torch
import numpy

from qbcompiler.model_dict.parser.backend.misc.nemo.collections.base import ModelingNemoBase
from qbcompiler.model_dict.common.parserabc import MobilintParserOutputs
from qbcompiler.model_dict.common import (
    ModelDict,
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.parser.util.subgraph_builder import SubGraphBuilder
from qbcompiler.model_dict.parser.backend.hf.util import (
    DefaultInputsCaptureContainer,
    InputCaptureCtxManager,
)

import nemo.collections.asr.parts.submodules.conformer_modules as nemo_conformer_layer


class ConformerLayer(ModelingNemoBase):
    __slots__ = (
        "self_attention_model",
        "conv",
        "feed_forward1",
        "feed_forward2",
        "norm_conv",
        "norm_feed_forward1",
        "norm_feed_forward2",
        "norm_out",
        "self_attn",
        "fc_factor",
        "norm_self_att",
    )

    def forward(
        self,
        x: ActivationSpec,
        att_mask=None,
        pos_emb=None,
        pad_mask=None,
        cache_last_channel=None,
        cache_last_time=None,
    ):
        residual = x
        x = self.norm_feed_forward1(x)  # [1, 2642, 512]
        layer_name = ".".join(x.name.split(".")[:2])
        x = self.feed_forward1(x)
        x = self.builder.make_mul(x, self.fc_factor)
        residual = self.builder.make_add(residual, x, opname=f"{layer_name}/res_0")

        x = self.norm_self_att(residual)  # [1, 2642, 512]
        if self.self_attention_model == "rel_pos":
            x = self.self_attn(
                query=x,
                key=x,
                value=x,
                mask=att_mask,
                pos_emb=pos_emb,
                cache=cache_last_channel,
            )
        else:
            raise NotImplementedError("Not Implemented for other attention model types")

        residual = self.builder.make_add(residual, x, opname=f"{layer_name}/res_1")
        x = self.norm_conv(residual)
        x = self.conv(x, pad_mask=pad_mask, cache=cache_last_time)
        residual = self.builder.make_add(
            residual, x, opname=f"{layer_name}/res_2"
        )  # [1, 2642, 512]

        x = self.norm_feed_forward2(residual)  # [1, 2642, 512]
        x = self.feed_forward2(x)  # [1, 2642, 512]
        x = self.builder.make_mul(x, self.fc_factor)  # [1, 2642, 512]
        x = self.builder.make_add(
            residual, x, opname=f"{layer_name}/res_3"
        )  # [1, 2642, 512]

        x = self.norm_out(x)

        if cache_last_channel is None:
            return x
        else:
            raise NotImplementedError("Not Implemented for cache_last_channel")

    @property
    def target_module_type(self) -> Type:
        return nemo_conformer_layer.ConformerLayer


class ConformerFeedForward(ModelingNemoBase):
    __slots__ = ("linear1", "linear2", "activation", "dropout")

    def forward(self, x):
        x = self.linear1(x)
        x = self.activation(x)
        x = self.dropout(x)
        x = self.linear2(x)
        return x

    @property
    def target_module_type(self) -> Type:
        return nemo_conformer_layer.ConformerFeedForward


class ConformerConvolution(ModelingNemoBase):
    __slots__ = (
        "pointwise_conv1",
        "pointwise_activation",
        "depthwise_conv",
        "norm_type",
        "batch_norm",
        "activation",
        "pointwise_conv2",
    )

    def forward(self, x, pad_mask=None, cache=None):
        x = self.builder.make_transpose(
            x, (0, 2, 1)
        )  # [1, 1714, 512] -> [1, 512, 1714]
        x = self.pointwise_conv1(x)  # [1, 512, 1714] -> [1, 1024, 1714]

        if self.pointwise_activation == "glu_":
            x = self.builder.make_glu(x, dim=1)
        else:
            x = self.pointwise_activation(x)

        x = self.depthwise_conv(x, cache=cache)
        if cache is not None:
            x, cache = x

        if self.norm_type == "layer_norm":
            x = self.builder.make_transpose(
                x, (0, 2, 1)
            )  # [1, 512, 1714] -> [1, 1714, 512]
            x = self.batch_norm(x)
            x = self.builder.make_transpose(x, (0, 2, 1))
        else:
            x = self.batch_norm(x)

        x = self.activation(x)
        x = self.pointwise_conv2(x)
        x = self.builder.make_transpose(
            x, (0, 2, 1)
        )  # [1, 512, 1714] -> [1, 1714, 512]

        if cache is None:
            return x
        else:
            return x, cache

    @property
    def target_module_type(self) -> Type:
        return nemo_conformer_layer.ConformerConvolution
