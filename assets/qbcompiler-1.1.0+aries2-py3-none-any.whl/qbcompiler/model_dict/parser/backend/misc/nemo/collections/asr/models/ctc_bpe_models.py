from typing import Any, Optional, Type
import torch
import numpy

from qbcompiler.model_dict.parser.backend.misc.nemo.collections.base import ModelingNemoBase
from qbcompiler.model_dict.parser.backend.misc.wenet.sample_data import get_sample_data
from qbcompiler.model_dict.common.parserabc import MobilintParserOutputs
from qbcompiler.model_dict.common import (
    ModelDict,
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.parser.util.subgraph_builder import SubGraphBuilder
from qbcompiler.model_dict.parser.backend.hf.util import (
    DefaultInputsCaptureContainer,
    InputCaptureCtxManager,
)

import nemo.collections.asr.models.ctc_bpe_models as nemo_ctc_bpe_models


class EncDecCTCModelBPE(ModelingNemoBase):
    """Encoder decoder CTC-based models with Byte Pair Encoding."""

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return nemo_ctc_bpe_models.EncDecCTCModelBPE

    # Assume that "processed_signal" is provided for forward pass.
    # "preprocessor" is processed on the CPU.
    def forward(
        self,
        input_signal: ActivationSpec = None,
        input_signal_length: ActivationSpec = None,
        processed_signal: ActivationSpec = None,
        processed_signal_length: ActivationSpec = None,
    ):
        has_input_signal = input_signal is not None and input_signal_length is not None
        has_processed_signal = (
            processed_signal is not None and processed_signal_length is not None
        )
        if (has_input_signal ^ has_processed_signal) == False:
            raise ValueError(
                f"{self} Arguments ``input_signal`` and ``input_signal_length`` are mutually exclusive "
                " with ``processed_signal`` and ``processed_signal_len`` arguments."
            )

        if not has_processed_signal:
            processed_signal, processed_signal_length = self.preprocessor(
                input_signal=input_signal,
                length=input_signal_length,
            )

        # processed_signal: [1, 80, 10568]
        # processed_signal_length: [1]

        encoder_output = self.encoder(
            audio_signal=processed_signal, length=processed_signal_length
        )
        encoded = encoder_output[0]
        encoded_len = encoder_output[1]
        log_probs = self.decoder(encoder_output=encoded)
        greedy_predictions = log_probs.argmax(dim=-1, keepdim=False)
