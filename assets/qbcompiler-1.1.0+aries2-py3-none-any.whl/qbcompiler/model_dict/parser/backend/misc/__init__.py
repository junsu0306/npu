from qbcompiler.model_dict.parser.backend.misc.parser import MiscModelParser


def get_parser(model, **kwargs):
    return MiscModelParser(model=model, **kwargs)
