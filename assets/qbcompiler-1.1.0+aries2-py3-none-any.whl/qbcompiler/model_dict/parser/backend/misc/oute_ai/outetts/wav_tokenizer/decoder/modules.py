import abc
from typing import Type, Optional

import outetts.wav_tokenizer.decoder.modules as outetts_wav_tokenizer_decoder_modules
import torch

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase


class ModulesBase(ModuleParserBase, abc.ABC):
    __slots__ = ()


class AdaLayerNorm(ModulesBase):
    __slots__ = ("scale", "shift", "dim", "eps")

    @property
    def target_module_type(self) -> Type:
        return outetts_wav_tokenizer_decoder_modules.AdaLayerNorm

    def forward(
        self, x: ActivationSpec, cond_embedding_id: ActivationSpec | torch.Tensor
    ) -> ActivationSpec:
        scale = self.scale(cond_embedding_id)
        shift = self.shift(cond_embedding_id)
        # x = nn.functional.layer_norm(x, (self.dim,), eps=self.eps)
        # x = x * scale + shift

        normalized_shape = (self.dim,)
        if scale.shape == (1, self.dim) and shift.shape == (1, self.dim):
            x = self.builder.make_layernorm(
                x,
                normalized_shape,
                epsilon=self.eps,
                scale=scale.squeeze(0),
                bias=shift.squeeze(0),
            )

        else:
            x = self.builder.make_layernorm(
                x,
                normalized_shape,
                epsilon=self.eps,
                scale=torch.ones(normalized_shape),
                bias=torch.zeros(normalized_shape),
            )
            x = self.builder.make_add(self.builder.make_mul(x, scale), shift)
        return x


class ConvNeXtBlock(ModulesBase):
    __slots__ = ("dwconv", "adanorm", "norm", "pwconv1", "act", "pwconv2", "gamma")

    @property
    def target_module_type(self) -> Type:
        return outetts_wav_tokenizer_decoder_modules.ConvNeXtBlock

    def forward(
        self, x: ActivationSpec, cond_embedding_id: Optional[ActivationSpec] = None
    ) -> ActivationSpec:
        residual = x  # torch.Size([1, 768, 280])
        x = self.dwconv(x)  # torch.Size([1, 768, 280])
        # x = x.transpose(1, 2)  # (B, C, T) -> (B, T, C) #torch.Size([1, 280, 768])
        x = self.builder.make_transpose(x, (0, 2, 1))
        if self.adanorm:
            # todo: check cond_embedding_id value
            assert cond_embedding_id is not None
            x = self.norm(x, cond_embedding_id)
        else:
            raise NotImplementedError
            # x = self.norm(x)
        x = self.pwconv1(x)  # torch.Size([1, 280, 2304])
        x = self.act(x)
        x = self.pwconv2(x)  # torch.Size([1, 280, 768])
        if self.gamma is not None:
            # x = self.gamma * x  # torch.Size([1, 280, 768])
            x = self.builder.make_mul(self.gamma, x)
        # x = x.transpose(1, 2)  # (B, T, C) -> (B, C, T) #torch.Size([1, 768, 280])
        x = self.builder.make_transpose(x, (0, 2, 1))

        # x = residual + x #torch.Size([1, 768, 280])
        x = self.builder.make_add(residual, x)
        return x
