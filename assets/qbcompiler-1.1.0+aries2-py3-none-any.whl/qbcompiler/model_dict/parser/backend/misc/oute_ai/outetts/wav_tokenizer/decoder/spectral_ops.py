import abc
from typing import Type

import outetts.wav_tokenizer.decoder.spectral_ops as outetts_wav_tokenizer_decoder_spectral_ops

from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase


class SpectralOpsBase(ModuleParserBase, abc.ABC):
    __slots__ = ()


class ISTFT(SpectralOpsBase):
    __slots__ = ("padding", "n_fft", "win_length", "hop_length", "window")

    @property
    def target_module_type(self) -> Type:
        return outetts_wav_tokenizer_decoder_spectral_ops.ISTFT
