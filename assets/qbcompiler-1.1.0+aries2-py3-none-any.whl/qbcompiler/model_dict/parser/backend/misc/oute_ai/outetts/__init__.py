import pathlib

import numpy
import torch

from qbcompiler.model_dict.common import ModelDict
from qbcompiler.model_dict.common import DimValue, ActivationSpec, DataFormat
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.common.parserabc import (
    MobilintParserInputs,
    MobilintParserOutputs,
)
from qbcompiler.model_dict.parser.backend.modeling_torch.util import MakeDynamicObject
from qbcompiler.model_dict.parser.util.subgraph_builder import SubGraphBuilder

# fmt:off
_OUTETTS_BASE_PATH = "qbcompiler/model_dict/parser/backend/misc/oute_ai/outetts"
_DYN_MODULE_PATH = {
    "decoder.models"             : _OUTETTS_BASE_PATH + "/wav_tokenizer/decoder/models",
    "decoder.modules"            : _OUTETTS_BASE_PATH + "/wav_tokenizer/decoder/modules",
    "decoder.heads"              : _OUTETTS_BASE_PATH + "/wav_tokenizer/decoder/heads",
    "decoder.spectral_ops"       : _OUTETTS_BASE_PATH + "/wav_tokenizer/decoder/spectral_ops",
    "outetts.wav_tokenizer.model": _OUTETTS_BASE_PATH + "/wav_tokenizer/model",
}
# fmt:on


def _make_feed_dict():
    file_path = pathlib.Path(__file__).resolve()
    data_path = file_path.parent.joinpath("data/features_input.pt")
    features_input = torch.load(data_path)
    bandwidth_id = torch.tensor([0])

    return {"features_input": features_input, "bandwidth_id": bandwidth_id}


def parse_wav_decoder(
    model,
    parser_inputs: MobilintParserInputs,
    seq_len=277,
    make_value_dict=True,
    feed_dict=None,
    **kwargs
):
    if feed_dict is None:
        feed_dict = _make_feed_dict()

    if "features_input" in feed_dict:
        seq_len = feed_dict["features_input"].size(-1)

    if "bandwidth_id" in feed_dict:
        bandwidth_id = feed_dict["bandwidth_id"]
    else:
        bandwidth_id = torch.tensor([0])
        feed_dict["bandwidth_id"] = bandwidth_id

    const_dict = {}
    wav_decoder_builder = SubGraphBuilder(
        global_weight_dict=const_dict, builder_name="wav_decoder"
    )
    seq_len = DimValue(seq_len, dynamic=True)

    features_input = ActivationSpec(
        name="features_input",
        src_shape=(1, 512, seq_len),
        dtype="float32",
        dataformat=DataFormat.UNKNOWN,
    )
    wav_decoder_builder.add_activation(features_input)
    wav_decoder_builder.make_input(features_input)

    module = MakeDynamicObject(dynamic_module_path=_DYN_MODULE_PATH)(model)
    module.set_builder(wav_decoder_builder, recursive=True)

    audio_output = module(features_input, bandwidth_id=bandwidth_id)

    wav_decoder_builder.make_output(audio_output)

    sg = wav_decoder_builder.build()

    md = ModelDict()
    md.subgraphs = [sg]
    for idx, sg in enumerate(md.subgraphs):
        sg.idx = idx
    md.graph_order = [0]
    for iidx in sg.inputs:
        inact = sg.activations[iidx]
        md.inputs.append(inact.name)
    for oidx in sg.outputs:
        outact = sg.activations[oidx]
        md.outputs.append(outact.name)
    md.model_backend = "outetts"
    md.set_main_sg(0)

    if make_value_dict:
        value_dict = {}
        value_dict["features_input"] = feed_dict["features_input"]
        value_dict["bandwidth_id"] = feed_dict["bandwidth_id"]
        module.set_value_dict(value_dict)
        module.register_forward_hook()

        model_device = next(model.parameters()).device
        fd = {}
        for k, v in feed_dict.items():
            fd[k] = v.to(model_device)

        module.torch_compute(**fd)
        _value_dict = ValueDict()
        for k, v in value_dict.items():
            if isinstance(v, torch.Tensor):
                if v.dtype == torch.bfloat16:
                    v = v.to(torch.float32)
                v = v.detach().cpu().numpy()
            if isinstance(v, numpy.ndarray):
                _value_dict[k] = v
        value_dict = _value_dict
    else:
        value_dict = ValueDict()

    out = MobilintParserOutputs()

    out.model_dict = md
    out.const_dict = const_dict
    out.value_dict = value_dict

    return out
