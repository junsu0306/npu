import abc
from typing import Any, Type, Optional

import outetts.wav_tokenizer.decoder.models as outetts_wav_tokenizer_decoder_models

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase


class ModelsBase(ModuleParserBase, abc.ABC):
    __slots__ = ()


class Backbone(ModelsBase, abc.ABC):
    @property
    def target_module_type(self) -> Type:
        return outetts_wav_tokenizer_decoder_models.Backbone


def nonlinearity(x, builder):
    # swish
    # return x * torch.sigmoid(x)
    return builder.make_mul(x, builder.make_sigmoid(x))


class VocosBackbone(Backbone):
    __slots__ = (
        "embed",
        "pos_net",
        "adanorm",
        "norm",
        "convnext",
        "final_layer_norm",
    )

    @property
    def target_module_type(self) -> Type:
        return outetts_wav_tokenizer_decoder_models.VocosBackbone

    def forward(
        self, x: ActivationSpec, bandwidth_id: Optional[ActivationSpec] = None
    ) -> ActivationSpec:
        # x: torch.Size([1, 512, 277])
        x = self.embed(x)  # torch.Size([1, 768, 277])
        x = self.pos_net(x)
        if self.adanorm:
            assert bandwidth_id is not None
            # x = self.norm(x.transpose(1, 2), cond_embedding_id=bandwidth_id)  # torch.Size([1, 277, 768])
            x = self.norm(
                self.builder.make_transpose(x, (0, 2, 1)),
                cond_embedding_id=bandwidth_id,
            )
        else:
            raise NotImplementedError
            # x = self.norm(x.transpose(1, 2))

        # x = x.transpose(1, 2) # torch.Size([1, 768, 277])
        x = self.builder.make_transpose(x, (0, 2, 1))
        for conv_block in self.convnext:
            x = conv_block(x, cond_embedding_id=bandwidth_id)
        # x = self.final_layer_norm(x.transpose(1, 2))  #torch.Size([1, 280, 768])
        x = self.builder.make_transpose(x, (0, 2, 1))
        x = self.final_layer_norm(x)
        return x


class ResnetBlock(ModelsBase):
    __slots__ = (
        "norm1",
        "conv1",
        "norm2",
        "conv2",
        "dropout",
        "in_channels",
        "out_channels",
    )

    @property
    def target_module_type(self) -> Type:
        return outetts_wav_tokenizer_decoder_models.ResnetBlock

    def forward(self, x, temb=None):
        h = x  # torch.Size([1, 768, 277])
        h = self.norm1(h)  # torch.Size([1, 768, 277])
        h = nonlinearity(h, self.builder)  # torch.Size([1, 768, 277])
        h = self.conv1(h)  # torch.Size([1, 768, 277])

        if temb is not None:
            raise NotImplementedError
            # h = h + self.temb_proj(nonlinearity(temb))[:, :, None, None]

        h = self.norm2(h)  # torch.Size([1, 768, 277])
        h = nonlinearity(h, self.builder)  # torch.Size([1, 768, 277])
        h = self.dropout(h)  # torch.Size([1, 768, 277])
        h = self.conv2(h)  # torch.Size([1, 768, 277])

        if self.in_channels != self.out_channels:
            raise NotImplementedError
            # if self.use_conv_shortcut:
            #     x = self.conv_shortcut(x)
            # else:
            #     x = self.nin_shortcut(x)

        return self.builder.make_add(x, h)


class AttnBlock(ModelsBase):
    __slots__ = ("norm", "q", "k", "v", "proj_out")

    @property
    def target_module_type(self) -> Type:
        return outetts_wav_tokenizer_decoder_models.AttnBlock

    def forward(self, x):
        h_ = x  # torch.Size([1, 768, 280])
        h_ = self.norm(h_)  # torch.Size([1, 768, 280])
        q = self.q(h_)  # torch.Size([1, 768, 280])
        k = self.k(h_)  # torch.Size([1, 768, 280])
        v = self.v(h_)  # torch.Size([1, 768, 280])

        # compute attention
        b, c, h = q.get_act_src_shape()
        # q = q.permute(0, 2, 1)  # b,hw,c # torch.Size([1, 280, 768])
        q = self.builder.make_transpose(q, (0, 2, 1))
        # w_ = torch.bmm(q, k)  # b,hw,hw    w[b,i,j]=sum_c q[b,i,c]k[b,c,j] # torch.Size([1, 280, 280])
        w_ = self.builder.make_torch_bmm(q, k)
        # w_ = w_ * (int(c) ** (-0.5))
        w_ = self.builder.make_mul(w_, (int(c) ** (-0.5)))
        # w_ = torch.nn.functional.softmax(w_, dim=2)
        w_ = self.builder.make_softmax(w_, axis=2)

        # attend to values
        # w_ = w_.permute(0, 2, 1)  # b,hw,hw (first hw of k, second of q)  # torch.Size([1, 280, 768])
        w_ = self.builder.make_transpose(w_, (0, 2, 1))
        # h_ = torch.bmm(v, w_)  # b, c,hw (hw of q) h_[b,c,j] = sum_i v[b,c,i] w_[b,i,j] # torch.Size([1, 768, 280])
        h_ = self.builder.make_torch_bmm(v, w_)

        h_ = self.proj_out(h_)  # torch.Size([1, 768, 280])

        return self.builder.make_add(x, h_)
