import abc
from typing import Type

import outetts.wav_tokenizer.decoder.heads as outetts_wav_tokenizer_decoder_heads

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase


class HeadsBase(ModuleParserBase, abc.ABC):
    __slots__ = ()


class ISTFTHead(HeadsBase):
    __slots__ = ("out", "istft")

    @property
    def target_module_type(self) -> Type:
        return outetts_wav_tokenizer_decoder_heads.ISTFTHead

    def forward(self, x: ActivationSpec) -> ActivationSpec:
        # x = self.out(x).transpose(1, 2)  # torch.Size([1, 1282, 280])
        x = self.builder.make_transpose(self.out(x), (0, 2, 1))

        istft = self.istft
        if istft.padding == "same":
            pad = (istft.win_length - istft.hop_length) // 2
        else:
            raise NotImplementedError
        B, N, T = x.get_act_src_shape()
        output_size = (T - 1) * istft.hop_length + istft.win_length - 2 * pad

        def custom_fn(x):
            import torch

            mag, p = x.chunk(2, dim=1)
            mag = torch.exp(mag)
            mag = torch.clip(
                mag, max=1e2
            )  # safeguard to prevent excessively large magnitudes
            # wrapping happens here. These two lines produce real and imaginary value
            x = torch.cos(p)
            y = torch.sin(p)
            # recalculating phase here does not produce anything new
            # only costs time
            # phase = torch.atan2(y, x)
            # S = mag * torch.exp(phase * 1j)
            # better directly produce the complex value
            S = mag * (x + 1j * y)
            audio = self.reference_model.istft(S)
            return audio

        audio = self.builder.make_custom_singleop(
            x,
            output_src_shape=(1, output_size),
            output_dtype=x.dtype,
            content="ISTFTHeadPost",
            custom_fn=custom_fn,
        )

        # mag, p = x.chunk(
        #     2, dim=1
        # )  # torch.Size([1, 641, 280]), torch.Size([1, 641, 280])
        # mag = torch.exp(mag)
        # mag = torch.clip(
        #     mag, max=1e2
        # )  # safeguard to prevent excessively large magnitudes
        # # wrapping happens here. These two lines produce real and imaginary value
        # x = torch.cos(p)
        # y = torch.sin(p)
        # # recalculating phase here does not produce anything new
        # # only costs time
        # # phase = torch.atan2(y, x)
        # # S = mag * torch.exp(phase * 1j)
        # # better directly produce the complex value
        # S = mag * (x + 1j * y)
        # audio = self.istft(S)
        return audio
