import abc
from typing import Any

import outetts.wav_tokenizer.model as outetts_wav_tokenizer_model
import torch

from qbcompiler.model_dict.common import ModelDict
from qbcompiler.model_dict.common import ActivationSpec, DataFormat, DimValue
from qbcompiler.model_dict.common.parserabc import MobilintParserOutputs
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase
from qbcompiler.model_dict.parser.util.subgraph_builder import SubGraphBuilder


class ModelBase(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(self, model: Any, module_name: str = "", make_module_func=None):
        if make_module_func is None:
            raise Exception
        super().__init__(model, module_name, make_module_func=make_module_func)


class WavDecoder(ModelBase):
    __slots__ = ("backbone", "head")

    @property
    def target_module_type(self):
        return outetts_wav_tokenizer_model.WavDecoder

    def forward(self, features_input, **kwargs):
        """Decode features to audio"""
        x = self.backbone(features_input, **kwargs)
        audio_output = self.head(x)
        return audio_output

    def parse(self, make_value_dict=False, **kwargs):
        const_dict = {}
        wav_decoder_builder = SubGraphBuilder(
            global_weight_dict=const_dict, builder_name="WavDecoder"
        )
        self.set_builder(wav_decoder_builder)

        # torch.Size([1, 512, 266])
        seq_len = DimValue(277, dynamic=True)
        features_input = ActivationSpec(
            name="features_input",
            src_shape=(1, 512, seq_len),
            dtype="float32",
            dataformat=DataFormat.UNKNOWN,
        )
        wav_decoder_builder.add_activation(features_input)
        wav_decoder_builder.make_input(features_input)

        bandwidth_id = torch.tensor([0])
        audio_output = self(features_input, bandwidth_id=bandwidth_id)

        wav_decoder_builder.make_output(audio_output)

        sg = wav_decoder_builder.build()

        md = ModelDict()
        md.subgraphs = [sg]
        for idx, sg in enumerate(md.subgraphs):
            sg.idx = idx
        md.graph_order = [0]
        for iidx in sg.inputs:
            inact = sg.activations[iidx]
            md.inputs.append(inact.name)
        for oidx in sg.outputs:
            outact = sg.activations[oidx]
            md.outputs.append(outact.name)
        md.model_backend = "outetts"
        md.set_main_sg(0)

        out = MobilintParserOutputs()

        out.model_dict = md
        out.const_dict = const_dict
        out.value_dict = {}

        return out
