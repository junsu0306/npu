from typing import Any, Tuple, Union, Type

import wenet.transformer.embedding as wenet_transformer_embedding

from qbcompiler.model_dict.common import (
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)
from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.base import (
    ModelingWeNetBase,
)


class PositionalEncoding(ModelingWeNetBase):
    """Positional encoding.

    :param int d_model: embedding dim
    :param float dropout_rate: dropout rate
    :param int max_len: maximum input length

    PE(pos, 2i)   = sin(pos/(10000^(2i/dmodel)))
    PE(pos, 2i+1) = cos(pos/(10000^(2i/dmodel)))
    """

    __slots__ = ("d_model", "xscale", "dropout", "max_len", "pe")

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_embedding.PositionalEncoding

    def forward(
        self, x: ActivationSpec, offset: Union[int, ActivationSpec] = 0
    ) -> Tuple[ActivationSpec, ActivationSpec]:
        """Add positional encoding.

        Args:
            x (ActivationSpec): Input. Its shape is (batch, time, ...)
            offset (int, torch.tensor): position offset

        Returns:
            ActivationSpec: Encoded tensor. Its shape is (batch, time, ...)
            ActivationSpec: for compatibility to RelPositionalEncoding
        """

        num_beams = 10
        max_token_len = DimValue(
            int(x.get_act_src_shape()[1] / num_beams), dynamic=True
        )
        ch = x.get_act_src_shape()[2]

        pos_emb = self.position_encoding(offset, x.get_act_src_shape()[1], False)
        x = self.builder.make_mul(x, self.xscale, opname=x.name + "/mul")
        x = self.builder.make_reshape(x, shape=(1, num_beams, max_token_len, ch))
        # [Question]
        # qbcompiler
        # x: [1, 10, 20, 256] / pos_emb: [1, 1, 20, 256] -> [1, 10, 20, 256] (BroadCast Add ??)
        # Origin Source Code
        # x: [10, 20, 256] / pos_emb: [1, 20, 256] -> [10, 20, 256]
        x = self.builder.make_add(x, pos_emb, opname=x.name + "/add")
        # [1, 10, 20, 256]
        return self.dropout(x), self.dropout(pos_emb)

    def position_encoding(
        self, offset: Union[int, ActivationSpec], size: int, apply_dropout: bool = True
    ) -> ActivationSpec:
        if isinstance(offset, int):
            assert offset + size <= self.max_len
            size /= 10  # 10 is for candidate num. fix to 10.
            # self.pe : (1, 5000, 256) tensor
            pe = self.builder.make_inputconst(self.pe[:, None, :, :])
            pos_emb = self.builder.make_dynamic_slice_input_const(
                pe, axis=(2,), start=(0,), end=(20,), step=(1,), mod=0
            )

        elif (
            isinstance(offset, ActivationSpec) and len(offset.get_act_src_shape()) == 1
        ):  # scalar
            raise NotImplementedError()
        else:  # for batched streaming decoding on GPU
            raise NotImplementedError()

        if apply_dropout:
            pos_emb = self.dropout(pos_emb)
        return pos_emb


class RelPositionalEncoding(PositionalEncoding):
    """Relative positional encoding module.
    See : Appendix B in https://arxiv.org/abs/1901.02860
    Args:
        d_model (int): Embedding dimension.
        dropout_rate (float): Dropout rate.
        max_len (int): Maximum input length.
    """

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_embedding.RelPositionalEncoding

    def forward(
        self, x: ActivationSpec, offset: Union[int, ActivationSpec] = 0
    ) -> Tuple[ActivationSpec, ActivationSpec]:
        """Compute positional encoding.
        Args:
            x (ActivationSpec): Input tensor (batch, time, `*`).
        Returns:
            ActivationSpec: Encoded tensor (batch, time, `*`).
            ActivationSpec: Positional embedding tensor (1, time, `*`).
        """
        # x = x * self.xscale
        x = self.builder.make_mul(x, self.xscale, opname=x.name + "/mul")
        # pos_emb = self.position_encoding(offset, x.get_act_src_shape()[1], False)
        return self.dropout(x), None
