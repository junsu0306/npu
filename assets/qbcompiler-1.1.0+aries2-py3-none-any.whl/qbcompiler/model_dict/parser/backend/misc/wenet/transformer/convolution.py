from typing import Any, Tuple, Type
import wenet.transformer.convolution as wenet_transformer_convolution

from qbcompiler.model_dict.common import (
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
)
from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.base import (
    ModelingWeNetBase,
)


class ConvolutionModule(ModelingWeNetBase):
    """ConvolutionModule in Conformer model."""

    __slots__ = (
        "pointwise_conv1",
        "depthwise_conv",
        "pointwise_conv2",
        "activation",
        "norm",
        "lorder",
        "use_layer_norm",
    )

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_convolution.ConvolutionModule

    def forward(
        self,
        x: ActivationSpec,
        mask_pad: ActivationSpec,
        cache: ActivationSpec,
    ) -> Tuple[ActivationSpec, ActivationSpec]:
        """Compute convolution module.
        Args:
            x (ActivationSpec): Input tensor (#batch, time, channels).
            mask_pad (ActivationSpec): used for batch padding (#batch, 1, time),
                (0, 0, 0) means fake mask.
            cache (ActivationSpec): left context cache, it is only
                used in causal convolution (#batch, channels, cache_t),
                (0, 0, 0) meas fake cache.
        Returns:
            ActivationSpec: Output tensor (#batch, time, channels).
        """
        # exchange the temporal dimension and the feature dimension
        x = self.builder.make_transpose(
            x, transpose_axes=(0, 2, 1), opname=f"{x.name}/transpose"
        )  # [1, 30, 256] -> [1, 256, 30]
        # x.dataformat = DataFormat.NCX

        if self.lorder > 0:
            x = self.builder.make_stateful_causalconv_cache_wrapper(
                x, cache_name=x.name + "/cache", cache_len=self.lorder
            )  # [1, 256, 30], [1, 256, 14] -> [1, 256, 44]

            assert x.get_act_src_shape()[2] > self.lorder
            new_cache = None
        else:
            raise NotImplementedError

        x.dataformat = DataFormat.NCX
        # GLU mechanism
        x = self.pointwise_conv1(x)  # [1, 256, 44] -> [1, 512, 44]
        x = self.builder.make_glu(x, dim=1)  # [1, 512, 44] -> [1, 256, 44]

        # 1D Depthwise Conv
        x = self.depthwise_conv(x)  # [1, 256, 44] -> [1, 256, 30]
        if self.use_layer_norm:
            x = self.builder.make_transpose(
                x, transpose_axes=(0, 2, 1), opname=x.name + "/transpose_0"
            )

        x = self.activation(self.norm(x))  # [1, 30, 256]
        if self.use_layer_norm:
            x = self.builder.make_transpose(
                x, transpose_axes=(0, 2, 1), opname=x.name + "/transpose_1"
            )  # [1, 256, 30]

        x.dataformat = DataFormat.NCX
        x = self.pointwise_conv2(x)  # [1, 256, 30]
        x = self.builder.make_transpose(x, transpose_axes=(0, 2, 1))  # [1, 30, 256]

        return x, new_cache
