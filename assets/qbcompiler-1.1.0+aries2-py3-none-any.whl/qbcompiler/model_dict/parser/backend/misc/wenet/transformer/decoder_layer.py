from typing import Optional, Any, Tuple, Type, Dict
import torch, numpy

import wenet.transformer.decoder_layer as wenet_transformer_decoder_layer

from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.base import (
    ModelingWeNetBase,
)
from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.attention import KVCache

from qbcompiler.model_dict.common import (
    ModelDict,
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)


class DecoderLayer(ModelingWeNetBase):
    """Single decoder layer module.

    Args:
        size (int): Input dimension.
        self_attn (torch.nn.Module): Self-attention module instance.
            `MultiHeadedAttention` instance can be used as the argument.
        src_attn (torch.nn.Module): Inter-attention module instance.
            `MultiHeadedAttention` instance can be used as the argument.
            If `None` is passed, Inter-attention is not used, such as
            CIF, GPT, and other decoder only model.
        feed_forward (torch.nn.Module): Feed-forward module instance.
            `PositionwiseFeedForward` instance can be used as the argument.
        dropout_rate (float): Dropout rate.
        normalize_before (bool):
            True: use layer_norm before each sub-block.
            False: to use layer_norm after each sub-block.
    """

    __slots__ = ("norm1", "norm2", "norm3", "dropout", "normalize_before")

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_decoder_layer.DecoderLayer

    def forward(
        self,
        tgt: ActivationSpec,
        tgt_mask: ActivationSpec,
        memory: ActivationSpec,
        memory_mask: ActivationSpec,
        cache: Optional[Dict[str, Optional[KVCache]]] = None,
    ) -> Tuple[ActivationSpec, ActivationSpec, ActivationSpec, ActivationSpec]:
        """Compute decoded features.

        Args:
            tgt (torch.Tensor): Input tensor (#batch, maxlen_out, size).
            tgt_mask (torch.Tensor): Mask for input tensor
                (#batch, maxlen_out).
            memory (torch.Tensor): Encoded memory
                (#batch, maxlen_in, size).
            memory_mask (torch.Tensor): Encoded memory mask
                (#batch, maxlen_in).
            cache (torch.Tensor): cached tensors.
                (#batch, maxlen_out - 1, size).

        Returns:
            torch.Tensor: Output tensor (#batch, maxlen_out, size).
            torch.Tensor: Mask for output tensor (#batch, maxlen_out).
            torch.Tensor: Encoded memory (#batch, maxlen_in, size).
            torch.Tensor: Encoded memory mask (#batch, maxlen_in).

        """
        if cache is not None:
            att_cache = cache["self_att_cache"]
            cross_att_cache = cache["cross_att_cache"]
        else:
            att_cache, cross_att_cache = None, None

        residual = tgt
        if self.normalize_before:
            tgt = self.norm1(tgt)  # [10, 20, 256]

        if att_cache is None:
            tgt_q = tgt
            tgt_q_mask = tgt_mask
            att_cache = None
        else:
            raise NotImplementedError

        x, new_att_cache = self.self_attn(
            tgt_q,
            tgt_q,
            tgt_q,
            tgt_q_mask,
            cache=att_cache,
        )
        if cache is not None:
            cache["self_att_cache"] = new_att_cache
        x = self.builder.make_add(residual, self.dropout(x))
        if not self.normalize_before:
            x = self.norm1(x)
        if self.src_attn is not None:
            residual = x
            if self.normalize_before:
                x = self.norm2(x)
            if cross_att_cache is None:
                # raise NotImplementedError()
                cross_att_cache = None
                # cross_att_cache = (make_inputconst(torch.empty(0, 0, 0,
                #                                0)), make_inputconst(torch.empty(0, 0, 0, 0)))
            if len(memory.get_act_src_shape()) != 4:
                memory = self.builder.make_unsqueeze(
                    memory, axis=0, opname=memory.name + "/unsqueeze"
                )
            memory.dataformat = DataFormat.NHWC
            x, new_cross_cache = self.src_attn(
                x, memory, memory, memory_mask, cache=cross_att_cache
            )
            if cache is not None:
                cache["cross_att_cache"] = new_cross_cache
            x = self.builder.make_add(residual, self.dropout(x))
            if not self.normalize_before:
                x = self.norm2(x)

        residual = x
        if self.normalize_before:
            x = self.norm3(x)
        x = self.builder.make_add(residual, self.dropout(self.feed_forward(x)))
        if not self.normalize_before:
            x = self.norm3(x)

        return x, tgt_mask, memory, memory_mask
