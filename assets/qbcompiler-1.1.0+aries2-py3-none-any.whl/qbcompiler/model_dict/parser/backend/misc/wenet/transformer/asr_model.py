from typing import Any, Optional, Type
import torch
import numpy

from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.base import (
    ModelingWeNetBase,
)
from qbcompiler.model_dict.parser.backend.misc.wenet.sample_data import get_sample_data
from qbcompiler.model_dict.common.parserabc import MobilintParserOutputs
from qbcompiler.model_dict.common import (
    ModelDict,
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.parser.util.subgraph_builder import SubGraphBuilder
from qbcompiler.model_dict.parser.backend.hf.util import (
    DefaultInputsCaptureContainer,
    InputCaptureCtxManager,
)

import wenet.transformer.asr_model as wenet_transformer_asrmodel


class ASRModel(ModelingWeNetBase):
    """CTC-attention hybrid Encoder-Decoder model"""

    __slots__ = (
        "sos",
        "eos",
        "vocab_size",
        "special_tokens",
        "ignore_id",
        "ctc_weight",
        "reverse_weight",
        "apply_non_blank_embedding",
        "encoder",
        "decoder",
        "ctc",
    )

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_asrmodel.ASRModel

    def get_encoder_configs(self, configs):
        num_blocks = configs["encoder_conf"]["num_blocks"]
        num_heads = configs["encoder_conf"]["attention_heads"]
        output_size = configs["encoder_conf"]["output_size"]
        cnn_module_kernel = configs["encoder_conf"].get("cnn_module_kernel", 1)

        return num_blocks, num_heads, output_size, cnn_module_kernel

    def get_encoder_init_cache_mask(self, configs):
        (
            num_blocks,
            num_heads,
            output_size,
            cnn_module_kernel,
        ) = self.get_encoder_configs(configs)
        batch = 1
        if configs["num_decoding_left_chunks"] > 0:
            required_cache_size = (
                configs["chunk_size"] * configs["num_decoding_left_chunks"]
            )
            offset = required_cache_size
            # Real cache
            att_cache = torch.zeros(
                (
                    num_blocks,
                    num_heads,
                    required_cache_size,
                    output_size // num_heads * 2,
                )
            )
            # Real mask
            att_mask = torch.ones(
                (batch, 1, required_cache_size + configs["chunk_size"]),
                dtype=torch.bool,
            )
            att_mask[:, :, :required_cache_size] = 0
        elif configs["num_decoding_left_chunks"] <= 0:
            required_cache_size = -1 if configs["num_decoding_left_chunks"] < 0 else 0
            # Fake cache
            att_cache = torch.zeros(
                (num_blocks, num_heads, 0, output_size // num_heads * 2)
            )
            # Fake mask
            att_mask = torch.ones((0, 0, 0), dtype=torch.bool)

        cnn_cache = torch.zeros((num_blocks, batch, output_size, cnn_module_kernel - 1))
        return att_cache, cnn_cache, att_mask, required_cache_size

    def get_decoder_init_cache_mask(self, configs):
        # [DK]
        pass

    def forward_encoder(self, encoder, inputs, max_call_limit, configs):
        (
            torch_att_cache,
            torch_cnn_cache,
            torch_att_mask,
            torch_required_cache_size,
        ) = self.get_encoder_init_cache_mask(configs)

        offset = 0
        for iter in range(max_call_limit):
            if configs["num_decoding_left_chunks"] > 0:
                torch_att_mask[:, :, -(configs["chunk_size"] * (iter + 1)) :] = 1
            outs, torch_att_cache, torch_cnn_cache = encoder(
                inputs["feats"],
                offset,
                torch_required_cache_size,
                torch_att_cache,
                torch_cnn_cache,
                torch_att_mask,
            )
            offset += outs.size(10)

    def forward_decoder(self, decoder, max_call_limit):
        # [DK]
        # encoder_out = torch.randn(10, 200, 256)
        # encoder_mask = torch.ones(10, 1, 200)
        # hyps = torch.randint(0, 2500, (1, 200))
        # r_hyps = torch.randint(0, 2500, (1, 200))

        # encoder_out = torch.randn(1, 10, 200, 256)
        # encoder_mask = torch.ones(1, 10, 1, 200)
        # hyps = torch.randint(0, 2500, (1, 200))
        # r_hyps = torch.randint(0, 2500, (1, 200))

        encoder_out = torch.ones(
            1, 10, 200, 256, dtype=torch.float32
        )  # All ones instead of random values
        encoder_mask = torch.ones(1, 10, 1, 200)  # Already ones
        hyps = torch.ones(
            1, 200, dtype=torch.int64
        )  # All ones instead of random integers
        r_hyps = torch.ones(
            1, 200, dtype=torch.int64
        )  # All ones instead of random integers

        # Set the start token (sos) to 2500, as seen in the example
        hyps[:, 0] = 2500
        r_hyps[:, 0] = 2500

        hyps_lens = torch.randint(15, 21, (10,))

        memory = encoder_out  # torch.Size([10, 200, 256])
        memory_mask = encoder_mask  # torch.Size([10, 1, 200])
        ys_in_pad = hyps  # torch.Size([10, 20])
        ys_in_lens = hyps_lens  # torch.Size([10])
        r_ys_in_pad = r_hyps  # torch.Size([10, 20])
        reverse_weight = 0.5

        for iter in range(max_call_limit):
            score, r_score, olens = decoder(
                memory, memory_mask, ys_in_pad, ys_in_lens, r_ys_in_pad
            )

    def _make_feed_dict(self, target, max_call_limit=1):
        inputs = get_sample_data(self._reference_model.configs)
        inputs_container = DefaultInputsCaptureContainer()

        target_ref_model = getattr(self.reference_model, target)

        if target == "encoder":
            target_ref_model.forward = target_ref_model.forward_chunk
        target_fn_name = "forward"
        with InputCaptureCtxManager(
            target_ref_model,
            max_call_limit,
            inputs_container,
            target_fn_name=target_fn_name,
        ) as ctx:
            if target == "encoder":
                self.forward_encoder(
                    target_ref_model,
                    inputs,
                    max_call_limit,
                    self._reference_model.configs,
                )
            elif target == "decoder":
                # [DK]
                self.forward_decoder(target_ref_model, max_call_limit)

        fd = {}
        kw = {}
        if inputs_container.captured_args:
            captured_args = inputs_container.captured_args[-1]
        else:
            captured_args = []
        if inputs_container.captured_kwargs:
            captured_kwargs = inputs_container.captured_kwargs[-1]
        else:
            captured_kwargs = {}

        if target == "encoder":
            forward_chunk_keys = (
                "xs",
                "offset",
                "required_cache_size",
                "att_cache",
                "cnn_cache",
                "att_mask",
            )
        elif target == "decoder":
            forward_chunk_keys = (
                "memory",
                "memory_mask",
                "ys_in_pad",
                "ys_in_lens",
                "r_ys_in_pad",
            )

        for k, v in zip(forward_chunk_keys, captured_args):
            if k == "xs":
                captured_kwargs[k] = v.squeeze(0)
            else:
                captured_kwargs[k] = v

        for k, v in captured_kwargs.items():
            if isinstance(v, torch.Tensor):
                fd[k] = v.detach()
            else:
                fd[k] = v

        kw.update(captured_kwargs)
        return fd, kw

    def _parse_with_target(self, target, feed_dict=None):
        if target == "encoder":
            encoder_builder = SubGraphBuilder({}, "encoder")
            self.set_builder(encoder_builder, recursive=False)
            self.encoder.set_builder(encoder_builder)
            num_frames = 123

            if feed_dict is not None:
                feed_dict["xs"] = feed_dict["xs"][:, :num_frames, :]
                b, seq_len, c = feed_dict["xs"].shape
            else:
                b, seq_len, c = 1, num_frames, 80

            chunk = ActivationSpec(
                name="xs",
                src_shape=(b, DimValue(seq_len, dynamic=True), c),
                dataformat=DataFormat.NXC,
                dtype="float32",
            )
            encoder_builder.add_activation(chunk)
            encoder_builder.make_input(chunk)

            offset = ActivationSpec(
                name="offset", src_shape=(b,), dataformat=DataFormat.N, dtype="float32"
            )

            encoder_output, _, _ = self.encoder.forward_chunk(xs=chunk, offset=offset)
            encoder_builder.make_output(encoder_output)
        elif target == "decoder":
            # [DK]
            decoder_builder = SubGraphBuilder({}, "decoder")
            self.set_builder(decoder_builder, recursive=False)
            self.decoder.set_builder(decoder_builder)

            memory = ActivationSpec(
                name="memory",
                src_shape=(1, 10, 200, 256),
                dataformat=DataFormat.NHWC,
                dtype="float32",
            )

            memory_mask = ActivationSpec(
                name="memory_mask",
                src_shape=(1, 10, 1, 200),
                dataformat=DataFormat.NHWC,
                dtype="int64",
            )

            ys_in_pad = ActivationSpec(
                name="ys_in_pad",
                src_shape=(1, 200),  # (10, 20)
                dataformat=DataFormat.NX,
                dtype="int64",
            )

            ys_in_lens = ActivationSpec(
                name="ys_in_lens",
                src_shape=(10,),
                dataformat=DataFormat.UNKNOWN,
                dtype="int64",
            )

            r_ys_in_pad = ActivationSpec(
                name="r_ys_in_pad",
                src_shape=(1, 200),  # (10, 20)
                dataformat=DataFormat.NX,
                dtype="int64",
            )

            decoder_builder.add_activation(memory)
            decoder_builder.add_activation(memory_mask)  # ->
            decoder_builder.add_activation(ys_in_pad)
            decoder_builder.add_activation(ys_in_lens)  # ->
            decoder_builder.add_activation(r_ys_in_pad)
            decoder_builder.make_input(memory)
            decoder_builder.make_input(memory_mask)
            decoder_builder.make_input(ys_in_pad)
            decoder_builder.make_input(ys_in_lens)
            decoder_builder.make_input(r_ys_in_pad)

            decoder_output, r_decoder_output, _ = self.decoder.forward(
                memory, memory_mask, ys_in_pad, ys_in_lens, r_ys_in_pad
            )
            decoder_builder.make_output(decoder_output)
            decoder_builder.make_output(r_decoder_output)

        else:
            raise NotImplementedError

        md = ModelDict()
        target_builder = self.get_builder(target)
        sg_target = target_builder.build(target, unsupported=False)
        sg_target.idx = 0

        # for op in sg_target.operators:
        #     print("operator name: ", op.name)

        if target == "encoder":
            key_cache_names, value_cache_names, conv_cache_names = [], [], []
            for op in sg_target.operators:
                if op.layertype == LayerType.StatefulKVCacheWrapper:
                    layer_idx = int(op.name.split(".")[2])
                    if "linear_k" in op.name:
                        key_cache_names.append((layer_idx, op.options.cache_name))
                    if "linear_v" in op.name:
                        value_cache_names.append((layer_idx, op.options.cache_name))

                if op.layertype == LayerType.StatefulCausalConvCacheWrapper:
                    layer_idx = int(op.name.split(".")[2])
                    if "causalconv" in op.name:
                        conv_cache_names.append((layer_idx, op.options.cache_name))

            key_cache_names.sort(key=lambda x: x[0])
            value_cache_names.sort(key=lambda x: x[0])
            conv_cache_names.sort(key=lambda x: x[0])
            sg_target.key_cache_names = [x[1] for x in key_cache_names]
            sg_target.value_cache_names = [x[1] for x in value_cache_names]
            sg_target.conv_cache_names = [x[1] for x in conv_cache_names]

        md.subgraphs.append(sg_target)
        const_dict = target_builder._weights

        for iidx in md.sg_main().inputs:
            inact = md.sg_main().activations[iidx]
            md.inputs.append(inact.name)

        for oidx in md.sg_main().outputs:
            outact = md.sg_main().activations[oidx]
            md.outputs.append(outact.name)

        if target == "decoder":
            attn_cache = {
                "_seen_tokens": 0,
                "key_cache": [0, 0, 0, 0],
                "value_cache": [0, 0, 0, 0],
            }

            md.init_model_state = {"decoder": {"past_key_values": attn_cache}}

        elif "att_cache" in feed_dict:
            cache_size = feed_dict["att_cache"].shape[-1] // 2
            key_cache = feed_dict["att_cache"][:, :, :, :cache_size]
            value_cache = feed_dict["att_cache"][:, :, :, cache_size:]
            cnn_cache = feed_dict["cnn_cache"]

            attn_cache = {
                "_seen_tokens": feed_dict["att_cache"].shape[2],
                "key_cache": [
                    key_cache[i : i + 1, ...] for i in range(key_cache.shape[0])
                ],
                "value_cache": [
                    value_cache[i : i + 1, ...] for i in range(value_cache.shape[0])
                ],
            }

            md.init_model_state = {
                "sg_0": {  # sg1: True / encoder: False
                    "past_key_values": attn_cache,
                    "conv_cache": [
                        cnn_cache[i : i + 1, ...].permute(0, 1, 3, 2)
                        for i in range(cnn_cache.shape[0])
                    ],
                },
                "sg_1": {  # sg1: True / encoder: False
                    "past_key_values": attn_cache,
                    "conv_cache": [
                        cnn_cache[i : i + 1, ...].permute(0, 1, 3, 2)
                        for i in range(cnn_cache.shape[0])
                    ],
                },
                "sg_2": {  # sg1: True / encoder: False
                    "past_key_values": attn_cache,
                    "conv_cache": [
                        cnn_cache[i : i + 1, ...].permute(0, 1, 3, 2)
                        for i in range(cnn_cache.shape[0])
                    ],
                },
            }

        out = MobilintParserOutputs()
        out.model_dict = md
        out.value_dict = self.value_dict
        out.const_dict = const_dict

        return out

    def _make_value_dict(self, target, feed_dict, eval_kwargs):
        vd = {}
        vd.update(feed_dict)
        if target == "encoder" or target == "decoder":
            target_module = getattr(self, target)
        else:
            target_module = getattr(self, target)
        target_module.set_value_dict(vd)
        target_module.register_forward_hook()
        kw = {}
        kw.update(feed_dict)
        kw.update(eval_kwargs)

        _value_dict = ValueDict()
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        # target_module.reference_model = target_module.reference_model.to(device)

        for k, v in kw.items():
            if isinstance(v, torch.Tensor):
                if k == "memory":
                    kw[k] = v.squeeze(0)  # (1, 10, 200, 256) → (10, 200, 256)
                elif k == "memory_mask":
                    kw[k] = v.squeeze(0)  # (1, 10, 1, 200) → (10, 1, 200)
                elif k in ["ys_in_pad", "r_ys_in_pad"]:
                    kw[k] = v.view(10, -1)  # (1, 200) → (10, 20)
                elif k == "ys_in_lens":
                    pass  # Already in desired shape (10,)

        for k, v in kw.items():
            if isinstance(v, torch.Tensor):
                kw[k] = v

        target_module.torch_compute(**kw)
        for k, v in vd.items():
            if isinstance(v, torch.Tensor):
                if v.dtype == torch.bfloat16:
                    v = v.to(torch.float32)
                v = v.detach().cpu().numpy()
            if isinstance(v, numpy.ndarray):
                _value_dict[k] = v

        return _value_dict

    def parse(self, target, make_value_dict=True, **kwargs):
        max_call_limit = kwargs.pop("target_sg_state") + 1
        max_call_limit = 1

        feed_dict, eval_kwargs = self._make_feed_dict(
            target=target, max_call_limit=max_call_limit
        )
        out = self._parse_with_target(target=target, feed_dict=feed_dict)

        if make_value_dict:
            out.value_dict = self._make_value_dict(target, feed_dict, eval_kwargs)
        else:
            vd = ValueDict()
            vd._value_dict.update(feed_dict)
            out.value_dict = vd

        return out
