from typing import Optional, Type, Any, Tuple

import wenet.transformer.encoder as wenet_transformer_encoder

from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.base import (
    ModelingWeNetBase,
)
from qbcompiler.model_dict.common import (
    ModelDict,
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)
from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.attention import KVCache


class BaseEncoder(ModelingWeNetBase):
    # __slots__ =  ("globa_cmvn", "embed")

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_encoder.BaseEncoder

    def forward(self, *args, **kwargs):
        return super().forward(*args, **kwargs)

    def forward_chunk(
        self,
        xs: ActivationSpec,
        offset: int,
        required_cache_size: int = -1,
        att_cache: KVCache = None,
        cnn_cache: ActivationSpec = None,
        att_mask: ActivationSpec = None,
    ) -> Tuple[ActivationSpec, ActivationSpec, ActivationSpec]:
        """ Forward just one chunk

        Args:
            xs (torch.Tensor): chunk input, with shape (b=1, time, mel-dim),
                where `time == (chunk_size - 1) * subsample_rate + \
                        subsample.right_context + 1`
            offset (int): current offset in encoder output time stamp
            required_cache_size (int): cache size required for next chunk
                compuation
                >=0: actual cache size
                <0: means all history cache is required
            att_cache (torch.Tensor): cache tensor for KEY & VALUE in
                transformer/conformer attention, with shape
                (elayers, head, cache_t1, d_k * 2), where
                `head * d_k == hidden-dim` and
                `cache_t1 == chunk_size * num_decoding_left_chunks`.
            cnn_cache (torch.Tensor): cache tensor for cnn_module in conformer,
                (elayers, b=1, hidden-dim, cache_t2), where
                `cache_t2 == cnn.lorder - 1`

        Returns:
            torch.Tensor: output of current input xs,
                with shape (b=1, chunk_size, hidden-dim).
            torch.Tensor: new attention cache required for next chunk, with
                dynamic shape (elayers, head, ?, d_k * 2)
                depending on required_cache_size.
            torch.Tensor: new conformer cnn cache required for next chunk, with
                same shape as the original cnn_cache.

        """
        assert xs.get_act_src_shape()[0] == 1
        # tmp_masks is just for interface compatibility
        # tmp_masks = torch.ones(1,
        #                        xs.size(1),
        #                        device=xs.device,
        #                        dtype=torch.bool)
        # tmp_masks = tmp_masks.unsqueeze(1)
        if self.global_cmvn is not None:
            xs = self.global_cmvn(xs)
        # NOTE(xcsong): Before embed, shape(xs) is (b=1, time, mel-dim)
        xs, pos_emb, _ = self.embed(xs, None, offset)  # [1, 123, 80] -> [1, 30, 256]
        # NOTE(xcsong): After  embed, shape(xs) is (b=1, chunk_size, hidden-dim)

        # pos_emb shape: [1, dynamic, 256]
        pos_emb = self.builder.make_inputconst(
            self.embed.pos_enc.pe[:, None, :, :],
            opname=self.module_name + ".position_weight",
        )  # (1,1,5000,256)
        pos_emb = self.builder.make_dynamic_slice_input_const(
            pos_emb, axis=(2,), mod=0, start=(0,), end=(30,), step=(1,)
        )  # (1,1,30,256)
        pos_emb = self.builder.make_squeeze(pos_emb, squeeze_axes=(1,))
        pos_emb.dataformat = DataFormat.NXC

        for i, layer in enumerate(self.encoders):
            xs, _, new_kv_cache, new_cnn_cache = layer(
                xs, att_mask, pos_emb, mask_pad=None, att_cache=None, cnn_cache=None
            )

        if self.normalize_before and self.final_norm:
            xs = self.after_norm(xs)

        return (xs, None, None)


class ConformerEncoder(BaseEncoder):
    """Conformer encoder module."""

    __slots__ = (
        "encoders",
        "global_cmvn",
        "embed",
        "normalize_before",
        "final_norm",
        "after_norm",
        "static_chunk_size",
        "use_dynamic_chunk",
        "use_dynamic_left_chunk",
        "use_sdpa",
    )

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_encoder.ConformerEncoder
