from typing import Type

from qbcompiler.model_dict.common import (
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
)

import wenet.transformer.cmvn as wenet_transformer_cmvn
from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.base import (
    ModelingWeNetBase,
)


class GlobalCMVN(ModelingWeNetBase):
    __slots__ = ("norm_var", "mean", "istd")

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_cmvn.GlobalCMVN

    def forward(self, x: ActivationSpec):
        """
        Args:
            x (torch.Tensor): (batch, max_len, feat_dim)

        Returns:
            (torch.Tensor): normalized feature
        """
        # x = x - self.mean
        x = self.builder.make_sub(x, self.mean, opname=f"{x.name}/sub")
        if self.norm_var:
            x = self.builder.make_mul(x, self.istd, opname=f"{x.name}/mul")
            # x = x * self.istd
        return x
