from typing import Tuple, Type

from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.base import (
    ModelingWeNetBase,
)
from qbcompiler.model_dict.common import (
    ModelDict,
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)

import wenet.transformer.ctc as wenet_transformer_ctc


class CTC(ModelingWeNetBase):
    """CTC module"""

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_ctc.CTC

    def forward(
        self,
        hs_pad: ActivationSpec,
        hlens: ActivationSpec,
        ys_pad: ActivationSpec,
        ys_lens: ActivationSpec,
    ) -> Tuple[ActivationSpec, ActivationSpec]:
        """Calculate CTC loss.

        Args:
            hs_pad: batch of padded hidden state sequences (B, Tmax, D)
            hlens: batch of lengths of hidden state sequences (B)
            ys_pad: batch of padded character id sequence tensor (B, Lmax)
            ys_lens: batch of lengths of character sequence (B)
        """
        pass

    def log_softmax(self, hs_pad: ActivationSpec) -> ActivationSpec:
        """log_softmax of frame activations

        Args:
            Tensor hs_pad: 3d tensor (B, Tmax, eprojs)
        Returns:
            ActivationSpec: log softmax applied 3d tensor (B, Tmax, odim)
        """
        # return F.log_softmax(self.ctc_lo(hs_pad), dim=2)
        pass

    def argmax(self, hs_pad: ActivationSpec) -> ActivationSpec:
        """argmax of frame activations

        Args:
            ActivationSpec hs_pad: 3d tensor (B, Tmax, eprojs)
        Returns:
            ActivationSpec: argmax applied 2d tensor (B, Tmax)
        """
        # return torch.argmax(self.ctc_lo(hs_pad), dim=2)
        pass
