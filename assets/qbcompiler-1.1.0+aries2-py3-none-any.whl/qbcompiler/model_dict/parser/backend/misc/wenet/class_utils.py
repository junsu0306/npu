from torch.nn import LayerNorm

from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.attention import (
    MultiHeadedAttention,
    RelPositionMultiHeadedAttention,
    MultiHeadedCrossAttention,
)
from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.positionwise_feed_forward import (
    PositionwiseFeedForward,
)

WENET_ATTENTION_CLASSES = {
    "selfattn": MultiHeadedAttention,
    "rel_selfattn": RelPositionMultiHeadedAttention,
    "crossattn": MultiHeadedCrossAttention,
}

WENET_MLP_CLASSES = {
    "position_wise_feed_forward": PositionwiseFeedForward,
}

WENET_NORM_CLASSES = {
    "layer_norm": LayerNorm,
    #'batch_norm': BatchNorm1d,
    #'rms_norm': RMSNorm
}
