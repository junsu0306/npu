from typing import Any, Tuple, Type

import wenet.transformer.positionwise_feed_forward as wenet_transformer_pff

from qbcompiler.model_dict.common import (
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
)
from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.base import (
    ModelingWeNetBase,
)


class PositionwiseFeedForward(ModelingWeNetBase):
    """Positionwise feed forward layer.

    FeedForward are appied on each position of the sequence.
    The output dim is same with the input dim.

    Args:
        idim (int): Input dimenstion.
        hidden_units (int): The number of hidden units.
        dropout_rate (float): Dropout rate.
        activation (torch.nn.Module): Activation function
    """

    __slots__ = ("w_1", "activation", "dropout", "w_2")

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_pff.PositionwiseFeedForward

    def forward(self, xs: ActivationSpec) -> ActivationSpec:
        """Forward function.

        Args:
            xs: input tensor (B, L, D)
        Returns:
            output tensor, (B, L, D)
        """

        w1_out = self.w_1(xs)  # [1, 30, 256] -> [1, 30, 2048]
        act_out = self.activation(w1_out)
        dropout_out = self.dropout(act_out)
        out = self.w_2(dropout_out)  # [1, 30, 2048] -> [1, 30, 256]

        return out
