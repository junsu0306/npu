import abc
from typing import Any

from qbcompiler.model_dict.parser.backend.modeling_torch.abc import ModuleParserBase


class ModelingWeNetBase(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(self, model: Any, module_name: str = "", make_func=None):
        super().__init__(model, module_name, make_module_func=make_func)
