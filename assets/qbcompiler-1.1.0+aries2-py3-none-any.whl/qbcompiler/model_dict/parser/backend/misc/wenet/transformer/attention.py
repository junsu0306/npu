from typing import Optional, Tuple, Type, Any
import math
import copy

from qbcompiler.model_dict.common import (
    ModelDict,
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)

from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.base import (
    ModelingWeNetBase,
)

import wenet.transformer.attention as wenet_transformer_attention


class KVCache:
    def __init__(self, past_seqlen=0):
        self.past_seqlen = past_seqlen

    def get_updated(self, seq_len):
        return KVCache(self.past_seqlen + seq_len)


class MultiHeadedAttention(ModelingWeNetBase):
    """Multi-Head Attention layer.
    if n_kv_head != None and n_kv_head != n_head
    see: https://arxiv.org/pdf/1911.02150.pdf
         https://arxiv.org/pdf/2305.13245.pdf

    Example:
        case 1: n_kv_head == None, head_dim == None, MultiHead attention (MHSA)
        case 2: n_kv_head=1, n_head = 16, MultiQuery attention (MQA)
        case 3: nv_kv_head=2, n_head = 16, GroupedQuery attention (GQA)

    Args:
        n_head (int): The number of heads.
        n_feat (int): The number of features.
        dropout_rate (float): Dropout rate.

    """

    __slots__ = (
        "inner_dim",
        "inner_kv_dim",
        "d_k",
        "h",
        "h_kv",
        "linear_q",
        "linear_k",
        "linear_v",
        "linear_out",
        "dropout",
        "use_sdpa",
        "dropout_rate",
    )

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_attention.MultiHeadedAttention

    def _forward_linearx(
        self, name: str, x: ActivationSpec, head_first: bool = True
    ) -> ActivationSpec:
        is_decoder = False
        if "memory" in x.name or "decoder" in x.name:  # TODO need to revise
            is_decoder = True

        # x.dataformat = DataFormat.NHWC
        if name == "query":
            x = self.linear_q(x)
            if is_decoder:
                x = self.builder.make_transpose(
                    x, transpose_axes=(0, 2, 1, 3), opname=x.name + "/transpose"
                )
            x_shape = x.get_act_src_shape()
            if is_decoder:
                x_shape = x_shape[:-2] + (self.h * int(x_shape[-2]), self.d_k)
            else:
                x_shape = x_shape[:-1] + (self.h, self.d_k)
        elif name == "key":
            x = self.linear_k(x)
            if is_decoder:
                x = self.builder.make_transpose(
                    x, transpose_axes=(0, 2, 1, 3), opname=x.name + "/transpose"
                )
            x_shape = x.get_act_src_shape()
            if is_decoder:
                x_shape = x_shape[:-2] + (self.h_kv * int(x_shape[-2]), self.d_k)
            else:
                x_shape = x_shape[:-1] + (self.h_kv, self.d_k)
        else:
            assert name == "value"
            x = self.linear_v(x)
            if is_decoder:
                x = self.builder.make_transpose(
                    x, transpose_axes=(0, 2, 1, 3), opname=x.name + "/transpose"
                )
            x_shape = x.get_act_src_shape()
            if is_decoder:
                x_shape = x_shape[:-2] + (self.h_kv * int(x_shape[-2]), self.d_k)
            else:
                x_shape = x_shape[:-1] + (self.h_kv, self.d_k)

        # split last dim
        x = self.builder.make_reshape(x, shape=x_shape, new_dataformat=DataFormat.NHWC)
        if head_first:
            if is_decoder:
                pass
            x = self.builder.make_transpose(
                x, transpose_axes=(0, 2, 1, 3), opname=x.name + "/transpose"
            )
        return x

    def forward_qkv(
        self, query: ActivationSpec, key: ActivationSpec, value: ActivationSpec
    ) -> Tuple[ActivationSpec, ActivationSpec, ActivationSpec]:
        """Transform query, key and value.

        Args:
            query (ActivationSpec): Query tensor (#batch, ..., time1, size).
            key (ActivationSpec): Key tensor (#batch, ..., time2, size).
            value (ActivationSpec): Value tensor (#batch, ..., time2, size).

        Returns:
            ActivationSpec: Transformed query tensor, size
                (#batch, ..., n_head, time1, d_k).
            ActivationSpec: Transformed key tensor, size
                (#batch, ..., n_head_kv, time2, d_k).
            ActivationSpec: Transformed value tensor, size
                (#batch, ..., n_head_kv, time2, d_k).

        """
        q = self._forward_linearx("query", query)  # [1, 30, 256] -> [1, 4, 30, 64]
        k = self._forward_linearx("key", key)  # [1, 30, 256] -> [1, 4, 30, 64]
        v = self._forward_linearx("value", value)  # [1, 30, 256] -> [1, 4, 30, 64]
        return q, k, v

    def forward_attention(
        self,
        value: ActivationSpec,
        scores: ActivationSpec,
        past_seqlen=int,
        mask: ActivationSpec = None,
        is_decoder: bool = False,
    ):
        if is_decoder:
            scores = self.builder.apply_attention_mask(
                scores, mask, past_seq_len=past_seqlen, opname=scores.name + "/mask"
            )

        scores = self.builder.make_softmax(
            scores, axis=-1, beta=0, opname=scores.name + "/softmax"
        )
        x = self.builder.make_matmul(
            scores, value, opname=scores.name + "/attn_value"
        )  # [1, 4, 30, 30] x [1, 4, 30, 64] -> [1, 4, 30, 64]
        x = self.builder.make_transpose(
            x, transpose_axes=(0, 2, 1, 3), opname=x.name + "/transpose"
        )  # [1, 4, 30, 64] -> [1, 30, 4, 64]

        if is_decoder:
            x_shape = x.get_act_src_shape()[:-2] + (
                int(x.get_act_src_shape()[-2] / self.h),
                self.h * self.d_k,
            )
            x = self.builder.make_reshape(
                x,
                shape=x_shape,
                opname=x.name + "/reshape",
                new_dataformat=DataFormat.NHWC,
            )
            x = self.builder.make_transpose(
                x, transpose_axes=(0, 2, 1, 3), opname=x.name + "/transpose"
            )
        else:
            x_shape = x.get_act_src_shape()[:-2] + (self.h * self.d_k,)
            x = self.builder.make_reshape(
                x, shape=x_shape, opname=x.name + "/reshape"
            )  # [1, 30, 4, 64] -> [1, 30, 256]
            x.dataformat = DataFormat.NXC

        return self.linear_out(x)

    def _update_kv_and_cache(
        self,
        k: ActivationSpec,
        v: ActivationSpec,
        cache: KVCache,
        head_first: bool = True,
    ) -> Tuple[ActivationSpec, ActivationSpec, KVCache]:
        updates = []
        for x in (k, v):
            updates.append(
                self.builder.make_stateful_kvcache_wrapper(
                    x,
                    x.name,
                    0 if cache is None else cache.past_seqlen,
                    opname=x.name + "/cache",
                )
            )
        k, v = tuple(updates)

        if self.h_kv != self.h and self.h_kv != 1:
            raise NotImplementedError

        return k, v, cache

    def forward(
        self,
        query: ActivationSpec,
        key: ActivationSpec,
        value: ActivationSpec,
        mask: ActivationSpec = None,
        pos_emb: ActivationSpec = None,
        cache: KVCache = None,
    ) -> Tuple[ActivationSpec, KVCache]:
        """Compute scaled dot product attention.

        Args:
            query (ActivationSpec): Query tensor (#batch, time1, size).
            key (ActivationSpec): Key tensor (#batch, time2, size).
            value (ActivationSpec): Value tensor (#batch, time2, size).
            mask (ActivationSpec): Mask tensor (#batch, 1, time2) or
                (#batch, time1, time2).
                1.When applying cross attention between decoder and encoder,
                the batch padding mask for input is in (#batch, 1, T) shape.
                2.When applying self attention of encoder,
                the mask is in (#batch, T, T)  shape.
                3.When applying self attention of decoder,
                the mask is in (#batch, L, L)  shape.
                4.If the different position in decoder see different block
                of the encoder, such as Mocha, the passed in mask could be
                in (#batch, L, T) shape. But there is no such case in current
                Wenet.
            cache (ActivationSpec): Cache tensor (1, head, cache_t, d_k * 2),
                where `cache_t == chunk_size * num_decoding_left_chunks`
                and `head * d_k == size`


        Returns:
            ActivationSpec: Output tensor (#batch, time1, d_model).
            ActivationSpec: Cache tensor (1, head, cache_t + time1, d_k * 2)
                where `cache_t == chunk_size * num_decoding_left_chunks`
                and `head * d_k == size`

        """
        # [NOTE] The 'forward' function is used only by the decoder, which does not use caching.
        q, k, v = self.forward_qkv(query, key, value)

        is_causal = False if mask is None else True
        scale_factor = 1.0 / math.sqrt(self.d_k)
        opname = q.name + "/sdpa"

        if not self.use_sdpa:
            attn_output = self.builder.make_matmul(
                q,
                self.builder.make_transpose(
                    k, transpose_axes=(0, 1, 3, 2), opname=opname + "/transpose_k"
                ),
                opname=opname + "/attn_weight",
            )
            scores = self.builder.make_mul(
                attn_output, scale_factor, opname=opname + "/scale"
            )
            scores = self.builder.make_mul(
                attn_output, 1.0 / math.sqrt(self.d_k), opname=f"{scores.name}/scale"
            )
            past_seqlen = 0 if cache is None else cache.past_seqlen
            return (
                self.forward_attention(v, scores, past_seqlen, mask, is_decoder=True),
                cache,
            )
        else:
            raise NotImplementedError


class RelPositionMultiHeadedAttention(MultiHeadedAttention):
    """Multi-Head Attention layer with relative position encoding.
    Paper: https://arxiv.org/abs/1901.02860
    Args:
        n_head (int): The number of heads.
        n_feat (int): The number of features.
        dropout_rate (float): Dropout rate.
    """

    __slots__ = (
        "linear_pos",
        "pos_bias_u",
        "pos_bias_v",
        "linear_q",
        "linear_k",
        "linear_v",
        "d_k",
        "h",
        "h_kv",
        "use_sdpa",
        "linear_out",
    )

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_attention.RelPositionMultiHeadedAttention

    def forward(
        self,
        query: ActivationSpec,
        key: ActivationSpec,
        value: ActivationSpec,
        mask: ActivationSpec = None,
        pos_emb: ActivationSpec = None,
        cache: KVCache = None,
    ) -> Tuple[ActivationSpec, KVCache]:
        """Compute 'Scaled Dot Product Attention' with rel. positional encoding.
        Args:
            query (ActivationSpec): Query tensor (#batch, time1, size).
            key (ActivationSpec): Key tensor (#batch, time2, size).
            value (ActivationSpec): Value tensor (#batch, time2, size).
            mask (ActivationSpec): Mask tensor (#batch, 1, time2) or
                (#batch, time1, time2), (0, 0, 0) means fake mask.
            pos_emb (ActivationSpec): Positional embedding tensor
                (#batch, time2, size).
            cache (ActivationSpec): Cache tensor (1, head, cache_t, d_k * 2),
                where `cache_t == chunk_size * num_decoding_left_chunks`
                and `head * d_k == size`
        Returns:
            ActivationSpec: Output tensor (#batch, time1, d_model).
            ActivationSpec: Cache tensor (1, head, cache_t + time1, d_k * 2)
                where `cache_t == chunk_size * num_decoding_left_chunks`
                and `head * d_k == size`
        """
        q, k, v = self.forward_qkv(query, key, value)  # output: [1, 4, 30, 64]
        opname = q.name
        q = self.builder.make_transpose(
            q, transpose_axes=(0, 2, 1, 3), opname=f"{opname}/transpose_0"
        )  # [1, 4, 30, 64] -> [1, 30, 4, 64]
        k, v, new_cache = self._update_kv_and_cache(k, v, cache)  # [1, 4, dynamic, 64]

        n_batch_pos = pos_emb.get_act_src_shape()[0]
        p = self.linear_pos(pos_emb)  # [1, 30, 256] -> [1, 30, 256]
        p = self.builder.make_reshape(
            p, shape=(n_batch_pos, pos_emb.get_act_src_shape()[1], self.h, self.d_k)
        )  # [1, 30, 256] -> [1, 30, 4, 64]
        p = self.builder.make_transpose(
            p, transpose_axes=(0, 2, 1, 3)
        )  # [1, 30, 4, 64] -> [1, 4, 30, 64]

        # (batch, head, time1, d_k)
        # [TODO]: 정승님이 HeaderView -> Add -> Matmul 변경하라고 요청청
        pos_bias_u = self.builder.make_inputconst(
            self.pos_bias_u[None, None, :, :], opname=f"{opname}/inputconst_0"
        )  # [4, 64]
        q_with_bias_u = self.builder.make_add(
            q, pos_bias_u, opname=f"{opname}/add_0"
        )  # [1, 30, 4, 64] + [4, 64] -> [1, 30, 4, 64]
        q_with_bias_u = self.builder.make_transpose(
            q_with_bias_u, transpose_axes=(0, 2, 1, 3), opname=f"{opname}/transpose_2"
        )  # [1, 30, 4, 64] -> [1, 4, 30, 64]
        # (batch, head, time1, d_k)
        pos_bias_v = self.builder.make_inputconst(
            self.pos_bias_v[None, None, :, :], opname=f"{opname}/inputconst_1"
        )  # [4, 64]
        q_with_bias_v = self.builder.make_add(
            q, pos_bias_v, opname=f"{opname}/add_1"
        )  # [1, 30, 4, 64] + [4, 64] -> [1, 30, 4, 64]
        q_with_bias_v = self.builder.make_transpose(
            q_with_bias_v, transpose_axes=(0, 2, 1, 3), opname=f"{opname}/transpose_3"
        )  # [1, 30, 4, 64] -> [1, 4, 30, 64]
        # compute matrix b and matrix d
        # (batch, head, time1, time2)
        p = self.builder.make_transpose(
            p, transpose_axes=(0, 1, 3, 2)
        )  # [1, 4, 30, 64] -> [1, 4, 64, 30]
        matrix_bd = self.builder.make_matmul(
            q_with_bias_v, p, opname=f"{opname}/attn_weight_bias_v"
        )  # [1, 4, 30, 64] x [ 1, 4, 64, 30] -> [1, 4, 30, 30]
        if not self.use_sdpa:
            # (batch, head, time1, time2)
            matrix_ac = self.builder.make_matmul(
                q_with_bias_u,
                self.builder.make_transpose(k, transpose_axes=(0, 1, 3, 2)),
                opname=f"{opname}/attn_weight_bias_u",
            )  # [1, 4, 30, 64] x [1, 4, 64, 30] -> [1, 4, 30, 30]
            matrix_bd.src_shape = copy.deepcopy(matrix_ac.src_shape)
            scores = self.builder.make_add(
                matrix_ac, matrix_bd, opname=f"{opname}/attn_weight"
            )
            scores = self.builder.make_mul(
                scores, 1.0 / math.sqrt(self.d_k), opname=f"{opname}/scale"
            )  # [1, 4, 30, 30]

            return (
                self.forward_attention(
                    v,
                    scores,
                    past_seqlen=0 if cache is None else cache.past_seqlen,
                    mask=mask,
                ),
                new_cache,
            )
        else:
            raise NotImplementedError


class MultiHeadedCrossAttention(MultiHeadedAttention):
    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_attention.MultiHeadedCrossAttention

    def forward_attention(
        self,
        value: ActivationSpec,
        scores: ActivationSpec,
        past_seqlen=int,
        mask: ActivationSpec = None,
    ):
        if mask is not None:
            scores = self.builder.apply_attention_mask(
                scores, mask, past_seqlen=past_seqlen, opname=scores.name + "/mask"
            )

        scores = self.builder.make_softmax(
            scores, axis=-1, beta=0, opname=scores.name + "/softmax"
        )
        # scores = self.dropout(scores)
        x = self.builder.make_matmul(scores, value, opname=scores.name + "/attn_value")
        x = self.builder.make_transpose(
            x, transpose_axes=(0, 2, 1, 3), opname=x.name + "/transpose"
        )
        x_shape = x.get_act_src_shape()[:-2] + (
            int(x.get_act_src_shape()[-2] / self.h),
            self.h * self.d_k,
        )

        x = self.builder.make_reshape(
            x, shape=x_shape, opname=x.name + "/reshape", new_dataformat=DataFormat.NHWC
        )
        x = self.builder.make_transpose(
            x, transpose_axes=(0, 2, 1, 3), opname=x.name + "/transpose"
        )
        return self.linear_out(x)  # [10, 20, 256]

    def forward(
        self,
        query: ActivationSpec,
        key: ActivationSpec,
        value: ActivationSpec,
        mask: ActivationSpec = None,
        pos_emb: ActivationSpec = None,
        cache: KVCache = None,
    ) -> Tuple[ActivationSpec, KVCache]:
        q, k, v = self.forward_qkv(query, key, value)
        new_cache = None  # (k, v)  # if not self.training else cache
        # for multi query or multi groups attention
        if self.h_kv != self.h and self.h_kv != 1:
            raise NotImplementedError(
                "multi query or multi groups attention not supported now"
            )

        scale_factor = 1.0 / math.sqrt(self.d_k)
        opname = q.name + "/sdpa"

        if not self.use_sdpa:
            scores = self.builder.make_matmul(
                q,
                self.builder.make_transpose(
                    k, transpose_axes=(0, 1, 3, 2), opname=opname + "/transpose_k"
                ),
                opname=opname + "/attn_weight",
            )
            scores = self.builder.make_mul(
                scores, scale_factor, opname=opname + "/scale"
            )
            output = self.forward_attention(v, scores, mask)
        else:
            raise NotImplementedError("case: self.use_sdpa == true is not implemented.")

        return output, new_cache
