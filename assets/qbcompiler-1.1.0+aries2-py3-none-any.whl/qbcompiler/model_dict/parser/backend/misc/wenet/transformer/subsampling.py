from typing import Any, Union, Tuple, Type

import wenet.transformer.subsampling as wenet_transformer_subsampling

from qbcompiler.model_dict.common import (
    ActivationSpec,
    TensorSpec,
    Operator,
    DataFormat,
    SubGraph,
    WeightDict,
)
from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.base import (
    ModelingWeNetBase,
)


class BaseSubsampling(ModelingWeNetBase):
    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_subsampling.BaseSubsampling

    def position_encoding(
        self, offset: Union[int, ActivationSpec], size: int
    ) -> ActivationSpec:
        return self.pos_enc.position_encoding(offset, size)


class Conv2dSubsampling4(BaseSubsampling):
    __slots__ = ("conv", "out", "pos_enc", "subsampling_rate", "right_context")
    """Convolutional 2D subsampling (to 1/4 length).

    Args:
        idim (int): Input dimension.
        odim (int): Output dimension.
        dropout_rate (float): Dropout rate.

    """

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_subsampling.Conv2dSubsampling4

    def forward(
        self,
        x: ActivationSpec,
        x_mask: ActivationSpec = None,
        offset: Union[int, ActivationSpec] = 0,
    ) -> Tuple[ActivationSpec, ActivationSpec, ActivationSpec]:
        """Subsample x.

        Args:
            x (ActivationSpec): Input tensor (#batch, time, idim).
            x_mask (ActivationSpec): Input mask (#batch, 1, time).

        Returns:
            ActivationSpec: Subsampled tensor (#batch, time', odim),
                where time' = time // 4.
            ActivationSpec: Subsampled mask (#batch, 1, time'),
                where time' = time // 4.
            ActivationSpec: positional encoding

        """
        # x = x.unsqueeze(1)  # (b, c=1, t, f)
        x = self.builder.make_unsqueeze(x, axis=3, opname=x.name + "/unsqueeze")
        x = self.builder.make_transpose(x, transpose_axes=(0, 3, 2, 1))
        x.dataformat = DataFormat.NCHW
        for key in ("0", "2"):
            self.conv._modules[key].weight = self.conv._modules[key].weight.permute(
                0, 1, 3, 2
            )
        x = self.conv(x)  # [1, 1, 123, 80] -> [1, 256, 30, 19]
        # b, t, f, c = x.get_act_src_shape()
        b, c, f, t = x.get_act_src_shape()
        # [1, 256, 30, 19] -> [1, 30, 4864]
        # [TODO] 정승님이 HeaderView Revert로 바꿔달라고 요청
        x = self.builder.make_reshape(
            x, shape=(b, c * f, t)
        )  # 'encoder.embed.conv3/transpose/reshape'
        x = self.builder.make_transpose(
            x, transpose_axes=(0, 2, 1), opname=x.name + "/transpose"
        )  #  encoder.embed.conv3/transpose
        x.dataformat = DataFormat.NXC
        x = self.out(x)  # [1, 30, 4864] -> [1, 30, 256] / encoder.embed.out0/reshape
        x, pos_emb = self.pos_enc(x, offset)  # [1, 30, 256]
        # x = self.builder.make_squeeze(x, squeeze_axes=(1,))
        return x, pos_emb, None
