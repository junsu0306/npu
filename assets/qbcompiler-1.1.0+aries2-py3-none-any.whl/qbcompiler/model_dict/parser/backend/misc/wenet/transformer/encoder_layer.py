from typing import Optional, Any, Tuple, Type

import wenet.transformer.encoder_layer as wenet_transformer_encoder_layer

from qbcompiler.model_dict.common import (
    ModelDict,
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)

from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.base import (
    ModelingWeNetBase,
)
from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.attention import KVCache


class ConformerEncoderLayer(ModelingWeNetBase):
    """Encoder layer module.
    Args:
        size (int): Input dimension.
        self_attn (torch.nn.Module): Self-attention module instance.
            `MultiHeadedAttention` or `RelPositionMultiHeadedAttention`
            instance can be used as the argument.
        feed_forward (torch.nn.Module): Feed-forward module instance.
            `PositionwiseFeedForward` instance can be used as the argument.
        feed_forward_macaron (torch.nn.Module): Additional feed-forward module
             instance.
            `PositionwiseFeedForward` instance can be used as the argument.
        conv_module (torch.nn.Module): Convolution module instance.
            `ConvlutionModule` instance can be used as the argument.
        dropout_rate (float): Dropout rate.
        normalize_before (bool):
            True: use layer_norm before each sub-block.
            False: use layer_norm after each sub-block.
    """

    __slots__ = (
        "norm_ff",
        "norm_mha",
        "norm_ff_macaron",
        "feed_forward_macaron",
        "ff_scale",
        "norm_conv",
        "norm_final",
        "dropout",
        "size",
        "normalize_before",
    )

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_encoder_layer.ConformerEncoderLayer

    def forward(
        self,
        x: ActivationSpec,
        mask: ActivationSpec,
        pos_emb: ActivationSpec,
        mask_pad: ActivationSpec,
        att_cache: KVCache,
        cnn_cache: ActivationSpec,
    ) -> Tuple[ActivationSpec, ActivationSpec, KVCache, ActivationSpec]:
        """Compute encoded features.

        Args:
            x (ActivationSpec): (#batch, time, size)
            mask (ActivationSpec): Mask tensor for the input (#batch, time，time),
                (0, 0, 0) means fake mask.
            pos_emb (ActivationSpec): positional encoding, must not be None
                for ConformerEncoderLayer.
            mask_pad (ActivationSpec): batch padding mask used for conv module.
                (#batch, 1，time), (0, 0, 0) means fake mask.
            att_cache (ActivationSpec): Cache tensor of the KEY & VALUE
                (#batch=1, head, cache_t1, d_k * 2), head * d_k == size.
            cnn_cache (ActivationSpec): Convolution cache in conformer layer
                (#batch=1, size, cache_t2)
        Returns:
            ActivationSpec: Output tensor (#batch, time, size).
            ActivationSpec: Mask tensor (#batch, time, time).
            ActivationSpec: att_cache tensor,
                (#batch=1, head, cache_t1 + time, d_k * 2).
            ActivationSpec: cnn_cahce tensor (#batch, size, cache_t2).
        """
        opname = x.name
        # whether to use macaron style
        if self.feed_forward_macaron is not None:
            residual = x
            if self.normalize_before:
                x = self.norm_ff_macaron(x)  # [1, 30, 256] -> [1, 30, 256]

            # multiply: [1, 30, 256] x constant -> [1, 30, 256]
            ff_scale = self.builder.make_mul(
                self.dropout(self.feed_forward_macaron(x)), self.ff_scale
            )
            x = self.builder.make_add(
                residual, ff_scale, opname=opname + "/add_0"
            )  # [1, 30, 256]
            # x = residual + self.ff_scale * self.dropout(
            #     self.feed_forward_macaron(x))
            if not self.normalize_before:
                x = self.norm_ff_macaron(x)

        # multi-headed self-attention module
        residual = x
        if self.normalize_before:
            x = self.norm_mha(x)  # [1, 30, 256]

        x_att, new_att_cache = self.self_attn(x, x, x, mask, pos_emb, att_cache)
        # [1, 30, 256] + [1, 30, 256]
        x = self.builder.make_add(
            residual, self.dropout(x_att), opname=opname + "/add_1"
        )
        if not self.normalize_before:
            x = self.norm_mha(x)

        # convolution module
        # Fake new cnn cache here, and then change it in conv_module
        # new_cnn_cache = torch.zeros((0, 0, 0), dtype=x.dtype, device=x.device)
        if self.conv_module is not None:
            residual = x
            if self.normalize_before:
                x = self.norm_conv(x)  # [1, 30, 256]
            x, new_cnn_cache = self.conv_module(x, mask_pad, cnn_cache)
            x = self.builder.make_add(
                residual, self.dropout(x), opname=opname + "/add_2"
            )

            if not self.normalize_before:
                x = self.norm_conv(x)

        # feed forward module
        residual = x
        if self.normalize_before:
            x = self.norm_ff(x)  # [1, 30, 256]

        ff = self.dropout(self.feed_forward(x))
        ff_scale = self.builder.make_mul(ff, self.ff_scale, opname=opname + "/scale")
        x = self.builder.make_add(residual, ff_scale, opname=opname + "/add_3")
        # x = residual + self.ff_scale * self.dropout(self.feed_forward(x))
        x.dataformat = DataFormat.NXC
        if not self.normalize_before:
            x = self.norm_ff(x)

        if self.conv_module is not None:
            x = self.norm_final(x)

        return x, mask, new_att_cache, new_cnn_cache
