import copy

from torch.utils.data import DataLoader

from wenet.dataset.dataset import Dataset
from wenet.utils.init_tokenizer import init_tokenizer


def get_sample_data(configs):
    tokenizer = init_tokenizer(configs)

    test_conf = copy.deepcopy(configs["dataset_conf"])
    test_conf["filter_conf"]["max_length"] = 102400
    test_conf["filter_conf"]["min_length"] = 0
    test_conf["filter_conf"]["token_max_length"] = 102400
    test_conf["filter_conf"]["token_min_length"] = 0
    test_conf["filter_conf"]["max_output_input_ratio"] = 102400
    test_conf["filter_conf"]["min_output_input_ratio"] = 0
    test_conf["speed_perturb"] = False
    test_conf["spec_aug"] = False
    test_conf["spec_sub"] = False
    test_conf["spec_trim"] = False
    test_conf["shuffle"] = False
    test_conf["sort"] = False
    test_conf["fbank_conf"]["dither"] = 0.0
    test_conf["batch_conf"]["batch_type"] = "static"
    test_conf["batch_conf"]["batch_size"] = 1

    data_type = "raw"

    test_dataset = Dataset(
        data_type, configs["example_data_path"], tokenizer, test_conf, partition=False
    )

    test_data_loader = DataLoader(test_dataset, batch_size=1, num_workers=0)

    example = next(iter(test_data_loader))
    example["feats"] = example["feats"][:, :, :123, :]
    return example
