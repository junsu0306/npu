from typing import Optional, Any, Tuple, Type

from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.base import (
    ModelingWeNetBase,
)
from qbcompiler.model_dict.common import (
    ActivationSpec,
)

import wenet.transformer.label_smoothing_loss as wenet_transformer_label_smoothing_loss


class LabelSmoothingLoss(ModelingWeNetBase):
    """Label-smoothing loss.

    In a standard CE loss, the label's data distribution is:
    [0,1,2] ->
    [
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [0.0, 0.0, 1.0],
    ]

    In the smoothing version CE Loss,some probabilities
    are taken from the true label prob (1.0) and are divided
    among other labels.

    e.g.
    smoothing=0.1
    [0,1,2] ->
    [
        [0.9, 0.05, 0.05],
        [0.05, 0.9, 0.05],
        [0.05, 0.05, 0.9],
    ]

    Args:
        size (int): the number of class
        padding_idx (int): padding class id which will be ignored for loss
        smoothing (float): smoothing rate (0.0 means the conventional CE)
        normalize_length (bool):
            normalize loss by sequence length if True
            normalize loss by batch size if False
    """

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_label_smoothing_loss.LabelSmoothingLoss

    def forward(self, x: ActivationSpec, target: ActivationSpec) -> ActivationSpec:
        """Compute loss between x and target.

        The model outputs and data labels tensors are flatten to
        (batch*seqlen, class) shape and a mask is applied to the
        padding part which should not be calculated for loss.

        Args:
            x (ActivationSpec): prediction (batch, seqlen, class)
            target (ActivationSpec):
                target signal masked with self.padding_id (batch, seqlen)
        Returns:
            loss (ActivationSpec) : The KL loss, scalar float value
        """
        raise NotImplementedError("LabelSmoothingLoss is not Implemented")
        # assert x.size(2) == self.size
        # batch_size = x.size(0)
        # x = x.view(-1, self.size)
        # target = target.view(-1)
        # # use zeros_like instead of torch.no_grad() for true_dist,
        # # since no_grad() can not be exported by JIT
        # true_dist = torch.zeros_like(x)
        # true_dist.fill_(self.smoothing / (self.size - 1))
        # ignore = target == self.padding_idx  # (B,)
        # total = len(target) - ignore.sum().item()
        # target = target.masked_fill(ignore, 0)  # avoid -1 index
        # true_dist.scatter_(1, target.unsqueeze(1), self.confidence)
        # kl = self.criterion(torch.log_softmax(x, dim=1), true_dist)
        # denom = total if self.normalize_length else batch_size
        # return kl.masked_fill(ignore.unsqueeze(1), 0).sum() / denom
