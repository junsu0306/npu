from typing import Optional, Any, Tuple, Type
import logging
import torch
import os
import wenet.transformer.decoder as wenet_transformer_decoder
from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.base import (
    ModelingWeNetBase,
)
from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.attention import KVCache
from qbcompiler.model_dict.common import (
    ModelDict,
    ActivationSpec,
    DataFormat,
    Operator,
    LayerType,
    DimValue,
)
from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.decoder_layer import (
    DecoderLayer,
)
from typing import Dict, List, Optional, Tuple


class BiTransformerDecoder(ModelingWeNetBase):
    """Base class of Transfomer decoder module.
    Args:
        vocab_size: output dim
        encoder_output_size: dimension of attention
        attention_heads: the number of heads of multi head attention
        linear_units: the hidden units number of position-wise feedforward
        num_blocks: the number of decoder blocks
        r_num_blocks: the number of right to left decoder blocks
        dropout_rate: dropout rate
        self_attention_dropout_rate: dropout rate for attention
        input_layer: input layer type
        use_output_layer: whether to use output layer
        pos_enc_class: PositionalEncoding or ScaledPositionalEncoding
        normalize_before:
            True: use layer_norm before each sub-block of a layer.
            False: use layer_norm after each sub-block of a layer.
        key_bias: whether use bias in attention.linear_k, False for whisper models.
    """

    __slots__ = ("use_sdpa", "tie_word_embedding", "left_decoder", "right_decoder")

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_decoder.BiTransformerDecoder

    def forward(
        self,
        memory: ActivationSpec,
        ys_in_pad: ActivationSpec,
        r_ys_in_pad: ActivationSpec,
    ) -> Tuple[ActivationSpec, ActivationSpec, ActivationSpec]:
        """Forward decoder.
        Args:
            memory: encoded memory, float32  (batch, maxlen_in, feat)
            memory_mask: encoder memory mask, (batch, 1, maxlen_in)
            ys_in_pad: padded input token ids, int64 (batch, maxlen_out)
            ys_in_lens: input lengths of this batch (batch)
            r_ys_in_pad: padded input token ids, int64 (batch, maxlen_out),
                used for right to left decoder
            reverse_weight: used for right to left decoder
        Returns:
            (tuple): tuple containing:
                x: decoded token score before softmax (batch, maxlen_out,
                    vocab_size) if use_ouput_layer is True,
                r_x: x: decoded token score (right to left decoder)
                    before softmax (batch, maxlen_out, vocab_size)
                    if use_output_layer is True,
                olens: (batch, )
        """
        l_x, _, olens = self.left_decoder(memory, None, ys_in_pad)

        r_x, _, olens = self.right_decoder(memory, None, r_ys_in_pad)

        return l_x, r_x, olens


class TransformerDecoder(ModelingWeNetBase):
    """Base class of Transfomer decoder module.
    Args:
        vocab_size: output dim
        encoder_output_size: dimension of attention
        attention_heads: the number of heads of multi head attention
        linear_units: the hidden units number of position-wise feedforward
        num_blocks: the number of decoder blocks
        dropout_rate: dropout rate
        self_attention_dropout_rate: dropout rate for attention
        input_layer: input layer type
        use_output_layer: whether to use output layer
        pos_enc_class: PositionalEncoding or ScaledPositionalEncoding
        normalize_before:
            True: use layer_norm before each sub-block of a layer.
            False: use layer_norm after each sub-block of a layer.
        src_attention: if false, encoder-decoder cross attention is not
                       applied, such as CIF model
        query_bias: whether use bias in attention.linear_q
        key_bias: whether use bias in attention.linear_k, False for whisper models.
        value_bias: whether use bias in attention.linear_v
        gradient_checkpointing: rerunning a forward-pass segment for each
            checkpointed segment during backward.
        tie_word_embedding: Tie or clone module weights depending of whether we are
            using TorchScript or not
    """

    __slots__ = (
        "use_sdpa",
        "embed",
        "after_norm",
        "output_layer",
        "decoders",
        "gradient_checkpointing",
        "normalize_before",
        "use_output_layer",
        "training",
    )

    @property
    def target_module_type(self) -> Type:
        return wenet_transformer_decoder.TransformerDecoder

    def forward(
        self,
        memory: ActivationSpec,
        memory_mask: ActivationSpec,
        x: ActivationSpec,
    ) -> Tuple[ActivationSpec, ActivationSpec, ActivationSpec]:
        """Forward decoder.
        Args:
            memory: encoded memory, float32  (batch, maxlen_in, feat)
            memory_mask: encoder memory mask, (batch, 1, maxlen_in)
            ys_in_pad: padded input token ids, int64 (batch, maxlen_out)
            ys_in_lens: input lengths of this batch (batch)
            r_ys_in_pad: not used in transformer decoder, in order to unify api
                with bidirectional decoder
            reverse_weight: not used in transformer decoder, in order to unify
                api with bidirectional decode
        Returns:
            (tuple): tuple containing:
                x: decoded token score before softmax (batch, maxlen_out,
                    vocab_size) if use_output_layer is True,
                torch.tensor(0.0), in order to unify api with bidirectional decoder
                olens: (batch, )
        NOTE(xcsong):
            We pass the `__call__` method of the modules instead of `forward` to the
            checkpointing API because `__call__` attaches all the hooks of the module.
            https://discuss.pytorch.org/t/any-different-between-model-input-and-model-forward-input/3690/2
        """

        if self.use_sdpa:
            raise NotImplementedError("use_sdpa not implemented")
        tgt_mask = None
        if self.gradient_checkpointing and self.training:
            raise NotImplementedError("not implemented")
        else:
            x = self.forward_layers(x, tgt_mask, memory, memory_mask)
        if self.normalize_before:
            x = self.after_norm(x)
        if self.use_output_layer:
            x = self.output_layer(x)
        olens = None
        return x, 0.0, olens

    def forward_layers(
        self,
        x: ActivationSpec,
        tgt_mask: ActivationSpec,
        memory: ActivationSpec,
        memory_mask: ActivationSpec,
    ) -> ActivationSpec:
        for layer in self.decoders:
            x, tgt_mask, memory, memory_mask = layer(x, tgt_mask, memory, memory_mask)
        return x

    def forward_one_step(
        self,
        memory: ActivationSpec,
        memory_mask: ActivationSpec,
        tgt: ActivationSpec,
        tgt_mask: ActivationSpec,
        cache: Dict[str, Dict[str, KVCache]],
    ) -> torch.Tensor:
        """Forward one step.
            This is only used for decoding.
        Args:
            memory: encoded memory, float32  (batch, maxlen_in, feat)
            memory_mask: encoded memory mask, (batch, 1, maxlen_in)
            tgt: input token ids, int64 (batch, maxlen_out)
            tgt_mask: input token mask,  (batch, maxlen_out)
                      dtype=torch.uint8 in PyTorch 1.2-
                      dtype=torch.bool in PyTorch 1.2+ (include 1.2)
            cache: cached output list of (batch, max_time_out-1, size)
        Returns:
            y, cache: NN output value and cache per `self.decoders`.
            y.shape` is (batch, maxlen_out, token)
        """
        x, _ = self.embed(tgt)
        update_cross_att_cache = True
        if len(cache["cross_att_cache"]) != 0:
            assert len(cache["cross_att_cache"]) == self.num_blocks
            update_cross_att_cache = False
        for i, decoder in enumerate(self.decoders):
            layer_i = "layer_{}".format(i)
            self_att_cache = cache["self_att_cache"].get(layer_i, None)
            cross_att_cache = cache["cross_att_cache"].get(layer_i, None)
            c = {
                "self_att_cache": self_att_cache,
                "cross_att_cache": cross_att_cache,
            }
            x, tgt_mask, memory, memory_mask = decoder(
                x, tgt_mask, memory, memory_mask, cache=c
            )

            # update cache dict
            assert c["self_att_cache"] is not None
            assert c["cross_att_cache"] is not None
            cache["self_att_cache"][layer_i] = c["self_att_cache"]
            if update_cross_att_cache:
                cache["cross_att_cache"][layer_i] = c["cross_att_cache"]

        if self.normalize_before:
            y = self.after_norm(x[:, -1])
        else:
            y = x[:, -1]
        if self.use_output_layer:
            y = torch.log_softmax(self.output_layer(y), dim=-1)
        return y

    def tie_or_clone_weights(self, jit_mode: bool = True):
        """Tie or clone module weights (between word_emb and output_layer)
        depending of whether we are using TorchScript or not"""
        rank = int(os.environ.get("RANK", 0))
        if not self.use_output_layer:
            return
        if not self.tie_word_embedding:
            return
        if jit_mode:
            if rank == 0:
                logging.info("clone emb.weight to output.weight")
            self.output_layer.weight = torch.nn.Parameter(self.embed[0].weight.clone())
        else:
            if rank == 0:
                logging.info("tie emb.weight with output.weight")
            self.output_layer.weight = self.embed[0].weight

        if getattr(self.output_layer, "bias", None) is not None:
            self.output_layer.bias.data = torch.nn.functional.pad(
                self.output_layer.bias.data,
                (
                    0,
                    self.output_layer.weight.shape[0] - self.output_layer.bias.shape[0],
                ),
                "constant",
                0,
            )
