import abc
import copy
import math
from typing import Any

import melo.models as melo_models
import torch

from qbcompiler.model_dict.common import ActivationSpec, DataFormat
from qbcompiler.model_dict.common.item_specs import DimValue
from qbcompiler.model_dict.parser.backend.misc.myshell_ai.make_modules import (
    make_dynamic_object,
)
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase
from . import modules


class MeloModelsBase(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name, make_module_func=make_dynamic_object)


class SynthesizerTrn(MeloModelsBase):
    __slots__ = (
        "n_speakers",
        "emb_g",
        "use_vc",
        "enc_p",
        "sdp",
        "dp",
        "flow",
        "dec",
        "max_len",
    )

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> str:
        return melo_models.SynthesizerTrn

    def infer(
        self,
        x,
        x_lengths,
        sid,
        tone,
        language,
        bert,
        ja_bert,
        noise_scale=0.667,
        length_scale=1,
        noise_scale_w=0.8,
        max_len=None,
        sdp_ratio=0,
        y=None,
        g=None,
        feed_dict=None,
        trn1_seq_len=582,
    ):
        # x, m_p, logs_p, x_mask = self.enc_p(x, x_lengths, tone, language, bert)
        # g = self.gst(y)

        builder0 = self.get_builder("synthesizer_trn0")
        self.emb_g.set_builder(builder0)
        self.enc_p.set_builder(builder0)
        self.sdp.set_builder(builder0)
        self.dp.set_builder(builder0)

        use_g_const = True
        use_bert_const = True

        # fmt:off
        builder0.add_activation(x)
        builder0.add_activation(x_lengths)
        builder0.add_activation(tone)
        builder0.add_activation(language)
        builder0.add_activation(ja_bert)

        builder0.make_input(x)
        builder0.make_input(x_lengths)
        builder0.make_input(tone)
        builder0.make_input(language)
        builder0.make_input(ja_bert)

        if use_bert_const:
            bert = torch.zeros(tuple(int(x)for x in bert.get_act_src_shape())).to(self.emb_g.reference_model.weight.device)
        else:
            builder0.add_activation(bert)
            builder0.make_input(bert)

        # fmt:on
        if use_g_const:
            # g_path = str(pathlib.Path(os.path.abspath(__file__)).parent / "data/g.pt")
            # g = torch.load(g_path)
            g = self.emb_g.reference_model(
                torch.tensor([0]).to(self.emb_g.reference_model.weight.device)
            ).unsqueeze(-1)
        else:
            builder0.add_activation(sid)
            builder0.make_input(sid)

        if g is None:
            if self.n_speakers > 0:
                # g = self.emb_g(sid).unsqueeze(-1)  # [b, h, 1], (1,256,1)
                g = builder0.make_unsqueeze(self.emb_g(sid), axis=-1)
            else:
                raise NotImplementedError
                # g = self.ref_enc(y.transpose(1, 2)).unsqueeze(-1)
        if self.use_vc:
            raise NotImplementedError
            # g_p = None
        else:
            g_p = g  # (1,256,1)
        x, m_p, logs_p, x_mask = self.enc_p(
            x, x_lengths, tone, language, bert, ja_bert, g=g_p
        )  # ., torch.Size([1, 192, 149]), torch.Size([1, 192, 149]), torch.Size([1, 192, 149]), torch.Size([1, 1, 149])
        # logw = self.sdp(x, x_mask, g=g, reverse=True, noise_scale=noise_scale_w) * (
        #     sdp_ratio
        # ) + self.dp(x, x_mask, g=g) * (1 - sdp_ratio)  # torch.Size([1, 1, 149])
        sdp_out = self.sdp(x, x_mask, g=g, reverse=True, noise_scale=noise_scale_w)
        sdp_out = builder0.make_mul(sdp_out, sdp_ratio)
        dp_out = self.dp(x, x_mask, g=g)
        dp_out = builder0.make_mul(dp_out, (1 - sdp_ratio))
        logw = builder0.make_add(sdp_out, dp_out)

        builder0.make_output(logw)
        builder0.make_output(m_p)
        builder0.make_output(logs_p)

        # ========================= subgraph0 done ==============================

        # we will not parse this part for the moment

        # w = torch.exp(logw) * x_mask * length_scale  # torch.Size([1, 1, 149])
        # w_ceil = torch.ceil(w)  # torch.Size([1, 1, 149])
        # y_lengths = torch.clamp_min(
        #     torch.sum(w_ceil, [1, 2]), 1
        # ).long()  # torch.Size([1])
        # y_mask = torch.unsqueeze(commons.sequence_mask(y_lengths, None), 1).to(
        #     x_mask.dtype
        # )  # torch.Size([1, 1, 582])
        # attn_mask = torch.unsqueeze(x_mask, 2) * torch.unsqueeze(
        #     y_mask, -1
        # )  # torch.Size([1, 1, 582, 149])
        # attn = commons.generate_path(w_ceil, attn_mask)  # torch.Size([1, 1, 582, 149])
        #
        # m_p = torch.matmul(attn.squeeze(1), m_p.transpose(1, 2)).transpose(
        #     1, 2
        # )  # [b, t', t], [b, t, d] -> [b, d, t'] , torch.Size([1, 192, 582])
        # logs_p = torch.matmul(attn.squeeze(1), logs_p.transpose(1, 2)).transpose(
        #     1, 2
        # )  # [b, t', t], [b, t, d] -> [b, d, t'] , torch.Size([1, 192, 582])
        #
        # z_p = (
        #     m_p + torch.randn_like(m_p) * torch.exp(logs_p) * noise_scale
        # )  # torch.Size([1, 192, 582])

        # ========================= subgraph1 ==========582====================

        builder1 = self.get_builder("synthesizer_trn1")
        self.flow.set_builder(builder1)
        self.dec.set_builder(builder1)

        # seq_len = 582
        if "y_mask" in feed_dict:
            y_mask_val = feed_dict["y_mask"]
            z_p_val = feed_dict["z_p"]
        else:
            # for the case of synthesizerTrn0 parse
            seq_len = 582 if trn1_seq_len is None else trn1_seq_len
            y_mask_val = torch.ones(1, 1, seq_len)
            z_p_val = torch.randn(1, 192, seq_len)

        if trn1_seq_len is None:
            trn1_seq_len = DimValue(y_mask_val.shape[-1], dynamic=True)
        z_p = ActivationSpec(
            name="z_p",
            src_shape=(z_p_val.shape[0], z_p_val.shape[1], trn1_seq_len),
            dataformat=DataFormat.UNKNOWN,
            dtype="float32",
        )
        builder1.add_activation(z_p)
        builder1.make_input(z_p)

        if isinstance(g, torch.Tensor):
            g_copy = g
        else:
            g_copy = copy.deepcopy(g)
            builder1.add_activation(g_copy)
            builder1.make_input(g_copy)

        z = self.flow(
            z_p, y_mask_val, g=g_copy, reverse=True
        )  # torch.Size([1, 192, 582])
        # o = self.dec((z * y_mask)[:, :, :max_len], g=g)  # torch.Size([1, 1, 297984])
        z_y_mask_mul = builder1.make_mul(z, y_mask_val)
        if max_len is not None:
            z_y_mask_mul = builder1.make_slice(
                z_y_mask_mul, axis=(2,), start=(0,), end=(max_len,)
            )
        o = self.dec(z_y_mask_mul, g=g)

        # print('max/min of o:', o.max(), o.min())
        # return o, attn, y_mask, (z, z_p, m_p, logs_p)
        builder1.make_output(o)
        return (o,)


class TextEncoder(MeloModelsBase):
    __slots__ = (
        "bert_proj",
        "ja_bert_proj",
        "emb",
        "tone_emb",
        "language_emb",
        "hidden_channels",
        "encoder",
        "proj",
        "out_channels",
    )

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> str:
        return melo_models.TextEncoder

    def forward(self, x, x_lengths, tone, language, bert, ja_bert, g=None):
        # bert_emb = self.bert_proj(bert).transpose(1, 2) # torch.Size([1, 149, 192])
        if isinstance(bert, torch.Tensor):
            bert_emb = self.bert_proj.reference_model(bert).transpose(1, 2)
        else:
            bert_emb = self.builder.make_transpose(self.bert_proj(bert), (0, 2, 1))
        # ja_bert_emb = self.ja_bert_proj(ja_bert).transpose(1, 2)  # torch.Size([1, 149, 192])
        ja_bert_emb = self.builder.make_transpose(self.ja_bert_proj(ja_bert), (0, 2, 1))

        # x = (
        #     self.emb(x)
        #     + self.tone_emb(tone)
        #     + self.language_emb(language)
        #     + bert_emb
        #     + ja_bert_emb
        # ) * math.sqrt(
        #     self.hidden_channels
        # )  # [b, t, h]  # torch.Size([1, 149, 192])

        x = self.builder.make_add(self.emb(x), self.tone_emb(tone))
        x = self.builder.make_add(x, self.language_emb(language))

        # we strip out phones, tones, language embeddgins from here
        phone_tone_lang_emb = ja_bert_emb.copy(name="phone_tone_lang_emb")
        self.builder.add_activation(phone_tone_lang_emb)
        x = self.builder.make_input(phone_tone_lang_emb)
        bert_add = self.builder.make_add(bert_emb, ja_bert_emb)
        # x = self.builder.make_add(x, bert_emb)
        # x = self.builder.make_add(x, ja_bert_emb)
        x = self.builder.make_add(x, bert_add)
        x = self.builder.make_mul(x, math.sqrt(self.hidden_channels))

        # x = torch.transpose(x, 1, -1)  # [b, h, t] torch.Size([1, 192, 149])
        x = self.builder.make_transpose(x, (0, 2, 1))
        # x_lengths에는 모델 처음 인풋의 phones.shape[0](=149)이 있음. 현재는 그냥 x.size(2)와 같음.
        # x_mask = [[[True, True, ....]]]
        # x_mask = torch.unsqueeze(commons.sequence_mask(x_lengths, x.size(2)), 1).to(
        #     x.dtype
        # )  # torch.Size([1, 1, 149])
        x_mask = torch.FloatTensor(1, 1, int(x.get_act_src_shape()[2]))
        x_mask[:] = 1.0
        x = self.encoder(
            self.builder.make_mul(x, x_mask), x_mask, g=g
        )  # torch.Size([1, 192, 149])
        # stats = self.proj(x) * x_mask  # torch.Size([1, 384, 149])
        # x_t = self.builder.make_transpose(x, (0, 2, 1))
        # x_t.dataformat = DataFormat.NXC
        # proj_x = self.builder.make_transpose(self.proj(x_t), (0, 2, 1))
        proj_x = self.proj(x)
        stats = self.builder.make_mul(proj_x, x_mask)

        # m, logs = torch.split(stats, self.out_channels, dim=1)  # torch.Size([1, 192, 149]), torch.Size([1, 192, 149])
        m, logs = self.builder.make_split(stats, self.out_channels, dim=1)
        return x, m, logs, x_mask


class Generator(MeloModelsBase):
    __slots__ = (
        "num_upsamples",
        "conv_pre",
        "ups",
        "num_kernels",
        "conv_post",
        "resblocks",
    )

    def __init__(self, model: Any, module_name: str = ""):
        # Only remove weight_norm if it hasn't been removed already
        # Check if the first upsample layer has weight_g (indicating weight_norm is applied)
        if hasattr(model.ups[0], "weight_g"):
            model.remove_weight_norm()
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> str:
        return melo_models.Generator

    def forward(self, x, g=None):
        x = self.conv_pre(x)  # (1, 512, 587)
        if g is not None:
            # x = x + self.cond(g)
            if isinstance(g, torch.Tensor):
                g_cond = self.cond.reference_model(g)
            else:
                g_cond = self.cond(g)
            x = self.builder.make_add(x, g_cond)

        for i in range(self.num_upsamples):
            # x = F.leaky_relu(x, modules.LRELU_SLOPE)  # (1, 512, 582)
            x = self.builder.make_leaky_relu(x, modules.LRELU_SLOPE)
            # x = self.ups[i](x)# (1, 256, 4656) -> (1,128, 37248) -> (1,64, 74496) -> (1,32, 148992)-> (1,16, 297984)
            x_ups_i_out = self.ups[i](x)
            outval_ref = x_ups_i_out.name
            self.builder.set_output_value_reference(x_ups_i_out, "")  # 삭제.
            # self.builder.set_output_value_reference(x, outval_ref)
            x = x_ups_i_out
            xs = None
            for j in range(self.num_kernels):
                if xs is None:
                    xs = self.resblocks[i * self.num_kernels + j](x)  # (1, 256, 4656)
                else:
                    # xs += self.resblocks[i * self.num_kernels + j](x)  # (1, 256, 4656), (1,128, 37248)
                    xs = self.builder.make_add(
                        xs, self.resblocks[i * self.num_kernels + j](x)
                    )
            # x = xs / self.num_kernels  # (1, 256, 4696)
            x = self.builder.make_div(xs, self.num_kernels)
        # x = F.leaky_relu(x)
        x = self.builder.make_leaky_relu(x)
        x = self.conv_post(x)
        # x = torch.tanh(x)
        x = self.builder.make_tanh(x)
        return x


class PosteriorEncoder(MeloModelsBase):
    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> str:
        return melo_models.PosteriorEncoder


class TransformerCouplingBlock(MeloModelsBase):
    __slots__ = ("flows",)

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> str:
        return melo_models.TransformerCouplingBlock

    def forward(self, x, x_mask, g=None, reverse=False):
        # x: (1,192,587)
        # g: (1,256,1)
        # x_mask: (1,1,587)
        if not reverse:
            raise NotImplementedError
            for flow in self.flows:
                x, _ = flow(x, x_mask, g=g, reverse=reverse)
        else:
            for flow in reversed(self.flows):
                x = flow(x, x_mask, g=g, reverse=reverse)
        return x  # x: (1,192,587)


class StochasticDurationPredictor(MeloModelsBase):
    __slots__ = (
        "pre",
        "cond",
        "convs",
        "proj",
        "flows",
        "post_pre",
        "post_convs",
        "post_proj",
        "post_flows",
    )

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> str:
        return melo_models.StochasticDurationPredictor

    def forward(self, x, x_mask, w=None, g=None, reverse=False, noise_scale=1.0):
        # g: torch.Size([1, 256, 1])
        # x_mask: torch.Size([1, 1, 149])
        # w: None

        # x = torch.detach(x)  # (1,192,149)
        # x = self.pre(x)# torch.Size([1, 192, 149])
        # x = self.builder.make_transpose(x, (0, 2, 1))
        # x.dataformat = DataFormat.NXC
        # x = self.pre(x)
        # x = self.builder.make_transpose(x, (0, 2, 1))
        x = self.pre(x)
        if g is not None:
            # g = torch.detach(g)
            # x = x + self.cond(g)
            if isinstance(g, torch.Tensor):
                g_cond = self.cond.reference_model(g)
            else:
                g_cond = self.cond(g)
            x = self.builder.make_add(x, g_cond)  # torch.Size([1, 192, 149])
        x = self.convs(x, x_mask)  # torch.Size([1, 192, 149])
        # x = self.proj(x) * x_mask
        # x = self.builder.make_transpose(x, (0, 2, 1))
        # x.dataformat = DataFormat.NXC
        # x = self.builder.make_transpose(self.proj(x), (0, 2, 1))
        x = self.proj(x)
        x = self.builder.make_mul(x, x_mask)

        if not reverse:
            raise NotImplementedError
            # flows = self.flows
            # assert w is not None
            #
            # logdet_tot_q = 0
            # h_w = self.post_pre(w)
            # h_w = self.post_convs(h_w, x_mask)
            # h_w = self.post_proj(h_w) * x_mask
            # e_q = (
            #     torch.randn(w.size(0), 2, w.size(2)).to(device=x.device, dtype=x.dtype)
            #     * x_mask
            # )
            # z_q = e_q
            # for flow in self.post_flows:
            #     z_q, logdet_q = flow(z_q, x_mask, g=(x + h_w))
            #     # logdet_tot_q += logdet_q
            #     self.builder.make_add(logdet_tot_q, logdet_q)

        #     z_u, z1 = torch.split(z_q, [1, 1], 1)
        #     u = torch.sigmoid(z_u) * x_mask
        #     z0 = (w - u) * x_mask
        #     logdet_tot_q += torch.sum(
        #         (F.logsigmoid(z_u) + F.logsigmoid(-z_u)) * x_mask, [1, 2]
        #     )
        #     logq = (
        #         torch.sum(-0.5 * (math.log(2 * math.pi) + (e_q**2)) * x_mask, [1, 2])
        #         - logdet_tot_q
        #     )
        #
        #     logdet_tot = 0
        #     z0, logdet = self.log_flow(z0, x_mask)
        #     logdet_tot += logdet
        #     z = torch.cat([z0, z1], 1)
        #     for flow in flows:
        #         z, logdet = flow(z, x_mask, g=x, reverse=reverse)
        #         logdet_tot = logdet_tot + logdet
        #     nll = (
        #         torch.sum(0.5 * (math.log(2 * math.pi) + (z**2)) * x_mask, [1, 2])
        #         - logdet_tot
        #     )
        #     return nll + logq  # [b]
        else:
            flows = list(reversed(self.flows))
            flows = flows[:-2] + [flows[-1]]  # remove a useless vflow
            # z = (
            #     torch.randn(x.size(0), 2, x.size(2)).to(device=x.device, dtype=x.dtype)
            #     * noise_scale
            # )  # torch.Size([1, 2, 149])

            z = ActivationSpec(
                name="z",
                dtype="float32",
                src_shape=(x.get_act_src_shape()[0], 2, x.get_act_src_shape()[2]),
                dataformat=DataFormat.UNKNOWN,
            )
            self.builder.add_activation(z)
            self.builder.make_input(z)
            for flow in flows:
                z = flow(z, x_mask, g=x, reverse=reverse)
            # z0, z1 = torch.split(z, [1, 1], 1)  # (1,1,149), (1,1,149)
            z0, z1 = self.builder.make_split(z, [1, 1], dim=1)
            logw = z0
            return logw


class DurationPredictor(MeloModelsBase):
    __slots__ = ("conv_1", "norm_1", "drop", "conv_2", "norm_2", "proj", "cond")

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> str:
        return melo_models.DurationPredictor

    def forward(self, x, x_mask, g=None):
        # x = torch.detach(x)
        if g is not None:
            # g = torch.detach(g)  # torch.Size([1, 256, 1])
            # x = x + self.cond(g)  # torch.Size([1, 192, 149])
            # g = self.builder.make_transpose(g, (0, 2, 1))
            # g.dataformat = DataFormat.NXC
            # cond_g = self.builder.make_transpose(self.cond(g), (0, 2, 1))
            if isinstance(g, torch.Tensor):
                cond_g = self.cond.reference_model(g)
            else:
                cond_g = self.cond(g)
            x = self.builder.make_add(x, cond_g)

        # x = self.conv_1(x * x_mask)
        # x = torch.relu(x)  # torch.Size([1, 256, 149])
        # xxt = self.builder.make_transpose(self.builder.make_mul(x, x_mask), (0, 2, 1))
        # xxt.dataformat = DataFormat.NXC
        xxt = self.builder.make_mul(x, x_mask)
        x = self.conv_1(xxt)
        x = self.builder.make_relu(x)
        # x = self.builder.make_transpose(x, (0, 2, 1))
        x = self.norm_1(x)
        x = self.drop(x)
        self.builder.set_output_value_reference(x, "")  # 아래에 drop이 다시 사용되어 삭제함.

        # x = self.conv_2(x * x_mask)  # torch.Size([1, 256, 149])
        # x = torch.relu(x)
        # xxt = self.builder.make_transpose(self.builder.make_mul(x, x_mask), (0, 2, 1))
        # xxt.dataformat = DataFormat.NXC
        xxt = self.builder.make_mul(x, x_mask)
        x = self.conv_2(xxt)
        x = self.builder.make_relu(x)
        # x = self.builder.make_transpose(x, (0, 2, 1))
        x = self.norm_2(x)
        x = self.drop(x)

        # x = self.proj(x * x_mask)  # torch.Size([1, 1, 149])
        # xxt = self.builder.make_transpose(self.builder.make_mul(x, x_mask), (0, 2, 1))
        # xxt.dataformat = DataFormat.NXC
        # x = self.builder.make_transpose(self.proj(xxt), (0, 2, 1))
        xxt = self.builder.make_mul(x, x_mask)
        x = self.proj(xxt)

        # return x * x_mask
        return self.builder.make_mul(x, x_mask)
