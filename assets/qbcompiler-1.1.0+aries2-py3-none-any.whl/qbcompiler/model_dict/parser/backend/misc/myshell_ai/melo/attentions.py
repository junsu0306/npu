import abc
import math
from typing import Any, Type

import melo.attentions as melo_attentions
import torch
import torch.nn.functional as F

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.misc.myshell_ai.make_modules import (
    make_dynamic_object,
)
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase
from . import commons


class MeloAttentionBase(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name, make_module_func=make_dynamic_object)


class Encoder(MeloAttentionBase):
    __slots__ = (
        "n_layers",
        "cond_layer_idx",
        "spk_emb_linear",
        "attn_layers",
        "drop",
        "norm_layers_1",
        "norm_layers_2",
        "ffn_layers",
    )

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return melo_attentions.Encoder

    def forward(self, x: ActivationSpec, x_mask: torch.Tensor, g=None):
        # g: (1,256,1)
        # x: (1,192,149)
        attn_mask = x_mask.unsqueeze(2) * x_mask.unsqueeze(-1)
        # x = x * x_mask
        x = self.builder.make_mul(x, x_mask)
        for i in range(self.n_layers):
            if i == self.cond_layer_idx and g is not None:
                # g = self.spk_emb_linear(g.transpose(1, 2))
                # g = g.transpose(1, 2)
                # x = x + g
                # x = x * x_mask
                if isinstance(g, torch.Tensor):
                    g = self.spk_emb_linear.reference_model(g.transpose(1, 2))
                    g = g.transpose(1, 2)
                else:
                    g = self.builder.make_transpose(g, (0, 2, 1))
                    g = self.spk_emb_linear(g)
                    g = self.builder.make_transpose(g, (0, 2, 1))
                x = self.builder.make_add(x, g)
                x = self.builder.make_mul(x, x_mask)
            y = self.attn_layers[i](x, x, attn_mask)  # torch.Size([1, 192, 149])
            y = self.drop(y)
            self.builder.set_output_value_reference(
                y, ""
            )  # 아래에 drop이 다시 사용되므로 삭제

            x = self.norm_layers_1[i](
                self.builder.make_add(x, y)
            )  # torch.Size([1, 192, 149])

            y = self.ffn_layers[i](x, x_mask)  # torch.Size([1, 192, 149])
            y = self.drop(y)
            x = self.norm_layers_2[i](
                self.builder.make_add(x, y)
            )  # torch.Size([1, 192, 149])
        # x = x * x_mask
        x = self.builder.make_mul(x, x_mask)
        return x


class MultiHeadAttention(MeloAttentionBase):
    __slots__ = (
        "conv_q",
        "conv_k",
        "conv_v",
        "attn",
        "conv_o",
        "n_heads",
        "k_channels",
        "window_size",
        "emb_rel_k",
        "proximal_bias",
        "block_length",
        "emb_rel_v",
        "drop",
    )

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self):
        return melo_attentions.MultiHeadAttention

    def _matmul_with_relative_values(self, x, y):
        """
        x: [b, h, l, m]
        y: [h or 1, m, d]
        ret: [b, h, l, d]
        """
        ret = torch.matmul(x, y.unsqueeze(0))
        return ret

    def _matmul_with_relative_keys(self, x, y):
        """
        x: [b, h, l, d]
        y: [h or 1, m, d]
        ret: [b, h, l, m]
        """
        ret = torch.matmul(x, y.unsqueeze(0).transpose(-2, -1))
        return ret

    def _get_relative_embeddings(self, relative_embeddings, length):
        # Pad first before slice to avoid using cond ops.
        pad_length = max(length - (self.window_size + 1), 0)
        slice_start_position = max((self.window_size + 1) - length, 0)
        slice_end_position = slice_start_position + 2 * length - 1
        if pad_length > 0:
            padded_relative_embeddings = F.pad(
                relative_embeddings,
                commons.convert_pad_shape([[0, 0], [pad_length, pad_length], [0, 0]]),
            )
        else:
            padded_relative_embeddings = relative_embeddings
        used_relative_embeddings = padded_relative_embeddings[
            :, slice_start_position:slice_end_position
        ]
        return used_relative_embeddings

    def _relative_position_to_absolute_position(self, x):
        """
        x: [b, h, l, 2*l-1]
        ret: [b, h, l, l]
        """
        batch, heads, length, _ = x.size()
        # Concat columns of pad to shift from relative to absolute indexing.
        x = F.pad(x, commons.convert_pad_shape([[0, 0], [0, 0], [0, 0], [0, 1]]))

        # Concat extra elements so to add up to shape (len+1, 2*len-1).
        x_flat = x.view([batch, heads, length * 2 * length])
        x_flat = F.pad(
            x_flat, commons.convert_pad_shape([[0, 0], [0, 0], [0, length - 1]])
        )

        # Reshape and slice out the padded elements.
        x_final = x_flat.view([batch, heads, length + 1, 2 * length - 1])[
            :, :, :length, length - 1 :
        ]
        return x_final

    def _absolute_position_to_relative_position(self, x):
        """
        x: [b, h, l, l]
        ret: [b, h, l, 2*l-1]
        """
        batch, heads, length, _ = x.size()
        # pad along column
        x = F.pad(
            x, commons.convert_pad_shape([[0, 0], [0, 0], [0, 0], [0, length - 1]])
        )
        x_flat = x.view([batch, heads, length**2 + length * (length - 1)])
        # add 0's in the beginning that will skew the elements after reshape
        x_flat = F.pad(x_flat, commons.convert_pad_shape([[0, 0], [0, 0], [length, 0]]))
        x_final = x_flat.view([batch, heads, length, 2 * length])[:, :, :, 1:]
        return x_final

    def forward(self, x, c, attn_mask=None):
        # x = self.builder.make_transpose(x, (0, 2, 1))
        # x.dataformat = DataFormat.NXC
        # c = self.builder.make_transpose(c, (0, 2, 1))
        # c.dataformat = DataFormat.NXC

        # q = self.conv_q(x)  # torch.Size([1, 192, 149])
        # q = self.builder.make_transpose(self.conv_q(x), (0, 2, 1))
        q = self.conv_q(x)

        # k = self.conv_k(c)  # torch.Size([1, 192, 149])
        # k = self.builder.make_transpose(self.conv_k(c), (0, 2, 1))
        k = self.conv_k(c)

        # v = self.conv_v(c)  # torch.Size([1, 192, 149])
        # v = self.builder.make_transpose(self.conv_v(c), (0, 2, 1))
        v = self.conv_v(c)

        x, self.attn = self.attention(
            q, k, v, mask=attn_mask
        )  # torch.Size([1, 192, 149]),  #torch.Size([1, 2, 149, 149])

        # x = self.conv_o(x)  # torch.Size([1, 192, 149])
        # x = self.builder.make_transpose(x, (0, 2, 1))
        # x.dataformat = DataFormat.NXC
        # x = self.builder.make_transpose(self.conv_o(x), (0, 2, 1))
        x = self.conv_o(x)
        return x

    def attention(self, query, key, value, mask=None):
        # reshape [b, d, t] -> [b, n_h, t, d_k]
        # b, d, t_s, t_t = (*key.size(), query.size(2))  # 1, 192, 579,579
        b, d, t_s = key.get_act_src_shape()
        t_t = query.get_act_src_shape()[2]

        # query = query.view(b, self.n_heads, self.k_channels, t_t).transpose(
        #     2, 3
        # )  # ( 1,2,579, 96)
        query = self.builder.make_transpose(
            self.builder.make_reshape(query, (b, self.n_heads, self.k_channels, t_t)),
            (0, 1, 3, 2),
        )
        # key = key.view(b, self.n_heads, self.k_channels, t_s).transpose(
        #     2, 3
        # )  # ( 1,2, 579, 96)
        key = self.builder.make_transpose(
            self.builder.make_reshape(key, (b, self.n_heads, self.k_channels, t_s)),
            (0, 1, 3, 2),
        )
        # value = value.view(b, self.n_heads, self.k_channels, t_s).transpose(
        #     2, 3
        # )  # ( 1,2, 579, 96)
        value = self.builder.make_transpose(
            self.builder.make_reshape(value, (b, self.n_heads, self.k_channels, t_s)),
            (0, 1, 3, 2),
        )

        # scores = torch.matmul(
        #     query / math.sqrt(self.k_channels), key.transpose(-2, -1)
        # )  # torch.Size([1, 2, 579, 579])
        scores = self.builder.make_matmul(
            query, self.builder.make_transpose(key, (0, 1, 3, 2))
        )
        scores = self.builder.make_mul(scores, 1 / math.sqrt(self.k_channels))

        if self.window_size is not None:
            assert (
                t_s == t_t
            ), "Relative attention is only available for self-attention."
            # key_relative_embeddings = self._get_relative_embeddings(self.emb_rel_k, t_s)  # torch.Size([1, 1157, 96])
            # rel_logits = self._matmul_with_relative_keys(query / math.sqrt(self.k_channels), key_relative_embeddings)  # torch.Size([1, 2, 579, 1157])
            # scores_local = self._relative_position_to_absolute_position(rel_logits)  # torch.Size([1, 2, 579, 579])

            emb_rel_k = self.builder.make_inputconst(
                self.emb_rel_k.unsqueeze(0).transpose(-2, -1)
            )
            if (
                emb_rel_k.get_act_src_shape()[1] == 1
                and query.get_act_src_shape()[1] > 1
            ):
                emb_rel_k = self.builder.make_repeat_n(
                    emb_rel_k, num_repeat=int(query.get_act_src_shape()[1])
                )
            if emb_rel_k.get_act_src_shape()[1] != query.get_act_src_shape()[1]:
                raise ValueError
            scores_local = self.builder.make_matmul(query, emb_rel_k)
            scores_local = self.builder.make_mul(
                scores_local, 1 / math.sqrt(self.k_channels)
            )
            scores_local = self.builder.make_staggered_padding(
                scores_local, window_size=self.window_size
            )
            # scores_local = self.builder.make_slice(
            #     scores_local,
            #     axis=(3,),
            #     start=(self.window_size,),
            #     end=(-self.window_size,),
            # )
            # scores = scores + scores_local  # torch.Size([1, 2, 579, 579])
            scores = self.builder.make_add(scores, scores_local)
        if self.proximal_bias:
            raise NotImplementedError
            # assert t_s == t_t, "Proximal bias is only available for self-attention."
            # scores = scores + self._attention_bias_proximal(t_s).to(
            #     device=scores.device, dtype=scores.dtype
            # )
        if mask is not None:
            # 우리는 항상 batch가 1 이어서 마스크가 모두 1
            # scores = scores.masked_fill(mask == 0, -1e4)
            if self.block_length is not None:
                raise NotImplementedError
                # assert (
                #     t_s == t_t
                # ), "Local attention is only available for self-attention."
                # block_mask = (
                #     torch.ones_like(scores)
                #     .triu(-self.block_length)
                #     .tril(self.block_length)
                # )
                # scores = scores.masked_fill(block_mask == 0, -1e4)
        # p_attn = F.softmax(scores, dim=-1)  # [b, n_h, t_t, t_s] #torch.Size([1, 2, 579, 579])
        # p_attn = self.drop(p_attn)
        p_attn = self.builder.make_softmax(scores)
        p_attn = self.drop(p_attn)
        # output = torch.matmul(p_attn, value)  # torch.Size([1, 2, 579, 96])
        output = self.builder.make_matmul(p_attn, value)

        if self.window_size is not None:
            # relative_weights = self._absolute_position_to_relative_position(p_attn)  # torch.Size([1, 2, 579, 1157])
            # value_relative_embeddings = self._get_relative_embeddings(self.emb_rel_v, t_s)  # torch.Size([1, 1157, 96])
            # output = output + self._matmul_with_relative_values(relative_weights, value_relative_embeddings)  # torch.Size([1, 2, 579, 96])

            relative_weights = self.builder.make_staggered_padding(
                p_attn, reverse=True, window_size=self.window_size
            )
            # pad_length = t_s - (self.window_size + 1)
            # relative_weights = self.builder.make_slice(
            #     relative_weights,
            #     axis=(3,),
            #     start=(pad_length,),
            #     end=(pad_length + 2 * self.window_size + 1,),
            # )
            emb_rel_v = self.builder.make_inputconst(self.emb_rel_v.unsqueeze(0))
            if (
                emb_rel_v.get_act_src_shape()[1] == 1
                and relative_weights.get_act_src_shape()[1] > 1
            ):
                emb_rel_v = self.builder.make_repeat_n(
                    emb_rel_v, num_repeat=int(relative_weights.get_act_src_shape()[1])
                )
            if emb_rel_v.get_act_src_shape()[1] != query.get_act_src_shape()[1]:
                raise ValueError
            output = self.builder.make_add(
                output, self.builder.make_matmul(relative_weights, emb_rel_v)
            )
        # output = (output.transpose(2, 3).contiguous().view(b, d, t_t))  # [b, n_h, t_t, d_k] -> [b, d, t_t] #torch.Size([1, 192, 579])
        output = self.builder.make_transpose(output, (0, 1, 3, 2))
        output = self.builder.make_reshape(output, (b, d, t_t))
        return output, p_attn


class LayerNorm(MeloAttentionBase):
    __slots__ = ("channels", "gamma", "beta", "eps")

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self):
        return melo_attentions.LayerNorm

    def forward(self, x):
        # x = x.transpose(1, -1) #torch.Size([1, 192, 149])
        # x = F.layer_norm(x, (self.channels,), self.gamma, self.beta, self.eps) #torch.Size([1, 149, 192])
        # return x.transpose(1, -1)
        x = self.builder.make_transpose(x, (0, 2, 1))
        x = self.builder.make_layernorm(
            x, (self.channels,), scale=self.gamma, bias=self.beta, epsilon=self.eps
        )
        return self.builder.make_transpose(x, (0, 2, 1))


class FFN(MeloAttentionBase):
    __slots__ = (
        "causal",
        "conv_1",
        "padding",
        "activation",
        "drop",
        "conv_2",
        "kernel_size",
    )

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)
        if self.causal:
            self.padding = self._causal_padding
        else:
            self.padding = self._same_padding

    @property
    def target_module_type(self):
        return melo_attentions.FFN

    def forward(self, x, x_mask):
        # x = self.conv_1(self.padding(x * x_mask))  # torch.Size([1, 768, 149])
        x = self.builder.make_mul(x, x_mask)
        pad_l, pad_r = self.padding(x)
        self.conv_1.west_padding += pad_l
        self.conv_1.east_padding += pad_r
        # x = self.builder.make_transpose(x, (0, 2, 1))
        # x.dataformat = DataFormat.NXC
        # x = self.builder.make_transpose(self.conv_1(x), (0, 2, 1))
        x = self.conv_1(x)
        self.conv_1.west_padding -= pad_l
        self.conv_1.east_padding -= pad_r

        if self.activation == "gelu":
            raise NotImplementedError
            # x = x * torch.sigmoid(1.702 * x)
        else:
            # x = torch.relu(x)
            x = self.builder.make_relu(x)
        x = self.drop(x)
        # x = self.conv_2(self.padding(x * x_mask))  # torch.Size([1, 192, 149])
        x = self.builder.make_mul(x, x_mask)
        pad_l, pad_r = self.padding(x)
        self.conv_2.west_padding += pad_l
        self.conv_2.east_padding += pad_r
        # x = self.builder.make_transpose(x, (0, 2, 1))
        # x.dataformat = DataFormat.NXC
        # x = self.builder.make_transpose(self.conv_2(x), (0, 2, 1))
        # return x * x_mask
        x = self.conv_2(x)
        self.conv_2.west_padding -= pad_l
        self.conv_2.east_padding -= pad_r
        return self.builder.make_mul(x, x_mask)

    def _causal_padding(self, x):
        if self.kernel_size == 1:
            # return x
            return 0, 0
        pad_l = self.kernel_size - 1
        pad_r = 0
        # padding = [[0, 0], [0, 0], [pad_l, pad_r]]
        # x = F.pad(x, commons.convert_pad_shape(padding))
        # return x
        return pad_l, pad_r

    def _same_padding(self, x):
        if self.kernel_size == 1:
            # return x
            return 0, 0
        pad_l = (self.kernel_size - 1) // 2
        pad_r = self.kernel_size // 2
        # padding = [[0, 0], [0, 0], [pad_l, pad_r]]
        # x = F.pad(x, commons.convert_pad_shape(padding)) # torch.Size([1, 192, 151])
        # return x
        return pad_l, pad_r
