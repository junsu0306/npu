import abc
import functools
from typing import Any, Type

import melo.modules as melo_modules
import torch

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.misc.myshell_ai.make_modules import (
    make_dynamic_object,
)
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase

LRELU_SLOPE = 0.1


class MeloModulesBase(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name, make_module_func=make_dynamic_object)


class ResBlock1(MeloModulesBase):
    __slots__ = ("convs1", "convs2")

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return melo_modules.ResBlock1

    def forward(self, x, x_mask=None):
        for c1, c2 in zip(self.convs1, self.convs2):
            # xt = F.leaky_relu(x, LRELU_SLOPE)
            xt = self.builder.make_leaky_relu(x, LRELU_SLOPE)
            if x_mask is not None:
                # xt = xt * x_mask
                xt = self.builder.make_mul(xt, x_mask)
            # xt = c1(xt)
            # xt = F.leaky_relu(xt, LRELU_SLOPE)
            xt = c1(xt)
            xt = self.builder.make_leaky_relu(xt, LRELU_SLOPE)
            if x_mask is not None:
                # xt = xt * x_mask
                xt = self.builder.make_mul(xt, x_mask)
            # xt = c2(xt)
            xt = c2(xt)
            # x = xt + x
            x = self.builder.make_add(xt, x)
        if x_mask is not None:
            # x = x * x_mask
            x = self.builder.make_mul(x, x_mask)
        return x


class WN(MeloModulesBase):
    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return melo_modules.WN


class TransformerCouplingLayer(MeloModulesBase):
    __slots__ = ("half_channels", "pre", "enc", "post", "mean_only")

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return melo_modules.TransformerCouplingLayer

    def forward(self, x, x_mask, g=None, reverse=False):
        # x0, x1 = torch.split(x, [self.half_channels] * 2, 1)  # torch.Size([1, 96, 579]),torch.Size([1, 96, 579])
        x0, x1 = self.builder.make_split(x, [self.half_channels] * 2, 1)

        # h = self.pre(x0) * x_mask
        # x0_t = self.builder.make_transpose(x0, (0, 2, 1))
        # x0_t.dataformat = DataFormat.NXC
        # h = self.builder.make_transpose(self.pre(x0_t), (0, 2, 1))
        h = self.pre(x0)
        if torch.any(x_mask != 1):
            h = self.builder.make_mul(h, x_mask)
        h = self.enc(h, x_mask, g=g)  # torch.Size([1, 192, 579])

        # stats = self.post(h) * x_mask  # torch.Size([1, 96, 579])
        # h_t = self.builder.make_transpose(h, (0, 2, 1))
        # h_t.dataformat = DataFormat.NXC
        # stats = self.builder.make_transpose(self.post(h_t), (0, 2, 1))
        stats = self.post(h)
        stats = self.builder.make_mul(stats, x_mask)

        if not self.mean_only:
            # m, logs = torch.split(stats, [self.half_channels] * 2, 1)
            m, logs = self.builder.make_split(stats, [self.half_channels] * 2, 1)
        else:
            # m = stats
            # logs = torch.zeros_like(m)
            m = stats
            logs = torch.zeros(*tuple(int(x) for x in m.get_act_src_shape()))

        if not reverse:
            raise NotImplementedError
            # x1 = m + x1 * torch.exp(logs) * x_mask
            # x = torch.cat([x0, x1], 1)
            # logdet = torch.sum(logs, [1, 2])
            # return x, logdet
        else:
            # x1 = (x1 - m) * torch.exp(-logs) * x_mask
            left_ = self.builder.make_sub(x1, m)
            if isinstance(logs, ActivationSpec):
                right_ = self.builder.make_exp(self.builder.make_neg(logs))
            else:
                right_ = torch.exp(-logs)
            x1 = self.builder.make_mul(self.builder.make_mul(left_, right_), x_mask)
            # x = torch.cat([x0, x1], 1)
            x = self.builder.make_concatenate([x0, x1], 1)
            return x  # torch.Size([1, 192, 579])

        # x1, logabsdet = piecewise_rational_quadratic_transform(
        #     x1,
        #     unnormalized_widths,
        #     unnormalized_heights,
        #     unnormalized_derivatives,
        #     inverse=reverse,
        #     tails="linear",
        #     tail_bound=self.tail_bound,
        # )
        #
        # x = torch.cat([x0, x1], 1) * x_mask
        # logdet = torch.sum(logabsdet * x_mask, [1, 2])
        # if not reverse:
        #     return x, logdet
        # else:
        #     return x


class Log(MeloModulesBase):
    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return melo_modules.Log


class ElementwiseAffine(MeloModulesBase):
    __slots__ = ("m", "logs")

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return melo_modules.ElementwiseAffine

    def forward(self, x, x_mask, reverse=False, **kwargs):
        if not reverse:
            raise NotImplementedError
            # y = self.m + torch.exp(self.logs) * x
            # y = y * x_mask
            # logdet = torch.sum(self.logs * x_mask, [1, 2])
            # return y, logdet
        else:
            # x = (x - self.m) * torch.exp(-self.logs) * x_mask # (1,2,149)
            x = self.builder.make_mul(
                self.builder.make_mul(
                    self.builder.make_sub(x, self.m), torch.exp(-self.logs)
                ),
                x_mask,
            )
            return x


class LayerNorm(MeloModulesBase):
    __slots__ = ("channels", "gamma", "beta", "eps")

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return melo_modules.LayerNorm

    def forward(self, x):
        # x = x.transpose(1, -1)
        # x = F.layer_norm(x, (self.channels,), self.gamma, self.beta, self.eps)
        # return x.transpose(1, -1)
        if len(x.get_act_src_shape()) == 3:
            x = self.builder.make_transpose(x, (0, 2, 1))
            x = self.builder.make_layernorm(
                x,
                normalized_shape=(self.channels,),
                epsilon=self.eps,
                scale=self.gamma,
                bias=self.beta,
            )
            return self.builder.make_transpose(x, (0, 2, 1))
        else:
            raise NotImplementedError


class DDSConv(MeloModulesBase):
    __slots__ = ("n_layers", "convs_sep", "norms_1", "convs_1x1", "norms_2", "drop")

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return melo_modules.DDSConv

    def forward(self, x, x_mask, g=None):
        if g is not None:
            x = self.builder.make_add(x, g)
            # x = x + g
        for i in range(self.n_layers):
            # y = self.convs_sep[i](x * x_mask)
            # y = self.builder.make_transpose(self.builder.make_mul(x, x_mask), (0, 2, 1))
            # y.dataformat = DataFormat.NXC
            # y = self.builder.make_transpose(self.convs_sep[i](y), (0, 2, 1))
            y = self.builder.make_mul(x, x_mask)
            y = self.convs_sep[i](y)
            y = self.norms_1[i](y)
            # y = F.gelu(y)
            y = self.builder.make_gelu(y)

            # y = self.convs_1x1[i](y)
            # y = self.builder.make_transpose(y, (0, 2, 1))
            # y.dataformat = DataFormat.NXC
            # y = self.builder.make_transpose(self.convs_1x1[i](y), (0, 2, 1))
            y = self.convs_1x1[i](y)
            y = self.norms_2[i](y)
            # y = F.gelu(y)
            y = self.builder.make_gelu(y)
            y = self.drop(y)
            self.builder.set_output_value_reference(y, "")
            # x = x + y
            x = self.builder.make_add(x, y)
            # return x * x_mask
        return self.builder.make_mul(x, x_mask)


class Flip(MeloModulesBase):
    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return melo_modules.Flip

    def forward(self, x, *args, reverse=False, **kwargs):
        # x = torch.flip(x, [1])
        x = self.builder.make_flip(x, [1])
        if not reverse:
            raise NotImplementedError
            # logdet = torch.zeros(x.size(0)).to(dtype=x.dtype, device=x.device)
            # return x, logdet
        else:
            return x


class ConvFlow(MeloModulesBase):
    __slots__ = ("half_channels", "num_bins", "filter_channels", "tail_bound")

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> Type:
        return melo_modules.ConvFlow

    def forward(self, x, x_mask, g=None, reverse=False):
        # x:torch.Size([1, 2, 149])
        # x_mask: torch.Size([1, 1, 149])

        # x0, x1 = torch.split(x, [self.half_channels] * 2, 1) #torch.Size([1, 1, 149]), torch.Size([1, 1, 149])
        # h = self.pre(x0)  # torch.Size([1, 192, 149])
        x0, x1 = self.builder.make_split(x, [self.half_channels] * 2, dim=1)
        # h = self.builder.make_transpose(x0, (0, 2, 1))
        # h.dataformat = DataFormat.NXC
        # h = self.builder.make_transpose(self.pre(h), (0, 2, 1))
        h = self.pre(x0)

        h = self.convs(h, x_mask, g=g)  # torch.Size([1, 192, 149])

        # h = self.proj(h) * x_mask  # torch.Size([1, 29, 149])
        # h = self.builder.make_transpose(h, (0, 2, 1))
        # h.dataformat = DataFormat.NXC
        # h = self.builder.make_transpose(self.proj(h), (0, 2, 1))
        h = self.proj(h)
        h = self.builder.make_mul(h, x_mask)

        # 여기 처리 필요함.
        # b, c, t = x0.shape
        # h = h.reshape(b, c, -1, t).permute(
        #     0, 1, 3, 2
        # )  # [b, cx?, t] -> [b, c, t, ?] #torch.Size([1, 1, 149, 29])
        #
        # unnormalized_widths = h[..., : self.num_bins] / math.sqrt(
        #     self.filter_channels
        # )  # torch.Size([1, 1, 149, 10])
        # unnormalized_heights = h[..., self.num_bins : 2 * self.num_bins] / math.sqrt(
        #     self.filter_channels
        # )  # torch.Size([1, 1, 149, 10])
        # unnormalized_derivatives = h[
        #     ..., 2 * self.num_bins :
        # ]  # torch.Size([1, 1, 149, 9])
        #
        # x1, logabsdet = piecewise_rational_quadratic_transform(
        #     x1,
        #     unnormalized_widths,
        #     unnormalized_heights,
        #     unnormalized_derivatives,
        #     inverse=reverse,
        #     tails="linear",
        #     tail_bound=self.tail_bound,
        # )  # torch.Size([1, 1, 149]), #torch.Size([1, 1, 149]),

        def custom_fn(
            x1: torch.Tensor,
            h: torch.Tensor,
            num_bins,
            filter_channels,
            tail_bound,
        ):
            import math
            from melo.transforms import piecewise_rational_quadratic_transform

            b, c, t = x1.shape
            h = h.reshape(int(b), int(c), -1, int(t)).permute(
                0, 1, 3, 2
            )  # [b, cx?, t] -> [b, c, t, ?]

            unnormalized_widths = h[..., :num_bins] / math.sqrt(filter_channels)
            unnormalized_heights = h[..., num_bins : 2 * num_bins] / math.sqrt(
                filter_channels
            )
            unnormalized_derivatives = h[..., 2 * num_bins :]

            x1, logabsdet = piecewise_rational_quadratic_transform(
                x1,
                unnormalized_widths,
                unnormalized_heights,
                unnormalized_derivatives,
                inverse=reverse,
                tails="linear",
                tail_bound=tail_bound,
            )
            return x1

        b, c, t = x0.get_act_src_shape()
        fn_ = functools.partial(
            custom_fn,
            num_bins=self.num_bins,
            filter_channels=self.filter_channels,
            tail_bound=self.tail_bound,
        )
        # x1 = self.builder.make_custom_biop(
        #     inputs=(x1, h),
        #     content=f"melotts_piecewise_rational_quadratic_transform",
        #     output_src_shape=x1.get_act_src_shape(),
        #     output_dtype=x1.dtype,
        #     custom_fn=fn_,
        # )

        def _fwd_rank4_fix(act):
            act = self.builder.make_unsqueeze(act, 1)
            return self.builder.make_transpose(act, (0, 1, 3, 2))

        def _bwd_rank4_fix(act):
            act = self.builder.make_transpose(act, (0, 1, 3, 2))
            return self.builder.make_squeeze(act, (1,))

        x1 = _fwd_rank4_fix(x1)
        h = _fwd_rank4_fix(h)
        x1 = self.builder.make_MeloTTSPiecewiseRationalQuadraticTransformOptions(
            x1,
            h,
            num_bins=self.num_bins,
            filter_channels=self.filter_channels,
            tail_bound=self.tail_bound,
            reverse=reverse,
        )

        x1 = _bwd_rank4_fix(x1)

        # x = torch.cat([x0, x1], 1) * x_mask
        x = self.builder.make_concatenate([x0, x1], dim=1)

        # logdet = torch.sum(logabsdet * x_mask, [1, 2]) # torch.Size([1])
        if not reverse:
            raise NotImplementedError
            # return x, logdet
        else:
            return x
