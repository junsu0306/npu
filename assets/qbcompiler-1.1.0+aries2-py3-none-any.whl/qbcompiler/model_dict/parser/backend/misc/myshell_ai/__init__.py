from .parser import MeloParser


def get_parser(model, **kwargs):
    module_name = model.__class__.__module__
    if module_name.startswith("melo.api"):
        return MeloParser(model, **kwargs)
    raise NotImplementedError(str(type(model)))
