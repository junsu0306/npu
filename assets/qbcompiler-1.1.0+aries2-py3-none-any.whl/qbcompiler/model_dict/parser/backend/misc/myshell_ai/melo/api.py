import abc
import functools
import os
import pathlib
from typing import Any

import melo.api as melo_api
import numpy
import torch

from qbcompiler.model_dict.common import ActivationSpec, DataFormat, ModelDict
from qbcompiler.model_dict.common.item_specs import DimValue
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.common.parserabc import MobilintParserOutputs
from qbcompiler.model_dict.parser.backend.misc.myshell_ai.make_modules import (
    make_dynamic_object,
)
from qbcompiler.model_dict.parser.backend.modeling_torch import ModuleParserBase
from qbcompiler.model_dict.parser.util.subgraph_builder import SubGraphBuilder


class MeloAPIBase(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name, make_module_func=make_dynamic_object)


class TTS(MeloAPIBase):
    def __init__(self, model: Any, module_name: str = ""):
        super().__init__(model, module_name)

    @property
    def target_module_type(self) -> str:
        return melo_api.TTS

    # def tts_to_file(self, text, speaker_id, output_path=None, sdp_ratio=0.2, noise_scale=0.6, noise_scale_w=0.8, speed=1.0, pbar=None, format=None, position=None, quiet=False,):
    #     language = self.language
    #     texts = self.split_sentences_into_pieces(text, language, quiet)
    #     audio_list = []
    #     if pbar:
    #         tx = pbar(texts)
    #     else:
    #         if position:
    #             tx = tqdm(texts, position=position)
    #         elif quiet:
    #             tx = texts
    #         else:
    #             tx = tqdm(texts)
    #     for t in tx:
    #         if language in ['EN', 'ZH_MIX_EN']:
    #             t = re.sub(r'([a-z])([A-Z])', r'\1 \2', t)
    #         device = self.device
    #         bert, ja_bert, phones, tones, lang_ids = utils.get_text_for_tts_infer(t, language, self.hps, device, self.symbol_to_id)
    #         with torch.no_grad():
    #             x_tst = phones.to(device).unsqueeze(0)
    #             tones = tones.to(device).unsqueeze(0)
    #             lang_ids = lang_ids.to(device).unsqueeze(0)
    #             bert = bert.to(device).unsqueeze(0)
    #             ja_bert = ja_bert.to(device).unsqueeze(0)
    #             x_tst_lengths = torch.LongTensor([phones.size(0)]).to(device)
    #             del phones
    #             speakers = torch.LongTensor([speaker_id]).to(device)
    #             audio = self.model.infer(
    #                     x_tst,
    #                     x_tst_lengths,
    #                     speakers,
    #                     tones,
    #                     lang_ids,
    #                     bert,
    #                     ja_bert,
    #                     sdp_ratio=sdp_ratio,
    #                     noise_scale=noise_scale,
    #                     noise_scale_w=noise_scale_w,
    #                     length_scale=1. / speed,
    #                 )[0][0, 0].data.cpu().float().numpy()
    #             del x_tst, tones, lang_ids, bert, ja_bert, x_tst_lengths, speakers
    #             #
    #         audio_list.append(audio)
    #     torch.cuda.empty_cache()
    #     audio = self.audio_numpy_concat(audio_list, sr=self.hps.data.sampling_rate, speed=speed)
    #
    #     if output_path is None:
    #         return audio
    #     else:
    #         if format:
    #             soundfile.write(output_path, audio, self.hps.data.sampling_rate, format=format)
    #         else:
    #             soundfile.write(output_path, audio, self.hps.data.sampling_rate)

    def parse(
        self,
        make_value_dict=True,
        sdp_ratio=0.2,
        noise_scale=0.6,
        noise_scale_w=0.8,
        speed=1.0,
        target="synthesizer_trn0",
        trn0_seq_len=None,
        trn1_seq_len=None,
    ):
        # target = "bert"
        # target = "synthesizer_trn0"
        # target = "synthesizer_trn1"

        max_call_limit = 1
        feed_dict, eval_kwargs = self._make_feed_dict(
            target=target, max_call_limit=max_call_limit
        )

        if make_value_dict:
            vd = self._make_value_dict(target, feed_dict, eval_kwargs)
        else:
            vd = ValueDict()
            vd._value_dict.update(feed_dict)

        out = self._parse_with_target(
            target,
            sdp_ratio=sdp_ratio,
            noise_scale=noise_scale,
            noise_scale_w=noise_scale_w,
            speed=speed,
            feed_dict=feed_dict,
            trn0_seq_len=trn0_seq_len,
            trn1_seq_len=trn1_seq_len,
        )

        out.value_dict = vd

        return out

    def _make_value_dict(self, target, feed_dict, eval_kwargs):
        vd = {}
        vd.update(feed_dict)
        if target in ("synthesizer_trn0", "synthesizer_trn1"):
            target_module = self.model
        else:
            raise NotImplementedError
        target_module.set_value_dict(vd)
        target_module.register_forward_hook()
        kw = {}
        kw.update(feed_dict)
        kw.update(eval_kwargs)

        _value_dict = ValueDict()
        for k, v in kw.items():
            if isinstance(v, torch.Tensor):
                kw[k] = v.to(self.reference_model.device)

        if target == "synthesizer_trn0":
            flows = list(reversed(self.reference_model.model.sdp.flows))
            flows = flows[:-2] + [flows[-1]]
            target_flow = flows[0]
            original_forward = getattr(target_flow, "forward")

            @functools.wraps(original_forward)
            def _take_z_arg_wrapper(*args, **kwargs):
                z, x_mask = args
                feed_dict["z"] = z.detach().clone()
                return original_forward(*args, **kwargs)

            setattr(target_flow, "forward", _take_z_arg_wrapper)

            text_encoder = self.reference_model.model.enc_p
            phone_tone_lang_emb = (
                text_encoder.emb(feed_dict["x"])
                + text_encoder.tone_emb(feed_dict["tone"])
                + text_encoder.language_emb(feed_dict["language"])
            )
            vd["phone_tone_lang_emb"] = phone_tone_lang_emb

            target_module.reference_model.eval()
            with torch.no_grad():
                target_module.reference_model.infer(**kw)
            setattr(target_module, "forward", original_forward)
            vd["z"] = feed_dict["z"]

        elif target == "synthesizer_trn1":
            target_block = self.reference_model.model.flow
            original_forward = getattr(target_block, "forward")

            @functools.wraps(original_forward)
            def _take_z_arg_wrapper(*args, **kwargs):
                z_p, y_mask = args
                feed_dict["z_p"] = z_p.detach().clone()
                feed_dict["y_mask"] = y_mask.detach().clone()
                feed_dict["model.emb_g/unsqueeze"] = kwargs["g"].detach().clone()
                return original_forward(*args, **kwargs)

            setattr(target_block, "forward", _take_z_arg_wrapper)
            target_module.reference_model.eval()
            with torch.no_grad():
                target_module.reference_model.infer(**kw)
            setattr(target_block, "forward", original_forward)
            vd["z_p"] = feed_dict["z_p"]
            vd["y_mask"] = feed_dict["y_mask"]
            vd["model.emb_g/unsqueeze"] = feed_dict["model.emb_g/unsqueeze"]
        else:
            raise NotImplementedError
        for k, v in vd.items():
            if isinstance(v, torch.Tensor):
                if v.dtype == torch.bfloat16:
                    v = v.to(torch.float32)
                v = v.detach().cpu().numpy()
            if isinstance(v, numpy.ndarray):
                _value_dict[k] = v

        return _value_dict

    def get_sample_data(self, target):
        file_path = os.path.abspath(__file__)
        data_path = pathlib.Path(file_path).parent / "data"
        if target in ("synthesizer_trn0", "synthesizer_trn1"):
            tuples = (
                "x_tst",
                "x_tst_lengths",
                "speakers",
                "tones",
                "lang_ids",
                "bert",
                "ja_bert",
            )
            return tuple(
                torch.load(data_path / f"{k}.pt").to(self.reference_model.device)
                for k in tuples
            )
        else:
            raise NotImplementedError()

    def _make_feed_dict(self, target, max_call_limit: int = 1):
        if target in ("synthesizer_trn0", "synthesizer_trn1"):
            (
                x_tst,
                x_tst_lengths,
                speakers,
                tones,
                lang_ids,
                bert,
                ja_bert,
            ) = self.get_sample_data(target=target)
            fd = {
                "x": x_tst,
                "x_lengths": x_tst_lengths,
                "sid": speakers,
                "tone": tones,
                "language": lang_ids,
                "bert": bert,
                "ja_bert": ja_bert,
            }
            eval_kw = {
                "noise_scale": 0.6,
                "length_scale": 1.0,
                "noise_scale_w": 0.8,
                "sdp_ratio": 0.2,
            }
            return fd, eval_kw
        raise NotImplementedError()

    def _parse_with_target(
        self,
        target,
        sdp_ratio,
        noise_scale,
        noise_scale_w,
        speed,
        feed_dict,
        trn0_seq_len,
        trn1_seq_len,
    ):
        builder0 = SubGraphBuilder({}, "synthesizer_trn0")
        builder1 = SubGraphBuilder({}, "synthesizer_trn1")
        self.set_builder(builder0, recursive=False)
        self.set_builder(builder1, recursive=False)

        synthesizer_trn = self.model
        synthesizer_trn.set_builder(builder0, recursive=False)
        synthesizer_trn.set_builder(builder1, recursive=False)

        if target == "bert":
            ...
        elif target in ("synthesizer_trn0", "synthesizer_trn1"):
            # fmt: off
            n_batch, seq_len = feed_dict["x"].shape
            if trn0_seq_len is not None:
                seq_len = DimValue(trn0_seq_len, dynamic=False)
            else:
                seq_len = DimValue(seq_len, dynamic=True)
            x_tst = ActivationSpec(name="x", src_shape=(n_batch, seq_len), dtype="int64", dataformat=DataFormat.UNKNOWN)
            x_tst_lengths = ActivationSpec(name="x_lengths", src_shape=(1,), dtype="int64",
                                           dataformat=DataFormat.UNKNOWN)
            speakers = ActivationSpec(name="sid", src_shape=(1,), dtype="int64", dataformat=DataFormat.UNKNOWN)
            bert_dim = feed_dict["bert"].shape[1]
            bert = ActivationSpec(name="bert", src_shape=(1, bert_dim, seq_len), dtype="float32",
                                  dataformat=DataFormat.NCX)
            ja_bert_dim = feed_dict["ja_bert"].shape[1]
            ja_bert = ActivationSpec(name="ja_bert", src_shape=(1, ja_bert_dim, seq_len), dtype="float32",
                                     dataformat=DataFormat.NCX)
            lang_ids = ActivationSpec(name="language", src_shape=(1, seq_len,), dtype="int64",
                                      dataformat=DataFormat.UNKNOWN)
            tones = ActivationSpec(name="tone", src_shape=(1, seq_len), dtype="int64", dataformat=DataFormat.UNKNOWN)
            # fmt:on

            audio = self.model.infer(
                x=x_tst,
                x_lengths=x_tst_lengths,
                sid=speakers,
                tone=tones,
                language=lang_ids,
                bert=bert,
                ja_bert=ja_bert,
                sdp_ratio=sdp_ratio,
                noise_scale=noise_scale,
                noise_scale_w=noise_scale_w,
                length_scale=1.0 / speed,
                feed_dict=feed_dict,
                trn1_seq_len=trn1_seq_len
            )
        else:
            raise NotImplementedError(f"target={target}")

        md = ModelDict()
        target_builder = self.get_builder(target)
        sg_target = target_builder.build(name=target, unsupported=False)
        sg_target.idx = 0
        md.subgraphs.append(sg_target)
        const_dict = target_builder._weights

        for iidx in md.sg_main().inputs:
            inact = md.sg_main().activations[iidx]
            md.inputs.append(inact.name)
        for oidx in md.sg_main().outputs:
            outact = md.sg_main().activations[oidx]
            md.outputs.append(outact.name)

        out = MobilintParserOutputs()
        out.model_dict = md
        # out.value_dict = self.value_dict
        out.const_dict = const_dict
        return out
