import pathlib

from qbcompiler.model_dict.common.parserabc import (
    ParserABC,
    MobilintParserInputs,
    MobilintParserOutputs,
)
from qbcompiler.model_dict.parser.backend.misc.myshell_ai.make_modules import (
    make_dynamic_object,
)


class MeloParser(ParserABC):
    def __init__(self, model, temp_dir: str, seed: int = 12345, **kwargs):
        super().__init__("", "melo", seed)
        self.model = model
        self._temp_dir = temp_dir
        self._module_parser = None

    def parse(
        self, parser_inputs: MobilintParserInputs, **kwargs
    ) -> MobilintParserOutputs:
        module_name = self.model.__class__.__module__
        if module_name.startswith("melo.api"):
            return self._parse_melo(parser_inputs, **kwargs)
        else:
            raise NotImplementedError(f"model type={type(self.model)}")

    def _parse_melo(self, parser_inputs: MobilintParserInputs, **kwargs):
        module_name = self.model.__class__.__module__
        value_dict_temp_dir = str(pathlib.Path(self._temp_dir) / "value_dict")

        if module_name == "melo.api":
            make_value_dict = kwargs.pop("make_value_dict", False)
            # Filter out kwargs not expected by MeloTTS parser
            kwargs.pop("hf_config", None)

            # Support new multi-shape format with multi_shapeN kwargs
            # E.g., multi_shape0={"axis": 1, "value": 100}
            multi_shape0 = kwargs.pop("multi_shape0", None)

            if multi_shape0 is not None:
                # New multi-shape format: use value as seq_len
                # For MeloTTS, axis 1 is typically the seq_len dimension
                seq_len = multi_shape0["value"]

                # Set appropriate seq_len based on target
                target = kwargs.get("target", "synthesizer_trn0")
                if target == "synthesizer_trn0" and "trn0_seq_len" not in kwargs:
                    kwargs["trn0_seq_len"] = seq_len
                elif target == "synthesizer_trn1" and "trn1_seq_len" not in kwargs:
                    kwargs["trn1_seq_len"] = seq_len

            module = make_dynamic_object(self.model, "")
            return module.parse(make_value_dict=make_value_dict, **kwargs)
        else:
            raise NotImplementedError(f"model type={module_name}")
