import importlib
import os

import torch

from qbcompiler.model_dict.parser.backend.modeling_torch import (
    is_torch_module,
    make_torch_module,
)


def make_dynamic_object(module, module_name):
    if isinstance(module, torch.nn.modules.container.ModuleList):
        a = []
        for idx, x in enumerate(module):
            a.append(make_dynamic_object(x, module_name + "." + str(idx)))
        return a
    elif isinstance(module, list):
        a = []
        for idx, x in enumerate(module):
            a.append(make_dynamic_object(x, module_name + "." + str(idx)))
        return a

    if is_torch_module(module):
        return make_torch_module(module, module_name)

    cls_name = module.__class__.__name__
    melo_module = module.__class__.__module__

    curr_dir = os.path.dirname(__file__)
    dyn_module_path = curr_dir[curr_dir.find("qbcompiler/model_dict") :]
    module_path = dyn_module_path.replace("/", ".") + "." + melo_module

    mblt_module = importlib.import_module(module_path)
    obj = getattr(mblt_module, cls_name)(module, module_name)
    return obj
