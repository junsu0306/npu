import copy
import os
import pathlib
import uuid
from typing import Dict

import numpy
import onnx

from qbcompiler.model_dict.common import LayerType
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.common.value_wrapper import ValueWrapper
from qbcompiler.model_dict.parser.backend.onnx._inference import (
    get_onnx_inference_obj,
    OnnxInferenceValueDict,
)
from qbcompiler.model_dict.parser.backend.onnx._util import (
    get_all_tensors,
    get_onnx_value_loader,
    get_onnx_data_type,
    get_attr_value,
)
from qbcompiler.logging import get_logger

logger = get_logger(__name__)

ONNXLAYERTYPEMAPPER = {
    "add": LayerType.Adding,
    "celu": LayerType.Celu,
    "and": LayerType.And,
    "argmax": LayerType.ArgMax,
    "batchnorm": LayerType.Batchnorm,
    "cumsum": LayerType.CumSum,
    "batchtospace": None,
    "nonzero": LayerType.NonZero,
    "not": LayerType.Not,
    "cast": LayerType.Cast,
    "clip": LayerType.Clip,
    "concatenate": LayerType.Concatenate,
    "convolution": LayerType.Convolution,
    "convolution1d": LayerType.Convolution1d,
    "cos": LayerType.Cos,
    "sin": LayerType.Sin,
    "depthtospace": LayerType.DepthToSpace,
    "spacetodepth": LayerType.SpaceToDepth,
    "depthwiseconvolution": LayerType.Convolution,
    "convolution3d": LayerType.Convolution3d,
    "dequantizelinear": None,
    "elu": LayerType.Elu,
    "erf": LayerType.Erf,
    "equal": LayerType.Equal,
    "exp": LayerType.Exp,
    "expand": LayerType.Expand,
    "flatten": LayerType.Flatten,
    "floor": LayerType.Floor,
    "gather": LayerType.Gather,
    "gatherconstant": LayerType.GatherConstant,
    "groupconvolution": LayerType.GroupConvolution,
    "gathernd": LayerType.GatherND,
    "gemm": LayerType.Gemm,
    "gemmconstant": LayerType.GemmConstant,
    "greater": LayerType.Greater,
    "gridsample": LayerType.GridSample,
    "groupnormalization": LayerType.GroupNormalization,
    "h-sigmoid": LayerType.HardSigmoid,
    "identity": LayerType.Identity,
    "hardswish": LayerType.HardSwish,
    "input": LayerType.Input,
    "inputconstant": LayerType.InputConstant,
    "output": LayerType.Output,
    "instancenormalization": LayerType.InstanceNormalization,
    "layernormalization": LayerType.LayerNormalization,
    "leakyrelu": LayerType.LeakyRelu,
    "less": LayerType.Less,
    "loop": None,
    "matmul": LayerType.MatMul,
    "minimum": LayerType.Minimum,
    "mod": LayerType.Mod,
    "nms": LayerType.NonMaxSuppression,
    "or": LayerType.Or,
    "pad": LayerType.Pad,
    "prelu": LayerType.PRelu,  # completely same as Leaky relu in terms of parsing
    "pooling": LayerType.Pooling,
    "maxpool": LayerType.Pooling,  # for onnx parsing only
    "avgpool": LayerType.Pooling,  # for onnx parsing only
    "globalaveragepool": LayerType.Pooling,  # for onnx parsing only
    "pow": LayerType.Pow,
    "quantizelinear": None,
    "range": LayerType.Range,
    "reciprocal": LayerType.Reciprocal,
    "reducesum": LayerType.ReduceSum,
    "reducemax": LayerType.ReduceMax,
    "reducemin": LayerType.ReduceMin,
    "reducemean": LayerType.ReduceMean,
    "reducel2": LayerType.ReduceL2,
    "relu": LayerType.Relu,
    "reshape": LayerType.Reshape,
    "resize": LayerType.Resize,
    "scatternd": LayerType.ScatterND,
    "shape": LayerType.Shape,
    "sigmoid": LayerType.Sigmoid,
    "slice": LayerType.Slice,
    "softmax": LayerType.Softmax,
    "softplus": LayerType.Softplus,
    "spacetobatch": None,
    "split": LayerType.Split,
    "squeeze": LayerType.Squeeze,
    "unsqueeze": LayerType.Unsqueeze,
    "sqrt": LayerType.Sqrt,
    "tanh": LayerType.Tanh,
    "tile": LayerType.Tile,
    "topk": LayerType.TopKValues,  # TopKIndex layertype will be modify after make parse simple 2
    "transposeconvolution": LayerType.TransposeConvolution,
    "transpose": LayerType.Transpose,
    "upsampling": LayerType.Upsampling,
    "where": LayerType.Where,
    "xor": LayerType.Xor,
    "sub": LayerType.Sub,
    "mul": LayerType.Multiply,
    "div": LayerType.Div,
    "ceil": LayerType.Ceil,
    "neg": LayerType.Neg,
    "einsum": LayerType.Einsum,
    "lstm": LayerType.LSTM,
    "rnn": LayerType.RNN,
    "gru": LayerType.GRU,
    "log": LayerType.Log,
    "gatherelements": LayerType.GatherElements,
    "constant": "emtpy",
    "constantofshape": "emtpy",
    "shape": "emtpy",  # onnx speical cases
}


def add_output_to_layer_dict(layer_dict: dict, const_dict: dict):
    unknown_layer_list = []
    for layer_name, layer_info in layer_dict.items():
        if "output" not in layer_info:
            layer_info["output"] = []

        """ find input_tensor names """
        input_list = get_input_list(layer_info)
        for input_name in input_list:
            if input_name in layer_dict:
                if "output" not in layer_dict[input_name]:
                    layer_dict[input_name]["output"] = []
                layer_dict[input_name]["output"].append(layer_name)
            elif input_name in const_dict:
                pass
            else:
                # print("Warnning. input_tensor name in not in both layer dict and const dict. input_name = ", input_name)
                unknown_layer_list.append(input_name)


def get_input_list(layer_info):
    if not isinstance(layer_info, dict):
        raise ValueError(
            f"Error. layer_info should be a "
            f" dictionary, but got {type(layer_info).__name__}"
        )

    if "input" in layer_info:
        input_list = layer_info["input"]
        if isinstance(input_list, tuple):
            input_list = list(input_list)
        if not isinstance(input_list, list):
            input_list = [input_list]
    elif "input0" in layer_info and "input1" in layer_info:
        input_list = [layer_info["input0"], layer_info["input1"]]
    elif "input0" in layer_info or "input1" in layer_info:
        raise ValueError(
            f"Error. layer_info should have both input0 and input1, "
            f"but got {layer_info.keys()}"
        )
    else:
        return []

    for input_name in input_list:
        if not isinstance(input_name, str):
            raise ValueError(
                f"Error. input_name should be a string, "
                f"but got {type(input_name).__name__}"
            )

    return input_list


# Range for each data type which is used to generate random array/tensor
DATA_TYPE_RANGE = {
    "float32": [-1, 1],
    "uint8": [0, 255],
    "int8": [-128, 127],
    "uint16": [0, 255],
    "int16": [-128, 127],
    "int32": [-128, 127],
    "int64": [-128, 127],
    "bool": [0, 1],
    "float16": [-1, 1],
    "double": [-1, 1],
    "uint32": [0, 255],
    "uint64": [0, 255],
    "complex64": [-1, 1],
    "complex128": [-1, 1],
}


def get_np_random_array(data_type, shape):
    if data_type not in DATA_TYPE_RANGE:
        raise ValueError(f"Cannot create NumPy array with dtype = {data_type}")

    arr_range = DATA_TYPE_RANGE[data_type]
    return numpy.random.uniform(arr_range[0], arr_range[1], shape).astype(data_type)


def _check_embedding(input_name, nodes, onnx_weights_dict):
    """
    Check whether nn.Embedding exists in the graph
    """
    for node in nodes:
        if node.op_type == "Gather" and input_name in node.input:
            for node_input_name in node.input:
                if "weight" in node_input_name:
                    embedding_size = onnx_weights_dict[node_input_name].shape
                    return True, embedding_size[0]
    return False, 0


def _check_lstm_packed_input(input_name, operations):
    """
    Check whether 'input_name' is "lengths" input of `torch.nn.utils.rnn.pack_padded_sequence`
    """
    is_LSTM, is_Packed = False, False
    for n in operations:
        if n.op_type == "LSTM":
            is_LSTM = True

        if n.op_type == "Cast" and input_name in n.input:
            is_Packed = True

    return is_LSTM and is_Packed


def _make_compiletime_shape_dict(onnx_model):
    """
    Build a dictionary of activation tensor names and their shapes from the
    provided ONNX model.

    This function analyzes the ONNX model to infer compile-time shapes of
    intermediate activation tensors. It returns a dictionary where keys are
    activation tensor names (which are the same as layer output names) and
    values are lists of integers representing the shape of each tensor.

    The intermediate activation tensor shapes are inferred using the
    `onnx.shape_inference.infer_shapes(onnx_model)` function. It's important to
    note that these inferred shapes are known at compile time, not at runtime.
    Runtime shapes are inferred using ONNXRuntime, by running the model with
    random inputs, as demonstrated in `self.check_layer()`.

    The key distinction between compile-time shapes and runtime shapes is that
    former allows to identify whether a shape is static or dynamic. A shape is
    considered static if all its dimensions are known at compile time
    (e.g., [1, 3, 5, 5]). In contrast, a shape is considered dynamic if
    at least one dimension is unknown at compile time (e.g., [1, unk_x, 5, 5]).
    The post-processing step in this function replaces dynamic dimensions
    `unk_x` with `0`.

    Args:
        onnx_model (onnx.ModelProto): The ONNX model to be analyzed.

    Returns:
        Dict[str, List[int]]: A dictionary where keys are activation tensor
            names and values are lists of integers representing their static
            shapes. If intermediate activation tensor shapes cannot be inferred,
            an empty dictionary is returned.

    Note: activation tensor names are the same as layer output names.
    """
    if not isinstance(onnx_model, onnx.ModelProto):
        raise ValueError(
            f"Error. onnx_model should be onnx.ModelProto, "
            f"but got {type(onnx_model).__name__}"
        )

    compiletime_shape_dict = {}
    try:
        # noinspection PyUnresolvedReferences
        inferred_model = onnx.shape_inference.infer_shapes(onnx_model)
        value_info_list = (
            list(inferred_model.graph.input)
            + list(inferred_model.graph.value_info)
            + list(inferred_model.graph.output)
        )
        for v in value_info_list:
            shape = v.type.tensor_type.shape.dim
            shape = [dim.dim_value for dim in shape]
            compiletime_shape_dict[v.name] = shape
    except Exception as e:
        logger.warning(f"Failed to infer static shapes of the model. {e}")

    return compiletime_shape_dict


def _get_dynamic_axis(compiletime_shape_dict, layer_name):
    """
    Check if the compile-time shape of the given layer is dynamic.

    Args:
        compiletime_shape_dict (Dict[str, List[int]]): A dictionary
            where keys are layer output names and values are
            lists of integers representing their static shapes.

    Returns:
        bool: True if the shape of the given layer is dynamic, False otherwise.
    """
    if not isinstance(compiletime_shape_dict, dict):
        raise ValueError(
            f"Error. compiletime_shape_dict should be dict, "
            "but got {type(compiletime_shape_dict).__name__}"
        )
    if not isinstance(layer_name, str):
        raise ValueError(
            f"Error. layer_name should be str, " "but got {type(layer_name).__name__}"
        )

    shape = compiletime_shape_dict.get(layer_name, None)

    if shape is None:
        return None
    dynamic_axis = []
    for i, dim in enumerate(shape):
        if dim == 0:  # dynamic dimension
            # TODO(Kanye): come up with a better way to handle batch dimension
            if i == 0 and len(shape) > 1:  # it is batch dimension, so exclude it
                continue
            dynamic_axis.append(i)
    if dynamic_axis:
        return dynamic_axis
    return None


def _make_simple_layer_info(node):
    # one input only node
    if len(node.input) != 1:
        raise ValueError(
            f"Error. The number of inputs of {node.op_type} layer should be 1."
        )
    layer_type = ONNXLAYERTYPEMAPPER[node.op_type.lower()]
    input_name = node.input[0]
    layer_info = {"type": layer_type, "input": input_name}
    return layer_info


def _make_simple_layer_info_2(node):
    # two input only node
    if len(node.input) != 2:
        raise ValueError(
            f"Error. The number of inputs of {node.op_type} layer should be 2."
        )

    layer_type = ONNXLAYERTYPEMAPPER[node.op_type.lower()]
    input_name_1 = node.input[0]
    input_name_2 = node.input[1]
    layer_info = {
        "type": layer_type,
        "input0": input_name_1,
        "input1": input_name_2,
    }
    return layer_info


def parse_input_info(node, feed_dict=None):
    """
    (Seungmin): This function is to set dynamic dimension value for input shape.
    if feed_dict is provided, the value which is on same position in feed_dict will be used.
    else, set value arbitrarily.
    For avoiding different setting for same axis, param_dict is used.
    Checking whether dynamic dimension is set previously for other input is done based on param's name.
    """

    shape = [dim.dim_value for dim in node.type.tensor_type.shape.dim]
    dim_param = [dim.dim_param for dim in node.type.tensor_type.shape.dim]
    param_dict = {}
    shape_cand = None
    if feed_dict is not None:
        if node.name not in feed_dict:
            raise ValueError(
                f"User-defined Input Shape dict doesn't have Input {node.name} which is from model."
            )
        tensor_cand = feed_dict[node.name]
        shape_cand = tuple(tensor_cand.shape)
        if shape_cand is not None:
            if (
                len(shape_cand) == len(shape) + 1
            ):  # Shape with Batch vs shape without Batch
                shape_cand = shape_cand[1:]
            elif (
                len(shape_cand) == len(shape) - 1
            ):  # Shape without Batch vs shape with Batch
                shape_cand = type(shape_cand)((1,)) + shape_cand
            elif len(shape_cand) == len(shape):
                pass
            else:
                raise AssertionError(
                    f"User-Input shape of input ({shape_cand}) has different number of dimension with pre-defined one ({shape})."
                )

    new_shape = []
    unknown_counter = 0
    for i, s in enumerate(shape):
        if s <= 0:
            if shape_cand is not None:
                new_shape.append(shape_cand[i])
            else:
                param_name = dim_param[i].lower()
                new_shape.append(1)
                unknown_counter += 1
                logger.warning(
                    f"Warning! The {i}th axis of {param_name} shape is unknown."
                )
        else:
            new_shape.append(s)

    if unknown_counter == 1:
        logger.warning(
            f"qbcompiler requires the input shape to be {new_shape} for compilation."
        )
    elif unknown_counter > 1:
        raise ValueError(
            f"Input node named '{node.name}' has more than one unknown shape. Please follow the steps below to infer the input shape using a numpy input array:\n\n"
            "[Step 1] Create a dictionary that has node name for key and numpy array for value.\n\n"
            "For exampe, feed_dict = {\"<input node name 1>\": np.random.randn(a,b,c,d).astype('f'),\n"
            "                 \"<input node name 2>\": np.random.randn(e,f).astype('f')}\n\n"
            "[Step 2] Pass the custom input shape dictionary when compiling:\n\n"
            "mxq_compile(..., feed_dict=feed_dict)\n"
            "ONNX_Model_Dict(..., feed_dict=feed_dict)\n"
        )
    return tuple(new_shape)


def print_step(method):
    def _wrapped(self, *args, **kwargs):
        logger.debug(f"start {method.__qualname__}")
        v = method(self, *args, **kwargs)
        logger.debug(f"finished {method.__qualname__}")
        return v
        # else:
        #     return method(self, *args, **kwargs)

    return _wrapped


class ONNXLoader:
    # noinspection PyTypeChecker
    def __init__(
        self,
        onnx_path: str,
        feed_dict: Dict = None,
        dynamic_axes: Dict = None,
        large_model=False,
        temp_dir="",
        value_dict_path="",
        debug=True,
    ):
        self.debug = debug
        self.onnx_model_path = os.path.abspath(onnx_path)
        self.base_dir = os.path.dirname(self.onnx_model_path)
        self.large_model = large_model
        self.temp_dir = temp_dir
        self._value_dict_temp_dir = str(
            pathlib.Path(self.temp_dir).joinpath("value_dict")
        )

        # value_dict is provided. will not run onnx inference.
        self._provided_value_dict_path = value_dict_path

        #
        self.feed_dict = feed_dict
        self.dynamic_axes = dynamic_axes
        self.const_dict = None
        self.model_info = None
        self.source_output_attr = "onnx_output_name"
        self.onnx_model = None
        self.operations = None
        self.operations_dict = None
        self.input_list = None
        self.compiletime_shape_dict = None
        self.onnx_weights_dict = None
        self.opset = None
        self.ir_version = None
        self.src_output_list = None
        self.layer_dict: Dict = None
        self.onnx_input: Dict = None
        self.onnx_input_shapes = None
        self.onnx_input_dtypes = None
        self.onnx_value_dict = None
        self.sample_value_dict = None

        self.check_batch_size(self.onnx_model_path)

        self.load_operations(self.onnx_model_path)
        self.get_input_tensors()
        self.make_layer_dict()
        self.make_const_dict()
        self.calculate_const_value_and_shape()  # src_shape
        self.remove_loop_if()
        self.init_model_info()
        add_output_to_layer_dict(self.layer_dict, self.const_dict)

    def get_input_tensor_details(self, model):
        def get_data_type_str(elem_type):
            """Convert ONNX tensor type enum to string."""
            type_str = onnx.TensorProto.DataType.Name(elem_type)
            return type_str

        batch_sizes = []
        tensor_details = []

        initializer_names = set(x.name for x in model.graph.initializer)
        for input_tensor in model.graph.input:
            if input_tensor.name in initializer_names:
                continue

            shape = input_tensor.type.tensor_type.shape
            elem_type = input_tensor.type.tensor_type.elem_type

            # todo: dim 4가 아닌 경우에도 필요한가?
            if len(shape.dim) == 4:
                batch_size = shape.dim[0].dim_value
                batch_sizes.append(batch_size)
                tensor_info = {
                    "name": input_tensor.name,
                    "batch_size": batch_size,
                    "data_type": get_data_type_str(elem_type),
                }
                tensor_details.append(tensor_info)

        if len(set(batch_sizes)) == 1:
            return tensor_details, batch_sizes[0]
        return tensor_details, -1

    def check_batch_size(self, onnx_model_path):
        onnx_model = onnx.load(onnx_model_path, load_external_data=False)

        details, batch_size = self.get_input_tensor_details(onnx_model)
        if batch_size != -1:
            if batch_size > 1:
                print("Provided ONNX Model has batchsize > 1. Try to set batchsize 1.")
                updated_model, success = self.change_input_batch_size(
                    onnx_model, batch_size, 1
                )
                if success:
                    new_onnx_name = (
                        str(pathlib.Path(self.onnx_model_path).stem)
                        + "_"
                        + str(uuid.uuid4())
                    )
                    new_path = str(pathlib.Path(self.temp_dir).joinpath(new_onnx_name))
                    print(f"Model with batch_size 1 generated={new_path}")
                    onnx.save(updated_model, new_path)
                    self.onnx_model_path = new_path
                else:
                    print(f"Failed to generate a model with batch_size 1.")

    def change_input_batch_size(self, model, original_batch_size, new_batch_size):
        # we need to shape infrence on a new graph
        model_tmp = onnx.load(self.onnx_model_path)
        model_tmp = onnx.shape_inference.infer_shapes(model_tmp)
        # Create a map for accessing tensor shapes by name
        tensor_shapes = {
            value_info.name: value_info.type.tensor_type.shape
            for value_info in model_tmp.graph.value_info
        }
        tensor_shapes.update(
            {
                input_tensor.name: input_tensor.type.tensor_type.shape
                for input_tensor in model_tmp.graph.input
            }
        )
        tensor_shapes.update(
            {
                output_tensor.name: output_tensor.type.tensor_type.shape
                for output_tensor in model_tmp.graph.output
            }
        )
        for k, v in tensor_shapes.items():
            tensor_shapes[k] = list(d.dim_value for d in v.dim)

        #

        initializers = {v.name: v for v in model.graph.initializer}
        ambiguities = []
        # Manually inspect and update Reshape nodes if necessary
        for node in model.graph.node:
            if node.op_type == "Reshape":
                input_name = node.input[0]
                shape_name = node.input[1]
                output_name = node.output[0]

                initializer = initializers.get(shape_name, None)
                if (
                    initializer is None
                ):  # Shape is determined by the result of the previous layer
                    continue
                # Convert the initializer to numpy array
                if initializer.data_type == onnx.TensorProto.INT64:
                    shape_values = numpy.frombuffer(
                        initializer.raw_data, dtype=numpy.int64
                    ).copy()
                elif initializer.data_type == onnx.TensorProto.INT32:
                    shape_values = numpy.frombuffer(
                        initializer.raw_data, dtype=numpy.int32
                    ).copy()
                else:
                    continue

                input_shape = tensor_shapes.get(input_name, None)
                output_shape = tensor_shapes.get(output_name, None)

                if input_shape[0] == output_shape[0]:
                    if input_shape[0] == original_batch_size:
                        # Update the batch size if present in the shape values
                        shape_values[0] = new_batch_size
                        initializer.raw_data = shape_values.tobytes()
                        continue
                    elif input_shape[0] == new_batch_size:
                        # ex batch independent right hand side value in addition. in this case batch can
                        continue

                else:
                    if output_shape[0] == new_batch_size:
                        # (52,92,2) -> (1,1,52,92,2)
                        one_stripped = [x for x in output_shape if x != 1]
                        if all(x == y for x, y in zip(one_stripped, input_shape)):
                            continue
                ambiguities.append(node.name)

        if ambiguities:
            return ambiguities, False

        # Copy the input shape and change the batch size
        for input_tensor in model.graph.input:
            if input_tensor.name in initializers:
                continue
            shape = input_tensor.type.tensor_type.shape
            shape.dim[0].dim_value = new_batch_size
        # Copy the output shape and change the batch size
        for output_tensor in model.graph.output:
            shape = output_tensor.type.tensor_type.shape
            shape.dim[0].dim_value = new_batch_size

        while len(model.graph.value_info) > 0:
            model.graph.value_info.pop()
        # Copy value_info (intermediate tensors) shape and change the batch size if needed
        # for value_info in model.graph.value_info:
        #     shape = value_info.type.tensor_type.shape
        #     if shape.dim[0].dim_value != 0:
        #         shape.dim[0].dim_value = new_batch_size

        # Try to infer shapes again
        try:
            model1 = onnx.shape_inference.infer_shapes(model)
        except onnx.onnx_cpp2py_export.shape_inference.InferenceError as e:
            print(f"Shape Inference Error: {e}")
            return None, False

        return model1, True

    def make_value_dict(self, target_output_list, ort_inputs):
        onnx_inference = get_onnx_inference_obj(
            self.onnx_model_path,
            target_output_list=target_output_list,
            is_large_model=self.large_model,
            value_dict_temp_dir=self._value_dict_temp_dir,
        )

        kw = {}
        if self.large_model:
            kw = {"max_queue_len": 25}
        onnx_inference.run(ort_inputs, **kw)
        self.onnx_value_dict = onnx_inference.value_dict
        # onnx_inference.value_dict.serialize("/home/younghoon/models/Llama-3.2-1B-onnx/onnx_vd.value_dict",)

    def init_model_info(self):
        info = {
            "source": "onnx",
            "source_output_attr": self.source_output_attr,
            "opset": self.opset,
        }
        self.model_info = {"info": info}

    @print_step
    def remove_loop_if(self):
        target_to_remove = ["If", "Loop"]
        # (JS)ToDo: remove target
        # (JS)ToDo: update new input layers

    @print_step
    def load_operations(self, onnx_model_path):
        onnx_model = onnx.load(onnx_model_path, load_external_data=False)

        self.opset = onnx_model.opset_import[0].version
        self.ir_version = onnx_model.ir_version
        # producer_name = onnx_model.producer_name
        # producer_version = onnx_model.producer_version

        self.compiletime_shape_dict = _make_compiletime_shape_dict(onnx_model)

        initializer_list = [n.name for n in onnx_model.graph.initializer]
        self.input_list = [
            n.name for n in onnx_model.graph.input if n.name not in initializer_list
        ]
        self.src_output_list = [node.name for node in onnx_model.graph.output]
        self.onnx_weights_dict = self._make_onnx_weight_dict(onnx_model)
        self.operations_dict = {
            n.output[0]: i for i, n in enumerate(onnx_model.graph.node)
        }
        self.operations = onnx_model.graph.node
        self.onnx_model = onnx_model

    def _make_onnx_weight_dict(self, onnx_model):
        dct = {}
        for tensor in get_all_tensors(onnx_model):
            if tensor.name == "":
                pass
            else:
                dct[tensor.name] = ValueWrapper(
                    get_onnx_value_loader(tensor, self.base_dir)
                )
        return dct

    @print_step
    def get_input_tensors(self):
        onnx_input_values = {}
        onnx_input_shapes = {}
        onnx_input_dtypes = {}
        token_length = 0
        for node in self.onnx_model.graph.input:
            if node.name in self.input_list:
                input_name = node.name
                input_shape = parse_input_info(node, self.feed_dict)
                input_dtype = get_onnx_data_type(node.type.tensor_type.elem_type)
                is_embedding_input, vocab_size = _check_embedding(
                    input_name, self.onnx_model.graph.node, self.onnx_weights_dict
                )
                if self.feed_dict is not None and input_name in self.feed_dict:
                    input_value = self.feed_dict[input_name]
                    input_shape_feed = tuple(input_value.shape)
                    # noinspection PyUnresolvedReferences
                    input_dtype_feed = str(input_value.dtype)
                    if input_shape != input_shape_feed:
                        raise ValueError(
                            f"shape of name: '{input_name}' is not matched between onnx shape: {input_shape} feed shape: {input_shape_feed}"
                        )
                    if input_dtype != input_dtype_feed:
                        if not (
                            input_dtype == "bfloat16" and input_dtype_feed == "float32"
                        ):
                            raise ValueError(
                                f"data type of name'{input_name}' is not matched between onnx dtype: {input_dtype} feed dtype: {input_dtype_feed}"
                            )
                else:
                    if is_embedding_input:
                        input_value = numpy.random.randint(
                            low=1, high=vocab_size, size=input_shape, dtype=input_dtype
                        )
                        token_length = input_shape[0]  # not exact
                        # todo: 여기 뭔지 확인
                    elif _check_lstm_packed_input(
                        input_name, self.onnx_model.graph.node
                    ):
                        input_value = numpy.asarray([token_length])
                    else:
                        try:
                            input_value = get_np_random_array(input_dtype, input_shape)
                        except Exception as e:
                            raise ValueError(
                                f"{e}\nError. Failed to create a random input tensor for input '{input_name}'"
                            )
                onnx_input_values[input_name] = input_value
                onnx_input_shapes[input_name] = input_shape
                onnx_input_dtypes[input_name] = input_dtype

        self.onnx_input = onnx_input_values
        self.onnx_input_shapes = onnx_input_shapes
        self.onnx_input_dtypes = onnx_input_dtypes

    @print_step
    def make_layer_dict(self):
        self.layer_dict = {}

        # input_tensor
        for i, layer_name in enumerate(self.input_list):
            self.layer_dict[layer_name] = {}
            self.layer_dict[layer_name]["type"] = LayerType.Input
            self.layer_dict[layer_name]["shape"] = tuple(
                self.onnx_input_shapes[layer_name]
            )
            self.layer_dict[layer_name]["src_shape"] = tuple(
                self.onnx_input_shapes[layer_name]
            )
            self.layer_dict[layer_name]["elem_type"] = self.onnx_input_dtypes[
                layer_name
            ]
            # set is_dynamic attribute for input layer
            is_dynamic = False
            dynamic_axis = []
            dynamic_axis_from_onnx = _get_dynamic_axis(
                self.compiletime_shape_dict, layer_name
            )
            if dynamic_axis_from_onnx:
                is_dynamic = True
                # dynamic_axis += dynamic_axis_from_onnx
            dynamic_axis_from_input = []
            if self.dynamic_axes:
                dyn_axes = self.dynamic_axes.get(layer_name, None)
                if dyn_axes:
                    for k, v in dyn_axes.items():
                        dynamic_axis_from_input.append(k)
                        is_dynamic = True
            dynamic_axis += dynamic_axis_from_input
            self.layer_dict[layer_name]["is_dynamic"] = is_dynamic
            self.layer_dict[layer_name]["dynamic_axis"] = dynamic_axis

        # operations
        for node in self.operations:
            self.parse_node(node)
            self.layer_dict[node.output[0]]["is_dynamic"] = self.is_dynamic(
                node
            )  # set is_dynamic attribute

    @print_step
    def make_const_dict(self):
        def are_inputs_constant(input_list, const_dict):
            """Check if all inputs are constant"""
            for input_name in input_list:
                if input_name not in const_dict:
                    return False
            return True

        # make const dict from operations
        self.const_dict = {}
        const_type_list = ["Constant", "Shape", "ConstantOfShape"]

        # weight dict
        for key in self.onnx_weights_dict:
            self.const_dict[key] = {}
            self.const_dict[key]["type"] = "Const"
            self.const_dict[key]["value"] = self.onnx_weights_dict[key]
            self.const_dict[key]["op"] = "Constant"

        # operations
        is_changed = True
        while is_changed:
            is_changed = False
            for layer_name in list(self.layer_dict.keys()):
                layertype = self.layer_dict[layer_name]["type"]
                input_list = get_input_list(self.layer_dict[layer_name])
                is_const = are_inputs_constant(input_list, self.const_dict)

                if layertype == LayerType.Input:
                    continue
                if self.layer_dict[layer_name].get("loop_graph", False):
                    continue
                # Note: is_const is needed below because ONNX shape inference cannot deduce
                # output shape of operations like Reshape, so output shape would become dynamic.
                # Thus, input to layers Shape and ConstantOfShape might become dynamic, however,
                # we can still make them constant if the input is constant.
                # if layertype in const_type_list and \
                #         (is_const or not self.layer_dict[layer_name].get('is_dynamic', False)):
                if layertype in const_type_list:
                    """
                    TODO (Kanybek, Seungmin)
                    In some cases of Pad/Reshape, Shape/ConstantOfShape/Constant can be identified as dynamic
                    which is actually not meant to be. Kanybek is working on fixation of this cases.
                    Until then, the functionality of dynamic shape will be inactive.
                    """
                    self.const_dict[layer_name] = {}
                    self.const_dict[layer_name]["type"] = layertype
                    del self.layer_dict[layer_name]
                    continue

                if is_const:
                    self.const_dict[layer_name] = {}
                    self.const_dict[layer_name]["type"] = layertype
                    del self.layer_dict[layer_name]
                    is_changed = True

    @print_step
    def calculate_const_value_and_shape(self):
        check_const_list = []
        for layer_name, layer_info in self.const_dict.items():
            if "value" in layer_info:
                continue
            check_const_list.append(layer_name)

        check_layer_list = []
        check_layer_list_bk = []
        for layer_name, layer_info in self.layer_dict.items():
            if layer_info["type"] == LayerType.Input:  # matmul has onnx bug
                continue
            if layer_info.get("loop_graph", False):
                continue

            # add layer except backup layer
            if layer_info["type"] == LayerType.MatMul:
                check_layer_list.append(layer_name)
            else:
                check_layer_list.append(layer_name)
                check_layer_list_bk.append(layer_name)

        check_value_list = check_const_list + check_layer_list
        check_value_list_bk = check_const_list + check_layer_list_bk

        if self._provided_value_dict_path:
            self.onnx_value_dict = OnnxInferenceValueDict.deserialize(
                self._provided_value_dict_path
            )
        else:
            try:
                self.make_value_dict(check_value_list, self.onnx_input)
            except Exception as e:
                self.make_value_dict(check_value_list_bk, self.onnx_input)
                check_layer_list = check_layer_list_bk

        for layer_name in check_const_list:
            self.const_dict[layer_name]["value"] = self.onnx_value_dict[layer_name]

        self.sample_value_dict = ValueDict()
        for k, v in self.onnx_input.items():
            self.sample_value_dict.add(k, v)
        for layer_name in check_layer_list:
            layer_value = self.onnx_value_dict[layer_name]
            self.layer_dict[layer_name]["src_shape"] = layer_value.shape
            self.sample_value_dict[layer_name] = layer_value

    def is_dynamic(self, node):
        layer_name = node.output[0]
        input_list = get_input_list(self.layer_dict[layer_name])
        for input_name in input_list:
            if input_name not in self.layer_dict:  # input is a constant
                continue

            if input_name not in self.compiletime_shape_dict:
                return ValueError(
                    f"Error. {input_name} does not exist in compiletime_shape_dict."
                )
            if _get_dynamic_axis(self.compiletime_shape_dict, input_name):
                return True

            if self.layer_dict[input_name].get("is_dynamic"):
                return True

    def parse_constant(self, node):
        layer_name = node.output[0]
        self.layer_dict[layer_name] = {"type": "Constant"}

    def parse_shape(self, node):
        layer_info = _make_simple_layer_info(node)
        layer_name = node.output[0]
        start, end = 0, None  # default value

        for attr in node.attribute:
            if attr.name == "start":
                start = get_attr_value(attr)
            elif attr.name == "end":
                end = get_attr_value(attr)

        layer_info["start"] = start
        layer_info["end"] = end
        layer_info["type"] = "Shape"
        self.layer_dict[layer_name] = layer_info

    def parse_constantofshape(self, node):
        layer_info = _make_simple_layer_info(node)
        layer_name = node.output[0]
        value = 0  # default value

        for attr in node.attribute:
            if attr.name == "value":
                value = get_attr_value(attr).item()

        layer_info["value"] = value
        layer_info["type"] = "ConstantOfShape"
        self.layer_dict[layer_name] = layer_info

    def parse_cast(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]

        # default setting
        data_type = None
        # get value
        for attr in node.attribute:
            if attr.name == "to":
                data_type = get_onnx_data_type(attr.i)

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Cast
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["data_type"] = data_type

    def parse_pad(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        pad = None
        constant = 0.0
        if self.opset >= 11:
            pad = node.input[1]
            if len(node.input) > 2:
                constant = node.input[2]
        elif self.opset >= 2:
            pass  # mode, pads, value
        else:
            pass  # mode, paddings, value

        # default setting
        pad_mode = "constant"
        # get value
        for attr in node.attribute:
            if attr.name == "mode":
                pad_mode = str(attr.s)[2:-1]  # constant, reflect, edge
            elif attr.name == "paddings":
                pad = list(attr.ints)
            elif attr.name == "pads":
                pad = list(attr.ints)
            elif attr.name == "value":
                constant = attr.f

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Pad
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["pad"] = pad
        self.layer_dict[layer_name]["pad_mode"] = pad_mode
        self.layer_dict[layer_name]["constant"] = constant
        self.layer_dict[layer_name]["channel_last"] = False

    def parse_conv1d(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        weight_name = node.input[1]
        if len(node.input) > 2:
            bias_name = node.input[2]
        else:
            bias_name = None

        # default setting
        auto_pad = "NOTSET"
        group_number = 1
        padding_list = [0, 0]  #

        dilation = None
        kernal = None
        stride = None
        # get value
        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "dilations":
                dilation = attr.ints[0]
            elif attr.name == "group":
                group_number = attr.i
            elif attr.name == "kernel_shape":
                kernal = attr.ints[0]
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "strides":
                stride = attr.ints[0]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Convolution1d
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["weight"] = weight_name
        self.layer_dict[layer_name]["bias"] = bias_name
        self.layer_dict[layer_name]["dilation"] = dilation
        self.layer_dict[layer_name]["kernel"] = kernal
        self.layer_dict[layer_name]["stride"] = stride
        self.layer_dict[layer_name]["auto_pad"] = auto_pad
        self.layer_dict[layer_name]["padding_list"] = padding_list
        self.layer_dict[layer_name]["group_number"] = group_number
        self.layer_dict[layer_name]["channel_last"] = False

    def parse_conv2d(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        weight_name = node.input[1]
        if len(node.input) > 2:
            bias_name = node.input[2]
        else:
            bias_name = None

        # default setting
        auto_pad = "NOTSET"
        group_number = 1
        padding_list = [0, 0, 0, 0]

        d_h = None
        d_w = None
        k_h = None
        k_w = None
        s_h = None
        s_w = None
        # get value
        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "dilations":
                d_h, d_w = attr.ints
            elif attr.name == "group":
                group_number = attr.i
            elif attr.name == "kernel_shape":
                k_h, k_w = attr.ints
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "strides":
                s_h, s_w = attr.ints

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Convolution
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["weight"] = weight_name
        self.layer_dict[layer_name]["bias"] = bias_name
        self.layer_dict[layer_name]["h_dilation"] = d_h
        self.layer_dict[layer_name]["w_dilation"] = d_w
        self.layer_dict[layer_name]["h_kernel"] = k_h
        self.layer_dict[layer_name]["w_kernel"] = k_w
        self.layer_dict[layer_name]["h_stride"] = s_h
        self.layer_dict[layer_name]["w_stride"] = s_w
        self.layer_dict[layer_name]["auto_pad"] = auto_pad
        self.layer_dict[layer_name]["padding_list"] = padding_list
        self.layer_dict[layer_name]["group_number"] = group_number
        self.layer_dict[layer_name]["channel_last"] = False

    def parse_conv3d(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        weight_name = node.input[1]
        if len(node.input) > 2:
            bias_name = node.input[2]
        else:
            bias_name = None

        auto_pad = "NOTSET"
        group_number = 1
        padding_list = [0, 0, 0, 0, 0, 0]

        d_h = None
        d_w = None
        d_d = None
        k_h = None
        k_w = None
        k_d = None
        s_h = None
        s_w = None
        s_d = None

        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "dilations":
                d_d, d_h, d_w = attr.ints
            elif attr.name == "group":
                group_number = attr.i
            elif attr.name == "kernel_shape":
                k_d, k_h, k_w = attr.ints
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "strides":
                s_d, s_h, s_w = attr.ints
            else:
                pass

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Convolution3d
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["weight"] = weight_name
        self.layer_dict[layer_name]["bias"] = bias_name
        self.layer_dict[layer_name]["h_dilation"] = d_h
        self.layer_dict[layer_name]["w_dilation"] = d_w
        self.layer_dict[layer_name]["d_dilation"] = d_d
        self.layer_dict[layer_name]["h_kernel"] = k_h
        self.layer_dict[layer_name]["w_kernel"] = k_w
        self.layer_dict[layer_name]["d_kernel"] = k_d
        self.layer_dict[layer_name]["h_stride"] = s_h
        self.layer_dict[layer_name]["w_stride"] = s_w
        self.layer_dict[layer_name]["d_stride"] = s_d
        self.layer_dict[layer_name]["auto_pad"] = auto_pad
        self.layer_dict[layer_name]["padding_list"] = padding_list
        self.layer_dict[layer_name]["group_number"] = group_number
        self.layer_dict[layer_name]["channel_last"] = False

    def parse_conv(self, node):
        len_attributes = []
        check_att_names = ["dilations", "kernel_shape", "strides"]
        for attr in node.attribute:
            if attr.name in check_att_names:
                len_attributes.append(len(attr.ints))

        if all(element == 2 for element in len_attributes):  # 2D conv parsing
            self.parse_conv2d(node)
        elif all(element == 1 for element in len_attributes):  # 1D conv parsing
            self.parse_conv1d(node)
        elif all(element == 3 for element in len_attributes):  # 3D conv parsing
            self.parse_conv3d(node)
        else:
            raise NotImplementedError("Not implemented conv parsing case")

    def parse_tconv(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        weight_name = node.input[1]
        if len(node.input) > 2:
            bias_name = node.input[2]
        else:
            bias_name = None

        # default setting
        # noinspection PyPep8
        auto_pad = "NOTSET"
        d_h, d_w = 1, 1
        group_number = 1
        out_pad_e = 0
        # noinspection PyPep8
        out_pad_s = 0
        output_shape = None
        # get value
        k_h = None
        k_w = None
        s_h = None
        s_w = None
        padding_list = None
        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "dilations":
                d_h, d_w = attr.ints
            elif attr.name == "group":
                group_number = attr.i
            elif attr.name == "kernel_shape":
                k_h, k_w = attr.ints
            elif attr.name == "output_padding":
                out_pad_e, out_pad_s = attr.ints
            elif attr.name == "output_shape":
                output_shape = list(attr.ints)
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "strides":
                s_h, s_w = attr.ints

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.TransposeConvolution
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["weight"] = weight_name
        self.layer_dict[layer_name]["bias"] = bias_name
        self.layer_dict[layer_name]["h_dilation"] = d_h
        self.layer_dict[layer_name]["w_dilation"] = d_w
        self.layer_dict[layer_name]["h_kernel"] = k_h
        self.layer_dict[layer_name]["w_kernel"] = k_w
        self.layer_dict[layer_name]["h_stride"] = s_h
        self.layer_dict[layer_name]["w_stride"] = s_w
        self.layer_dict[layer_name]["auto_pad"] = auto_pad
        self.layer_dict[layer_name]["padding_list"] = padding_list
        self.layer_dict[layer_name]["out_pad_list"] = [out_pad_e, out_pad_s]
        self.layer_dict[layer_name]["group_number"] = group_number
        self.layer_dict[layer_name]["output_shape"] = output_shape
        self.layer_dict[layer_name]["channel_last"] = False

    def parse_gemm(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        weight_name = node.input[1]
        if len(node.input) > 2:
            bias_name = node.input[2]
        else:
            bias_name = None

        # default setting
        alpha = 1.0
        beta = 1.0
        transA = 0
        transB = 0
        # get value
        for attr in node.attribute:
            if attr.name == "alpha":
                alpha = attr.f
            elif attr.name == "beta":
                beta = attr.f
            elif attr.name == "transA":
                transA = attr.i
            elif attr.name == "transB":
                transB = attr.i

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Gemm
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["weight"] = weight_name
        self.layer_dict[layer_name]["bias"] = bias_name
        self.layer_dict[layer_name]["alpha"] = alpha
        self.layer_dict[layer_name]["beta"] = beta
        self.layer_dict[layer_name]["transA"] = transA
        self.layer_dict[layer_name]["transB"] = transB

    def parse_qlinear(self, node):
        op_type = node.op_type  # QuantizeLinear or DequantizeLinear
        layer_name = node.output[0]
        input_name = node.input[0]
        scale_name = node.input[1]
        if len(node.input) == 3:
            zeropoint_name = node.input[2]
        elif len(node.input) == 2:
            zeropoint_name = None
        else:
            raise ValueError("In this case, We haven't checked yet")

        raise NotImplementedError("Parsing Qlinear not updated implemented yet")
        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = op_type
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["input0"] = scale_name
        self.layer_dict[layer_name]["input1"] = zeropoint_name
        # scale and zeropoint are considered as arithmetic layers

    def parse_batchnorm(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        gamma_name = node.input[1]
        beta_name = node.input[2]
        moving_mean_name = node.input[3]
        moving_var_name = node.input[4]

        # default setting
        epsilon = 1e-5
        momentum = 0.9
        training_mode = 0
        # get value
        for attr in node.attribute:
            if attr.name == "epsilon":
                epsilon = attr.f
            elif attr.name == "momentum":
                momentum = attr.f
            elif attr.name == "training_mode":
                training_mode = attr.i

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Batchnorm
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["gamma"] = gamma_name
        self.layer_dict[layer_name]["beta"] = beta_name
        self.layer_dict[layer_name]["moving_mean"] = moving_mean_name
        self.layer_dict[layer_name]["moving_var"] = moving_var_name
        self.layer_dict[layer_name]["epsilon"] = epsilon
        self.layer_dict[layer_name]["momentum"] = momentum
        self.layer_dict[layer_name]["training_mode"] = training_mode
        self.layer_dict[layer_name]["channel_last"] = False

    def parse_maxpool(self, node):
        len_attributes = []
        check_att_names = ["dilations", "kernel_shape", "strides"]
        for attr in node.attribute:
            if attr.name in check_att_names:
                len_attributes.append(len(attr.ints))
        if all(element == 2 for element in len_attributes):
            self.parse_maxpool2d(node)
        elif all(element == 1 for element in len_attributes):
            self.parse_maxpool1d(node)
        else:
            raise NotImplementedError("Not implemented maxpool parsing case")

    def parse_maxpool2d(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]

        # default setting
        ceil_mode = 0
        auto_pad = "NOTSET"
        d_h, d_w = 1, 1
        padding_list = [0, 0, 0, 0]
        storage_order = 0
        s_h, s_w = 1, 1
        k_h = None
        k_w = None
        # get value
        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "ceil_mode":
                ceil_mode = attr.i
            elif attr.name == "dilations":
                d_h, d_w = attr.ints
            elif attr.name == "kernel_shape":
                k_h, k_w = attr.ints
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "storage_order":
                storage_order = attr.i
            elif attr.name == "strides":
                s_h, s_w = attr.ints

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Pooling
        self.layer_dict[layer_name]["pool_type"] = "MaxPool"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["h_dilation"] = d_h
        self.layer_dict[layer_name]["w_dilation"] = d_w
        self.layer_dict[layer_name]["h_kernel"] = k_h
        self.layer_dict[layer_name]["w_kernel"] = k_w
        self.layer_dict[layer_name]["h_stride"] = s_h
        self.layer_dict[layer_name]["w_stride"] = s_w
        # noinspection PyPep8
        self.layer_dict[layer_name]["auto_pad"] = auto_pad
        self.layer_dict[layer_name]["padding_list"] = padding_list
        self.layer_dict[layer_name]["is_ceil_mode"] = ceil_mode
        self.layer_dict[layer_name]["storage_order"] = storage_order
        self.layer_dict[layer_name]["channel_last"] = False

    def parse_maxpool1d(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]

        # default setting
        ceil_mode = 0
        auto_pad = "NOTSET"
        dilation = 1
        padding_list = [0, 0]
        storage_order = 0
        stride = 1
        kernel = None
        # get value
        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "ceil_mode":
                ceil_mode = attr.i
            elif attr.name == "dilations":
                dilation = attr.ints[0]
            elif attr.name == "kernel_shape":
                kernel = attr.ints[0]
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "storage_order":
                storage_order = attr.i
            elif attr.name == "strides":
                stride = attr.ints[0]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Pooling1d
        self.layer_dict[layer_name]["pool_type"] = "MaxPool"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["dilation"] = dilation
        self.layer_dict[layer_name]["kernel"] = kernel
        self.layer_dict[layer_name]["stride"] = stride
        # noinspection PyPep8
        self.layer_dict[layer_name]["auto_pad"] = auto_pad
        self.layer_dict[layer_name]["padding_list"] = padding_list
        self.layer_dict[layer_name]["is_ceil_mode"] = ceil_mode
        self.layer_dict[layer_name]["storage_order"] = storage_order
        self.layer_dict[layer_name]["channel_last"] = False

    def parse_avgpool(self, node):
        len_attributes = []
        check_att_names = ["dilations", "kernel_shape", "strides"]
        for attr in node.attribute:
            if attr.name in check_att_names:
                len_attributes.append(len(attr.ints))
        if all(element == 2 for element in len_attributes):  # 2D conv parsing
            self.parse_avgpool2d(node)
        elif all(element == 1 for element in len_attributes):  # 1D conv parsing
            self.parse_avgpool1d(node)
        else:
            raise NotImplementedError("Not implemented avgpool parsing case")

    def parse_avgpool2d(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]

        # default setting
        auto_pad = "NOTSET"
        ceil_mode = 0  # default = floor
        count_include_pad = False  # default = not count
        padding_list = [0, 0, 0, 0]
        s_h, s_w = 1, 1
        d_h, d_w = 1, 1
        k_h = None
        k_w = None
        # get value
        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "ceil_mode":
                ceil_mode = attr.i
            elif attr.name == "count_include_pad":
                count_include_pad = bool(attr.i)
            elif attr.name == "kernel_shape":
                k_h, k_w = attr.ints
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "dilations":
                d_h, d_w = attr.ints
            elif attr.name == "strides":
                s_h, s_w = attr.ints

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Pooling
        self.layer_dict[layer_name]["pool_type"] = "AvgPool"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["h_kernel"] = k_h
        self.layer_dict[layer_name]["w_kernel"] = k_w
        self.layer_dict[layer_name]["h_stride"] = s_h
        self.layer_dict[layer_name]["w_stride"] = s_w
        self.layer_dict[layer_name]["h_dilation"] = d_h
        self.layer_dict[layer_name]["w_dilation"] = d_w
        self.layer_dict[layer_name]["padding_list"] = padding_list
        self.layer_dict[layer_name]["auto_pad"] = auto_pad
        self.layer_dict[layer_name]["is_ceil_mode"] = ceil_mode
        self.layer_dict[layer_name]["count_include_pad"] = count_include_pad
        self.layer_dict[layer_name]["channel_last"] = False

    def parse_avgpool1d(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]

        # default setting
        auto_pad = "NOTSET"
        ceil_mode = 0  # default = floor
        count_include_pad = False  # default = not count
        padding_list = [0, 0]
        stride = 1
        dilation = 1
        kernel = None
        # get value
        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "ceil_mode":
                ceil_mode = attr.i
            elif attr.name == "count_include_pad":
                count_include_pad = bool(attr.i)
            elif attr.name == "kernel_shape":
                kernel = attr.ints[0]
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "strides":
                stride = attr.ints[0]
            elif attr.name == "dilations":
                dilation = attr.ints[0]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Pooling1d
        self.layer_dict[layer_name]["pool_type"] = "AvgPool"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["kernel"] = kernel
        self.layer_dict[layer_name]["stride"] = stride
        self.layer_dict[layer_name]["dilation"] = dilation
        self.layer_dict[layer_name]["padding_list"] = padding_list
        self.layer_dict[layer_name]["auto_pad"] = auto_pad
        self.layer_dict[layer_name]["is_ceil_mode"] = ceil_mode
        self.layer_dict[layer_name]["count_include_pad"] = count_include_pad
        self.layer_dict[layer_name]["channel_last"] = False

    def parse_reduce(self, node):
        if len(node.input) not in [1, 2]:
            raise ValueError(
                f"Error. The number of inputs of {node.op_type} layer should be 1 or 2."
            )

        layer_type = ONNXLAYERTYPEMAPPER[node.op_type.lower()]
        layer_name = node.output[0]
        input_name = node.input[0]

        keep_dims = 1
        noop_with_empty_axes = 0
        reduce_axes = None
        if len(node.input) == 2:
            reduce_axes = node.input[1]

        for attr in node.attribute:
            if attr.name == "keepdims":
                keep_dims = attr.i
            elif attr.name == "axes":
                if reduce_axes is not None:
                    raise ValueError("Axes cannot be both in Inputs and Attributes.")
                reduce_axes = list(attr.ints)
            elif attr.name == "noop_with_empty_axes":
                noop_with_empty_axes = attr.i
            else:
                raise ValueError(
                    f"Error. The attribute {attr.name} of {node.op_type} layer is not supported."
                )

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = layer_type
        self.layer_dict[layer_name]["input"] = input_name
        if reduce_axes is None and noop_with_empty_axes == 1:
            self.layer_dict[layer_name]["type"] = LayerType.Identity
        else:
            self.layer_dict[layer_name]["reduce_axes"] = reduce_axes
            self.layer_dict[layer_name]["noop_with_empty_axes"] = noop_with_empty_axes
            self.layer_dict[layer_name]["keep_dims"] = bool(keep_dims)

    def parse_resize(self, node):
        # need to test
        layer_name = node.output[0]
        input_name = node.input[0]
        if self.opset >= 13:
            if len(node.input) > 1:
                roi_name = node.input[1]  # only for tf_crop_and_resize
            else:
                roi_name = None
            if len(node.input) > 2:
                scales_name = node.input[2]
            else:
                scales_name = None
            if len(node.input) > 3:
                sizes_name = node.input[3]
            else:
                sizes_name = None
        elif self.opset >= 11:
            roi_name = node.input[1]
            scales_name = node.input[2]
            if len(node.input) > 3:
                sizes_name = node.input[3]
            else:
                sizes_name = None
        elif self.opset >= 10:
            scales_name = node.input[1]  # output = floor(input_dimension * scale)
            roi_name = None
            sizes_name = None
        else:
            raise NotImplementedError(
                "Unkown opset for resize operation. opset = ", self.opset
            )

        # default setting
        transform_mode = "half_pixel"  # half_pixel, pytorch_half_pixel, align_corners, asymmetric, tf_crop_and_resize
        cubic_coeff_a = 0.75
        exclude_outside = 0
        extrapolation_value = 0.0
        resize_mode = "nearest"  # nearest, bilinear, trilinear, etc
        nearest_mode = "round_prefer_floor"
        antialias = 0
        axes = None
        keep_aspect_ratio_policy = "stretch"
        # get attr
        for attr in node.attribute:
            if attr.name == "coordinate_transformation_mode":
                transform_mode = str(attr.s)[2:-1]
            elif attr.name == "cubic_coeff_a":
                cubic_coeff_a = attr.f
            elif attr.name == "exclude_outside":
                exclude_outside = attr.i
            elif attr.name == "extrapolation_value":
                extrapolation_value = attr.f
            elif attr.name == "mode":
                resize_mode = str(attr.s)[2:-1]
            elif attr.name == "nearest_mode":
                nearest_mode = str(attr.s)[2:-1]
            elif attr.name == "antialias":
                antialias = attr.i
            elif attr.name == "axes":
                axes = list(attr.ints)
            elif attr.name == "keep_aspect_ratio_policy":
                keep_aspect_ratio_policy = str(attr.s)[2:-1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Resize
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["roi"] = roi_name
        self.layer_dict[layer_name]["scales"] = scales_name
        self.layer_dict[layer_name]["sizes"] = sizes_name
        self.layer_dict[layer_name]["resize_mode"] = resize_mode
        self.layer_dict[layer_name]["nearest_mode"] = nearest_mode
        self.layer_dict[layer_name]["transform_mode"] = transform_mode
        self.layer_dict[layer_name]["cubic_coeff_a"] = cubic_coeff_a
        self.layer_dict[layer_name]["exclude_outside"] = exclude_outside
        self.layer_dict[layer_name]["extrapolation_value"] = extrapolation_value
        self.layer_dict[layer_name]["antialias"] = antialias
        self.layer_dict[layer_name]["axes"] = axes
        self.layer_dict[layer_name][
            "keep_aspect_ratio_policy"
        ] = keep_aspect_ratio_policy

    def parse_einsum(self, node):
        layer_name = node.output[0]
        input_names = list(node.input)

        # get attr
        equation = None
        for attr in node.attribute:
            if attr.name == "equation":
                equation = attr.s.decode("utf-8")
        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Einsum
        self.layer_dict[layer_name]["input"] = input_names
        self.layer_dict[layer_name]["equation"] = equation

    def parse_upsample(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        scale_name = None

        if self.opset >= 9:
            scale_name = node.input[1]
        scale_list = None
        up_mode = "nearest"
        for attr in node.attribute:
            if attr.name == "mode":
                up_mode = str(attr.s)[2:-1]
            elif attr.name == "scales":
                scale_list = attr.floats

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Upsampling
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["up_mode"] = up_mode
        if self.opset >= 9:
            self.layer_dict[layer_name]["scales"] = scale_name
        elif self.opset >= 7:
            self.layer_dict[layer_name]["scales"] = list(scale_list)

    def parse_concate(self, node):
        layer_name = node.output[0]
        input_name_list = list(node.input)
        axis = None
        for attr in node.attribute:
            if attr.name == "axis":
                axis = attr.i

        if len(input_name_list) == 1:
            self.layer_dict[layer_name] = {}
            self.layer_dict[layer_name]["type"] = LayerType.Identity
            self.layer_dict[layer_name]["input"] = input_name_list[0]
        else:
            self.layer_dict[layer_name] = {}
            self.layer_dict[layer_name]["type"] = LayerType.Concatenate
            self.layer_dict[layer_name]["input"] = input_name_list
            self.layer_dict[layer_name]["original_axis"] = axis

    def parse_leakyrelu(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]

        # default setting
        alpha = 0.01
        # get attr
        for attr in node.attribute:
            if attr.name == "alpha":
                alpha = attr.f

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.LeakyRelu
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["leaky_alpha"] = alpha

    def parse_celu(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        alpha = 1
        for attr in node.attribute:
            if attr.name == "alpha":
                alpha = attr.f

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Celu
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["alpha"] = alpha

    def parse_elu(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]

        # default setting
        alpha = 1.0
        # get attr
        for attr in node.attribute:
            if attr.name == "alpha":
                alpha = attr.f

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Elu
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["leaky_alpha"] = alpha

    def parse_prelu(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        slope_name = node.input[1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.PRelu
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["slope"] = slope_name

    def parse_cumsum(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        axis = node.input[1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.CumSum
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["axis"] = axis

    def parse_softmax(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]

        # default setting
        if self.opset >= 13:
            axis = -1
        else:
            axis = 1
        # get value
        for attr in node.attribute:
            if attr.name == "axis":
                axis = attr.i

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Softmax
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["axis"] = axis

    def parse_hardsigmoid(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]

        # get value
        alpha = 0.2
        beta = 0.5
        for attr in node.attribute:
            if attr.name == "alpha":
                alpha = attr.f
            elif attr.name == "beta":
                beta = attr.f

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.HardSigmoid
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["alpha"] = alpha
        self.layer_dict[layer_name]["beta"] = beta

    def parse_clip(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        if self.opset >= 11:
            min_value = node.input[1]
            max_value = node.input[2]
        else:
            min_value = None
            max_value = None
            for attr in node.attribute:
                if attr.name == "min":
                    min_value = attr.f
                elif attr.name == "max":
                    max_value = attr.f

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Clip
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["clip_min_value"] = min_value
        self.layer_dict[layer_name]["clip_max_value"] = max_value

    def parse_max(self, node):
        ### corresponds to torch.max(x, torch.tensor(y)) function
        layer_name = node.output[0]
        input_name = node.input[0]

        min_value = node.input[1]
        max_value = None

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Clip
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["clip_min_value"] = min_value
        self.layer_dict[layer_name]["clip_max_value"] = max_value

    def parse_min(self, node):
        ### corresponds to torch.min(x, torch.tensor(y)) function
        layer_name = node.output[0]
        input_name = node.input[0]

        min_value = None
        max_value = node.input[1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Clip
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["clip_min_value"] = min_value
        self.layer_dict[layer_name]["clip_max_value"] = max_value

    def parse_pow(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        exponent_name = node.input[1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Pow
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["exponent"] = exponent_name

    def parse_slice(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Slice
        self.layer_dict[layer_name]["input"] = input_name

        if self.opset >= 10:
            start_name = node.input[1]
            end_name = node.input[2]
            if len(node.input) > 3:
                axis_name = node.input[3]
            else:
                axis_name = None
            if len(node.input) > 4:
                step_name = node.input[4]
            else:
                step_name = None
            self.layer_dict[layer_name]["start"] = start_name
            self.layer_dict[layer_name]["end"] = end_name
            self.layer_dict[layer_name]["axis"] = axis_name
            self.layer_dict[layer_name]["step"] = step_name
        else:
            # default setting
            axis = None
            start = None
            end = None
            # get attr
            for attr in node.attribute:
                if attr.name == "starts":
                    start = list(attr.ints)
                elif attr.name == "ends":
                    end = list(attr.ints)
                elif attr.name == "axes":
                    axis = list(attr.ints)
            if axis is None:
                axis = list(range(len(start)))
            self.layer_dict[layer_name]["start"] = start
            self.layer_dict[layer_name]["end"] = end
            self.layer_dict[layer_name]["axis"] = axis
            self.layer_dict[layer_name]["step"] = None

    def parse_depth_to_space(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]

        block_size = None
        mode = "DCR"  # default (or CRD)
        for attr in node.attribute:
            if attr.name.lower() == "blocksize":
                block_size = attr.i
            if attr.name.lower() == "mode":
                mode = str(attr.s)[2:-1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.DepthToSpace
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["block_size"] = block_size
        self.layer_dict[layer_name]["mode"] = mode

    def parse_space_to_depth(self, node):
        raise NotImplementedError("onnx node type=spacetodepth not implemented.")

    def parse_reshape(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        shape_name = node.input[1]

        # default setting
        allowzero = 0
        # get attr
        for attr in node.attribute:
            if attr.name == "allowzero":
                allowzero = attr.i

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Reshape
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["shape"] = shape_name
        self.layer_dict[layer_name]["allowzero"] = allowzero

    def parse_transpose(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]

        # default setting
        perm = None
        # get attr
        for attr in node.attribute:
            if attr.name == "perm":
                perm = list(attr.ints)

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Transpose
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["transpose_axes"] = perm

    def parse_squeeze(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        axes = None
        if self.opset >= 13:
            if len(node.input) > 1:
                axes = node.input[1]
        elif self.opset >= 1:
            pass

        # get attr
        for attr in node.attribute:
            if attr.name == "axes":
                axes = list(attr.ints)

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Squeeze
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["squeeze_axes"] = axes

    def parse_unsqueeze(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        axes_name = None
        if self.opset >= 13:
            if len(node.input) > 1:
                axes_name = node.input[1]
        elif self.opset >= 1:
            pass

        # default setting
        axes = None
        # get attr
        for attr in node.attribute:
            if attr.name == "axes":
                axes = list(attr.ints)

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Unsqueeze
        self.layer_dict[layer_name]["input"] = input_name
        if axes_name is not None:
            self.layer_dict[layer_name]["axes"] = axes_name
        else:
            self.layer_dict[layer_name]["axes"] = axes

    def parse_flatten(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]

        # default setting
        axis = 1
        # get attr
        for attr in node.attribute:
            if attr.name == "axis":
                axis = attr.i

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Flatten
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["axis"] = axis

    def parse_argmax(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]

        # default setting
        axis = 0
        keepdims = 1
        select_last_index = 0
        # get attr
        for attr in node.attribute:
            if attr.name == "axis":
                axis = attr.i
            elif attr.name == "keepdims":
                keepdims = attr.i
            elif attr.name == "select_last_index":
                select_last_index = attr.i

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.ArgMax
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["axis"] = axis
        self.layer_dict[layer_name]["keepdims"] = bool(keepdims)
        self.layer_dict[layer_name]["select_last"] = bool(select_last_index)

    def parse_loop(self, node):
        output_list = list(node.output)
        max_trip_count_name = node.input[0]
        cond_name = node.input[1]
        v_initial_name = node.input[2]

        graph = None
        for attr in node.attribute:
            if attr.name == "body":
                graph = attr.g

        graph_input_all = [n.name for n in graph.input]
        graph_initializer_list = [n.name for n in graph.initializer]
        graph_output_list = [n.name for n in graph.output]
        graph_input_list = list(set(graph_input_all) - set(graph_initializer_list))

        # N = len(graph_input_list) - 2
        # K = len(graph_output_list) - 1 - N

        before_layer_list = list(self.layer_dict.keys())
        for graph_node in graph.node:
            self.parse_node(graph_node)
        after_layer_list = list(self.layer_dict.keys())
        new_layer_list = list(set(after_layer_list) - set(before_layer_list))

        for layer_name in new_layer_list:
            self.layer_dict[layer_name]["loop_graph"] = True

        for i in range(len(output_list)):
            output_name = output_list[i]
            graph_output_name = graph_output_list[i + 1]

            self.layer_dict[output_name] = {}
            self.layer_dict[output_name]["type"] = LayerType.Identity
            self.layer_dict[output_name]["input"] = graph_output_name
            self.layer_dict[output_name]["loop_graph"] = True

    def parse_tile(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        repeats_name = node.input[1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = LayerType.Tile
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["repeats"] = repeats_name

    def parse_split(self, node):
        output_list = node.output
        input_name = node.input[0]

        # Initialization
        axis = 0  # onnx default value
        num_outputs = None
        split = None

        # Parse attributes
        if self.opset >= 18:
            for attr in node.attribute:
                if attr.name == "axis":
                    axis = attr.i
                elif attr.name == "num_outputs":
                    num_outputs = attr.i

            if len(node.input) == 2:
                split = node.input[1]

        elif self.opset >= 13:
            for attr in node.attribute:
                if attr.name == "axis":
                    axis = attr.i

            if len(node.input) == 2:
                split = node.input[1]

        elif self.opset >= 2:
            for attr in node.attribute:
                if attr.name == "axis":
                    axis = attr.i
                elif attr.name == "split":
                    split = list(attr.ints)

        else:
            for attr in node.attribute:
                if attr.name == "axis":
                    axis = attr.i
                elif attr.name == "split":
                    split = list(attr.ints)

            if len(node.input) == 2:
                if split is not None:
                    raise ValueError("Split cannot be both in Inputs and Attributes.")
                split = node.input[1]

        if num_outputs is None:
            num_outputs = len(output_list)

        for i, layer_name in enumerate(output_list):
            self.layer_dict[layer_name] = {
                "type": LayerType.Split,
                "input": input_name,
                "axis": axis,
                "split": split,
                "num_outputs": num_outputs,
                "split_index": i,
            }

    def parse_instance_norm(self, node):
        assert (
            len(node.input) == 3
        ), f"Got unsupported number of inputs for Instance Normalization: {len(node.input)}."
        layer_name = node.output[0]
        input_name, scale_name, bias_name = node.input
        epsilon = 1e-5  # ONNX default value

        for attr in node.attribute:
            if attr.name.lower() == "epsilon":
                assert (
                    attr.type == 1
                ), f"epsilon must have float dtype (1), but got {attr.type}."
                epsilon = attr.f

        self.layer_dict[layer_name] = {
            "type": LayerType.InstanceNormalization,
            "input": input_name,
            "scale": scale_name,
            "bias": bias_name,
            "epsilon": epsilon,
        }
        self.layer_dict[layer_name]["channel_last"] = False

    def parse_layer_norm(self, node):
        assert (
            len(node.input) == 3
        ), f"Got unsupported number of inputs for Layer Normalization: {len(node.input)}."
        layer_name = node.output[0]
        input_name, scale_name, bias_name = node.input
        axis = 1  # ONNX default value
        epsilon = 1e-5  # ONNX default value
        stash_type = 1  # ONNX default value

        for attr in node.attribute:
            if attr.name.lower() == "axis":
                axis = get_attr_value(attr)
            elif attr.name.lower() == "epsilon":
                epsilon = get_attr_value(attr)
            elif attr.name.lower() == "stash_type":
                stash_type = get_attr_value(attr)

        if stash_type != 1:
            raise NotImplementedError(f"Unsupported stash_type: {stash_type}.")

        self.layer_dict[layer_name] = {
            "type": LayerType.LayerNormalization,
            "input": input_name,
            "scale": scale_name,
            "bias": bias_name,
            "reduce_axes": axis,
            "epsilon": epsilon,
        }

    def parse_scatterND(self, node):
        assert (
            len(node.input) == 3
        ), f"Got unsupported number of inputs for scatterND: {len(node.input)}."
        layer_name = node.output[0]
        data_name, indices_name, updates_name = node.input

        reduction = "None"
        for attr in node.attribute:
            if attr.name.lower() == "reduction":
                reduction = str(attr.s)[2:-1]

        self.layer_dict[layer_name] = {
            "type": LayerType.ScatterND,
            "reduction": reduction,
            "input": [data_name, indices_name, updates_name],
        }

    def parse_NMS(self, node):
        """
        input_box : (B, spatial_dimension, 4)
                  default - [ymin, xmin, ymax, xmax]
                  center  - [x_center, y_center, width, height]
                  Q. y = height, x = width?
        input_scores : (B, Num_CLasses, spatial_dimension)
        """
        layer_name = node.output[0]
        input_boxes = node.input[0]
        input_scores = node.input[1]
        if len(node.input) >= 3:
            max_output_boxes_per_class = node.input[2]
        else:
            max_output_boxes_per_class = 0
        if len(node.input) >= 4:
            iou_threshold = node.input[3]
        else:
            iou_threshold = 0
        if len(node.input) >= 5:
            score_threshold = node.input[4]
        else:
            score_threshold = None

        center_point_box = 0
        for attr in node.attribute:
            if attr.name.lower() == "center_point_box":
                center_point_box = int(attr.i)

        self.layer_dict[layer_name] = {
            "type": LayerType.NonMaxSuppression,
            "input0": input_boxes,
            "input1": input_scores,
            "max_output": max_output_boxes_per_class,
            "iou_thres": iou_threshold,
            "score_thres": score_threshold,
            "is_center": center_point_box,
        }

    def parse_range(self, node):
        layer_name = node.output[0]
        input_name_list = list(node.input)
        self.layer_dict[layer_name] = {
            "type": LayerType.Range,
            "input": input_name_list,
        }

    def parse_mod(self, node):
        layer_info = _make_simple_layer_info_2(node)
        layer_name = node.output[0]
        fmod = 0  # default value

        for attr in node.attribute:
            if attr.name == "fmod":
                fmod = get_attr_value(attr)

        layer_info["fmod"] = fmod
        self.layer_dict[layer_name] = layer_info

    def parse_topk(self, node):
        layer_info = _make_simple_layer_info_2(node)
        layer_name_1, layer_name_2 = node.output
        axis, largest, sorted = -1, 1, 1  # default value

        for attr in node.attribute:
            if attr.name == "axis":
                axis = get_attr_value(attr)
            elif attr.name == "largest":
                largest = get_attr_value(attr)
            elif attr.name == "sorted":
                sorted = get_attr_value(attr)

        layer_info["axis"] = axis
        layer_info["largest"] = bool(largest)
        layer_info["sorted"] = bool(sorted)
        layer_info["type"] = LayerType.TopKValues
        layer_info_2 = layer_info.copy()
        layer_info_2["type"] = LayerType.TopKIndices
        self.layer_dict[layer_name_1] = layer_info
        self.layer_dict[layer_name_2] = layer_info_2

    def parse_gather(self, node):
        layer_info = _make_simple_layer_info_2(node)
        layer_name = node.output[0]
        axis = 0  # default value

        for attr in node.attribute:
            if attr.name == "axis":
                axis = get_attr_value(attr)

        layer_info["axis"] = axis
        self.layer_dict[layer_name] = layer_info

    def parse_gatherelements(self, node):
        layer_info = _make_simple_layer_info_2(node)
        layer_name = node.output[0]
        for attr in node.attribute:
            if attr.name == "axis":
                axis = get_attr_value(attr)

        layer_info["axis"] = axis
        self.layer_dict[layer_name] = layer_info

    def parse_gathernd(self, node):
        layer_info = _make_simple_layer_info_2(node)
        layer_name = node.output[0]
        batch_dims = 0  # default value

        for attr in node.attribute:
            if attr.name == "batch_dims":
                batch_dims = get_attr_value(attr)

        layer_info["batch_dims"] = batch_dims
        self.layer_dict[layer_name] = layer_info

    def parse_gridsample(self, node):
        layer_info = _make_simple_layer_info_2(node)
        layer_name = node.output[0]
        for attr in node.attribute:
            layer_info[attr.name] = get_attr_value(attr)
        self.layer_dict[layer_name] = layer_info

    def parse_rnn(self, node):
        # Between 3 and 6 inputs.
        X, W, R = node.input[:3]
        B = node.input[3] if len(node.input) > 3 else ""
        sequence_lens = node.input[4] if len(node.input) > 4 else ""
        initial_h = node.input[5] if len(node.input) > 5 else ""

        input_mask = "i"
        inputs = [X]
        if sequence_lens:
            inputs.append(sequence_lens)
            input_mask += "s"
        if initial_h:
            inputs.append(initial_h)
            input_mask += "h"

        layer_name = node.output[0]
        hidden_out = node.output[1] if len(node.output) > 1 else ""

        hidden_size = None
        direction = "forward"  # forward, backward, bidirectional
        layout = 0
        for attr in node.attribute:
            if attr.name == "hidden_size":
                hidden_size = get_attr_value(attr)
            elif attr.name == "direction":
                direction = get_attr_value(attr)
            elif attr.name == "layout":
                layout = get_attr_value(attr)

        layer_info = {
            "type": LayerType.RNN,
            "input": inputs,
            "input_mask": input_mask,
            "output_mask": "o",
            "W": W,
            "R": R,
            "B": B,
            "sequence_lens": sequence_lens,
            "direction": direction,
            "batch_first": bool(layout),
            "hidden_size": hidden_size,
            "hidden_name": hidden_out,
            "rnn_group": layer_name,
        }
        self.layer_dict[layer_name] = layer_info

        if hidden_out:
            self.layer_dict[hidden_out] = copy.deepcopy(layer_info)
            self.layer_dict[hidden_out]["output_mask"] = "h"

    def parse_gru(self, node):
        # Between 3 and 6 inputs.
        X, W, R = node.input[:3]
        B = node.input[3] if len(node.input) > 3 else ""
        sequence_lens = node.input[4] if len(node.input) > 4 else ""
        initial_h = node.input[5] if len(node.input) > 5 else ""

        input_mask = "i"
        inputs = [X]
        if sequence_lens:
            inputs.append(sequence_lens)
            input_mask += "s"
        if initial_h:
            inputs.append(initial_h)
            input_mask += "h"

        layer_name = node.output[0]
        hidden_out = node.output[1] if len(node.output) > 1 else ""

        hidden_size = None
        direction = "forward"
        layout = 0
        linear_before_reset = 0
        for attr in node.attribute:
            if attr.name == "hidden_size":
                hidden_size = get_attr_value(attr)
            elif attr.name == "direction":
                direction = get_attr_value(attr)
            elif attr.name == "layout":
                layout = get_attr_value(attr)
            elif attr.name == "linear_before_reset":
                linear_before_reset = get_attr_value(attr)

        layer_info = {
            "type": LayerType.GRU,
            "input": inputs,
            "input_mask": input_mask,
            "output_mask": "o",
            "W": W,
            "R": R,
            "B": B,
            "sequence_lens": sequence_lens,
            "direction": direction,
            "batch_first": bool(layout),
            "hidden_size": hidden_size,
            "hidden_name": hidden_out,
            "gru_group": layer_name,
            "linear_before_reset": bool(linear_before_reset),
        }
        self.layer_dict[layer_name] = layer_info

        if hidden_out:
            self.layer_dict[hidden_out] = copy.deepcopy(layer_info)
            self.layer_dict[hidden_out]["output_mask"] = "h"

    def parse_lstm(self, node):
        """
        Unsupported attributes;
        - activation_alpha
        - activation_beta
        - activations
        - clip
        - input_forget = 0

        layout information
        if layout == 0:
            input shape = [T, B, C_in]
            output shape = [T, num_direction, B, C_out]
            states shape = [num_direction, B, C_out]
        elif layout == 1:
            input shape = [B, T, C_in]
            output shape = [B, T, num_direction, C_out]
            states shape = [B, num_direction, C_out]
        **ONNX Automatically makes input of LSTM as layout==0
        """
        #     layer_name, hidden_out, cell_out = node.output
        #     input_name, weight_name, recur_name, bias_name = node.input[:4]
        #     hidden_input, cell_input = node.input[5:7]
        #     """
        #     Unsupported attributes;
        #     - activation_alpha
        #     - activation_beta
        #     - activations
        #     - clip
        #     - input_forget = 0
        #
        #     layout information
        #     if layout == 0:
        #         input shape = [T, B, C_in]
        #         output shape = [T, num_direction, B, C_out]
        #         states shape = [num_direction, B, C_out]
        #     elif layout == 1:
        #         input shape = [B, T, C_in]
        #         output shape = [B, T, num_direction, C_out]
        #         states shape = [B, num_direction, C_out]
        #     **ONNX Automatically makes input of LSTM as layout==0
        #     """
        #
        #     # default setting
        #     hidden_size = None
        #     direction = "forward"  # forward, backward, bidirectional
        #     layout = 0
        #     for attr in node.attribute:
        #         if attr.name == "hidden_size":
        #             hidden_size = self.get_attr_value(attr)
        #         elif attr.name == "direction":
        #             direction = self.get_attr_value(attr)
        #         elif attr.name == "layout":
        #             layout = self.get_attr_value(attr)
        #     if direction != "forward":
        #         raise AssertionError(
        #             "Direction != forward for LSTM Layer is not Supported."
        #         )
        #
        #     layer_info = {}
        #     layer_info["type"] = "LSTM"
        #     layer_info["input"] = [input_name, hidden_input, cell_input]
        #     layer_info["weight"] = weight_name
        #     layer_info["recurrence"] = recur_name
        #     layer_info["bias"] = bias_name
        #     layer_info["direction"] = direction
        #     layer_info["batch_first"] = bool(layout)
        #     layer_info["hidden_size"] = hidden_size
        #     layer_info["hidden_name"] = hidden_out
        #     layer_info["hidden_out"] = None
        #     layer_info["hidden_src_shape"] = None
        #     layer_info["cell_name"] = cell_out
        #     layer_info["cell_out"] = None
        #     layer_info["cell_src_shape"] = None
        #     self.layer_dict[layer_name] = layer_info
        #
        #     # Make dummy identity for multiple output tensor
        #     self.layer_dict[hidden_out] = {"type": "Identity", "input": layer_name}
        #     self.layer_dict[cell_out] = {"type": "Identity", "input": layer_name}

        # new impl

        X, W, R = node.input[:3]
        B = node.input[3] if len(node.input) > 3 else ""
        sequence_lens = node.input[4] if len(node.input) > 4 else ""
        initial_h = node.input[5] if len(node.input) > 5 else ""
        initial_c = node.input[6] if len(node.input) > 6 else ""
        P = node.input[7] if len(node.input) > 7 else ""

        input_mask = "i"
        inputs = [X]
        if sequence_lens:
            inputs.append(sequence_lens)
            input_mask += "s"
        if initial_h:
            inputs.append(initial_h)
            input_mask += "h"
        if initial_c:
            inputs.append(initial_c)
            input_mask += "c"

        layer_name = node.output[0]
        hidden_out = node.output[1] if len(node.output) > 1 else ""
        cell_out = node.output[2] if len(node.output) > 2 else ""

        # default setting
        hidden_size = None
        direction = "forward"  # forward, backward, bidirectional
        layout = 0
        for attr in node.attribute:
            if attr.name == "hidden_size":
                hidden_size = get_attr_value(attr)
            elif attr.name == "direction":
                direction = get_attr_value(attr)
            elif attr.name == "layout":
                layout = get_attr_value(attr)

        layer_info = {
            "type": LayerType.LSTM,
            "input": inputs,
            "input_mask": input_mask,
            "output_mask": "o",
            "W": W,
            "R": R,
            "B": B,
            "sequence_lens": sequence_lens,
            "P": P,
            "direction": direction,
            "batch_first": bool(layout),
            "hidden_size": hidden_size,
            "hidden_name": hidden_out,
            "cell_name": cell_out,
            "lstm_group": layer_name,
        }
        self.layer_dict[layer_name] = layer_info

        self.layer_dict[hidden_out] = copy.deepcopy(layer_info)
        self.layer_dict[hidden_out]["output_mask"] = "h"

        self.layer_dict[cell_out] = copy.deepcopy(layer_info)
        self.layer_dict[cell_out]["output_mask"] = "c"

    def parse_simple(self, node):
        # one input only node, no attributes
        if node.attribute:
            raise ValueError(f"Error. {node.op_type} layer should not have attribute.")

        layer_name = node.output[0]
        layer_info = _make_simple_layer_info(node)
        if node.op_type == "GlobalAveragePool":
            layer_info["pool_type"] = "GlobalAveragePool"
            layer_info["channel_last"] = False
        self.layer_dict[layer_name] = layer_info

    def parse_simple_2(self, node):
        # two input only node, no attributes
        if node.attribute:
            raise ValueError(f"Error. {node.op_type} layer should not have attribute.")

        layer_name = node.output[0]
        layer_info = _make_simple_layer_info_2(node)
        self.layer_dict[layer_name] = layer_info

    def parse_default(self, node):
        layer_name = node.output[0]
        input_list = list(node.input)
        layer_type = ONNXLAYERTYPEMAPPER[node.op_type.lower()]
        if node.op_type.lower() == "if":
            raise ValueError("We do not parse graphs that contain 'if' node")
        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = layer_type
        self.layer_dict[layer_name]["input"] = input_list
        self.layer_dict[layer_name]["is_default"] = True

    def parse_node(self, node):
        op_type = node.op_type
        if op_type == "Constant":
            self.parse_constant(node)
        elif op_type == "Shape":
            self.parse_shape(node)
        elif op_type == "ConstantOfShape":
            self.parse_constantofshape(node)
        elif op_type == "Cast":
            self.parse_cast(node)
        elif op_type == "Pad":
            self.parse_pad(node)
        elif op_type == "Conv":
            self.parse_conv(node)
        elif op_type == "ConvTranspose":
            self.parse_tconv(node)
        elif op_type == "Gemm":
            self.parse_gemm(node)
        elif op_type in [
            "QuantizeLinear",
            "DequantizeLinear",
        ]:  # quantize and dequantize linear layer are parsed once
            self.parse_qlinear(node)
        elif op_type == "BatchNormalization":
            self.parse_batchnorm(node)
        elif op_type == "MaxPool":
            self.parse_maxpool(node)
        elif op_type == "AveragePool":
            self.parse_avgpool(node)
        elif op_type in [
            "ReduceMin",
            "ReduceMax",
            "ReduceMean",
            "ReduceSum",
            "ReduceProd",
            "ReduceL2",
        ]:
            self.parse_reduce(node)
        elif op_type == "Resize":
            self.parse_resize(node)
        elif op_type == "Einsum":
            self.parse_einsum(node)
        elif op_type == "Upsample":
            self.parse_upsample(node)
        elif op_type == "Concat":
            self.parse_concate(node)
        elif op_type == "LeakyRelu":
            self.parse_leakyrelu(node)
        elif op_type == "Celu":
            self.parse_celu(node)
        elif op_type == "Elu":
            self.parse_elu(node)
        elif op_type == "PRelu":
            self.parse_prelu(node)
        elif op_type == "CumSum":
            self.parse_cumsum(node)
        elif op_type == "Softmax":
            self.parse_softmax(node)
        elif op_type == "HardSigmoid":
            self.parse_hardsigmoid(node)
        elif op_type == "Clip":
            self.parse_clip(node)
        elif op_type == "Max":
            self.parse_max(node)
        elif op_type == "Min":
            self.parse_min(node)
        elif op_type == "Pow":
            self.parse_pow(node)
        elif op_type == "Slice":
            self.parse_slice(node)
        elif op_type == "DepthToSpace":
            self.parse_depth_to_space(node)
        elif op_type == "SpaceToDepth":
            self.parse_space_to_depth(node)
        elif op_type == "Reshape":
            self.parse_reshape(node)
        elif op_type == "Transpose":
            self.parse_transpose(node)
        elif op_type == "Squeeze":
            self.parse_squeeze(node)
        elif op_type == "Unsqueeze":
            self.parse_unsqueeze(node)
        elif op_type == "Flatten":
            self.parse_flatten(node)
        elif op_type == "ArgMax":
            self.parse_argmax(node)
        elif op_type == "Loop":
            self.parse_loop(node)
        elif op_type == "Tile":
            self.parse_tile(node)
        elif op_type == "Split":
            self.parse_split(node)
        elif op_type == "InstanceNormalization":
            self.parse_instance_norm(node)
        elif op_type == "LayerNormalization":
            self.parse_layer_norm(node)
        elif op_type == "ScatterND":
            self.parse_scatterND(node)
        elif op_type == "NonMaxSuppression":
            self.parse_NMS(node)
        elif op_type == "Range":
            self.parse_range(node)
        elif op_type == "Mod":
            self.parse_mod(node)
        elif op_type == "TopK":
            self.parse_topk(node)
        elif op_type == "Gather":
            self.parse_gather(node)
        elif op_type == "GatherElements":
            self.parse_gatherelements(node)
        elif op_type == "GatherND":
            self.parse_gathernd(node)
        elif op_type == "LSTM":
            self.parse_lstm(node)
        elif op_type == "RNN":
            self.parse_rnn(node)
        elif op_type == "GRU":
            self.parse_gru(node)
        elif op_type == "GridSample":
            self.parse_gridsample(node)
        elif op_type in [
            "Identity",
            "GlobalAveragePool",
            "Relu",
            "Sigmoid",
            "Tanh",
            "Softplus",
            "HardSwish",
            "Exp",
            "Sqrt",
            "Reciprocal",
            "Floor",
            "Ceil",
            "Not",
            "NonZero",
            "Erf",
        ]:
            self.parse_simple(node)
        elif op_type in [
            "Add",
            "Sub",
            "Mul",
            "Div",
            "MatMul",
            "And",
            "Or",
            "Xor",
            "Less",
            "Equal",
            "Greater",
            "Expand",
        ]:
            self.parse_simple_2(node)
        else:
            logger.debug(
                f"Warnning. There is an unknown layer {node.output[0]}. Optype = {op_type}."
            )
            self.parse_default(node)
