from qbcompiler.model_dict.parser.backend.onnx.parser import OnnxParser

__all__ = ["get_parser"]


def get_parser(model_path: str, **kwargs):
    return OnnxParser(path_to_model=model_path, **kwargs)
