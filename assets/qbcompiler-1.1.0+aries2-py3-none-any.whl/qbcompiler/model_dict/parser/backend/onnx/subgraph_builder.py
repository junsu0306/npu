import copy
import functools
import math
import numbers
import operator
import os
import pathlib
import uuid
from typing import Dict, List, Optional

import numpy
import onnx

from qbcompiler.model_dict.common import (
    options,
    Operator,
    DataFormat,
    DimValue,
)
from qbcompiler.model_dict.common.item_specs import ActivationSpec
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.common.subgraph_builder import (
    MobilintSubGraphBuilder,
)
from qbcompiler.model_dict.common.value_wrapper import ValueWrapper
from qbcompiler.model_dict.parser.backend.onnx._inference import (
    get_onnx_inference_obj,
)
from qbcompiler.model_dict.parser.backend.onnx._loader import (
    get_np_random_array,
)
from qbcompiler.model_dict.parser.backend.onnx._util import (
    get_all_tensors,
    get_onnx_value_loader,
    get_onnx_data_type,
    get_attr_value,
)
from qbcompiler.logging import get_logger

logger = get_logger(__name__)

OPTIONSMAPPER = {
    "floor": options.FloorOptions,
    "sqrt": options.SqrtOptions,
    "softplus": options.SoftplusOptions,
    "reducemin": options.ReduceMinOptions,
    "reducemax": options.ReduceMaxOptions,
    "reducemean": options.ReduceMeanOptions,
    "reducesum": options.ReduceSumOptions,
    "reduceprod": options.ReduceProdOptions,
    "reducel2": options.ReduceL2Options,
    "and": options.AndOptions,
    "or": options.OrOptions,
    "xor": options.XorOptions,
    "erf": options.ErfOptions,
    "log": options.LogOptions,
}


def _pre_post_transpose(self, op, ax0, ax1, dformat, dformat_post, args, kwargs):
    """
    Add transpose before and after given op, where channel dimension needs to be at the last dimension of the input tensor
    """
    idx = args[0].input[0]
    pre_x = self.get_activation_or_value(idx)
    pre_x_idx = self.get_activation_index(pre_x)
    pre_x_val = self.value_dict[idx]
    x = self.make_transpose(pre_x, transpose_axes=ax0)
    x.dataformat = dformat
    x_idx = self.get_activation_index(x)
    self.value_dict.add(x.name, numpy.transpose(pre_x_val, ax0), dformat)

    self._act_map[idx] = x_idx
    op(self, *args, **kwargs)
    self._act_map[idx] = pre_x_idx

    x = self.get_activation_or_value(args[0].output[0])
    post_x = self.make_transpose(x, transpose_axes=ax1)
    post_x.dataformat = dformat_post
    post_x_idx = self.get_activation_index(post_x)
    x_val = self.value_dict[args[0].output[0]]
    self.value_dict.add(x.name, numpy.transpose(x_val, ax0), dformat)
    self.value_dict.add(post_x.name, x_val, dformat_post)
    self._act_map[args[0].output[0]] = post_x_idx
    return post_x


def to_channel_last(*valid_ranks):
    """
    Wrapper function to transpose tensors before and after a layer
    """

    def decorator(method):
        @functools.wraps(method)
        def wrapper(self, *args, **kwargs):
            input = self.get_activation_or_value(args[0].input[0])
            x_rank = len(input.src_shape)
            if x_rank not in valid_ranks:
                raise ValueError(f"rank={x_rank} not in {valid_ranks}")
            if x_rank == 2:
                return method(self, *args, **kwargs)
            if x_rank == 3:
                ax0, ax1, dfmt, dfmt_post = (
                    (0, 2, 1),
                    (0, 2, 1),
                    DataFormat.NXC,
                    DataFormat.NCX,
                )
            elif x_rank == 4:
                ax0, ax1, dfmt, dfmt_post = (
                    (0, 2, 3, 1),
                    (0, 3, 1, 2),
                    DataFormat.NHWC,
                    DataFormat.NCHW,
                )
            elif x_rank == 5:
                ax0, ax1, dfmt, dfmt_post = (
                    (0, 2, 3, 4, 1),
                    (0, 4, 1, 2, 3),
                    DataFormat.UNKNOWN,
                    DataFormat.UNKNOWN,
                )
            else:
                raise ValueError("code should not be reached!")

            return _pre_post_transpose(
                self, method, ax0, ax1, dfmt, dfmt_post, args, kwargs
            )

        return wrapper

    return decorator


def _conv_out_size(in_size: DimValue, pad_front, pad_end, kernel, dilation, stride):
    v = math.floor(
        (int(in_size) + (pad_front + pad_end) - dilation * (kernel - 1) - 1) / stride
        + 1
    )
    return DimValue(v, dynamic=in_size.dynamic)


def _check_embedding(input_name, nodes, onnx_weights_dict):
    """
    Check whether nn.Embedding exists in the graph
    """
    for node in nodes:
        if node.op_type == "Gather" and input_name in node.input:
            for node_input_name in node.input:
                if "weight" in node_input_name:
                    embedding_size = onnx_weights_dict[node_input_name].shape
                    return True, embedding_size[0]
    return False, 0


def _check_lstm_packed_input(input_name, operations):
    """
    Check whether 'input_name' is "lengths" input of `torch.nn.utils.rnn.pack_padded_sequence`
    """
    is_LSTM, is_Packed = False, False
    for n in operations:
        if n.op_type == "LSTM":
            is_LSTM = True

        if n.op_type == "Cast" and input_name in n.input:
            is_Packed = True

    return is_LSTM and is_Packed


def _make_compiletime_shape_dict(onnx_model):
    """
    Build a dictionary of activation tensor names and their shapes from the
    provided ONNX model.

    This function analyzes the ONNX model to infer compile-time shapes of
    intermediate activation tensors. It returns a dictionary where keys are
    activation tensor names (which are the same as layer output names) and
    values are lists of integers representing the shape of each tensor.

    The intermediate activation tensor shapes are inferred using the
    `onnx.shape_inference.infer_shapes(onnx_model)` function. It's important to
    note that these inferred shapes are known at compile time, not at runtime.
    Runtime shapes are inferred using ONNXRuntime, by running the model with
    random inputs, as demonstrated in `self.check_layer()`.

    The key distinction between compile-time shapes and runtime shapes is that
    former allows to identify whether a shape is static or dynamic. A shape is
    considered static if all its dimensions are known at compile time
    (e.g., [1, 3, 5, 5]). In contrast, a shape is considered dynamic if
    at least one dimension is unknown at compile time (e.g., [1, unk_x, 5, 5]).
    The post-processing step in this function replaces dynamic dimensions
    `unk_x` with `0`.

    Args:
        onnx_model (onnx.ModelProto): The ONNX model to be analyzed.

    Returns:
        Dict[str, List[int]]: A dictionary where keys are activation tensor
            names and values are lists of integers representing their static
            shapes. If intermediate activation tensor shapes cannot be inferred,
            an empty dictionary is returned.

    Note: activation tensor names are the same as layer output names.
    """
    if not isinstance(onnx_model, onnx.ModelProto):
        raise ValueError(
            f"Error. onnx_model should be onnx.ModelProto, "
            f"but got {type(onnx_model).__name__}"
        )

    compiletime_shape_dict = {}
    try:
        # noinspection PyUnresolvedReferences
        inferred_model = onnx.shape_inference.infer_shapes(onnx_model)
        value_info_list = (
            list(inferred_model.graph.input)
            + list(inferred_model.graph.value_info)
            + list(inferred_model.graph.output)
        )
        for v in value_info_list:
            shape = v.type.tensor_type.shape.dim
            shape = [dim.dim_value for dim in shape]
            compiletime_shape_dict[v.name] = shape
    except Exception as e:
        logger.warning(f"Failed to infer static shapes of the model. {e}")

    return compiletime_shape_dict


def parse_input_info(node, feed_dict=None):
    """
    (Seungmin): This function is to set dynamic dimension value for input shape.
    if feed_dict is provided, the value which is on same position in feed_dict will be used.
    else, set value arbitrarily.
    For avoiding different setting for same axis, param_dict is used.
    Checking whether dynamic dimension is set previously for other input is done based on param's name.
    """

    shape = [dim.dim_value for dim in node.type.tensor_type.shape.dim]
    dim_param = [dim.dim_param for dim in node.type.tensor_type.shape.dim]
    param_dict = {}
    shape_cand = None
    if feed_dict is not None:
        if node.name not in feed_dict:
            raise ValueError(
                f"User-defined Input Shape dict doesn't have Input {node.name} which is from model."
            )
        tensor_cand = feed_dict[node.name]
        shape_cand = tuple(tensor_cand.shape)
        if shape_cand is not None:
            if (
                len(shape_cand) == len(shape) + 1
            ):  # Shape with Batch vs shape without Batch
                shape_cand = shape_cand[1:]
            elif (
                len(shape_cand) == len(shape) - 1
            ):  # Shape without Batch vs shape with Batch
                shape_cand = type(shape_cand)((1,)) + shape_cand
            elif len(shape_cand) == len(shape):
                pass
            else:
                raise AssertionError(
                    f"User-Input shape of input ({shape_cand}) has different number of dimension with pre-defined one ({shape})."
                )

    new_shape = []
    unknown_counter = 0
    for i, s in enumerate(shape):
        if s <= 0:
            if shape_cand is not None:
                new_shape.append(shape_cand[i])
            else:
                param_name = dim_param[i].lower()
                new_shape.append(1)
                unknown_counter += 1
                logger.warning(
                    f"Warning! The {i}th axis of {param_name} shape is unknown."
                )
        else:
            new_shape.append(s)

    if unknown_counter == 1:
        logger.warning(
            f"qbcompiler requires the input shape to be {new_shape} for compilation."
        )
    elif unknown_counter > 1:
        raise ValueError(
            f"Input node named '{node.name}' has more than one unknown shape. Please follow the steps below to infer the input shape using a numpy input array:\n\n"
            "[Step 1] Create a dictionary that has node name for key and numpy array for value.\n\n"
            "For exampe, feed_dict = {\"<input node name 1>\": np.random.randn(a,b,c,d).astype('f'),\n"
            "                 \"<input node name 2>\": np.random.randn(e,f).astype('f')}\n\n"
            "[Step 2] Pass the custom input shape dictionary when compiling:\n\n"
            "mxq_compile(..., feed_dict=feed_dict)\n"
            "ONNX_Model_Dict(..., feed_dict=feed_dict)\n"
        )
    return tuple(new_shape)


def print_step(method):
    def _wrapped(self, *args, **kwargs):
        logger.debug(f"start {method.__qualname__}")
        v = method(self, *args, **kwargs)
        logger.debug(f"finished {method.__qualname__}")
        return v
        # else:
        #     return method(self, *args, **kwargs)

    return _wrapped


class ONNXSubGraphBuilder(MobilintSubGraphBuilder):
    def __init__(
        self,
        path_to_model: str,
        temp_dir: str,
        large_model=False,
        feed_dict: Dict = None,
        dynamic_axes: Dict = None,
        value_dict_path: str = "",
        debug=True,
        global_weight_dict: Optional[Dict] = None,
        builder_name: str = "",
    ):
        super().__init__(global_weight_dict=global_weight_dict)
        self.debug = debug
        self._temp_dir = temp_dir
        self.model_path = path_to_model
        self.base_dir = os.path.dirname(self.model_path)
        self.large_model = large_model
        self.temp_dir = temp_dir
        self.dynamic_axes = dynamic_axes
        self._value_dict_temp_dir = str(
            pathlib.Path(self.temp_dir).joinpath("value_dict")
        )
        self._provided_value_dict_path = value_dict_path

        self.opset = None
        self.ir_version = None
        self.operations = None
        self.model = None
        self.feed_dict = feed_dict
        self.input_list: List = None
        self.src_output_list: List = None
        self.compiletime_shape_dict: Dict = None
        self.onnx_weights_dict: Dict = None
        self.operations_dict: Dict = None

        self.onnx_input: Dict = None
        self.onnx_input_shapes = None
        self.onnx_input_dtypes = None

        self.check_batch_size()
        self.load_operations()
        self.get_input_tensors()
        self.make_value_dict()
        self.add_initializer_to_weights()
        self._make_subgraph()

    def get_input_tensor_details(self, model):
        def get_data_type_str(elem_type):
            """Convert ONNX tensor type enum to string."""
            type_str = onnx.TensorProto.DataType.Name(elem_type)
            return type_str

        batch_sizes = []
        tensor_details = []

        initializer_names = set(x.name for x in model.graph.initializer)
        for input_tensor in model.graph.input:
            if input_tensor.name in initializer_names:
                continue

            shape = input_tensor.type.tensor_type.shape
            elem_type = input_tensor.type.tensor_type.elem_type

            # todo: dim 4가 아닌 경우에도 필요한가?
            if len(shape.dim) == 4:
                batch_size = shape.dim[0].dim_value
                batch_sizes.append(batch_size)
                tensor_info = {
                    "name": input_tensor.name,
                    "batch_size": batch_size,
                    "data_type": get_data_type_str(elem_type),
                }
                tensor_details.append(tensor_info)

        if len(set(batch_sizes)) == 1:
            return tensor_details, batch_sizes[0]
        return tensor_details, -1

    def check_batch_size(self):
        onnx_model = onnx.load(self.model_path, load_external_data=False)

        details, batch_size = self.get_input_tensor_details(onnx_model)
        if batch_size != -1:
            if batch_size > 1:
                print("Provided ONNX Model has batchsize > 1. Try to set batchsize 1.")
                updated_model, success = self.change_input_batch_size(
                    onnx_model, batch_size, 1
                )
                if success:
                    new_onnx_name = (
                        str(pathlib.Path(self.model_path).stem)
                        + "_"
                        + str(uuid.uuid4())
                    )
                    new_path = str(pathlib.Path(self._temp_dir).joinpath(new_onnx_name))
                    print(f"Model with batch_size 1 generated={new_path}")
                    onnx.save(updated_model, new_path)
                    self.model_path = new_path
                else:
                    print(f"Failed to generate a model with batch_size 1.")

    def change_input_batch_size(self, model, original_batch_size, new_batch_size):
        # we need to shape infrence on a new graph
        model_tmp = onnx.load(self.model_path)
        model_tmp = onnx.shape_inference.infer_shapes(model_tmp)
        # Create a map for accessing tensor shapes by name
        tensor_shapes = {
            value_info.name: value_info.type.tensor_type.shape
            for value_info in model_tmp.graph.value_info
        }
        tensor_shapes.update(
            {
                input_tensor.name: input_tensor.type.tensor_type.shape
                for input_tensor in model_tmp.graph.input
            }
        )
        tensor_shapes.update(
            {
                output_tensor.name: output_tensor.type.tensor_type.shape
                for output_tensor in model_tmp.graph.output
            }
        )
        for k, v in tensor_shapes.items():
            tensor_shapes[k] = list(d.dim_value for d in v.dim)

        #

        initializers = {v.name: v for v in model.graph.initializer}
        ambiguities = []
        # Manually inspect and update Reshape nodes if necessary
        for node in model.graph.node:
            if node.op_type == "Reshape":
                input_name = node.input[0]
                shape_name = node.input[1]
                output_name = node.output[0]

                initializer = initializers.get(shape_name, None)
                if (
                    initializer is None
                ):  # Shape is determined by the result of the previous layer
                    continue
                # Convert the initializer to numpy array
                if initializer.data_type == onnx.TensorProto.INT64:
                    shape_values = numpy.frombuffer(
                        initializer.raw_data, dtype=numpy.int64
                    ).copy()
                elif initializer.data_type == onnx.TensorProto.INT32:
                    shape_values = numpy.frombuffer(
                        initializer.raw_data, dtype=numpy.int32
                    ).copy()
                else:
                    continue

                input_shape = tensor_shapes.get(input_name, None)
                output_shape = tensor_shapes.get(output_name, None)

                if input_shape[0] == output_shape[0]:
                    if input_shape[0] == original_batch_size:
                        # Update the batch size if present in the shape values
                        shape_values[0] = new_batch_size
                        initializer.raw_data = shape_values.tobytes()
                        continue
                    elif input_shape[0] == new_batch_size:
                        # ex batch independent right hand side value in addition. in this case batch can
                        continue

                else:
                    if output_shape[0] == new_batch_size:
                        # (52,92,2) -> (1,1,52,92,2)
                        one_stripped = [x for x in output_shape if x != 1]
                        if all(x == y for x, y in zip(one_stripped, input_shape)):
                            continue
                ambiguities.append(node.name)

        if ambiguities:
            return ambiguities, False

        # Copy the input shape and change the batch size
        for input_tensor in model.graph.input:
            if input_tensor.name in initializers:
                continue
            shape = input_tensor.type.tensor_type.shape
            shape.dim[0].dim_value = new_batch_size
        # Copy the output shape and change the batch size
        for output_tensor in model.graph.output:
            shape = output_tensor.type.tensor_type.shape
            shape.dim[0].dim_value = new_batch_size

        while len(model.graph.value_info) > 0:
            model.graph.value_info.pop()

        # Try to infer shapes again
        try:
            model1 = onnx.shape_inference.infer_shapes(model)
        except onnx.onnx_cpp2py_export.shape_inference.InferenceError as e:
            print(f"Shape Inference Error: {e}")
            return None, False

        return model1, True

    @print_step
    def load_operations(self):
        onnx_model = onnx.load(self.model_path, load_external_data=False)

        self.opset = onnx_model.opset_import[0].version
        self.ir_version = onnx_model.ir_version

        self.compiletime_shape_dict = _make_compiletime_shape_dict(onnx_model)

        initializer_list = [n.name for n in onnx_model.graph.initializer]
        self.input_list = [
            n.name for n in onnx_model.graph.input if n.name not in initializer_list
        ]
        self.src_output_list = [node.name for node in onnx_model.graph.output]
        self.onnx_weights_dict = self._make_onnx_weight_dict(onnx_model)
        self.operations_dict = {}
        i = 0
        for n in onnx_model.graph.node:
            for o in n.output:
                self.operations_dict[o] = i
                i += 1
        self.operations = onnx_model.graph.node
        self.model = onnx_model
        self.initializer = initializer_list

    def _make_onnx_weight_dict(self, onnx_model):
        dct = {}
        for tensor in get_all_tensors(onnx_model):
            if tensor.name == "":
                pass
            else:
                dct[tensor.name] = ValueWrapper(
                    get_onnx_value_loader(tensor, self.base_dir)
                )
        return dct

    def make_value_dict(self):
        onnx_inference = get_onnx_inference_obj(
            self.model_path,
            target_output_list=list(self.operations_dict.keys()),
            is_large_model=self.large_model,
            value_dict_temp_dir=self._value_dict_temp_dir,
        )

        kw = {}
        if self.large_model:
            kw = {"max_queue_len": 25}
        onnx_inference.run(self.onnx_input, **kw)
        self.value_dict = ValueDict()
        for k, v in self.onnx_input.items():
            self.value_dict.add(k, v)
        for k, v in onnx_inference.value_dict.items():
            self.value_dict.add(k, v.value)

    def add_initializer_to_weights(self):
        """
        Add initializer to weights of the subgraph, to easily access each values where required
        """
        for init in self.initializer:
            self.add_weight(init, self.get_value(init))

    @print_step
    def get_input_tensors(self):
        onnx_input_values = {}
        onnx_input_shapes = {}
        onnx_input_dtypes = {}
        token_length = 0
        for node in self.model.graph.input:
            if node.name in self.input_list:
                input_name = node.name
                input_shape = parse_input_info(node, self.feed_dict)
                input_dtype = get_onnx_data_type(node.type.tensor_type.elem_type)
                is_embedding_input, vocab_size = _check_embedding(
                    input_name, self.model.graph.node, self.onnx_weights_dict
                )
                if self.feed_dict is not None and input_name in self.feed_dict:
                    input_value = self.feed_dict[input_name]
                    input_shape_feed = tuple(input_value.shape)
                    # noinspection PyUnresolvedReferences
                    input_dtype_feed = str(input_value.dtype)
                    if input_shape != input_shape_feed:
                        raise ValueError(
                            f"shape of name: '{input_name}' is not matched between onnx shape: {input_shape} feed shape: {input_shape_feed}"
                        )
                    if input_dtype != input_dtype_feed:
                        if not (
                            input_dtype == "bfloat16" and input_dtype_feed == "float32"
                        ):
                            raise ValueError(
                                f"data type of name'{input_name}' is not matched between onnx dtype: {input_dtype} feed dtype: {input_dtype_feed}"
                            )
                else:
                    if is_embedding_input:
                        input_value = numpy.random.randint(
                            low=1, high=vocab_size, size=input_shape, dtype=input_dtype
                        )
                        token_length = input_shape[0]  # not exact
                        # todo: 여기 뭔지 확인
                    elif _check_lstm_packed_input(input_name, self.model.graph.node):
                        input_value = numpy.asarray([token_length])
                    else:
                        try:
                            input_value = get_np_random_array(input_dtype, input_shape)
                        except Exception as e:
                            raise ValueError(
                                f"{e}\nError. Failed to create a random input tensor for input '{input_name}'"
                            )
                onnx_input_values[input_name] = input_value
                onnx_input_shapes[input_name] = input_shape
                onnx_input_dtypes[input_name] = input_dtype

        self.onnx_input = onnx_input_values
        self.onnx_input_shapes = onnx_input_shapes
        self.onnx_input_dtypes = onnx_input_dtypes

    @print_step
    def _make_subgraph(self):
        """
        Create subgraph of operations, connecting operations and activations
        """
        # input_tensor
        for i, layer_name in enumerate(self.input_list):
            self.parse_input(layer_name)
            self.set_dynamic(layer_name)
        # operations
        for node in self.operations:
            if self.check_const_inputs(node):
                self.get_activation_or_value(node.output[0])
                continue
            try:
                self.parse_node(node)
            except:
                raise NotImplementedError(
                    f"Parsing Error occurred in node: {node.name} op_type: {node.op_type}"
                )
            # print(f"output: {node.output[0]} optype = {node.op_type}")

        # output_tensor
        for layer_name in self.src_output_list:
            if layer_name in self._act_map:
                self.make_output(self.get_activation(layer_name))

    def set_dynamic(self, _input):
        def _get_dynamic_axis(name):
            shape = self.compiletime_shape_dict.get(name, None)
            if shape is None:
                return None
            dynamic_axis = []
            for i, dim in enumerate(shape):
                if dim == 0:  # dynamic dimension
                    if (
                        i == 0 and len(shape) > 1
                    ):  # it is batch dimension, so exclude it
                        continue
                    dynamic_axis.append(i)
            if dynamic_axis:
                return dynamic_axis
            return None

        if _input not in self._act_map:
            return
        input = self.get_activation_or_value(_input)
        dyn_axes = (
            self.dynamic_axes.get(_input, None)
            if self.dynamic_axes is not None
            else None
        )
        if dyn_axes is not None:
            for k, v in dyn_axes.items():
                input.get_act_src_shape()[k].set_dynamic()
        # dynamic_axes = _get_dynamic_axis(_input)
        # if dynamic_axes is not None:
        #     for idx in dynamic_axes:
        #         input.get_act_src_shape()[idx].set_dynamic()

    def get_value(self, key: str):
        """
        Get actual value of a tensor with given key
        """
        if key in self.value_dict:
            return self.value_dict[key]
        elif key in self.onnx_weights_dict:
            return self.onnx_weights_dict[key].value
        else:
            return None

    def get_activation_or_value(self, key: str, const_ok: bool = False):
        """
        Get, create an activationspec, or get real value from given key
        """
        if key not in self._act_map:
            act = copy.deepcopy(self.get_value(key))
            if not const_ok:
                dtype = self.get_value(key).dtype
                src_shape = self.get_value(key).shape
                self.add_weight(key, act)
                act = self.activationspec(key, str(dtype), tuple(src_shape))
        else:
            act = self.get_activation(key)
        return act

    def check_const_inputs(self, node):
        """
        check if all inputs of a node are constant
        """
        input_list = list(node.input)
        if all(i in self._weights for i in input_list):
            return True
        return False

    def parse_input(self, key: str):
        """
        Create an input activationspec;
        If an input has rank == 4, assume its shape as (N, C, H, W) and transpose into (N, H, W, C)
        """
        if len(self.onnx_input_shapes[key]) == 4:
            if (
                self.onnx_input_shapes[key][-1] == 3
                and self.onnx_input_shapes[key][0] == 1
                and self.onnx_input_shapes[key][1:3] == (224, 224)
            ):
                # If, for some reason, input is in shape of (N, H, W, C)
                # Todo -> any other available constraints?
                act = self.activationspec(
                    key,
                    self.onnx_input_dtypes[key],
                    tuple(self.onnx_input_shapes[key]),
                )
                self.make_input(act)
            else:
                ax0 = (0, 2, 3, 1)
                ax1 = (0, 3, 1, 2)
                layer_name_pre = f"{key}_0"
                act = self.activationspec(
                    layer_name_pre,
                    self.onnx_input_dtypes[key],
                    tuple([self.onnx_input_shapes[key][idx] for idx in ax0]),
                )
                input_val = self.value_dict[key]
                self.value_dict.add(
                    layer_name_pre, numpy.transpose(input_val, ax0), act.dataformat
                )
                self.make_input(act)
                self.make_transpose(act, transpose_axes=ax1, opname=key)
        else:
            act = self.activationspec(
                key,
                self.onnx_input_dtypes[key],
                tuple(self.onnx_input_shapes[key]),
            )
            self.make_input(act)

    def parse_constant(self, node):
        layer_name = node.output[0]
        dtype = self.value_dict[layer_name].dtype
        src_shape = self.get_value(layer_name).shape
        self.activationspec(layer_name, str(dtype), src_shape)
        self.add_weight(layer_name, self.value_dict[layer_name])

    def parse_shape(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)
        start, end = 0, None  # default value

        for attr in node.attribute:
            if attr.name == "start":
                start = get_attr_value(attr)
            elif attr.name == "end":
                end = get_attr_value(attr)

        if start < 0:
            start = len(input.src_shape) + start
        if end is None:
            end = len(input.src_shape)
        src_shape = (end - start,)
        outact = self.activationspec(
            layer_name, input.dtype, src_shape=src_shape, dataformat=input.dataformat
        )
        op = Operator(
            name=outact.name,
            options=options.ShapeOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                start=start,
                end=end,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op
        self.add_weight(layer_name, self.value_dict[layer_name])

    def parse_constantofshape(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        value = 0  # default value

        for attr in node.attribute:
            if attr.name == "value":
                value = get_attr_value(attr).item()

        input = self.get_activation_or_value(input_name)
        input.src_shape = self.value_dict[input_name]
        super().make_constant_of_shape(input, value, opname=layer_name)

    def parse_act_func(self, node, **kwargs):
        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)
        super().make_act_func(input, node.op_type.lower(), opname=layer_name, **kwargs)

    def parse_cast(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        # default setting
        data_type = None
        # get value
        for attr in node.attribute:
            if attr.name == "to":
                data_type = get_onnx_data_type(attr.i)

        input = self.get_activation_or_value(input_name)
        super().make_cast(input, data_type, opname=layer_name)

    def parse_pad(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        layer_name = node.output[0]
        input_name = node.input[0]
        pad = None
        constant = 0.0
        if self.opset >= 11:
            pad = self.get_value(node.input[1])
            if len(node.input) > 2:
                constant = self.get_value(node.input[2])
                constant = 0.0 if constant is None else constant
        else:
            pass  # mode, paddings, value

        # default setting
        pad_mode = "constant"
        # get value
        for attr in node.attribute:
            if attr.name == "mode":
                pad_mode = str(attr.s)[2:-1]  # constant, reflect, edge
            elif attr.name == "paddings":
                pad = list(attr.ints)
            elif attr.name == "pads":
                pad = list(attr.ints)
            elif attr.name == "value":
                constant = 0.0 if attr.f is None else attr.f

        input = self.get_activation_or_value(input_name)
        output_src_shape = list(copy.deepcopy(input.src_shape))
        for i in range(len(input.src_shape)):
            output_src_shape[i] += pad[i] + pad[i + len(pad) // 2]
        outact = self.copy_activationspec(
            input, layer_name, src_shape=tuple(output_src_shape)
        )
        op = Operator(
            name=layer_name,
            options=options.PadGenericOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                pad_mode=pad_mode,
                constant=constant,
                padding_list=tuple(pad),
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    @to_channel_last(3)
    def parse_conv1d(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        weight_name = node.input[1]
        if len(node.input) > 2:
            bias_name = node.input[2]
            bias = self.get_value(bias_name)
        else:
            bias_name = None
            bias = None
        input = self.get_activation_or_value(input_name)
        weight = self.get_value(weight_name)

        # default setting
        auto_pad = "NOTSET"
        group_number = 1
        padding_list = [0, 0]
        dilation = None
        kernal = None
        stride = None
        # get value
        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "dilations":
                dilation = attr.ints[0]
            elif attr.name == "group":
                group_number = attr.i
            elif attr.name == "kernel_shape":
                kernal = attr.ints[0]
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "strides":
                stride = attr.ints[0]

        out_ch, in_ch, k_w = weight.shape
        _, in_width, in_channels = input.src_shape

        assert (
            in_ch * group_number == in_channels
        ), "input channel parsing Error for conv"
        in_width = in_width._value
        kernel_width = (k_w - 1) * dilation + 1
        p_w, p_e = padding_list

        if auto_pad == "NOTSET":
            residual_w = (in_width + p_w + p_e - kernel_width) % stride
            p_e = p_e - residual_w if residual_w < p_e else 0

            # noinspection PyPep8
            output_width = (in_width + p_w + p_e - kernel_width) / stride + 1
        elif auto_pad == "SAME_UPPER":
            output_width = math.ceil(in_width / stride)

            pad_width = output_width * stride - in_width + kernel_width - stride
            p_w = pad_width // 2
            p_e = pad_width - p_w
        elif auto_pad == "SAME_LOWER":
            output_width = math.ceil(in_width / stride)

            pad_width = output_width * stride - in_width + kernel_width - stride
            p_e = pad_width // 2
            p_w = pad_width - p_e
        elif auto_pad == "VALID":
            p_w, p_e = 0, 0
            residual_w = (in_width + p_w + p_e - kernel_width) % stride
            p_e = p_e - residual_w if residual_w < p_e else 0

            # noinspection PyPep8
            output_width = (in_width + p_w + p_e - kernel_width) / stride + 1
        else:
            raise ValueError("unknown auto pad attr, ", auto_pad)

        in_ch = in_ch * group_number

        super().make_conv1d(
            input,
            in_channels,
            out_ch,
            k_w,
            stride,
            dilation,
            p_w,
            p_e,
            group_number=group_number,
            weight=weight,
            bias=bias,
            opname=layer_name,
        )

    @to_channel_last(4)
    def parse_conv2d(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        weight_name = node.input[1]
        if len(node.input) > 2:
            bias_name = node.input[2]
            bias = self.get_value(bias_name)
        else:
            bias_name = None
            bias = None
        input = self.get_activation_or_value(input_name)
        weight = self.get_value(weight_name)

        auto_pad = "NOTSET"
        group_number = 1
        padding_list = [0, 0, 0, 0]
        d_h = None
        d_w = None
        k_h = None
        k_w = None
        s_h = None
        s_w = None
        # get value
        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "dilations":
                d_h, d_w = attr.ints
            elif attr.name == "group":
                group_number = attr.i
            elif attr.name == "kernel_shape":
                k_h, k_w = attr.ints
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "strides":
                s_h, s_w = attr.ints

        out_ch, in_ch, k_h, k_w = weight.shape
        _, in_height, in_width, in_channels = input.src_shape
        assert (
            in_ch * group_number == in_channels
        ), "input channel parsing Error for conv"
        in_height = in_height._value
        in_width = in_width._value
        kernel_height = (k_h - 1) * d_h + 1
        kernel_width = (k_w - 1) * d_w + 1
        p_n, p_w, p_s, p_e = padding_list

        if auto_pad == "NOTSET" or auto_pad == "VALID":
            if auto_pad == "VALID":
                p_w, p_n, p_e, p_s = 0, 0, 0, 0
            residual_h = (in_height + p_n + p_s - kernel_height) % s_h
            residual_w = (in_width + p_w + p_e - kernel_width) % s_w
            p_s = p_s - residual_h if residual_h < p_s else 0
            p_e = p_e - residual_w if residual_w < p_e else 0

            output_height = (in_height + p_n + p_s - kernel_height) / s_h + 1
            output_width = (in_width + p_w + p_e - kernel_width) / s_w + 1
        elif auto_pad == "SAME_UPPER" or auto_pad == "SAME_LOWER":
            output_height = math.ceil(in_height / s_h)
            output_width = math.ceil(in_width / s_w)

            pad_height = output_height * s_h - in_height + kernel_height - s_h
            pad_width = output_width * s_w - in_width + kernel_width - s_w
            if auto_pad == "SAME_LOWER":
                p_s = pad_height // 2
                p_n = pad_height - p_s
                p_e = pad_width // 2
                p_w = pad_width - p_e
            else:
                p_n = pad_height // 2
                p_s = pad_height - p_n
                p_w = pad_width // 2
                p_e = pad_width - p_w
        else:
            raise ValueError("unknown auto pad attr, ", auto_pad)

        in_ch = in_ch * group_number

        super().make_conv2d(
            input,
            in_channels,
            out_ch,
            k_h,
            k_w,
            s_h,
            s_w,
            d_h,
            d_w,
            p_w,
            p_e,
            p_s,
            p_n,
            padding_list=padding_list,
            group_number=group_number,
            weight=weight,
            bias=bias,
            opname=layer_name,
        )

    @to_channel_last(5)
    def parse_conv3d(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        layer_name = node.output[0]
        input_name = node.input[0]
        weight_name = node.input[1]
        if len(node.input) > 2:
            bias_name = node.input[2]
            bias = self.get_value(bias_name)
        else:
            bias_name = None
            bias = None
        input = self.get_activation_or_value(input_name)
        weight = self.get_value(weight_name)

        auto_pad = "NOTSET"
        group_number = 1
        padding_list = [0, 0, 0, 0, 0, 0]

        d_h = None
        d_w = None
        d_d = None
        k_h = None
        k_w = None
        k_d = None
        s_h = None
        s_w = None
        s_d = None

        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "dilations":
                d_d, d_h, d_w = attr.ints
            elif attr.name == "group":
                group_number = attr.i
            elif attr.name == "kernel_shape":
                k_d, k_h, k_w = attr.ints
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "strides":
                s_d, s_h, s_w = attr.ints
            else:
                pass

        out_ch, in_ch, k_d, k_h, k_w = weight.shape
        batch, in_depth, in_height, in_width, in_channels = input.src_shape
        assert (
            in_ch * group_number == in_channels
        ), "input channel parsing Error for conv"
        in_depth = in_depth._value
        in_height = in_height._value
        in_width = in_width._value
        kernel_depth = (k_d - 1) * d_d + 1
        kernel_height = (k_h - 1) * d_h + 1
        kernel_width = (k_w - 1) * d_w + 1
        p_f, p_n, p_w, p_b, p_s, p_e = padding_list

        if auto_pad == "NOTSET" or auto_pad == "VALID":
            if auto_pad == "VALID":
                p_w, p_n, p_e, p_s, p_f, p_b = 0, 0, 0, 0, 0, 0
            residual_h = (in_height + p_n + p_s - kernel_height) % s_h
            residual_w = (in_width + p_w + p_e - kernel_width) % s_w
            residual_d = (in_depth + p_f + p_b - kernel_depth) % s_d
            p_s = p_s - residual_h if residual_h < p_s else 0
            p_e = p_e - residual_w if residual_w < p_e else 0
            p_b = p_b - residual_d if residual_w < p_b else 0

            output_height = (in_height + p_n + p_s - kernel_height) / s_h + 1
            output_width = (in_width + p_w + p_e - kernel_width) / s_w + 1
            output_depth = (in_depth + p_f + p_b - kernel_depth) / s_d + 1
        elif auto_pad == "SAME_UPPER" or auto_pad == "SAME_LOWER":
            output_height = math.ceil(in_height / s_h)
            output_width = math.ceil(in_width / s_w)
            output_depth = math.ceil(in_depth / s_d)

            pad_height = output_height * s_h - in_height + kernel_height - s_h
            pad_width = output_width * s_w - in_width + kernel_width - s_w
            pad_depth = output_depth * s_d - in_depth + kernel_depth - s_d
            if auto_pad == "SAME_LOWER":
                p_s = pad_height // 2
                p_n = pad_height - p_s
                p_e = pad_width // 2
                p_w = pad_width - p_e
                p_b = pad_width // 2
                p_f = pad_width - p_b
            else:
                p_n = pad_height // 2
                p_s = pad_height - p_n
                p_w = pad_width // 2
                p_e = pad_width - p_w
                p_f = pad_width // 2
                p_b = pad_width - p_f
        else:
            raise ValueError("unknown auto pad attr, ", auto_pad)
        in_ch = in_ch * group_number
        output_src_shape = tuple(
            [batch, output_depth, output_height, output_width, out_ch]
        )
        outact = self.activationspec(layer_name, input.dtype, output_src_shape)
        op = Operator(
            name=outact.name,
            options=options.Convolution3dOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                in_channels=in_channels,
                out_channels=out_ch,
                h_kernel=k_h,
                w_kernel=k_w,
                d_kernel=k_d,
                h_stride=s_h,
                w_stride=s_w,
                d_stride=s_d,
                h_dilation=d_h,
                w_dilation=d_w,
                d_dilation=d_d,
                west_padding=p_w,
                east_padding=p_e,
                north_padding=p_s,
                south_padding=p_n,
                front_padding=p_f,
                back_padding=p_b,
                padding_list=padding_list,
                group_number=group_number,
                weight=self.add_weight(
                    outact.name + ".weight",
                    weight.reshape((out_ch, in_ch, k_d, k_h, k_w)).astype(
                        numpy.float32
                    ),
                ),
                bias=self.add_weight(outact.name + ".bias", bias.astype(numpy.float32)),
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    def parse_conv(self, node):
        len_attributes = []
        check_att_names = ["dilations", "kernel_shape", "strides"]
        for attr in node.attribute:
            if attr.name in check_att_names:
                len_attributes.append(len(attr.ints))

        if all(element == 2 for element in len_attributes):  # 2D conv parsing
            self.parse_conv2d(node)
        elif all(element == 1 for element in len_attributes):  # 1D conv parsing
            self.parse_conv1d(node)
        elif all(element == 3 for element in len_attributes):  # 3D conv parsing
            self.parse_conv3d(node)
        else:
            raise NotImplementedError(
                "Not implemented parsing case for such convolution"
            )

    @to_channel_last(4)
    def parse_tconv(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """

        def weight_conversion(weight):
            shape = weight.shape
            weight_copy = copy.deepcopy(weight)
            for i in range(shape[2]):
                for j in range(shape[3]):
                    weight_copy[:, :, i, j] = weight[
                        :, :, shape[2] - 1 - i, shape[3] - 1 - j
                    ]
            return numpy.transpose(weight_copy, axes=(1, 0, 2, 3))

        layer_name = node.output[0]
        input_name = node.input[0]
        weight_name = node.input[1]
        if len(node.input) > 2:
            bias_name = node.input[2]
            bias = self.get_value(bias_name)
        else:
            bias_name = None
            bias = None
        input = self.get_activation_or_value(input_name)
        weight = self.get_value(weight_name)

        auto_pad = "NOTSET"
        group_number = 1
        padding_list = [0, 0, 0, 0]
        d_h, d_w, k_h, k_w, s_h, s_w = 1, 1, None, None, None, None
        out_pad_e, out_pad_s = 0, 0
        # get value
        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "dilations":
                d_h, d_w = attr.ints
            elif attr.name == "group":
                group_number = attr.i
            elif attr.name == "kernel_shape":
                k_h, k_w = attr.ints
            elif attr.name == "output_padding":
                out_pad_e, out_pad_s = attr.ints
            elif attr.name == "output_shape":
                output_shape = list(attr.ints)
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "strides":
                s_h, s_w = attr.ints

        in_ch, out_ch, k_h, k_w = weight.shape
        _batch, in_height, in_width, in_channels = input.src_shape
        assert (
            in_ch * group_number == in_channels
        ), "input channel parsing Error for conv"

        kernel_height = (k_h - 1) * d_h + 1
        kernel_width = (k_w - 1) * d_w + 1
        p_n, p_w, p_s, p_e = padding_list

        base_p_w = kernel_width - 1
        base_p_e = kernel_width - 1
        base_p_n = kernel_height - 1
        base_p_s = kernel_height - 1

        npu_p_w = base_p_w - p_w
        npu_p_e = base_p_e - p_e + out_pad_e
        npu_p_n = base_p_n - p_n
        npu_p_s = base_p_s - p_s + out_pad_s

        weight = weight_conversion(weight)

        strided_in_height = (in_height - 1) * s_h + 1
        strided_in_width = (in_width - 1) * s_w + 1
        h_out = _conv_out_size(strided_in_height, npu_p_s, npu_p_n, k_h, d_h, 1)
        w_out = _conv_out_size(strided_in_width, npu_p_w, npu_p_e, k_w, d_w, 1)

        outact = self.activationspec(
            layer_name, input.dtype, (_batch, h_out, w_out, out_ch), DataFormat.NHWC
        )
        in_ch = in_channels // group_number
        conv_weight = weight.reshape((out_ch, in_ch, k_h, k_w)).astype(numpy.float32)
        conv_weight_idx = self.add_weight(outact.name + ".weight", conv_weight)

        conv_bias_idx = -1
        if bias is not None:
            conv_bias = bias.astype(numpy.float32)
            conv_bias_idx = self.add_weight(outact.name + ".bias", conv_bias)

        if padding_list is None:
            padding_list = tuple()

        op = Operator(
            name=outact.name,
            options=options.TransposeConvolutionOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                in_channels=in_ch,
                out_channels=out_ch,
                h_kernel=k_h,
                w_kernel=k_w,
                h_stride=s_h,
                w_stride=s_w,
                h_dilation=d_h,
                w_dilation=d_w,
                west_padding=npu_p_w,
                east_padding=npu_p_e,
                north_padding=npu_p_s,
                south_padding=npu_p_n,
                padding_list=padding_list,
                group_number=group_number,
                weight=conv_weight_idx,
                bias=conv_bias_idx,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    def parse_gemm(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        layer_name = node.output[0]
        input_name = node.input[0]
        weight_name = node.input[1]
        if len(node.input) > 2:
            bias_name = node.input[2]
            bias = self.get_value(bias_name)
        else:
            bias_name = None
            bias = None
        input = self.get_activation_or_value(input_name)
        weight = self.get_value(weight_name)

        # default setting
        alpha = 1.0
        beta = 1.0
        transA = 0
        transB = 0
        # get value
        for attr in node.attribute:
            if attr.name == "alpha":
                alpha = attr.f
            elif attr.name == "beta":
                beta = attr.f
            elif attr.name == "transA":
                transA = attr.i
            elif attr.name == "transB":
                transB = attr.i

        M, K = input.get_act_src_shape()
        K, N = weight.shape
        if transA:
            M, K = K, M
        if transB:
            N, K = K, N
        output_src_shape = (M, N)
        outact = self.activationspec(
            layer_name, input.dtype, output_src_shape, input.dataformat
        )
        weight_idx = self.add_weight(outact.name + ".weight", weight)
        if bias is None:
            bias_idx = -1
        else:
            bias_idx = self.add_weight(outact.name + ".bias", bias)
        op = Operator(
            name=outact.name,
            options=options.GemmConstantOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                constant=weight_idx,
                bias=bias_idx,
                alpha=alpha,
                beta=beta,
                transA=transA,
                transB=transB,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    def parse_qlinear(self, node):
        op_type = node.op_type  # QuantizeLinear or DequantizeLinear
        layer_name = node.output[0]
        input_name = node.input[0]
        scale_name = node.input[1]
        if len(node.input) == 3:
            zeropoint_name = node.input[2]
        elif len(node.input) == 2:
            zeropoint_name = None
        else:
            raise ValueError("In this case, We haven't checked yet")

        raise NotImplementedError("Parsing Qlinear not updated implemented yet")

    def parse_batchnorm(self, node):
        input = self.get_activation_or_value(node.input[0])
        x_rank = len(input.src_shape)
        if 2 <= x_rank <= 4:
            return self._parse_batchnorm(node)
        raise NotImplementedError

    @to_channel_last(2, 3, 4)
    def _parse_batchnorm(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        gamma = self.get_value(node.input[1])
        beta = self.get_value(node.input[2])
        moving_mean = self.get_value(node.input[3])
        moving_var = self.get_value(node.input[4])

        # default setting
        epsilon = 1e-5
        momentum = 0.9
        training_mode = 0
        # get value
        for attr in node.attribute:
            if attr.name == "epsilon":
                epsilon = attr.f
            elif attr.name == "momentum":
                momentum = attr.f
            elif attr.name == "training_mode":
                training_mode = attr.i

        input = self.get_activation_or_value(input_name)
        return super().make_batchnorm(
            input, gamma, beta, moving_mean, moving_var, epsilon, opname=layer_name
        )

    def parse_maxpool(self, node):
        len_attributes = []
        check_att_names = ["dilations", "kernel_shape", "strides"]
        for attr in node.attribute:
            if attr.name in check_att_names:
                len_attributes.append(len(attr.ints))
        if all(element == 2 for element in len_attributes):
            self.parse_maxpool2d(node)
        elif all(element == 1 for element in len_attributes):
            self.parse_maxpool1d(node)
        else:
            raise NotImplementedError("Not implemented maxpool parsing case")

    @to_channel_last(4)
    def parse_maxpool2d(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)

        # default setting
        ceil_mode = 0
        auto_pad = "NOTSET"
        d_h, d_w, s_h, s_w, k_h, k_w = 1, 1, 1, 1, None, None
        padding_list = [0, 0, 0, 0]
        storage_order = 0

        # get value
        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "ceil_mode":
                ceil_mode = attr.i
            elif attr.name == "dilations":
                d_h, d_w = attr.ints
            elif attr.name == "kernel_shape":
                k_h, k_w = attr.ints
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "storage_order":
                storage_order = attr.i
            elif attr.name == "strides":
                s_h, s_w = attr.ints

        kernel_height = (k_h - 1) * d_h + 1
        kernel_width = (k_w - 1) * d_w + 1
        pad_mode = "-inf"
        batch, in_height, in_width, in_channels = input.src_shape
        p_n, p_w, p_s, p_e = padding_list
        in_height = in_height._value
        in_width = in_width._value

        if auto_pad == "SAME_UPPER" or auto_pad == "SAME_LOWER":
            output_height = math.ceil(in_height / s_h)
            output_width = math.ceil(in_width / s_w)

            pad_height = (output_height - 1) * s_h + kernel_height - in_height
            pad_width = (output_width - 1) * s_w + kernel_width - in_width

            if auto_pad == "SAME_LOWER":
                p_s = pad_height // 2
                p_n = pad_height - p_s
                p_e = pad_width // 2
                p_w = pad_width - p_e
            else:
                p_n = pad_height // 2
                p_s = pad_height - p_n
                p_w = pad_width // 2
                p_e = pad_width - p_w

        elif auto_pad == "NOTSET" or auto_pad == "VALID":
            if auto_pad == "VALID":
                p_n = 0
                p_s = 0
                p_e = 0
                p_w = 0

            if ceil_mode:
                output_height = math.ceil(
                    (in_height + (p_n + p_s) - kernel_height) / s_h + 1
                )
                output_width = math.ceil(
                    (in_width + (p_e + p_w) - kernel_width) / s_w + 1
                )
            else:
                output_height = math.floor(
                    (in_height + (p_n + p_s) - kernel_height) / s_h + 1
                )
                output_width = math.floor(
                    (in_width + (p_e + p_w) - kernel_width) / s_w + 1
                )

            pad_height = max((output_height - 1) * s_h + kernel_height - in_height, 0)
            pad_width = max((output_width - 1) * s_w + kernel_width - in_width, 0)

            p_e = pad_width - p_w
            p_s = pad_height - p_n

        else:
            raise ValueError("for maxpool, unknown auto pad attr, ", auto_pad)

        super().make_maxpool(
            input,
            k_h,
            k_w,
            s_h,
            s_w,
            p_w,
            p_e,
            p_s,  # NPU's padding north/south is inverted.
            p_n,
            pad_mode,
            d_h,
            d_w,
            is_ceil_mode=ceil_mode,
            is_include_pad=False,
            opname=layer_name,
        )

    @to_channel_last(3)
    def parse_maxpool1d(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)

        # default setting
        ceil_mode = 0
        auto_pad = "NOTSET"
        dilation = 1
        padding_list = [0, 0]
        storage_order = 0
        stride = 1
        kernel = None
        # get value
        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "ceil_mode":
                ceil_mode = attr.i
            elif attr.name == "dilations":
                dilation = attr.ints[0]
            elif attr.name == "kernel_shape":
                kernel = attr.ints[0]
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "storage_order":
                storage_order = attr.i
            elif attr.name == "strides":
                stride = attr.ints[0]

        kernel_width = (kernel - 1) * dilation + 1
        pad_mode = "-inf"
        batch, in_width, in_channels = input.src_shape
        p_w, p_e = padding_list

        if auto_pad == "SAME_UPPER" or auto_pad == "SAME_LOWER":
            output_width = math.ceil(in_width / stride)
            pad_width = (output_width - 1) * stride + kernel_width - in_width
            if auto_pad == "SAME_LOWER":
                p_e = pad_width // 2
                p_w = pad_width - p_e
            else:
                p_w = pad_width // 2
                p_e = pad_width - p_w

        elif auto_pad == "NOTSET" or auto_pad == "VALID":
            if auto_pad == "VALID":
                p_e = 0
                p_w = 0

            if ceil_mode:
                output_width = math.ceil(
                    (in_width + (p_e + p_w) - kernel_width) / stride + 1
                )
            else:
                output_width = math.floor(
                    (in_width + (p_e + p_w) - kernel_width) / stride + 1
                )
            pad_width = max((output_width - 1) * stride + kernel_width - in_width, 0)
            p_e = pad_width - p_w
        else:
            raise ValueError("for maxpool, unknown auto pad attr, ", auto_pad)
        new_pad_list = (0, p_w, 0, 0, p_e, 0)
        output_src_shape = (batch, output_width, in_channels)
        outact = self.activationspec(
            layer_name, input.dtype, output_src_shape, DataFormat.NXC
        )
        op = Operator(
            name=outact.name,
            options=options.Pooling1dOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                kernel=kernel,
                stride=stride,
                west_padding=p_w,
                east_padding=p_e,
                pool_type="MaxPool",
                pad_mode=pad_mode,
                dilation=dilation,
                padding_list=new_pad_list,
                is_ceil_mode=ceil_mode,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    def parse_avgpool(self, node):
        len_attributes = []
        check_att_names = ["dilations", "kernel_shape", "strides"]
        for attr in node.attribute:
            if attr.name in check_att_names:
                len_attributes.append(len(attr.ints))
        if all(element == 2 for element in len_attributes):  # 2D conv parsing
            self.parse_avgpool2d(node)
        elif all(element == 1 for element in len_attributes):  # 1D conv parsing
            self.parse_avgpool1d(node)
        else:
            raise NotImplementedError("Not implemented avgpool parsing case")

    @to_channel_last(4)
    def parse_avgpool2d(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)

        # default setting
        ceil_mode = 0
        auto_pad = "NOTSET"
        d_h, d_w, s_h, s_w, k_h, k_w = 1, 1, 1, 1, None, None
        padding_list = [0, 0, 0, 0]
        storage_order = 0
        count_include_pad = 0

        # get value
        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "ceil_mode":
                ceil_mode = attr.i
            elif attr.name == "dilations":
                d_h, d_w = attr.ints
            elif attr.name == "kernel_shape":
                k_h, k_w = attr.ints
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "storage_order":
                storage_order = attr.i
            elif attr.name == "strides":
                s_h, s_w = attr.ints
            elif attr.name == "count_include_pad":
                count_include_pad = attr.i

        kernel_height = (k_h - 1) * d_h + 1
        kernel_width = (k_w - 1) * d_w + 1
        batch, in_height, in_width, in_channels = input.src_shape
        p_n, p_w, p_s, p_e = padding_list
        in_height = in_height._value
        in_width = in_width._value

        if auto_pad == "SAME_UPPER" or auto_pad == "SAME_LOWER":
            output_height = math.ceil(in_height / s_h)
            output_width = math.ceil(in_width / s_w)

            pad_height = (output_height - 1) * s_h + kernel_height - in_height
            pad_width = (output_width - 1) * s_w + kernel_width - in_width

            if auto_pad == "SAME_LOWER":
                p_s = pad_height // 2
                p_n = pad_height - p_s
                p_e = pad_width // 2
                p_w = pad_width - p_e
            else:
                p_n = pad_height // 2
                p_s = pad_height - p_n
                p_w = pad_width // 2
                p_e = pad_width - p_w

        elif auto_pad == "NOTSET" or auto_pad == "VALID":
            if auto_pad == "VALID":
                p_n = 0
                p_s = 0
                p_e = 0
                p_w = 0

            if ceil_mode:
                output_height = math.ceil(
                    (in_height + (p_n + p_s) - kernel_height) / s_h + 1
                )
                output_width = math.ceil(
                    (in_width + (p_e + p_w) - kernel_width) / s_w + 1
                )
            else:
                output_height = math.floor(
                    (in_height + (p_n + p_s) - kernel_height) / s_h + 1
                )
                output_width = math.floor(
                    (in_width + (p_e + p_w) - kernel_width) / s_w + 1
                )

            pad_height = max((output_height - 1) * s_h + kernel_height - in_height, 0)
            pad_width = max((output_width - 1) * s_w + kernel_width - in_width, 0)

            p_e = pad_width - p_w
            p_s = pad_height - p_n

        else:
            raise ValueError("for avgpool, unknown auto pad attr, ", auto_pad)

        super().make_avgpool(
            input,
            k_h,
            k_w,
            s_h,
            s_w,
            p_w,
            p_e,
            p_s,  # NPU's padding north/south is inverted.
            p_n,
            "constant",
            d_h,
            d_w,
            is_ceil_mode=ceil_mode,
            is_include_pad=count_include_pad,
            opname=layer_name,
        )

    @to_channel_last(3)
    def parse_avgpool1d(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)

        # default setting
        auto_pad = "NOTSET"
        ceil_mode = 0  # default = floor
        count_include_pad = False  # default = not count
        padding_list = [0, 0]
        stride = 1
        dilation = 1
        kernel = None
        # get value
        for attr in node.attribute:
            if attr.name == "auto_pad":
                auto_pad = str(attr.s)[2:-1]
            elif attr.name == "ceil_mode":
                ceil_mode = attr.i
            elif attr.name == "count_include_pad":
                count_include_pad = bool(attr.i)
            elif attr.name == "kernel_shape":
                kernel = attr.ints[0]
            elif attr.name == "pads":
                padding_list = list(attr.ints)
            elif attr.name == "strides":
                stride = attr.ints[0]
            elif attr.name == "dilations":
                dilation = attr.ints[0]
        batch, input_width, input_channels = input.src_shape
        p_w, p_e = padding_list

        if auto_pad == "SAME_UPPER" or auto_pad == "SAME_LOWER":
            output_width = math.ceil(input_width / stride)
            pad_width = (output_width - 1) * stride + kernel - input_width

            if auto_pad == "SAME_LOWER":
                p_e = pad_width // 2
                p_w = pad_width - p_e
            else:
                p_w = pad_width // 2
                p_e = pad_width - p_w

        elif auto_pad == "NOTSET" or auto_pad == "VALID":
            if auto_pad == "VALID":
                p_e = 0
                p_w = 0

            if ceil_mode:
                output_width = math.ceil(
                    (input_width + (p_e + p_w) - kernel) / stride + 1
                )
            else:
                output_width = math.floor(
                    (input_width + (p_e + p_w) - kernel) / stride + 1
                )

            pad_width = max((output_width - 1) * stride + kernel - input_width, 0)

            p_e = pad_width - p_w
        else:
            raise ValueError("unknown auto pad attr, ", auto_pad)

        new_pad_list = (0, p_w, 0, 0, p_e, 0)
        output_src_shape = (batch, output_width, input_channels)
        outact = self.activationspec(
            layer_name, input.dtype, output_src_shape, DataFormat.NXC
        )
        op = Operator(
            name=outact.name,
            options=options.Pooling1dOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                kernel=kernel,
                stride=stride,
                west_padding=p_w,
                east_padding=p_e,
                pool_type="AvgPool",
                pad_mode="constant",
                dilation=dilation,
                padding_list=new_pad_list,
                is_ceil_mode=ceil_mode,
                is_include_pad=count_include_pad,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    @to_channel_last(3)
    def parse_global_avgpool_3d(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)
        super().make_global_avgpool_nd(input, channel_last=True, opname=layer_name)

    @to_channel_last(4)
    def parse_global_avgpool_4d(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)
        _, k_h, k_w, c = input.src_shape
        super()._make_pooling(
            input,
            h_kernel=k_h.value,
            w_kernel=k_w.value,
            w_stride=1,
            h_stride=1,
            west_padding=0,
            east_padding=0,
            north_padding=0,
            south_padding=0,
            pool_type="AvgPool",
            pad_mode="constant",
            h_dilation=1,
            w_dilation=1,
            padding_list=None,
            is_ceil_mode=False,
            is_include_pad=False,
            opname=layer_name,
        )

    @to_channel_last(5)
    def parse_global_avgpool_5d(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)
        super().make_global_avgpool_nd(input, channel_last=True, opname=layer_name)

    def parse_global_avgpool_nd(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)
        _, k_h, k_w, c = input.src_shape
        super()._make_pooling(
            input,
            h_kernel=k_h.value,
            w_kernel=k_w.value,
            w_stride=1,
            h_stride=1,
            west_padding=0,
            east_padding=0,
            north_padding=0,
            south_padding=0,
            pool_type="AvgPool",
            pad_mode="constant",
            h_dilation=1,
            w_dilation=1,
            padding_list=None,
            is_ceil_mode=False,
            is_include_pad=False,
            opname=layer_name,
        )

    def parse_global_avgpool(self, node):
        input = self.get_activation_or_value(node.input[0])
        layer_name = node.output[0]
        if len(input.src_shape) == 3:
            self.parse_global_avgpool_3d(node)
        elif len(input.src_shape) == 4:
            self.parse_global_avgpool_4d(node)
        elif len(input.src_shape) == 5:
            self.parse_global_avgpool_5d(node)
        else:
            super().make_global_avgpool_nd(input, channel_last=False, opname=layer_name)

    def parse_biop_math(self, node, func):
        layer_name = node.output[0]
        left_name = node.input[0]
        right_name = node.input[1]
        left = self.get_activation_or_value(left_name, const_ok=True)
        right = self.get_activation_or_value(right_name, const_ok=True)
        opkind = node.op_type.lower()
        func(left, right, opkind, opname=layer_name)

    def parse_biop(self, node, func):
        """
        Parse as many "biop" operators as possible with single function
        biop - operators with two inputs, and without any further attributes
        """
        if not func:
            raise NotImplementedError
        layer_name = node.output[0]
        left_name = node.input[0]
        right_name = node.input[1]
        left = self.get_activation_or_value(left_name, const_ok=True)
        right = self.get_activation_or_value(right_name, const_ok=True)

        if (
            isinstance(func, type)
            and isinstance(left, ActivationSpec)
            and isinstance(right, ActivationSpec)
        ):
            # For operators which parsing is not yet implemented in MobilintSubGraphBuilder
            outact = self.copy_activationspec(left, name=layer_name)
            op = Operator(
                name=layer_name,
                options=func(
                    inputs=(
                        self.get_activation_index(left),
                        self.get_activation_index(right),
                    ),
                    outputs=(self.get_activation_index(outact),),
                ),
            )
            self.add_operator(op)
            outact.producer_op = op
        elif (
            isinstance(func, type)
            and isinstance(left, ActivationSpec)
            and isinstance(right, numpy.ndarray)
        ):
            outact = self.copy_activationspec(left, name=layer_name)
            constant_data = self.add_weight(left.name + "_const", right)
            op = Operator(
                name=layer_name,
                options=func(
                    inputs=(self.get_activation_index(left),),
                    outputs=(self.get_activation_index(outact),),
                    constant=constant_data,
                    is_const_first=False,
                ),
            )
            self.add_operator(op)
            outact.producer_op = op
        elif (
            isinstance(func, type)
            and isinstance(left, numpy.ndarray)
            and isinstance(right, ActivationSpec)
        ):
            outact = self.copy_activationspec(left, name=layer_name)
            constant_data = self.add_weight(right.name + "_const", left)
            op = Operator(
                name=layer_name,
                options=func(
                    inputs=(self.get_activation_index(right),),
                    outputs=(self.get_activation_index(outact),),
                    constant=constant_data,
                    is_const_first=True,
                ),
            )
            self.add_operator(op)
            outact.producer_op = op
        else:
            func(left, right, opname=layer_name)

    def parse_reduce(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        - Parent class only supports following modes
            - ReduceMean
            - ReduceSum
            - ReduceL2
        """
        if len(node.input) not in [1, 2]:
            raise ValueError(
                f"Error. The number of inputs of {node.op_type} layer should be 1 or 2."
            )
        layer_name = node.output[0]
        input_name = node.input[0]

        keep_dims = 1
        noop_with_empty_axes = 0
        axes = None
        if len(node.input) == 2:
            axes = self.get_value(node.input[1])

        for attr in node.attribute:
            if attr.name == "keepdims":
                keep_dims = attr.i
            elif attr.name == "axes":
                if axes is not None:
                    raise ValueError("Axes cannot be both in Inputs and Attributes.")
                axes = list(attr.ints)
            elif attr.name == "noop_with_empty_axes":
                noop_with_empty_axes = attr.i
            else:
                raise ValueError(
                    f"Error. The attribute {attr.name} of {node.op_type} layer is not supported."
                )
        input = self.get_activation_or_value(input_name)
        reduce_axes = copy.deepcopy(axes)
        for i, axis in enumerate(reduce_axes):
            if axis < 0:
                reduce_axes[i] += len(input.src_shape)

        if reduce_axes is None and noop_with_empty_axes == 1:
            outact = self.copy_activationspec(input, layer_name)
            op = Operator(
                name=outact.name,
                options=options.IdentityOptions(
                    inputs=(self.get_activation_index(input),),
                    outputs=(self.get_activation_index(outact),),
                ),
            )
        else:
            if keep_dims > 0:
                output_src_shape = [
                    dim if i not in reduce_axes else 1
                    for i, dim in enumerate(input.src_shape)
                ]
            else:
                if reduce_axes is None:
                    reduce_axes = [i for i in range(len(input.src_shape))]
                output_src_shape = [
                    dim for i, dim in enumerate(input.src_shape) if i not in reduce_axes
                ]
            outact = self.activationspec(
                layer_name, input.dtype, tuple(output_src_shape)
            )
            op = Operator(
                name=outact.name,
                options=OPTIONSMAPPER[node.op_type.lower()](
                    inputs=(self.get_activation_index(input),),
                    outputs=(self.get_activation_index(outact),),
                    reduce_axes=reduce_axes,
                    keep_dims=bool(keep_dims),
                    noop_with_empty_axes=noop_with_empty_axes,  # onnx default
                ),
            )

        self.add_operator(op)
        outact.producer_op = op

    def parse_resize(self, node):
        """
        Such function does exist in MobilintSubGraphBuilder class
        As ONNX Resize has more attributes, separate implementation is necessary before fusing this function to parent one
        """
        layer_name = node.output[0]
        input_name = node.input[0]

        # default setting
        transform_mode = "half_pixel"
        cubic_coeff_a = 0.75
        exclude_outside = 0
        extrapolation_value = 0.0
        resize_mode = "nearest"
        nearest_mode = "round_prefer_floor"
        antialias = 0
        axes = None
        keep_aspect_ratio_policy = "stretch"
        roi = None
        scales = None
        sizes = None

        if self.opset >= 13:
            if len(node.input) > 1 and node.input[1] != "":
                roi = self.get_value(node.input[1])  # only for tf_crop_and_resize
            if len(node.input) > 2 and node.input[2] != "":
                scales = self.get_value(node.input[2])
            if len(node.input) > 3 and node.input[3] != "":
                sizes = self.get_value(node.input[3])
        elif self.opset >= 11:
            if node.input[1] != "" and node.input[1] in self.value_dict.keys():
                roi = self.get_value(node.input[1])
            if node.input[2] != "" and node.input[2] in self.value_dict.keys():
                scales = self.get_value(node.input[2])
            if len(node.input) > 3:
                sizes = self.get_value(node.input[3])
        elif self.opset >= 10:
            scales = self.get_value(
                node.input[1]
            )  # output = floor(input_dimension * scale)
        else:
            raise NotImplementedError(
                "Unkown opset for resize operation. opset = ", self.opset
            )
        for attr in node.attribute:
            if attr.name == "coordinate_transformation_mode":
                transform_mode = str(attr.s)[2:-1]
            elif attr.name == "cubic_coeff_a":
                cubic_coeff_a = attr.f
            elif attr.name == "exclude_outside":
                exclude_outside = attr.i
            elif attr.name == "extrapolation_value":
                extrapolation_value = attr.f
            elif attr.name == "mode":
                resize_mode = str(attr.s)[2:-1]
            elif attr.name == "nearest_mode":
                nearest_mode = str(attr.s)[2:-1]
            elif attr.name == "antialias":
                antialias = attr.i
            elif attr.name == "axes":
                axes = list(attr.ints)
            elif attr.name == "keep_aspect_ratio_policy":
                keep_aspect_ratio_policy = str(attr.s)[2:-1]

        input = self.get_activation_or_value(input_name)
        outact = self.copy_activationspec(
            input, layer_name, src_shape=tuple(self.value_dict[layer_name].shape)
        )

        if scales is None and sizes is None:
            if input.contain_dynamic:
                logger.info(
                    f"inact contain dynamic shape: please check parsing process"
                )
            scales = tuple(
                float(out_shape) / float(in_shape)
                for in_shape, out_shape in zip(input.src_shape, outact.src_shape)
            )

        op = Operator(
            name=layer_name,
            options=options.ResizeOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                resize_type=resize_mode,
                resize_mode=resize_mode,
                nearest_mode=nearest_mode,
                transform_mode=transform_mode,
                roi=roi,
                scales=scales,
                sizes=sizes,
                cubic_coeff_a=cubic_coeff_a,
                exclude_outside=exclude_outside,
                extrapolation_value=extrapolation_value,
                antialias=antialias,
                axes=axes,
                keep_aspect_ratio_policy=keep_aspect_ratio_policy,
            ),
        )
        self.add_operator(op)

    def parse_einsum(self, node):
        layer_name = node.output[0]
        input_names = list(node.input)

        # get attr
        equation = None
        for attr in node.attribute:
            if attr.name == "equation":
                equation = attr.s.decode("utf-8")

        super().make_einsum(
            tuple([self.get_activation_or_value(idx) for idx in input_names]),
            equation,
            layer_name,
        )

    def parse_upsample(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        layer_name = node.output[0]
        input_name = node.input[0]
        scale_list = None
        up_mode = "nearest"

        if self.opset >= 9:
            scale_list = self.get_value(node.input[1])
        for attr in node.attribute:
            if attr.name == "mode":
                up_mode = str(attr.s)[2:-1]
            elif attr.name == "scales":
                scale_list = attr.floats

        input = self.get_activation_or_value(input_name)
        output_src_shape = [
            float(round(i.value * s)) for i, s in zip(input.src_shape, scale_list)
        ]
        outact = self.copy_activationspec(
            input, layer_name, src_shape=tuple(output_src_shape)
        )
        op = Operator(
            name=outact.name,
            options=options.UpsamplingOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                up_mode=up_mode,
                scales=tuple(scale_list),
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    def parse_concatenate(self, node):
        layer_name = node.output[0]
        input_name_list = list(node.input)
        input_list = [self.get_activation_or_value(idx) for idx in input_name_list]
        axis = None
        for attr in node.attribute:
            if attr.name == "axis":
                axis = attr.i
        super().make_concatenate(input_list, axis, opname=layer_name)

    def parse_leakyrelu(self, node):
        # default setting
        alpha = 0.01
        # get attr
        for attr in node.attribute:
            if attr.name == "alpha":
                alpha = attr.f

        self.parse_act_func(node, leaky_alpha=alpha)

    def parse_mish(self, node):
        self.parse_act_func(node)

    def parse_swish(self, node):
        alpha = 1.0
        for attr in node.attribute:
            if attr.name == "alpha":
                alpha = attr.f
        # self.parse_act_func(node, alpha=alpha)
        self.parse_act_func(node)

    def parse_gelu(self, node):
        approximate = False
        for attr in node.attribute:
            if attr.name == "approximate":
                approximate = attr.s != b"none"

        self.parse_act_func(node, approximate=approximate)

    def parse_celu(self, node):
        alpha = 1
        for attr in node.attribute:
            if attr.name == "alpha":
                alpha = attr.f

        self.parse_act_func(node, alpha=alpha)

    def parse_selu(self, node):
        alpha = 1.67326
        gamma = 1.0507
        for attr in node.attribute:
            if attr.name == "alpha":
                alpha = attr.f
            elif attr.name == "gamma":
                gamma = attr.f
        self.parse_act_func(node, alpha=alpha, gamma=gamma)

    def parse_elu(self, node):
        # default setting
        alpha = 1.0
        # get attr
        for attr in node.attribute:
            if attr.name == "alpha":
                alpha = attr.f

        self.parse_act_func(node, leaky_alpha=alpha)

    def parse_prelu(self, node):
        slope = self.get_value(node.input[1])
        if isinstance(slope, numpy.ndarray):
            slope = slope.astype(numpy.float32)
        elif isinstance(slope, numbers.Real):
            slope = float(slope)
        else:
            raise NotImplementedError
        self.parse_act_func(node, leaky_alpha=slope)

    def parse_hardsigmoid(self, node):
        # get value
        alpha = 0.2
        beta = 0.5
        for attr in node.attribute:
            if attr.name == "alpha":
                alpha = attr.f
            elif attr.name == "beta":
                beta = attr.f
        self.parse_act_func(node, alpha=alpha, beta=beta)

    def parse_softmax(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]

        # default setting
        if self.opset >= 13:
            axis = -1
        else:
            axis = 1
        # get value
        for attr in node.attribute:
            if attr.name == "axis":
                axis = attr.i

        input = self.get_activation_or_value(input_name)
        super().make_softmax(input, axis, beta=1, opname=layer_name)

    def parse_clip(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]

        if self.opset >= 11:
            min_value = self.get_value(node.input[1])
            if len(node.input) == 3:
                max_value = self.get_value(node.input[2])
            else:
                max_value = None
        else:
            min_value = None
            max_value = None
            for attr in node.attribute:
                if attr.name == "min":
                    min_value = attr.f
                elif attr.name == "max":
                    max_value = attr.f

        input = self.get_activation_or_value(input_name)
        super().make_clip(input, min_value, max_value, opname=layer_name)

    def parse_max(self, node):
        if len(node.input) != 2:
            raise NotImplementedError(
                f"max with {len(node.input)} input(s) is not supported yet."
            )
        layer_name = node.output[0]
        input_name0 = node.input[0]
        input_name1 = node.input[1]
        if input_name0 in self._weights and input_name1 not in self._weights:
            const_name, act_name = input_name0, input_name1
        elif input_name1 in self._weights and input_name0 not in self._weights:
            const_name, act_name = input_name1, input_name0
        else:
            raise ValueError(
                "max with two inputs should be one of the two inputs is a constant with single value."
            )

        const_arr = numpy.asarray(self._weights[const_name])
        if const_arr.size != 1:
            raise ValueError(
                f"expected const with exactly 1 element, got {const_arr.size}"
            )

        const_val = const_arr.reshape(-1)[0].item()

        input_ = self.get_activation_or_value(act_name)
        return super().make_clip(input_, clip_min_value=const_val, opname=layer_name)

    def parse_min(self, node):
        if len(node.input) != 2:
            raise NotImplementedError(
                f"min with {len(node.input)} input(s) is not supported yet."
            )
        layer_name = node.output[0]
        input_name0 = node.input[0]
        input_name1 = node.input[1]
        if input_name0 in self._weights and input_name1 not in self._weights:
            const_name, act_name = input_name0, input_name1
        elif input_name1 in self._weights and input_name0 not in self._weights:
            const_name, act_name = input_name1, input_name0
        else:
            raise ValueError(
                "max with two inputs should be one of the two inputs is a constant with single value."
            )

        const_arr = numpy.asarray(self._weights[const_name])
        if const_arr.size != 1:
            raise ValueError(
                f"expected const with exactly 1 element, got {const_arr.size}"
            )

        const_val = const_arr.reshape(-1)[0].item()

        input_ = self.get_activation_or_value(act_name)
        return super().make_clip(input_, clip_max_value=const_val, opname=layer_name)

    def parse_pow(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        exponent_name = node.input[1]

        input = self.get_activation_or_value(input_name)
        exponent = self.get_value(exponent_name)
        super().make_pow(input, exponent, layer_name)

    def parse_slice(self, node):
        """
        Such function exists in MobilintSubGraphBuilder class
        However, in order to transform slice operators where necessary, 'step' attribute should not be created even if original value is None
        Therefore, separate function has been created, prior to fusion
        """

        def slice_out_len(start, end, step, seq_length):
            start_ = max(
                0, min(seq_length, start if start >= 0 else seq_length + start)
            )
            end_ = max(0, min(seq_length, end if end >= 0 else seq_length + end))
            if step > 0:
                length = max(0, (end_ - start_ + step - 1) // step)
            elif step < 0:
                length = max(0, (start_ - end_ - step - 1) // -step)
            else:
                raise ValueError("step cannot be 0")
            return length

        layer_name = node.output[0]
        input_name = node.input[0]
        # default setting
        axis = None
        start = None
        end = None
        step = None
        if self.opset >= 10:
            start = self.get_value(node.input[1])
            end = self.get_value(node.input[2])
            axis = self.get_value(node.input[3]) if len(node.input) > 3 else None
            step = self.get_value(node.input[4]) if len(node.input) > 4 else None
        else:
            # get attr
            for attr in node.attribute:
                if attr.name == "starts":
                    start = tuple(attr.ints)
                elif attr.name == "ends":
                    end = tuple(attr.ints)
                elif attr.name == "axes":
                    axis = tuple(attr.ints)
            if axis is None:
                axis = tuple(range(len(start)))
        if step is None:
            step_ = [1] * len(axis)
        else:
            step_ = list(step)
            for i, st in enumerate(step_):
                if st is None:
                    step_[i] = 1

        input = self.get_activation_or_value(input_name)
        new_src_shape = list(input.get_act_src_shape())

        new_axis = []
        for a in axis:
            if a < 0:
                a += len(input.get_act_src_shape())
            new_axis.append(a)
        axis = new_axis

        for i, _s, _e, _st in zip(axis, start, end, step_):
            new_src_shape[i] = slice_out_len(_s, _e, _st, new_src_shape[i])

        outact = self.copy_activationspec(
            input, name=layer_name, src_shape=new_src_shape, shape=(-1, -1, -1)
        )
        op = Operator(
            outact.name,
            options=options.SliceOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                axis=axis,
                start=start,
                end=end,
                step=step,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    @to_channel_last(4)
    def parse_depth_to_space(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        layer_name = node.output[0]
        input_name = node.input[0]
        block_size = None
        mode = "DCR"  # default (or CRD)
        for attr in node.attribute:
            if attr.name.lower() == "blocksize":
                block_size = attr.i
            if attr.name.lower() == "mode":
                mode = str(attr.s)[2:-1]

        input = self.get_activation_or_value(input_name)
        output_src_shape = []
        for i, src in enumerate(input.src_shape):
            if i == 0:
                output_src_shape.append(src)
            elif i == len(input.src_shape) - 1:
                output_src_shape.append(src / (block_size * block_size))
            else:
                output_src_shape.append(src * block_size)
        outact = self.copy_activationspec(
            input, layer_name, src_shape=tuple(output_src_shape)
        )
        op = Operator(
            name=outact.name,
            options=options.DepthToSpaceOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                block_size=block_size,
                mode=mode,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    def parse_reshape(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        shape_name = node.input[1]
        allowzero = 0
        # get attr
        for attr in node.attribute:
            if attr.name == "allowzero":
                allowzero = list(attr.ints)

        input = self.get_activation_or_value(input_name)
        shape = copy.deepcopy(self.get_value(shape_name))
        if not bool(allowzero):
            for idx, sh in enumerate(shape):
                if sh == 0:
                    shape[idx] = int(input.src_shape[idx])

        super().make_reshape(input, tuple(shape), opname=layer_name)

    def parse_transpose(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)

        # default setting
        attr = None
        # get attr
        for attr in node.attribute:
            if attr.name == "perm":
                perm = list(attr.ints)

        return super().make_transpose(input, perm, opname=layer_name)

    def parse_squeeze(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        axes = None
        if self.opset >= 13:
            if len(node.input) > 1:
                axes = self.get_value(node.input[1])
        elif self.opset >= 1:
            pass

        # get attr
        for attr in node.attribute:
            if attr.name == "axes":
                axes = list(attr.ints)

        input = self.get_activation_or_value(input_name)
        super().make_squeeze(input, axes, opname=layer_name)

    def parse_unsqueeze(self, node):
        """
        Such function exists in MobilintSubGraphBuilder class
        Separate function has been created in order to support axis with List|Tuple of values
        """
        layer_name = node.output[0]
        input_name = node.input[0]
        axes = None
        if self.opset >= 13:
            if len(node.input) > 1:
                axes = self.get_value(node.input[1])
        elif self.opset >= 1:
            pass

        # get attr
        for attr in node.attribute:
            if attr.name == "axes":
                axes = list(attr.ints)

        input = self.get_activation_or_value(input_name)
        out_src_len = len(input.src_shape) + len(axes)
        axes = copy.deepcopy(axes)
        for i, axis in enumerate(axes):
            if axis < 0:
                axes[i] += out_src_len
        output_src_shape = []
        j = 0
        for i in range(out_src_len):
            if i in axes:
                output_src_shape.append(1)
            else:
                output_src_shape.append(input.src_shape[j])
                j += 1

        outact = self.activationspec(
            layer_name, dtype=input.dtype, src_shape=tuple(output_src_shape)
        )
        op = Operator(
            name=layer_name,
            options=options.UnsqueezeOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                axes=axes,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    def parse_flatten(self, node):
        """
        Such function does exist in MobilintSubGraphBuilder class
        Behaviours of flatten functions for ONNX and torch are different,
        and so are the output shapes.
        Therefore, separate parsing function for ONNX flatten operator is implemented
        """
        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)
        # default setting
        axis = 1
        # get attr
        for attr in node.attribute:
            if attr.name == "axis":
                axis = attr.i
        flatten_front = functools.reduce(
            operator.mul, (int(x) for x in input.src_shape[:axis]), 1
        )
        flatten_back = functools.reduce(
            operator.mul, (int(x) for x in input.src_shape[axis:]), 1
        )
        output_src_shape = (flatten_front,) + (flatten_back,)
        outact = self.activationspec(layer_name, input.dtype, output_src_shape)
        op = Operator(
            name=outact.name,
            options=options.FlattenOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                axis=axis,
            ),
        )
        self.add_operator(op)

    def parse_argmax(self, node):
        """
        Such function exists in MobilintSubGraphBuilder class
        Implementation with additional feature, where keepdims is False.
        """
        layer_name = node.output[0]
        input_name = node.input[0]

        # default setting
        axis = 0
        keep_dims = 1
        select_last_index = 0
        # get attr
        for attr in node.attribute:
            if attr.name == "axis":
                axis = attr.i
            elif attr.name == "keepdims":
                keep_dims = attr.i
            elif attr.name == "select_last_index":
                select_last_index = attr.i

        input = self.get_activation_or_value(input_name)
        if axis < 0:
            axis += input.src_dim

        if keep_dims > 0:
            output_src_shape = [
                1 if i == axis else dim for i, dim in enumerate(input.src_shape)
            ]
            dataformat = input.dataformat
        else:
            output_src_shape = [
                dim for i, dim in enumerate(input.src_shape) if i != axis
            ]
            dataformat = DataFormat.UNKNOWN

        outact = self.copy_activationspec(
            input,
            layer_name,
            "int64",
            src_shape=tuple(output_src_shape),
            dataformat=dataformat,
        )

        op = Operator(
            name=outact.name,
            options=options.ArgMaxOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                axis=axis,
                keepdims=bool(keep_dims),
                select_last=bool(select_last_index),
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    def parse_loop(self, node):
        output_list = list(node.output)
        graph = None
        for attr in node.attribute:
            if attr.name == "body":
                graph = attr.g

        graph_output_list = [n.name for n in graph.output]
        for graph_node in graph.node:
            self.parse_node(graph_node)
        for i in range(len(output_list)):
            output_name = output_list[i]
            graph_output_name = graph_output_list[i + 1]
            graph_output = self.get_activation_or_value(graph_output_name)
            super().make_identity(graph_output, opname=output_name)

    def parse_tile(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        layer_name = node.output[0]
        input_name = node.input[0]
        repeats_name = node.input[1]

        input = self.get_activation_or_value(input_name)
        repeats = self.get_value(repeats_name)
        output_src_shape = [i * r for i, r in zip(input.src_shape, repeats)]
        outact = self.copy_activationspec(
            input, layer_name, src_shape=tuple(output_src_shape)
        )
        op = Operator(
            name=outact.name,
            options=options.TileOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                repeats=tuple(repeats),
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    def parse_split(self, node):
        """
        Such function exists in MobilintSubGraphBuilder class
        Separate implementation for ONNX Split operator.
        """

        def check_split(split, num_outputs, split_rank):
            # If split is not provided, split is made from num_outputs
            if split is None:
                q, r = divmod(split_rank, num_outputs)
                if self.opset >= 18 and r != 0:
                    chunk_size = q + 1
                    last_chunk_size = split_rank - chunk_size * (num_outputs - 1)
                    if last_chunk_size <= 0:
                        raise ValueError(
                            f"Cannot split {split_rank} into {num_outputs}"
                            " chunks, last_chunk_size should be positive but "
                            f"got {last_chunk_size}"
                        )
                elif r == 0:  # any opset version
                    chunk_size, last_chunk_size = q, q
                else:  # opset < 18 and r != 0
                    raise ValueError(
                        f"Cannot evenly split {split_rank} into "
                        f"{num_outputs} chunks, opset = {self.opset}"
                    )
                split = [chunk_size] * (num_outputs - 1) + [last_chunk_size]
            if isinstance(split, numpy.ndarray):
                split = list(split)
                split = [int(i) for i in split]
            return split

        output_list = node.output
        input_name = node.input[0]

        axis = 0  # onnx default value
        num_outputs = None
        split = None
        # Parse attributes
        if self.opset >= 13:
            for attr in node.attribute:
                if attr.name == "axis":
                    axis = attr.i
                elif self.opset >= 18 and attr.name == "num_outputs":
                    num_outputs = attr.i
            if len(node.input) == 2:
                split = self.get_value(node.input[1])
        elif self.opset >= 2:
            for attr in node.attribute:
                if attr.name == "axis":
                    axis = attr.i
                elif attr.name == "split":
                    split = list(attr.ints)
        else:
            for attr in node.attribute:
                if attr.name == "axis":
                    axis = attr.i
                elif attr.name == "split":
                    split = list(attr.ints)
            if len(node.input) == 2:
                if split is not None:
                    raise ValueError("Split cannot be both in Inputs and Attributes.")
                split = node.input[1]

        if num_outputs is None:
            num_outputs = len(output_list)

        input = self.get_activation_or_value(input_name)
        if isinstance(axis, numpy.ndarray) and len(axis.shape) == 0:
            axis = int(axis)
        if axis < 0:
            axis += len(input.src_shape)

        split = check_split(split, num_outputs, input.src_shape[axis].value)
        for i, out in enumerate(node.output):
            output_src_shape = list(input.src_shape)
            output_src_shape[axis] = split[i]
            outact = self.copy_activationspec(
                input, out, src_shape=tuple(output_src_shape)
            )
            op = Operator(
                name=out,
                options=options.SplitOptions(
                    inputs=(self.get_activation_index(input),),
                    outputs=(self.get_activation_index(outact),),
                    axis=axis,
                    split=tuple(split),
                    num_outputs=num_outputs,
                    split_index=i,
                ),
            )
            self.add_operator(op)

    def parse_instance_norm(self, node):
        input = self.get_activation_or_value(node.input[0])
        x_rank = len(input.src_shape)
        if 2 <= x_rank <= 4:
            return self._parse_instancenorm(node)
        raise NotImplementedError("instance_norm with rank=1 not supported")

    def parse_simplifiedLayerNormalization(self, node):
        input_name_list = list(node.input)
        layer_name = node.output[0]
        inact = self.get_activation(input_name_list[0])
        scale_value = self.get_value(input_name_list[1])
        for attr in node.attribute:
            if attr.name.lower() == "epsilon":
                epsilon = attr.f
            elif attr.name.lower() == "axis":
                axis = attr.i

        if isinstance(inact, ActivationSpec):
            inact_shape = inact.src_shape
        else:
            raise NotImplementedError(f"NotImplemented Error")

        normalized_shape = (inact_shape[axis],)
        # for onnx, node name contains "layernorm", but its operations involve rmsnrom.
        return super().make_rmsnorm(
            inact, epsilon, scale_value, normalized_shape, layer_name
        )

    def parse_skipsimplifiedlayernormalization(self, node):
        input_name_list = list(node.input)
        if len(input_name_list) == 3:
            input_act = self.get_activation(input_name_list[0])
            skip = self.get_activation(input_name_list[1])
            gamma_value = self.get_value(input_name_list[2])
        else:
            raise NotImplementedError

        for attr in node.attribute:
            if attr.name.lower() == "epsilon":
                epsilon = attr.f

        output_name_list = list(node.output)
        if len(output_name_list) == 4:
            if (
                output_name_list[1] == output_name_list[2] != ""
            ):  # ignore mean and inv_std_var
                raise NotImplementedError
            return super().make_skipsimplifiedlayernormalization(
                input_act,
                skip,
                gamma_value,
                epsilon,
                output_name=output_name_list[0],
                input_skip_bias_sum_name=output_name_list[3],
            )
        elif len(output_name_list) == 1:
            return super().make_skipsimplifiedlayernormalization(
                input_act, skip, gamma_value, epsilon, output_name=output_name_list[0]
            )
        else:
            raise NotImplementedError

    def parse_group_query_attention(self, node):
        input_name_list = list(node.input)
        output_name = node.output[0]
        for attr in node.attribute:
            if attr.name.lower() == "num_heads":
                num_heads = attr.i
            elif attr.name.lower() == "kv_num_heads":
                kv_num_heads = attr.i
            elif attr.name.lower() == "scale":
                scale = attr.f
            elif attr.name.lower() == "do_rotary":
                do_rotary = attr.i
            elif attr.name.lower() == "rotary_interleaved":
                rotary_interleaved = attr.i

        if len(input_name_list) != 9:
            raise NotImplementedError(f"not implemented parse_group_query_attention")

        query = self.get_activation(input_name_list[0])
        key = (
            self.get_activation(input_name_list[1]) if input_name_list[1] != "" else ""
        )
        value = (
            self.get_activation(input_name_list[2]) if input_name_list[1] != "" else ""
        )
        past_key = input_name_list[3]
        past_value = input_name_list[4]
        seqlens_k = self.get_value(input_name_list[5])
        total_sequence_length = self.get_value(input_name_list[6])
        cos_cache = self.get_value(input_name_list[7])
        sin_cache = self.get_value(input_name_list[8])

        return super().make_group_query_attention(
            query=query,
            key=key,
            value=value,
            past_key=past_key,
            past_value=past_value,
            seqlens_k=seqlens_k,
            total_sequence_length=total_sequence_length,
            cos_cache=cos_cache,
            sin_cache=sin_cache,
            num_heads=num_heads,
            kv_num_heads=kv_num_heads,
            scale=scale,
            do_rotary=do_rotary,
            rotary_interleaved=rotary_interleaved,
            opname=output_name,
        )

    @to_channel_last(3, 4)
    def _parse_instancenorm(self, node):
        assert (
            len(node.input) == 3
        ), f"Got unsupported number of inputs for Instance Normalization: {len(node.input)}."
        layer_name = node.output[0]
        input_name, scale_name, bias_name = node.input
        epsilon = 1e-5  # ONNX default value

        for attr in node.attribute:
            if attr.name.lower() == "epsilon":
                assert (
                    attr.type == 1
                ), f"epsilon must have float dtype (1), but got {attr.type}."
                epsilon = attr.f
        input_ = self.get_activation_or_value(input_name)
        if len(input_.src_shape) == 2:
            raise NotImplementedError("instancenorm rank2")
        scale = self.get_value(scale_name)
        bias = self.get_value(bias_name)
        return super().make_instancenorm(
            input_, epsilon, scale, bias, opname=layer_name
        )

    def parse_layer_norm(self, node):
        assert (
            len(node.input) == 3
        ), f"Got unsupported number of inputs for Layer Normalization: {len(node.input)}."
        layer_name = node.output[0]
        input_name, scale_name, bias_name = node.input
        axis = -1  # ONNX default value
        epsilon = 1e-5  # ONNX default value
        stash_type = 1  # ONNX default value

        for attr in node.attribute:
            if attr.name.lower() == "axis":
                axis = get_attr_value(attr)
            elif attr.name.lower() == "epsilon":
                epsilon = get_attr_value(attr)
            elif attr.name.lower() == "stash_type":
                stash_type = get_attr_value(attr)

        if stash_type != 1:
            raise NotImplementedError(f"Unsupported stash_type: {stash_type}.")
        input = self.get_activation_or_value(input_name)
        scale = self.get_value(scale_name)
        bias = self.get_value(bias_name)
        axis = axis if axis >= 0 else axis + input.src_dim
        reduce_axes = list(range(axis, len(input.src_shape)))
        return super().make_layernorm(
            input,
            [input.src_shape[a] for a in reduce_axes],
            epsilon,
            scale,
            bias=bias,
            opname=layer_name,
        )

    def parse_scatterND(self, node):
        """
        Such function exists in MobilintSubGraphBuilder class.
        Implemetation with additional features
            - All inputs can either be activationspec, or values
        """
        assert (
            len(node.input) == 3
        ), f"Got unsupported number of inputs for scatterND: {len(node.input)}."
        layer_name = node.output[0]
        data_name, indices_name, updates_name = node.input

        reduction = "None"
        for attr in node.attribute:
            if attr.name.lower() == "reduction":
                reduction = str(attr.s)[2:-1]

        data = self.get_activation_or_value(data_name, const_ok=True)
        indices = self.get_activation_or_value(indices_name, const_ok=True)
        updates = self.get_activation_or_value(updates_name, const_ok=True)
        if isinstance(data, numpy.ndarray) and isinstance(updates, numpy.ndarray):
            raise NotImplementedError

        input_list = []
        constant_data = -1
        constant_indices = -1
        if isinstance(data, ActivationSpec):
            input_list.append(self.get_activation_index(data))
            output_src_shape = data.src_shape
        else:
            constant_data = self.add_weight(data_name, data)
            output_src_shape = data.shape
        if isinstance(indices, ActivationSpec):
            input_list.append(self.get_activation_index(indices))
        else:
            constant_indices = self.add_weight(indices_name, indices)
        if isinstance(updates, ActivationSpec):
            input_list.append(self.get_activation_index(updates))
        else:
            constant_data = self.add_weight(updates_name, updates)

        outact = self.activationspec(layer_name, str(data.dtype), output_src_shape)
        op = Operator(
            layer_name,
            options=options.ScatterNDOptions(
                inputs=tuple(input_list),
                outputs=(self.get_activation_index(outact),),
                constant_data=constant_data,
                constant_indices=constant_indices,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    def parse_NMS(self, node):
        """
        No such function in MobilintSubGraphBuilder class

        input_box : (B, spatial_dimension, 4)
                  default - [ymin, xmin, ymax, xmax]
                  center  - [x_center, y_center, width, height]
                  Q. y = height, x = width?
        input_scores : (B, Num_CLasses, spatial_dimension)
        """
        layer_name = node.output[0]
        input_boxes = node.input[0]
        input_scores = node.input[1]

        max_output_boxes_per_class = 0
        iou_threshold = 0
        score_threshold = None
        center_point_box = 0

        if len(node.input) >= 3:
            max_output_boxes_per_class = self.get_value(node.input[2])
        if len(node.input) >= 4:
            iou_threshold = self.get_value(node.input[3])
        if len(node.input) >= 5:
            score_threshold = self.get_value(node.input[4])

        for attr in node.attribute:
            if attr.name.lower() == "center_point_box":
                center_point_box = int(attr.i)
        boxes = self.get_activation_or_value(input_boxes)
        scores = self.get_activation_or_value(input_scores)
        nms_shape = [
            DimValue(shape) if shape != 0 else DimValue(1, dynamic=True)
            for shape in self.value_dict[layer_name].shape
        ]
        outact = self.activationspec(layer_name, "int64", src_shape=nms_shape)
        op = Operator(
            name=outact.name,
            options=options.NonMaxSuppressionOptions(
                inputs=(
                    self.get_activation_index(boxes),
                    self.get_activation_index(scores),
                ),
                outputs=(self.get_activation_index(outact),),
                max_output_size=max_output_boxes_per_class,
                iou_threshold=iou_threshold,
                score_threshold=score_threshold,
                soft_nms_sigma=0,
                pad_to_max_output_size=False,
                center_point_box=center_point_box,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    def parse_range(self, node):
        layer_name = node.output[0]

        input_name_list = list(node.input)
        assert (
            len(input_name_list) == 3
        ), "Range expects 3 inputs: start, end(limit), delta"

        roles = ["start", "limit", "delta"]

        act_inputs = []
        act_input_idx = []

        opt = {"start": -1, "limit": -1, "delta": -1}

        for role, inname in zip(roles, input_name_list):
            temp = self.get_activation_or_value(inname, const_ok=True)

            if self.is_act_value_type(temp):
                act_inputs.append(temp)
                act_input_idx.append(self.get_activation_index(temp))
            else:
                wname = f"{layer_name}_{role}"
                opt[role] = self.add_weight(wname, temp)

        if not act_inputs:
            raise NotImplementedError(
                "All-constant Range is not supported by this builder path."
            )

        outact = self.copy_activationspec(
            act_inputs[0],
            layer_name,
            src_shape=(DimValue(1, dynamic=True),),
            dataformat=DataFormat.UNKNOWN,
        )

        op = Operator(
            name=outact.name,
            options=options.RangeOptions(
                inputs=tuple(act_input_idx),
                outputs=(self.get_activation_index(outact),),
                start=opt["start"],
                limit=opt["limit"],
                delta=opt["delta"],
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    def parse_mod(self, node):
        """
        Such function exists in MobilintSubGraphBuilder class
        Implementation to support `fmod` attribute in ONNX mod operator
        """
        layer_name = node.output[0]
        left_name = node.input[0]
        right_name = node.input[1]
        fmod = 0  # default value

        for attr in node.attribute:
            if attr.name == "fmod":
                fmod = get_attr_value(attr)

        left = self.get_activation_or_value(left_name, const_ok=True)
        right = self.get_activation_or_value(right_name, const_ok=True)
        outact = self.copy_activationspec(left, layer_name)
        if self.is_act_value_type(left) and self.is_act_value_type(right):
            op = Operator(
                name=outact.name,
                options=options.ModV2Options(
                    inputs=(
                        self.get_activation_index(left),
                        self.get_activation_index(right),
                    ),
                    outputs=(self.get_activation_index(outact),),
                    fmod=fmod,
                ),
            )
        elif self.is_act_value_type(left):
            op = Operator(
                name=outact.name,
                options=options.ModOptions(
                    inputs=(self.get_activation_index(left),),
                    outputs=(self.get_activation_index(outact),),
                    is_const_first=False,
                    constant=self.add_weight(right_name, right),
                    fmod=fmod,
                ),
            )
        elif self.is_act_value_type(right):
            op = Operator(
                name=outact.name,
                options=options.ModOptions(
                    inputs=(self.get_activation_index(right),),
                    outputs=(self.get_activation_index(outact),),
                    is_const_first=True,
                    constant=self.add_weight(left_name, left),
                    fmod=fmod,
                ),
            )
        else:
            raise NotImplementedError

        self.add_operator(op)
        outact.producer_op = op

    def parse_topk(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        layer_name_1, layer_name_2 = node.output
        input_name, const_name = node.input
        axis, largest, sorted = -1, 1, 1  # default value

        for attr in node.attribute:
            if attr.name == "axis":
                axis = get_attr_value(attr)
            elif attr.name == "largest":
                largest = get_attr_value(attr)
            elif attr.name == "sorted":
                sorted = get_attr_value(attr)
        input = self.get_activation_or_value(input_name)
        const = self.get_value(const_name)
        value = self.copy_activationspec(
            input, layer_name_1, src_shape=self.value_dict[layer_name_1].shape
        )
        indices = self.copy_activationspec(
            input, layer_name_2, "int64", src_shape=self.value_dict[layer_name_2].shape
        )

        op1 = Operator(
            name=value.name,
            options=options.TopKValuesOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(value),),
                constant=const,
                axis=axis,
                largest=largest,
                sorted=sorted,
            ),
        )
        op2 = Operator(
            name=value.name,
            options=options.TopKIndicesOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(indices),),
                constant=const,
                axis=axis,
                largest=largest,
                sorted=sorted,
            ),
        )
        self.add_operator(op1)
        self.add_operator(op2)
        value.producer_op = op1
        indices.producer_op = op2

    def parse_gather(self, node):
        """
        Such function exists in MobilintSubGraphBuilder class
        Implementation to support ONNX input types (numpy.ndarray)
        """
        layer_name = node.output[0]
        input_name = node.input[0]
        indices_name = node.input[1]
        axis = 0  # default value

        for attr in node.attribute:
            if attr.name == "axis":
                axis = get_attr_value(attr)

        input = self.get_activation_or_value(input_name, const_ok=True)
        if indices_name in self._weights:
            indices = self._weights[indices_name]
        else:
            indices = self.get_activation_or_value(indices_name, const_ok=True)
        if not isinstance(indices, ActivationSpec):
            idx = self.add_weight(indices_name, indices)
            out_dtype = (
                str(input.dtype) if isinstance(input, numpy.ndarray) else input.dtype
            )
            shape = [
                DimValue(shape) if shape != 0 else DimValue(1, dynamic=True)
                for shape in self.value_dict[layer_name].shape
            ]
            outact = self.activationspec(layer_name, out_dtype, tuple(shape))
            op = Operator(
                name=outact.name,
                options=options.GatherConstantOptions(
                    inputs=(self.get_activation_index(input),),
                    outputs=(self.get_activation_index(outact),),
                    axis=axis,
                    constant=idx,
                    is_const_first=False,
                ),
            )
            self.add_operator(op)
        else:
            outact = super().make_gather(input, indices, axis, opname=layer_name)

    def parse_gatherelements(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        layer_name = node.output[0]
        input_name = node.input[0]
        indices_name = node.input[1]
        axis = 0  # default value

        for attr in node.attribute:
            if attr.name == "axis":
                axis = get_attr_value(attr)

        input = self.get_activation_or_value(input_name)
        indices = self.get_activation_or_value(indices_name)
        outact = self.copy_activationspec(
            input, layer_name, src_shape=indices.src_shape
        )
        op = Operator(
            name=layer_name,
            options=options.GatherElementsOptions(
                inputs=(
                    self.get_activation_index(input),
                    self.get_activation_index(indices),
                ),
                outputs=(self.get_activation_index(outact),),
                axis=axis,
            ),
        )
        self.add_operator(op)

    def parse_gathernd(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        layer_name = node.output[0]
        input_name = node.input[0]
        indices_name = node.input[1]
        batch_dims = 0  # default value

        for attr in node.attribute:
            if attr.name == "batch_dims":
                batch_dims = get_attr_value(attr)

        input = self.get_activation_or_value(input_name)
        indices = self.get_activation_or_value(indices_name)
        if len(input.src_shape) - batch_dims == indices.src_shape[-1]:
            output_src_shape = [indices.src_shape[:-1]]
        elif len(input.src_shape) - batch_dims > indices.src_shape[-1]:
            output_src_shape = [
                indices.src_shape[:-1],
                input.src_shape[
                    len(input.src_shape) - batch_dims - indices.src_shape[-1]
                ],
            ]
        outact = self.copy_activationspec(
            input, layer_name, src_shape=tuple(output_src_shape)
        )
        op = Operator(
            name=layer_name,
            options=options.GatherNDOptions(
                inputs=(
                    self.get_activation_index(input),
                    self.get_activation_index(indices),
                ),
                outputs=(self.get_activation_index(outact),),
                batch_dims=batch_dims,
            ),
        )
        self.add_operator(op)

    def parse_matmul(self, node):
        """
        Such function exists in MobilintSubGraphBuilder class
        Implementation to support arbitrary shape 'left' input
        """
        layer_name = node.output[0]
        left_name = node.input[0]
        right_name = node.input[1]
        left = self.get_activation_or_value(left_name)
        right = self.get_activation_or_value(right_name)

        if (
            left.get_act_src_shape()[-1] == right.get_act_src_shape()[0]
            and right.src_dim == 1
        ):
            mm_out_shape = left.get_act_src_shape()[:-1]
        elif left.get_act_src_shape()[-1] == right.get_act_src_shape()[-2]:
            mm_out_shape = left.get_act_src_shape()[:-1] + (
                right.get_act_src_shape()[-1],
            )
        else:
            raise NotImplementedError

        dtype = left.dtype if isinstance(left, ActivationSpec) else right.dtype
        outact = self.activationspec(layer_name, dtype, mm_out_shape)
        op = Operator(
            outact.name,
            options=options.MatMulOptions(
                inputs=(
                    self.get_activation_index(left),
                    self.get_activation_index(right),
                ),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    def parse_expand(self, node):
        """
        Such function exists in MobilintSubGraphBuilder class
        Implementation to support inputs where ndim(shape) != ndim(input)
        """
        layer_name = node.output[0]
        input_name = node.input[0]
        shape_name = node.input[1]
        input = self.get_activation_or_value(input_name)
        shape = self.get_value(shape_name)
        len_diff = len(shape) - input.src_dim
        temp_shape = []
        for i, c in enumerate(shape):
            if i - len_diff < 0:
                temp_shape.append(c)
            else:
                s = input.get_act_src_shape()[i - len_diff]
                if c == -1:
                    temp_shape.append(s)
                else:
                    if s != c and c != 1:
                        temp_shape.append(c)
                    else:
                        temp_shape.append(s)
        shape = numpy.array(temp_shape).astype(int)
        outact = self.activationspec(
            name=layer_name, src_shape=tuple(shape), dtype=input.dtype
        )
        op = Operator(
            name=layer_name,
            options=options.ExpandOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                is_const_first=False,
                constant=self.add_weight(outact.name + ".const", shape),
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    def parse_identity(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)

        super().make_identity(input, opname=layer_name)

    def parse_not(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)

        super().make_not(input, opname=layer_name)

    def parse_neg(self, node):
        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)

        super().make_neg(input, opname=layer_name)

    def parse_where(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        layer_name = node.output[0]
        cond_name = node.input[0]
        input_name_1 = node.input[1]
        input_name_2 = node.input[2]
        cond = self.get_activation_or_value(cond_name, const_ok=True)
        input_1 = self.get_activation_or_value(input_name_1, const_ok=True)
        input_2 = self.get_activation_or_value(input_name_2, const_ok=True)
        condition_const = -1
        X_const = -1
        Y_const = -1
        input_list = []
        output_src_shape = None
        output_dtype = None

        shapes = []

        if isinstance(cond, ActivationSpec):
            input_list.append(self.get_activation_index(cond))
            shapes.append(cond.src_shape)
        else:
            condition_const = self.add_weight(cond_name, cond)
            shapes.append(condition_const.shape)
        if isinstance(input_1, ActivationSpec):
            input_list.append(self.get_activation_index(input_1))
            shapes.append(input_1.src_shape)
            # output_src_shape = input_1.src_shape
            output_dtype = input_1.dtype
        else:
            self.add_weight(input_name_1, input_1)
            shapes.append(input_1.shape)
            # output_src_shape = tuple(input_1.shape)
            output_dtype = str(input_1.dtype)
        if isinstance(input_2, ActivationSpec):
            input_list.append(self.get_activation_index(input_2))
            shapes.append(input_2.src_shape)
        else:
            Y_const = self.add_weight(input_name_2, input_2)
            shapes.append(Y_const.shape)
        output_src_shape = numpy.broadcast_shapes(*shapes)
        outact = self.activationspec(layer_name, output_dtype, output_src_shape)
        op = Operator(
            name=outact.name,
            options=options.WhereOptions(
                inputs=tuple(input_list),
                outputs=(self.get_activation_index(outact),),
                condition_const=condition_const,
                X_const=X_const,
                Y_const=Y_const,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

    def parse_gridsample(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        layer_name = node.output[0]
        left_name = node.input[0]
        right_name = node.input[1]
        align_corners = 0
        mode = "linear"
        padding_mode = "zeros"
        for attr in node.attribute:
            if attr.name == "align_corners":
                align_corners = get_attr_value(attr)
            elif attr.name == "mode":
                mode = get_attr_value(attr)
            elif attr.name == "padding_mode":
                padding_mode = get_attr_value(attr)
        left = self.get_activation_or_value(left_name, const_ok=True)
        right = self.get_activation_or_value(right_name, const_ok=True)
        outact = self.get_activation_or_value(layer_name, const_ok=True)
        if isinstance(outact, numpy.ndarray):
            outact = self.activationspec(layer_name, str(outact.dtype), outact.shape)
        elif isinstance(outact, ActivationSpec):
            pass
        else:
            raise NotImplementedError

        base_op = Operator(
            name=outact.name,
            options=options.GridSampleOptions(
                inputs=(
                    self.get_activation_index(left),
                    self.get_activation_index(right),
                ),
                outputs=(self.get_activation_index(outact),),
                align_corners=align_corners,
                mode=mode,
                padding_mode=padding_mode,
                is_const_first=False,
            ),
        )
        if self.is_act_value_type(left) and self.is_act_value_type(right):
            op = base_op
        elif self.is_act_value_type(left):
            op = base_op
            op.options.inputs = (self.get_activation_index(left),)
            op.options.constant = self.add_weight(right_name, right)
        elif self.is_act_value_type(right):
            op = base_op
            op.options.inputs = (self.get_activation_index(right),)
            op.options.is_const_first = True
            op.options.constant = self.add_weight(left_name, left)
        self.add_operator(op)
        outact.producer_op = outact

    def parse_rnn(self, node):
        # Between 3 and 6 inputs.
        X, W, R = node.input[:3]
        B = node.input[3] if len(node.input) > 3 else ""
        sequence_lens = node.input[4] if len(node.input) > 4 else ""
        initial_h = node.input[5] if len(node.input) > 5 else ""

        input_mask = "i"
        inputs = [X]
        if sequence_lens:
            inputs.append(sequence_lens)
            input_mask += "s"
        if initial_h:
            inputs.append(initial_h)
            input_mask += "h"

        layer_name = node.output[0]
        hidden_out = node.output[1] if len(node.output) > 1 else ""

        hidden_size = None
        direction = "forward"  # forward, backward, bidirectional
        layout = 0
        for attr in node.attribute:
            if attr.name == "hidden_size":
                hidden_size = get_attr_value(attr)
            elif attr.name == "direction":
                direction = get_attr_value(attr)
            elif attr.name == "layout":
                layout = get_attr_value(attr)

        num_direction = 2 if direction == "bidirectional" else 1
        inputs = [self.get_activation_or_value(idx) for idx in inputs]
        output_src_shape = (
            [inputs[0].src_shape[0]] + [num_direction] + list(inputs[1].src_shape[1:])
        )
        outact = self.activationspec(
            layer_name, inputs[0].dtype, tuple(output_src_shape)
        )
        op = Operator(
            name=outact.name,
            options=options.RNNOptions(
                inputs=tuple([self.get_activation_index(idx) for idx in inputs]),
                outputs=(self.get_activation_index(outact),),
                W=self.add_weight(W, self.get_value(W)),
                R=self.add_weight(R, self.get_value(R)),
                rnn_group=layer_name,
                input_mask=input_mask,
                output_mask="o",
                hidden_size=hidden_size,
                B=self.add_weight(B, self.get_value(B)) if B else -1,
                direction=direction,
                batch_first=bool(layout),
            ),
        )
        self.add_operator(op)
        outact.producer_op = op
        if hidden_out:
            hiddenact = self.activationspec(
                hidden_out, inputs[0].dtype, tuple(output_src_shape[1:])
            )
            hidden_op = copy.deepcopy(op)
            hidden_op.name = hiddenact.name
            hidden_op.options.outputs = (self.get_activation_index(hiddenact),)
            hidden_op.options.output_mask = "h"
            self.add_operator(hidden_op)
            hiddenact.producer_op = hidden_op

    def parse_gru(self, node):
        # Between 3 and 6 inputs.
        X, W, R = node.input[:3]
        B = node.input[3] if len(node.input) > 3 else ""
        sequence_lens = node.input[4] if len(node.input) > 4 else ""
        initial_h = node.input[5] if len(node.input) > 5 else ""

        input_mask = "i"
        inputs = [X]
        if sequence_lens:
            inputs.append(sequence_lens)
            input_mask += "s"
        if initial_h:
            inputs.append(initial_h)
            input_mask += "h"

        layer_name = node.output[0]
        hidden_out = node.output[1] if len(node.output) > 1 else ""

        hidden_size = None
        direction = "forward"
        layout = 0
        linear_before_reset = 0
        for attr in node.attribute:
            if attr.name == "hidden_size":
                hidden_size = get_attr_value(attr)
            elif attr.name == "direction":
                direction = get_attr_value(attr)
            elif attr.name == "layout":
                layout = get_attr_value(attr)
            elif attr.name == "linear_before_reset":
                linear_before_reset = get_attr_value(attr)

        num_direction = 2 if direction == "bidirectional" else 1
        inputs = [self.get_activation_or_value(idx) for idx in inputs]
        output_src_shape = (
            [inputs[0].src_shape[0]] + [num_direction] + list(inputs[1].src_shape[1:])
        )
        outact = self.activationspec(
            layer_name, inputs[0].dtype, tuple(output_src_shape)
        )
        op = Operator(
            name=outact.name,
            options=options.GRUOptions(
                inputs=tuple([self.get_activation_index(idx) for idx in inputs]),
                outputs=(self.get_activation_index(outact),),
                W=self.add_weight(W, self.get_value(W)),
                R=self.add_weight(R, self.get_value(R)),
                gru_group=layer_name,
                input_mask=input_mask,
                output_mask="o",
                hidden_size=hidden_size,
                B=self.add_weight(B, self.get_value(B)) if B else -1,
                direction=direction,
                batch_first=bool(layout),
                linear_before_reset=bool(linear_before_reset),
            ),
        )
        self.add_operator(op)
        outact.producer_op = op
        if hidden_out:
            hiddenact = self.activationspec(
                hidden_out, inputs[0].dtype, tuple(output_src_shape[1:])
            )
            hidden_op = copy.deepcopy(op)
            hidden_op.name = hiddenact.name
            hidden_op.options.outputs = (self.get_activation_index(hiddenact),)
            hidden_op.options.output_mask = "h"
            self.add_operator(hidden_op)
            hiddenact.producer_op = hidden_op

    def parse_lstm(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        X, W, R = node.input[:3]
        B = node.input[3] if len(node.input) > 3 else ""
        sequence_lens = node.input[4] if len(node.input) > 4 else ""
        initial_h = node.input[5] if len(node.input) > 5 else ""
        initial_c = node.input[6] if len(node.input) > 6 else ""
        P = node.input[7] if len(node.input) > 7 else ""

        input_mask = "i"
        inputs = [X]
        if sequence_lens:
            inputs.append(sequence_lens)
            input_mask += "s"
        if initial_h:
            inputs.append(initial_h)
            input_mask += "h"
        if initial_c:
            inputs.append(initial_c)
            input_mask += "c"

        layer_name = node.output[0]
        hidden_out = node.output[1] if len(node.output) > 1 else ""
        cell_out = node.output[2] if len(node.output) > 2 else ""

        # default setting
        hidden_size = None
        direction = "forward"  # forward, backward, bidirectional
        layout = 0
        for attr in node.attribute:
            if attr.name == "hidden_size":
                hidden_size = get_attr_value(attr)
            elif attr.name == "direction":
                direction = get_attr_value(attr)
            elif attr.name == "layout":
                layout = get_attr_value(attr)

        num_direction = 2 if direction == "bidirectional" else 1
        inputs = [self.get_activation_or_value(idx) for idx in inputs]
        output_src_shape = (
            [inputs[0].src_shape[0]] + [num_direction] + list(inputs[1].src_shape[1:])
        )
        outact = self.activationspec(
            layer_name, inputs[0].dtype, tuple(output_src_shape)
        )
        op = Operator(
            name=outact.name,
            options=options.LSTMOptions(
                inputs=tuple([self.get_activation_index(idx) for idx in inputs]),
                outputs=(self.get_activation_index(outact),),
                W=self.add_weight(W, self.get_value(W)),
                R=self.add_weight(R, self.get_value(R)),
                lstm_group=layer_name,
                input_mask=input_mask,
                output_mask="o",
                hidden_size=hidden_size,
                B=self.add_weight(B, self.get_value(B)) if B else -1,
                P=self.add_weight(P, self.get_value(P)) if P else -1,
                direction=direction,
                batch_first=bool(layout),
            ),
        )
        self.add_operator(op)
        outact.producer_op = op
        if hidden_out:
            hiddenact = self.activationspec(
                hidden_out, inputs[0].dtype, tuple(output_src_shape[1:])
            )
            hidden_op = copy.deepcopy(op)
            hidden_op.name = hiddenact.name
            hidden_op.options.outputs = (self.get_activation_index(hiddenact),)
            hidden_op.options.output_mask = "h"
            self.add_operator(hidden_op)
            hiddenact.producer_op = hidden_op
        if cell_out:
            cellact = self.activationspec(
                cell_out, inputs[0].dtype, tuple(output_src_shape[1:])
            )
            cell_op = copy.deepcopy(op)
            cell_op.name = cellact.name
            cell_op.options.outputs = (self.get_activation_index(cellact),)
            cell_op.options.output_mask = "c"
            self.add_operator(cell_op)
            cellact.producer_op = cell_op

    def parse_simple(self, node):
        """
        One input only node, no attributes, and where
        such functions are not implemented in MobilintSubGraphBuilder class
        """
        if node.attribute:
            raise ValueError(f"Error. {node.op_type} layer should not have attribute.")

        layer_name = node.output[0]
        input_name = node.input[0]
        input = self.get_activation_or_value(input_name)
        outact = self.copy_activationspec(input, layer_name)
        op = Operator(
            name=layer_name,
            options=OPTIONSMAPPER[node.op_type.lower()](
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)

    def parse_simple_2(self, node):
        """
        Two input only node, no attributes
        """
        if node.attribute:
            raise ValueError(f"Error. {node.op_type} layer should not have attribute.")

        comparison = {
            "Less": self.make_less,
            "Equal": self.parse_equal,
            "Greater": self.make_greater,
        }
        math = ["Add", "Sub", "Mul", "Div"]
        if node.op_type in comparison:
            self.parse_biop(node, comparison[node.op_type])
        elif node.op_type in math:
            self.parse_biop_math(node, self._make_biop)
        else:
            self.parse_biop(node, OPTIONSMAPPER[node.op_type.lower()])

    def parse_equal(self, left: ActivationSpec, right: ActivationSpec, opname=""):
        """
        Such function exists in MobilintSubGraphBuilder class
        Implementation to support arbitrary 'right' input
        """
        if not opname:
            opname = left.name + "/equal"
        if self.is_act_value_type(left) and not self.is_act_value_type(right):
            outact = self.copy_activationspec(left, name=opname, dtype="bool")
            constant = self.add_weight(opname + ".right", right)
            kw = {
                "inputs": (self.get_activation_index(left),),
                "outputs": (self.get_activation_index(outact),),
                "constant": constant,
                "is_const_first": False,
            }
        else:
            raise NotImplementedError
        op = Operator(name=outact.name, options=options.EqualOptions(**kw))
        self.add_operator(op)
        return outact

    def parse_default(self, node):
        """
        No such function in MobilintSubGraphBuilder class
        """
        layer_name = node.output[0]
        input_list = list(node.input)
        layer_type = OPTIONSMAPPER[node.op_type.lower()]
        if node.op_type.lower() == "if":
            raise ValueError("We do not parse graphs that contain 'if' node")

        try:
            input_list = [self.get_activation_or_value(idx) for idx in input_list]
            outact = self.copy_activationspec(input_list[0], layer_name)
            op = Operator(
                name=outact.name,
                options=layer_type(
                    inputs=tuple(
                        [self.get_activation_index(idx) for idx in input_list]
                    ),
                    outputs=(self.get_activation_index(outact),),
                ),
            )
            self.add_operator(op)
            outact.producer_op = op
        except:
            raise NotImplementedError(f"{node.op_type} layer not implemented")

    def parse_node(self, node):
        op_type = node.op_type
        if op_type == "Constant":
            self.parse_constant(node)
        elif op_type == "Shape":
            self.parse_shape(node)
        elif op_type == "ConstantOfShape":
            self.parse_constantofshape(node)
        elif op_type == "Cast":
            self.parse_cast(node)
        elif op_type == "Pad":
            self.parse_pad(node)
        elif op_type == "Conv":
            self.parse_conv(node)
        elif op_type == "ConvTranspose":
            self.parse_tconv(node)
        elif op_type == "Gemm":
            self.parse_gemm(node)
        elif op_type in [
            "QuantizeLinear",
            "DequantizeLinear",
        ]:  # quantize and dequantize linear layer are parsed once
            self.parse_qlinear(node)
        elif op_type == "BatchNormalization":
            self.parse_batchnorm(node)
        elif op_type == "MaxPool":
            self.parse_maxpool(node)
        elif op_type == "AveragePool":
            self.parse_avgpool(node)
        elif op_type in [
            "ReduceMin",
            "ReduceMax",
            "ReduceMean",
            "ReduceSum",
            "ReduceProd",
            "ReduceL2",
        ]:
            self.parse_reduce(node)
        elif op_type == "Resize":
            self.parse_resize(node)
        elif op_type == "Einsum":
            self.parse_einsum(node)
        elif op_type == "Upsample":
            self.parse_upsample(node)
        elif op_type == "Concat":
            self.parse_concatenate(node)
        elif op_type == "LeakyRelu":
            self.parse_leakyrelu(node)
        elif op_type == "Mish":
            self.parse_mish(node)
        elif op_type == "Swish":
            self.parse_swish(node)
        elif op_type == "Gelu":
            self.parse_gelu(node)
        elif op_type == "Celu":
            self.parse_celu(node)
        elif op_type == "Selu":
            self.parse_selu(node)
        elif op_type == "Elu":
            self.parse_elu(node)
        elif op_type == "PRelu":
            self.parse_prelu(node)
        elif op_type == "Softmax":
            self.parse_softmax(node)
        elif op_type == "HardSigmoid":
            self.parse_hardsigmoid(node)
        elif op_type == "Clip":
            self.parse_clip(node)
        elif op_type == "Max":
            self.parse_max(node)
        elif op_type == "Min":
            self.parse_min(node)
        elif op_type == "Pow":
            self.parse_pow(node)
        elif op_type == "Slice":
            self.parse_slice(node)
        elif op_type == "DepthToSpace":
            self.parse_depth_to_space(node)
        elif op_type == "Reshape":
            self.parse_reshape(node)
        elif op_type == "Transpose":
            self.parse_transpose(node)
        elif op_type == "Squeeze":
            self.parse_squeeze(node)
        elif op_type == "Unsqueeze":
            self.parse_unsqueeze(node)
        elif op_type == "Flatten":
            self.parse_flatten(node)
        elif op_type == "ArgMax":
            self.parse_argmax(node)
        elif op_type == "Loop":
            self.parse_loop(node)
        elif op_type == "Tile":
            self.parse_tile(node)
        elif op_type == "Split":
            self.parse_split(node)
        elif op_type == "InstanceNormalization":
            self.parse_instance_norm(node)
        elif op_type == "GroupQueryAttention":
            self.parse_group_query_attention(node)
        elif op_type == "SimplifiedLayerNormalization":
            self.parse_simplifiedLayerNormalization(node)
        elif op_type == "SkipSimplifiedLayerNormalization":
            self.parse_skipsimplifiedlayernormalization(node)
        elif op_type == "LayerNormalization":
            self.parse_layer_norm(node)
        elif op_type == "ScatterND":
            self.parse_scatterND(node)
        elif op_type == "NonMaxSuppression":
            self.parse_NMS(node)
        elif op_type == "Range":
            self.parse_range(node)
        elif op_type == "Mod":
            self.parse_mod(node)
        elif op_type == "TopK":
            self.parse_topk(node)
        elif op_type == "Gather":
            self.parse_gather(node)
        elif op_type == "GatherElements":
            self.parse_gatherelements(node)
        elif op_type == "GatherND":
            self.parse_gathernd(node)
        elif op_type == "LSTM":
            self.parse_lstm(node)
        elif op_type == "RNN":
            self.parse_rnn(node)
        elif op_type == "GRU":
            self.parse_gru(node)
        elif op_type == "GridSample":
            self.parse_gridsample(node)
        elif op_type == "GlobalAveragePool":
            self.parse_global_avgpool(node)
        elif op_type == "MatMul":
            self.parse_matmul(node)
        elif op_type == "Expand":
            self.parse_expand(node)
        elif op_type == "Identity":
            self.parse_identity(node)
        elif op_type == "Not":
            self.parse_not(node)
        elif op_type == "Where":
            self.parse_where(node)
        elif op_type == "Neg":
            self.parse_neg(node)
        elif op_type in [
            "Relu",
            "Sigmoid",
            "HardSwish",
            "Exp",
            "Tanh",
        ]:
            self.parse_act_func(node)
        elif op_type in [
            "Softplus",
            "Sqrt",
            "Reciprocal",
            "Floor",
            "Ceil",
            "NonZero",
            "Erf",
        ]:
            self.parse_simple(node)
        elif op_type in [
            "Add",
            "Sub",
            "Mul",
            "Div",
            "And",
            "Or",
            "Xor",
            "Less",
            "Equal",
            "Greater",
        ]:
            self.parse_simple_2(node)
        else:
            logger.debug(
                f"Warnning. There is an unknown layer {node.output[0]}. Optype = {op_type}."
            )
            self.parse_default(node)
