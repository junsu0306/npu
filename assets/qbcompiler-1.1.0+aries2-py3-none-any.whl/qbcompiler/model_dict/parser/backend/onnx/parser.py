from collections import OrderedDict
from typing import List, Dict, Any

import numpy

import qbcompiler.model_dict.common.model_dict as schema
from qbcompiler.model_dict.common.parserabc import (
    ParserABC,
    MobilintParserInputs,
    MobilintParserOutputs,
)
from .subgraph_builder import ONNXSubGraphBuilder


class OnnxParser(ParserABC):
    def __init__(
        self,
        path_to_model: str,
        temp_dir: str,
        large_model=False,
        seed: int = 12345,
        model=None,  # not used, only for get parser function
    ):
        super().__init__(path_to_model, backend="onnx", seed=seed)
        self._large_model = large_model
        self._temp_dir = temp_dir
        self.path_to_model = path_to_model

    def parse(
        self, parser_inputs: MobilintParserInputs, **kwargs
    ) -> MobilintParserOutputs:
        in_shapes = parser_inputs.in_shapes
        feed_dict = parser_inputs.feed_dict
        in_dformats = parser_inputs.in_dformats
        dynamic_axes = parser_inputs.dynamic_axes
        large_value_dict_path = (
            parser_inputs.large_value_dict_path
        )  # value_dict only for large onnx model

        const_dict = {}
        builder = ONNXSubGraphBuilder(
            self.path_to_model,
            feed_dict=feed_dict,
            dynamic_axes=dynamic_axes,
            large_model=self._large_model,
            temp_dir=self._temp_dir,
            value_dict_path=large_value_dict_path,
            global_weight_dict=const_dict,
        )
        sg = builder.build()
        md = schema.ModelDict()
        md.subgraphs = [sg]
        md.set_main_sg(0)

        value_dict = builder.value_dict

        onnx_output = MobilintParserOutputs()
        onnx_output.model_dict = md
        onnx_output.const_dict = const_dict
        onnx_output.value_dict = value_dict

        return onnx_output
