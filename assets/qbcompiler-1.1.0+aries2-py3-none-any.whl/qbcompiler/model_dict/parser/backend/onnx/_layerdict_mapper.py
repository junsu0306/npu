import copy
import dataclasses
import math
from collections import deque
from typing import Dict, Any, Tuple, List

import numpy
import numbers

from qbcompiler.model_dict.common import (
    Registry,
    LayerOptions,
    TensorIndex,
    options,
    LayerType,
)
from qbcompiler.model_dict.common.dataformat import (
    DATAFORMAT_LIST,
    validate_src_shape_dformat,
    DataFormat,
)
from qbcompiler.model_dict.common.value_wrapper import ValueWrapper

from qbcompiler.logging import get_logger

logger = get_logger(__name__)


def get_BCNdim_input_shape(input_layer_info, in_channel=None):
    try:
        input_shape = input_layer_info["output_shape"]
        input_height, input_width, input_channel = input_shape
    except:
        src_shape = input_layer_info["src_shape"]
        if len(src_shape) == 4:
            if src_shape[1] == in_channel:
                batch, input_channel, input_height, input_width = src_shape
            elif src_shape[3] == in_channel:
                batch, input_height, input_width, input_channel = src_shape
            else:
                batch, input_channel, input_height, input_width = src_shape
        elif len(src_shape) == 3:
            if in_channel is not None:
                if src_shape[1] == in_channel:
                    input_height, input_channel, input_width = src_shape
                elif src_shape[2] == in_channel:
                    input_height, input_width, input_channel = src_shape
                elif src_shape[0] == in_channel:  # is used?
                    input_channel, input_height, input_width = src_shape
                else:
                    print(f"src_shape = {src_shape} in_channel = {in_channel}")
                    raise ValueError("in_channel is not matched with any axis")
            else:
                if src_shape[0] == 1:
                    batch, input_channel, input_height = src_shape
                    input_width = 1
                else:
                    input_height, input_channel, input_width = src_shape
        elif len(src_shape) == 2:
            batch, input_channel = src_shape
            input_height = 1
            input_width = 1
        else:
            raise ValueError("src dimension is too high. input dim = ", len(src_shape))
    input_shape = [int(input_height), int(input_width), int(input_channel)]
    return input_shape


def get_const_value(attr_name, const_dict):
    if isinstance(attr_name, numpy.ndarray):
        return attr_name
    elif isinstance(attr_name, str):
        if attr_name in const_dict:
            v = const_dict[attr_name]["value"]
            if isinstance(v, ValueWrapper):
                v = v.value
            return v
        else:
            return None
    else:
        return attr_name


def in_const_dict(key, const_dict: dict):
    try:
        if key in const_dict:
            return True
        else:
            return False
    except:
        return False


def get_generated_name(layer_dict, const_dict):
    all_name = set(list(layer_dict.keys()) + list(const_dict.keys()))
    i = 0
    while True:
        name = f"gen_{i}"
        if name not in all_name:
            return name
        else:
            i += 1


def tconv_weight_conversion(weight):
    shape = weight.shape
    weight_copy = copy.deepcopy(weight.value)
    for i in range(shape[2]):
        for j in range(shape[3]):
            weight_copy[:, :, i, j] = weight.value[
                :, :, shape[2] - 1 - i, shape[3] - 1 - j
            ]
    return ValueWrapper(numpy.transpose(weight_copy, axes=(1, 0, 2, 3)))


def post_conv(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    input_name = layer_info["inputs"][0]
    d_h = layer_info["h_dilation"]
    d_w = layer_info["w_dilation"]
    s_h = layer_info["h_stride"]
    s_w = layer_info["w_stride"]
    padding_list = layer_info["padding_list"]
    input_src_shape = layer_dict[input_name]["src_shape"]
    weight_name = layer_info["weight"]
    weight = const_dict[weight_name]["value"]
    group_number = layer_info["group_number"]
    auto_pad = layer_info["auto_pad"]

    out_ch, in_ch, k_h, k_w = weight.shape
    _, in_channels, in_height, in_width = input_src_shape

    assert in_ch * group_number == in_channels, "input channel parsing Error for conv"

    kernel_height = (k_h - 1) * d_h + 1
    kernel_width = (k_w - 1) * d_w + 1
    p_n, p_w, p_s, p_e = padding_list

    if auto_pad == "NOTSET":
        residual_h = (in_height + p_n + p_s - kernel_height) % s_h
        residual_w = (in_width + p_w + p_e - kernel_width) % s_w
        p_s = p_s - residual_h if residual_h < p_s else 0
        p_e = p_e - residual_w if residual_w < p_e else 0

        output_height = (in_height + p_n + p_s - kernel_height) / s_h + 1
        # noinspection PyPep8
        output_width = (in_width + p_w + p_e - kernel_width) / s_w + 1
    elif auto_pad == "SAME_UPPER":
        output_height = math.ceil(in_height / s_h)
        output_width = math.ceil(in_width / s_w)

        pad_height = output_height * s_h - in_height + kernel_height - s_h
        pad_width = output_width * s_w - in_width + kernel_width - s_w

        p_n = pad_height // 2
        p_s = pad_height - p_n
        p_w = pad_width // 2
        p_e = pad_width - p_w
    elif auto_pad == "SAME_LOWER":
        output_height = math.ceil(in_height / s_h)
        output_width = math.ceil(in_width / s_w)

        pad_height = output_height * s_h - in_height + kernel_height - s_h
        pad_width = output_width * s_w - in_width + kernel_width - s_w

        p_s = pad_height // 2
        p_n = pad_height - p_s
        p_e = pad_width // 2
        p_w = pad_width - p_e
    elif auto_pad == "VALID":
        p_w, p_n, p_e, p_s = 0, 0, 0, 0
        residual_h = (in_height + p_n + p_s - kernel_height) % s_h
        residual_w = (in_width + p_w + p_e - kernel_width) % s_w
        p_s = p_s - residual_h if residual_h < p_s else 0
        p_e = p_e - residual_w if residual_w < p_e else 0

        output_height = (in_height + p_n + p_s - kernel_height) / s_h + 1
        # noinspection PyPep8
        output_width = (in_width + p_w + p_e - kernel_width) / s_w + 1
    else:
        raise ValueError("unknown auto pad attr, ", auto_pad)

    in_ch = in_ch * group_number

    if group_number == 1:
        layer_info["type"] = LayerType.Convolution
    elif group_number == out_ch and group_number == in_ch:
        layer_info["type"] = LayerType.DepthwiseConvolution
    else:
        layer_info["type"] = LayerType.GroupConvolution

    layer_info["in_channels"] = in_ch
    layer_info["out_channels"] = out_ch
    layer_info["west_padding"] = p_w
    layer_info["east_padding"] = p_e
    # NPU's padding north/south is inverted.
    layer_info["north_padding"] = p_s
    layer_info["south_padding"] = p_n
    layer_info["padding_list"] = (0, 0, p_n, p_w, 0, 0, p_s, p_e)

    layer_info["shape"] = (int(output_height), int(output_width), int(out_ch))
    layer_info["dataformat"] = DataFormat.NCHW


def post_conv3d(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    input_name = layer_info["inputs"][0]
    padding_list = layer_info["padding_list"]
    weight_name = layer_info["weight"]
    weight = const_dict[weight_name]["value"]

    out_ch, in_ch, k_h, k_w, k_d = weight.shape
    p_f, p_n, p_w, p_b, p_s, p_e = padding_list

    layer_info["in_channels"] = in_ch
    layer_info["out_channels"] = out_ch
    layer_info["west_padding"] = p_w
    layer_info["east_padding"] = p_e
    # Unsupported convolution case. therefore, north/south padding are not inverted.
    layer_info["north_padding"] = p_n
    layer_info["south_padding"] = p_s
    layer_info["front_padding"] = p_f
    layer_info["back_padding"] = p_b
    layer_info["padding_list"] = (0, 0, p_f, p_n, p_w, 0, 0, p_b, p_s, p_e)


def post_conv1d(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    input_name = layer_info["inputs"][0]
    dilation = layer_info["dilation"]
    s_w = layer_info["stride"]
    padding_list = layer_info["padding_list"]
    input_src_shape = layer_dict[input_name]["src_shape"]
    weight_name = layer_info["weight"]
    weight = const_dict[weight_name]["value"]
    group_number = layer_info["group_number"]
    auto_pad = layer_info["auto_pad"]

    out_ch, in_ch, k_w = weight.shape
    _, in_channels, in_width = input_src_shape

    assert in_ch * group_number == in_channels, "input channel parsing Error for conv"

    kernel_width = (k_w - 1) * dilation + 1
    p_w, p_e = padding_list

    if auto_pad == "NOTSET":
        residual_w = (in_width + p_w + p_e - kernel_width) % s_w
        p_e = p_e - residual_w if residual_w < p_e else 0

        # noinspection PyPep8
        output_width = (in_width + p_w + p_e - kernel_width) / s_w + 1
    elif auto_pad == "SAME_UPPER":
        output_width = math.ceil(in_width / s_w)

        pad_width = output_width * s_w - in_width + kernel_width - s_w
        p_w = pad_width // 2
        p_e = pad_width - p_w
    elif auto_pad == "SAME_LOWER":
        output_width = math.ceil(in_width / s_w)

        pad_width = output_width * s_w - in_width + kernel_width - s_w
        p_e = pad_width // 2
        p_w = pad_width - p_e
    elif auto_pad == "VALID":
        p_w, p_e = 0, 0
        residual_w = (in_width + p_w + p_e - kernel_width) % s_w
        p_e = p_e - residual_w if residual_w < p_e else 0

        # noinspection PyPep8
        output_width = (in_width + p_w + p_e - kernel_width) / s_w + 1
    else:
        raise ValueError("unknown auto pad attr, ", auto_pad)

    layer_info["in_channels"] = in_ch
    layer_info["out_channels"] = out_ch
    layer_info["west_padding"] = p_w
    layer_info["east_padding"] = p_e
    layer_info["padding_list"] = (0, 0, p_w, 0, 0, p_e)

    layer_info["shape"] = (1, int(output_width), int(out_ch))  # no height
    layer_info["dataformat"] = DataFormat.NCX


def post_tconv(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    input_name = layer_info["inputs"][0]
    d_h = layer_info["h_dilation"]
    d_w = layer_info["w_dilation"]
    auto_pad = layer_info["auto_pad"]
    padding_list = layer_info["padding_list"]
    out_pad_list = layer_info["out_pad_list"]
    group_number = layer_info["group_number"]
    weight_name = layer_info["weight"]
    weight = const_dict[weight_name]["value"]
    s_h = layer_info["h_stride"]
    s_w = layer_info["w_stride"]

    in_ch, out_ch, k_h, k_w = weight.shape
    input_height, input_width, in_channels = get_BCNdim_input_shape(
        layer_dict[input_name], in_ch * group_number
    )

    assert in_ch * group_number == in_channels, "input channel parsing Error for tconv"

    kernel_height = (k_h - 1) * d_h + 1
    kernel_width = (k_w - 1) * d_w + 1
    p_n, p_w, p_s, p_e = padding_list
    out_pad_e, out_pad_s = out_pad_list

    # ToDo: auto_pad 적용
    output_height = s_h * (input_height - 1) + out_pad_s + kernel_height - p_s - p_n
    output_width = s_w * (input_width - 1) + out_pad_e + kernel_width - p_w - p_e

    base_p_w = kernel_width - 1
    base_p_e = kernel_width - 1
    base_p_n = kernel_height - 1
    base_p_s = kernel_height - 1

    npu_p_w = base_p_w - p_w
    npu_p_e = base_p_e - p_e + out_pad_e
    npu_p_n = base_p_n - p_n
    npu_p_s = base_p_s - p_s + out_pad_s

    const_dict[weight_name]["value"] = tconv_weight_conversion(weight)

    layer_info["in_channels"] = in_ch
    layer_info["out_channels"] = out_ch

    layer_info["west_padding"] = npu_p_w
    layer_info["east_padding"] = npu_p_e
    # NPU's padding north/south is inverted.
    layer_info["north_padding"] = npu_p_s
    layer_info["south_padding"] = npu_p_n
    layer_info["padding_list"] = (0, 0, npu_p_n, npu_p_w, 0, 0, npu_p_s, npu_p_e)

    layer_info["shape"] = (int(output_height), int(output_width), int(out_ch))
    layer_info["dataformat"] = DataFormat.NCHW


def post_maxpool(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    input_name = layer_info["inputs"][0]
    d_h = layer_info["h_dilation"]
    d_w = layer_info["w_dilation"]
    k_h = layer_info["h_kernel"]
    k_w = layer_info["w_kernel"]
    s_h = layer_info["h_stride"]
    s_w = layer_info["w_stride"]
    padding_list = layer_info["padding_list"]
    input_src_shape = layer_dict[input_name]["src_shape"]
    src_shape = layer_info["src_shape"]

    auto_pad = layer_info["auto_pad"]
    ceil_mode = layer_info["is_ceil_mode"]
    storage_order = layer_info.get("storage_order")
    if storage_order:
        raise NotImplementedError(
            f"maxpool with storage_order {storage_order} is not implemented yet."
        )

    kernel_height = (k_h - 1) * d_h + 1
    kernel_width = (k_w - 1) * d_w + 1
    pad_mode = "-inf"
    batch, in_channels, in_height, in_width = input_src_shape
    p_n, p_w, p_s, p_e = padding_list

    if auto_pad == "SAME_UPPER" or auto_pad == "SAME_LOWER":
        output_height = math.ceil(in_height / s_h)
        output_width = math.ceil(in_width / s_w)

        pad_height = (output_height - 1) * s_h + kernel_height - in_height
        pad_width = (output_width - 1) * s_w + kernel_width - in_width

        if auto_pad == "SAME_LOWER":
            p_s = pad_height // 2
            p_n = pad_height - p_s
            p_e = pad_width // 2
            p_w = pad_width - p_e
        else:
            p_n = pad_height // 2
            p_s = pad_height - p_n
            p_w = pad_width // 2
            p_e = pad_width - p_w

    elif auto_pad == "NOTSET" or auto_pad == "VALID":
        if auto_pad == "VALID":
            p_n = 0
            p_s = 0
            p_e = 0
            p_w = 0

        if ceil_mode:
            output_height = math.ceil(
                (in_height + (p_n + p_s) - kernel_height) / s_h + 1
            )
            output_width = math.ceil((in_width + (p_e + p_w) - kernel_width) / s_w + 1)
        else:
            output_height = math.floor(
                (in_height + (p_n + p_s) - kernel_height) / s_h + 1
            )
            output_width = math.floor((in_width + (p_e + p_w) - kernel_width) / s_w + 1)

        pad_height = max((output_height - 1) * s_h + kernel_height - in_height, 0)
        pad_width = max((output_width - 1) * s_w + kernel_width - in_width, 0)

        p_e = pad_width - p_w
        p_s = pad_height - p_n

    else:
        raise ValueError("for maxpool, unknown auto pad attr, ", auto_pad)

    out_channels = in_channels

    layer_info["type"] = LayerType.Pooling
    layer_info["pool_type"] = "MaxPool"
    layer_info["pad_mode"] = pad_mode
    layer_info["west_padding"] = p_w
    layer_info["east_padding"] = p_e
    # NPU's padding north/south is inverted.

    layer_info["north_padding"] = p_s
    layer_info["south_padding"] = p_n
    layer_info["padding_list"] = (0, 0, p_n, p_w, 0, 0, p_s, p_e)

    layer_info["shape"] = (int(output_height), int(output_width), int(out_channels))
    layer_info["dataformat"] = DataFormat.NCHW


def post_maxpool1d(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    input_name = layer_info["inputs"][0]
    dilation = layer_info["dilation"]
    kernel = layer_info["kernel"]
    stride = layer_info["stride"]
    padding_list = layer_info["padding_list"]
    input_src_shape = layer_dict[input_name]["src_shape"]

    auto_pad = layer_info["auto_pad"]
    ceil_mode = layer_info["is_ceil_mode"]

    kernel_width = (kernel - 1) * dilation + 1
    pad_mode = "-inf"
    batch, in_channels, in_width = input_src_shape
    p_w, p_e = padding_list

    if auto_pad == "SAME_UPPER" or auto_pad == "SAME_LOWER":
        output_width = math.ceil(in_width / stride)

        pad_width = (output_width - 1) * stride + kernel_width - in_width

        if auto_pad == "SAME_LOWER":
            p_e = pad_width // 2
            p_w = pad_width - p_e
        else:
            p_w = pad_width // 2
            p_e = pad_width - p_w

    elif auto_pad == "NOTSET" or auto_pad == "VALID":
        if auto_pad == "VALID":
            p_e = 0
            p_w = 0

        if ceil_mode:
            output_width = math.ceil(
                (in_width + (p_e + p_w) - kernel_width) / stride + 1
            )
        else:
            output_width = math.floor(
                (in_width + (p_e + p_w) - kernel_width) / stride + 1
            )

        pad_width = max((output_width - 1) * stride + kernel_width - in_width, 0)

        p_e = pad_width - p_w
    else:
        raise ValueError("for maxpool, unknown auto pad attr, ", auto_pad)

    layer_info["type"] = LayerType.Pooling1d
    layer_info["pool_type"] = "MaxPool"
    layer_info["pad_mode"] = pad_mode
    layer_info["west_padding"] = p_w
    layer_info["east_padding"] = p_e
    layer_info["padding_list"] = (0, 0, p_w, 0, 0, p_e)
    layer_info["dataformat"] = DataFormat.NCX


def post_avgpool(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    input_name = layer_info["inputs"][0]
    k_h = layer_info["h_kernel"]
    k_w = layer_info["w_kernel"]
    s_h = layer_info["h_stride"]
    s_w = layer_info["w_stride"]
    input_src_shape = layer_dict[input_name]["src_shape"]
    batch, input_channels, input_height, input_width = input_src_shape

    auto_pad = layer_info["auto_pad"]
    padding_list = layer_info["padding_list"]
    ceil_mode = layer_info["is_ceil_mode"]
    count_include_pad = layer_info["count_include_pad"]
    p_n, p_w, p_s, p_e = padding_list

    kernel_height = k_h
    kernel_width = k_w

    if auto_pad == "SAME_UPPER" or auto_pad == "SAME_LOWER":
        output_height = math.ceil(input_height / s_h)
        output_width = math.ceil(input_width / s_w)

        pad_height = (output_height - 1) * s_h + kernel_height - input_height
        pad_width = (output_width - 1) * s_w + kernel_width - input_width

        if auto_pad == "SAME_LOWER":
            p_s = pad_height // 2
            p_n = pad_height - p_s
            p_e = pad_width // 2
            p_w = pad_width - p_e
        else:
            p_n = pad_height // 2
            p_s = pad_height - p_n
            p_w = pad_width // 2
            p_e = pad_width - p_w

    elif auto_pad == "NOTSET" or auto_pad == "VALID":
        if auto_pad == "VALID":
            p_n = 0
            p_s = 0
            p_e = 0
            p_w = 0

        if ceil_mode:
            output_height = math.ceil(
                (input_height + (p_n + p_s) - kernel_height) / s_h + 1
            )
            output_width = math.ceil(
                (input_width + (p_e + p_w) - kernel_width) / s_w + 1
            )
        else:
            output_height = math.floor(
                (input_height + (p_n + p_s) - kernel_height) / s_h + 1
            )
            output_width = math.floor(
                (input_width + (p_e + p_w) - kernel_width) / s_w + 1
            )

        pad_height = max((output_height - 1) * s_h + kernel_height - input_height, 0)
        pad_width = max((output_width - 1) * s_w + kernel_width - input_width, 0)

        p_e = pad_width - p_w
        p_s = pad_height - p_n

    else:
        raise ValueError("unknown auto pad attr, ", auto_pad)

    new_pad_list = (0, 0, p_n, p_w, 0, 0, p_s, p_e)
    out_channels = input_channels

    layer_info["west_padding"] = p_w
    layer_info["east_padding"] = p_e
    # NPU's padding north/south is inverted.
    layer_info["north_padding"] = p_s
    layer_info["south_padding"] = p_n
    layer_info["padding_list"] = new_pad_list

    layer_info["pool_type"] = "AvgPool"
    layer_info["pad_mode"] = "constant"
    layer_info["is_include_pad"] = count_include_pad
    layer_info["type"] = LayerType.Pooling

    layer_info["shape"] = (int(output_height), int(output_width), int(out_channels))
    layer_info["dataformat"] = DataFormat.NCHW


def post_avgpool1d(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    input_name = layer_info["inputs"][0]
    kernel = layer_info["kernel"]
    stride = layer_info["stride"]
    input_src_shape = layer_dict[input_name]["src_shape"]
    batch, input_channels, input_width = input_src_shape

    auto_pad = layer_info["auto_pad"]
    padding_list = layer_info["padding_list"]
    ceil_mode = layer_info["is_ceil_mode"]
    count_include_pad = layer_info["count_include_pad"]
    p_w, p_e = padding_list

    if auto_pad == "SAME_UPPER" or auto_pad == "SAME_LOWER":
        output_width = math.ceil(input_width / stride)
        pad_width = (output_width - 1) * stride + kernel - input_width

        if auto_pad == "SAME_LOWER":
            p_e = pad_width // 2
            p_w = pad_width - p_e
        else:
            p_w = pad_width // 2
            p_e = pad_width - p_w

    elif auto_pad == "NOTSET" or auto_pad == "VALID":
        if auto_pad == "VALID":
            p_e = 0
            p_w = 0

        if ceil_mode:
            output_width = math.ceil((input_width + (p_e + p_w) - kernel) / stride + 1)
        else:
            output_width = math.floor((input_width + (p_e + p_w) - kernel) / stride + 1)

        pad_width = max((output_width - 1) * stride + kernel - input_width, 0)

        p_e = pad_width - p_w
    else:
        raise ValueError("unknown auto pad attr, ", auto_pad)

    new_pad_list = (0, 0, p_w, 0, 0, p_e)
    layer_info["west_padding"] = p_w
    layer_info["east_padding"] = p_e
    layer_info["padding_list"] = new_pad_list

    layer_info["pool_type"] = "AvgPool"
    layer_info["pad_mode"] = "constant"
    layer_info["is_include_pad"] = count_include_pad
    layer_info["type"] = LayerType.Pooling1d
    layer_info["dataformat"] = DataFormat.NCX


def post_globalavgpool(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    input_name = layer_info["inputs"][0]
    input_src_shape = layer_dict[input_name]["src_shape"]
    _, c, k_h, k_w = input_src_shape  # input must be form of BCHW
    shape = [1, 1, c]

    layer_info["type"] = LayerType.Pooling
    layer_info["w_kernel"] = k_w
    layer_info["h_kernel"] = k_h
    layer_info["w_stride"] = 1
    layer_info["h_stride"] = 1
    layer_info["w_dilation"] = 1
    layer_info["h_dilation"] = 1
    layer_info["pad_mode"] = "constant"
    layer_info["west_padding"] = 0
    layer_info["east_padding"] = 0
    layer_info["north_padding"] = 0
    layer_info["south_padding"] = 0
    layer_info["pool_type"] = "AvgPool"
    layer_info["padding_list"] = ()

    layer_info["shape"] = shape
    layer_info["dataformat"] = DataFormat.NCHW  # data format doesn't change


def post_reduce_op(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    input_name = layer_info["inputs"][0]
    input_src_shape = layer_dict[input_name]["src_shape"]
    reduce_axes = layer_info.get("reduce_axes", None)
    if reduce_axes is None:
        layer_info["reduce_axes"] = tuple(range(len(input_src_shape)))


def post_pooling(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    pooling_type = layer_info["pool_type"].lower()
    if pooling_type == "avgpool":
        post_avgpool(layer_name, layer_dict, const_dict, model_info)
    elif pooling_type == "maxpool":
        post_maxpool(layer_name, layer_dict, const_dict, model_info)
    elif pooling_type == "globalaveragepool":
        post_globalavgpool(layer_name, layer_dict, const_dict, model_info)
    else:
        raise NotImplementedError(
            f"pooling type: {pooling_type} Not implemented pooling type"
        )


def post_pooling1d(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    pooling_type = layer_info["pool_type"].lower()
    if pooling_type == "avgpool":
        post_avgpool1d(layer_name, layer_dict, const_dict, model_info)
    elif pooling_type == "maxpool":
        post_maxpool1d(layer_name, layer_dict, const_dict, model_info)
    else:
        raise NotImplementedError(
            f"pooling type: {pooling_type} Not implemented pooling type"
        )


def post_pad(layer_name, layer_dict, const_dict, model_info):
    input_name = layer_dict[layer_name]["inputs"][0]
    layer_info = layer_dict[layer_name]
    pad_mode = layer_info["pad_mode"]
    pad = get_const_value(layer_info["pad"], const_dict)
    constant = get_const_value(layer_info["constant"], const_dict)
    if constant is None:
        constant = 0
    else:
        constant = float(constant)
    layer_info["original_pad_list"] = pad
    layer_info["padding_list"] = tuple(pad)
    layer_info["constant"] = constant
    layer_info["pad_mode"] = pad_mode

    is_generic = True
    if len(pad) == 8:
        if 0 == pad[0] == pad[1] == pad[4] == pad[5]:
            is_generic = False
            layer_info["north_padding"] = pad[2]
            layer_info["south_padding"] = pad[6]
            layer_info["west_padding"] = pad[3]
            layer_info["east_padding"] = pad[7]
    elif len(pad) == 10:
        if 0 == pad[0] == pad[1] == pad[5] == pad[6]:
            layer_info["type"] = LayerType.Pad3d
            layer_info["front_padding"] = pad[2]
            layer_info["north_padding"] = pad[3]
            layer_info["west_padding"] = pad[4]
            layer_info["back_padding"] = pad[7]
            layer_info["south_padding"] = pad[8]
            layer_info["east_padding"] = pad[9]
            is_generic = False
    if is_generic:
        layer_info["type"] = LayerType.PadGeneric

    # layer_info["padding_list"] = (0, 0, p_n, p_w, 0, 0, p_s, p_e)


def post_resize(layer_name, layer_dict, const_dict, model_info):
    input_name = layer_dict[layer_name]["inputs"][0]
    layer_info = layer_dict[layer_name]

    input_src_shape = layer_dict[input_name]["src_shape"]
    layer_src_shape = layer_info["src_shape"]
    scales_name = layer_info["scales"]
    sizes_name = layer_info["sizes"]
    resize_mode = layer_info["resize_mode"]

    # ONNX attributes
    roi_name = layer_info.get("roi")
    if roi_name is None:
        roi = None
    else:
        roi = get_const_value(roi_name, const_dict)

    nearest_mode = layer_info.get("nearest_mode", "round_prefer_floor")
    transform_mode = layer_info.get("transform_mode", "half_pixel")
    cubic_coeff_a = layer_info.get("cubic_coeff_a", 0.75)
    exclude_outside = layer_info.get("exclude_outside", 0)
    extrapolation_value = layer_info.get("extrapolation_value", 0.0)
    antialias = layer_info.get("antialias", 0)
    _axes = layer_info.get("axes")
    if _axes is None:
        axes = list(range(len(input_src_shape)))
    else:
        axes = _axes

    keep_aspect_ratio_policy = layer_info.get("keep_aspect_ratio_policy", "stretch")

    scales = get_const_value(scales_name, const_dict)
    sizes = get_const_value(sizes_name, const_dict)

    layer_info["resize_type"] = resize_mode
    layer_info["src_shape"] = layer_src_shape

    # Only for ONNX inference
    layer_info["antialias"] = antialias
    layer_info["axes"] = axes
    layer_info["transform_mode"] = transform_mode
    layer_info["cubic_coeff_a"] = cubic_coeff_a
    layer_info["exclude_outside"] = exclude_outside
    layer_info["extrapolation_value"] = extrapolation_value
    layer_info["keep_aspect_ratio_policy"] = keep_aspect_ratio_policy
    layer_info["nearest_mode"] = nearest_mode
    layer_info["roi"] = roi
    layer_info["scales"] = scales
    layer_info["sizes"] = sizes


def post_split(layer_name, layer_dict, const_dict, model_info):
    def check_axis(axis, ndim):
        if isinstance(axis, numpy.ndarray) and len(axis.shape) == 0:
            axis = int(axis)

        assert isinstance(axis, int) and axis < ndim and axis >= -ndim
        # Update negative axis
        if axis < 0:
            axis += ndim
        return axis

    def check_split(split, num_outputs, split_rank, model_info):
        assert (
            isinstance(num_outputs, int)
            and num_outputs > 0
            and isinstance(split_rank, int)
            and split_rank > 0
            and split_rank >= num_outputs
        )
        opset = model_info.get("opset", None)
        # If split is not provided, split is made from num_outputs
        if split is None:
            q, r = divmod(split_rank, num_outputs)
            assert isinstance(opset, int) and opset >= 1
            if opset >= 18 and r != 0:
                chunk_size = q + 1
                last_chunk_size = split_rank - chunk_size * (num_outputs - 1)
                if last_chunk_size <= 0:
                    raise ValueError(
                        f"Cannot split {split_rank} into {num_outputs}"
                        " chunks, last_chunk_size should be positive but "
                        f"got {last_chunk_size}"
                    )
            elif r == 0:  # any opset version
                chunk_size, last_chunk_size = q, q
            else:  # opset < 18 and r != 0
                raise ValueError(
                    f"Cannot evenly split {split_rank} into "
                    f"{num_outputs} chunks, opset = {opset}"
                )
            split = [chunk_size] * (num_outputs - 1) + [last_chunk_size]
        if isinstance(split, numpy.ndarray):
            split = list(split)
            split = [int(i) for i in split]

        assert (
            isinstance(split, list)
            and len(split) == num_outputs
            and all([isinstance(s, int) for s in split])
            and all([s >= 0 for s in split])
            and sum(split) == split_rank
        )
        return split

    input_name = layer_dict[layer_name]["inputs"][0]
    layer_info = layer_dict[layer_name]
    input_src_shape = layer_dict[input_name]["src_shape"]
    axis = layer_info["axis"]
    split = get_const_value(layer_info["split"], const_dict)
    num_outputs = layer_info["num_outputs"]
    split_rank = input_src_shape[axis]
    axis = check_axis(axis, len(input_src_shape))
    split = check_split(split, num_outputs, split_rank, model_info)

    layer_info["axis"] = axis
    layer_info["split"] = split


def post_layer_norm(layer_name, layer_dict, const_dict, model_info):
    input_name = layer_dict[layer_name]["inputs"][0]
    layer_info = layer_dict[layer_name]
    reduce_axes = layer_info["reduce_axes"]
    input_src_shape = layer_info["src_shape"]
    if reduce_axes < 0:
        reduce_axes += len(input_src_shape)
    reduce_axes = list(range(reduce_axes, len(input_src_shape)))
    normalized_shape = [input_src_shape[a] for a in reduce_axes]
    layer_info["normalized_shape"] = normalized_shape


def post_gather(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    input_name_0, input_name_1 = layer_info["inputs"]
    if input_name_0 in const_dict or input_name_1 in const_dict:
        layer_info["type"] = LayerType.GatherConstant
    post_simple_2(layer_name, layer_dict, const_dict, model_info)


def post_simple_2(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    input_name_0, input_name_1 = layer_info["inputs"]
    const_name = None
    if input_name_0 in const_dict:
        const_name = input_name_0
        input_name = input_name_1
    elif input_name_1 in const_dict:
        const_name = input_name_1
        input_name = input_name_0

    # one of the inputs is constant
    if const_name is not None:
        layer_info["is_const_first"] = const_name == input_name_0
        layer_info["constant"] = const_name
        layer_info["inputs"] = (input_name,)


def post_nms(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    layer_info["max_output_size"] = layer_info["max_output"]
    layer_info["iou_threshold"] = layer_info["iou_thres"]
    layer_info["score_threshold"] = layer_info["score_thres"]
    layer_info["soft_nms_sigma"] = 0  # should be checked
    layer_info["pad_to_max_output_size"] = False  # should be checked


def post_batchnorm(layer_name, layer_dict, const_dict, *args, **kwargs):
    layer_info = layer_dict[layer_name]
    eps_value = layer_info["epsilon"]
    eps_name = get_generated_name(layer_dict, const_dict)
    layer_info["epsilon"] = eps_name
    const_dict[eps_name] = {"type": "Constant", "value": numpy.array((eps_value,))}


def post_prelu(layer_name, layer_dict, const_dict, model_info):
    layer_info = layer_dict[layer_name]
    slope = const_dict[layer_info["slope"]]["value"].value
    if isinstance(slope, numpy.ndarray):
        slope = slope.astype(numpy.float32)
    elif isinstance(slope, numbers.Real):
        slope = float(slope)
    else:
        raise NotImplementedError
    layer_info["leaky_alpha"] = slope


def post_gemm(layer_name, layer_dict, const_dict, *args, **kwargs):
    layer_info = layer_dict[layer_name]
    if in_const_dict(layer_info["weight"], const_dict) and in_const_dict(
        layer_info["bias"], const_dict
    ):
        layer_info["type"] = LayerType.GemmConstant
        layer_info["constant"] = layer_info.pop("weight")


def post_default(layer_name, layer_dict, const_dict, *args, **kwargs):
    ...


ONNXPOSTFUNCMAPPER = {
    LayerType.Pooling: post_pooling,
    LayerType.Pooling1d: post_pooling1d,
    LayerType.And: post_simple_2,
    LayerType.Batchnorm: post_batchnorm,
    LayerType.Convolution: post_conv,
    LayerType.Convolution1d: post_conv1d,
    LayerType.Convolution3d: post_conv3d,
    LayerType.ReduceL2: post_reduce_op,
    LayerType.ReduceMax: post_reduce_op,
    LayerType.ReduceMean: post_reduce_op,
    LayerType.ReduceMin: post_reduce_op,
    LayerType.ReduceSum: post_reduce_op,
    LayerType.DepthwiseConvolution: post_conv,
    LayerType.Equal: post_simple_2,
    LayerType.Expand: post_simple_2,
    LayerType.Gather: post_gather,
    LayerType.GatherND: post_simple_2,
    LayerType.Gemm: post_gemm,
    LayerType.Greater: post_simple_2,
    LayerType.LayerNormalization: post_layer_norm,
    LayerType.Less: post_simple_2,
    LayerType.Mod: post_simple_2,
    LayerType.NonMaxSuppression: post_nms,
    LayerType.Or: post_simple_2,
    LayerType.Pad: post_pad,
    LayerType.PRelu: post_prelu,
    LayerType.Split: post_split,
    LayerType.TopKValues: post_simple_2,
    LayerType.TopKIndices: post_simple_2,
    LayerType.TransposeConvolution: post_tconv,
    LayerType.Xor: post_simple_2,
    LayerType.Resize: post_resize,
    "empty": post_default,
}


def get_post_func(layer_info: Dict[str, Any]):
    layertype = layer_info.get("type", "empty")
    return ONNXPOSTFUNCMAPPER.get(layertype, post_default)


def _get_field_info(layertype: LayerOptions) -> Dict[str, Any]:
    field_info = {}
    for field in dataclasses.fields(layertype):
        field_info[field.name] = {}
        if hasattr(field.type, "__origin__"):
            # ex) in the case of tuple class input, tuple
            field_info[field.name]["type"] = field.type.__origin__
            # ex) field_dtype nummpy.int32, ... -> Ellipsis class
            field_info[field.name]["dtype"] = field.type.__args__
        else:
            field_info[field.name]["type"] = None
            field_info[field.name]["dtype"] = field.type
    return field_info


def get_src_shape_dict(layer_dict: Dict[str, Any]) -> Dict[str, Tuple[int, ...]]:
    src_shape_dict = {}
    for layer_name, info in layer_dict.items():
        src_shape_dict[layer_name] = info.get("src_shape", tuple())

    return src_shape_dict


def inputs_mapper(layer_name, layer_info: Dict[str, Any]):
    if layer_info["type"] == LayerType.Input:
        layer_info["inputs"] = (layer_name,)
        # layer_info["inputs"] = (layer_name + "_input",)
    elif {"input0", "input1"}.issubset(layer_info):
        layer_info["inputs"] = (layer_info["input0"], layer_info["input1"])
        del layer_info["input0"], layer_info["input1"]
    elif isinstance(layer_info.get("input", None), list):
        layer_info["inputs"] = tuple(layer_info["input"])
        del layer_info["input"]
    elif isinstance(layer_info.get("input", None), str):
        layer_info["inputs"] = (layer_info["input"],)
        del layer_info["input"]
    else:
        raise NotImplementedError


def outputs_mapper(layer_info: Dict[str, Any]):
    if isinstance(layer_info["output"], list):
        layer_info["outputs"] = tuple(layer_info["output"])
        del layer_info["output"]
    else:
        raise NotImplementedError


def inoutmapper(layer_dict: Dict[str, Any]):
    for layer_name, info in layer_dict.items():
        inputs_mapper(layer_name, info)
        outputs_mapper(info)


def dformat_check(name, layer_info, layer_dict, visit, forward_queue):
    inputs = layer_info["inputs"]
    layer_inputs = [name for name in inputs if name not in visit and name in layer_dict]
    if not layer_inputs:
        visit.append(name)
        return True
    else:
        forward_queue.appendleft(layer_inputs[0])
        forward_queue.append(name)
        return False


def get_in_out_list(layer_dict: Dict[str, Any]):
    inputs = set()
    outputs = set()
    for name, layer_info in layer_dict.items():
        inputs.update(set(layer_info["inputs"]))
        outputs.update((layer_info["outputs"]))
        if outputs == ():
            outputs.update(name)

    output_list = [
        layer_name for layer_name in list(outputs - inputs) if layer_name in layer_dict
    ]
    input_list = [
        layer_name for layer_name in list(inputs - outputs) if layer_name in layer_dict
    ]

    return input_list, output_list


def set_dtype_shape(
    layer_dict: Dict[str, Any], const_dict: dict, in_dataformat: Dict[str, str]
):
    # Forward
    input_list, _ = get_in_out_list(layer_dict)
    if in_dataformat is not None:
        if set(in_dataformat.keys()) != set(input_list):
            logger.info(
                f"in_dataformat and model input name are not matched, input names: {input_list}, dformats: {in_dataformat}"
            )
        for in_name in input_list:
            if in_name in in_dataformat:
                if in_dataformat[in_name] not in DATAFORMAT_LIST:
                    raise ValueError
                validate_src_shape_dformat(
                    layer_dict[in_name]["src_shape"], DataFormat[in_dataformat[in_name]]
                )
                layer_dict[in_name]["dataformat"] = DataFormat[in_dataformat[in_name]]
    else:
        layer_type = set([layer_info["type"] for layer_info in layer_dict.values()])
        supported_type = {
            LayerType.Convolution,
            LayerType.DepthwiseConvolution,
            LayerType.GroupConvolution,
            LayerType.Pooling,
        }
        for input_name in input_list:
            if (
                len(layer_dict[input_name]["src_shape"]) == 3
                and (supported_type & layer_type) == set()
            ):
                layer_dict[input_name]["dataformat"] = DataFormat.UNKNOWN
                print(
                    f"dataformat of {input_name} is automatically set to HWC, but you can manually change the dataformat using in_dformats if needed"
                )


def layer_dict_post(
    layer_dict: Dict[str, Any], const_dict: Dict[str, Any], _model_info: Dict[str, str]
):
    for layer_name, layer_info in layer_dict.items():
        post_func = get_post_func(layer_info)
        post_func(layer_name, layer_dict, const_dict, _model_info)
        for key, value in layer_info.items():
            if isinstance(value, str) and not value:
                layer_info[key] = None


def add_output_layer_list(
    layer_dict: Dict[str, Any], value_dict: Dict[str, Any], const_dict, src_output_list
):
    # _, output_list = get_in_out_list(layer_dict)
    src_output_list = [output for output in src_output_list if output not in const_dict]
    for out_name in src_output_list:
        output_layer_name = out_name + "_layer"
        info = {
            "type": LayerType.Output,
            "inputs": (out_name,),
            "outputs": (out_name,),
            "is_output": True,
            "src_shape": layer_dict[out_name]["src_shape"],
            "dataformat": layer_dict[out_name].get("dataformat", DataFormat.UNKNOWN),
        }

        layer_dict[output_layer_name] = info
        value_dict[output_layer_name] = value_dict[out_name]


def in_const_dict(item, const_dict):
    try:
        return item in const_dict
    except Exception as e:
        return False


def _find_tensor_idx_key(layeroption: LayerOptions) -> List[str]:
    fields_info = _get_field_info(layeroption)
    tensor_idx_keys = []
    for field_key, info in fields_info.items():
        if info["dtype"] == TensorIndex:
            tensor_idx_keys.append(field_key)

    return tensor_idx_keys


class PostOnnxMapper:
    def __init__(self):
        self._ori_layer_dict = None
        self._source_shape = None
        #
        self.tensor_names = []
        self.name_to_idx = {}
        #
        self._tensor_idx = 0
        self._name_idx = 0
        self._debug_idx = 0
        self._gen_idx = 0

    def next_name_idx(self):
        idx = self._name_idx
        self._name_idx += 1
        return idx

    def next_gen_idx(self):
        idx = self._gen_idx
        self._gen_idx += 1
        return idx

    def next_tensor_index(self) -> TensorIndex:
        idx = TensorIndex(self._tensor_idx)
        self._tensor_idx += 1
        return idx

    def map(
        self, legacy_onnx_dict, in_dformats: Dict[str, str]
    ) -> Dict[str, LayerOptions]:
        layer_dict: Dict[str, Any] = legacy_onnx_dict.layer_dict
        const_dict: Dict[str, Any] = legacy_onnx_dict.const_dict
        value_dict: Dict[str, Any] = legacy_onnx_dict.sample_value_dict
        model_info: Dict[str, str] = legacy_onnx_dict.model_info

        self._ori_layer_dict = copy.deepcopy(layer_dict)
        self._source_shape = get_src_shape_dict(layer_dict)
        inoutmapper(layer_dict)
        set_dtype_shape(layer_dict, const_dict, in_dformats)
        layer_dict_post(layer_dict, const_dict, model_info)
        add_output_layer_list(
            layer_dict, value_dict, const_dict, legacy_onnx_dict.src_output_list
        )
        _option_dict = {k: {} for k in layer_dict.keys()}

        for layer_name, info in layer_dict.items():
            class_type = Registry.getcls(info["type"])
            _option_dict[layer_name]["type"] = class_type
            _fields_info = _get_field_info(class_type)
            str_fields = [
                fd.name
                for fd in dataclasses.fields(class_type)
                if fd.type.__name__ == "str"
            ]

            for _field_name, _fields_info in _fields_info.items():
                if _field_name in info:
                    if (
                        _field_name not in str_fields
                        and _fields_info["dtype"] is not TensorIndex
                        and in_const_dict(info.get(_field_name, None), const_dict)
                    ):
                        _option_dict[layer_name][_field_name] = get_const_value(
                            info[_field_name], const_dict
                        )
                    else:
                        _option_dict[layer_name][_field_name] = info[_field_name]

        return self._get_onnx_options(_option_dict, const_dict)

    def _inout_name_to_idx(
        self, layer_name: str, layer_info: dict, class_type: "LayerOptions", const_dict
    ):
        input_idx = []
        for input_name in layer_info["inputs"]:
            if class_type in (options.InputOptions, options.OutputOptions):
                if not input_name in self.name_to_idx:
                    self.name_to_idx[input_name] = self.next_name_idx()
                else:
                    pass
                self.name_to_idx[layer_name] = self.name_to_idx[input_name]
                layer_info["outputs"] = (self.name_to_idx[layer_name],)
            elif not input_name in self.name_to_idx:
                self.name_to_idx[input_name] = self.next_name_idx()
            elif input_name in self.name_to_idx and input_name in const_dict:
                old_name = input_name
                input_name = f"{input_name}_M{self.next_gen_idx()}"
                self.name_to_idx[input_name] = self.next_name_idx()
                const_dict[input_name] = const_dict[old_name]
            else:
                pass
            input_idx.append(self.name_to_idx[input_name])
        layer_info["inputs"] = tuple(input_idx)

        if not layer_name in self.name_to_idx:
            self.name_to_idx[layer_name] = self.next_name_idx()
        layer_info["outputs"] = (self.name_to_idx[layer_name],)

    def _get_onnx_options(
        self, option_dict: Dict[str, Any], const_dict
    ) -> Dict[str, LayerOptions]:
        onnx_options = {}
        try:
            for layer_name, layer_info in option_dict.items():
                class_type = layer_info.pop("type")
                input_names = layer_info["inputs"]

                self._inout_name_to_idx(layer_name, layer_info, class_type, const_dict)
                tensor_idx_keys = _find_tensor_idx_key(class_type)

                for input_name in input_names:
                    if (
                        in_const_dict(input_name, const_dict)
                        and input_name not in self.tensor_names
                        and "constant" in tensor_idx_keys
                    ):
                        self.tensor_names.append(input_name)
                        layer_info["constant"] = self.next_tensor_index()
                # when one of the input is used as a "constant" Tensoridx

                for option_key in tensor_idx_keys:
                    if option_key not in layer_info:
                        continue

                    if (
                        isinstance(layer_info[option_key], TensorIndex)
                        and layer_info[option_key] >= 0
                    ):
                        continue

                    const_key = layer_info[option_key]
                    if const_key is None or (
                        isinstance(const_key, str) and const_key not in const_dict
                    ):
                        del layer_info[option_key]
                        continue

                    if (
                        in_const_dict(layer_info[option_key], const_dict)
                        and layer_info[option_key] in self.tensor_names
                    ):
                        old_name = layer_info[option_key]
                        const_name = f"{old_name}_M{self.next_gen_idx()}"
                        self.tensor_names.append(const_name)
                        const_dict[const_name] = const_dict[old_name]
                        layer_info[option_key] = self.next_tensor_index()
                        continue

                    if not isinstance(layer_info[option_key], str):
                        const_name = f"{layer_name}_{option_key}_M{self.next_gen_idx()}"
                        const_dict[const_name] = {
                            "type": "Const",
                            "value": numpy.array(layer_info[option_key]),
                            "op": "Constant",
                        }
                        self.tensor_names.append(const_name)
                        layer_info[option_key] = self.next_tensor_index()
                    else:
                        self.tensor_names.append(layer_info[option_key])
                        layer_info[option_key] = self.next_tensor_index()
                dct = {}
                for k, v in layer_info.items():
                    if v is None:
                        continue
                    if isinstance(v, ValueWrapper):
                        v = v.value
                    dct[k] = v
                onnx_options[layer_name] = class_type(**dct)
        except Exception as e:
            print(
                f"error while mapping layer to options. layer_name={layer_name}, dct={dct}"
            )
            raise e

        return onnx_options

    def ori_layer_dict(self):
        return self._ori_layer_dict

    def source_shape(self):
        return self._source_shape
