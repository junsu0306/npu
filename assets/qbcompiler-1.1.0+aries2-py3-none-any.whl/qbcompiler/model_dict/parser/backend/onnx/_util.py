"""
# this module redirect onnx built-in utils
"""

import abc
import copy
import os
import pathlib
from typing import Dict

import numpy
import onnx
from onnx import external_data_helper, numpy_helper, helper
from onnx.external_data_helper import ExternalDataInfo
from onnx.helper import tensor_dtype_to_string

from qbcompiler.model_dict.common.value_wrapper import ValueProviderABC


def get_all_tensors(onnx_model):
    yield from external_data_helper._get_all_tensors(onnx_model)


def get_attr_value(attr):
    if not isinstance(attr, onnx.AttributeProto):
        raise ValueError(f"Error. {attr} is not ONNX node attribute.")

    if attr.type == onnx.AttributeProto.INT:
        return attr.i
    elif attr.type == onnx.AttributeProto.INTS:
        return list(attr.ints)
    elif attr.type == onnx.AttributeProto.FLOAT:
        return attr.f
    elif attr.type == onnx.AttributeProto.FLOATS:
        return list(attr.floats)
    elif attr.type == onnx.AttributeProto.STRING:
        return attr.s.decode("utf-8")
    elif attr.type == onnx.AttributeProto.TENSOR:
        return numpy_helper.to_array(attr.t)
    else:
        raise ValueError(
            f"Error. The type of attribute {attr.name} is not supported yet."
        )


def read_external_data_for_tensor(tensor: onnx.TensorProto, base_dir: str) -> None:
    info = external_data_helper.ExternalDataInfo(tensor)
    external_data_file_path = external_data_helper.c_checker._resolve_external_data_location(  # type: ignore[attr-defined]
        base_dir, info.location, tensor.name
    )
    with open(external_data_file_path, "rb") as data_file:
        if info.offset:
            data_file.seek(info.offset)

        if info.length:
            return data_file.read(info.length)
        else:
            return data_file.read()


def is_bfloat16_tensor(tensor: onnx.TensorProto | onnx.ValueInfoProto):
    return tensor.data_type == onnx.TensorProto.BFLOAT16


def is_bfloat16_value(value: onnx.ValueInfoProto):
    return value.type.tensor_type.elem_type == onnx.TensorProto.BFLOAT16


def is_complex128_value(value: onnx.ValueInfoProto):
    return value.type.tensor_type.elem_type == onnx.TensorProto.COMPLEX128


def get_onnx_data_type(data_type_idx):
    if data_type_idx == 0:  # unknown
        return "float32"
    typename = tensor_dtype_to_string(data_type_idx)
    dt = typename.split(".")[1].lower()
    if dt == "float":
        return "float32"
    return dt


def make_bfloat16_value_info(value: onnx.ValueInfoProto):
    return helper.make_tensor_value_info(
        name=value.name,
        elem_type=onnx.TensorProto.FLOAT,
        shape=[
            x.dim_param if x.dim_param else x.dim_value
            for x in value.type.tensor_type.shape.dim
        ],
    )


def make_bfloat16_tensor(tensor: onnx.TensorProto):
    new_tensor = copy.deepcopy(tensor)
    new_tensor.data_type = onnx.TensorProto.FLOAT
    return new_tensor


def _bfloat16_rawdata_to_float32_rawdata(raw_data):
    data = numpy.frombuffer(raw_data, dtype=numpy.int16)
    data_float32 = numpy_helper.bfloat16_to_float32(data)
    return data_float32.tobytes()


def rewrite_bfloat16_to_float32(
    tensor: onnx.TensorProto, base_dir: str, tmp_weight_write_dir: str
):
    info = ExternalDataInfo(tensor)
    external_data_file_path = external_data_helper.c_checker._resolve_external_data_location(  # type: ignore[attr-defined]
        base_dir, info.location, tensor.name
    )
    with open(external_data_file_path, "rb") as f:
        if info.offset:
            f.seek(info.offset)
        if info.length:
            raw_data = f.read(info.length)
        else:
            raw_data = f.read()
    expected_size = 2
    for d in tensor.dims:
        expected_size *= d
    if len(raw_data) != expected_size:
        raise ValueError("len(raw_data) != expected_size")
    data_float32_raw_data = _bfloat16_rawdata_to_float32_rawdata(raw_data)
    write_data_path = pathlib.Path(tmp_weight_write_dir).joinpath(info.location)
    write_data_path.write_bytes(data_float32_raw_data)
    return str(write_data_path)


def float32_to_bfloat16(float32_array):
    """
    make float32 value to bfloat16 value by truncating last 16 bits and returns the value as float32
    """
    data_bf16 = (float32_array.view(numpy.uint32)) >> 16
    data_bf16_32bit = (data_bf16 << 16).view(numpy.float32)
    return data_bf16_32bit


class SingleNodeModelProvider:
    def __init__(self, onnx_model_path: str):
        self.onnnx_model_path = onnx_model_path
        self.base_dir = os.path.dirname(onnx_model_path)
        base_model = onnx.load(onnx_model_path, load_external_data=False)

        self.base_model = onnx.shape_inference.infer_shapes(base_model)
        self._value_infos: Dict[str, onnx.ValueInfoProto] = {
            t.name: t for t in self.base_model.graph.value_info
        }
        self._graph_inputs: Dict[str, onnx.ValueInfoProto] = {
            t.name: t for t in self.base_model.graph.input
        }
        self._graph_outputs: Dict[str, onnx.ValueInfoProto] = {
            t.name: t for t in self.base_model.graph.output
        }
        self._graph_initializers: Dict[str, onnx.TensorProto] = {
            t.name: t for t in self.base_model.graph.initializer
        }
        p = pathlib.Path(self.base_dir).joinpath("tmp_weight")
        p.mkdir(exist_ok=True, parents=True)
        self.tmp_weight_dir = str(p)

    def iter_nodes(self):
        for n in self.base_model.graph.node:
            yield n

    def _new_node_model_inputs(self, node):
        inputs, new_graph_initializers = [], []
        for k in node.input:
            if k in self._graph_initializers:
                new_graph_initializers.append(self._graph_initializers[k])
            else:
                if k in self._value_infos:
                    v = self._value_infos[k]
                elif k in self._graph_inputs:
                    v = self._graph_inputs[k]
                elif k in self._graph_outputs:
                    v = self._graph_outputs[k]
                else:
                    raise Exception(f"value info not found. node={node.name}")
                # remove duplicate model inputs that happens when concatenating same inputs.
                if v not in inputs:
                    inputs.append(v)
        return inputs, new_graph_initializers

    def _new_node_model_outputs(self, node):
        outputs = []
        for k in node.output:
            if k in self._value_infos:
                v = self._value_infos[k]
            elif k in self._graph_outputs:
                v = self._graph_outputs[k]
            else:
                raise Exception(f"value info not found. node={node.name}")
            outputs.append(v)
        return outputs

    def _handle_bfloat16(self, node, inputs, outputs, initializers):
        bfloat16_inputs = []
        bfloat16_outputs = []
        bfloat16_initializers = []

        for value_info in inputs:
            if is_bfloat16_value(value_info):
                value_info.type.tensor_type.elem_type = onnx.TensorProto.FLOAT
                bfloat16_inputs.append(value_info.name)

        for value_info in outputs:
            if is_bfloat16_value(value_info):
                value_info.type.tensor_type.elem_type = onnx.TensorProto.FLOAT
                bfloat16_outputs.append(value_info.name)
                if node.op_type == "Cast":
                    for attr in node.attribute:
                        if attr.name == "to":
                            attr.i = onnx.TensorProto.FLOAT
                elif node.op_type == "Constant":
                    for attr in node.attribute:
                        if (
                            attr.name == "value"
                            and attr.type == onnx.AttributeProto.TENSOR
                        ):
                            if external_data_helper.uses_external_data(attr.t):
                                for entry in attr.t.external_data:
                                    if entry.key != "location":
                                        continue
                                    if is_bfloat16_tensor(attr.t):
                                        attr.t.data_type = onnx.TensorProto.FLOAT
                                        entry.value = rewrite_bfloat16_to_float32(
                                            attr.t, self.base_dir, self.tmp_weight_dir
                                        )
                                    else:
                                        entry.value = os.path.join(
                                            self.base_dir, entry.value
                                        )
                            else:
                                if is_bfloat16_tensor(attr.t):
                                    attr.t.raw_data = (
                                        _bfloat16_rawdata_to_float32_rawdata(
                                            attr.t.raw_data
                                        )
                                    )
                                    attr.t.data_type = onnx.TensorProto.FLOAT

        for initializer in initializers:
            if external_data_helper.uses_external_data(initializer):
                for entry in initializer.external_data:
                    if entry.key != "location":
                        continue
                    if is_bfloat16_tensor(initializer):
                        initializer.data_type = onnx.TensorProto.FLOAT
                        bfloat16_initializers.append(initializer)
                        entry.value = rewrite_bfloat16_to_float32(
                            initializer, self.base_dir, self.tmp_weight_dir
                        )
                    else:
                        entry.value = os.path.join(self.base_dir, entry.value)
        return bfloat16_inputs, bfloat16_outputs, bfloat16_initializers

    def get_single_node_model(self, node: onnx.NodeProto):
        # we copy node not to modify original one.
        node = copy.deepcopy(node)
        inputs, initializers = self._new_node_model_inputs(node)
        outputs = self._new_node_model_outputs(node)
        (
            bfloat16_inputs,
            bfloat16_outputs,
            bfloat16_initializers,
        ) = self._handle_bfloat16(node, inputs, outputs, initializers)

        new_graph = onnx.helper.make_graph(
            [node], node.name, inputs, outputs, initializers
        )

        opset_imports = [
            onnx.helper.make_operatorsetid("", self.base_model.opset_import[0].version)
        ]
        new_model = onnx.helper.make_model(new_graph, opset_imports=opset_imports)
        new_model = onnx.shape_inference.infer_shapes(new_model)
        return new_model, bfloat16_inputs, bfloat16_outputs, bfloat16_initializers


def attach_layers_as_output(
    onnx_model,
    layer_names,
):
    known_vis = {}
    for vi in (
        list(onnx_model.graph.input)
        + list(onnx_model.graph.value_info)
        + list(onnx_model.graph.output)
    ):
        known_vis[vi.name] = vi

    existing_outs = {o.name for o in onnx_model.graph.output}

    for name in layer_names:
        if not name or name in existing_outs:
            continue

        vi = known_vis.get(name)

        if (
            vi
            and vi.type
            and getattr(vi.type, "tensor_type", None)
            and vi.type.tensor_type.elem_type
        ):
            onnx_model.graph.output.append(copy.deepcopy(vi))
            existing_outs.add(name)
            continue

        pvi = helper.ValueInfoProto()
        pvi.name = name
        onnx_model.graph.output.append(pvi)
        existing_outs.add(name)


def attach_intermediate_layers_as_output(onnx_model):
    intermediate_outputs = []
    for node in onnx_model.graph.node:
        for output in node.output:
            intermediate_outputs.append(output)

    for output in intermediate_outputs:
        value_info = onnx.helper.ValueInfoProto()
        value_info.name = output
        onnx_model.graph.output.extend([value_info])


class OnnxValueProvider(ValueProviderABC, abc.ABC):
    def __init__(self, tensor: onnx.TensorProto):
        self.tensor = tensor

    @property
    def shape(self):
        return tuple(self.tensor.dims)

    @property
    def dtype(self):
        return get_onnx_data_type(self.tensor.data_type)


class OnnxFileValueLoader(OnnxValueProvider):
    def __init__(self, base_dir, tensor: onnx.TensorProto):
        super().__init__(tensor)
        self.base_dir = base_dir

    @property
    def value(self, *args, **kwargs):
        # Direct use of `external_data_helper.load_external_data for tensor`
        # Caches values in TensorProto, which may cause errors in subsequent steps.
        _tensor = copy.deepcopy(self.tensor)
        return numpy_helper.to_array(_tensor, self.base_dir)

    @property
    def available(self):
        for entry in self.tensor.external_data:
            if entry.key == "location":
                path_ = pathlib.Path(
                    external_data_helper.c_checker._resolve_external_data_location(
                        self.base_dir, entry.value, self.tensor.name
                    )
                )
                return path_.exists() and path_.is_file()
        return False

        # external_data_path = external_data_path


class OnnxCachingValueLoader(OnnxValueProvider):
    def __init__(self, tensor: onnx.TensorProto):
        super().__init__(tensor)
        self._value = None

    @property
    def value(self, *args, **kwargs):
        if self._value is None:
            self._value = numpy_helper.to_array(self.tensor)
        return self._value

    @property
    def available(self):
        return True

    def astype(self, dtype: numpy.generic):
        return self.value.astype(dtype)


def get_onnx_value_loader(tensor: onnx.TensorProto, base_dir=""):
    if external_data_helper.uses_external_data(tensor):
        return OnnxFileValueLoader(base_dir, copy.deepcopy(tensor))
    else:
        return OnnxCachingValueLoader(copy.deepcopy(tensor))
