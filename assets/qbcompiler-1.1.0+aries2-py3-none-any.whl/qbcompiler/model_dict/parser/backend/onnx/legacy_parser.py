from typing import List, Dict, Any
from collections import OrderedDict
import numpy

import qbcompiler.model_dict.common.model_dict as schema
from qbcompiler.model_dict.common import (
    Operator,
    TensorSpec,
    ActivationSpec,
    options,
    SubGraph,
    DataFormat,
)
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.common.parserabc import (
    ParserABC,
    MobilintParserInputs,
    MobilintParserOutputs,
)
from ._layerdict_mapper import PostOnnxMapper
from ._loader import ONNXLoader

def _get_subgraph(
    name: str,
    operators: List[Operator],
    tensors: List[TensorSpec],
    activations: List[ActivationSpec],
    input_name_list: List[str],
    output_name_list: List[str],
):
    input_name_dict = OrderedDict()
    output_name_dict = OrderedDict()

    for opt in operators:
        op = opt.options
        if isinstance(op, options.InputOptions):
            input_name_dict[activations[op.inputs[0]].name] = op.inputs[0]
        elif isinstance(op, options.OutputOptions):
            output_name_dict[activations[op.outputs[0]].name] = op.outputs[0]

    input_names = sorted(input_name_dict.keys(), key=lambda x: input_name_list.index(x))
    output_names = sorted(
        output_name_dict.keys(), key=lambda x: output_name_list.index(x)
    )
    input_idx = [input_name_dict[in_name] for in_name in input_names]
    output_idx = [output_name_dict[out_name] for out_name in output_names]

    sg = SubGraph(
        name=name,
        operators=operators,
        tensors=tensors,
        inputs=input_idx,
        outputs=output_idx,
        activations=activations,
    )
    return sg, input_names, output_names


def _get_value_dict(value_dict_raw, _layer_dict):
    value_dict = ValueDict()
    for k, v in value_dict_raw.items():
        value_dict.add(k, v, _layer_dict[k].get("dataformat", DataFormat.UNKNOWN))

    return value_dict


def _get_model_dict(main_subgraph, in_names, out_names, backend):
    md = schema.ModelDict()
    md.subgraphs = [main_subgraph]
    md.graph_order = [0]
    md.inputs = in_names
    md.outputs = out_names
    md.model_backend = backend
    return md


def _get_tensors(_tensor_names, _simple_const_dict: Dict[str, Any]):
    tensors = []
    for name in _tensor_names:
        if name in _simple_const_dict:
            tensors.append(
                TensorSpec(
                    name=name,
                    dtype=str(_simple_const_dict[name].dtype),
                    shape=_simple_const_dict[name].shape,
                )
            )

    return tensors


def _get_activations(
    name_to_idx,
    value_dict: Dict[str, numpy.ndarray],
    layer_dict: Dict[str, Any],
    const_dict: Dict[str, numpy.ndarray],
) -> List:
    if value_dict.keys() != layer_dict.keys():
        raise ValueError("layer name of value dict and layer dict are not matched")

    activations = []
    for name in name_to_idx.keys():
        if name in layer_dict:
            activations.append(
                ActivationSpec(
                    name=name,
                    dtype=str(value_dict[name].dtype),
                    src_shape=value_dict[name].shape,
                    shape=(-1, -1, -1),
                    dataformat=layer_dict[name].get("dataformat", DataFormat.UNKNOWN),
                )
            )
        elif name in const_dict:
            activations.append(
                ActivationSpec(
                    name=name,
                    dtype=str(const_dict[name].dtype),
                    src_shape=const_dict[name].shape,
                    shape=(-1, -1, -1),
                    dataformat=DataFormat.UNKNOWN,
                )
            )
        else:
            raise NotImplementedError(f"name={name} not in layer_dict or const_dict")

    return activations

class OnnxParser(ParserABC):
    def __init__(
        self,
        path_to_model: str,
        temp_dir: str,
        large_model=False,
        seed: int = 12345,
        model=None,  # not used, only for get parser function
    ):
        super().__init__(path_to_model, "onnx", seed)
        self._large_model = large_model
        self._temp_dir = temp_dir

    def parse(
        self, parser_inputs: MobilintParserInputs, **kwargs
    ) -> MobilintParserOutputs:
        tmp_name = "mobilint"
        in_shapes = parser_inputs.in_shapes
        feed_dict = parser_inputs.feed_dict
        in_dformats = parser_inputs.in_dformats
        large_value_dict_path = (
            parser_inputs.large_value_dict_path
        )  # value_dict only for large onnx model

        legacy_onnx_dict = ONNXLoader(
            self.onnx_path,
            feed_dict=feed_dict,
            large_model=self._large_model,
            temp_dir=self._temp_dir,
            value_dict_path=large_value_dict_path,
        )
        _input_name_list = legacy_onnx_dict.input_list
        _output_name_list = legacy_onnx_dict.src_output_list

        mapper = PostOnnxMapper()
        _option_dict = mapper.map(legacy_onnx_dict, in_dformats)

        _layer_dict = legacy_onnx_dict.layer_dict
        _const_dict = legacy_onnx_dict.const_dict
        _value_dict = legacy_onnx_dict.sample_value_dict
        _model_info = legacy_onnx_dict.model_info

        _operators = [
            Operator(name=layer_name, options=options_)
            for layer_name, options_ in _option_dict.items()
        ]
        _const_dict = {name: _const_dict[name]["value"] for name in _const_dict.keys()}
        _activations = _get_activations(
            mapper.name_to_idx, _value_dict, _layer_dict, _const_dict
        )
        _tensors = _get_tensors(mapper.tensor_names, _const_dict)
        _subgraph, _in_names, _out_names = _get_subgraph(
            name=tmp_name,
            operators=_operators,
            tensors=_tensors,
            activations=_activations,
            input_name_list=_input_name_list,
            output_name_list=_output_name_list,
        )
        _model_dict = _get_model_dict(_subgraph, _in_names, _out_names, self.backend)
        _subgraph.idx = 0
        _value_dict = _get_value_dict(_value_dict, _layer_dict)
        onnx_output = MobilintParserOutputs(_model_dict, _const_dict, _value_dict)
        onnx_output.origin_input_names = _in_names
        onnx_output.origin_output_names = _out_names

        return onnx_output

    @property
    def onnx_path(self):
        return self.path_to_model

    @onnx_path.setter
    def onnx_path(self, path: str):
        self.path_to_model = path
