import asyncio
import base64
import functools
import json
import logging
import os
import pathlib
import tempfile
from collections import namedtuple
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, Tuple

import numpy
import onnx
import onnxruntime

from qbcompiler.model_dict.common.value_wrapper import ValueWrapper, ValueProviderABC
from qbcompiler.model_dict.parser.backend.onnx._util import (
    attach_layers_as_output,
    SingleNodeModelProvider,
    float32_to_bfloat16,
)
from qbcompiler.logging import get_logger

logger = get_logger(__name__)

ArrayFileInfo = namedtuple("ArrayFileInfo", ["shape", "dtype", "path_to_file"])


class OnnxInferenceValue(ValueProviderABC):
    def __init__(
        self,
        value: numpy.ndarray | None = None,
        shape: Tuple[int, ...] | None = None,
        dtype: str | None = None,
        base_dir: str | None = None,
        file_name: str | None = None,
    ):
        if value is not None:
            self._available = True
        else:
            self._available = False
            value = ArrayFileInfo(shape, dtype, os.path.join(base_dir, file_name))
        self._value: numpy.ndarray | ArrayFileInfo = value

    def to_json(self):
        if isinstance(self._value, numpy.ndarray):
            raw_data = self.value.tobytes()
            return {
                "raw_data": base64.b64encode(raw_data).decode("utf-8"),
                "shape": list(self._value.shape),
                "dtype": str(self._value.dtype),
            }
        else:
            return {
                "shape": list(self._value.shape),
                "dtype": str(self._value.dtype),
                "path_to_file": self._value.path_to_file,
            }

    @property
    def value(self):
        if isinstance(self._value, numpy.ndarray):
            return self._value
        file_path = pathlib.Path(self._value.path_to_file)
        if not file_path.exists():
            raise FileNotFoundError(f"File does not exist: {file_path}")
        if file_path.stat().st_size == 0:
            raise ValueError(f"File is empty: {file_path}")
        b = file_path.read_bytes()
        return numpy.frombuffer(b, dtype=self.dtype).reshape(self.shape)

    @property
    def shape(self):
        return self._value.shape

    @property
    def dtype(self):
        return self._value.dtype

    def has_numpy_value(self):
        return isinstance(self._value, numpy.ndarray)

    @property
    def path_to_file(self):
        if isinstance(self._value, numpy.ndarray):
            raise ValueError(
                "The current OnnxInferenceValue instance contains a numpy.ndarray value."
            )
        return self._value.path_to_file

    @property
    def available(self):
        return self._available

    def astype(self, dtype: numpy.dtype):
        if isinstance(numpy.dtype(dtype), numpy.dtype):
            self._value = self._value.astype(dtype)
            return self
        else:
            raise NotImplementedError("Not implemented casting")

    def set_available(self):
        self._available = True


class OnnxInferenceValueDict:
    def __init__(self):
        self._container: Dict[str, ValueWrapper] = {}

    def __setitem__(self, key, value):
        self._container[key] = value

    def __getitem__(self, key):
        return self._container[key]

    def __contains__(self, item):
        return item in self._container

    def __len__(self):
        return len(self._container)

    def __iter__(self):
        return iter(self._container)

    def items(self):
        return self._container.items()

    def keys(self):
        return self._container.keys()

    def values(self):
        return self._container.values()

    def serialize(self, path_to_file: str):
        dct = {}
        for k, v in self._container.items():
            if isinstance(v._value, OnnxInferenceValue):
                dct[k] = v._value.to_json()
            else:
                raise NotImplementedError(
                    f"Not implemented serializing({type(v._value)})"
                )
        with open(path_to_file, "w") as f:
            json.dump(dct, f)

    @staticmethod
    def deserialize(path_to_file: str) -> "OnnxInferenceValueDict":
        obj = OnnxInferenceValueDict()
        with open(path_to_file, "r") as f:
            dct = json.load(f)
            for k, v in dct.items():
                if "raw_data" in v:
                    oiv = OnnxInferenceValue(
                        value=numpy.frombuffer(
                            base64.b64decode(v["raw_data"]), dtype=v["dtype"]
                        ).reshape(v["shape"])
                    )
                else:
                    oiv = OnnxInferenceValue(
                        shape=v["shape"],
                        dtype=v["dtype"],
                        base_dir=os.path.dirname(v["path_to_file"]),
                        file_name=os.path.basename(v["path_to_file"]),
                    )
                obj[k] = ValueWrapper(oiv)
        return obj


class OnnxInference:
    def __init__(self, onnx_model_path, output_targets=None, value_dict_temp_dir=""):
        self.onnx_model_path = onnx_model_path
        self.output_targets = output_targets
        self.value_dict_temp_dir = value_dict_temp_dir
        self.value_dict = None

    def run(self, ort_inputs):
        self.value_dict = OnnxInferenceValueDict()

        with tempfile.TemporaryDirectory() as d:
            file_path = os.path.join(d, "tmp.onnx")
            onnx_model = onnx.load(self.onnx_model_path)
            if self.output_targets is not None:
                attach_layers_as_output(onnx_model, self.output_targets)
            onnx.save(onnx_model, file_path, save_as_external_data=True)

            sess_options = onnxruntime.SessionOptions()
            sess_options.intra_op_num_threads = 8
            # prevent onnxruntime fuse layers during parsing
            sess_options.graph_optimization_level = (
                onnxruntime.GraphOptimizationLevel.ORT_ENABLE_BASIC
            )
            logger.info("run onnx inference session")
            ort_session = onnxruntime.InferenceSession(
                file_path,
                sess_options=sess_options,
                providers=["CPUExecutionProvider"],
            )
            ort_outs = ort_session.run(None, ort_inputs)
            logger.info("onnx inference session done.")
            for k, v in zip(onnx_model.graph.output, ort_outs):
                self.value_dict[k.name] = ValueWrapper(OnnxInferenceValue(value=v))


def _write_output_callback(
    node_name_, tensor_name, value_loader, debug, *args, **kwargs
):
    value_loader.set_available()
    if debug:
        print(
            f"[Write] node={node_name_}, tensor={tensor_name}, file={value_loader.path_to_file}"
        )


class LargeOnnxModelInference:
    def __init__(
        self,
        onnx_model_path: str,
        output_targets=None,
        value_dict_temp_dir: str = "",
        debug=True,
    ):
        self.onnx_model_path = onnx_model_path
        self.output_targets = output_targets
        self.value_dict: OnnxInferenceValueDict | None = None
        self.debug = debug

        self.onnx_model_base_dir = os.path.dirname(self.onnx_model_path)

        self.max_queue_len = 25
        self.data_queue = asyncio.Queue()
        self.done = False
        self.base_model = None
        self.sess_options = None
        self.base_model_input_dict = None
        self.loop = None
        self.executor = None
        self.single_nodel_model_provider = None

        self.write_counter = None
        self.sleep_t = 0.0001

        self._next_node_inputs = None
        self._input_cnt_remaining = None
        self._value_dict_temp_dir = str(value_dict_temp_dir)
        self._input_cache: Dict[str, numpy.ndarray] | None = None
        self._max_input_cache = 4

    def init(self, max_queue_len=None):
        if max_queue_len:
            self.max_queue_len = min(max_queue_len, 25)

        self.sess_options = onnxruntime.SessionOptions()
        self.sess_options.graph_optimization_level = (
            onnxruntime.GraphOptimizationLevel.ORT_ENABLE_BASIC
        )
        self.single_nodel_model_provider = SingleNodeModelProvider(self.onnx_model_path)
        self.write_counter = 0
        self.value_dict = OnnxInferenceValueDict()

        if not pathlib.Path(self._value_dict_temp_dir).exists():
            pathlib.Path(self._value_dict_temp_dir).mkdir(parents=True, exist_ok=True)

        # prepare input cache
        self._input_cache = {}
        self._next_node_inputs = {}
        self._input_cnt_remaining = {}

        initializer_names = set(
            n.name
            for n in self.single_nodel_model_provider.base_model.graph.initializer
        )
        prev_node = None
        for n in self.single_nodel_model_provider.iter_nodes():
            input_names = tuple(n for n in n.input if n not in initializer_names)
            for name in input_names:
                if name not in self._input_cnt_remaining:
                    self._input_cnt_remaining[name] = 1
                self._input_cnt_remaining[name] += 1
            if prev_node is not None:
                self._next_node_inputs[prev_node.name] = input_names
            prev_node = n

    def run(self, ort_inputs, max_queue_len: int | None = None):
        try:
            asyncio.run(self._run(ort_inputs=ort_inputs, max_queue_len=max_queue_len))
        except Exception as e:
            print(f"large model run error! {e}")
            raise e

    async def _run(self, ort_inputs, max_queue_len):
        self.init(max_queue_len)
        self.loop = asyncio.get_running_loop()
        self.executor = ThreadPoolExecutor()

        for k, v in ort_inputs.items():
            value_provider = self._get_value_loader(v, name=k)
            value_provider.set_available()
            self.value_dict[k] = ValueWrapper(value_provider)
            if not value_provider.has_numpy_value():
                pathlib.Path(value_provider.path_to_file).write_bytes(v.tobytes())
            if len(self._input_cache) < self._max_input_cache:
                self._input_cache[k] = v

        tasks = [
            self.loop.create_task(self.node_eval_proc()),
            self.loop.create_task(self.write_output_proc()),
        ]
        await asyncio.gather(*tasks)

    def _get_value_loader(self, v: numpy.ndarray, name: str = None):
        if v.size <= 1:
            return OnnxInferenceValue(
                value=v,
                shape=v.shape,
                dtype=v.dtype,
            )

        if name is None:
            tmp_file_name = "vd" + str(self.write_counter)
        else:
            tmp_file_name = name.replace("/", "_").replace(":", "_")
        self.write_counter += 1
        return OnnxInferenceValue(
            shape=v.shape,
            dtype=v.dtype,
            base_dir=self._value_dict_temp_dir,
            file_name=tmp_file_name,
        )

    async def node_eval_proc(self):
        for node in self.single_nodel_model_provider.iter_nodes():
            while self.data_queue.qsize() >= self.max_queue_len:
                print(
                    f"node={node.name}, waiting, queue_len={self.data_queue.qsize()}/{self.max_queue_len} "
                )
                await asyncio.sleep(self.sleep_t)

            (
                node_model,
                bf16_inputs,
                bf16_outputs,
                bf16_initializers,
            ) = self.single_nodel_model_provider.get_single_node_model(node)
            if self.debug:
                print(f"[Prepare Input] node={node.name}")

            output_names = [n.name for n in node_model.graph.output]
            input_names = [
                n.name
                for n in node_model.graph.input
                if n.name not in set(n.name for n in node_model.graph.initializer)
            ]
            input_dict = await self.input_dict_proc(input_names)
            if self.debug:
                print(f"[Done] Input Dict. node={node.name}")

            ort_session = onnxruntime.InferenceSession(
                node_model.SerializeToString(),
                self.sess_options,
                ["CPUExecutionProvider"],
            )
            output_values = ort_session.run(None, input_dict)

            if self.debug:
                print(f"[Evaluate] node={node.name}")

            for output_name, output_value in zip(output_names, output_values):
                if output_name in bf16_outputs:
                    output_value = float32_to_bfloat16(output_value)

                nni = self._next_node_inputs.get(node.name, tuple())
                if output_name not in nni:
                    while len(self._input_cache) >= self._max_input_cache:
                        del_candidate = sorted(
                            (self._input_cnt_remaining[c], c)
                            for c in self._input_cache.keys()
                            if c not in nni
                        )[0][1]
                        self._input_cache.pop(del_candidate)
                    self._input_cache[output_name] = output_value
                value_provider = self._get_value_loader(output_value, name=output_name)
                self.value_dict[output_name] = ValueWrapper(value_provider)
                if not value_provider.available:
                    await self.data_queue.put(
                        (output_name, output_value, node.name, value_provider)
                    )
        self.done = True

    async def write_output_proc(self):
        while not (self.done and self.data_queue.empty()):
            if self.data_queue.empty():
                await asyncio.sleep(self.sleep_t)
            else:
                (
                    tensor_name,
                    value,
                    node_name,
                    value_provider,
                ) = await self.data_queue.get()
                path_to_file = pathlib.Path(value_provider.path_to_file)
                future = self.loop.run_in_executor(
                    self.executor, path_to_file.write_bytes, value.tobytes()
                )
                # fix params to _write_output_callback.
                callback = functools.partial(
                    _write_output_callback,
                    node_name,
                    tensor_name,
                    value_provider,
                    self.debug,
                )
                future.add_done_callback(callback)
                # await future  # 파일 쓰기 작업이 완료될 때까지 대기

    async def input_dict_proc(self, input_names):
        dct = {}
        for name in input_names:
            self._input_cnt_remaining[name] -= 1
            if name in self._input_cache:
                if self._input_cnt_remaining[name] == 0:
                    dct[name] = self._input_cache.pop(name)
                else:
                    dct[name] = self._input_cache[name]
            elif name in self.value_dict:
                v: ValueWrapper = self.value_dict[name]
                while not v.value_provider.available:  # wait for writing done
                    await asyncio.sleep(self.sleep_t)
                dct[name] = await self.loop.run_in_executor(
                    self.executor, lambda x: x.value, v
                )
            else:
                raise Exception(f"input={name} not found")
        return dct


def get_onnx_inference_obj(
    onnx_model_path, target_output_list=None, is_large_model=False, **kwargs
):
    if is_large_model:
        return LargeOnnxModelInference(
            onnx_model_path,
            output_targets=target_output_list,
            value_dict_temp_dir=kwargs["value_dict_temp_dir"],
        )
    else:
        return OnnxInference(onnx_model_path, output_targets=target_output_list)
