import importlib

__all__ = ["get_parser"]

from typing import Any

_DEFAULT_IMPLEMENTED_PARSERS = ["onnx", "tf", "tflite", "hf", "torch"]
# fmt: off
_MISC_MODELS = {
    "mellotts": "qbcompiler.model_dict.parser.backend.misc.myshell_ai",
    "outetts" : "qbcompiler.model_dict.parser.backend.misc",
    "wenet": "qbcompiler.model_dict.parser.backend.misc",
    "nemo": "qbcompiler.model_dict.parser.backend.misc"
}

_PARSER_PATHS = {
    k: f"qbcompiler.model_dict.parser.backend.{k}" for k in _DEFAULT_IMPLEMENTED_PARSERS
}
_PARSER_PATHS.update(_MISC_MODELS)
# fmt: on


def get_parser(backend: str, model: Any, model_path: str, **kwargs):
    if backend in _PARSER_PATHS:
        module_path = _PARSER_PATHS[backend]
    else:
        raise NotImplementedError(
            f"`{backend}` not supported! Supported_frameworks={_PARSER_PATHS.keys()}"
        )

    parser_module = importlib.import_module(module_path)
    if kwargs.get("large_model", False):
        if backend != "onnx":
            raise NotImplementedError(
                f"large_model mode not implemented for backend={backend}!"
            )

    return parser_module.get_parser(model=model, model_path=model_path, **kwargs)
