from typing import Dict, Any, List

import numpy

import qbcompiler.model_dict.common.model_dict as schema
from qbcompiler.model_dict.common.parserabc import (
    ParserABC,
    MobilintParserInputs,
    MobilintParserOutputs,
)
from qbcompiler.model_dict.common.model_dict import ValueDict
from ._layerdict_mapper import PostTFMapper
from ._legacy_tf_dict import LegacyTFModelDict

from qbcompiler.model_dict.common import (
    Operator,
    TensorSpec,
    ActivationSpec,
    options,
    SubGraph,
    DataFormat,
)


def _get_subgraph(
    name: str,
    operators: List[Operator],
    tensors: List[TensorSpec],
    activations: List[ActivationSpec],
):
    input_names = []
    input_idx = []
    output_names = []
    output_idx = []
    for opt in operators:
        op = opt.options
        if isinstance(op, options.InputOptions):
            input_idx.append(op.inputs[0])
            input_names.append(activations[op.inputs[0]].name)
        elif isinstance(op, options.OutputOptions):
            output_idx.append(op.outputs[0])
            output_names.append(activations[op.outputs[0]].name)

    sg = SubGraph(
        name=name,
        operators=operators,
        tensors=tensors,
        inputs=input_idx,
        outputs=output_idx,
        activations=activations,
    )
    return sg, input_names, output_names


def _get_tensors(_tensor_names, _simple_const_dict: Dict[str, Any]):
    tensors = []
    for name in _tensor_names:
        if name in _simple_const_dict:
            tensors.append(
                TensorSpec(
                    name=name,
                    dtype=str(_simple_const_dict[name].dtype),
                    shape=_simple_const_dict[name].shape,
                )
            )

    return tensors


def _get_activations(
    name_to_idx,
    value_dict: Dict[str, numpy.ndarray],
    layer_dict: Dict[str, Any],
    const_dict: Dict[str, numpy.ndarray],
) -> List:
    if value_dict.keys() != layer_dict.keys():
        raise ValueError("layer name of value dict and layer dict are not matched")

    activations = []
    for name in name_to_idx.keys():
        if name in layer_dict:
            activations.append(
                ActivationSpec(
                    name=name,
                    dtype=str(value_dict[name].dtype),
                    src_shape=value_dict[name].shape,
                    shape=(-1, -1, -1),
                    dataformat=layer_dict[name]["dataformat"],
                )
            )
        elif name in const_dict:
            activations.append(
                ActivationSpec(
                    name=name,
                    dtype=str(const_dict[name].dtype),
                    src_shape=const_dict[name].shape,
                    shape=(-1, -1, -1),
                    dataformat=DataFormat.UNKNOWN,
                )
            )
        else:
            raise NotImplementedError(f"name={name} not in layer_dict or const_dict")

    return activations


def _get_model_dict(main_subgraph, in_names, out_names, backend):
    md = schema.ModelDict()
    md.subgraphs = [main_subgraph]
    md.graph_order = [0]
    md.inputs = in_names
    md.outputs = out_names
    md.model_backend = backend
    return md


def _get_value_dict(value_dict_raw, _layer_dict):
    value_dict = ValueDict()
    for k, v in value_dict_raw.items():
        value_dict.add(k, v, _layer_dict[k]["dataformat"])

    return value_dict


class TFParser(ParserABC):
    def __init__(self, path_to_model: str, seed=12345, **kwargs):
        super().__init__(path_to_model, "tf", seed)
        self._feed_dict = None
        self._input_shape_dict = None

    def parse(
        self, parser_inputs: MobilintParserInputs, **kwargs
    ) -> MobilintParserOutputs:
        in_dformats = parser_inputs.in_dformats
        feed_dict = parser_inputs.feed_dict
        self._input_shape_dict = in_dformats
        self._feed_dict = feed_dict

        tmp_name = "mobilint"
        legacy_tf_dict = LegacyTFModelDict(
            self.tf_path,
            input_shape_dict=self._input_shape_dict,
            feed_dict=self._feed_dict,
        )
        mapper = PostTFMapper()
        _option_dict = mapper.map(legacy_tf_dict, in_dformats)
        _layer_dict = legacy_tf_dict.layer_dict
        _const_dict = legacy_tf_dict.const_dict
        _value_dict = legacy_tf_dict.sample_value_dict

        _operators = [
            Operator(name=layer_name, options=options_)
            for layer_name, options_ in _option_dict.items()
        ]
        _const_dict = {name: _const_dict[name]["value"] for name in _const_dict.keys()}

        _activations = _get_activations(
            mapper.name_to_idx, _value_dict, _layer_dict, _const_dict
        )
        _tensors = _get_tensors(mapper.tensor_names, _const_dict)
        _subgraph, _in_names, _out_names = _get_subgraph(
            name=tmp_name,
            operators=_operators,
            tensors=_tensors,
            activations=_activations,
        )

        _model_dict = _get_model_dict(_subgraph, _in_names, _out_names, self.backend)
        _subgraph.idx = 0
        _value_dict = _get_value_dict(_value_dict, _layer_dict)

        return MobilintParserOutputs(_model_dict, _const_dict, _value_dict)

    def _get_model_dict(self, main_subgraph, inputs, outputs):
        md = schema.ModelDict()
        md.subgraphs = [main_subgraph]
        md.graph_order = [0]
        md.inputs = inputs
        md.outputs = outputs
        md.model_backend = self.backend

        return md

    @property
    def tf_path(self):
        return self._path_to_model

    @tf_path.setter
    def tf_path(self, path: str):
        self._path_to_model = path
