import copy
import os

import numpy
import tensorflow as tf

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
import tensorflow.python.framework as tf_fw
import tensorflow.compat.v1 as tf1
from ._legacy_tf_loader import (
    get_frozen_graph_from_saved_model,
    get_frozen_graph_from_keras,
    get_frozen_graph_from_graphdef,
    get_frozen_graph_from_checkpoint,
)
from qbcompiler.model_dict.parser.old_model_dict_utils import (
    add_output_to_layer_dict,
    get_input_list,
    DATA_FORMAT,
    logger,
)
from ._layerdict_mapper import get_HWC_indices


def parse_data_format_str(data_format_str: str) -> DATA_FORMAT:
    """
    Parses a string representation of data format into a DATA_FORMAT enum.

    Args:
        data_format_str (str): String representation of the data format.

    Returns:
        DATA_FORMAT: Enum value representing the parsed data format.

    Raises:
        ValueError: If the input string is not a supported data format.
    """
    if data_format_str in ["BCHW", "NCHW"]:
        return DATA_FORMAT.BCHW
    elif data_format_str in ["BHWC", "NHWC"]:
        return DATA_FORMAT.BHWC
    elif data_format_str in ["BC", "NC"]:
        return DATA_FORMAT.BC
    elif data_format_str in ["CB", "CN"]:
        return DATA_FORMAT.CB
    elif data_format_str == "HWC":
        return DATA_FORMAT.HWC
    elif data_format_str == "HCW":
        return DATA_FORMAT.HCW
    elif data_format_str == "BH1W1C":
        return DATA_FORMAT.BH1W1C
    elif data_format_str == "BH2W2C":
        return DATA_FORMAT.BH2W2C
    elif data_format_str == "BHW":
        return DATA_FORMAT.BHW
    else:
        raise ValueError(f"Unsupported data format string: {data_format_str}")


def _is_str_list(obj):
    return isinstance(obj, list) and all(isinstance(k, str) for k in obj)


def check_new_input_shape(input_shape_dict, target_shape, input_name):
    # todo: tf only
    if input_shape_dict is None:
        return None
    if all(isinstance(k, str) for k in input_shape_dict.keys()) and all(
        _is_str_list(v) for v in input_shape_dict.values()
    ):
        return None
    if input_name not in input_shape_dict:
        raise ValueError(
            f"User-defined Input Shape dict doesn't have Input {input_name} which is from model."
        )
    new_target_shape = input_shape_dict[input_name]
    if new_target_shape is None:
        return None
    elif not isinstance(new_target_shape, (list, tuple)):
        raise ValueError(
            f"Shape for single value should be list or tuple. got {new_target_shape}"
        )
    if len(target_shape) == len(new_target_shape):
        return new_target_shape
    if len(target_shape) == len(new_target_shape) + 1:
        return type(new_target_shape)((0,)) + new_target_shape
    if len(target_shape) == len(new_target_shape) - 1:
        return new_target_shape[1:]
    raise AssertionError(
        f"User-Input shape of input ({new_target_shape}) has different number of dimension with pre-defined one ({target_shape})."
    )


def replace_input_of_layers(input_name_old: str, input_name_new: str, model_dict: dict):
    """
    Replace the old input_tensor of layers by the new one
    """
    for layer_name, layer_info in model_dict.items():
        for attr in [
            "input",
            "input0",
            "input1",
            "input_names",
            "input_list",
            "indices",
        ]:
            if attr not in layer_info:
                continue

            if isinstance(layer_info[attr], str):
                if layer_info[attr] == input_name_old:
                    layer_info[attr] = input_name_new
            elif isinstance(layer_info[attr], (list, tuple)):
                for i, temp_input_name in enumerate(layer_info[attr]):
                    if temp_input_name == input_name_old:
                        model_dict[layer_name][attr][i] = input_name_new
                        break
            elif attr == "indices":
                continue
            else:
                raise ValueError(
                    "unknown type of input_tensor of layers. ", model_dict[layer_name]
                )


class LegacyTFModelDict:
    def __init__(
        self,
        tf_model_path,
        input_shape_dict=None,
        feed_dict=None,
    ):
        """
        tf_model_path :
            Loading TF model from path. The given path should be one of below.
            1. .keras, .h5 file path
            2. saved_model directory path where saved_model.pb file is located
            3. graphdef(designated .pb file) path
            4. ckpt directory path where ckpt files (*.meta, *.data, *.index)
        input_shape_dict : dict with input name : shape (list/tuple of Int or str) If it is dictionary of string, it will be used on loading tf model. If it is dictionary of (list/tuple) of int, it will be used on fixing the shape of input layer.

        *Notice: node_def of TF's Node has Namespace `name` which stands for its layer name.
                And node_def's Namespace `input` indicates input layers as their layer names.
                ONNX model dict's layer name is its output tensor name but TF model dict's layer name is node_def's layer name.
        """
        logger.debug("start TF_MODEL_DICT")
        self.exclude_unsupported = None
        self.tf_model_path = os.path.abspath(tf_model_path)
        if input_shape_dict is not None:
            assert isinstance(
                input_shape_dict, dict
            ), "input_shape_dict should be dictionary."
        self.input_shape_dict = input_shape_dict
        self.tf_feed_dict = feed_dict

        self.source_output_attr = "tf_output_name"
        self.load_operations(tf_model_path)
        self.make_layer_dict()
        self.check_input_with_default()
        self.remove_switch_merge()
        self.make_const_dict()
        self.calculate_const_and_shape()
        self.update_info()

        add_output_to_layer_dict(self.layer_dict, self.const_dict)
        self.sess.close()

    @property
    def get_layer_dict(self):
        return self.layer_dict

    @property
    def get_const_dict(self):
        return self.const_dict

    def op_name(self, name):
        ### load operation from name
        return self.operations[name]

    @staticmethod
    def _input_name_to_node_name(name):
        if ":" in name:
            name = ":".join(name.split(":")[:-1])
        if "^" in name:
            name = name.replace("^", "")
        return name

    def _get_output_nodes(self, nodes):
        all_nodes = {node.name: node for node in nodes}
        all_inputs = []
        # ban_list = ["Const", "NoOp", "Identity", "Add", "Fill", "Mul", "RestoreV2"] # TODO Need to Update
        core_subtrees = []
        for node_name in all_nodes.keys():
            node = all_nodes[node_name]
            if node.op == "Placeholder":
                core_subtrees.append(node_name)
                continue
            input_names = node.input
            if len(input_names) == 0:
                continue
            is_valid = False
            for input_name in input_names:
                input_node_name = self._input_name_to_node_name(input_name)
                if input_node_name in core_subtrees:
                    is_valid = True
                    break
            if is_valid:
                core_subtrees.append(node_name)
            all_inputs.extend([self._input_name_to_node_name(x) for x in input_names])

        output_names = list(set(core_subtrees) - set(all_inputs))
        return output_names

    def _load_operation_frozen_graph(self, tf_model_path):
        self.graph_def, self.graph = get_frozen_graph_from_graphdef(
            tf_model_path,
            self.input_shape_dict["input"],
            self.input_shape_dict["output"],
        )

    def _load_operation_ckpt(self, tf_model_path):
        meta_path = os.path.join(
            tf_model_path,
            [x for x in os.listdir(tf_model_path) if x.endswith(".meta")][0],
        )
        self.graph_def, self.graph = get_frozen_graph_from_checkpoint(
            meta_path, self.input_shape_dict["input"], self.input_shape_dict["output"]
        )

    def _load_operation_saved_model(self, tf_model_path):
        self.graph_def, self.graph = get_frozen_graph_from_saved_model(tf_model_path)

    def _load_operation_keras(self, tf_model_path):
        self.graph_def, self.graph = get_frozen_graph_from_keras(tf_model_path)

    @staticmethod
    def check_type_of_tf_model(tf_model_path):
        """Prioritized order is
        1. .keras, .h5 file path
        2. saved_model directory path where saved_model.pb file is located
        3. graphdef(designated .pb file) path
        4. ckpt directory path where ckpt files (*.meta, *.data, *.index)
        """
        if os.path.isfile(tf_model_path) and (
            tf_model_path.endswith(".keras") or tf_model_path.endswith(".h5")
        ):  # TF 2.x(>2.7). The latest standard saving format.
            print("Given path is a .keras or .h5 file.")
            return "keras"
        elif os.path.isdir(tf_model_path) and os.path.exists(
            os.path.join(tf_model_path, "saved_model.pb")
        ):  # TF 2.x
            print("Given path is a SavedModel directory.")
            return "saved_model"
        elif os.path.isfile(tf_model_path) and tf_model_path.endswith(".pb"):  # TF 1.x
            print("Given path is a .pb file.")
            return "protobuf"
        elif os.path.isdir(tf_model_path) and (
            any([x.endswith(".meta") for x in os.listdir(tf_model_path)])
            and any([x.endswith(".index") for x in os.listdir(tf_model_path)])
            and any([".data" in x for x in os.listdir(tf_model_path)])
        ):
            print("Given path is a ckpt directory.")
            return "meta"
        else:
            raise AssertionError(
                f"Given path is not in valid format. The path should be either .pb, .h5, .keras file, or a directory containing saved_model.pb or ckpt files. But got {tf_model_path}"
            )

    def load_operations(self, tf_model_path):
        method = self.check_type_of_tf_model(tf_model_path)
        if method == "protobuf":
            self._load_operation_frozen_graph(tf_model_path)
        elif method == "saved_model":
            raise NotImplementedError("Outdated format. Use keras based model")
            # TODO Handling tags and signatures which is customized and default is different up to TF version.
            # self._load_operation_saved_model(tf_model_path)
        elif method == "meta":
            self._load_operation_ckpt(tf_model_path)
        elif method == "keras":
            self._load_operation_keras(tf_model_path)
        self.sess = tf1.InteractiveSession(graph=self.graph)
        """
        Using tf_input_dict and tf_output_dict, layers with multiple output tensor can be split to multiple layers with single output.
        But if layers split from single layer cannot have operation type which is already defined in make_model_dict, 
            You need to implement new operations which is not recommended.
        """
        self.operations = self.graph.get_operations()
        self.tf_input_dict = {}
        self.tf_output_dict = {}
        self.compiletime_shape_dict = {}
        for node in self.operations:
            layer_name = node.node_def.name
            self.tf_input_dict[layer_name] = [x.name for x in node.inputs]
            self.tf_output_dict[layer_name] = []
            for tensor in node.outputs:
                self.tf_output_dict[layer_name].append(tensor.name)
                try:
                    shape = tensor.shape.as_list()
                except:
                    continue
                if len(shape) > 0:
                    shape = [s if s is not None else 0 for s in shape]
                self.compiletime_shape_dict[tensor.name] = shape

        # Set model input/output list.
        # FIXME Assume that model's input has only type `Placeholder`.
        self.input_list = []
        self.input_type_list = []
        self.input_shape_list = []
        total_layer_list = []
        used_layer_list = []
        for node in self.operations:
            layer_name = node.node_def.name
            input_list = node.node_def.input
            # if node.node_def.op != "Const" and len(node.node_def.input) == 0:
            if node.node_def.op == "Placeholder":
                # Set Input layer here, not in `make_layer_dict`
                assert len(input_list) == 0, "Placeholder has input layer."
                elem_type = tf.as_dtype(node.node_def.attr["dtype"].type).name
                shape = [
                    shape_dim.size
                    for shape_dim in node.node_def.attr["shape"].shape.dim
                ]
                if len(shape) == 0:
                    if elem_type == "bool":
                        logger.warning(
                            "Input with dtype `bool` is not supported currently. Will use False as default."
                        )
                    # No input shape is set in mode.
                    else:
                        raise ValueError(
                            "Input of TF model does not have shape information. Current layer name = {}".format(
                                layer_name
                            )
                        )
                new_input_shape = check_new_input_shape(
                    self.input_shape_dict, shape, layer_name
                )
                if len(shape) > 0:
                    if shape[0] <= 0:  # Batch Dimension
                        shape[0] = 1
                    for i in range(1, len(shape)):
                        if shape[i] <= 0:
                            if new_input_shape is None:
                                logger.warning(
                                    f"No User Input Shape specified at dim {i}. Use 300 as Default."
                                )
                                shape[i] = 300
                            else:
                                shape[i] = new_input_shape[i]
                self.input_list.append(layer_name)
                self.input_type_list.append(elem_type)
                self.input_shape_list.append(shape)
            total_layer_list.append(layer_name)
            used_layer_list.extend(input_list)
        self.src_output_list = list(set(total_layer_list) - set(used_layer_list))

        # Set Tensorflow input_tensor
        if self.tf_feed_dict is not None:
            for input_name, input_dtype, input_shape in zip(
                self.input_list, self.input_type_list, self.input_shape_list
            ):
                tf_output_name = self.tf_output_dict[input_name][0]
                if tf_output_name not in self.tf_feed_dict:
                    logger.warning(
                        f"Input Tensor named {tf_output_name} does not exist in feed_dict. Reset Randomly..."
                    )
                    self.make_random_feed_tensor(
                        tf_output_name, input_shape, input_dtype
                    )
                    continue
                if any(
                    [
                        x != y
                        for x, y in zip(
                            input_shape, self.tf_feed_dict[tf_output_name].shape
                        )
                    ]
                ):
                    # For this case, should raise error? or printing warning and set new tensor randomly?
                    logger.warning(
                        f"Input Tensor named {tf_output_name} has different shape with layer_dict's shape. Reset Randomly..."
                    )
                    self.make_random_feed_tensor(
                        tf_output_name, input_shape, input_dtype
                    )
                    continue
                existing_input_dtype = self.tf_feed_dict[tf_output_name].dtype.name
                if existing_input_dtype != input_dtype:
                    try:
                        self.tf_feed_dict[tf_output_name] = self.tf_feed_dict[
                            tf_output_name
                        ].astype(input_dtype)
                        logger.warning(
                            f"Data type of Input Tensor named {tf_output_name} Changed to {input_dtype}"
                        )
                    except:
                        logger.warning(
                            f"Cannot change Data type of Input Tensor named {tf_output_name}. Reset Randomly..."
                        )
                        self.make_random_feed_tensor(
                            tf_output_name, input_shape, input_dtype
                        )
                        continue
        else:
            self.tf_feed_dict = {}
            for input_name, input_dtype, input_shape in zip(
                self.input_list, self.input_type_list, self.input_shape_list
            ):
                tf_output_name = self.tf_output_dict[input_name][0]
                self.make_random_feed_tensor(tf_output_name, input_shape, input_dtype)

    def is_dynamic_shape(self, compiletime_shape_dict, layer_name):
        """
        Check if the compile-time shape of the given layer is dynamic.

        Args:
            compiletime_shape_dict (Dict[str, List[int]]): A dictionary
                where keys are layer output names and values are
                lists of integers representing their static shapes.

        Returns:
            bool: True if the shape of the given layer is dynamic, False otherwise.
        """
        for tensor_name in self.tf_output_dict[layer_name]:
            shape = compiletime_shape_dict.get(tensor_name, None)
            if shape is None:
                return False
            for i, dim in enumerate(shape):
                if dim == 0:  # dynamic dimension
                    # TODO(Kanye): come up with a better way to handle batch dimension
                    if (
                        i == 0 and len(shape) > 1
                    ):  # it is batch dimension, so exclude it
                        continue
                    return True
        return False

    def is_dynamic(self, layer_name):
        # FIXME How to deal with layers made from node which has different name with its corresponding layer info?
        input_list = get_input_list(self.layer_dict[layer_name])
        for input_name in input_list:
            if input_name not in self.layer_dict:  # input is a constant
                continue

            if all(
                [
                    tensor_name not in self.compiletime_shape_dict
                    for tensor_name in self.tf_output_dict[input_name]
                ]
            ):
                return ValueError(
                    f"Error. {input_name} does not exist in compiletime_shape_dict."
                )

            if self.is_dynamic_shape(self.compiletime_shape_dict, input_name):
                return True

            if self.layer_dict[input_name].get("is_dynamic", False):
                return True
        return False

    def make_layer_dict(self):
        self.layer_dict = {}

        # input_tensor
        for i, layer_name in enumerate(self.input_list):
            self.layer_dict[layer_name] = {}
            self.layer_dict[layer_name]["type"] = "input"
            self.layer_dict[layer_name]["shape"] = self.input_shape_list[i]
            self.layer_dict[layer_name]["src_shape"] = self.input_shape_list[i]
            self.layer_dict[layer_name]["elem_type"] = self.input_type_list[i]
            self.layer_dict[layer_name]["is_dynamic"] = self.is_dynamic_shape(
                self.compiletime_shape_dict, layer_name
            )  # set is_dynamic attribute for input layer

        # operations
        unknown_layers = {}
        for node in self.operations:
            if node.node_def.name in self.input_list:
                continue
            self.parse_node(node, unknown_layers)

        # In TF parsing, it could be happend that layer name is not matched with node's name directly.
        for layer_name in self.layer_dict:
            self.layer_dict[layer_name]["is_dynamic"] = self.is_dynamic(
                layer_name
            )  # set is_dynamic attribute

        # Because TF has too many layer operations which is not supported yet, print it later.
        for k, v in unknown_layers.items():
            print(f"There is an unknown operation {k}.")
            print("\tNumber of layers: {}".format(len(v)))
            print()

    def parse_node(self, node, unknown_layers):
        layerop = node.node_def.op
        if layerop == "Placeholder":
            # self.parse_placeholder(node)
            raise ValueError(
                "Placeholder layer should be made before parse_node is called. layer_name = {}".format(
                    node.node_def.op
                )
            )
        elif layerop in [
            "PlaceholderWithDefault",
            "Identity",
            "Floor",
            "Ceil",
            "Size",
            "Rank",
            "StopGradient",
            "Round",
        ]:  # Simple Operation with single input
            self.parse_simple_1(node)
        elif layerop == "Const":
            self.parse_const(node)
        elif layerop == "IdentityN":
            self.parse_identityN(node)
        elif layerop in ["Pad", "PadV2"]:
            self.parse_pad(node)
        elif layerop == "Conv2D":
            self.parse_conv2d(node)
        elif layerop == "DepthwiseConv2dNative":
            self.parse_dwconv2d(node)
        elif layerop == "Conv2DBackpropInput":
            self.parse_tconv2d(node)
        elif layerop in ["MatMul", "BatchMatMul", "BatchMatMulV2", "BatchMatMulV3"]:
            self.parse_matmul(node)
        elif layerop in ["FusedBatchNormV3", "FusedBatchNormV2", "FusedBatchNorm"]:
            self.parse_bn2d(node)
        elif layerop == "MaxPool":
            self.parse_maxpool2d(node)
        elif layerop == "AvgPool":
            self.parse_avgpool2d(node)
        elif layerop in ["Mean", "Sum", "Max", "Min", "Prod"]:
            self.parse_reduce(node, layerop)
        elif layerop in ["ResizeNearestNeighbor", "ResizeBilinear"]:
            self.parse_resize(node)
        elif layerop == "ConcatV2":
            self.parse_concate(node)
        elif layerop in [
            "Add",
            "AddV2",
            "Mul",
            "Sub",
            "RealDiv",
            "Div",
            "FloorDiv",
            "FloorMod",
            "Mod",
            "TruncateMod",
        ]:  # Simple math operation with 2 inputs
            self.parse_simple_2(node)
        elif layerop in ["AddN"]:
            self.parse_addN(node)
        elif layerop == "BiasAdd":
            self.parse_biasadd(node)
        elif layerop in [
            "Relu",
            "Sigmoid",
            "Softplus",
            "Exp",
            "Tanh",
            "Neg",
            "Inverse",
            "Reciprocal",
        ]:  # Simple activation Operation with single input
            self.parse_simple_1(node)
        elif layerop == "LeakyRelu":
            self.parse_leakyrelu(node)
        elif layerop == "Relu6":
            self.parse_relu6(node)
        elif layerop == "Softmax":
            self.parse_softmax(node)
        elif layerop == "ArgMax":
            self.parse_argmax(node)
        elif layerop == "Switch":
            self.parse_switch(node)
        elif layerop == "Merge":
            self.parse_merge(node)
        elif layerop == "Shape":
            self.parse_simple_1(node)
        elif layerop == "Reshape":
            self.parse_reshape(node)
        elif layerop == "Transpose":
            self.parse_transpose(node)
        elif layerop == "ExpandDims":
            self.parse_expanddims(node)
        elif layerop == "Squeeze":
            self.parse_squeeze(node)
        elif layerop == "StridedSlice":
            self.parse_stridedslice(node)
        elif layerop == "Slice":
            self.parse_slice(node)
        elif layerop == "Pack":
            self.parse_pack(node)
        elif layerop == "Split":
            self.parse_split(node)
        elif layerop == "SplitV":
            self.parse_splitv(node)
        elif layerop == "Range":
            self.parse_range(node)
        elif layerop == "Fill":
            self.parse_fill(node)
        elif layerop == "Tile":
            self.parse_tile(node)
        elif layerop == "Cast":
            self.parse_cast(node)
        elif layerop == "TensorArrayV3":
            self.parse_tensorarray(node)
        elif layerop == "TensorArrayReadV3":
            self.parse_tensorarray_read(node)
        elif layerop == "TensorArrayWriteV3":
            self.parse_tensorarray_write(node)
        elif layerop == "TensorArraySizeV3":
            self.parse_tensorarray_size(node)
        elif layerop == "TensorArrayGatherV3":
            self.parse_tensorarray_gather(node)
        elif layerop == "TensorArrayScatterV3":
            self.parse_tensorarray_scatter(node)
        elif layerop == "Maximum":
            self.parse_maximum(node)
        elif layerop in ["Sqrt", "Rsqrt", "Rint", "Sign", "Abs", "Erf"]:
            self.parse_simple_1(node)
        elif layerop in ["Gather", "GatherV2"]:
            self.parse_gather(node)
        elif layerop == "GatherNd":
            self.parse_gathernd(node)
        elif layerop in [
            "LogicalAnd",
            "Equal",
            "Greater",
            "GreaterEqual",
            "Less",
            "LessEqual",
            "Minimum",
            "SquaredDifference",
        ]:
            self.parse_simple_2(node)
        elif layerop == "RandomUniform":
            self.parse_rand(node)
        elif layerop == "All":
            self.parse_all(node)
        elif layerop == "TopKV2":
            self.parse_topk(node)
        elif layerop == "ZerosLike":
            self.parse_zeros_like(node)
        elif layerop == "Unpack":
            self.parse_unpack(node)
        elif layerop in ["Where", "Select", "SelectV2"]:
            self.parse_simple_1(node)
        elif layerop == "OneHot":
            self.parse_onehot(node)
        elif layerop == "Pow":
            self.parse_pow(node)
        elif layerop == "SpaceToBatchND":
            self.parse_space_to_batch(node)
        elif layerop == "BatchToSpaceND":
            self.parse_batch_to_space(node)
        elif layerop in ["Enter", "Exit", "LoopCond", "NextIteration"]:
            # Loop can be pre/post and is not supported yet.
            # Need to Raise Error (TODO: How to deal with it?)
            raise ValueError("While Loop of TF cannot be handled currently.")
        elif layerop in [
            "NonMaxSuppression",
            "NonMaxSuppressionV2",
            "NonMaxSuppressionV3",
        ]:
            self.parse_nms(node)
        elif layerop == "NonMaxSuppressionV4":
            self.parse_nms_double(node)
        elif layerop == "NonMaxSuppressionV5":
            self.parse_nms_multi(node)
        elif layerop in ["BroadcastTo", "BroadcastArgs"]:
            self.parse_simple_2(node)
        elif layerop in ["NoOp", "Assert", "ReadFile", "DecodeJpeg"]:
            # No need to set.
            pass
        else:
            if layerop in unknown_layers:
                unknown_layers[layerop].append(node.node_def.name)
            else:
                unknown_layers[layerop] = [node.node_def.name]
            self.parse_default(node)

    def make_const_dict(self):
        def are_inputs_constant(input_list, layer_dict, const_dict):
            """Check if all inputs are constant"""
            for input_name in input_list:
                if input_name not in const_dict:
                    if input_name not in layer_dict:
                        continue
                    return False
            return True

        # make const dict from operations
        self.const_dict = {}
        const_type_list = [
            "Constant",
            "Shape",
            "RandomConst",
            "ZerosLike",
            "Fill",
            "Range",
        ]

        is_changed = True
        while is_changed:
            is_changed = False
            for layer_name in list(self.layer_dict.keys()):
                layertype = self.layer_dict[layer_name]["type"]
                input_list = get_input_list(self.layer_dict[layer_name])
                is_const = are_inputs_constant(
                    input_list, self.layer_dict, self.const_dict
                )

                if layertype in ["input"]:
                    continue
                if layertype in const_type_list:
                    self.const_dict[layer_name] = {}
                    self.const_dict[layer_name]["type"] = layertype
                    if layertype == "Constant":
                        self.const_dict[layer_name]["value"] = self.layer_dict[
                            layer_name
                        ]["value"]
                    del self.layer_dict[layer_name]
                    continue
                if is_const:
                    self.const_dict[layer_name] = {}
                    self.const_dict[layer_name]["type"] = layertype
                    del self.layer_dict[layer_name]
                    is_changed = True
                    continue

    def parse_placeholder(self, node):
        """
        To match logical flow with ONNX Model Dict and compute `make_compiletime_shape_dict` in `load_operations`,
        Logics below is moved to `load_operations`.
        """
        layer_name = node.node_def.name
        dtype = tf.as_dtype(node.node_def.attr["dtype"].type).name
        shape = [shape_dim.size for shape_dim in node.node_def.attr["shape"].shape.dim]
        if len(shape) == 0:
            pass
        else:
            new_input_shape = check_new_input_shape(
                self.input_shape_dict, shape, layer_name
            )
            if shape[0] <= 0:  # Batch Dimension
                shape[0] = 1
            for i in range(1, len(shape)):
                if shape[i] <= 0:
                    if new_input_shape is None:
                        logger.warning(
                            f"No User Input Shape specified at dim {i}. Use 100 as Default."
                        )
                        shape[i] = 100
                    else:
                        shape[i] = new_input_shape[i]
        self.layer_dict[layer_name] = {
            "type": "input",
            "dtype": dtype,
            "shape": shape,
            "src_shape": shape,
        }

    def parse_const(self, node):
        layer_name = node.node_def.name
        value = tf_fw.tensor_util.MakeNdarray(node.node_def.attr["value"].tensor)
        self.layer_dict[layer_name] = {"type": "Constant", "value": value}

    def parse_identityN(self, node):
        layer_name = node.node_def.name
        input_name_list = list(node.node_def.input)

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "IdentityN"
        self.layer_dict[layer_name]["input"] = input_name_list

    def parse_pad(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        pad_name = node.node_def.input[1]
        constant = 0
        if node.node_def.op == "PadV2":
            constant = node.node_def.input[2]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Pad"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["pad"] = pad_name
        self.layer_dict[layer_name]["pad_mode"] = "constant"
        self.layer_dict[layer_name]["constant"] = constant

    def parse_conv2d(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        weight_name = node.node_def.input[1]
        data_format_str = str(node.node_def.attr["data_format"].s)[2:-1]
        data_format = parse_data_format_str(data_format_str)
        H, W, C = get_HWC_indices(data_format)

        d_h = node.node_def.attr["dilations"].list.i[H]
        d_w = node.node_def.attr["dilations"].list.i[W]
        s_h = node.node_def.attr["strides"].list.i[H]
        s_w = node.node_def.attr["strides"].list.i[W]

        tf_pad_mode = str(node.node_def.attr["padding"].s)[2:-1]
        if tf_pad_mode == "EXPLICIT":
            padding_list = node.node_def.attr["explicit_paddings"].list.i

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Convolution"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["w_stride"] = s_w
        self.layer_dict[layer_name]["h_stride"] = s_h
        self.layer_dict[layer_name]["w_dilation"] = d_w
        self.layer_dict[layer_name]["h_dilation"] = d_h
        self.layer_dict[layer_name]["data_format"] = data_format
        self.layer_dict[layer_name]["tf_pad_mode"] = tf_pad_mode
        self.layer_dict[layer_name]["weight"] = weight_name
        self.layer_dict[layer_name]["bias"] = None
        self.layer_dict[layer_name]["group_number"] = None
        if tf_pad_mode == "EXPLICIT":
            self.layer_dict[layer_name]["padding_list"] = padding_list
        else:
            self.layer_dict[layer_name]["padding_list"] = [[0, 0]] * 4
        self.layer_dict[layer_name]["activation"] = None

    def parse_dwconv2d(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        weight_name = node.node_def.input[1]
        data_format_str = str(node.node_def.attr["data_format"].s)[2:-1]
        data_format = parse_data_format_str(data_format_str)
        H, W, C = get_HWC_indices(data_format)

        d_h = node.node_def.attr["dilations"].list.i[H]
        d_w = node.node_def.attr["dilations"].list.i[W]
        s_h = node.node_def.attr["strides"].list.i[H]
        s_w = node.node_def.attr["strides"].list.i[W]

        tf_pad_mode = str(node.node_def.attr["padding"].s)[2:-1]
        if tf_pad_mode == "EXPLICIT":
            padding_list = node.node_def.attr["explicit_paddings"].list.i

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "DepthwiseConvolution"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["w_stride"] = s_w
        self.layer_dict[layer_name]["h_stride"] = s_h
        self.layer_dict[layer_name]["w_dilation"] = d_w
        self.layer_dict[layer_name]["h_dilation"] = d_h
        self.layer_dict[layer_name]["data_format"] = data_format
        self.layer_dict[layer_name]["tf_pad_mode"] = tf_pad_mode
        self.layer_dict[layer_name]["weight"] = weight_name
        self.layer_dict[layer_name]["bias"] = None
        self.layer_dict[layer_name]["group_number"] = None
        if tf_pad_mode == "EXPLICIT":
            self.layer_dict[layer_name]["padding_list"] = padding_list
        else:
            self.layer_dict[layer_name]["padding_list"] = [[0, 0]] * 4
        self.layer_dict[layer_name]["activation"] = None

    def parse_tconv2d(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[2]
        weight_name = node.node_def.input[1]
        output_size_name = node.node_def.input[0]
        data_format_str = str(node.node_def.attr["data_format"].s)[2:-1]
        data_format = parse_data_format_str(data_format_str)
        H, W, C = get_HWC_indices(data_format)

        d_h = node.node_def.attr["dilations"].list.i[H]
        d_w = node.node_def.attr["dilations"].list.i[W]
        s_h = node.node_def.attr["strides"].list.i[H]
        s_w = node.node_def.attr["strides"].list.i[W]

        tf_pad_mode = str(node.node_def.attr["padding"].s)[2:-1]
        if tf_pad_mode == "EXPLICIT":
            padding_list = node.node_def.attr["explicit_paddings"].list.i

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "TransposeConvolution"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["w_stride"] = s_w
        self.layer_dict[layer_name]["h_stride"] = s_h
        self.layer_dict[layer_name]["w_dilation"] = d_w
        self.layer_dict[layer_name]["h_dilation"] = d_h
        self.layer_dict[layer_name]["data_format"] = data_format
        self.layer_dict[layer_name]["tf_pad_mode"] = tf_pad_mode
        self.layer_dict[layer_name]["weight"] = weight_name
        self.layer_dict[layer_name]["bias"] = None
        self.layer_dict[layer_name]["group_number"] = None
        if tf_pad_mode == "EXPLICIT":
            self.layer_dict[layer_name]["padding_list"] = padding_list
        else:
            self.layer_dict[layer_name]["padding_list"] = [[0, 0]] * 4
        self.layer_dict[layer_name]["activation"] = None
        self.layer_dict[layer_name]["output_size"] = output_size_name

    def parse_matmul(self, node):
        """
        NOTE(JM): make model 단계에서 broadcasting 가능한 다른 케이스들도 커버 가능하게 되므로, MatMul, BatchMatMul, BatchMatMulV2, BatchMatMulV3 모두 MatMul로 통합
        """
        layer_name = node.node_def.name
        input_name_0 = node.node_def.input[0]
        input_name_1 = node.node_def.input[1]

        transpose_a = node.node_def.attr["transpose_a"].b
        transpose_b = node.node_def.attr["transpose_b"].b

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name][
            "type"
        ] = "MatMul"  # make model dict에서 convolution으로 변경
        self.layer_dict[layer_name]["input0"] = input_name_0
        self.layer_dict[layer_name]["input1"] = input_name_1
        self.layer_dict[layer_name]["activation"] = None
        self.layer_dict[layer_name]["transpose_input"] = transpose_a
        self.layer_dict[layer_name]["transpose_weight"] = transpose_b

    def parse_bn2d(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        is_training = node.node_def.attr["is_training"].b

        gamma_name = node.node_def.input[1]
        beta_name = node.node_def.input[2]
        moving_mean_name = node.node_def.input[3]
        moving_var_name = node.node_def.input[4]

        eps = node.node_def.attr["epsilon"].f

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Batchnorm"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["training_mode"] = is_training
        self.layer_dict[layer_name]["gamma"] = gamma_name
        self.layer_dict[layer_name]["beta"] = beta_name
        self.layer_dict[layer_name]["moving_mean"] = moving_mean_name
        self.layer_dict[layer_name]["moving_var"] = moving_var_name
        self.layer_dict[layer_name]["epsilon"] = eps

    def parse_maxpool2d(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        data_format_str = str(node.node_def.attr["data_format"].s)[2:-1]
        data_format = parse_data_format_str(data_format_str)
        H, W, C = get_HWC_indices(data_format)

        k_h = node.node_def.attr["ksize"].list.i[H]
        k_w = node.node_def.attr["ksize"].list.i[W]
        s_h = node.node_def.attr["strides"].list.i[H]
        s_w = node.node_def.attr["strides"].list.i[W]

        tf_pad_mode = str(node.node_def.attr["padding"].s)[2:-1]
        if tf_pad_mode == "EXPLICIT":
            padding_list = list(node.node_def.attr["explicit_paddings"].list.i)
            padding_list = [int(i) for i in padding_list]

        # default setting of ONNX for Matching with ONNX Layer Dict.
        ceil_mode = 0

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "MaxPool"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["w_kernel"] = k_w
        self.layer_dict[layer_name]["h_kernel"] = k_h
        self.layer_dict[layer_name]["w_stride"] = s_w
        self.layer_dict[layer_name]["h_stride"] = s_h
        self.layer_dict[layer_name]["w_dilation"] = 1
        self.layer_dict[layer_name]["h_dilation"] = 1
        self.layer_dict[layer_name]["is_ceil_mode"] = ceil_mode
        self.layer_dict[layer_name]["data_format"] = data_format
        self.layer_dict[layer_name]["tf_pad_mode"] = tf_pad_mode
        if tf_pad_mode == "EXPLICIT":
            self.layer_dict[layer_name]["padding_list"] = padding_list
        else:
            self.layer_dict[layer_name]["padding_list"] = None
        self.layer_dict[layer_name]["activation"] = None

    def parse_avgpool2d(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        data_format_str = str(node.node_def.attr["data_format"].s)[2:-1]
        data_format = parse_data_format_str(data_format_str)
        H, W, C = get_HWC_indices(data_format)

        k_h = node.node_def.attr["ksize"].list.i[H]
        k_w = node.node_def.attr["ksize"].list.i[W]
        s_h = node.node_def.attr["strides"].list.i[H]
        s_w = node.node_def.attr["strides"].list.i[W]

        tf_pad_mode = str(node.node_def.attr["padding"].s)[2:-1]
        if tf_pad_mode == "EXPLICIT":
            padding_list = list(node.node_def.attr["explicit_paddings"].list.i)
            padding_list = [int(i) for i in padding_list]

        # default setting of ONNX for Matching with ONNX Layer Dict.
        ceil_mode = 0  # default = floor

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "AvgPool"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["w_kernel"] = k_w
        self.layer_dict[layer_name]["h_kernel"] = k_h
        self.layer_dict[layer_name]["w_stride"] = s_w
        self.layer_dict[layer_name]["h_stride"] = s_h
        self.layer_dict[layer_name]["is_ceil_mode"] = ceil_mode
        self.layer_dict[layer_name]["data_format"] = data_format
        self.layer_dict[layer_name]["tf_pad_mode"] = tf_pad_mode
        if tf_pad_mode == "EXPLICIT":
            self.layer_dict[layer_name]["padding_list"] = padding_list
        else:
            self.layer_dict[layer_name]["padding_list"] = None
        self.layer_dict[layer_name]["count_include_pad"] = False
        self.layer_dict[layer_name]["activation"] = None

    def parse_reduce(self, node, reduction_type: str):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        reduction_name = node.node_def.input[1]  # reduction indices

        keep_dims = node.node_def.attr["keep_dims"].b

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Reduce" + reduction_type
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["reduce_axes"] = reduction_name
        self.layer_dict[layer_name]["keep_dims"] = keep_dims
        self.layer_dict[layer_name]["noop_with_empty_axes"] = 0

    def parse_resizenearest(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        size_name = node.node_def.input[1]

        align_corners = node.node_def.attr["align_corners"].b
        half_pixel_centers = node.node_def.attr["half_pixel_centers"].b

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name][
            "type"
        ] = "ResizeNearest"  # make model dict에서 upsample로 변환
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["size"] = size_name
        self.layer_dict[layer_name]["align_corners"] = align_corners
        self.layer_dict[layer_name]["half_pixel_centers"] = half_pixel_centers

    def parse_resize(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        sizes_name = node.node_def.input[1]
        if node.node_def.op == "ResizeNearestNeighbor":
            resize_mode = "nearest"
        elif node.node_def.op == "ResizeBilinear":
            resize_mode = "linear"
        else:
            raise ValueError(f"Invalid operation type for resize; {node.node_def.op}")

        # Set attribute for ONNX Resize Operation as default following Onnx_dict.
        scales_name = None
        roi_name = None
        cubic_coeff_a = 0.75
        exclude_outside = 0
        extrapolation_value = 0.0
        nearest_mode = "round_prefer_floor"
        transform_mode = None
        nearest_mode = None
        antialias = 0
        axes = None
        keep_aspect_ratio_policy = "stretch"

        align_corners = node.node_def.attr["align_corners"].b
        half_pixel = node.node_def.attr["half_pixel_centers"].b
        if not align_corners and not half_pixel:
            transform_mode = "asymmetric"
            nearest_mode = "floor"
        elif align_corners and not half_pixel:
            transform_mode = "align_corners"
            nearest_mode = "round_prefer_ceil"
        elif not align_corners and half_pixel:
            if resize_mode == "nearest":
                transform_mode = "tf_half_pixel_for_nn"
            elif resize_mode == "linear":
                transform_mode = "half_pixel"
            nearest_mode = "floor"
        else:
            if resize_mode == "nearest":
                transform_mode = "tf_half_pixel_for_nn"
            elif resize_mode == "linear":
                transform_mode = "half_pixel"
            nearest_mode = "round_prefer_ceil"

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Resize"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["roi"] = roi_name
        self.layer_dict[layer_name]["scales"] = scales_name
        self.layer_dict[layer_name]["sizes"] = sizes_name
        self.layer_dict[layer_name]["resize_mode"] = resize_mode
        self.layer_dict[layer_name]["nearest_mode"] = nearest_mode
        self.layer_dict[layer_name]["transform_mode"] = transform_mode
        self.layer_dict[layer_name]["cubic_coeff_a"] = cubic_coeff_a
        self.layer_dict[layer_name]["exclude_outside"] = exclude_outside
        self.layer_dict[layer_name]["extrapolation_value"] = extrapolation_value
        self.layer_dict[layer_name]["antialias"] = antialias
        self.layer_dict[layer_name]["axes"] = axes
        self.layer_dict[layer_name][
            "keep_aspect_ratio_policy"
        ] = keep_aspect_ratio_policy

    def parse_concate(self, node):
        layer_name = node.node_def.name
        num_input = node.node_def.attr["N"].i
        input_name_list = node.node_def.input[:num_input]
        axis_name = node.node_def.input[num_input]

        self.layer_dict[layer_name] = {}
        if len(input_name_list) == 1:
            self.layer_dict[layer_name]["type"] = "Identity"
            self.layer_dict[layer_name]["input"] = input_name_list[0]
        else:
            self.layer_dict[layer_name]["type"] = "Concatenate"
            self.layer_dict[layer_name]["input"] = input_name_list
            self.layer_dict[layer_name]["original_axis"] = axis_name

    def parse_addN(self, node):
        layer_name = node.node_def.name
        num_input = node.node_def.attr["N"].i
        input_name_list = node.node_def.input[:num_input]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "addN"  # addN is equivalent to ONNX Sum
        self.layer_dict[layer_name]["input"] = input_name_list

    def parse_biasadd(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        bias_name = node.node_def.input[1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "BiasAdd"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["bias"] = bias_name
        self.layer_dict[layer_name]["input1"] = bias_name
        self.layer_dict[layer_name]["keep_dims"] = 0  # keep_dims is not supported on TF

    def parse_leakyrelu(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        leaky_alpha = node.node_def.attr["alpha"].f

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "LeakyRelu"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["leaky_alpha"] = leaky_alpha

    def parse_relu6(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Clip"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["clip_max_value"] = 6
        self.layer_dict[layer_name]["clip_min_value"] = 0

    def parse_softmax(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        axis = -1
        """
        tensorflow::ops::Softmax calculates softmax activations for each batch && class (Channel)
        """

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Softmax"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["axis"] = axis

    def parse_argmax(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        dim_name = node.node_def.input[1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "ArgMax"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["axis"] = dim_name
        self.layer_dict[layer_name]["keepdims"] = 0
        self.layer_dict[layer_name]["select_last"] = 0

    def parse_switch(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        pred_name = node.node_def.input[1]
        output_false, output_true = self.tf_output_dict[layer_name]
        output_false_name, output_true_name = None, None
        # Find output layer whose input is output_false tensor and output_true tensor.
        for name in self.tf_input_dict:
            if output_false in self.tf_input_dict[name]:
                output_false_name = name
            if output_true in self.tf_input_dict[name]:
                output_true_name = name

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Switch"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["pred"] = pred_name
        self.layer_dict[layer_name]["output_false"] = output_false_name
        self.layer_dict[layer_name]["output_true"] = output_true_name

    def parse_merge(self, node):
        layer_name = node.node_def.name
        num_input = node.node_def.attr["N"].i
        input_tensor_list = node.node_def.input[:num_input]
        # Convert all those case to its representative output tensor name to identify which input is valid.
        for i in range(len(input_tensor_list)):
            if input_tensor_list[i] in self.tf_output_dict:
                input_tensor_list[i] = self.tf_output_dict[input_tensor_list[i]][0]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Merge"
        self.layer_dict[layer_name]["input"] = input_tensor_list

    def parse_reshape(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        shape_name = node.node_def.input[1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Reshape"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["shape"] = shape_name
        self.layer_dict[layer_name]["allowzero"] = 0

    def parse_transpose(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        tperm_name = node.node_def.input[1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Transpose"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["transpose_axes"] = tperm_name

    def parse_expanddims(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        expand_name = node.node_def.input[1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "ExpandDims"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["expand"] = expand_name

    def parse_squeeze(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        squeeze_dims = list(node.node_def.attr["squeeze_dims"].list.i)
        if len(squeeze_dims) == 0:
            squeeze_dims = None

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Squeeze"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["squeeze_axes"] = squeeze_dims

    def parse_stridedslice(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        begin_name = node.node_def.input[1]  # list of int, could be minus
        end_name = node.node_def.input[2]  # list of int, could be minus
        try:
            stride_name = node.node_def.input[
                3
            ]  # list of int, clamped to [0, dim[i]) if slice[i] > 0, [-1, dim[i]-1] if slice[i] < 0
        except:
            stride_name = None

        begin_mask = node.node_def.attr[
            "begin_mask"
        ].i  # when i번째 bit=1, ignore begin[i]
        end_mask = node.node_def.attr["end_mask"].i  # when i번째 bit=1, ignore end[i]
        ellipsis_mask = node.node_def.attr[
            "ellipsis_mask"
        ].i  # when i번째 bit=1, ignore i번째 dim and take full slice
        new_axis_mask = node.node_def.attr[
            "new_axis_mask"
        ].i  # when i번째 bit=1, 새로운 axis 추가
        shrink_axis_mask = node.node_def.attr[
            "shrink_axis_mask"
        ].i  # when i번째 bit=1, 기존 axis 제거

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "StridedSlice"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["start"] = begin_name
        self.layer_dict[layer_name]["end"] = end_name
        self.layer_dict[layer_name]["step"] = stride_name
        self.layer_dict[layer_name]["begin_mask"] = begin_mask
        self.layer_dict[layer_name]["end_mask"] = end_mask
        # For unsupported operation apply, add attributes about additional masks.
        self.layer_dict[layer_name]["ellipsis_mask"] = ellipsis_mask
        self.layer_dict[layer_name]["new_axis_mask"] = new_axis_mask
        self.layer_dict[layer_name]["shrink_axis_mask"] = shrink_axis_mask
        self.layer_dict[layer_name]["axis"] = None

    def parse_slice(self, node):
        # This Operation is used at TensorFlow 1.0.
        # Currently Deprecated.
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        begin_name = node.node_def.input[1]
        size_name = node.node_def.input[2]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Slice_Old"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["begin"] = begin_name
        self.layer_dict[layer_name]["size"] = size_name

    def parse_pack(self, node):
        # == torch.stack
        layer_name = node.node_def.name
        input_name_list = list(node.node_def.input)
        axis = node.node_def.attr["axis"].i  # [-(R+1), R+1)

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Pack"
        self.layer_dict[layer_name]["input"] = input_name_list
        self.layer_dict[layer_name]["axis"] = axis

    def parse_split(self, node):
        layer_name = node.node_def.name
        split_dim_name = node.node_def.input[0]
        input_name = node.node_def.input[1]
        num_split = node.node_def.attr["num_split"].i
        output_tensor_names = self.tf_output_dict[layer_name]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Split"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name][
            "split"
        ] = None  # For Split op, there is no information for size of each split.
        self.layer_dict[layer_name]["axis"] = split_dim_name
        self.layer_dict[layer_name]["num_outputs"] = num_split
        self.layer_dict[layer_name]["split_index"] = 0
        self.tf_output_dict[layer_name] = [output_tensor_names[0]]
        for i in range(1, num_split):
            temp_layer_name = layer_name + ":" + str(i)
            self.layer_dict[temp_layer_name] = {}
            self.layer_dict[temp_layer_name]["type"] = "Split"
            self.layer_dict[temp_layer_name]["input"] = input_name
            self.layer_dict[temp_layer_name]["split"] = None
            self.layer_dict[temp_layer_name]["axis"] = split_dim_name
            self.layer_dict[temp_layer_name]["num_outputs"] = num_split
            self.layer_dict[temp_layer_name]["split_index"] = i
            self.tf_input_dict[temp_layer_name] = self.tf_input_dict[layer_name]
            self.tf_output_dict[temp_layer_name] = [output_tensor_names[i]]

    def parse_splitv(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        size_splits_name = node.node_def.input[1]
        split_dim_name = node.node_def.input[2]  # [-rank, rank)
        num_split = node.node_def.attr["num_split"].i
        output_tensor_names = self.tf_output_dict[layer_name]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Split"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["split"] = size_splits_name
        self.layer_dict[layer_name]["axis"] = split_dim_name
        self.layer_dict[layer_name]["num_outputs"] = num_split
        self.layer_dict[layer_name]["split_index"] = 0
        self.tf_output_dict[layer_name] = [output_tensor_names[0]]
        for i in range(1, num_split):
            temp_layer_name = layer_name + ":" + str(i)
            self.layer_dict[temp_layer_name] = {}
            self.layer_dict[temp_layer_name]["type"] = "Split"
            self.layer_dict[temp_layer_name]["input"] = input_name
            self.layer_dict[temp_layer_name]["split"] = size_splits_name
            self.layer_dict[temp_layer_name]["axis"] = split_dim_name
            self.layer_dict[temp_layer_name]["num_outputs"] = num_split
            self.layer_dict[temp_layer_name]["split_index"] = i
            self.tf_input_dict[temp_layer_name] = self.tf_input_dict[layer_name]
            self.tf_output_dict[temp_layer_name] = [output_tensor_names[i]]

    def parse_range(self, node):
        """constant"""
        layer_name = node.node_def.name
        start_name = node.node_def.input[0]
        limit_name = node.node_def.input[1]
        try:
            delta_name = node.node_def.input[2]
        except:
            delta_name = None

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Range"
        self.layer_dict[layer_name]["start"] = start_name
        self.layer_dict[layer_name]["limit"] = limit_name
        self.layer_dict[layer_name]["delta"] = delta_name

    def parse_fill(self, node):
        """constant"""
        layer_name = node.node_def.name
        dim_name = node.node_def.input[0]
        value_name = node.node_def.input[1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Fill"
        self.layer_dict[layer_name]["dim"] = dim_name
        self.layer_dict[layer_name]["value"] = value_name

    def parse_tile(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        multiple_name = node.node_def.input[1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Tile"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["repeats"] = multiple_name

    def parse_cast(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        dst_type = node.node_def.attr["DstT"].type
        src_type = node.node_def.attr["SrcT"].type
        truncate = node.node_def.attr["Truncate"].b  # not used

        dst_type = tf.as_dtype(dst_type)
        src_type = tf.as_dtype(src_type)

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Cast"
        self.layer_dict[layer_name]["input"] = input_name
        # self.layer_dict[layer_name]['src_type'] = src_type
        # self.layer_dict[layer_name]['dst_type'] = dst_type
        # self.layer_dict[layer_name]['truncate'] = truncate
        self.layer_dict[layer_name]["data_type"] = dst_type.name

    def parse_tensorarray(self, node):
        layer_name = node.node_def.name
        shape_name = node.node_def.input[0]
        clear_after_read = node.node_def.attr["clear_after_read"].b
        dynamic_size = node.node_def.attr["dynamic_size"].b
        element_shape = node.node_def.attr["element_shape"].shape
        identical_element_shapes = node.node_def.attr["identical_element_shapes"].b
        tensor_array_name = node.node_def.attr["tensor_array_name"].s

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Tensorarray"
        self.layer_dict[layer_name]["input"] = shape_name
        self.layer_dict[layer_name]["clear_after_read"] = clear_after_read
        self.layer_dict[layer_name]["dynamic_size"] = dynamic_size
        self.layer_dict[layer_name]["element_shape"] = element_shape
        self.layer_dict[layer_name][
            "identical_element_shapes"
        ] = identical_element_shapes
        self.layer_dict[layer_name]["tensor_array_name"] = tensor_array_name

    def parse_tensorarray_read(self, node):
        layer_name = node.node_def.name
        input_name, index_name, flow_name = node.node_def.input
        data_type = tf.as_dtype(node.node_def.attr["dtype"].type).name

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "TensorarrayRead"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["index"] = index_name
        self.layer_dict[layer_name]["flow"] = flow_name
        self.layer_dict[layer_name]["dtype"] = data_type

    def parse_tensorarray_write(self, node):
        layer_name = node.node_def.name
        input_name, index_name, value_name, flow_name = node.node_def.input

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "TensorarrayWrite"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["index"] = index_name
        self.layer_dict[layer_name]["value"] = value_name
        self.layer_dict[layer_name]["flow"] = flow_name

    def parse_tensorarray_size(self, node):
        layer_name = node.node_def.name
        input_name, flow_name = node.node_def.input

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "TensorarraySize"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["flow"] = flow_name

    def parse_tensorarray_gather(self, node):
        layer_name = node.node_def.name
        input_name, index_name, flow_name = node.node_def.input
        data_type = tf.as_dtype(node.node_def.attr["dtype"].type).name
        element_shape = node.node_def.attr["element_shape"].shape

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "TensorarrayGather"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["index"] = index_name
        self.layer_dict[layer_name]["flow"] = flow_name
        self.layer_dict[layer_name]["dtype"] = data_type
        self.layer_dict[layer_name]["gather_shape"] = element_shape

    def parse_tensorarray_scatter(self, node):
        layer_name = node.node_def.name
        input_name, index_name, value_name, flow_name = node.node_def.input

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "TensorarrayScatter"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["index"] = index_name
        self.layer_dict[layer_name]["value"] = value_name
        self.layer_dict[layer_name]["flow"] = flow_name

    def parse_maximum(self, node):
        # Element-wise max valu return
        layer_name = node.node_def.name
        input_name_0 = node.node_def.input[0]
        input_name_1 = node.node_def.input[1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Maximum"
        self.layer_dict[layer_name]["input0"] = input_name_0
        self.layer_dict[layer_name]["input1"] = input_name_1

    def parse_gather(self, node):
        self.parse_simple_2(node)
        layer_name = node.node_def.name
        axis = 0  # default value
        self.layer_dict[layer_name]["axis"] = axis

    def parse_gathernd(self, node):
        self.parse_simple_2(node)
        layer_name = node.node_def.name
        # FIXME Need to find proper projection to ONNX format.
        self.layer_dict[layer_name]["batch_dims"] = 0

    def parse_default(self, node):
        layer_name = node.node_def.name
        input_list = list(node.node_def.input)
        layer_type = node.node_def.op
        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = layer_type
        self.layer_dict[layer_name]["input"] = input_list
        self.layer_dict[layer_name]["is_default"] = True

    def parse_simple_1(self, node):
        layer_name = node.node_def.name
        layer_type = node.node_def.op
        input_name = node.node_def.input[0]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = layer_type
        self.layer_dict[layer_name]["input"] = input_name

        if layer_type == "StopGradient":
            self.layer_dict[layer_name]["type"] = "Identity"
        elif layer_type == "Where":
            self.layer_dict[layer_name]["type"] = "NonZero"
        elif layer_type in ["Select", "SelectV2"]:
            self.layer_dict[layer_name]["type"] = "Where"
        elif layer_type == "Inverse":
            self.layer_dict[layer_name]["type"] = "Reciprocal"

    def parse_simple_2(self, node):
        layer_name = node.node_def.name
        layer_type = node.node_def.op
        input_name_1 = node.node_def.input[0]
        input_name_2 = node.node_def.input[1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = layer_type
        self.layer_dict[layer_name]["input0"] = input_name_1
        self.layer_dict[layer_name]["input1"] = input_name_2

        if layer_type in ["Add", "AddV2"]:
            self.layer_dict[layer_name]["type"] = "Adding"
        elif layer_type == "Mul":
            self.layer_dict[layer_name]["type"] = "Multiply"
        elif layer_type == "RealDiv":
            self.layer_dict[layer_name]["type"] = "Div"
        elif layer_type == "GatherV2":
            self.layer_dict[layer_name]["type"] = "Gather"
        elif layer_type == "GatherNd":
            self.layer_dict[layer_name]["type"] = "GatherND"
        elif layer_type == "Mod":
            self.layer_dict[layer_name]["type"] = "TruncateMod"
        elif layer_type == "GreaterEqual":
            self.layer_dict[layer_name]["type"] = "GreaterOrEqual"
        elif layer_type == "LessEqual":
            self.layer_dict[layer_name]["type"] = "LessOrEqual"

    def parse_rand(self, node):
        layer_name = node.node_def.name
        shape_name = node.node_def.input[0]
        seed = node.node_def.attr["seed"]
        seed2 = node.node_def.attr["seed2"]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "RandomConst"
        self.layer_dict[layer_name]["shape"] = shape_name
        self.layer_dict[layer_name]["seed"] = seed
        self.layer_dict[layer_name]["seed2"] = seed2

    def parse_all(self, node):
        layer_name = node.node_def.name
        layer_type = node.node_def.op
        input_name = node.node_def.input[0]
        index_name = node.node_def.input[1]
        keep_dim = node.node_def.attr["keep_dims"].b

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = layer_type
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["axis"] = index_name
        self.layer_dict[layer_name]["keep_dims"] = keep_dim

    def parse_topk(self, node):
        self.parse_simple_2(node)
        layer_name = node.node_def.name
        largest = True
        axis = -1
        sorted = node.node_def.attr["sorted"].b
        tf_output_list = self.tf_output_dict[layer_name]
        value_name = layer_name
        idx_name = tf_output_list[1]

        layer_info = self.layer_dict.pop(layer_name)
        layer_info["axis"] = axis
        layer_info["largest"] = largest
        layer_info["sorted"] = sorted
        layer_info["type"] = "TopKValues"

        layer_info_2 = copy.deepcopy(layer_info)
        layer_info_2["type"] = "TopKIndices"

        self.layer_dict[value_name] = layer_info
        self.layer_dict[idx_name] = layer_info_2

        self.tf_input_dict[value_name] = self.tf_input_dict[layer_name]
        self.tf_input_dict[idx_name] = self.tf_input_dict[layer_name]
        self.tf_output_dict[value_name] = [tf_output_list[0]]
        self.tf_output_dict[idx_name] = [idx_name]

    def parse_zeros_like(self, node):
        layer_name = node.node_def.name
        ref_name = node.node_def.input[0]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "ZerosLike"
        self.layer_dict[layer_name]["input"] = ref_name

    def parse_unpack(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        axis = node.node_def.attr["axis"].i
        num = node.node_def.attr["num"].i

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Unpack"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["axis"] = axis
        self.layer_dict[layer_name]["num"] = num

    def parse_enter(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        frame_name = node.node_def.attr["frame_name"].s
        is_constant = node.node_def.attr["is_constant"].b
        parallel_iter = node.node_def.attr["parallel_iterations"].i

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Enter"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["frame_name"] = frame_name
        self.layer_dict[layer_name]["is_constant"] = is_constant
        self.layer_dict[layer_name]["parallel_iter"] = parallel_iter

    def parse_exit(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Exit"
        self.layer_dict[layer_name]["input"] = input_name

    def parse_nms(self, node):
        layer_name = node.node_def.name
        input_list = node.node_def.input
        if len(input_list) == 4:  # NMS, V2
            (
                input_boxes,
                input_scores,
                max_output_boxes_per_class,
                iou_threshold,
            ) = node.node_def.input
            score_threshold = None
        elif len(input_list) == 5:  # NMS V3
            (
                input_boxes,
                input_scores,
                max_output_boxes_per_class,
                iou_threshold,
                score_threshold,
            ) = node.node_def.input
        else:
            raise ValueError(
                f"NMS of TF with {len(input_list)} inputs are not implemented yet."
            )
        center_point_box = 0

        self.layer_dict[layer_name] = {
            "type": "NMS",
            "input0": input_boxes,
            "input1": input_scores,
            "max_output": max_output_boxes_per_class,
            "iou_thres": iou_threshold,
            "score_thres": score_threshold,
            "is_center": center_point_box,
        }

    def parse_nms_double(self, node):
        """This NMS returns 2 outputs.
        1. Selected indices of boxes
        2. valid outputs
        """
        layer_name = node.node_def.name
        output_tensor_names = self.tf_output_dict[layer_name]
        assert (
            len(output_tensor_names) == 2
        ), "NMS with multiple output should have 2 outputs. got {}".format(
            len(output_tensor_names)
        )
        idx_tensor_name, num_tensor_name = output_tensor_names
        (
            input_boxes,
            input_scores,
            max_output_boxes_per_class,
            iou_threshold,
            score_threshold,
        ) = node.node_def.input
        pad_to_max_output_size = node.node_def.attr["pad_to_max_output_size"].b
        if pad_to_max_output_size:
            raise ValueError("pad_to_max_output_size in NMS is not supported.")
        center_point_box = 0

        # TF NMS V4 returns three outputs (selected indices, valid outputs)
        # ONNX NMS output is selected indices of shape (N,3) [batch_index, class_index, box_index]
        self.layer_dict[layer_name] = {
            "type": "NMS",
            "input0": input_boxes,
            "input1": input_scores,
            "max_output": max_output_boxes_per_class,
            "iou_thres": iou_threshold,
            "score_thres": score_threshold,
            "is_center": center_point_box,
        }  # selected indices
        self.tf_output_dict[layer_name] = [idx_tensor_name]

        self.layer_dict[num_tensor_name] = {
            "type": "Shape",
            "input": layer_name,
            "start": 0,
            "end": None,
        }  # valid outputs
        self.tf_input_dict[num_tensor_name] = [idx_tensor_name]
        self.tf_output_dict[num_tensor_name] = [num_tensor_name]

    def parse_nms_multi(self, node):
        """
        This NMS returns 3 outputs.
        1. Selected indices of boxes
        2. Selected sorces of boxes
        3. valid outputs
        """
        layer_name = node.node_def.name
        output_tensor_names = self.tf_output_dict[layer_name]
        assert (
            len(output_tensor_names) == 3
        ), "NMS with multiple output should have 3 outputs. got {}".format(
            len(output_tensor_names)
        )
        idx_tensor_name, score_tensor_name, num_tensor_name = output_tensor_names
        score_input_name = self.tf_input_dict[layer_name][1]
        (
            input_boxes,
            input_scores,
            max_output_boxes_per_class,
            iou_threshold,
            score_threshold,
            soft_nms_sigma,
        ) = node.node_def.input
        pad_to_max_output_size = node.node_def.attr["pad_to_max_output_size"].b
        if pad_to_max_output_size:
            raise ValueError("pad_to_max_output_size in NMS is not supported.")
        center_point_box = 0

        # TF NMS V5 returns three outputs (selected indices, selected scores, valid outputs)
        # ONNX NMS output is selected indices of shape (N,3) [batch_index, class_index, box_index]
        self.layer_dict[layer_name] = {
            "type": "NMS",
            "input0": input_boxes,
            "input1": input_scores,
            "max_output": max_output_boxes_per_class,
            "iou_thres": iou_threshold,
            "score_thres": score_threshold,
            "is_center": center_point_box,
            "soft_nms_sigma": soft_nms_sigma,
        }  # selected indices
        self.tf_output_dict[layer_name] = [idx_tensor_name]

        self.layer_dict[score_tensor_name] = {
            "type": "Gather",
            "input0": input_scores,
            "input1": layer_name,
            "axis": 0,
        }  # selected scores
        self.tf_input_dict[score_tensor_name] = [score_input_name, idx_tensor_name]
        self.tf_output_dict[score_tensor_name] = [score_tensor_name]

        self.layer_dict[num_tensor_name] = {
            "type": "Shape",
            "input": layer_name,
            "start": 0,
            "end": None,
        }  # valid outputs
        self.tf_input_dict[num_tensor_name] = [idx_tensor_name]
        self.tf_output_dict[num_tensor_name] = [num_tensor_name]

    def parse_onehot(self, node):
        layer_name = node.node_def.name
        indices_name = node.node_def.input[0]
        depth_name = node.node_def.input[1]
        on_value_name = node.node_def.input[2]
        off_value_name = node.node_def.input[3]
        axis = node.node_def.attr["axis"].i

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "OneHot"
        self.layer_dict[layer_name]["indices"] = indices_name
        self.layer_dict[layer_name]["depth"] = depth_name
        self.layer_dict[layer_name]["on_value"] = on_value_name
        self.layer_dict[layer_name]["off_value"] = off_value_name
        self.layer_dict[layer_name]["axis"] = axis

    def parse_pow(self, node):
        layer_name = node.node_def.name
        input_name = node.node_def.input[0]
        pow_name = node.node_def.input[1]

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "Pow"
        self.layer_dict[layer_name]["input"] = input_name
        self.layer_dict[layer_name]["pow"] = pow_name

    def parse_space_to_batch(self, node):
        """
        Only For spatial dimensions (ndim of spatial dimensions = M),
        1. Zero-pads input's spatial dimensions according to paddings value.
        2. Reshape to split out spatial dimensions to its corresponding block shape.
            ex) [B, H, W, C] -> [B, H/block_h, block_h, W/block_w, block_w, C]
        3. Permute block dimensions to infront of batch dim.
            ex) [B, H/block_h, block_h, W/block_w, block_w, C] -> [block_h, block_w, B, H/block_h, W/block_w, C]
        4. Reshape to merge blocks with batch dimension.
            ex) [block_h, block_w, B, H/block_h, W/block_w, C] -> [B*block_h*block_w, H/block_h, W/block_w, C]
        """
        layer_name = node.node_def.name
        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "SpaceToBatch"
        self.layer_dict[layer_name]["input"] = list(node.node_def.input)

    def parse_batch_to_space(self, node):
        """
        Only For spatial dimensions (ndim of spatial dimensions = M),
        1. Reshape Batch dimension to split out all block shapes.
            ex) [B, H, W, C] -> [block_h, block_w, B/(block_h*block_w), H, W, C]
        2. Permute tensor to place each block_shape[i] next to its corresponding dimension.
            ex) [block_h, block_w, B/(block_h*block_w), H, W, C] -> [B/(block_h*block_w), H, block_h, W, block_w, C]
        3. Reshape Tensor to merge each block shape and its corresponding dimension
            ex) [B/(block_h*block_w), H, block_h, W, block_w, C] -> [B/(block_h*block_w), H*block_h, W*block_w, C]
        4. Crop Spatial dimensions according to `crops` value.
        """
        layer_name = node.node_def.name

        self.layer_dict[layer_name] = {}
        self.layer_dict[layer_name]["type"] = "BatchToSpace"
        self.layer_dict[layer_name]["input"] = list(node.node_def.input)

    def update_info(self):
        """
        This function is to update layer info to align attributes with ONNX model dict.
        FIXME: Trivial Updates Should be done before this function is called hopefully.
        """
        layer_order = list(self.layer_dict.keys())
        for layer_name in list(self.layer_dict.keys()):
            layer_type = self.layer_dict[layer_name]["type"]

            if layer_type == "FloorDiv":
                self.layer_dict[layer_name]["type"] = "Div"  # convert FloorDiv to Div
                # Then, add Floor operation after Div operation
                new_layer_name = layer_name + "_Floor"
                replace_input_of_layers(layer_name, new_layer_name, self.layer_dict)

                self.layer_dict[new_layer_name] = {}
                self.layer_dict[new_layer_name]["type"] = "Floor"
                self.layer_dict[new_layer_name]["input"] = layer_name
                self.layer_dict[new_layer_name]["src_shape"] = self.layer_dict[
                    layer_name
                ]["src_shape"]
                layer_order.insert(layer_order.index(layer_name) + 1, new_layer_name)

            if layer_type == "Slice_Old":
                input_name = self.layer_dict[layer_name]["input"]
                begin_name = self.layer_dict[layer_name]["begin"]
                size_name = self.layer_dict[layer_name]["size"]
                start = self.const_dict[begin_name]["value"]
                if size_name not in self.const_dict:
                    # Size should be constant.
                    # If it is in layer_dict, use sample value calculated from TF session
                    # If size layer is not used for other layer's input, it will be deleted.
                    # TODO Should upstream subgraph which is input of this layer be removed?
                    size = self.sample_value_dict[size_name]
                else:
                    size = self.const_dict[size_name]["value"]
                input_src_shape = self.layer_dict[input_name]["src_shape"]
                src_shape = self.layer_dict[layer_name]["src_shape"]
                assert len(start) == len(
                    size
                ), f"Shapes of Begin Array and Size Array for Old Slice Operation are different. Layer Name: {layer_name}"
                assert len(start) == len(
                    src_shape
                ), f"Number of `start` should be same with rank of input"
                end = []
                axis = list(range(len(size)))
                for i in range(len(size)):
                    _size = size[i]
                    if _size == -1:
                        end.append(input_src_shape[i])
                    else:
                        if start[i] < 0:
                            start[i] += input_src_shape[i]
                        end.append(start[i] + _size)

                self.layer_dict[layer_name] = {}
                self.layer_dict[layer_name]["type"] = "Slice"
                self.layer_dict[layer_name]["input"] = input_name
                self.layer_dict[layer_name]["start"] = start
                self.layer_dict[layer_name]["end"] = end
                self.layer_dict[layer_name]["step"] = numpy.ones_like(start)
                self.layer_dict[layer_name]["axis"] = axis
                self.layer_dict[layer_name]["src_shape"] = src_shape

            if layer_type == "StridedSlice":
                start_name = self.layer_dict[layer_name]["start"]
                _start = self.const_dict[start_name]["value"]
                end_name = self.layer_dict[layer_name]["end"]
                _end = self.const_dict[end_name]["value"]
                step_name = self.layer_dict[layer_name]["step"]
                if step_name is None:
                    _step = None
                else:
                    _step = self.const_dict[step_name]["value"]

                input_name = self.layer_dict[layer_name]["input"]
                src_shape = self.layer_dict[layer_name]["src_shape"]
                input_src_shape = list(self.layer_dict[input_name]["src_shape"])

                def parse_mask(mask_int):
                    return tuple(
                        map(int, bin(mask_int)[-1:1:-1].ljust(len(_start), "0"))
                    )

                begin_mask = parse_mask(self.layer_dict[layer_name]["begin_mask"])
                end_mask = parse_mask(self.layer_dict[layer_name]["end_mask"])
                ellipsis_mask = parse_mask(
                    self.layer_dict[layer_name].pop("ellipsis_mask")
                )
                assert (
                    numpy.sum(ellipsis_mask) <= 1
                ), "Ellipsis mask should have at most one bit."
                shrink_axis_mask = parse_mask(
                    self.layer_dict[layer_name].pop("shrink_axis_mask")
                )
                shrink_axes = tuple(
                    idx for idx, x in enumerate(shrink_axis_mask) if x == 1
                )
                new_axis_mask = parse_mask(
                    self.layer_dict[layer_name].pop("new_axis_mask")
                )

                new_axes = []
                for i, i_digit in enumerate(new_axis_mask):
                    if i_digit == 1:
                        new_axes.append(i)
                        input_src_shape.insert(i, 1)

                shrink_axes = []
                for i, i_digit in enumerate(shrink_axis_mask):
                    if i_digit == 1:
                        shrink_axes.append(i)
                        input_src_shape.pop(i)

                for i, i_digit in enumerate(zip(begin_mask, end_mask)):
                    if i_digit[0] == 1:
                        _start[i] = 0
                    if i_digit[1] == 1:
                        _end[i] = input_src_shape[i]

                num_shorten = len(input_src_shape) - len(_start)
                if num_shorten > 0:
                    try:
                        i_digit = new_axis_mask.index(1)
                        _start.pop(i_digit)
                        for j in range(num_shorten):
                            _start = numpy.insert(_start, i_digit + j, 0, axis=0)
                            _end = numpy.insert(
                                _end, i_digit + j, input_src_shape[i_digit + j], axis=0
                            )
                    except:
                        start_idx = len(_start)
                        for j in range(num_shorten):
                            _start = numpy.insert(_start, start_idx + j, 0, axis=0)
                            _end = numpy.insert(
                                _end,
                                start_idx + j,
                                input_src_shape[start_idx + j],
                                axis=0,
                            )

                start = []
                end = []
                axis = []
                step = []
                for i in range(len(input_src_shape)):
                    if _start[i] == 0 and _end[i] == input_src_shape[i]:
                        continue
                    start.append(_start[i])
                    end.append(_end[i])
                    axis.append(i)
                    if _step is not None:
                        step.append(_step[i])

                if len(new_axes) > 0:  # new_axes가 있을 경우 Unsqueeze 추가
                    new_layer_name = layer_name + "_NewAxes"
                    self.layer_dict[new_layer_name] = {}
                    self.layer_dict[new_layer_name]["type"] = "Unsqueeze"
                    self.layer_dict[new_layer_name]["input"] = input_name
                    self.layer_dict[new_layer_name]["axes"] = new_axes
                    self.layer_dict[new_layer_name]["src_shape"] = src_shape
                    layer_order.insert(layer_order.index(layer_name), new_layer_name)
                    input_name = new_layer_name

                if len(shrink_axes) > 0:  # shrink_axes가 있을 경우 Squeeze 추가
                    new_layer_name = layer_name + "_ShrinkAxes"
                    self.layer_dict[new_layer_name] = {}
                    self.layer_dict[new_layer_name]["type"] = "Squeeze"
                    self.layer_dict[new_layer_name]["input"] = input_name
                    self.layer_dict[new_layer_name]["squeeze_axes"] = shrink_axes
                    self.layer_dict[new_layer_name]["src_shape"] = src_shape
                    layer_order.insert(layer_order.index(layer_name), new_layer_name)
                    input_name = new_layer_name

                self.layer_dict[layer_name] = {}
                self.layer_dict[layer_name]["type"] = "Slice"
                self.layer_dict[layer_name]["input"] = input_name
                self.layer_dict[layer_name]["start"] = start
                self.layer_dict[layer_name]["end"] = end
                self.layer_dict[layer_name]["step"] = step
                self.layer_dict[layer_name]["axis"] = axis
                self.layer_dict[layer_name]["src_shape"] = src_shape

            if layer_type == "ExpandDims":
                input_name = self.layer_dict[layer_name]["input"]
                expand_name = self.layer_dict[layer_name]["expand"]
                dim_value = self.const_dict[expand_name]["value"]
                src_shape = self.layer_dict[layer_name]["src_shape"]

                self.layer_dict[layer_name] = {}
                self.layer_dict[layer_name]["type"] = "Unsqueeze"
                self.layer_dict[layer_name]["input"] = input_name
                self.layer_dict[layer_name]["axes"] = [dim_value.item()]
                self.layer_dict[layer_name]["src_shape"] = src_shape

            if layer_type == "addN":
                # addN -> [Unsqueeze] * num_input + Concatenate + ReduceSum
                src_shape = self.layer_dict[layer_name]["src_shape"]
                idx = layer_order.index(layer_name)
                axis = 0

                new_input_list = []
                for input_name in self.layer_dict[layer_name]["input"]:
                    if input_name in self.layer_dict:
                        new_layer_name = input_name + "_ToSum"
                        self.layer_dict[new_layer_name] = {}
                        self.layer_dict[new_layer_name]["type"] = "Unsqueeze"
                        self.layer_dict[new_layer_name]["input"] = input_name
                        self.layer_dict[new_layer_name]["axes"] = [axis]
                        self.layer_dict[new_layer_name]["src_shape"] = self.layer_dict[
                            input_name
                        ]["src_shape"]
                        layer_order.insert(idx, new_layer_name)
                        new_input_list.append(new_layer_name)
                        idx += 1
                    elif input_name in self.const_dict:
                        value = self.const_dict[input_name]["value"]
                        self.const_dict[input_name]["value"] = numpy.expand_dims(
                            value, axis=axis
                        )
                        new_input_list.append(input_name)
                    else:
                        raise ValueError(
                            "Sum Layer's input {} does not exist.".format(input_name)
                        )
                concat_layer_name = layer_name + "_Concat"
                self.layer_dict[concat_layer_name] = {}
                self.layer_dict[concat_layer_name]["type"] = "Concatenate"
                self.layer_dict[concat_layer_name]["input"] = new_input_list
                self.layer_dict[concat_layer_name]["original_axis"] = axis
                self.layer_dict[concat_layer_name]["src_shape"] = src_shape
                layer_order.insert(idx, concat_layer_name)
                idx += 1

                self.layer_dict[layer_name] = {}
                self.layer_dict[layer_name]["type"] = "ReduceSum"
                self.layer_dict[layer_name]["input"] = concat_layer_name
                self.layer_dict[layer_name]["reduce_axes"] = [axis]
                self.layer_dict[layer_name]["keep_dims"] = False
                self.layer_dict[layer_name]["src_shape"] = src_shape
                self.layer_dict[layer_name]["noop_with_empty_axes"] = 0

            if layer_type == "Split":
                input_name = self.layer_dict[layer_name]["input"]
                axis_name = self.layer_dict[layer_name]["axis"]
                axis = self.const_dict[axis_name]["value"].item()
                split_rank = self.layer_dict[input_name]["src_shape"][axis]
                if self.layer_dict[layer_name]["split"] is None:
                    num_outputs = self.layer_dict[layer_name][
                        "num_outputs"
                    ]  # keep num_outputs
                    if int(split_rank / num_outputs) * num_outputs != split_rank:
                        raise ValueError(
                            f"For `Split` Operation in TF1, Rank of Target dimension ({split_rank}) should be divided EVENLY by num_outputs({num_outputs})."
                        )
                    self.layer_dict[layer_name]["split"] = [
                        int(split_rank / num_outputs)
                    ] * num_outputs
                else:
                    split_value = [
                        int(x)
                        for x in self.const_dict[self.layer_dict[layer_name]["split"]][
                            "value"
                        ]
                    ]
                    for i in range(len(split_value)):
                        if split_value[i] == -1:
                            split_value[i] = split_rank - sum(split_value) - 1
                    self.layer_dict[layer_name]["split"] = split_value
                self.layer_dict[layer_name]["axis"] = axis

            if layer_type == "Concatenate":
                axis_name = self.layer_dict[layer_name]["original_axis"]
                axis = self.const_dict[axis_name][
                    "value"
                ].item()  # Numpy Scalar to Integer.
                self.layer_dict[layer_name]["original_axis"] = axis

            if layer_type in [
                "Convolution",
                "DepthwiseConvolution",
                "TransposeConvolution",
            ]:
                # For aligning layer info of Convs with ONNX layer dict, check kernel size and add it.
                layer_info = self.layer_dict[layer_name]
                weight_name = layer_info["weight"]
                kh, kw, _, _ = self.const_dict[weight_name]["value"].shape
                layer_info["h_kernel"] = kh
                layer_info["w_kernel"] = kw
                # Update padding_list format to align with ONNX value.
                if layer_info["data_format"] == DATA_FORMAT.BCHW:
                    p_n, p_s = layer_info["padding_list"][2]
                    p_w, p_e = layer_info["padding_list"][3]
                elif layer_info["data_format"] == DATA_FORMAT.BHWC:
                    p_n, p_s = layer_info["padding_list"][1]
                    p_w, p_e = layer_info["padding_list"][2]
                else:
                    raise ValueError(
                        layer_type
                        + " of TF Model has invalid data format. got {}".format(
                            layer_info["data_format"]
                        )
                    )
                layer_info["padding_list"] = [p_n, p_w, p_s, p_e]

            if layer_type == "Pack":
                """
                Split single Pack layer to [Unsqueeze] * num_input + Concatenate
                Assign new layer names for Unsqueeze layers to each original input, then add Concatenate layer.
                """
                src_shape = self.layer_dict[layer_name]["src_shape"]
                axis = self.layer_dict[layer_name]["axis"]
                idx = layer_order.index(layer_name)  # Index of Pack Layer
                new_input_name_list = []
                for input_name in self.layer_dict[layer_name]["input"]:
                    if input_name in self.layer_dict:
                        new_layer_name = input_name + "_ToPack"
                        self.layer_dict[new_layer_name] = {}
                        self.layer_dict[new_layer_name]["type"] = "Unsqueeze"
                        self.layer_dict[new_layer_name]["input"] = input_name
                        self.layer_dict[new_layer_name]["axes"] = [axis]
                        self.layer_dict[new_layer_name]["src_shape"] = src_shape
                        layer_order.insert(
                            idx, new_layer_name
                        )  # Insert Unsqueeze Layer before Pack Layer
                        new_input_name_list.append(new_layer_name)
                        idx += 1
                    elif input_name in self.const_dict:
                        value = self.const_dict[input_name]["value"]
                        self.const_dict[input_name]["value"] = numpy.expand_dims(
                            value, axis=axis
                        )
                        new_input_name_list.append(input_name)
                    else:
                        raise ValueError(
                            "Pack Layer's input {} does not exist.".format(input_name)
                        )
                self.layer_dict[layer_name] = {}
                self.layer_dict[layer_name]["type"] = "Concatenate"
                self.layer_dict[layer_name]["input"] = new_input_name_list
                self.layer_dict[layer_name]["original_axis"] = axis
                self.layer_dict[layer_name]["src_shape"] = src_shape

            if layer_type == "Unpack":
                """
                Split single Unpack layer to [Split + Squeeze] * num_output
                """
                num = self.layer_dict[layer_name]["num"]
                axis = self.layer_dict[layer_name]["axis"]
                src_shape = self.layer_dict[layer_name][
                    "src_shape"
                ]  # One shape among split outputs.
                input_name = self.layer_dict[layer_name]["input"]
                split_rank = self.layer_dict[input_name]["src_shape"][axis]
                idx = layer_order.index(layer_name)
                output_tensor_names = self.tf_output_dict[layer_name]

                if num == 1:  # Simple Squeeze
                    self.layer_dict[layer_name] = {}
                    self.layer_dict[layer_name]["type"] = "Squeeze"
                    self.layer_dict[layer_name]["input"] = input_name
                    self.layer_dict[layer_name]["squeeze_axes"] = [axis]
                    self.layer_dict[layer_name]["src_shape"] = src_shape
                    continue

                # First Split has same name with its layer name
                new_layer_name = layer_name + "_Split"
                self.layer_dict[new_layer_name] = {}
                self.layer_dict[new_layer_name]["type"] = "Split"
                self.layer_dict[new_layer_name]["input"] = input_name
                self.layer_dict[new_layer_name]["split"] = [1] * num
                self.layer_dict[new_layer_name]["axis"] = axis
                self.layer_dict[new_layer_name]["num_outputs"] = num
                self.layer_dict[new_layer_name]["split_index"] = 0
                self.layer_dict[new_layer_name]["src_shape"] = src_shape
                layer_order.insert(idx, new_layer_name)

                self.layer_dict[layer_name] = {}
                self.layer_dict[layer_name]["type"] = "Squeeze"
                self.layer_dict[layer_name]["input"] = new_layer_name
                self.layer_dict[layer_name]["squeeze_axes"] = [axis]
                self.layer_dict[layer_name]["src_shape"] = src_shape
                self.tf_output_dict[layer_name] = [output_tensor_names[0]]

                # Add new layers
                for i in range(1, num):
                    idx += 2
                    cur_layer_name = output_tensor_names[i]
                    new_layer_name = cur_layer_name + "_Split"
                    self.layer_dict[new_layer_name] = {}
                    self.layer_dict[new_layer_name]["type"] = "Split"
                    self.layer_dict[new_layer_name]["input"] = input_name
                    self.layer_dict[new_layer_name]["split"] = [1] * num
                    self.layer_dict[new_layer_name]["axis"] = axis
                    self.layer_dict[new_layer_name]["num_outputs"] = num
                    self.layer_dict[new_layer_name]["split_index"] = i
                    self.layer_dict[new_layer_name]["src_shape"] = src_shape
                    layer_order.insert(idx, new_layer_name)

                    self.layer_dict[cur_layer_name] = {}
                    self.layer_dict[cur_layer_name]["type"] = "Squeeze"
                    self.layer_dict[cur_layer_name]["input"] = new_layer_name
                    self.layer_dict[cur_layer_name]["squeeze_axes"] = [axis]
                    self.layer_dict[cur_layer_name]["src_shape"] = src_shape
                    self.tf_input_dict[cur_layer_name] = self.tf_input_dict[layer_name]
                    self.tf_output_dict[cur_layer_name] = [cur_layer_name]
                    layer_order.insert(idx + 1, cur_layer_name)

            if layer_type == "SquaredDifference":
                """
                Split SquaredDifference to [Sub -> Pow]
                """
                src_shape = self.layer_dict[layer_name]["src_shape"]
                input_name_0, input_name_1 = get_input_list(self.layer_dict[layer_name])
                idx = layer_order.index(layer_name)
                sub_name = layer_name + "_Diff"
                self.layer_dict[sub_name] = {}
                self.layer_dict[sub_name]["type"] = "Sub"
                self.layer_dict[sub_name]["input0"] = input_name_0
                self.layer_dict[sub_name]["input1"] = input_name_1
                self.layer_dict[sub_name]["src_shape"] = src_shape
                layer_order.insert(idx, sub_name)

                self.layer_dict[layer_name] = {}
                self.layer_dict[layer_name]["type"] = "Pow"
                self.layer_dict[layer_name]["input"] = sub_name
                self.layer_dict[layer_name]["exponent"] = numpy.array(2)
                self.layer_dict[layer_name]["src_shape"] = src_shape

            if layer_type == "NMS":
                sigma_name = self.layer_dict[layer_name].get("soft_nms_sigma", None)
                if sigma_name is None:
                    pass
                elif sigma_name not in self.const_dict:
                    logger.warning(
                        "Cannot determine soft_nms_sigma value. It could be larger than 0 which is not supported."
                    )
                else:
                    sigma = self.const_dict[sigma_name]["value"]
                    if sigma > 0:
                        logger.warning(
                            "Soft-NMS is not supported. Result may differ with original model."
                        )

                # ----------------------------------------------
                # Slice (N,3) tensor's last dimension to get (N,) tensor
                # Then Squeeze (N,1) tensor to get (N,) tensor
                idx = layer_order.index(layer_name)
                src_shape = self.layer_dict[layer_name]["src_shape"]
                slice_layer_name = layer_name + "_Slice"
                squeeze_layer_name = layer_name + "_Squeeze"
                replace_input_of_layers(layer_name, squeeze_layer_name, self.layer_dict)

                self.layer_dict[slice_layer_name] = {}
                self.layer_dict[slice_layer_name]["type"] = "Slice"
                self.layer_dict[slice_layer_name]["input"] = layer_name
                self.layer_dict[slice_layer_name]["start"] = [2]
                self.layer_dict[slice_layer_name]["end"] = [3]
                self.layer_dict[slice_layer_name]["step"] = [1]
                self.layer_dict[slice_layer_name]["axis"] = [1]
                self.layer_dict[slice_layer_name]["src_shape"] = src_shape
                layer_order.insert(layer_order.index(layer_name) + 1, slice_layer_name)

                self.layer_dict[squeeze_layer_name] = {}
                self.layer_dict[squeeze_layer_name]["type"] = "Squeeze"
                self.layer_dict[squeeze_layer_name]["input"] = slice_layer_name
                self.layer_dict[squeeze_layer_name]["squeeze_axes"] = [-1]
                self.layer_dict[squeeze_layer_name]["src_shape"] = src_shape
                layer_order.insert(
                    layer_order.index(slice_layer_name) + 1, squeeze_layer_name
                )

        # Reorder layer_dict
        new_layer_dict = {}
        for layer_name in layer_order:
            new_layer_dict[layer_name] = self.layer_dict[layer_name]
        self.layer_dict = new_layer_dict

    def check_input_with_default(self):
        """
        Sometimes, default value of PlaceholderWithDefault causes session run error.
        To notify this error case, check default value and warn users.
        TODO: How to deal with PlaceholderWithDefault?
                - consider as Constant
                - consider as Input
        """
        for layer_name in self.layer_dict:
            if self.layer_dict[layer_name]["type"] != "PlaceholderWithDefault":
                continue
            input_name = self.layer_dict[layer_name]["input"]
            # input of PlaceholderWithDefault is Constant.
            value = self.layer_dict[input_name]["value"]
            msg = "PlaceholderWithDefault Found. Name = {}, type = {}, Default Value = {}".format(
                layer_name, value.dtype, value
            )
            logger.warning(msg)

    def update_switch_output(self):
        """
        The output layer of Switch sometimes have its input as tensor name (output_true, output_false).
        For downstream logic, update it to layer name.
        """
        for layer_name in self.layer_dict:
            input_list = get_input_list(self.layer_dict[layer_name])
            for input_name in input_list:
                if input_name in self.layer_dict:
                    continue
                for name in self.tf_output_dict:
                    if name not in self.layer_dict:
                        continue
                    if self.layer_dict[name]["type"] != "Switch":
                        continue
                    if input_name in self.tf_output_dict[name]:
                        if input_name == self.layer_dict[layer_name].get(
                            "input0", None
                        ):
                            self.layer_dict[layer_name]["input0"] = name
                        elif input_name == self.layer_dict[layer_name].get(
                            "input1", None
                        ):
                            self.layer_dict[layer_name]["input1"] = name
                        else:
                            input_val = self.layer_dict[layer_name]["input"]
                            if isinstance(input_val, str) and input_val == input_name:
                                self.layer_dict[layer_name]["input"] = name
                            elif (
                                isinstance(input_val, list) and input_name in input_val
                            ):
                                idx = self.layer_dict[layer_name]["input"].index(
                                    input_name
                                )
                                self.layer_dict[layer_name]["input"][idx] = name
                            else:
                                raise ValueError(
                                    "Tensor-named input {} from layer {} does not exist in layer info.".format(
                                        input_name, layer_name
                                    )
                                )

    def remove_switch_merge(self):
        """
        convert switch and merge to identity with proper output.

        Switch;
        1. invalid output layers are removed already from TF, just update Switch to Identity
        2. all output layers are removed already from TF, just remove it.
        3. if all output layers exist, calculate pred value and decide valid output.

        Merge;
        Its input is list of tensor names.
        Find first tensor name to become valid and change Merge to Identity to valid output layer.
        If there is no valid tensor, remove Merge.
        """

        def remove_disconnected():
            # Remove isolated layers.
            is_changed = True
            while is_changed:
                is_changed = False
                for layer_name in list(self.layer_dict.keys()):
                    if self.layer_dict[layer_name]["type"] == "Merge":
                        # Only Merge can have input tensors which could be not valid.
                        continue
                    for input_tensor in self.tf_input_dict[layer_name]:
                        exist = False
                        for name in self.tf_output_dict:
                            if name not in self.layer_dict:
                                continue
                            if input_tensor in self.tf_output_dict[name]:
                                exist = True
                                break
                        if not exist:
                            del self.layer_dict[layer_name]
                            del self.tf_input_dict[layer_name]
                            del self.tf_output_dict[layer_name]
                            is_changed = True
                            break

        self.update_switch_output()
        # Update Switch layers to Identity
        for layer_name in list(self.layer_dict.keys()):
            if layer_name not in self.layer_dict:
                continue
            if self.layer_dict[layer_name]["type"] != "Switch":
                continue
            output_false = self.layer_dict[layer_name]["output_false"]
            output_true = self.layer_dict[layer_name]["output_true"]
            if output_false is None and output_true is None:
                logger.warning(
                    "Switch Layer {} does not have output. Remove it...".format(
                        layer_name
                    )
                )
                del self.layer_dict[layer_name]
                continue

            if output_false is None or output_true is None:
                rm_idx = 0 if output_false is None else 1
            else:
                pred_name = self.layer_dict[layer_name]["pred"]
                tf_output_name = self.tf_output_dict[pred_name][0]
                output_tensor = self.graph.get_tensor_by_name(tf_output_name)
                output = self.sess.run([output_tensor], feed_dict=self.tf_feed_dict)
                rm_idx = 0 if output[0] else 1

            remove_tf_output = self.tf_output_dict[layer_name][rm_idx]
            self.tf_output_dict[layer_name].remove(remove_tf_output)
            new_layer_info = {}
            new_layer_info["type"] = "Identity"
            new_layer_info["input"] = self.layer_dict[layer_name]["input"]

            for name in list(self.tf_input_dict.keys()):
                if remove_tf_output in self.tf_input_dict[name]:
                    del self.layer_dict[name]
                    del self.tf_input_dict[name]
                    del self.tf_output_dict[name]

        remove_disconnected()

        # Update Merge layers to Identity
        for layer_name in list(self.layer_dict.keys()):
            if layer_name not in self.layer_dict:
                continue
            if self.layer_dict[layer_name]["type"] != "Merge":
                continue
            # Merge returns the first tensor to become available.
            input_list = self.layer_dict[layer_name]["input"]
            selected_output = None
            for input_name in input_list:
                for name in self.tf_output_dict:
                    if input_name in self.tf_output_dict[name]:
                        selected_output = name
                        break
                if selected_output is not None:
                    break
            if selected_output is not None:
                self.layer_dict[layer_name] = {
                    "type": "Identity",
                    "input": selected_output,
                }
            else:
                del self.layer_dict[layer_name]
                del self.tf_input_dict[layer_name]
                del self.tf_output_dict[layer_name]

        remove_disconnected()

    def make_random_feed_tensor(self, tensor_name, layer_shape, input_dtype):
        if input_dtype == "float32":
            self.tf_feed_dict[tensor_name] = numpy.random.uniform(
                low=-1.0, high=1.0, size=layer_shape
            ).astype(numpy.float32)
        elif input_dtype == "uint8":
            self.tf_feed_dict[tensor_name] = (
                numpy.random.uniform(low=0.0, high=1.0, size=layer_shape) * 255
            ).astype(numpy.uint8)
        elif input_dtype == "int32":
            self.tf_feed_dict[tensor_name] = (
                numpy.random.uniform(low=-1.0, high=1.0, size=layer_shape) * 255
            ).astype(numpy.int32)
        elif input_dtype == "bool":
            # Default value of bool input is False (considering `is_training` input.)
            self.tf_feed_dict[tensor_name] = False
        elif input_dtype in ["string"]:
            raise TypeError("Placeholder having dtype str is not supported currently.")
        else:
            raise NotImplementedError(
                f"Placeholder having unknown dtype {input_dtype}."
            )

    def calculate_const_and_shape(self):
        output_list = []
        output_dict = {}
        i = 0
        for layer_name in self.layer_dict:
            if layer_name not in self.tf_output_dict:
                continue
            layertype = self.layer_dict[layer_name]["type"]
            if layertype in ["input"]:
                continue
            # FIXME Is it safe to only use first output of layer?
            tf_output_name = self.tf_output_dict[layer_name][0]
            output_list.append(self.graph.get_tensor_by_name(tf_output_name))
            output_dict[layer_name] = i
            i += 1
        for layer_name in self.const_dict:
            if layer_name not in self.tf_output_dict:
                continue
            if "value" in self.const_dict[layer_name]:
                continue
            tf_output_name = self.tf_output_dict[layer_name][0]
            output_list.append(self.graph.get_tensor_by_name(tf_output_name))
            output_dict[layer_name] = i
            i += 1
        output = self.sess.run(output_list, feed_dict=self.tf_feed_dict)

        for layer_name in self.const_dict:
            if layer_name not in output_dict:
                continue
            self.const_dict[layer_name]["value"] = output[output_dict[layer_name]]

        self.sample_value_dict = {}
        for input_name in self.input_list:
            tf_output_name = self.tf_output_dict[input_name][0]
            self.sample_value_dict[input_name] = self.tf_feed_dict[tf_output_name]
        for layer_name in self.layer_dict:
            if layer_name not in output_dict:
                continue
            self.layer_dict[layer_name]["src_shape"] = output[
                output_dict[layer_name]
            ].shape
            self.sample_value_dict[layer_name] = output[output_dict[layer_name]]
