import uuid
import numpy as np
import tensorflow as tf
import os

# version sensitive import
from tensorflow.core.framework import graph_pb2
from tensorflow.core.protobuf import saved_model_pb2, meta_graph_pb2, config_pb2

# from tensorflow.python.training.tracking.base import Trackable
from tensorflow.python.grappler import tf_optimizer as tf_opt

# from tensorflow.python.training.tracking.resource import RestoredResource
from tensorflow.python.framework.convert_to_constants import (
    convert_variables_to_constants_v2,
)
from tensorflow.python.ops.lookup_ops import StaticHashTable
from tensorflow.python.ops.gen_lookup_ops import hash_table_v2, lookup_table_export_v2
import tensorflow.python.framework as tf_fw
from tensorflow.python.keras.saving import saving_utils
import tensorflow.compat.v1 as tf1

############################################################################################################
# The following code is for loading a frozen graph from a saved model and removing training nodes from it.
############################################################################################################
tf_session = tf1.Session


def graph_def_surgeon(graph_def):
    """Remove training nodes and unused nodes from a graph_def.

    Args:
        graph_def (GraphDef): TensorFlow GraphDef object.

    Returns:
        pruned_graph_def (GraphDef): TensorFlow GraphDef object of which training node and inappropriate nodes are removed.
    """
    pruned_graph_def = tf1.graph_util.remove_training_nodes(graph_def)
    for i in reversed(range(len(pruned_graph_def.node))):
        if pruned_graph_def.node[i].op.lower() == "noop":
            print("Deleting", pruned_graph_def.node[i].name)
            del pruned_graph_def.node[i]

    for node in pruned_graph_def.node:
        for i in reversed(range(len(node.input))):
            if node.input[i][0] == "^":
                print("Deleting", node.input[i])
                del node.input[i]

    # Remove deprecated nodes
    # TODO Keep Updating Cases.
    all_nodes = {n.name: n for n in pruned_graph_def.node}
    valid_nodes = []
    for node_name in all_nodes.keys():
        if all_nodes[node_name].op == "VarIsInitializedOp":
            continue
        if all_nodes[node_name].op == "Assign":
            all_nodes[node_name].op = "Identity"
            input_names = list(all_nodes[node_name].input)
            if len(input_names) == 2:
                del all_nodes[node_name].input[:]
                all_nodes[node_name].input.append(input_names[0])
            if "validate_shape" in all_nodes[node_name].attr:
                del all_nodes[node_name].attr["validate_shape"]
            if "use_locking" in all_nodes[node_name].attr:
                del all_nodes[node_name].attr["use_locking"]
        if all_nodes[node_name].op == "AssignAdd":
            all_nodes[node_name].op = "Add"
            if "use_locking" in all_nodes[node_name].attr:
                del all_nodes[node_name].attr["use_locking"]
        if all_nodes[node_name].op == "AssignSub":
            all_nodes[node_name].op = "Sub"
            if "use_locking" in all_nodes[node_name].attr:
                del all_nodes[node_name].attr["use_locking"]
        valid_nodes.append(node_name)
    target_nodes = [all_nodes[x] for x in valid_nodes]
    pruned_graph_def_new = tf1.GraphDef()
    pruned_graph_def_new.node.extend(target_nodes)

    return pruned_graph_def_new


def get_frozen_graph_from_saved_model(model_path):
    """Load tensorflow graph from saved_model.

    Args:
        model_path (str): Path to the saved model.

    Returns:
        pruned_frozen_graph_def (GraphDef): TensorFlow GraphDef object of which training node and inappropriate nodes are removed.
        frozen_func.graph (Graph): TensorFlow Graph object.
    """

    frozen_graph_def, frozen_func = from_saved_model(model_path)
    pruned_frozen_graph_def = graph_def_surgeon(frozen_graph_def)

    return pruned_frozen_graph_def, frozen_func.graph


def from_saved_model(model_path):
    """Load tensorflow graph from saved_model.

    Args:
        model_path (str): Path to the saved model.

    Returns:
        frozen_graph_def (GraphDef): TensorFlow GraphDef object.
        frozen_func (ConcreteFunction): TensorFlow ConcreteFunction object.
    """

    tf1.reset_default_graph()
    with tf.device("/cpu:0"):
        tf.keras.backend.clear_session()
        tf.keras.backend.set_learning_phase(False)
        try:
            imported = tf.keras.models.load_model(model_path)
        except Exception:
            imported = tf.saved_model.load(model_path)
        if imported.__class__.__name__.lower() in ["sequential", "functional"]:
            imported = convert_groups_conv2d_2_split_conv2d(
                imported
            )  # Convert group convolutions to split convolutions when the model is either Sequential or Functional
            function = saving_utils.trace_model_call(imported)
            concrete_func = function.get_concrete_function()
            # allow to pass inputs and outputs from caller if we don't want all of them
            input_names = [
                input_tensor.name
                for input_tensor in concrete_func.inputs
                if input_tensor.dtype != tf.dtypes.resource
            ]
            output_names = [
                output_tensor.name
                for output_tensor in concrete_func.outputs
                if output_tensor.dtype != tf.dtypes.resource
            ]
            frozen_graph_def, frozen_func = from_function(
                concrete_func, input_names, output_names
            )
        else:
            all_sigs = imported.signatures.keys()
            valid_sigs = [s for s in all_sigs if not s.startswith("_")]
            concrete_func = imported.signatures[valid_sigs[0]]

            tensors_to_rename = {}

            inputs = [
                tensor.name
                for tensor in concrete_func.inputs
                if tensor.dtype != tf.dtypes.resource
            ]
            if hasattr(concrete_func.graph, "_captures"):
                graph_captures = concrete_func.graph._captures
                captured_inputs = [t_name.name for _, t_name in graph_captures.values()]
            else:
                graph_captures = concrete_func.graph.function_captures.by_val_internal
                captured_inputs = [t.name for t in graph_captures.values()]
            inputs = [inp for inp in inputs if inp not in captured_inputs]
            if concrete_func.structured_input_signature is not None:
                flat_structured_inp = tf.nest.flatten(
                    concrete_func.structured_input_signature
                )
                structured_inputs = [
                    t.name for t in flat_structured_inp if isinstance(t, tf.TensorSpec)
                ]
                tensors_to_rename.update(zip(inputs, structured_inputs))

            outputs = [
                tensor.name
                for tensor in concrete_func.outputs
                if tensor.dtype != tf.dtypes.resource
            ]
            if isinstance(concrete_func.structured_outputs, dict):
                # outputs are sorted, sort structured_outputs the same way
                structured_outputs = sorted(concrete_func.structured_outputs.keys())
                tensors_to_rename.update(zip(outputs, structured_outputs))

            frozen_graph_def, frozen_func = from_trackable(
                imported, concrete_func, inputs, outputs
            )
        tf1.reset_default_graph()
    return frozen_graph_def, frozen_func


def from_trackable(trackable, concrete_func, inputs, outputs):
    """Freeze a trackable object and its concrete function into a graphdef and a concrete function.

    Args:
        trackable (Trackable): Trackable object.
        concrete_func (ConcreteFunction): TensorFlow ConcreteFunction object.
        inputs (list): List of input names.
        outputs (list): List of output names.

    Returns:
        frozen_graph_def (GraphDef): TensorFlow GraphDef object.
        frozen_func (ConcreteFunction): TensorFlow ConcreteFunction object.
    """

    # Avoid errors due to bug in TF freezing
    (
        removed_resource_to_placeholder,
        placeholder_to_resource,
        graph_captures_copy,
        func_captures_copy,
    ) = _remove_non_variable_resources_from_captures(concrete_func)

    frozen_graph_def, frozen_func = from_function(concrete_func, inputs, outputs)
    _restore_captured_resources(concrete_func, graph_captures_copy, func_captures_copy)

    table_info = get_hash_table_info(frozen_graph_def)
    placeholder_to_table_info = {}
    _get_hash_table_info_from_trackable(
        trackable,
        table_info,
        removed_resource_to_placeholder,
        placeholder_to_table_info,
    )

    for info in table_info:
        if info.shared_name is not None:
            n = info.shared_name
        elif (
            info.resource_input in placeholder_to_resource
            and info.resource_input not in placeholder_to_table_info
        ):
            # We found a lookup op with no corresponding HashTable op, but we can associate the placeholder input
            # from the op with the resource handle from graph captures and make up a shared_name
            n = str(uuid.uuid4()).encode()
            info.shared_name = n
            placeholder_to_table_info[info.resource_input] = info
        else:
            # Found a lookup op but the corresponding HashTable op has already been found and processed.
            continue

    replace_placeholders_with_tables(frozen_graph_def, placeholder_to_table_info)

    return frozen_graph_def, frozen_func


def from_function(func, input_names, output_names):
    """Freeze a function into a graphdef and a concrete function.

    Args:
        func (ConcreteFunction): TensorFlow ConcreteFunction object.
        input_names (list): List of input names.
        output_names (list): List of output names.

    Returns:
        graph_def (GraphDef): TensorFlow GraphDef object.
        frozen_func (ConcreteFunction): TensorFlow ConcreteFunction object.
    """
    frozen_func = tf_fw.convert_to_constants.convert_variables_to_constants_v2(
        func, lower_control_flow=False, aggressive_inlining=True
    )

    graph_def = frozen_func.graph.as_graph_def(add_shapes=True)
    graph_def = fix_freezing_errors_part2(graph_def)

    with tf.Graph().as_default() as tf_graph:
        with tf_session(graph=tf_graph) as sess:
            tf.import_graph_def(graph_def, name="")
            input_names = inputs_without_resource(sess, input_names)
            graph_def = tf_optimize(input_names, output_names, graph_def)
    return graph_def, frozen_func


def _remove_non_variable_resources_from_captures(concrete_func):
    """
    Removes all non-variable resources (such as tables) from a function's captured inputs to prevent tf from
    raising a 'cannot convert dtype resource to numpy' error while freezing the graph.


    Args:
        concrete_func (ConcreteFunction): TensorFlow ConcreteFunction object.

    Returns:
        resource_id_to_placeholder (dict): Dictionary mapping resource ids to placeholder names.
        placeholder_to_resource (dict): Dictionary mapping placeholder names to resource tensors.
        graph_captures_copy (dict): Copy of the graph captures.
        func_captures_copy (dict): Copy of the function captures.
    """
    # pylint: disable=protected-access
    resource_id_to_placeholder = {}
    placeholder_to_resource = {}
    graph_captures_copy = None
    func_captures_copy = None
    if hasattr(concrete_func.graph, "_captures") and hasattr(
        concrete_func, "_captured_inputs"
    ):
        graph_captures_copy = concrete_func.graph._captures.copy()
        func_captures_copy = concrete_func._captured_inputs.copy()

        (
            resource_id_to_placeholder,
            placeholder_to_resource,
            keys_to_be_removed,
        ) = _get_resources_from_captures(concrete_func, concrete_func.graph._captures)
        for key in keys_to_be_removed:
            del concrete_func.graph._captures[key]
    elif hasattr(concrete_func.graph, "function_captures") and hasattr(
        concrete_func, "_captured_inputs"
    ):
        # Since tensorflow 2.13.0, _captures has been removed and replaced with function_captures
        graph_captures = {}
        for k, v in concrete_func.graph.function_captures.by_val_external.items():
            graph_captures[k] = (
                v,
                concrete_func.graph.function_captures.by_val_internal[k],
            )
        graph_captures_copy = graph_captures.copy()
        func_captures_copy = concrete_func._captured_inputs.copy()

        (
            resource_id_to_placeholder,
            placeholder_to_resource,
            keys_to_be_removed,
        ) = _get_resources_from_captures(concrete_func, graph_captures)
        for key in keys_to_be_removed:
            del concrete_func.graph.function_captures.by_val_internal[key]
            del concrete_func.graph.function_captures.by_val_external[key]

    return (
        resource_id_to_placeholder,
        placeholder_to_resource,
        graph_captures_copy,
        func_captures_copy,
    )


def tf_optimize(input_names, output_names, graph_def):
    """Extract inference subgraph and optimize graph.

    Args:
        input_names (list): List of input names.
        output_names (list): List of output names.
        graph_def (GraphDef): TensorFlow GraphDef object.

    Returns:
        graph_def (GraphDef): TensorFlow GraphDef object. Optimized graph.
    """

    config = config_pb2.ConfigProto()
    rewrite_options = config.graph_options.rewrite_options
    config.graph_options.infer_shapes = True

    rewrite_options.optimizers[:] = ["constfold", "function", "dependency"]
    rewrite_options.experimental_disable_folding_quantization_emulation = True

    meta_graph = tf1.train.export_meta_graph(graph_def=graph_def)
    fetch_collection = meta_graph_pb2.CollectionDef()
    for t in input_names + output_names:
        fetch_collection.node_list.value.append(t)
    meta_graph.collection_def["train_op"].CopyFrom(fetch_collection)
    graph_def = tf_opt.OptimizeGraph(config, meta_graph)
    return graph_def


def inputs_without_resource(sess, input_names):
    """Remove resource inputs from input_names.

    Args:
        sess (Session): TensorFlow Session object.
        input_names (list): List of input names.

    Returns:
        input_names (list): List of input names without resource inputs.
    """

    try:
        new_input_names = []
        for n in input_names:
            t = sess.graph.get_tensor_by_name(n)
            if t.dtype != tf.dtypes.resource:
                new_input_names.append(n)
        input_names = new_input_names
    except:  # pylint: disable=bare-except
        pass
    return input_names


def fix_freezing_errors_part2(graph_def):
    """Fix freezing errors in the graph_def.
        Sometimes tf freezing fails to convert ResourceGather ops in subgraphs
    Args:
        graph_def (GraphDef): TensorFlow GraphDef object.

    Returns:
        graph_def (GraphDef): TensorFlow GraphDef object.
    """

    for f in graph_def.library.function:
        for n in f.node_def:
            if n.op == "ResourceGather":
                # Convert to standard Gather op. Freezing will have replaced resource with constant.
                # Needed because of: https://github.com/tensorflow/tensorflow/issues/51488
                n.op = "Gather"
                n.attr["Tparams"].type = n.attr["dtype"].type
                del n.attr["dtype"]
                if "batch_dims" in n.attr:
                    del n.attr["batch_dims"]
    return graph_def


def _restore_captured_resources(concrete_func, graph_captures_copy, func_captures_copy):
    """Undoes effect of _remove_non_variable_resources_from_captures on concrete_func

    Args:
        concrete_func (ConcreteFunction): TensorFlow ConcreteFunction object.
        graph_captures_copy (dict): Copy of the graph captures.
        func_captures_copy (dict): Copy of the function captures.
    """

    if hasattr(concrete_func.graph, "_captures") and hasattr(
        concrete_func, "_captured_inputs"
    ):
        concrete_func.graph._captures = graph_captures_copy
        concrete_func._captured_inputs = func_captures_copy


def _get_resources_from_captures(concrete_func, graph_captures):
    """Extracts resources from graph captures and removes them from the graph captures

    Args:
        concrete_func (ConcreteFunction): TensorFlow ConcreteFunction object.
        graph_captures (dict): Dictionary of graph captures.

    Returns:
        resource_id_to_placeholder (dict): Dictionary mapping resource ids to placeholder names.
    """
    resource_id_to_placeholder = {}
    placeholder_to_resource = {}
    keys_to_be_removed = []

    variable_handles = {id(v.handle) for v in concrete_func.graph.variables}
    for k, v in list(graph_captures.items()):
        val_tensor, name_tensor = v
        if val_tensor.dtype == tf.resource and id(val_tensor) not in variable_handles:
            resource_id_to_placeholder[id(val_tensor)] = name_tensor.name.split(":")[0]
            placeholder_to_resource[name_tensor.name.split(":")[0]] = val_tensor
            keys_to_be_removed.append(k)
            for i in reversed(range(len(concrete_func._captured_inputs))):
                if concrete_func._captured_inputs[i] is val_tensor:
                    concrete_func._captured_inputs.pop(i)

    return resource_id_to_placeholder, placeholder_to_resource, keys_to_be_removed


def replace_placeholders_with_tables(graph_def, placeholder_to_table_info):
    """
    Given a graph_def and a map from placeholder names to a tuple of table names, key dtypes, and value dtypes,
    Replaces placeholder ops in the graph_def with HashTableV2 ops

    Args:
        graph_def (GraphDef): TensorFlow GraphDef object.
        placeholder_to_table_info (dict): Dictionary mapping placeholder names to a tuple of table names, key dtypes, and value dtypes.
    """
    for n in graph_def.node:
        if n.op == "Placeholder" and n.name in placeholder_to_table_info:
            info = placeholder_to_table_info[n.name]
            for a in list(n.attr):
                del n.attr[a]
            n.op = "HashTableV2"
            n.attr["shared_name"].s = info.shared_name
            n.attr["key_dtype"].type = info.key_dtype
            n.attr["value_dtype"].type = info.val_dtype


def _get_hash_table_info_from_trackable(
    trackable, table_info, removed_resource_to_placeholder, placeholder_to_table_info
):
    """Get hash table info from a trackable object.

    Args:
        trackable (Trackable): Trackable object.
        table_info (list): List of hash table info.
        removed_resource_to_placeholder (dict): Dictionary mapping resource ids to placeholder names.
        placeholder_to_table_info (dict): Dictionary mapping placeholder names to a tuple of table names, key dtypes, and value dtypes.
    """
    stack = [trackable]
    visited = set()
    while stack:
        r = stack.pop()
        visited.add(id(r))
        try:
            for trackable_ref in r._checkpoint_dependencies:
                if id(trackable_ref.ref) not in visited:
                    if isinstance(trackable_ref.ref, Trackable):
                        stack.append(trackable_ref.ref)
        except Exception:
            continue
        for t in r.__dict__.values() if hasattr(r, "__dict__") else []:
            if isinstance(t, StaticHashTable) and hasattr(t, "_shared_name"):
                info = HashTableInfo(
                    t._shared_name.encode(),
                    t.key_dtype.as_datatype_enum,
                    t.value_dtype.as_datatype_enum,
                )
                table_info.append(info)
                table_handle = id(t.resource_handle)
                if table_handle in removed_resource_to_placeholder:
                    placeholder_to_table_info[
                        removed_resource_to_placeholder[table_handle]
                    ] = info
        if isinstance(r, RestoredResource) and hasattr(r, "_create_resource"):
            try:
                table_handle = id(r.resource_handle)
            except Exception:
                continue
            initializer = r._create_resource.concrete_functions[0].function_def
            new_table_info = get_hash_table_info(initializer.node_def)
            table_info.extend(new_table_info)
            if (
                table_handle in removed_resource_to_placeholder
                and len(new_table_info) == 1
            ):
                placeholder_to_table_info[
                    removed_resource_to_placeholder[table_handle]
                ] = new_table_info[0]


class HashTableInfo:
    def __init__(self, shared_name, key_dtype, val_dtype, resource_input=None):
        """Initialize HashTableInfo.

        Args:
            shared_name (str): Shared name.
            key_dtype (DType): Key data type.
            val_dtype (DType): Value data type.
            resource_input (str): Resource input.
        """
        self.shared_name = shared_name
        self.key_dtype = key_dtype
        self.val_dtype = val_dtype
        self.resource_input = resource_input


def get_hash_table_info(nodes_or_graph_def):
    """
    Return lists of the shared_names, key_dtypes, and value_dtypes of all hash tables declared in the graph_def
    or list of nodes

    Args:
        nodes_or_graph_def (list or GraphDef): List of nodes or TensorFlow GraphDef object.

    Returns:
        info (list): List of hash table info.
    """
    if isinstance(nodes_or_graph_def, graph_pb2.GraphDef):
        nodes = nodes_or_graph_def.node
    else:
        nodes = nodes_or_graph_def
    info = []
    for n in nodes:
        if n.op == "LookupTableFindV2":
            info.append(
                HashTableInfo(None, n.attr["Tin"].type, n.attr["Tout"].type, n.input[0])
            )
        if n.op in ["HashTableV2", "MutableHashTableV2"]:
            if all(k in n.attr for k in ["shared_name", "key_dtype", "value_dtype"]):
                name = n.attr["shared_name"].s
                if name != b"":
                    info.append(
                        HashTableInfo(
                            name, n.attr["key_dtype"].type, n.attr["value_dtype"].type
                        )
                    )
    return info


############################################################################################################
# The following code is for converting a model to a frozen graph from .keras or .h5 file.
############################################################################################################
def get_frozen_graph_from_keras(model_path, input_names=None, output_names=None):
    """Load tensorflow graph from keras model.
        Always deals with model that is sequential or functional
    Args:
        model_path (str): Path to the keras model. It can be either .keras or .h5 file.
        input_names (list): List of input names.
        output_names (list): List of output names.

    Returns:
        frozen_graph_def (GraphDef): TensorFlow GraphDef object.
        frozen_func.graph (Graph): TensorFlow Graph object.
    """
    with tf.device("/cpu:0"):
        tf.keras.backend.clear_session()
        # tf.keras.backend.set_learning_phase(False)
        keras_model = tf.keras.models.load_model(model_path)  # Load model
        keras_model = convert_groups_conv2d_2_split_conv2d(
            keras_model
        )  # Convert group convolutions to split convolutions

        concrete_func = tf.function(lambda x: keras_model(x))
        concrete_func = concrete_func.get_concrete_function(
            tf.TensorSpec(keras_model.input_shape, keras_model.input.dtype)
        )

        # allow to pass inputs and outputs from caller if we don't want all of them
        input_names = [
            input_tensor.name
            for input_tensor in concrete_func.inputs
            if input_tensor.dtype != tf.dtypes.resource
        ]
        output_names = [
            output_tensor.name
            for output_tensor in concrete_func.outputs
            if output_tensor.dtype != tf.dtypes.resource
        ]
        frozen_graph_def, frozen_func = from_function(
            concrete_func, input_names, output_names
        )
        frozen_graph_def = graph_def_surgeon(frozen_graph_def)
    return frozen_graph_def, frozen_func.graph


############################################################################################################
# The following code is for converting a model to a frozen graph from .pb file (frozen graph).
############################################################################################################
def freeze_session(sess, input_names=None, output_names=None, get_tables=False):
    """Freezes the state of a session into a pruned computation graph.

    Args:
        sess (Session): TensorFlow Session object.
        input_names (list): List of input names.
        output_names (list): List of output names.
        get_tables (bool): Whether to get tables.

    Returns:
        graph_def (GraphDef): TensorFlow GraphDef object.
        frozen_graph (Graph): TensorFlow Graph object.
    """
    output_node_names = [i.split(":")[:-1][0] for i in output_names]
    keep_var_names = [i.split(":")[:-1][0] for i in input_names]
    with sess.graph.as_default():
        output_node_names = output_node_names or []
        output_node_names += [v.op.name for v in tf1.global_variables()]
        output_node_names += keep_var_names
        graph_def = sess.graph.as_graph_def(add_shapes=True)
        for node in graph_def.node:
            node.device = ""
        graph_def = tf1.graph_util.convert_variables_to_constants(
            sess, graph_def, output_node_names
        )
        table_info = get_hash_table_info(graph_def)
        if get_tables:
            initialized_tables = {}
            tf1.tables_initializer().run(session=sess)
            for info in table_info:
                if info.shared_name is None:
                    continue
                h = hash_table_v2(
                    info.key_dtype, info.val_dtype, shared_name=info.shared_name
                )
                n = info.shared_name
                try:
                    k, v = lookup_table_export_v2(h, info.key_dtype, info.val_dtype)
                    k, v = sess.run([k, v])
                    initialized_tables[n] = (k, v)
                except Exception:  # pylint: disable=broad-except
                    print("Could not initialize table with shared_name = %r", n)
            return graph_def, sess.graph
        frozen_graph = sess.graph
    return graph_def, frozen_graph


def remove_redundant_inputs(frozen_graph_def, input_names):
    """Remove redundant inputs not in frozen graph.

    Args:
        frozen_graph_def (GraphDef): TensorFlow GraphDef object.
        input_names (list): List of input names.

    Returns:
        frozen_inputs (list): List of input names in frozen graph.
    """
    frozen_inputs = []
    # get inputs in frozen graph
    node_names = set(n.name for n in frozen_graph_def.node)

    def get_node_name(name):
        """Get node name without io#."""
        pos = name.find(":")
        if pos >= 0:
            return name[:pos]
        return name

    frozen_inputs = [inp for inp in input_names if get_node_name(inp) in node_names]
    deleted_inputs = list(set(input_names) - set(frozen_inputs))
    if deleted_inputs:
        print(
            "inputs [%s] is not in frozen graph, delete them", ",".join(deleted_inputs)
        )
    return frozen_inputs


def get_frozen_graph_from_graphdef(model_path, input_names, output_names):
    """Load tensorflow graph from graphdef.

    Args:
        model_path (str): Path to the graphdef file.
        input_names (list): List of input names.
        output_names (list): List of output names.

    Raises:
        OSError: Unable to load file.

    Returns:
        frozen_graph_def (GraphDef): TensorFlow GraphDef object.
        frozen_graph (Graph): TensorFlow Graph object.
    """
    with tf_session() as sess:
        graph_def = tf1.GraphDef()
        with tf.io.gfile.GFile(model_path, "rb") as f:
            try:
                content = f.read()
            except Exception as e:
                raise OSError("Unable to load file '{}'.".format(model_path)) from e
            try:
                graph_def.ParseFromString(content)
            except Exception:
                content_as_bytes = tf.compat.as_bytes(content)
                saved_model = saved_model_pb2.SavedModel()
                saved_model.ParseFromString(content_as_bytes)
                graph_def = saved_model.meta_graphs[0].graph_def
            tf.import_graph_def(graph_def, name="")
        input_names = inputs_without_resource(sess, input_names)
        frozen_graph_def, frozen_graph = freeze_session(
            sess, input_names=input_names, output_names=output_names
        )
        input_names = remove_redundant_inputs(frozen_graph_def, input_names)

    tf1.reset_default_graph()
    with tf_session() as sess:
        input_names = inputs_without_resource(sess, input_names)
        frozen_graph_def = tf_optimize(input_names, output_names, frozen_graph_def)
        frozen_graph_def = graph_def_surgeon(frozen_graph_def)
    tf1.reset_default_graph()
    return frozen_graph_def, frozen_graph


############################################################################################################
# The following code is for converting a model to a frozen graph from checkpoint files.
############################################################################################################


def get_frozen_graph_from_checkpoint(model_path, input_names, output_names):
    """Load tensorflow graph from checkpoint.

    Args:
        model_path (str): Path to the checkpoint file.
        input_names (list): List of input names.
        output_names (list): List of output names.

    Raises:
        e: Failed to load graphdef from checkpoint.

    Returns:
        frozen_graph_def (GraphDef): TensorFlow GraphDef object.
        frozen_graph (Graph): TensorFlow Graph object.
    """
    # make sure we start with clean default graph
    tf1.reset_default_graph()
    # model_path = checkpoint/checkpoint.meta
    tmp_graph_path = model_path.replace(".meta", "_tmp.pb")
    with tf.device("/cpu:0"):
        with tf_session() as sess:
            saver = tf1.train.import_meta_graph(model_path, clear_devices=True)
            # restore from model_path minus the ".meta"
            saver.restore(sess, model_path[:-5])
            input_names = inputs_without_resource(sess, input_names)
            frozen_graph_def, frozen_graph = freeze_session(
                sess, input_names=input_names, output_names=output_names
            )
            input_names = remove_redundant_inputs(frozen_graph_def, input_names)

        with tf.io.gfile.GFile(tmp_graph_path, "wb") as f:
            f.write(frozen_graph_def.SerializeToString())
        try:
            tf1.reset_default_graph()
            frozen_graph_def, frozen_graph = get_frozen_graph_from_graphdef(
                tmp_graph_path, input_names, output_names
            )

            os.remove(tmp_graph_path)
        except Exception as e:
            print("Failed to load graphdef from checkpoint")
            print(
                "Debug the error by loading the graphdef from the file: ",
                tmp_graph_path,
            )
            raise e

    return frozen_graph_def, frozen_graph


############################################################################################################
# The following code is for replacing the group convolution with a series of convolutions.
# https://github.com/leondgarse/keras_cv_attention_models/tree/main
############################################################################################################
class SplitConv2D(tf.keras.layers.Conv2D):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.super_class = tf.keras.layers.Conv2D

    def build(self, input_shape):
        cc = self.get_config().copy()
        cc.update({"groups": 1, "filters": self.filters // self.groups})
        grouped_input_shape = (*input_shape[:-1], input_shape[-1] // self.groups)
        self.convs = []
        for ii in range(self.groups):
            name_scope = self.name + "_{}".format(ii)
            with tf.name_scope(name_scope) as scope:
                cc["name"] = self.name + "_{}".format(ii)
                conv = self.super_class.from_config(cc)
                conv.build(grouped_input_shape)
            self.convs.append(conv)

    def call(self, inputs, **kwargs):
        return tf.concat(
            [
                conv(ii)
                for conv, ii in zip(self.convs, tf.split(inputs, self.groups, axis=-1))
            ],
            axis=-1,
        )


class SplitScaledStandardizedConv2D(SplitConv2D):
    def __init__(self, gamma=1.0, eps=1e-5, **kwargs):
        super().__init__(**kwargs)
        self.super_class = ScaledStandardizedConv2D
        self.eps, self.gamma = eps, gamma

    def get_config(self):
        base_config = super().get_config()
        base_config.update({"eps": self.eps, "gamma": self.gamma})
        return base_config


class ScaledStandardizedConv2D(tf.keras.layers.Conv2D):
    """
    Copied from https://github.com/google-research/big_transfer/blob/master/bit_tf2/models.py, Author: Lucas Beyer
    Modified reference: https://github.com/deepmind/deepmind-research/blob/master/nfnets/base.py#L121
    """

    def __init__(self, gamma=1.0, eps=1e-5, *args, **kwargs):
        super(ScaledStandardizedConv2D, self).__init__(*args, **kwargs)
        self.eps, self.gamma = eps, gamma

    def build(self, input_shape):
        super(ScaledStandardizedConv2D, self).build(input_shape)
        # Wrap a standardization around the conv OP.
        default_conv_op = self.convolution_op
        self.gain = self.add_weight(
            name="gain", shape=(self.filters,), initializer="ones", trainable=True
        )
        self.fan_in = float(np.prod(self.kernel.shape[:-1]))
        self.__eps__ = float(self.eps)
        self.__gamma__ = float(self.gamma)

        def standardized_conv_op(inputs, kernel):
            # Kernel has shape HWIO, normalize over HWI
            mean, var = tf.nn.moments(kernel, axes=[0, 1, 2], keepdims=True)
            # Manually fused normalization, eq. to (w - mean) * gain / sqrt(N * var)
            # print(">>>>", mean.dtype, var.dtype, self.fan_in.dtype, self.__eps__.dtype, self.__gamma__.dtype, self.gain.dtype)
            scale = tf.math.rsqrt(tf.math.maximum(var * self.fan_in, self.__eps__)) * (
                self.gain * self.__gamma__
            )
            return default_conv_op(inputs, (kernel - mean) * scale)

        self.convolution_op = standardized_conv_op
        self.built = True

    def get_config(self):
        base_config = super(ScaledStandardizedConv2D, self).get_config()
        base_config.update({"eps": self.eps, "gamma": self.gamma})
        return base_config


def convert_groups_conv2d_2_split_conv2d(model):
    """Convert group convolutions to split convolutions

    Args:
        model (Sequential or Functional): Keras model. If the model has group convolutions, it will be converted to split convolutions.

    Remarks:
        If the input model is neither Sequential nor Functional, it will raise an error.
    """

    def __convert_groups_conv2d_2_split_conv2d__(layer):
        if (
            isinstance(layer, tf.keras.layers.Conv2D)
            and not isinstance(layer, SplitConv2D)
            and layer.groups != 1
        ):
            aa = layer.get_config()
            # Check if ScaledStandardizedConv2D or typical Conv2D
            bb = (
                SplitScaledStandardizedConv2D.from_config(aa)
                if hasattr(layer, "gain")
                else SplitConv2D.from_config(aa)
            )
            # bb.build(layer.input_shape)
            bb(tf.keras.initializers.ones()([1, *layer.input_shape[1:]]))
            wws = tf.split(layer.get_weights()[0], bb.groups, axis=-1)
            if bb.use_bias:
                bbs = tf.split(layer.get_weights()[1], bb.groups, axis=-1)
            if hasattr(layer, "gain"):
                # ScaledStandardizedConv2D with gain from NFNets
                ggs = tf.split(layer.get_weights()[-1], bb.groups, axis=-1)
            for id in range(bb.groups):
                sub_weights = [wws[id].numpy()]
                if bb.use_bias:
                    sub_weights.append(bbs[id].numpy())
                if hasattr(layer, "gain"):
                    sub_weights.append(ggs[id].numpy())
                bb.convs[id].set_weights(sub_weights)
            return bb
        return layer

    input_tensors = tf.keras.layers.Input(model.input_shape[1:])
    return tf.keras.models.clone_model(
        model,
        input_tensors=input_tensors,
        clone_function=__convert_groups_conv2d_2_split_conv2d__,
    )
