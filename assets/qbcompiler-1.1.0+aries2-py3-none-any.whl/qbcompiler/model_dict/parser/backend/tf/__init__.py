from qbcompiler.model_dict.parser.backend.tf.parser import TFParser

__all__ = ["get_parser"]


def get_parser(model_path: str, **kwargs):
    return TFParser(path_to_model=model_path, **kwargs)
