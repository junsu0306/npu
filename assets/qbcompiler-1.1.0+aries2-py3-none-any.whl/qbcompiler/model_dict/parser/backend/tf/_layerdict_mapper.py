import copy
import dataclasses

from typing import Dict, Any, Tuple, List, Optional

import numpy

from qbcompiler.model_dict.common import (
    Registry,
    LayerOptions,
    TensorIndex,
    options,
    LayerType,
)
from qbcompiler.model_dict.common.value_wrapper import ValueWrapper


from qbcompiler.model_dict.common.dataformat import (
    DATAFORMAT_LIST,
    DIMENSION,
    validate_src_shape_dformat,
    DataFormat,
)

from qbcompiler.logging import get_logger

logger = get_logger(__name__)

from qbcompiler.model_dict.parser.old_model_dict_utils import (
    get_input_list,
    DATA_FORMAT,
)

# tensorflow dataformat to our dataformat
TFDATAFORMATMAPPER = {
    DATA_FORMAT.BCHW: DataFormat.NCHW,
    DATA_FORMAT.BHWC: DataFormat.NHWC,
    DATA_FORMAT.BC: DataFormat.NC,
    DATA_FORMAT.CB: DataFormat.UNKNOWN,
    DATA_FORMAT.HWC: DataFormat.UNKNOWN,
    DATA_FORMAT.HCW: DataFormat.UNKNOWN,
    DATA_FORMAT.BH1W1C: DataFormat.UNKNOWN,
    DATA_FORMAT.BH2W2C: DataFormat.UNKNOWN,
    DATA_FORMAT.BHW: DataFormat.UNKNOWN,
    DATA_FORMAT.BCH: DataFormat.NCX,
    DATA_FORMAT.UNKNOWN: DataFormat.UNKNOWN,
}

TFLAYERTYPEMAPPER = {
    "abs": LayerType.Abs,
    "adding": LayerType.Adding,
    "and": LayerType.And,
    "argmax": LayerType.ArgMax,
    "avgpool": LayerType.Pooling,
    "batchnorm": LayerType.Batchnorm,
    "biasadd": LayerType.AddingConstant,
    "cast": LayerType.Cast,
    "ceil": LayerType.Ceil,
    "clip": LayerType.Clip,
    "concatenate": LayerType.Concatenate,
    "convolution": LayerType.Convolution,
    "depthwiseconvolution": LayerType.DepthwiseConvolution,
    "div": LayerType.Div,
    "erf": LayerType.Erf,
    "equal": LayerType.Equal,
    "exp": LayerType.Exp,
    "floor": LayerType.Floor,
    "gather": LayerType.Gather,
    "gathernd": LayerType.GatherND,
    "greater": LayerType.Greater,
    "identity": LayerType.Identity,
    "input": LayerType.Input,
    "iess": LayerType.Less,
    "leakylelu": LayerType.LeakyRelu,
    "matmul": LayerType.MatMul,
    # "maximum": LayerType.Maximum,
    "maxpool": LayerType.Pooling,
    "minimum": LayerType.Minimum,
    "mod": LayerType.Mod,
    "mul": LayerType.Multiply,
    "multiply": LayerType.Multiply,
    "neg": LayerType.Neg,
    "nms": LayerType.NonMaxSuppression,
    "nonzero": LayerType.NonZero,
    "not": LayerType.Not,
    "or": LayerType.Or,
    "pad": LayerType.Pad,
    "pow": LayerType.Pow,
    "range": LayerType.Range,
    "reciprocal": LayerType.Reciprocal,
    "reducemax": LayerType.ReduceMax,
    "reducemean": LayerType.ReduceMean,
    # "reducemin": LayerType.ReduceMin,
    "reduceprod": LayerType.ReduceProd,
    "reducesum": LayerType.ReduceSum,
    "resize": LayerType.Resize,
    "relu": LayerType.Relu,
    "reshape": LayerType.Reshape,
    # "round": LayerType.Round,
    "rsqrt": LayerType.Rsqrt,
    "shape": LayerType.Shape,
    "sigmoid": LayerType.Sigmoid,
    "slice": LayerType.Slice,
    "softplus": LayerType.Softplus,
    "softmax": LayerType.Softmax,
    "split": LayerType.Split,
    "sqrt": LayerType.Sqrt,
    "squareddifference": LayerType.SquaredDifference,
    "squeeze": LayerType.Squeeze,
    "pooling": LayerType.Pooling,
    "sub": LayerType.Sub,
    "tanh": LayerType.Tanh,
    "tile": LayerType.Tile,
    "topkindices": LayerType.TopKIndices,
    "topkvalues": LayerType.TopKValues,
    "transpose": LayerType.Transpose,
    "transposeconvolution": LayerType.TransposeConvolution,
    "unsqueeze": LayerType.Unsqueeze,
    "where": LayerType.Where,
    "xor": LayerType.Xor,
    "output": LayerType.Output,
}


def get_dimensions_indices(
    data_format: DATA_FORMAT, dimensions: List[DIMENSION], strict: bool = False
) -> List[Optional[int]]:
    """Get indices of the given dimensions in the data format.

    Args:
        data_format (DATA_FORMAT): Data format.
        dimensions (List[DIMENSION]): List of dimensions to find indices.
        strict (bool, optional): If True, raises ValueError if a dimension is not found in the data format.
                                    Default is False.

    Returns:
        List[Optional[int]]: List of indices of the given dimensions in the data format.
                              If a dimension is not found and strict is False, its index will be None.
    """
    if not isinstance(data_format, DATA_FORMAT):
        raise TypeError(
            f"data_format must be of type DATA_FORMAT, but got {type(data_format)}."
        )

    if not isinstance(dimensions, list):
        raise TypeError(f"dimensions must be a list, but got {type(dimensions)}.")

    indices = []
    for d in dimensions:
        if not isinstance(d, DIMENSION):
            raise TypeError(
                f"dimensions must be a list of DIMENSIONS, but got {type(dimensions)}."
            )

        idx = data_format.name.find(d.name)
        if idx == -1:
            if strict:
                raise ValueError(
                    f"Given dimension {d.name} is not found in the data format: {data_format.name}."
                )
            idx = None
        indices.append(idx)

    return indices


def get_HWC_indices(
    data_format: DATA_FORMAT, strict: bool = False
) -> List[Optional[int]]:
    """Get indices of HWC in the data format.

    Args:
        data_format (DATA_FORMAT): Data format.
        strict (bool, optional): If True, raises ValueError if a dimension is not found in the data format.
                                    Default is False.

    Returns:
        List[Optional[int]]: List of indices of the given dimensions in the data format.
                              If a dimension is not found and strict is False, its index will be None.
    """
    hwc_dims = [DIMENSION.H, DIMENSION.W, DIMENSION.C]
    return get_dimensions_indices(data_format, hwc_dims, strict)


def get_const_value(attr_name, const_dict):
    if isinstance(attr_name, numpy.ndarray):
        return attr_name
    elif isinstance(attr_name, str):
        if attr_name in const_dict:
            v = const_dict[attr_name]["value"]
            return v
        else:
            return None
    else:
        return attr_name


def del_attr(attr_name_list, layer_info):
    if not isinstance(attr_name_list, list):
        raise TypeError(
            f"attr_name_list should be list, but got {type(attr_name_list)}"
        )
    if not isinstance(layer_info, dict):
        raise TypeError(f"layer_info should be dict, but got {type(layer_info)}")
    for attr_name in attr_name_list:
        if not isinstance(attr_name, str):
            raise TypeError(f"attr_name should be str, but got {type(attr_name)}")
        if attr_name in layer_info:
            del layer_info[attr_name]


def partition_inputs(input_list, const_dict):
    """
    Partition input list into constant inputs and non-constant inputs.

    Args:
        input_list (list): List of input names.
        const_dict (dict): Dictionary of constants.

    Returns:
        non_const_inputs (list): List of non-constant input names.
        const_inputs (list): List of constant input names.
    """
    if not isinstance(input_list, list) and len(input_list) in [2, 3]:
        raise ValueError(
            f"input_list should be list of length 2 or 3, " f"but got {input_list}"
        )
    if not isinstance(const_dict, dict):
        raise ValueError(f"const_dict should be dict, " f"but got {const_dict}")

    non_const_inputs, const_inputs = [], []
    for input_name in input_list:
        if input_name in const_dict:
            const_inputs.append(input_name)
        else:
            non_const_inputs.append(input_name)

    return non_const_inputs, const_inputs


def determine_data_format(dict_shape, src_shape, default_data_format=DATA_FORMAT.BCHW):
    """Determine the data format of a tensor from the source framework.

    Args:
        dict_shape (tuple): Tensor shape in model_dict (H, W, C).
        src_shape (tuple): Tensor shape in the original (source) framework.
        default_data_format (DATA_FORMAT, optional): Default data format to return when H == W == C.
                                                      Defaults to DATA_FORMAT.BCHW.

    Returns:
        DATA_FORMAT: Data format of the tensor from the source framework.
    """
    dict_h, dict_w, dict_c = dict_shape
    if len(src_shape) == 4:
        d_0, d_1, d_2, d_3 = src_shape
        if dict_h == dict_w and dict_w == dict_c:
            return default_data_format  # default shape
        if (
            dict_h == d_1 and dict_w == d_2 and dict_c == d_3
        ):  # when c = h = w, it could be corner case
            return DATA_FORMAT.BHWC
        if dict_h == d_2 and dict_w == d_3 and dict_c == d_1:
            return DATA_FORMAT.BCHW
    elif len(src_shape) == 3:
        d_0, d_1, d_2 = src_shape
        if dict_h == dict_w and dict_w == dict_c:
            return default_data_format  # default shape
        if d_0 == dict_h and d_1 == dict_w and d_2 == dict_c:
            return DATA_FORMAT.HWC
        if d_0 == dict_h and d_1 == dict_c and d_2 == dict_w:
            return DATA_FORMAT.HCW
        if d_0 == dict_c and d_1 == dict_h and d_2 == dict_w:
            return DATA_FORMAT.BHW
    elif len(src_shape) == 2:
        d_0, d_1 = src_shape
        if dict_h == 1 and dict_w == 1 and dict_c == d_1:
            return DATA_FORMAT.BC
        if dict_h == 1 and dict_w == 1 and dict_c == d_0:
            return DATA_FORMAT.CB
    elif len(src_shape) == 6:
        d_0, d_1, d_2, d_3, d_4, d_5 = src_shape
        if d_1 == dict_h and d_2 == 1 and d_2 == dict_w and d_4 == 1 and d_5 == dict_c:
            return DATA_FORMAT.BH1W1C
        if (
            d_1 * 2 == dict_h
            and d_2 == 2
            and d_3 * 2 == dict_w
            and d_4 == 2
            and d_5 == dict_c
        ):
            return DATA_FORMAT.BH2W2C

    raise ValueError(
        "Error. dict shape and src shape did not match. dict shape = ",
        dict_shape,
        " || sample shape = ",
        src_shape,
    )


def post_biasadd(layer_name, layer_dict, const_dict):
    layer_info = layer_dict[layer_name]
    layer_info["constant"] = layer_info["bias"]


def post_empty(*args, **kwargs):
    ...


def post_simple_2(layer_name, layer_dict, const_dict):
    layer_info = layer_dict[layer_name]
    input_name_0, input_name_1 = layer_info["inputs"]
    const_name = None
    if input_name_0 in const_dict:
        const_name = input_name_0
        input_name = input_name_1
    elif input_name_1 in const_dict:
        const_name = input_name_1
        input_name = input_name_0

    # one of the inputs is constant
    if const_name is not None:
        layer_info["is_const_first"] = const_name == input_name_0
        layer_info["constant"] = const_name
        layer_info["inputs"] = (input_name,)


def post_simple_3(layer_name, layer_dict, const_dict):
    layer_info = layer_dict[layer_name]
    input_names = get_input_list(layer_info)
    non_const_inputs, const_inputs = partition_inputs(input_names, const_dict)

    if len(const_inputs) > 0:
        layer_info["input"] = non_const_inputs
        layer_info["is_const_first"] = input_names[0] in const_dict
        layer_info["is_const_second"] = input_names[1] in const_dict
        layer_info["is_const_third"] = input_names[2] in const_dict
        constants = []
        for const_name in const_inputs:
            constants.append(numpy.array(const_dict[const_name]["value"]))
        layer_info["const"] = const_inputs[0]
        if len(constants) > 1:
            layer_info["const2"] = const_inputs[1]


def post_conv(layer_name, layer_dict, const_dict):
    layer_info = layer_dict[layer_name]
    input_name = layer_info["inputs"][0]
    d_h = layer_info["h_dilation"]
    d_w = layer_info["w_dilation"]
    s_h = layer_info["h_stride"]
    s_w = layer_info["w_stride"]
    padding_list = layer_info["padding_list"]
    input_src_shape = layer_dict[input_name]["src_shape"]
    weight_name = layer_info["weight"]
    weight = const_dict[weight_name]["value"]

    k_h, k_w, in_ch, out_ch = weight.shape

    tf_pad_mode = layer_info["tf_pad_mode"]
    data_format = layer_info["data_format"]
    if data_format == DATA_FORMAT.BCHW:
        # N, H, W, C = 0, 2, 3, 1
        batch_size, input_channel, input_height, input_width = input_src_shape
    elif data_format == DATA_FORMAT.BHWC:
        # N, H, W, C = 0, 1, 2, 3
        batch_size, input_height, input_width, input_channel = input_src_shape
    else:
        raise ValueError(
            "Error. Unknown type of data format. data format = ", data_format
        )

    if layer_info["type"] == "DepthwiseConvolution":
        group_number = input_channel
        layer_info["group_number"] = group_number
        out_ch *= input_channel
    elif layer_info["type"] == "Convolution":
        group_number = int(input_channel / in_ch)
        layer_info["group_number"] = group_number
        if group_number > 1:
            layer_info["type"] = "GroupConvolution"

    kernel_height = (k_h - 1) * d_h + 1
    kernel_width = (k_w - 1) * d_w + 1

    if tf_pad_mode == "SAME":
        output_height = numpy.ceil(float(input_height) / float(s_h))
        output_width = numpy.ceil(float(input_width) / float(s_w))

        pad_height = max((output_height - 1) * s_h + kernel_height - input_height, 0)
        pad_width = max((output_width - 1) * s_w + kernel_width - input_width, 0)
        p_n = pad_height // 2
        p_s = pad_height - p_n
        p_w = pad_width // 2
        p_e = pad_width - p_w
    elif tf_pad_mode == "VALID":
        p_w, p_e, p_s, p_n = 0, 0, 0, 0
        residual_h = (input_height + p_n + p_s - kernel_height) % s_h
        residual_w = (input_width + p_w + p_e - kernel_width) % s_w
        p_s = p_s - residual_h if residual_h < p_s else 0
        p_e = p_e - residual_w if residual_w < p_e else 0
        output_height = (input_height + p_n + p_s - kernel_height) / s_h + 1
        output_width = (input_width + p_w + p_e - kernel_width) / s_w + 1
    elif tf_pad_mode == "EXPLICIT":
        p_n, p_w, p_s, p_e = padding_list
        residual_h = (input_height + p_n + p_s - kernel_height) % s_h
        residual_w = (input_width + p_w + p_e - kernel_width) % s_w
        p_s = p_s - residual_h if residual_h < p_s else 0
        p_e = p_e - residual_w if residual_w < p_e else 0
        output_height = (input_height + p_n + p_s - kernel_height) / s_h + 1
        output_width = (input_width + p_w + p_e - kernel_width) / s_w + 1
    else:
        raise ValueError(
            "Error. Unknown type of tf pad mode. tf pad mode = ", tf_pad_mode
        )

    const_dict[weight_name]["value"] = numpy.transpose(
        weight, (3, 2, 0, 1)
    )  # weight for torch order
    new_pad_list = (0, p_n, p_w, 0, 0, p_s, p_e, 0)
    layer_info["padding_list"] = new_pad_list
    layer_info["in_channels"] = in_ch
    layer_info["out_channels"] = out_ch
    layer_info["west_padding"] = int(p_w)
    layer_info["east_padding"] = int(p_e)
    layer_info["north_padding"] = int(p_s)
    layer_info["south_padding"] = int(p_n)


def post_tconv(layer_name, layer_dict, const_dict):
    layer_info = layer_dict[layer_name]
    weight_name = layer_info["weight"]
    weight = const_dict[weight_name]["value"]
    k_h, k_w, out_ch, in_ch = weight.shape
    input_name = layer_info["inputs"][0]
    src_shape = layer_dict[input_name]["src_shape"]
    d_h = layer_info["h_dilation"]
    d_w = layer_info["w_dilation"]
    s_h = layer_info["h_stride"]
    s_w = layer_info["w_stride"]
    tf_pad_mode = layer_info["tf_pad_mode"]
    data_format = layer_info["data_format"]

    if data_format == DATA_FORMAT.BCHW:
        # N, H, W, C = 0, 2, 3, 1
        batch_size, input_channel, input_height, input_width = src_shape
    elif data_format == DATA_FORMAT.BHWC:
        # N, H, W, C = 0, 1, 2, 3
        batch_size, input_height, input_width, input_channel = src_shape
    else:
        raise ValueError(
            "Error. Unknown type of data format. data format = ", data_format
        )

    group_number = int(input_channel / in_ch)
    layer_info["group_number"] = group_number
    kernel_height = (k_h - 1) * d_h + 1
    kernel_width = (k_w - 1) * d_w + 1

    if tf_pad_mode == "SAME":
        pad_height = (kernel_height - 1) + (s_h - 1)
        pad_width = (kernel_width - 1) + (s_w - 1)
        p_s = pad_height // 2
        p_n = pad_height - p_s
        p_e = pad_width // 2
        p_w = pad_width - p_e
    elif tf_pad_mode == "VALID":
        # padding values are zero in this case.
        p_w, p_e, p_s, p_n = k_w - 1, k_w - 1, k_h - 1, k_h - 1
    elif tf_pad_mode == "EXPLICIT":
        p_n, p_w, p_s, p_e = layer_info["padding_list"]
    else:
        raise ValueError(
            "Error. Unknown type of tf pad mode. tf pad mode = ", tf_pad_mode
        )

    layer_info["in_channels"] = in_ch
    layer_info["out_channels"] = out_ch
    layer_info["west_padding"] = int(p_w)
    layer_info["east_padding"] = int(p_e)
    layer_info["north_padding"] = int(p_s)  # NPU's north, south is inversed
    layer_info["south_padding"] = int(p_n)  # NPU's north, south is inversed


def post_maxpool(layer_name, layer_dict, const_dict):
    layer_info = layer_dict[layer_name]
    input_name = layer_info["inputs"][0]
    d_h = layer_info["h_dilation"]
    d_w = layer_info["w_dilation"]
    k_h = layer_info["h_kernel"]
    k_w = layer_info["w_kernel"]
    s_h = layer_info["h_stride"]
    s_w = layer_info["w_stride"]
    padding_list = layer_info["padding_list"]
    input_src_shape = layer_dict[input_name]["src_shape"]
    kernel_height = (k_h - 1) * d_h + 1
    kernel_width = (k_w - 1) * d_w + 1
    pad_mode = "-inf"

    tf_pad_mode = layer_info["tf_pad_mode"]
    data_format = layer_info["data_format"]

    if data_format == DATA_FORMAT.BCHW:
        N, H, W, C = 0, 2, 3, 1
    elif data_format == DATA_FORMAT.BHWC:
        N, H, W, C = 0, 1, 2, 3
    else:
        raise ValueError(
            "Error. Unknown type of data format. data format = ", data_format
        )

    input_height, input_width, input_channel = (
        input_src_shape[H],
        input_src_shape[W],
        input_src_shape[C],
    )

    kernel_height = k_h
    kernel_width = k_w

    if tf_pad_mode == "SAME":
        output_height = numpy.ceil(float(input_height) / float(s_h))
        output_width = numpy.ceil(float(input_width) / float(s_w))

        pad_height = max((output_height - 1) * s_h + kernel_height - input_height, 0)
        pad_width = max((output_width - 1) * s_w + kernel_width - input_width, 0)
        p_n = pad_height // 2
        p_s = pad_height - p_n
        p_w = pad_width // 2
        p_e = pad_width - p_w
    elif tf_pad_mode == "VALID":
        p_w, p_e, p_s, p_n = 0, 0, 0, 0
        residual_h = (input_height + p_n + p_s - kernel_height) % s_h
        residual_w = (input_width + p_w + p_e - kernel_width) % s_w
        p_s = p_s - residual_h if residual_h < p_s else 0
        p_e = p_e - residual_w if residual_w < p_e else 0
    elif tf_pad_mode == "EXPLICIT":
        p_n, p_s = padding_list[H]
        p_w, p_e = padding_list[W]
        residual_h = (input_height + p_n + p_s - kernel_height) % s_h
        residual_w = (input_width + p_w + p_e - kernel_width) % s_w
        p_s = p_s - residual_h if residual_h < p_s else 0
        p_e = p_e - residual_w if residual_w < p_e else 0
    else:
        raise ValueError(
            "Error. Unknown type of tf pad mode. tf pad mode = ", tf_pad_mode
        )

    layer_info["type"] = "Pooling"
    layer_info["pool_type"] = "MaxPool"
    layer_info["pad_mode"] = pad_mode
    layer_info["west_padding"] = int(p_w)
    layer_info["east_padding"] = int(p_e)
    layer_info["north_padding"] = int(p_s)  # NPU's north, south is inversed
    layer_info["south_padding"] = int(p_n)  # NPU's north, south is inversed


def post_avgpool(layer_name, layer_dict, const_dict):
    layer_info = layer_dict[layer_name]
    input_name = layer_info["inputs"][0]
    k_h = layer_info["h_kernel"]
    k_w = layer_info["w_kernel"]
    s_h = layer_info["h_stride"]
    s_w = layer_info["w_stride"]
    input_src_shape = layer_dict[input_name]["src_shape"]

    tf_pad_mode = layer_info["tf_pad_mode"]
    data_format = layer_info["data_format"]

    if data_format == DATA_FORMAT.BCHW:
        N, H, W, C = 0, 2, 3, 1
    elif data_format == DATA_FORMAT.BHWC:
        N, H, W, C = 0, 1, 2, 3
    else:
        raise ValueError(
            "Error. Unknown type of data format. data format = ", data_format
        )
    input_height, input_width, input_channel = (
        input_src_shape[H],
        input_src_shape[W],
        input_src_shape[C],
    )

    if tf_pad_mode == "SAME":
        output_height = numpy.ceil(float(input_height) / float(s_h))
        output_width = numpy.ceil(float(input_width) / float(s_w))
        pad_height = max((output_height - 1) * s_h + k_h - input_height, 0)
        pad_width = max((output_width - 1) * s_w + k_w - input_width, 0)
        p_n = pad_height // 2
        p_s = pad_height - p_n
        p_w = pad_width // 2
        p_e = pad_width - p_w
    elif tf_pad_mode == "VALID":
        p_w, p_e, p_s, p_n = 0, 0, 0, 0
        residual_h = (input_height + p_n + p_s - k_h) % s_h
        residual_w = (input_width + p_w + p_e - k_w) % s_w
        p_s = p_s - residual_h if residual_h < p_s else 0
        p_e = p_e - residual_w if residual_w < p_e else 0
    elif tf_pad_mode == "EXPLICIT":
        padding_list = layer_info["padding_list"]
        p_n, p_s = padding_list[H]
        p_w, p_e = padding_list[W]
        residual_h = (input_height + p_n + p_s - k_h) % s_h
        residual_w = (input_width + p_w + p_e - k_w) % s_w
        p_s = p_s - residual_h if residual_h < p_s else 0
        p_e = p_e - residual_w if residual_w < p_e else 0
    else:
        raise ValueError(
            "Error. Unknown type of tf pad mode. tf pad mode = ", tf_pad_mode
        )

    layer_info["h_dilation"] = 1
    layer_info["w_dilation"] = 1
    layer_info["west_padding"] = int(p_w)
    layer_info["east_padding"] = int(p_e)
    layer_info["north_padding"] = int(p_s)  # NPU's north, south is inversed
    layer_info["south_padding"] = int(p_n)  # NPU's north, south is inversed


def post_pad(layer_name, layer_dict, const_dict):
    input_name = layer_dict[layer_name]["inputs"][0]
    layer_info = layer_dict[layer_name]
    pad_mode = layer_info["pad_mode"]
    pad = get_const_value(layer_info["pad"], const_dict)
    constant = float(get_const_value(layer_info["constant"], const_dict))
    layer_info["original_pad_list"] = pad

    H, W = get_dimensions_indices(DATA_FORMAT.BHWC, [DIMENSION.H, DIMENSION.W], True)
    p_n, p_s = pad[H]
    p_w, p_e = pad[W]

    new_pad_list = (0, p_n, p_w, 0, 0, p_s, p_e, 0)
    layer_info["padding_list"] = new_pad_list
    layer_info["west_padding"] = p_w
    layer_info["east_padding"] = p_e
    layer_info["north_padding"] = p_s
    layer_info["south_padding"] = p_n
    layer_info["constant"] = constant
    layer_info["pad_mode"] = pad_mode


def post_resize(layer_name, layer_dict, const_dict):
    input_name = layer_dict[layer_name]["inputs"][0]
    input_src_shape = layer_dict[input_name]["src_shape"]
    layer_info = layer_dict[layer_name]

    layer_src_shape = layer_info["src_shape"]
    scales_name = layer_info["scales"]
    sizes_name = layer_info["sizes"]
    resize_mode = layer_info["resize_mode"]

    _axes = layer_info.get("axes")
    if _axes is None:
        axes = list(range(len(input_src_shape)))
    else:
        axes = _axes

    keep_aspect_ratio_policy = layer_info.get("keep_aspect_ratio_policy", "stretch")
    input_shape = input_src_shape[
        1:
    ]  # Input of tensorflow::ops::Resize~ has BHWC channel order.
    data_format = determine_data_format(input_shape, input_src_shape)
    H, W = get_dimensions_indices(data_format, [DIMENSION.H, DIMENSION.W], True)
    axis_to_i = {H: 0, W: 1}  # sizes always have (target_height, target_width).
    input_height, input_width, input_channel = input_shape

    scales = get_const_value(scales_name, const_dict)
    sizes = get_const_value(sizes_name, const_dict)
    if scales is None or len(scales) == 0:
        if keep_aspect_ratio_policy == "stretch":
            output_height = sizes[axis_to_i[H]]
            output_width = sizes[axis_to_i[W]]
        elif keep_aspect_ratio_policy == "not_larger":
            scale = min(
                [sizes[i] / input_src_shape[axes[i]] for i in range(len(sizes))]
            )
            output_height = int(input_height * scale + 0.5)
            output_width = int(input_width * scale + 0.5)
        elif keep_aspect_ratio_policy == "not_smaller":
            scale = max(
                [sizes[i] / input_src_shape[axes[i]] for i in range(len(sizes))]
            )
            output_height = int(input_height * scale + 0.5)
            output_width = int(input_width * scale + 0.5)
        else:
            raise ValueError(
                f"Got unexpected keep_aspect_ratio_policy={keep_aspect_ratio_policy}"
            )
    else:
        scale_height = scales[axis_to_i[H]]
        scale_width = scales[axis_to_i[W]]
        output_height = int(input_height * scale_height)
        output_width = int(input_width * scale_width)

    output_channel = int(input_channel)
    output_shape = [output_height, output_width, output_channel]

    layer_info["resize_type"] = resize_mode
    layer_info["activation"] = None
    layer_info["input_shape"] = [input_shape]
    layer_info["output_shape"] = output_shape
    layer_info["src_shape"] = layer_src_shape


def post_nms(layer_name, layer_dict, const_dict):
    layer_info = layer_dict[layer_name]
    layer_info["max_output_size"] = layer_info["max_output"]
    layer_info["iou_threshold"] = layer_info["iou_thres"]
    layer_info["score_threshold"] = layer_info["score_thres"]
    layer_info["soft_nms_sigma"] = 0  # should be checked
    layer_info["pad_to_max_output_size"] = False  # should be checked


def post_tile(layer_name, layer_dict, const_dict):
    input_name = layer_dict[layer_name]["inputs"][0]
    input_src_shape = layer_dict[input_name]["src_shape"]
    input_shape = layer_dict[input_name]["output_shape"]
    layer_info = layer_dict[layer_name]
    repeats = get_const_value(layer_info["repeats"], const_dict)
    repeats = [int(r) for r in repeats]
    if len(input_src_shape) == 3:
        data_format = determine_data_format(
            input_shape, input_src_shape, DATA_FORMAT.HWC
        )
        H, W, C = get_HWC_indices(data_format)
        out_H = input_src_shape[H] * repeats[H]
        out_W = input_src_shape[W] * repeats[W]
        out_C = input_src_shape[C] * repeats[C]
        output_shape = [out_H, out_W, out_C]
        real_repeats = (repeats[C], repeats[H], repeats[W])
    elif len(input_src_shape) == 4:
        data_format = determine_data_format(
            input_shape, input_src_shape, DATA_FORMAT.BHWC
        )
        H, W, C = get_HWC_indices(data_format)
        out_H = input_src_shape[H] * repeats[H]
        out_W = input_src_shape[W] * repeats[W]
        out_C = input_src_shape[C] * repeats[C]
        output_shape = [out_H, out_W, out_C]
        real_repeats = (repeats[C], repeats[H], repeats[W])
    elif len(input_src_shape) == 2:
        data_format = determine_data_format(
            input_shape, input_src_shape, DATA_FORMAT.BC
        )
        C = get_dimensions_indices(data_format, [DIMENSION.C], True)[0]
        out_C = input_src_shape[C] * repeats[C]
        output_shape = copy.copy(input_shape)
        output_shape[2] = out_C
        real_repeats = (repeats[C], 1, 1)

    layer_info["repeats"] = repeats
    layer_info["real_repeats"] = real_repeats
    layer_info["input_shape"] = [input_shape]
    layer_info["output_shape"] = output_shape


def post_split(layer_name, layer_dict, const_dict):
    def check_axis(axis, ndim):
        if isinstance(axis, numpy.ndarray) and len(axis.shape) == 0:
            axis = int(axis)

        assert isinstance(axis, int) and axis < ndim and axis >= -ndim
        # Update negative axis
        if axis < 0:
            axis += ndim
        return axis

    input_name = layer_dict[layer_name]["inputs"][0]
    layer_info = layer_dict[layer_name]
    input_src_shape = layer_dict[input_name]["src_shape"]
    axis = layer_info["axis"]
    split = get_const_value(layer_info["split"], const_dict)

    axis = check_axis(axis, len(input_src_shape))

    layer_info["axis"] = axis
    layer_info["split"] = split


TFPOSTFUNCMAPPER = {
    "abs": post_empty,
    "adding": post_empty,
    "and": post_simple_2,
    "argmax": post_empty,
    "argmin": post_empty,
    "avgpool": post_avgpool,
    "batchnorm": post_empty,
    "cast": post_empty,
    "ceil": post_empty,
    "clip": post_empty,
    "concatenate": post_empty,
    "convolution": post_conv,
    "depthwiseconvolution": post_conv,
    "div": post_empty,
    "erf": post_empty,
    "equal": post_simple_2,
    "exp": post_empty,
    "floor": post_empty,
    "gather": post_simple_2,
    "gathernd": post_simple_2,
    "greater": post_simple_2,
    "identity": post_empty,
    "input": post_empty,
    "less": post_simple_2,
    "leakyrelu": post_empty,
    "matmul": post_empty,
    "maximum": post_empty,
    "maxpool": post_maxpool,
    "minimum": post_empty,
    "mod": post_simple_2,
    "mul": post_empty,
    "neg": post_empty,
    "nms": post_nms,
    "nonzero": post_empty,
    "not": post_empty,
    "or": post_simple_2,
    "pad": post_pad,
    "pow": post_empty,
    "range": post_simple_3,
    "reciprocal": post_empty,
    "reducemax": post_empty,
    "reducemean": post_empty,
    "reducemin": post_empty,
    "reduceprod": post_empty,
    "reducesum": post_empty,
    "reshape": post_empty,
    "relu": post_empty,
    "round": post_empty,
    "rsqrt": post_empty,
    "shape": post_empty,
    "sigmoid": post_empty,
    "slice": post_empty,
    "softplus": post_empty,
    "softmax": post_empty,
    "split": post_split,
    "sqrt": post_empty,
    "squareddifference": post_empty,
    "squeeze": post_empty,
    "sub": post_empty,
    "tanh": post_empty,
    "tile": post_tile,
    "topkindices": post_simple_2,
    "topkvalues": post_simple_2,
    "transpose": post_empty,
    "transposeconvolution": post_tconv,
    "unsqueeze": post_empty,
    "where": post_simple_3,
    "xor": post_simple_2,
    "multiply": post_empty,
    "pooling": post_empty,
    "biasadd": post_biasadd,
}


def get_post_func(layer_info: Dict[str, Any]):
    layertype = layer_info.get("type", "empty")
    return TFPOSTFUNCMAPPER[layertype.lower()]


def _get_field_info(layertype: LayerOptions) -> Dict[str, Any]:
    field_info = {}
    for field in dataclasses.fields(layertype):
        field_info[field.name] = {}
        if hasattr(field.type, "__origin__"):
            # ex) in the case of tuple class input, tuple
            field_info[field.name]["type"] = field.type.__origin__
            # ex) field_dtype nummpy.int32, ... -> Ellipsis class
            field_info[field.name]["dtype"] = field.type.__args__
        else:
            field_info[field.name]["type"] = None
            field_info[field.name]["dtype"] = field.type
    return field_info


def get_src_shape_dict(layer_dict: Dict[str, Any]) -> Dict[str, Tuple[int, ...]]:
    src_shape_dict = {}
    for layer_name, info in layer_dict.items():
        src_shape_dict[layer_name] = info.get("src_shape", tuple())

    return src_shape_dict


def inputs_mapper(layer_name, layer_info: Dict[str, Any]):
    if layer_info["type"] == "input":
        layer_info["inputs"] = (layer_name,)
        # layer_info["inputs"] = (layer_name + "_input",)
    elif {"input0", "input1"}.issubset(layer_info):
        layer_info["inputs"] = (layer_info["input0"], layer_info["input1"])
        del layer_info["input0"], layer_info["input1"]
    elif isinstance(layer_info.get("input", None), list):
        layer_info["inputs"] = tuple(layer_info["input"])
        del layer_info["input"]
    elif isinstance(layer_info.get("input", None), str):
        layer_info["inputs"] = (layer_info["input"],)
        del layer_info["input"]
    else:
        raise NotImplementedError


def outputs_mapper(layer_info: Dict[str, Any]):
    if isinstance(layer_info["output"], list):
        layer_info["outputs"] = tuple(layer_info["output"])
        del layer_info["output"]
    else:
        raise NotImplementedError


def inoutmapper(layer_dict: Dict[str, Any]):
    for layer_name, info in layer_dict.items():
        inputs_mapper(layer_name, info)
        outputs_mapper(info)


def get_in_out_list(layer_dict: Dict[str, Any]):
    inputs = set()
    outputs = set()
    for name, layer_info in layer_dict.items():
        inputs.update(set(layer_info["inputs"]))
        outputs.update((layer_info["outputs"]))
        if outputs == ():
            outputs.update(name)

    output_list = [
        layer_name for layer_name in list(outputs - inputs) if layer_name in layer_dict
    ]
    input_list = [
        layer_name for layer_name in list(inputs - outputs) if layer_name in layer_dict
    ]

    return input_list, output_list


def set_dtype_shape(
    layer_dict: Dict[str, Any], const_dict: dict, in_dataformat: Dict[str, str]
):
    # Forward
    input_list, _ = get_in_out_list(layer_dict)
    if in_dataformat is not None:
        if set(in_dataformat.keys()) != set(input_list):
            logger.info(
                f"in_dataformat and model input name are not matched, input names: {input_list}, dformats: {in_dataformat}"
            )
        for in_name in input_list:
            if in_name in in_dataformat:
                if in_dataformat[in_name] not in DATAFORMAT_LIST:
                    raise ValueError
                validate_src_shape_dformat(
                    layer_dict[in_name]["src_shape"], DataFormat[in_dataformat[in_name]]
                )
                layer_dict[in_name]["dataformat"] = DataFormat[in_dataformat[in_name]]
    else:
        layer_type = set([layer_info["type"] for layer_info in layer_dict.values()])
        supported_type = {
            "Convolution",
            "DepthwiseConvolution",
            "GroupConvolution",
            "Pooling",
        }
        for input_name in input_list:
            if (
                len(layer_dict[input_name]["src_shape"]) == 3
                and (supported_type & layer_type) == set()
            ):
                layer_dict[input_name]["dataformat"] = DataFormat.UNKNOWN
                print(
                    f"dataformat of {input_name} is automatically set to HWC, but you can manually change the dataformat using in_dformats if needed"
                )

    for name, layer_info in layer_dict.items():
        src_shape = layer_info["src_shape"]
        old_dformat = layer_info.get("data_format", DATA_FORMAT.UNKNOWN)
        dformat = TFDATAFORMATMAPPER.get(old_dformat, DataFormat.UNKNOWN)
        layer_info["dataformat"] = dformat
        try:
            if len(src_shape) in [3, 4]:
                idx = get_dimensions_indices(
                    dataformat=dformat,
                    dimensions=[DIMENSION.H, DIMENSION.W, DIMENSION.C],
                )
                shape = (src_shape[idx[0]], src_shape[idx[1]], src_shape[idx[2]])
            elif len(src_shape) in [1, 2]:
                idx = get_dimensions_indices(
                    dataformat=dformat, dimensions=[DIMENSION.C]
                )
                shape = (1, 1, src_shape[idx[0]])
            else:
                shape = (-1, -1, -1)
        except Exception as e:
            shape = (-1, -1, -1)
        layer_info["shape"] = shape


def layer_dict_post(layer_dict: Dict[str, Any], const_dict: Dict[str, Any]):
    for layer_name, layer_info in layer_dict.items():
        post_func = get_post_func(layer_info)
        post_func(layer_name, layer_dict, const_dict)
        for key, value in layer_info.items():
            if isinstance(value, str) and not value:
                layer_info[key] = None


def add_output_layer_list(
    layer_dict: Dict[str, Any], value_dict: Dict[str, Any], const_dict, src_output_list
):
    # _, output_list = get_in_out_list(layer_dict)
    src_output_list = [output for output in src_output_list if output not in const_dict]
    for out_name in src_output_list:
        if out_name in layer_dict:
            output_layer_name = out_name + "_layer"
            info = {
                "type": "output",
                "inputs": (out_name,),
                "outputs": (out_name,),
                "is_output": True,
                "shape": layer_dict[out_name]["shape"],
                "src_shape": layer_dict[out_name]["src_shape"],
                "dataformat": layer_dict[out_name]["dataformat"],
            }

            layer_dict[output_layer_name] = info
            value_dict[output_layer_name] = value_dict[out_name]


def in_const_dict(item, const_dict):
    try:
        return item in const_dict
    except Exception as e:
        return False


def _find_tensor_idx_key(layeroption: LayerOptions) -> List[str]:
    fields_info = _get_field_info(layeroption)
    tensor_idx_keys = []
    for field_key, info in fields_info.items():
        if info["dtype"] == TensorIndex:
            tensor_idx_keys.append(field_key)

    return tensor_idx_keys


class PostTFMapper:
    def __init__(self):
        self._ori_layer_dict = None
        self._source_shape = None

        self.tensor_names = []
        self.name_to_idx = {}

        self._tensor_idx = 0
        self._name_idx = 0
        self._debug_idx = 0
        self._gen_idx = 0

    def next_name_idx(self):
        idx = self._name_idx
        self._name_idx += 1
        return idx

    def next_gen_idx(self):
        idx = self._gen_idx
        self._gen_idx += 1
        return idx

    def next_tensor_index(self) -> TensorIndex:
        idx = TensorIndex(self._tensor_idx)
        self._tensor_idx += 1
        return idx

    def map(
        self, legacy_tf_dict, in_dformats: Dict[str, str]
    ) -> Dict[str, LayerOptions]:
        layer_dict: Dict[str, Any] = legacy_tf_dict.layer_dict
        const_dict: Dict[str, Any] = legacy_tf_dict.const_dict
        value_dict: Dict[str, Any] = legacy_tf_dict.sample_value_dict
        inoutmapper(layer_dict)
        set_dtype_shape(layer_dict, const_dict, in_dformats)
        layer_dict_post(layer_dict, const_dict)
        add_output_layer_list(
            layer_dict, value_dict, const_dict, legacy_tf_dict.src_output_list
        )
        _option_dict = {k: {} for k in layer_dict.keys()}
        _fail_layer_dict = copy.deepcopy(_option_dict)

        for layer_name, info in layer_dict.items():
            layer_type = info["type"].lower()
            class_type = Registry.getcls(TFLAYERTYPEMAPPER[layer_type])
            _option_dict[layer_name]["type"] = class_type
            _fields_info = _get_field_info(class_type)
            str_fields = [
                fd.name
                for fd in dataclasses.fields(class_type)
                if fd.type.__name__ == "str"
            ]

            for _field_name, _fields_info in _fields_info.items():
                if _field_name in info:
                    if (
                        _field_name not in str_fields
                        and _fields_info["dtype"] is not TensorIndex
                        and in_const_dict(info.get(_field_name, None), const_dict)
                    ):
                        _option_dict[layer_name][_field_name] = get_const_value(
                            info[_field_name], const_dict
                        )
                    else:
                        _option_dict[layer_name][_field_name] = info[_field_name]
                else:
                    _fail_layer_dict[layer_name][_field_name] = None

        return self._get_tf_options(_option_dict, const_dict)

    def _inout_name_to_idx(
        self, layer_name: str, layer_info: dict, class_type: "LayerOptions", const_dict
    ):
        input_idx = []
        for input_name in layer_info["inputs"]:
            if class_type in (options.InputOptions, options.OutputOptions):
                if not input_name in self.name_to_idx:
                    self.name_to_idx[input_name] = self.next_name_idx()
                else:
                    pass
                self.name_to_idx[layer_name] = self.name_to_idx[input_name]
                layer_info["outputs"] = (self.name_to_idx[layer_name],)
            elif not input_name in self.name_to_idx:
                self.name_to_idx[input_name] = self.next_name_idx()
            elif input_name in self.name_to_idx and input_name in const_dict:
                old_name = input_name
                input_name = f"{input_name}_M{self.next_gen_idx()}"
                self.name_to_idx[input_name] = self.next_name_idx()
                const_dict[input_name] = const_dict[old_name]
            else:
                pass
            input_idx.append(self.name_to_idx[input_name])
        layer_info["inputs"] = tuple(input_idx)

        if not layer_name in self.name_to_idx:
            self.name_to_idx[layer_name] = self.next_name_idx()
        layer_info["outputs"] = (self.name_to_idx[layer_name],)

    def _get_tf_options(
        self, option_dict: Dict[str, Any], const_dict
    ) -> Dict[str, LayerOptions]:
        tf_options = {}
        try:
            for layer_name, layer_info in option_dict.items():
                class_type = layer_info.pop("type")
                input_names = layer_info["inputs"]

                self._inout_name_to_idx(layer_name, layer_info, class_type, const_dict)
                tensor_idx_keys = _find_tensor_idx_key(class_type)

                for input_name in input_names:
                    if (
                        in_const_dict(input_name, const_dict)
                        and input_name not in self.tensor_names
                        and "constant" in tensor_idx_keys
                    ):
                        self.tensor_names.append(input_name)
                        layer_info["constant"] = self.next_tensor_index()
                # when one of the input is used as a "constant" Tensoridx
                for option_key in tensor_idx_keys:
                    if option_key not in layer_info:
                        continue

                    if (
                        isinstance(layer_info[option_key], TensorIndex)
                        and layer_info[option_key] >= 0
                    ):
                        continue

                    if (
                        in_const_dict(layer_info[option_key], const_dict)
                        and layer_info[option_key] in self.tensor_names
                    ):
                        old_name = layer_info[option_key]
                        const_name = f"{old_name}_M{self.next_gen_idx()}"
                        self.tensor_names.append(const_name)
                        const_dict[const_name] = const_dict[old_name]
                        layer_info[option_key] = self.next_tensor_index()
                        continue

                    if layer_info[option_key] is None:
                        del layer_info[option_key]
                        continue
                    elif not isinstance(layer_info[option_key], str):
                        const_name = f"{layer_name}_{option_key}_M{self.next_gen_idx()}"
                        const_dict[const_name] = {
                            "type": "Const",
                            "value": numpy.array(layer_info[option_key]),
                            "op": "Constant",
                        }
                        self.tensor_names.append(const_name)
                        layer_info[option_key] = self.next_tensor_index()
                    else:
                        self.tensor_names.append(layer_info[option_key])
                        layer_info[option_key] = self.next_tensor_index()
                dct = {}
                for k, v in layer_info.items():
                    if v is None:
                        continue
                    if isinstance(v, ValueWrapper):
                        v = v.value
                    dct[k] = v
                tf_options[layer_name] = class_type(**dct)
        except Exception as e:
            print(
                f"error while mapping layer to options. layer_name={layer_name}, dct={dct}"
            )
            raise e

        return tf_options
