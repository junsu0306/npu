import importlib
from typing import Dict, Optional

from .torch_modules import is_torch_module, make_torch_module
from .abc import ModuleParserBase


class MakeDynamicObject:
    def __init__(
        self, dynamic_module_path: Dict, module_class_path: Optional[Dict] = None
    ):
        """
        Args:
            dynamic_module_path: map of (module_name, module_path)
            ex)
            _OUTETTS_BASE_PATH = "qbcompiler/model_dict/parser/backend/misc/oute_ai/outetts"
            dynamic_module_path = {
                "decoder.models"             : _OUTETTS_BASE_PATH + "/wav_tokenizer/decoder/models",
                "decoder.modules"            : _OUTETTS_BASE_PATH + "/wav_tokenizer/decoder/modules",
                "decoder.heads"              : _OUTETTS_BASE_PATH + "/wav_tokenizer/decoder/heads",
                "decoder.spectral_ops"       : _OUTETTS_BASE_PATH + "/wav_tokenizer/decoder/spectral_ops",
                "outetts.wav_tokenizer.model": _OUTETTS_BASE_PATH + "/wav_tokenizer/model",
            }
        """

        self.dynamic_module_path = dynamic_module_path
        self.module_class_path = module_class_path

    def __call__(self, instance, name_with_prefix="", **kwargs) -> ModuleParserBase:
        if is_torch_module(instance):
            return make_torch_module(instance, name_with_prefix, make_module_fn=self)

        cls_name = instance.__class__.__name__
        inst_module_name = instance.__class__.__module__
        if inst_module_name == "builtins":
            if cls_name in ("int", "float", "bool", "str", "NoneType"):
                return instance
            if cls_name == "list":
                return [self(x) for x in instance]
            if cls_name == "tuple":
                return tuple(self(x) for x in instance)
            if cls_name == "dict":
                return {k: self(v) for k, v in instance.items()}

        if inst_module_name == "torch.nn.parameter" and cls_name == "Parameter":
            return instance
        if inst_module_name == "torch" and cls_name == "Tensor":
            return instance

        if inst_module_name in self.dynamic_module_path:
            module_path = self.dynamic_module_path[inst_module_name].replace("/", ".")
        elif self.module_class_path is not None and cls_name in self.module_class_path:
            module_path = self.module_class_path[cls_name].replace("/", ".")
        else:
            raise NotImplementedError(inst_module_name, cls_name)

        try:
            mblt_module = importlib.import_module(module_path)
            obj = getattr(mblt_module, cls_name)(instance, name_with_prefix, self)
            return obj
        except Exception as e:
            print(
                f"failed to import parser implementation of the class: {inst_module_name}.{cls_name}"
            )
            raise e
