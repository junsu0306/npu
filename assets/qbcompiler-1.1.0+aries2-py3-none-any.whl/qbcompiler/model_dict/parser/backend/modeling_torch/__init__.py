from qbcompiler.model_dict.parser.backend.modeling_torch.abc import ModuleParserBase
from .torch_modules import is_torch_module, make_torch_module
from .modules import *

__all__ = ["ModuleParserBase", "is_torch_module", "make_torch_module"]
