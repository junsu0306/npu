from typing import Type, Optional


class Registry:
    def __init__(self, name):
        self.name = name
        self._registry = {}

    def add_to_registry(self, base_module: Optional[Type] = None):
        def decorator(cls):
            self._registry[cls.__name__] = (cls, base_module)
            return cls

        return decorator

    def get(self, name):
        """Retrieve a registered class by name."""
        if name not in self._registry:
            raise KeyError(f"'{name}' is not registered in the registry.")
        return self._registry[name][0]

    def is_registered(self, name):
        """Check if a class is registered by name."""
        return name in self._registry

    def list_registered(self):
        """List all registered module names."""
        return list(self._registry.keys())

    def get_base_module(self, name):
        return self._registry[name][1]
