import numpy
import torch

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.modeling_torch.torch_modules import (
    torch_registry,
    ModelingTorchBase,
)


@torch_registry.add_to_registry(torch.nn.modules.dropout.Dropout)
class Dropout(ModelingTorchBase):
    __slots__ = ("p", "training")

    def forward(self, x: ActivationSpec):
        if numpy.allclose(self.p, 0) or not self.training:
            return self.builder.make_identity(x, opname=self.module_name)
        raise NotImplementedError(f"dropout with p={self.p}, training={self.training}")
