import torch

from qbcompiler.model_dict.common import ActivationSpec, DataFormat, Operator
from qbcompiler.model_dict.parser.backend.modeling_torch.torch_modules import (
    torch_registry,
    ModelingTorchBase,
)


@torch_registry.add_to_registry(torch.nn.modules.sparse.Embedding)
class Embedding(ModelingTorchBase):
    def __init__(self, model, module_name: str = "", make_module_fn=None, **kwargs):
        super().__init__(model, module_name, make_module_fn)
        self.num_embeddings = model.num_embeddings  # 128256
        self.embedding_dim = model.embedding_dim  # 2048
        self.weight = model.weight  # (num_embeddings, embedding_dim)

    def forward(self, input_ids: ActivationSpec | torch.Tensor):
        if len(self.weight.shape) != 2:
            raise NotImplementedError("len(weight.shape)!=2")

        if isinstance(input_ids, torch.Tensor):
            return self.reference_model(
                input_ids.to(self.reference_model.weight.device)
            )
        return self.builder.make_gather(
            self.weight, input_ids, 0, opname=self.module_name
        )
