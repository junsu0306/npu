import torch

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.modeling_torch.torch_modules import (
    torch_registry,
    ModelingTorchBase,
    to_channel_last,
)


@torch_registry.add_to_registry(torch.nn.modules.batchnorm.BatchNorm2d)
class BatchNorm2d(ModelingTorchBase):
    __slots__ = (
        "num_features",
        "eps",
        "momentum",
        "running_mean",
        "running_var",
        "weight",
        "bias",
    )

    @to_channel_last(4)
    def forward(self, x: ActivationSpec) -> ActivationSpec:
        return self.builder.make_batchnorm(
            x,
            gamma=self.weight,
            beta=self.bias,
            moving_mean=self.running_mean,
            moving_var=self.running_var,
            epsilon=self.eps,
            opname=self.module_name,
        )
