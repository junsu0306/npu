import collections
import functools

import torch

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.modeling_torch.torch_modules import (
    ModelingTorchBase,
    torch_registry,
)


@torch_registry.add_to_registry(torch.nn.modules.container.Sequential)
class Sequential(ModelingTorchBase):
    __slots__ = ("_modules",)

    def __init__(
        self, model, name_with_prefix: str = "", make_module_fn=None, **kwargs
    ):
        super().__init__(None, name_with_prefix, make_module_fn)
        self._modules = collections.OrderedDict(
            (str(i), make_module_fn(x, f"{name_with_prefix}.{i}", **kwargs))
            for i, x in enumerate(model)
        )

    def __iter__(self):
        return iter(self._modules.values())

    def __len__(self):
        return len(self._modules)

    def forward(self, x: ActivationSpec) -> ActivationSpec:
        return functools.reduce(lambda acc, m: m(acc), self, x)


@torch_registry.add_to_registry(torch.nn.modules.container.ModuleList)
class ModuleList(ModelingTorchBase):
    def __init__(
        self, model, name_with_prefix: str = "", make_module_fn=None, **kwargs
    ):
        super().__init__(None, name_with_prefix, make_module_fn)
        self._modules = collections.OrderedDict(
            (str(i), make_module_fn(x, f"{name_with_prefix}.{i}", **kwargs))
            for i, x in enumerate(model)
        )

    def __iter__(self):
        return iter(self._modules.values())

    def __len__(self):
        return len(self._modules)

    def forward(self, x: ActivationSpec) -> ActivationSpec:
        return functools.reduce(lambda acc, m: m(acc), self, x)


@torch_registry.add_to_registry(torch.nn.modules.container.ModuleDict)
class ModuleDict(ModelingTorchBase):
    __slots__ = ("_modules",)

    def __init__(
        self, model, name_with_prefix: str = "", make_module_fn=None, **kwargs
    ):
        super().__init__(None, name_with_prefix, make_module_fn)
        self._modules = collections.OrderedDict(
            (k, make_module_fn(v, f"{name_with_prefix}.{k}", **kwargs))
            for k, v in model.items()
        )

    def __len__(self):
        return len(self._modules)

    def __iter__(self):
        return iter(self._modules)
