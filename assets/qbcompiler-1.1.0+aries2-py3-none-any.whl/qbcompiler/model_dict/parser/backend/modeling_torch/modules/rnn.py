import torch

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.modeling_torch.torch_modules import (
    torch_registry,
    ModelingTorchBase,
)


def to_onnx_weight(w_, hidden_size):
    r, z, n = torch.split(w_, hidden_size, dim=0)
    return torch.cat((z, r, n))


# @torch_registry.add_to_registry(torch.nn.modules.rnn.LSTM)
# class LSTM(ModelingTorchBase):
#     __slots__ = (
#         "input_size",
#         "num_layers",
#         "hidden_size",
#         "bias",
#         "batch_first",
#         "bidirectional",
#         "proj_size",
#     )
#
#     def forward(self, x: ActivationSpec, hx=None) -> ActivationSpec:
#         if self.num_layers > 1:
#             raise NotImplementedError
#         N = x.get_act_src_shape()[0]
#         D = 2 if self.bidirectional == True else 1
#         if hx is not None:
#             h0, c0 = hx
#             h0_new_shape = [self.num_layers, D] + h0.shape[1:]
#             c0_new_shape = [self.num_layers, D] + c0.shape[1:]
#             h0 = self.builder.make_reshape(h0, tuple(h0_new_shape))
#             c0 = self.builder.make_reshape(c0, tuple(c0_new_shape))
#         else:
#             Hout = self.proj_size if self.proj_size > 0 else self.hidden_size
#             Cout = self.hidden_size
#             h0_new_shape = [self.num_layers, D, N, Hout]
#             c0_new_shape = [self.num_layers, D, N, Cout]
#             h0 = torch.zeros(h0_new_shape)
#             h0 = self.builder.make_inputconst(h0)
#             c0 = torch.zeros(c0_new_shape)
#             c0 = self.builder.make_inputconst(c0)
#
#         h0 = self.builder.make_transpose(h0, (0, 2, 1, 3))
#         c0 = self.builder.make_transpose(c0, (0, 2, 1, 3))
#         if self.bidirectional:
#             h0, h0_r = self.builder.make_split(h0, 1, 2)
#             c0, c0_r = self.builder.make_split(c0, 1, 2)
#         if len(x.get_act_src_shape()) == 3:
#             new_shape = x.get_act_src_shape()
#             new_shape = (1,) + new_shape
#             x = self.builder.make_reshape(x, tuple(new_shape))
#         direction = "forward" if self.bidirectional == False else "bidirectional"
#         for i in range(self.num_layers):
#             w_name = f"weight_ih_l{i}"
#             r_name = f"weight_hh_l{i}"
#             bw_name = f"bias_ih_l{i}"
#             br_name = f"bias_hh_l{i}"
#
#             w = [getattr(self._reference_model, w_name).clone().detach()]
#             r = [getattr(self._reference_model, r_name).clone().detach()]
#             bw = getattr(self._reference_model, bw_name).clone().detach()
#             br = getattr(self._reference_model, br_name).clone().detach()
#             b = [torch.concat((bw, br))]
#             h0_ = self.builder.make_slice(h0, (0,), (i,), (i + 1,))
#             c0_ = self.builder.make_slice(c0, (0,), (i,), (i + 1,))
#             outacts = self.builder.make_stateful_lstm_wrapper(
#                 x,
#                 init_hidden_state=h0_,
#                 init_cell_state=c0_,
#                 W=w,
#                 R=r,
#                 B=b,
#                 hidden_size=self.hidden_size,
#                 hidden_state_name=x.name + f"/hidden{i}",
#                 cell_state_name=x.name + f"/cell{i}",
#                 subgraph=x.name + f"/lstm{i}",
#                 direction="forward",
#                 batch_first=self.batch_first,
#             )
#
#             if self.bidirectional:
#                 w_r_name = w_name + "_reverse"
#                 r_r_name = r_name + "_reverse"
#                 bw_r_name = bw_name + "_reverse"
#                 br_r_name = br_name + "_reverse"
#                 w_r = [getattr(self._reference_model, w_r_name).clone().detach()]
#                 r_r = [getattr(self._reference_model, r_r_name).clone().detach()]
#                 bw_r = getattr(self._reference_model, bw_r_name).clone().detach()
#                 br_r = getattr(self._reference_model, br_r_name).clone().detach()
#                 b_r = [torch.concat((bw_r, br_r))]
#                 h0r_ = self.builder.make_slice(h0_r, (0,), (i,), (i + 1,))
#                 c0r_ = self.builder.make_slice(c0_r, (0,), (i,), (i + 1,))
#                 outacts_ = self.builder.make_stateful_lstm_wrapper(
#                     x,
#                     init_hidden_state=h0r_,
#                     init_cell_state=c0r_,
#                     W=w_r,
#                     R=r_r,
#                     B=b_r,
#                     hidden_size=self.hidden_size,
#                     hidden_state_name=x.name + f"/hidden{i}",
#                     cell_state_name=x.name + f"/cell{i}",
#                     subgraph=x.name + f"/lstm_r{i}",
#                     direction="backward",
#                     batch_first=self.batch_first,
#                 )
#             x = self.builder.make_concatenate([outacts[0], outacts_[0]], dim=-1)
#             h_o = self.builder.make_concatenate([outacts[1], outacts_[1]], dim=2)
#             c_o = self.builder.make_concatenate([outacts[2], outacts_[2]], dim=2)
#         return [x, h_o, c_o]


@torch_registry.add_to_registry(torch.nn.modules.rnn.GRU)
class GRU(ModelingTorchBase):
    __slots__ = (
        "input_size",
        "hidden_size",
        "num_layers",
        "bias",
        "batch_first",
        "dropout",
        "bidirectional",
    )

    def forward(self, x: ActivationSpec, hx=None, **kwargs):
        if self.num_layers > 1:
            raise NotImplementedError
        assert (
            x.src_dim == 3
        ), "x.shape must be (seq, batch, feature) or (batch, seq, feature)"

        if not self.batch_first:
            x = self.builder.make_transpose(x, (1, 0, 2))

        N, seq, feature = x.src_shape
        x = self.builder.make_reshape(x, (N, 1, seq, feature))

        D = 2 if self.bidirectional else 1
        if hx is not None:
            # (D * num_layers, H_out) or (D * num_layers, N, H_out) 인데 layer, direction 순서인 듯.
            h0 = hx
            h0_new_shape = (self.num_layers, D) + h0.shape[1:]
            h0 = self.builder.make_reshape(h0, tuple(h0_new_shape))
        else:
            Hout = self.hidden_size
            h0_new_shape = (self.num_layers, D, N, Hout)
            h0 = torch.zeros(h0_new_shape)
            h0 = self.builder.make_inputconst(h0)

        direction = "forward" if not self.bidirectional else "bidirectional"
        for k in range(self.num_layers):
            # fixme: self.num_layer > 1
            w_name = f"weight_ih_l{k}"
            r_name = f"weight_hh_l{k}"
            bw_name = f"bias_ih_l{k}"
            br_name = f"bias_hh_l{k}"
            # onnx
            # W[zrh]: (num_directions, 3H, input_size) (update, reset, hidden)
            # R[zrh]: (num_directions, 3H, hidden_size)
            # B: Wb[zrh] + Rb[zrh]: (num_directions, 6H)

            # torch
            # (W_ir|W_iz|W_in) (reset, update, new)
            w = getattr(self._reference_model, w_name).clone()
            w = to_onnx_weight(w, self.hidden_size).unsqueeze(0).detach().cpu()
            r = getattr(self._reference_model, r_name)
            r = to_onnx_weight(r, self.hidden_size).clone().unsqueeze(0).detach().cpu()
            bw = getattr(self._reference_model, bw_name).clone().detach().cpu()
            bw = to_onnx_weight(bw, self.hidden_size)
            br = getattr(self._reference_model, br_name).clone().detach().cpu()
            br = to_onnx_weight(br, self.hidden_size)
            b = [torch.concat((bw, br))]
            # 여기 slice axis 맞나?
            h0_ = self.builder.make_slice(h0, (0,), (k,), (k + 1,))

            outacts = self.builder.make_stateful_gru_wrapper(
                x,
                init_hidden_state=h0_,
                W=w,
                R=r,
                B=b,
                hidden_size=self.hidden_size,
                hidden_state_name=x.name + f"/hidden{k}",
                subgraph=x.name + f"/gru{k}",
                direction="forward",
                batch_first=True,
            )  # (output_o, output_h)

            if self.bidirectional:
                raise NotImplementedError
                x = self.builder.make_concatenate([outacts[0], outacts_[0]], dim=-1)
                h_o = self.builder.make_concatenate([outacts[1], outacts_[1]], dim=2)
                c_o = self.builder.make_concatenate([outacts[2], outacts_[2]], dim=2)
            else:
                x, h_o = outacts
        n, h, w, c = x.src_shape
        assert h == 1
        x = self.builder.make_reshape(x, (n, w, c))
        if not self.batch_first:
            x = self.builder.make_transpose(x, (1, 0, 2))
        n, h, w, c = h_o.src_shape
        assert h == 1
        h_o = self.builder.make_reshape(h_o, (n, w, c))
        return (x, h_o)
