import torch

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.modeling_torch.torch_modules import (
    torch_registry,
    ModelingTorchBase,
    to_channel_last,
)
from .util import conv_out_size, tighten_end_padding


@torch_registry.add_to_registry(torch.nn.modules.pooling.MaxPool2d)
class MaxPool2d(ModelingTorchBase):
    __slots__ = (
        "kernel_size",
        "kernel_size",
        "stride",
        "dilation",
        "padding",
        "ceil_mode",
    )

    @to_channel_last(4)
    def forward(self, x: ActivationSpec):
        # todo: experiment with different padding sizes
        if isinstance(self.kernel_size, int):
            h_kernel = w_kernel = self.kernel_size
        else:
            h_kernel, w_kernel = self.kernel_size
        if isinstance(self.stride, int):
            h_stride = w_stride = self.stride
        else:
            h_stride, w_stride = self.stride
        if isinstance(self.dilation, int):
            h_dilation = w_dilation = self.dilation
        else:
            h_dilation, w_dilation = self.dilation

        _, in_h, in_w, c = x.get_act_src_shape()
        if isinstance(self.padding, int):
            p_w = p_e = p_n = p_s = self.padding
            padding_list = [self.padding, self.padding]
        else:
            p_n = p_s = self.padding[0]
            p_e = p_w = self.padding[1]
            padding_list = list(self.padding)

        if in_h.dynamic or in_w.dynamic:
            raise NotImplementedError
        output_height = conv_out_size(
            in_h, p_n, p_s, h_kernel, h_dilation, h_stride, ceil_mode=self.ceil_mode
        )
        output_width = conv_out_size(
            in_w, p_e, p_w, w_kernel, w_dilation, w_stride, ceil_mode=self.ceil_mode
        )
        p_s = tighten_end_padding(
            in_h, output_height, h_kernel, h_stride, p_n, h_dilation
        )
        p_e = tighten_end_padding(
            in_w, output_width, w_kernel, w_stride, p_w, w_dilation
        )

        return self.builder.make_maxpool(
            x,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            h_stride=h_stride,
            w_stride=w_stride,
            west_padding=p_w,
            east_padding=p_e,
            north_padding=p_s,  # NPU's padding north/south is inverted.
            south_padding=p_n,
            pad_mode="-inf",
            h_dilation=h_dilation,
            w_dilation=w_dilation,
            padding_list=padding_list,
            is_ceil_mode=self.ceil_mode,
            is_include_pad=False,
            opname=self.module_name,
        )


@torch_registry.add_to_registry(torch.nn.modules.pooling.AdaptiveAvgPool2d)
class AdaptiveAvgPool2d(ModelingTorchBase):
    __slots__ = ("output_size",)

    @to_channel_last(4)
    def forward(self, x: ActivationSpec):
        if self.output_size is None:
            out_h, out_w = x.get_act_src_shape()[1:2]
        elif isinstance(self.output_size, int):
            out_h = out_w = self.output_size
        elif isinstance(self.output_size, tuple) and len(self.output_size) == 2:
            out_h, out_w = self.output_size
        else:
            raise NotImplementedError

        in_h, in_w = x.get_act_src_shape()[1:3]
        in_h = int(in_h)
        in_w = int(in_w)

        h_stride = in_h // out_h
        h_kernel = in_h - (out_h - 1) * h_stride

        w_stride = in_w // out_w
        w_kernel = in_w - (out_w - 1) * w_stride

        # padding is zero by default.
        return self.builder.make_avgpool(
            x,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            h_stride=h_stride,
            w_stride=w_stride,
            west_padding=0,
            east_padding=0,
            north_padding=0,
            south_padding=0,
            pad_mode="constant",
            h_dilation=1,
            w_dilation=1,
            opname=self.module_name,
        )


@torch_registry.add_to_registry(torch.nn.modules.pooling.AvgPool2d)
class AvgPool2d(ModelingTorchBase):
    __slots__ = ("kernel_size", "stride", "padding", "ceil_mode", "count_include_pad")

    @to_channel_last(4)
    def forward(self, x: ActivationSpec):
        if isinstance(self.kernel_size, int):
            h_kernel = w_kernel = self.kernel_size
        else:
            h_kernel, w_kernel = self.kernel_size
        if isinstance(self.stride, int):
            h_stride = w_stride = self.stride
        else:
            h_stride, w_stride = self.stride

        if isinstance(self.padding, int):
            p_w = p_e = p_n = p_s = self.padding
            padding_list = [self.padding, self.padding]
        else:
            p_n = p_s = self.padding[0]
            p_e = p_w = self.padding[1]
            padding_list = list(self.padding)
        h_dilation, w_dilation = (1, 1)

        _, in_h, in_w, c = x.get_act_src_shape()
        output_height = conv_out_size(
            in_h, p_n, p_s, h_kernel, h_dilation, h_stride, ceil_mode=self.ceil_mode
        )
        output_width = conv_out_size(
            in_w, p_e, p_w, w_kernel, w_dilation, w_stride, ceil_mode=self.ceil_mode
        )
        p_s = tighten_end_padding(
            in_h, output_height, h_kernel, h_stride, p_n, h_dilation
        )
        p_e = tighten_end_padding(
            in_w, output_width, w_kernel, w_stride, p_w, w_dilation
        )

        return self.builder.make_avgpool(
            x,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            h_stride=h_stride,
            w_stride=w_stride,
            west_padding=p_w,
            east_padding=p_e,
            north_padding=p_s,  # NPU's padding north/south is inverted.
            south_padding=p_n,
            pad_mode="constant",
            h_dilation=1,
            w_dilation=1,
            padding_list=None,
            is_ceil_mode=self.ceil_mode,
            is_include_pad=self.count_include_pad,
            opname=self.module_name,
        )
