import torch

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.modeling_torch.torch_modules import (
    torch_registry,
    ModelingTorchBase,
)


@torch_registry.add_to_registry(torch.nn.modules.loss.CrossEntropyLoss)
class CrossEntropyLoss(ModelingTorchBase):
    __slots__ = (
        "weight",
        "ignore_index",
        "reduction",
        "label_smoothing",
    )

    def forward(self, x: ActivationSpec) -> ActivationSpec:
        raise NotImplementedError("CrossEntropyLoss is not implemented")

        # return F.cross_entropy(input, target, weight=self.weight,
        #                        ignore_index=self.ignore_index, reduction=self.reduction,
        #                        label_smoothing=self.label_smoothing)


@torch_registry.add_to_registry(torch.nn.modules.loss.CTCLoss)
class CTCLoss(ModelingTorchBase):
    __slots__ = ("blank", "zero_infinity", "reduction")

    @property
    def target_module_type(self) -> ActivationSpec:
        return torch.nn.CTCLoss

    def forward(self, x: ActivationSpec) -> ActivationSpec:
        raise NotImplementedError("CTCLoss is not implemented")


@torch_registry.add_to_registry(torch.nn.modules.loss.KLDivLoss)
class KLDivLoss(ModelingTorchBase):
    __slots__ = (
        "log_target",
        "size_average",
        "reduce",
        "reduction",
    )

    @property
    def target_module_type(self) -> ActivationSpec:
        return torch.nn.KLDivLoss

    def forward(self, x: ActivationSpec) -> ActivationSpec:
        raise NotImplementedError("KLDivLoss is not implemented")
