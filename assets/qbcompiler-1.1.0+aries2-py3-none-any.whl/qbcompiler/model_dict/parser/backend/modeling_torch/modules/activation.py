import torch

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.modeling_torch.torch_modules import (
    ModelingTorchBase,
    torch_registry,
)


@torch_registry.add_to_registry(torch.nn.modules.activation.GELU)
class GELU(ModelingTorchBase):
    __slots__ = ("approximate",)

    def forward(self, x: ActivationSpec) -> ActivationSpec:
        return self.builder.make_gelu(x, approximate=self.approximate == "tanh")


@torch_registry.add_to_registry(torch.nn.modules.activation.SiLU)
class SiLU(ModelingTorchBase):
    def forward(self, x: ActivationSpec):
        return self.builder.make_swish(x, opname=self.module_name)


@torch_registry.add_to_registry(torch.nn.modules.activation.GLU)
class GLU(ModelingTorchBase):
    @property
    def target_module_type(self) -> ActivationSpec:
        return torch.nn.GLU

    def forward(self, x: ActivationSpec, dim: int):
        num_dim = x.get_act_src_shape()[dim]
        first = self.builder.make_slice(
            x, axis=dim, start=0, end=num_dim / 2, opname=f"{x.name}/slice0"
        )
        second = self.builder.make_slice(
            x, axis=dim, start=num_dim / 2, end=num_dim, opname=f"{x.name}/slice1"
        )
        second_sig = self.builder.make_act_func(
            second, act_kind="sigmoid", opname=f"{x.name}/sigmoid"
        )
        act_out = self.builder.make_mul(first, second_sig, opname=f"{x.name}/mul")

        return act_out


@torch_registry.add_to_registry(torch.nn.modules.activation.ReLU)
class ReLU(ModelingTorchBase):
    def forward(self, x: ActivationSpec):
        return self.builder.make_relu(x, opname=self.module_name)

@torch_registry.add_to_registry(torch.nn.modules.activation.LeakyReLU)
class LeakyReLU(ModelingTorchBase):
    __slots__ = ("negative_slope",)
    def forward(self, x: ActivationSpec):
        return self.builder.make_leaky_relu(x, leaky_alpha=self.negative_slope, opname=self.module_name)

@torch_registry.add_to_registry(torch.nn.modules.activation.ReLU6)
class ReLU6(ModelingTorchBase):
    def forward(self, x: ActivationSpec):
        return self.builder.make_relu6(x, opname=self.module_name)


@torch_registry.add_to_registry(torch.nn.modules.activation.Hardswish)
class Hardswish(ModelingTorchBase):
    def forward(self, x: ActivationSpec):
        return self.builder.make_hardswish(x, opname=self.module_name)


@torch_registry.add_to_registry(torch.nn.modules.activation.Sigmoid)
class Sigmoid(ModelingTorchBase):
    def forward(self, x: ActivationSpec):
        return self.builder.make_sigmoid(x)


@torch_registry.add_to_registry(torch.nn.modules.activation.Hardsigmoid)
class Hardsigmoid(ModelingTorchBase):
    def forward(self, x: ActivationSpec):
        alpha = 1.0 / 6
        return self.builder.make_hardsigmoid(x, alpha=alpha, opname=self.module_name)


@torch_registry.add_to_registry(torch.nn.modules.activation.Tanh)
class Tanh(ModelingTorchBase):
    def forward(self, x: ActivationSpec):
        return self.builder.make_tanh(x)


#
# @torch_registry.add_to_registry(torch.nn.modules.activation.MultiheadAttention)
# class MultiheadAttention(ModelingTorchBase):
#     def forward(
#             self,
#             query: ActivationSpec,
#             key: ActivationSpec,
#             value: ActivationSpec,
#             key_padding_mask: Optional[ActivationSpec] = None,
#             need_weights: bool = True,
#             attn_mask: Optional[ActivationSpec] = None,
#             average_attn_weights: bool = True,
#             is_causal : bool = False) -> Tuple[ActivationSpec, Optional[ActivationSpec]]:
#         raise NotImplementedError("MultiheadAttention module should be implemented")
#
#
#
