import torch

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.modeling_torch.torch_modules import (
    torch_registry,
    ModelingTorchBase,
    to_channel_last,
)


@torch_registry.add_to_registry(torch.nn.modules.normalization.GroupNorm)
class GroupNorm(ModelingTorchBase):
    __slots__ = ("num_groups", "weight", "bias", "eps")

    @to_channel_last(3, 4)
    def forward(self, x: ActivationSpec) -> ActivationSpec:
        return self.builder.make_groupnorm(
            x,
            num_groups=self.num_groups,
            scale=self.weight,
            bias=self.bias,
            epsilon=self.eps,
        )
        # return F.group_norm(
        #     input, self.num_groups, self.weight, self.bias, self.eps)


@torch_registry.add_to_registry(torch.nn.modules.normalization.LayerNorm)
class LayerNorm(ModelingTorchBase):
    __slots__ = ("bias", "eps", "weight", "normalized_shape", "elementwise_affine")

    def forward(self, x: ActivationSpec):
        if not self.elementwise_affine:
            weight = torch.ones(self.normalized_shape)
            bias = torch.zeros(self.normalized_shape)
        else:
            weight = self.weight
            bias = self.bias
        return self.builder.make_layernorm(
            x,
            normalized_shape=self.normalized_shape,
            epsilon=self.eps,
            scale=weight,
            bias=bias,
            opname=self.module_name,
        )


@torch_registry.add_to_registry(torch.nn.modules.normalization.RMSNorm)
class RMSNorm(ModelingTorchBase):
    __slots__ = ("eps", "weight", "normalized_shape", "elementwise_affine")

    def forward(self, x: ActivationSpec):
        if not self.elementwise_affine:
            weight = torch.ones(self.normalized_shape)
        else:
            weight = self.weight
        eps = torch.finfo(getattr(torch, x.dtype)).eps if self.eps is None else self.eps
        return self.builder.make_rmsnorm(
            x,
            normalized_shape=self.normalized_shape,
            epsilon=eps,
            scale=weight,
            opname=self.module_name,
        )


@torch_registry.add_to_registry(torch.nn.modules.batchnorm.BatchNorm1d)
class BatchNorm1d(ModelingTorchBase):
    __slots__ = (
        "num_features",
        "weight",
        "bias",
        "eps",
        "momentum",
        "affine",
        "running_mean",
        "running_var",
    )

    def forward(self, x: ActivationSpec) -> ActivationSpec:
        return self.builder.make_batchnorm_1d(
            x,
            num_features=self.num_features,
            scale=self.weight,  # [TODO] check we
            bias=self.bias,
            epsilon=self.eps,
            momentum=self.momentum,
            running_mean=self.running_mean,
            running_var=self.running_var,
        )
