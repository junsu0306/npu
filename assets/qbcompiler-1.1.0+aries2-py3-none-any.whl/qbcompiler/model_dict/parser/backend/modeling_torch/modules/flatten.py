import torch

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.modeling_torch.torch_modules import (
    torch_registry,
    ModelingTorchBase,
)


@torch_registry.add_to_registry(torch.nn.modules.flatten.Flatten)
class Flatten(ModelingTorchBase):
    __slots__ = (
        "start_dim",
        "end_dim",
    )

    def forward(self, input: ActivationSpec) -> torch.Tensor:
        ref_shape = input.get_act_src_shape()
        self.start_dim = self.start_dim+len(ref_shape) if self.start_dim < 0 else self.start_dim
        self.end_dim = self.end_dim+len(ref_shape) if self.end_dim < 0 else self.end_dim
        if self.end_dim == len(ref_shape) - 1:
            new_shape = (
                    ref_shape[:self.start_dim] + (-1,)
                )
        else:
            new_shape = (
                    ref_shape[:self.start_dim] + (-1,) + ref_shape[self.end_dim + 1 :]
                )
        flatten_name = self.module_name + "/flatten"            
        out_flatten = self.builder.make_flatten(input, axis=self.start_dim, opname=flatten_name)
        reshape_name = flatten_name + "/reshape"
        return self.builder.make_reshape(out_flatten, shape=new_shape, opname=reshape_name)

