import math

from qbcompiler.model_dict.common import DimValue


def conv_out_size(
    in_size: DimValue, pad_front, pad_end, kernel, dilation, stride, ceil_mode=False
) -> DimValue:
    if ceil_mode:
        v = math.ceil(
            (int(in_size) + (pad_front + pad_end) - dilation * (kernel - 1) - 1)
            / stride
            + 1
        )
    else:
        v = math.floor(
            (int(in_size) + (pad_front + pad_end) - dilation * (kernel - 1) - 1)
            / stride
            + 1
        )
    return DimValue(v, dynamic=in_size.dynamic)


def tighten_end_padding(in_size, out_size, kernel, stride, pad_front, dilation):
    "returns new pad_end"
    pad_height = max(0, (out_size - 1) * stride - in_size + dilation * (kernel - 1) + 1)
    return pad_height - pad_front
