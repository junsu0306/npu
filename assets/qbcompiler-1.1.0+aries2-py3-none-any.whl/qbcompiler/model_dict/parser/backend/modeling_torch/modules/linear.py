import torch

from qbcompiler.model_dict.common import ActivationSpec, DataFormat
from qbcompiler.model_dict.parser.backend.modeling_torch.torch_modules import (
    torch_registry,
    ModelingTorchBase,
)


@torch_registry.add_to_registry(torch.nn.modules.linear.Identity)
class Identity(ModelingTorchBase):
    def forward(self, x: ActivationSpec):
        return x


@torch_registry.add_to_registry(torch.nn.modules.linear.Linear)
class Linear(ModelingTorchBase):
    __slots__ = ("in_features", "out_features", "weight", "bias")

    def _make_as_conv2d(self, x: ActivationSpec):
        if x.get_act_src_shape()[-1] != self.in_features:
            raise ValueError(
                f"activation src_shape={x.get_act_src_shape()[-1]} does not match in_features={self.in_features}"
            )
        return self.builder.make_conv2d(
            x,
            in_channels=self.in_features,
            out_channels=self.out_features,
            weight=self.weight,
            bias=self.bias,
            opname=self.module_name,
        )

    def forward(self, x: ActivationSpec):
        # if self.weight.shape != (self.out_features, self.in_features):
        #     raise ValueError(f"weight.shape={self.weight.shape}")

        src_in_channels = x.get_act_src_shape()[-1]
        if self.in_features != src_in_channels:
            raise ValueError(
                f"in_features={self.in_features} but src_in_channels={src_in_channels}"
            )

        # if src_in_channels.dynamic:
        #     raise ValueError(f"src_in_channels has dynamic value. src_shape={x.get_act_src_shape()}")

        new_src_shape_conv_in = new_src_shape_reshape_out = None
        original_dataformat = x.dataformat
        if (
            x.dataformat in (DataFormat.NC, DataFormat.NX)
            or len(x.get_act_src_shape()) == 2
        ):
            n, in_ch = x.get_act_src_shape()
            if n == 1:
                new_src_shape_conv_in = (n, 1, 1, in_ch)
                new_src_shape_reshape_out = (n, self.out_features)
            else:
                new_src_shape_conv_in = (1, 1, n, in_ch)
                new_src_shape_reshape_out = (n, self.out_features)
        elif (
            x.dataformat in (DataFormat.NCX, DataFormat.NXC)
            or len(x.get_act_src_shape()) == 3
        ):
            n, w, in_ch = x.get_act_src_shape()
            new_src_shape_conv_in = (n, 1, w, in_ch)
            new_src_shape_reshape_out = (n, w, self.out_features)
        elif len(x.get_act_src_shape()) == 6:
            n, h0, h1, w0, w1, in_ch = x.get_act_src_shape()
            new_src_shape_conv_in = (n, h0*h1, w0*w1, in_ch)
            new_src_shape_reshape_out = (n ,h0, h1, w0, w1, self.out_features)

        if new_src_shape_conv_in:
            x = self.builder.make_reshape(
                x, new_src_shape_conv_in, new_dataformat=DataFormat.NHWC
            )

        x = self._make_as_conv2d(x)

        if new_src_shape_reshape_out:
            x = self.builder.make_reshape(
                x, new_src_shape_reshape_out, new_dataformat=original_dataformat
            )

        return x
