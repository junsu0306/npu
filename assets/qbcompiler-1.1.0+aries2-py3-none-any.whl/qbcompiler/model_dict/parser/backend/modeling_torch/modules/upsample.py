import torch

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.modeling_torch.torch_modules import (
    torch_registry,
    ModelingTorchBase,
    to_channel_last,
)


@torch_registry.add_to_registry(torch.nn.modules.upsampling.Upsample)
class Upsample(ModelingTorchBase):
    def __init__(self, model, module_name: str = "", make_module_fn=None, **kwargs):
        super().__init__(model, module_name, make_module_fn)
        self.size = model.size
        self.scale_factor = model.scale_factor
        self.mode = model.mode
        self.align_corners = model.align_corners
        self.recompute_scale_factor = model.recompute_scale_factor

    @to_channel_last(4)
    def forward(self, x: ActivationSpec):
        return self.builder.make_interpolate(
            x,
            self.size,
            scale_factor=self.scale_factor,
            mode=self.mode,
            align_corners=self.align_corners,
        )
