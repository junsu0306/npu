import torch

from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.parser.backend.modeling_torch.torch_modules import (
    torch_registry,
    ModelingTorchBase,
    to_channel_last,
)
from .util import conv_out_size, tighten_end_padding


@torch_registry.add_to_registry(torch.nn.modules.conv.Conv3d)
class Conv3d(ModelingTorchBase):
    __slots__ = (
        "in_channels",
        "out_channels",
        "kernel_size",
        "stride",
        "padding",
        "dilation",
        "groups",
        "bias",
        "padding_mode",
        "weight",
    )

    @to_channel_last(5)
    def forward(self, x: ActivationSpec):
        if isinstance(self.kernel_size, int):
            d_kernel = h_kernel = w_kernel = self.kernel_size
        else:
            d_kernel, h_kernel, w_kernel = self.kernel_size
        if isinstance(self.stride, int):
            d_stride = h_stride = w_stride = self.stride
        else:
            d_stride, h_stride, w_stride = self.stride
        if isinstance(self.dilation, int):
            d_dilation = h_dilation = w_dilation = self.dilation
        else:
            d_dilation, h_dilation, w_dilation = self.dilation
        if self.padding_mode != "zeros":
            raise NotImplementedError(f"padding_mode={self.padding_mode}")
        if isinstance(self.padding, str):
            # padding='valid' is the same as no padding. padding='same' pads the input so the output has the shape as the input. However, this mode doesn’t support any stride values other than 1.
            if self.padding == "valid":
                p_f = p_b = p_w = p_e = p_n = p_s = 0
                padding_list = [0, 0, 0]
            else:
                raise NotImplementedError("padding=same is not implemented yet.")
        elif isinstance(self.padding, int):
            p_f = p_b = p_w = p_e = p_n = p_s = self.padding
            padding_list = [self.padding, self.padding, self.padding]
        else:
            p_f = p_b = self.padding[0]
            p_n = p_s = self.padding[1]
            p_e = p_w = self.padding[2]
            padding_list = list(self.padding)

        _, in_d, in_h, in_w, c = x.get_act_src_shape()
        output_depth = conv_out_size(in_d, p_f, p_b, d_kernel, d_dilation, d_stride)
        output_height = conv_out_size(in_h, p_n, p_s, h_kernel, h_dilation, h_stride)
        output_width = conv_out_size(in_w, p_e, p_w, w_kernel, w_dilation, w_stride)
        p_d = tighten_end_padding(
            in_d, output_depth, d_kernel, d_stride, p_f, d_dilation
        )
        p_s = tighten_end_padding(
            in_h, output_height, h_kernel, h_stride, p_n, h_dilation
        )
        p_e = tighten_end_padding(
            in_w, output_width, w_kernel, w_stride, p_w, w_dilation
        )

        return self.builder.make_conv3d(
            x,
            in_channels=self.in_channels,
            out_channels=self.out_channels,
            d_kernel=d_kernel,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            d_stride=d_stride,
            h_stride=h_stride,
            w_stride=w_stride,
            d_dilation=d_dilation,
            h_dilation=h_dilation,
            w_dilation=w_dilation,
            front_padding=p_f,
            back_padding=p_b,
            west_padding=p_w,
            east_padding=p_e,
            north_padding=p_s,  # NPU's padding north/south is inverted.
            south_padding=p_n,
            group_number=self.groups,
            padding_list=padding_list,
            weight=self.weight,
            bias=self.bias,
            opname=self.module_name,
        )


@torch_registry.add_to_registry(torch.nn.modules.conv.Conv2d)
class Conv2d(ModelingTorchBase):
    __slots__ = (
        "in_channels",
        "out_channels",
        "kernel_size",
        "stride",
        "dilation",
        "padding",
        "padding_mode",
        "groups",
        "transposed",
        "weight",
        "bias",
    )

    @to_channel_last(4)
    def forward(self, x: ActivationSpec):
        if isinstance(self.kernel_size, int):
            h_kernel = w_kernel = self.kernel_size
        else:
            h_kernel, w_kernel = self.kernel_size
        if isinstance(self.stride, int):
            h_stride = w_stride = self.stride
        else:
            h_stride, w_stride = self.stride
        if isinstance(self.dilation, int):
            h_dilation = w_dilation = self.dilation
        else:
            h_dilation, w_dilation = self.dilation
        if self.padding_mode != "zeros":
            raise NotImplementedError(f"padding_mode={self.padding_mode}")
        if isinstance(self.padding, str):
            # padding='valid' is the same as no padding. padding='same' pads the input so the output has the shape as the input. However, this mode doesn’t support any stride values other than 1.
            if self.padding == "valid":
                p_w = p_e = p_n = p_s = 0
                padding_list = [0, 0]
            else:
                raise NotImplementedError("padding=same is not implemented yet.")
        elif isinstance(self.padding, int):
            p_w = p_e = p_n = p_s = self.padding
            padding_list = [self.padding, self.padding]
        else:
            p_n = p_s = self.padding[0]
            p_e = p_w = self.padding[1]
            padding_list = list(self.padding)

        _, in_h, in_w, c = x.get_act_src_shape()
        output_height = conv_out_size(in_h, p_n, p_s, h_kernel, h_dilation, h_stride)
        output_width = conv_out_size(in_w, p_e, p_w, w_kernel, w_dilation, w_stride)
        p_s = tighten_end_padding(
            in_h, output_height, h_kernel, h_stride, p_n, h_dilation
        )
        p_e = tighten_end_padding(
            in_w, output_width, w_kernel, w_stride, p_w, w_dilation
        )

        return self.builder.make_conv2d(
            x,
            in_channels=self.in_channels,
            out_channels=self.out_channels,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            h_stride=h_stride,
            w_stride=w_stride,
            h_dilation=h_dilation,
            w_dilation=w_dilation,
            west_padding=p_w,
            east_padding=p_e,
            north_padding=p_s,  # NPU's padding north/south is inverted.
            south_padding=p_n,
            group_number=self.groups,
            padding_list=padding_list,
            weight=self.weight,
            bias=self.bias,
            opname=self.module_name,
        )


@torch_registry.add_to_registry(torch.nn.modules.conv.Conv1d)
class Conv1d(ModelingTorchBase):
    def __init__(self, model, module_name: str = "", make_module_fn=None, **kwargs):
        super().__init__(model, module_name, make_module_fn)
        self.in_channels = model.in_channels
        self.out_channels = model.out_channels
        self.kernel = model.kernel_size
        self.stride = model.stride
        self.dilation = model.dilation

        if not (model.padding_mode == "zeros"):
            raise NotImplementedError(f"padding_mode={model.padding_mode}")
        if isinstance(model.padding, tuple):
            pad_w = model.padding[0]
        elif isinstance(model.padding, int):
            pad_w = model.padding
        else:
            raise NotImplementedError(f"padding={model.padding}")

        self.west_padding = self.east_padding = pad_w
        self.groups = model.groups

        if model.transposed:
            raise NotImplementedError(f"transposed={model.transposed}")
        self.weight = model.weight
        self.bias = model.bias

    @to_channel_last(3)
    def forward(self, x: ActivationSpec):
        return self.builder.make_conv1d(
            x,
            in_channels=self.in_channels,
            out_channels=self.out_channels,
            kernel=self.kernel,
            stride=self.stride,
            dilation=self.dilation,
            west_padding=self.west_padding,
            east_padding=self.east_padding,
            group_number=self.groups,
            weight=self.weight,
            bias=self.bias,
            opname=self.module_name,
        )


@torch_registry.add_to_registry(torch.nn.modules.conv.ConvTranspose1d)
class ConvTranspose1d(ModelingTorchBase):
    def __init__(self, model, module_name: str = "", make_module_fn=None, **kwargs):
        super().__init__(model, module_name, make_module_fn)
        self.in_channels = model.in_channels
        self.out_channels = model.out_channels
        self.kernel = model.kernel_size[0]
        self.stride = model.stride[0]
        self.dilation = model.dilation[0]
        if not (model.padding_mode == "zeros"):
            raise NotImplementedError(f"padding_mode={model.padding_mode}")
        if isinstance(model.padding, tuple):
            pad = model.padding[0]
        elif isinstance(model.padding, int):
            pad = model.padding
        else:
            raise NotImplementedError(f"padding={model.padding}")
        if isinstance(model.output_padding, tuple):
            output_padding = model.output_padding[0]
        elif isinstance(model.output_padding, int):
            output_padding = model.output_padding
        else:
            raise NotImplementedError(f"output_padding={model.output_padding}")

        dilated_kernel_size = (self.kernel - 1) * self.dilation + 1
        self.west_padding = dilated_kernel_size - 1 - pad
        self.east_padding = dilated_kernel_size - 1 - pad + output_padding
        self.groups = model.groups
        self.bias = model.bias
        self.weight = torch.flip(model.weight.permute(1, 0, 2), dims=[2])

    @to_channel_last(3)
    def forward(self, x: ActivationSpec):
        return self.builder.make_transposeconv1d(
            x,
            in_channels=self.in_channels,
            out_channels=self.out_channels,
            kernel=self.kernel,
            stride=self.stride,
            dilation=self.dilation,
            west_padding=self.west_padding,
            east_padding=self.east_padding,
            group_number=self.groups,
            weight=self.weight,
            bias=self.bias,
            opname=self.module_name,
        )
