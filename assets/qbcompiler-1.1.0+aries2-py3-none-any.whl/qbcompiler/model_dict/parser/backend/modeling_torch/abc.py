import abc
import collections
import itertools
from typing import Any, List, Callable

import torch

from qbcompiler.model_dict.parser.util.subgraph_builder import SubGraphBuilder


def get_torch_output(value_dict, name):
    def hook(module, input_, output_):
        # if name in value_dict:
        #     print("name is duplicated: ", name)
        #     raise ValueError
        value_dict[name] = output_

    return hook


class ModuleParserBase(abc.ABC):
    def __init__(
        self,
        model: torch.nn.Module | Any,
        module_name: str = "",
        make_module_func: Callable = None,
    ):
        self._reference_model: torch.nn.Module | Any = model
        self.module_name = module_name
        self._builders: List[SubGraphBuilder] = []
        self._check_builder = True
        self.value_dict = None
        if model is None:
            return
        if make_module_func is None:
            raise ValueError("make_module_func must be provided")

        prefix = self.module_name
        # set torch modules.
        if isinstance(model, torch.nn.Module):
            for attr, submodule in model.named_children():
                name_with_prefix = prefix + ("." if self.module_name else "") + attr
                try:
                    module_ = make_module_func(submodule, name_with_prefix)
                    setattr(self, attr, module_)
                except Exception as e:
                    print(f"make_torch_module_failed: {e}")
                    setattr(self, attr, submodule)

        for attr in self.__slots__:
            if not hasattr(self, attr):
                if hasattr(model, attr):
                    submodule = getattr(model, attr)
                    name_with_prefix = prefix + ("." if self.module_name else "") + attr
                    try:
                        setattr(
                            self, attr, make_module_func(submodule, name_with_prefix)
                        )
                    except Exception as e:
                        print(f"make_module_failed: {e}")
                        setattr(self, attr, submodule)

    def set_value_dict(self, value_dict):
        self.value_dict = value_dict
        for k, v in self.__dict__.items():
            if isinstance(v, ModuleParserBase):
                v.set_value_dict(value_dict)
            elif isinstance(v, list) and v and isinstance(v[0], ModuleParserBase):
                for vv in v:
                    vv.set_value_dict(value_dict)

    def register_forward_hook(self):
        for i, (name, layer) in enumerate(self._reference_model.named_modules()):
            oname = self.module_name + "." + name if self.module_name else name
            layer.register_forward_hook(get_torch_output(self.value_dict, oname))

    def torch_compute(self, *args, **kwargs):
        output_ = self._reference_model(*args, **kwargs)

    def no_check_builder(self):
        self._check_builder = False
        return self

    def num_builders(self):
        return len(self._builders)

    def set_builder(self, builder: SubGraphBuilder, recursive: bool = True):
        if not self.has_builder(builder.builder_name):
            self._builders.append(builder)

        if recursive:
            for attr in itertools.chain(self.__dict__, self.__slots__):
                attr = getattr(self, attr)
                if isinstance(attr, ModuleParserBase):
                    attr.set_builder(builder)
                elif isinstance(attr, list):
                    for x in attr:
                        if isinstance(x, ModuleParserBase):
                            x.set_builder(builder)
                elif isinstance(attr, (dict, collections.OrderedDict)):
                    for x in attr.values():
                        if isinstance(x, ModuleParserBase):
                            x.set_builder(builder)

        return self

    def pop_builder(self, builder_name):
        for idx, bder in enumerate(self._builders):
            if bder.builder_name == builder_name:
                return self._builders.pop(idx)
        return None

    def builder_names(self):
        return list(x.builder_name for x in self._builders)

    def has_builder(self, name: str):
        return name in self.builder_names()

    def get_builder(self, name: str):
        for bder in self._builders:
            if bder.builder_name == name:
                return bder
        raise Exception(f"builder with name={name} not found!")

    @property
    def reference_model(self):
        return self._reference_model

    @property
    def builder(self) -> SubGraphBuilder:
        if len(self._builders) > 1:
            raise Exception(
                f"multiple builder exists. use the method `get_builder` with one of the builder names: {self._builders.keys()}"
            )
        return self._builders[0]

    def forward(self, *args, **kwargs):
        raise NotImplementedError(
            f"forward not implemented. module={self.__class__.__module__}.{self.__class__.__name__}"
        )

    def __call__(self, *args, **kwargs):
        if self._check_builder and not self._builders:
            raise Exception(f"no builder set. self_type={type(self)}")
        return self.forward(*args, **kwargs)
