import abc
import functools

import torch

from qbcompiler.model_dict.common import DataFormat
from .abc import ModuleParserBase
from .module_registry import Registry

torch_registry = Registry(name="torch_registry")


def make_torch_module(module, module_name, make_module_fn=None, **kwargs):
    if is_torch_module(module):
        return torch_registry.get(module.__class__.__name__)(
            module, module_name, make_module_fn, **kwargs
        )
    elif module.__class__.__name__ == "PositionalEncoding":
        from qbcompiler.model_dict.parser.backend.misc.wenet.transformer.embedding import (
            PositionalEncoding,
        )

        return PositionalEncoding(module, module_name, make_module_fn, **kwargs)
    return module


def is_torch_module(module):
    module_ = module.__class__.__module__
    cls_name = module.__class__.__name__
    if not module_.startswith("torch."):
        return False
    if module_ == "torch.nn.parameter" and cls_name == "Parameter":
        return False
    if torch_registry.is_registered(cls_name):
        return True
    raise NotImplementedError(
        f"module {type(module)} is not registered in torch_registry"
    )


__all__ = ["make_torch_module", "is_torch_module"]


def _pre_post_transpose(self, method, ax0, ax1, dformat, args, kwargs):
    x = args[0]
    x = self.builder.make_transpose(x, transpose_axes=ax0)
    x.dataformat = dformat
    args = (x,) + args[1:]
    x = method(self, *args, **kwargs)
    x = self.builder.make_transpose(x, transpose_axes=ax1)
    return x


def to_channel_last(*valid_ranks):
    def decorator(method):
        @functools.wraps(method)
        def wrapper(self, *args, **kwargs):
            x_rank = len(args[0].get_act_src_shape())
            if x_rank not in valid_ranks:
                raise ValueError(f"rank={x_rank} not in {valid_ranks}")
            if x_rank == 3:
                ax0, ax1, dfmt = (0, 2, 1), (0, 2, 1), DataFormat.NXC
            elif x_rank == 4:
                ax0, ax1, dfmt = (0, 2, 3, 1), (0, 3, 1, 2), DataFormat.NHWC
            elif x_rank == 5:
                ax0, ax1, dfmt = (0, 2, 3, 4, 1), (0, 4, 1, 2, 3), DataFormat.UNKNOWN
            else:
                raise ValueError("code should not be reached!")

            return _pre_post_transpose(self, method, ax0, ax1, dfmt, args, kwargs)

        return wrapper

    return decorator


class ModelingTorchBase(ModuleParserBase, abc.ABC):
    __slots__ = ()

    def __init__(
        self, model: torch.nn.Module, name_with_prefix: str = "", make_module_fn=None
    ):
        base_module_type = torch_registry.get_base_module(self.__class__.__name__)
        if not isinstance(model, base_module_type) and model is not None:
            raise NotImplementedError(
                f"{type(model)} is not instance of {base_module_type}."
            )
        if make_module_fn is None:
            make_module_fn = make_torch_module

        super().__init__(model, name_with_prefix, make_module_fn)
