from __future__ import annotations

import abc
import collections
import dataclasses
import itertools
from typing import List, Union, Dict, TypeVar, Tuple, Optional, Any

import torch

import qbcompiler.model_dict.common.options as layer_options
from qbcompiler.logging import get_logger
from qbcompiler.model_dict.common import MobilintSubGraphBuilder
from qbcompiler.model_dict.common import (
    Operator,
    SubGraph,
    WeightDict,
    LayerType,
    ActivationSpec,
    TensorSpec,
    TensorIndex,
    WrappedTensor,
    DataFormat,
)
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.common.value_wrapper import ValueWrapper

logger = get_logger(__name__)


__all__ = [
    "OperatorGraphTransform",
    "Rule",
    "RuleSet",
    "OperatorTransformResult_Type",
    "OpTransformResult",
    "OpTransformResultV2",
    "OpInplaceTransformResult",
    "OpSequenceCollapseResult",
    "OpParallelCollapseResult",
    "RemoveIdentityResult",
    "ActivationTracer",
    "TransformOutputValueReference",
]


class OperatorTransformResultABC(abc.ABC):
    def accept(self, visitor):
        if isinstance(visitor, ActivationTracer):
            visitor.visit(self)
        else:
            raise NotImplementedError(f"visitor_type:{type(visitor)}")


OperatorTransformResult_Type = TypeVar(
    "OperatorTransformResult_Type", bound=OperatorTransformResultABC
)


class _ActivationTrace(abc.ABC):
    __slots__ = ("name", "src_shape")

    def __init__(self, name: str, src_shape: Tuple[int, ...]):
        self.name = name
        self.src_shape = src_shape

    def __repr__(self):
        t = "org" if self.trace_type == 0 else "gen"
        return f"[{t}]{self.name}"

    def __eq__(self, other):
        if not other:
            return False
        return self.trace_type == other.trace_type and self.name == self.name

    @property
    @abc.abstractmethod
    def trace_type(self):
        """
        0: from the model
        1: generated
        """


class ActTraceT0(_ActivationTrace):
    @property
    def trace_type(self):
        return 0


class ActTraceT1(_ActivationTrace):
    @property
    def trace_type(self):
        return 1


ActTrace_T = TypeVar("ActTrace_T", ActTraceT0, ActTraceT1)


class ActivationTracer:
    """
    tracing activations by their name.
    """

    def __init__(self, sg: SubGraph):
        # (act name, (parent act name, flag)). if act_name == parent_act_name then this activation is original one from the loaded model.
        self.act_trace: Dict[str, ActTrace_T] = {
            act.name: ActTraceT0(act.name, act.get_act_src_shape())
            for act in sg.activations
        }

    def get(self, name, default: ActTrace_T | None = None):
        return self.act_trace.get(name, default)

    def _visit_op_transform_result(self, node: OpTransformResult):
        _PROPAGATE_TYPES = (LayerType.Transpose, LayerType.Reshape)
        processed_names = set()  # processed in current session
        for item in itertools.chain(node.input_map, node.output_map):
            if item.external_act.name in self.act_trace:
                self.act_trace[item.internal_act.name] = self.act_trace[
                    item.external_act.name
                ]
            else:
                self.act_trace[item.internal_act.name] = ActTraceT1(
                    item.external_act.name, item.external_act.get_act_src_shape()
                )
            processed_names.add(item.internal_act.name)

        def propagate_fwd(cop, trace, op_names):
            q = collections.deque()
            q.append(cop)
            while q:
                cop = q.popleft()
                outact = node.activations[
                    node.act_idx_map_ext_int[cop.options.outputs[0]]
                ]
                if outact.name in processed_names:
                    continue
                self.act_trace[outact.name] = trace
                for c in outact.consumer_ops:
                    if c.layertype in _PROPAGATE_TYPES and c.name in op_names:
                        q.append(c)

        def propagate_bwd(pop, trace, op_names):
            q = collections.deque()
            q.append(pop)
            while q:
                pop = q.popleft()
                inact = node.activations[
                    node.act_idx_map_ext_int[pop.options.inputs[0]]
                ]
                if inact.name in processed_names:
                    continue
                self.act_trace[inact.name] = trace
                if (
                    inact.producer_op.layertype in _PROPAGATE_TYPES
                    and inact.producer_op.name in op_names
                ):
                    q.append(inact.producer_op)

        # propagate references.
        op_names = set(op.name for op in node.ops)
        for item in node.input_map:
            for cop in item.internal_act.consumer_ops:
                if cop.layertype in _PROPAGATE_TYPES:
                    propagate_fwd(cop, self.act_trace[item.internal_act.name], op_names)
        for item in node.output_map:
            if (pop := item.internal_act.producer_op).layertype in _PROPAGATE_TYPES:
                propagate_bwd(pop, self.act_trace[item.internal_act.name], op_names)

    def visit(self, node: OperatorTransformResult_Type):
        if isinstance(node, OpTransformResult):
            self._visit_op_transform_result(node)


class TransformOutputValueReference:
    def __init__(self, ref_name: str, trasnsform=None):
        self.ref_name = ref_name
        self.transform = trasnsform

    def get(self, vd: ValueDict):
        value = vd.get_value(self.ref_name)
        if isinstance(value, ValueWrapper):
            value = value.value

        if all(
            len(value.shape) == len(inact.dataformat.name)
            for inact in self.transform.inputs
        ):
            dformat = self.transform.inputs[0].dataformat
        else:
            dformat = DataFormat.UNKNOWN

        wrapped_tensor = WrappedTensor(
            value,
            dtype=str(value.dtype),
            shape=value.shape,
            dataformat=dformat,
        )
        res = self.transform(wrapped_tensor)
        if res._t.dtype == torch.bfloat16:
            res._t = res._t.to(torch.float32)
        return res._t.detach().cpu().numpy(), res.dataformat


class OpInplaceTransformResult(OperatorTransformResultABC):
    """when we want to simply replace some attributes without changing the graph topology."""

    class Builder:
        def __init__(self):
            self._op = None
            self._opts = {}

        def add_op(self, op: Operator):
            self._op = op

        def add_options_field(self, field_name, value):
            self._opts[field_name] = value

        def build(self):
            return OpInplaceTransformResult(self._op, self._opts)

    def __init__(self, op, opts):
        self._op = op
        self._opts = opts

    def apply_to_subgraph(self, sg: SubGraph, wd: WeightDict):
        self._op.options = dataclasses.replace(self._op.options, **self._opts)


class TransformActvationMapping:
    def __init__(self, internal_act: ActivationSpec, external_act: ActivationSpec):
        self.internal_act = internal_act
        self.external_act = external_act


class OpTransformResult(OperatorTransformResultABC):
    class Builder:
        __slots__ = (
            "_invalidate_ops",
            "_ops",
            "_activations",
            "_input_map",
            "_output_map",
            "_tensors",
            "_act_names",
            "_make_node_group",
        )

        def __init__(self):
            self._invalidate_ops = []
            self._ops = []
            self._activations = []
            self._input_map = []
            self._output_map = []
            self._tensors = []
            self._make_node_group = False

        def set_make_node_group(self, v):
            self._make_node_group = v

        def build(self):
            self._update_internal_connectivity()
            return OpTransformResult(
                self._invalidate_ops,
                self._ops,
                self._input_map,
                self._output_map,
                self._activations,
                self._tensors,
                self._make_node_group,
            )

        def add_invalidate_ops(self, *ops):
            self._invalidate_ops.extend(ops)

        def add_ops(self, *ops):
            self._ops.extend(ops)

        def add_input_map(
            self,
            internal_act: ActivationSpec,
            external_act: ActivationSpec,
        ):
            self._input_map.append(
                TransformActvationMapping(internal_act, external_act)
            )

        def add_output_map(
            self,
            internal_act: ActivationSpec,
            external_act: ActivationSpec,
        ):
            self._output_map.append(
                TransformActvationMapping(internal_act, external_act)
            )

        def _get_valid_act_name(self, name):
            existing_names = set(x.name for x in self._activations)
            i = 0
            while True:
                nm = name + "_" + str(i)
                if nm not in existing_names:
                    return nm
                i += 1

        def is_act_name_exists(self, name):
            return any(name == x.name for x in self._activations)

        def add_activation(self, act: ActivationSpec, fix_name=True):
            if any(act.name == x.name for x in self._activations):
                if fix_name:
                    act.name = self._get_valid_act_name(act.name)
                else:
                    raise ValueError(f"activation name already exists. {act.name}")
            self._activations.append(act)
            return len(self._activations) - 1

        def get_activaion_idx(self, act: ActivationSpec):
            for idx, a in enumerate(self._activations):
                if act.name == a.name:
                    return idx
            raise ValueError(f"activation name does not exist. {act.name}")

        def add_activations(self, acts: List[ActivationSpec]):
            return [self.add_activation(a) for a in acts]

        def add_tensor(self, ts: TensorSpec):
            self._tensors.append(ts)
            return len(self._tensors) - 1

        def _update_internal_connectivity(self):
            for act in self._activations:
                act.consumer_ops.clear()
            for op in self._ops:
                for oidx in op.options.outputs:
                    self._activations[oidx].producer_op = op
                if op.layertype == LayerType.Input:
                    continue
                for iidx in op.options.inputs:
                    self._activations[iidx].consumer_ops.append(op)

        def add_all_tensors(self, op, sg):
            """returns tensor_map"""
            dct = {}
            for k, v in op.options.iter_tensorindex():
                dct[k] = self.add_tensor(sg.tensors[v].copy()) if v != -1 else -1
            return dct

    def __init__(
        self,
        invalidate_ops,
        ops,
        input_map,
        output_map,
        activations,
        tensors,
        make_node_group,
    ):
        self.invalidate_ops = invalidate_ops
        self.ops = ops
        self.input_map: List[TransformActvationMapping] = input_map
        self.output_map: List[TransformActvationMapping] = output_map
        # all activations should be new.
        self.activations: List[ActivationSpec] = activations
        # remind that tensor is uniquely identified with its name in weight_dict.
        self.tensors: List[TensorSpec] = tensors
        self.make_node_group = make_node_group
        self.act_idx_map_ext_int = {}

    def _add_activations_to_subgraph(self, sg: SubGraph):
        act_idx_map = {}
        for idx, act in enumerate(self.activations):
            if sg.is_duplicate_act_name(act.name):
                act.name = sg.get_valid_act_name(act.name)
                if act.producer_op is not None:
                    # becuase of multiple output op
                    if act.producer_op.options.outputs[0] == idx:
                        act.producer_op.name = act.name
            act_idx_map[idx] = sg.add_activation(act)
            logger.debug(f"new activation: {sg.activations[act_idx_map[idx]]}")
        return act_idx_map

    def _add_tensors_to_subgraph(self, sg: SubGraph):
        ts_idx_map = {}
        for idx, ts in enumerate(self.tensors):
            sg_ts_idx = sg.get_idx_exists(ts.name)
            if sg_ts_idx == -1:
                sg_ts_idx = sg.add_tensor(ts)
            ts_idx_map[idx] = TensorIndex(sg_ts_idx)
        return ts_idx_map

    def _update_idx(self, act_idx_map, ts_idx_map):
        for op in self.ops:
            op.options.inputs = tuple(act_idx_map[x] for x in op.options.inputs)
            op.options.outputs = tuple(act_idx_map[x] for x in op.options.outputs)
        if ts_idx_map:
            for op in self.ops:
                for k, v in op.options.iter_tensorindex():
                    if v == -1:
                        continue
                    setattr(op.options, k, ts_idx_map[v])

    def _add_operators_to_subgraph(self, sg: SubGraph, wd: WeightDict):
        sg.operators.extend(
            itertools.chain(
                self._update_input_connectivity(sg, wd),
                self.ops,
                self._update_output_connectivity(sg),
            )
        )

    def apply_to_subgraph(self, sg: SubGraph, wd: WeightDict):
        for op in self.invalidate_ops:
            op.valid = False
        # duplicate activation name is fixed in self._add_activations_to_subgraph(sg)
        act_idx_map = self._add_activations_to_subgraph(sg)
        ts_idx_map = self._add_tensors_to_subgraph(sg)
        for k, v in act_idx_map.items():
            self.act_idx_map_ext_int[v] = k
        self._update_idx(act_idx_map, ts_idx_map)
        self._add_operators_to_subgraph(sg, wd)

    def update_output_value_reference(self, sg: SubGraph, vd: ValueDict):
        for op in self.ops:
            if isinstance(op.output_value_reference, TransformOutputValueReference):
                try:
                    new_ref_value, new_ref_dformat = op.output_value_reference.get(vd)
                    if len(op.options.outputs) != 1:
                        raise NotImplementedError()
                    new_ref_name = sg.activations[op.options.outputs[0]].name
                    vd.add(new_ref_name, new_ref_value, new_ref_dformat)
                    op.output_value_reference = new_ref_name
                except:
                    pass

    def _get_connection_op(self, reshape_inact_idx, reshape_outact_idx, sg: SubGraph):
        reshape_inact = sg.activations[reshape_inact_idx]
        reshape_outact = sg.activations[reshape_outact_idx]
        if (
            any(x.dynamic for x in reshape_inact.src_shape)
            and all(not x.dynamic for x in reshape_outact.src_shape)
            and reshape_inact.src_shape == reshape_outact.src_shape
        ):
            for idx, x in enumerate(reshape_inact.src_shape):
                reshape_outact.src_shape[idx].set_dynamic(x.dynamic)

        # todo: remove `op_transform_generated_reshape` flag
        if reshape_inact.get_act_src_shape() == reshape_outact.get_act_src_shape():
            return Operator(
                name=reshape_outact.name,
                options=layer_options.IdentityOptions(
                    inputs=(reshape_inact_idx,), outputs=(reshape_outact_idx,)
                ),
                op_transform_generated_reshape=True,
            )
        else:
            return Operator(
                name=reshape_outact.name,
                options=layer_options.ReshapeOptions(
                    inputs=(reshape_inact_idx,),
                    outputs=(reshape_outact_idx,),
                    allowzero=0,
                ),
                op_transform_generated_reshape=True,
            )

    def _update_input_connectivity(self, sg: SubGraph, wd: WeightDict):
        processed = set()
        for x in self.input_map:
            reshape_in = x.external_act
            reshape_out = x.internal_act  # new act
            if reshape_in.name == reshape_out.name:
                raise ValueError(
                    f"reshape_in.name == reshape_out.name, value={reshape_in.name}"
                )
            # special case of const input to promote const folding.
            if wd.isin(reshape_in.name):
                wd.add_weight(
                    reshape_out.name, wd.get_weight_by_name(reshape_in.name).copy()
                )
                continue

            reshape_iact_idx = sg.get_act_idx(reshape_in.name)
            reshape_oact_idx = sg.get_act_idx(reshape_out.name)
            # to avoid repeated reshape generation in one-to-many case
            if (reshape_iact_idx, reshape_oact_idx) not in processed:
                connection_op = self._get_connection_op(
                    reshape_iact_idx, reshape_oact_idx, sg
                )
                connection_op.op_transform_generated_reshape = True
                processed.add((reshape_iact_idx, reshape_oact_idx))
                reshape_in.consumer_ops = [
                    io for io in reshape_in.consumer_ops if io.valid
                ]
                reshape_in.consumer_ops.append(connection_op)
                reshape_out.producer_op = connection_op
                yield connection_op

    def _update_output_connectivity(self, sg: SubGraph):
        for x in self.output_map:
            reshape_in = x.internal_act
            reshape_out = x.external_act
            reshape_iact_idx = sg.get_act_idx(reshape_in.name)  # new act
            reshape_oact_idx = sg.get_act_idx(reshape_out.name)
            if reshape_iact_idx == reshape_oact_idx:
                raise ValueError("reshape_iact_idx == reshape_oact_idx")
            connection_op = self._get_connection_op(
                reshape_iact_idx, reshape_oact_idx, sg
            )
            reshape_in.consumer_ops.append(connection_op)
            reshape_out.producer_op = connection_op
            yield connection_op


class OpTransformResultV2(OpTransformResult):
    __slots__ = (
        "_invalidate_ops",
        "_operators",
        "_input_map",
        "_output_map",
        "_activations",
        "_tensors",
    )

    class Builder(MobilintSubGraphBuilder):
        __slots__ = (
            "_invalidate_ops",
            "_operators",
            "_activations",
            "_tensors",
            "_weights",
            "_input_map",
            "_output_map",
        )

        def __init__(self, wd: WeightDict, builder_name=""):
            self._input_map = []
            self._output_map = []
            self._invalidate_ops = []
            super().__init__(global_weight_dict=wd, builder_name=builder_name)

        def copy_activationspec(
            self,
            x: ActivationSpec,
            name: str = None,
            dtype: str = None,
            shape=None,
            src_shape=None,
            dataformat=None,
            add_input_map=False,
            **kwargs,
        ):
            copied = super().copy_activationspec(
                x, name, dtype, shape, src_shape, dataformat, **kwargs
            )
            if add_input_map:
                self.add_input_map(copied, x)
            return copied

        def build(self) -> OpTransformResultV2:
            self._update_internal_connectivity()
            return OpTransformResultV2(
                self._invalidate_ops,
                self._operators,
                self._input_map,
                self._output_map,
                self._activations,
                self._tensors,
            )

        def add_invalidate_ops(self, *ops):
            unique = tuple(
                o for o in ops if o is not None and o not in self._invalidate_ops
            )
            self._invalidate_ops.extend((o for o in unique))

        def add_input_map(
            self,
            internal_act: ActivationSpec,
            external_act: ActivationSpec,
        ):
            self._input_map.append(
                TransformActvationMapping(internal_act, external_act)
            )

        def add_output_map(
            self,
            internal_act: ActivationSpec,
            external_act: ActivationSpec,
        ):
            self._output_map.append(
                TransformActvationMapping(internal_act, external_act)
            )

        def _update_internal_connectivity(self):
            for act in self._activations:
                act.consumer_ops.clear()
            for op in self._operators:
                for oidx in op.options.outputs:
                    self._activations[oidx].producer_op = op
                if op.layertype == LayerType.Input:
                    continue
                for iidx in op.options.inputs:
                    self._activations[iidx].consumer_ops.append(op)

        def remove_connectivity_and_invalidate(self, sg: SubGraph, *ops: Operator):
            # only works for a sequence of operators
            if not isinstance(sg, SubGraph):
                raise Exception(f"sg is not SubGraph: got = {type(sg)}")
            self.add_invalidate_ops(ops[-1])
            if len(ops) == 1:
                last_op = ops[-1]
                for iidx in last_op.options.inputs:
                    inact = sg.activations[iidx]
                    inact.consumer_ops = [
                        cop for cop in inact.consumer_ops if cop is not last_op
                    ]
                return
            assert len(ops) > 1, f"len(ops) > 1 but got len(ops)={len(ops)}"
            for i in range(len(ops) - 1, 0, -1):
                next_op = ops[i]
                op = ops[i - 1]
                outact = sg.activations[op.options.outputs[0]]
                outact.consumer_ops = [
                    cop for cop in outact.consumer_ops if cop is not next_op
                ]
                if not outact.consumer_ops:
                    self.add_invalidate_ops(op)
                else:
                    break

        def with_new_input(self, sg, old_op: Operator, new_inact, **kwargs):
            kw = dataclasses.asdict(old_op.options)
            kw.pop("inputs", None)
            kw.pop("outputs", None)
            kw.pop("channel_last", None)
            for k, v in kw.items():
                if isinstance(v, TensorIndex):
                    if v != -1:
                        kw[k] = self._weights.get_weight_by_name(sg.tensors[v].name)
                    else:
                        kw[k] = None
            kw.update(kwargs)

            act_fn_type = (
                LayerType.Relu,
                LayerType.Erf,
                LayerType.LeakyRelu,
                LayerType.PRelu,
                LayerType.Clip,
                LayerType.Exp,
                LayerType.Softplus,
                LayerType.Sigmoid,
                LayerType.QuickGelu,
                LayerType.Pow,
                LayerType.Gelu,
                LayerType.Swish,
                LayerType.HardSwish,
                LayerType.HardSigmoid,
                LayerType.Tanh,
                LayerType.Elu,
            )

            if old_op.layertype in act_fn_type:
                return self.make_act_func(
                    new_inact, old_op.layertype.name.lower(), **kw
                )
            if old_op.layertype == LayerType.Logit:
                return self.make_logit(new_inact, **kw)
            if old_op.layertype == LayerType.Cos:
                return self.make_cos(new_inact, **kw)
            if old_op.layertype == LayerType.Sin:
                return self.make_sin(new_inact, **kw)
            if old_op.layertype in (LayerType.Convolution, LayerType.GroupConvolution):
                return self.make_conv2d(new_inact, **kw)
            if old_op.layertype == LayerType.MinMaxNormalization:
                return self.make_minmaxnorm(new_inact, **kw)
            if old_op.layertype == LayerType.LayerNormalization:
                return self.make_layernorm(new_inact, **kw)
            if old_op.layertype == LayerType.RmsNormalization:
                return self.make_rmsnorm(new_inact, **kw)
            if old_op.layertype == LayerType.Resize:
                return self.make_resize(new_inact, **kw)
            if old_op.layertype == LayerType.Slice:
                return self.make_slice(new_inact, **kw)
            if old_op.layertype == LayerType.Tile:
                kw.pop("real_repeats")
                return self.make_tile(new_inact, **kw)
            if old_op.layertype == LayerType.InstanceNormalization:
                return self.make_instancenorm(new_inact, **kw)
            if old_op.layertype == LayerType.ReduceMean:
                if "reduce_axes" in kw:
                    kw["dim"] = kw.pop("reduce_axes")
                return self.make_reduce_mean(new_inact, **kw)
            if old_op.layertype == LayerType.ReduceMax:
                return self.make_reduce_max(new_inact, **kw)
            if old_op.layertype == LayerType.ReduceMin:
                return self.make_reduce_min(new_inact, **kw)
            if old_op.layertype == LayerType.ReduceSum:
                return self.make_reduce_sum(new_inact, **kw)
            if old_op.layertype == LayerType.ReduceProd:
                return self.make_reduce_prod(new_inact, **kw)
            if old_op.layertype == LayerType.ReduceL2:
                return self.make_reduce_l2(new_inact, **kw)
            if old_op.layertype == LayerType.Pooling:
                return self._make_pooling(new_inact, **kw)
            if old_op.layertype == LayerType.Batchnorm:
                return self.make_batchnorm(new_inact, **kw)
            if old_op.layertype == LayerType.Softmax:
                return self.make_softmax(new_inact, **kw)
            if old_op.layertype in (
                LayerType.MultiplyConstant,
                LayerType.AddingConstant,
                LayerType.DivConstant,
                LayerType.SubConstant,
            ):
                left = new_inact
                right = kw.pop("const_val")
                assert right is not None
                if old_op.options.is_const_first:
                    left, right = right, left
                return self._make_biop(
                    left, right, opkind=old_op.layertype.name[:3].lower()
                )
            if old_op.layertype == LayerType.HeaderView:
                kw.pop("view_shape")
                return self.make_headerview(new_inact, **kw)
            if old_op.layertype == LayerType.Sqrt:
                return self.make_sqrt(new_inact)

            raise NotImplementedError(f"with_new_input: {old_op.layertype}")

        # fixme: Manage the global namespace to prevent naming conflicts with the existing add in the original model. currently, we set default opname to `_add`.
        def make_add(
            self, left: ActivationSpec | Any, right: ActivationSpec | Any, opname="_add"
        ):
            return self._make_biop(left, right, opkind="add", opname=opname)

    def __init__(
        self, invalidate_ops, operators, input_map, output_map, activations, tensors
    ):
        super().__init__(
            invalidate_ops=invalidate_ops,
            ops=operators,
            input_map=input_map,
            output_map=output_map,
            activations=activations,
            tensors=tensors,
            make_node_group=False,
        )


class RemoveIdentityResult(OperatorTransformResultABC):
    def __init__(self, original_op):
        self.original_op: Operator = original_op

    def apply_to_subgraph(self, sg: SubGraph, wd: WeightDict):
        self.original_op.valid = False
        inact_idx = self.original_op.inputs[0]
        inact = sg.activations[inact_idx]
        outact_idx = self.original_op.outputs[0]
        inact.consumer_ops = [x for x in inact.consumer_ops if x.valid]
        for x in sg.activations[self.original_op.outputs[0]].consumer_ops:
            new_inputs = tuple(
                inact_idx if iidx == outact_idx else iidx for iidx in x.options.inputs
            )
            x.options = dataclasses.replace(x.options, inputs=new_inputs)
            inact.consumer_ops.append(x)


class OpSequenceCollapseResult(OperatorTransformResultABC):
    def __init__(
        self,
        remove_sequence: List[Operator],
        replace_sequence: List[Operator] | Operator,
    ):
        self.remove_sequence = remove_sequence
        if isinstance(replace_sequence, Operator):
            self.replace_sequence = [replace_sequence]
        else:
            self.replace_sequence = replace_sequence

    def apply_to_subgraph(self, sg: SubGraph, wd: WeightDict):
        # self.replace_ops = [identity] or [reshape]
        for op in self.remove_sequence:
            op.valid = False

        begin_op = self.replace_sequence[0]
        in_act = sg.activations[begin_op.options.inputs[0]]
        in_act.consumer_ops = [x for x in in_act.consumer_ops if x.valid]
        in_act.consumer_ops.append(begin_op)

        last_op = self.remove_sequence[-1]
        out_act = sg.activations[last_op.options.outputs[0]]
        out_act.producer_op = last_op

        if in_act.src_shape == out_act.src_shape:
            if 1 == sum(x.dynamic for x in in_act.src_shape) and 0 == sum(
                x.dynamic for x in out_act.src_shape
            ):
                for idx, x in enumerate(in_act.src_shape):
                    out_act.src_shape[idx].set_dynamic(x.dynamic)

        sg.operators.extend(self.replace_sequence)

    def update_output_value_reference(self, sg: SubGraph, vd: ValueDict):
        for op in self.replace_sequence:
            if isinstance(op.output_value_reference, TransformOutputValueReference):
                try:
                    new_ref_value, new_ref_dformat = op.output_value_reference.get(vd)
                    if len(op.options.outputs) != 1:
                        raise NotImplementedError()
                    new_ref_name = sg.activations[op.options.outputs[0]].name
                    vd.add(new_ref_name, new_ref_value, new_ref_dformat)
                    op.output_value_reference = new_ref_name
                except:
                    pass


class OpParallelCollapseResult(OperatorTransformResultABC):
    def __init__(self, parallel_ops):
        self.parallel_ops = parallel_ops

    def apply_to_subgraph(self, sg: SubGraph, wd: WeightDict):
        remain_op = self.parallel_ops[0]
        for pop in self.parallel_ops[1:]:
            pop.valid = False
        if len(remain_op.options.outputs) > 1:
            raise NotImplementedError

        replace_targets = []
        replace_idx = remain_op.options.outputs[0]
        remain_outact = sg.activations[replace_idx]
        cops = []
        for pop in self.parallel_ops[1:]:
            for oidx in pop.options.outputs:
                cops += sg.activations[oidx].consumer_ops
                replace_targets.append(oidx)

        remain_outact_consumer_names = [x.name for x in remain_outact.consumer_ops]
        for cop in cops:
            if cop.name not in remain_outact_consumer_names:
                remain_outact.consumer_ops.append(cop)
            cop.options.inputs = tuple(
                replace_idx if x in replace_targets else x for x in cop.options.inputs
            )


class RuleCase:
    """descriptor for defining a rule case."""

    def __init__(self, check_func):
        self.check_func = check_func
        self.transform_func = None
        self.name = check_func.__name__

    def transform(self, func):
        """
        Decorator to register the transformation logic for specific case.
        """
        self.transform_func = func
        return self

    def __get__(self, inst, owner):
        """Descriptor method to bind the check function to the instance."""
        if inst is None:
            return self
        return self.check_func.__get(inst, owner)

    def __repr__(self):
        return f"{self.name}"


def pattern(func) -> RuleCase:
    """
    Decorator to mark a method as a rule check function.

    Usage:
        @pattern
        def case0(self, ...): ...

        @case0.transform
        def transform_case0(self, ...): ...
    """
    return RuleCase(func)


class RuleNew(abc.ABC):
    """
    Base class for rule implementations using the decorator pattern.
    Allows defining multiple cases (check & transform pairs) within a single class.
    """

    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)
        self._matched_case: Optional[RuleCase] = None
        # fixme: matched_pattern을 rulecase가 가지는게 더 나을 것 같은데?
        self._matched_pattern: Any = None
        self._rules = []

        for name in dir(self.__class__):
            try:
                cls_attr = getattr(self.__class__, name)
                if isinstance(cls_attr, RuleCase):
                    self._rules.append(cls_attr)
            except AttributeError:
                pass

        self._rules.sort(key=lambda x: x.name)

    def __repr__(self):
        case = self._matched_case if self._matched_case is not None else "NA"
        return f"{self.__class__.__qualname__}, case={case}"

    def clear_result(self):
        self._matched_pattern = None
        self._matched_case = None

    @property
    def matched_case(self):
        return self._matched_case

    @property
    def matched_pattern(self):
        return self._matched_pattern

    def check(
        self, op: Operator, sg: SubGraph, wd: WeightDict = None, **kwargs
    ) -> bool:
        """Iterates and checks all registered cases.
        If a case's check function returns a truthy value (pattern), matches that case and returns True.
        """
        for rule in self._rules:
            # rule.check_func is unbounded, we pass 'self' here.
            res = rule.check_func(self, op, sg, wd, **kwargs)
            if res:
                self._matched_case = rule
                self._matched_pattern = res
                return True
        return False

    def transform(
        self, op: Operator, sg: SubGraph, wd: WeightDict = None, *args, **kwargs
    ) -> OperatorTransformResult_Type:
        """Executes the transformation logic for the currently matched case."""
        if self._matched_case is None:
            raise NotImplementedError("matched case is None.")
        return self._matched_case.transform_func(self, op, sg, wd, *args, **kwargs)


class Rule(abc.ABC):
    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)
        self._matched_case: Optional[int] = None
        self._matched_pattern: Any = None

    def __repr__(self):
        case = self._matched_case if self._matched_case is not None else "NA"
        return f"{self.__class__.__qualname__}, case={case}"

    def clear_result(self):
        self._matched_case = None
        self._matched_pattern = None

    def set_case(self, case_no: Optional[int] = None, pat: Any = None) -> bool:
        """
        always returns True
        """
        self._matched_case = case_no
        self._matched_pattern = pat
        return True

    @property
    def matched_case(self):
        return self._matched_case

    @property
    def matched_pattern(self):
        return self._matched_pattern

    @abc.abstractmethod
    def check(
        self, op: Operator, sg: SubGraph, wd: WeightDict = None, **kwargs
    ) -> bool:
        ...

    @abc.abstractmethod
    def transform(
        self, op: Operator, sg: SubGraph, wd: WeightDict = None, *args, **kwargs
    ) -> OperatorTransformResult_Type:
        ...


class RemoveIdentity(Rule):
    def check(self, op: Operator, sg: SubGraph, wd: WeightDict = None, **kwargs):
        return op.layertype == LayerType.Identity

    def transform(
        self, op: Operator, sg: SubGraph, wd: WeightDict = None, *args, **kwargs
    ) -> RemoveIdentityResult:
        return RemoveIdentityResult(original_op=op)


class ReshapeToIdentity(Rule):
    def check(self, op: Operator, sg: SubGraph, wd: WeightDict = None, **kwargs):
        if op.layertype == LayerType.Reshape:
            inact = sg.activations[op.options.inputs[0]]
            outact = sg.activations[op.options.outputs[0]]
            if inact.producer_op is not None:
                # promote reshape collapse
                if inact.producer_op == LayerType.Reshape:
                    return False
            isrc_shape = inact.get_act_src_shape()
            osrc_shape = outact.get_act_src_shape()
            return len(isrc_shape) == len(osrc_shape) and all(
                x == y and (x.dynamic == y.dynamic or (x != 1))
                for x, y in zip(isrc_shape, osrc_shape)
            )
        return False

    def transform(
        self, op: Operator, sg: SubGraph, wd: WeightDict = None, *args, **kwargs
    ):
        reshape_input_idx = op.options.inputs[0]
        reshape_output_idx = op.options.outputs[0]
        reshape_out = sg.activations[reshape_output_idx]
        identity = Operator(
            name=f"Identity;{reshape_out.name}",
            options=layer_options.IdentityOptions(
                inputs=(reshape_input_idx,), outputs=(reshape_output_idx,)
            ),
        )
        return OpSequenceCollapseResult(remove_sequence=[op], replace_sequence=identity)


class RuleSet:
    def __init__(self, name):
        self._registry = {}
        self._backend_except = {"tf": [], "onnx": [], "tflite": []}
        self._name = name

    def name(self):
        return self._name

    def register_except(self, backend):
        def decorator(rule_cls):
            self._backend_except[backend].append(rule_cls.__name__)

        return decorator

    def register(self, rule_cls):
        if rule_cls.__name__ in self._registry:
            raise KeyError(f"Duplicate rule name: {rule_cls.__name__}")
        self._registry[rule_cls.__name__] = rule_cls
        return rule_cls

    def get(self, rule_name: Union[List[str], str], backend=None, **kwargs):
        if isinstance(rule_name, str):
            return [self._registry[rule_name](**kwargs)]
        lst = []
        for name in rule_name:
            if backend and name in self._backend_except.get(backend, []):
                continue  # We don't add a rule if the rule name is registered as an exception.
            if name not in self._registry:
                raise KeyError("Unknown rule: {}".format(name))
            lst.append(self._registry[name](**kwargs))
        return lst

    def get_all_names(self):
        return list(self._registry.keys())


class OperatorGraphTransform:
    def __init__(self, rules: List[Rule]):
        self.rules: List[Rule] = rules
        self.default_rules: List[Rule] = [RemoveIdentity(), ReshapeToIdentity()]
        self.failed_rule_reasons: Dict[int, str] = {}

    def _pre_proc(self, sg: SubGraph):
        for op in sg.operators:
            op.valid = True
        sg.init_all_act_tensor_names()

    def _is_skipped_rule(self, rule: Rule) -> bool:
        return id(rule) in self.failed_rule_reasons

    def _skip_rule(self, rule: Rule, stage: str, op: Operator, exc: Exception):
        rule_key = id(rule)
        if rule_key in self.failed_rule_reasons:
            return
        reason = f"{rule.__class__.__qualname__} failed during {stage} on op `{op.name}`: {exc!r}"
        self.failed_rule_reasons[rule_key] = reason
        logger.exception("%s. This rule will be skipped from now on.", reason)

    def _match(self, op, sg, wd, skip_failed_rules=True) -> Optional[Rule]:
        for rule in self.rules:
            if skip_failed_rules and self._is_skipped_rule(rule):
                continue
            rule.clear_result()
            if not skip_failed_rules:
                if rule.check(op, sg, wd):
                    return rule
                continue
            try:
                if rule.check(op, sg, wd):
                    return rule
            except Exception as exc:
                self._skip_rule(rule, "check", op, exc)
        return None

    def _match_default(self, op, sg, wd, skip_failed_rules=True) -> Optional[Rule]:
        for rule in self.default_rules:
            if skip_failed_rules and self._is_skipped_rule(rule):
                continue
            rule.set_case()
            if not skip_failed_rules:
                if rule.check(op, sg, wd):
                    return rule
                continue
            try:
                if rule.check(op, sg, wd):
                    return rule
            except Exception as exc:
                self._skip_rule(rule, "check", op, exc)
        return None

    def process(
        self,
        sg: SubGraph,
        wd: WeightDict = None,
        vd: ValueDict = None,
        activation_tracer: ActivationTracer = None,
        debug=False,
        **kwargs,
    ) -> bool:
        """returns if graph is changed."""

        if debug:
            logger.setLevel(debug)

        self._pre_proc(sg)

        val_ret = False
        is_loop = True

        lcnt = kwargs.get("loop_cnt", "")
        skip_failed_rules = kwargs.get("skip_failed_rules", True)
        cnt = 0

        while is_loop:
            is_loop = False
            sg.update_op_act_connectivity()
            lst = sg.operators.copy()
            has_identity = any([op for op in lst if op.layertype == LayerType.Identity])
            for k, op in enumerate(lst):
                if not op.valid:
                    continue
                rule = self._match_default(
                    op, sg, wd, skip_failed_rules=skip_failed_rules
                )
                if rule is None and not has_identity:
                    rule = self._match(op, sg, wd, skip_failed_rules=skip_failed_rules)
                if rule is not None:
                    logger.debug(f"[{lcnt}:{cnt}] -> {rule}, opname={op.name}")
                    if skip_failed_rules:
                        try:
                            res = rule.transform(op, sg, wd)
                        except Exception as exc:
                            self._skip_rule(rule, "transform", op, exc)
                            continue
                    else:
                        res = rule.transform(op, sg, wd)
                    cnt += 1
                    res.apply_to_subgraph(sg, wd)
                    if isinstance(
                        res,
                        (
                            OpTransformResult,
                            OpTransformResultV2,
                            OpSequenceCollapseResult,
                        ),
                    ):
                        res.update_output_value_reference(sg, vd)
                    if activation_tracer:
                        res.accept(activation_tracer)
                    is_loop = True
                    val_ret = True
                    sg.update_op_act_connectivity()
            sg.operators = [op for op in sg.operators if op.valid]

        return val_ret
