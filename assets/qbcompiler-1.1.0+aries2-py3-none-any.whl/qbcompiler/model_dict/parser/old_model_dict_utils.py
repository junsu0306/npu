import enum
import json
import torch

from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.logging import get_logger
from pathlib import Path

logger = get_logger(__name__)


class DATA_FORMAT(enum.Enum):
    UNKNOWN = enum.auto()
    BCHW = enum.auto()
    BHWC = enum.auto()
    BC = enum.auto()
    CB = enum.auto()
    HWC = enum.auto()
    HCW = enum.auto()
    BH1W1C = enum.auto()
    BH2W2C = enum.auto()
    BHW = enum.auto()
    BCH = enum.auto()


class DIMENSION(enum.Enum):
    B = enum.auto()
    C = enum.auto()
    H = enum.auto()
    W = enum.auto()


def get_input_list(layer_info):
    if not isinstance(layer_info, dict):
        raise ValueError(
            f"Error. layer_info should be a "
            f" dictionary, but got {type(layer_info).__name__}"
        )

    if "input" in layer_info:
        input_list = layer_info["input"]
        if isinstance(input_list, tuple):
            input_list = list(input_list)
        if not isinstance(input_list, list):
            input_list = [input_list]
    elif "input0" in layer_info and "input1" in layer_info:
        input_list = [layer_info["input0"], layer_info["input1"]]
    elif "input0" in layer_info or "input1" in layer_info:
        raise ValueError(
            f"Error. layer_info should have both input0 and input1, "
            f"but got {layer_info.keys()}"
        )
    else:
        return []

    for input_name in input_list:
        if not isinstance(input_name, str):
            raise ValueError(
                f"Error. input_name should be a string, "
                f"but got {type(input_name).__name__}"
            )

    return input_list


def add_output_to_layer_dict(layer_dict: dict, const_dict: dict):
    unknown_layer_list = []
    for layer_name, layer_info in layer_dict.items():
        if "output" not in layer_info:
            layer_info["output"] = []

        """ find input_tensor names """
        input_list = get_input_list(layer_info)
        for input_name in input_list:
            if input_name in layer_dict:
                if "output" not in layer_dict[input_name]:
                    layer_dict[input_name]["output"] = []
                layer_dict[input_name]["output"].append(layer_name)
            elif input_name in const_dict:
                pass
            else:
                # print("Warnning. input_tensor name in not in both layer dict and const dict. input_name = ", input_name)
                unknown_layer_list.append(input_name)


def get_BCNdim_input_shape(input_layer_info, in_channel=None):
    try:
        input_shape = input_layer_info["output_shape"]
        input_height, input_width, input_channel = input_shape
    except:
        src_shape = input_layer_info["src_shape"]
        if len(src_shape) == 4:
            if src_shape[1] == in_channel:
                batch, input_channel, input_height, input_width = src_shape
            elif src_shape[3] == in_channel:
                batch, input_height, input_width, input_channel = src_shape
            else:
                batch, input_channel, input_height, input_width = src_shape
        elif len(src_shape) == 3:
            if in_channel is not None:
                if src_shape[1] == in_channel:
                    input_height, input_channel, input_width = src_shape
                elif src_shape[2] == in_channel:
                    input_height, input_width, input_channel = src_shape
                elif src_shape[0] == in_channel:  # is used?
                    input_channel, input_height, input_width = src_shape
                else:
                    print(f"src_shape = {src_shape} in_channel = {in_channel}")
                    raise ValueError("in_channel is not matched with any axis")
            else:
                if src_shape[0] == 1:
                    batch, input_channel, input_height = src_shape
                    input_width = 1
                else:
                    input_height, input_channel, input_width = src_shape
        elif len(src_shape) == 2:
            batch, input_channel = src_shape
            input_height = 1
            input_width = 1
        else:
            raise ValueError("src dimension is too high. input dim = ", len(src_shape))
    input_shape = [int(input_height), int(input_width), int(input_channel)]
    return input_shape


def load_all_tensors(base_dir: str):
    base_path = Path(base_dir)
    mapper_path = base_path / "name_idx_mapper.json"

    with open(mapper_path, "r") as f:
        name_idx_mapper = json.load(f)

    value_dict = ValueDict()
    for name, idx in name_idx_mapper.items():
        tensor_path = base_path / f"{idx}.pt"

        if not tensor_path.exists():
            raise FileNotFoundError(
                f"Tensor file not found for name '{name}' at {tensor_path}"
            )

        tensor = torch.load(tensor_path)
        value_dict[name] = tensor
        print(f"Loaded: {tensor_path} -> as '{name}'")

    return value_dict
