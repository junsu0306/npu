import collections
import dataclasses
from typing import Callable

import qbcompiler.model_dict.common.options as layer_options
from qbcompiler.model_dict.common import (
    ModelDict,
    LayerType,
    SubGraph,
    WeightDict,
    Operator,
    ActivationSpec,
    TensorSpec,
)


def _new_activation(act):
    return ActivationSpec(
        name=act.name,
        dtype=act.dtype,
        shape=None,
        src_shape=act.src_shape,
        dataformat=act.dataformat,
    )


def _new_tensor(ts):
    return TensorSpec(name=ts.name, dtype=ts.dtype, shape=ts.shape)


class SubGraphScopeProcessor:
    def __init__(
        self,
        md: ModelDict,
        wd: WeightDict,
        start_check: Callable,
        end_check: Callable,
        kind,
        subgraph_name=None,
    ):
        self.md = md
        self.wd = wd
        self.start_check = start_check
        self.end_check = end_check
        self.kind = kind
        if subgraph_name is None:
            subgraph_name = kind
        self.subgraph_name = subgraph_name

    def process(self):
        # FIXME: This method modifies main_sg in place.
        #        Consider refactoring to create a new main_sg instead of mutating the original.
        main_sg = self.md.subgraphs[0]
        main_sg.update_op_act_connectivity()

        start_nodes = [x for x in main_sg.operators if self.start_check(x)]
        if not start_nodes:
            return

        replace_targets = []
        for idx, start_node in enumerate(start_nodes):
            _, end_node, collected_ops = self._collect_scoped_ops(main_sg, start_node)
            replace_targets.append(
                (
                    start_node,
                    end_node,
                    collected_ops,
                    self.kind,
                    f"{self.subgraph_name}_{idx}",
                )
            )
        new_subgraphs = self.replace_scope_to_subgraph_call(main_sg, replace_targets)
        return new_subgraphs

    def _collect_scoped_ops(self, main_sg, start_node):
        scoped_ops = []
        queue = collections.deque([start_node])
        visited = set()

        in_degree_counter = {}
        end_node = None

        while queue:
            curr_op = queue.popleft()
            if curr_op in visited:
                continue
            visited.add(curr_op)

            if self.end_check(curr_op):
                if end_node is not None:
                    raise RuntimeError(
                        "Multiple end nodes found. Currently not supported."
                    )
                end_node = curr_op

            scoped_ops.append(curr_op)

            if end_node and curr_op.name == end_node.name:
                continue

            for oidx in curr_op.options.outputs:
                outact = main_sg.activations[oidx]
                for cop in outact.consumer_ops:
                    if cop not in in_degree_counter:
                        cnt = 0
                        for iidx in cop.options.inputs:
                            pop = main_sg.activations[iidx].producer_op
                            if pop and pop.layertype != LayerType.InputConstant:
                                cnt += 1
                        in_degree_counter[cop] = cnt
                    in_degree_counter[cop] -= 1  # parent visited
                    if in_degree_counter[cop] <= 0:
                        queue.append(cop)
        if end_node in scoped_ops:
            scoped_ops.remove(end_node)
            scoped_ops.append(end_node)
        return start_node, end_node, scoped_ops

    def replace_scope_to_subgraph_call(self, main_sg, replace_targets):
        main_sg.update_op_act_connectivity()
        main_sg.idx = 0
        new_subgraphs = [main_sg]
        for start_node, end_node, collected_ops, kind, subgraph_name in replace_targets:
            outact_indices = []
            outacts = []
            for oidx in end_node.options.outputs:
                outact = main_sg.activations[oidx]
                if sum(x.valid for x in outact.consumer_ops) > 0:
                    outact_indices.append(oidx)
                    outacts.append(outact)
            outact0 = main_sg.activations[outact_indices[0]]
            graph_call = Operator(
                name=outact0.name,
                options=layer_options.SubgraphCallOptions(
                    inputs=tuple(start_node.options.inputs),
                    outputs=tuple(outact_indices),
                    scope=subgraph_name,
                    kind=kind,
                    subgraph=subgraph_name,
                ),
            )
            for oact in outacts:
                oact.producer_op = graph_call
            main_sg.operators.append(graph_call)
            new_sg = self._new_subgraph_proc(
                main_sg,
                start_node=start_node,
                end_node=end_node,
                collected_ops=collected_ops,
                subgraph_name=subgraph_name,
                subgraph_idx=len(new_subgraphs),
            )
            new_subgraphs.append(new_sg)
        main_sg.operators = [op for op in main_sg.operators if op.valid and op]
        for sg in new_subgraphs:
            sg.update_op_act_connectivity()
            sg.remove_dangling_activations()
            sg.remove_dangling_tensors()
            sg.update_next_operator()
            sg.update_graph_in_out()
            sg.update_next_operator()
        return new_subgraphs

    def _new_subgraph_proc(
        self, main_sg, start_node, end_node, collected_ops, subgraph_name, subgraph_idx
    ):
        operators = []
        activations = [None] * len(main_sg.activations)
        tensors = [None] * len(main_sg.tensors)
        sg_inputs = []
        sg_outputs = []

        in_degree = {op.name: 0 for op in collected_ops}
        for __op in collected_ops:
            for iidx in __op.options.inputs:
                prev_op = main_sg.activations[iidx].producer_op
                if prev_op is None:
                    raise RuntimeError("producer of input activation not found.")
                if prev_op.name in in_degree:
                    in_degree[__op.name] += 1

        # queue에 start_node, inputconst_node 그리고 외부의 inputconst를 input으로 가지는 노드들이 추가되었음.
        queue = collections.deque([start_node])
        queue.extend(
            _op
            for _op in collected_ops
            if in_degree[_op.name] == 0 and _op.name != start_node.name
        )
        while queue:
            curr_op = queue.popleft()
            for iidx in curr_op.options.inputs:
                if activations[iidx] is None:
                    act = main_sg.activations[iidx]
                    pop = act.producer_op
                    if pop.name not in in_degree:
                        if pop.layertype == LayerType.InputConstant:
                            act.consumer_ops = [
                                x for x in act.consumer_ops if x.name != curr_op.name
                            ]
                            new_act = _new_activation(act)
                            activations[iidx] = new_act
                            tidx = pop.options.constant
                            tensors[tidx] = _new_tensor(main_sg.tensors[tidx])
                            iconst = Operator(
                                name=new_act.name,
                                options=layer_options.InputConstantOptions(
                                    outputs=(iidx,), constant=tidx
                                ),
                            )
                            new_act.producer_op = iconst
                            operators.append(iconst)
                            in_degree[pop.name] = 0
                        else:
                            sg_inputs.append(iidx)
                            new_act = _new_activation(act)
                            activations[iidx] = new_act
                            input_op = Operator(
                                name=new_act.name,
                                options=layer_options.InputOptions(
                                    inputs=(iidx,), outputs=(iidx,)
                                ),
                            )
                            operators.append(input_op)
                            new_act.producer_op = input_op
                            in_degree[pop.name] = 0
            for oidx in curr_op.options.outputs:
                if activations[oidx] is not None:
                    raise RuntimeError("output activation already generated.")
                activations[oidx] = _new_activation(main_sg.activations[oidx])
            for k, tidx in curr_op.options.iter_tensorindex():
                if tidx != -1:
                    tensors[tidx] = _new_tensor(main_sg.tensors[tidx])
            new_op = Operator(
                name=curr_op.name,
                options=dataclasses.replace(curr_op.options),
                output_value_reference=curr_op.output_value_reference,
                unsupported=curr_op.unsupported,
            )
            operators.append(new_op)

            if curr_op.name == end_node.name:
                for oidx in curr_op.options.outputs:
                    sg_outputs.append(oidx)
                    act = activations[oidx]
                    op_output = Operator(
                        name=act.name,
                        options=layer_options.OutputOptions(
                            inputs=(oidx,), outputs=(oidx,)
                        ),
                    )
                    operators.append(op_output)

            for oidx in curr_op.options.outputs:
                oact = main_sg.activations[oidx]
                for cop in oact.consumer_ops:
                    if cop.name in in_degree:
                        in_degree[cop.name] -= 1
                        if in_degree[cop.name] <= 0:
                            queue.append(cop)

        for op in collected_ops:
            if op.layertype == LayerType.InputConstant:
                oact = main_sg.activations[op.options.outputs[0]]
                if not oact.consumer_ops:
                    op.valid = False
            else:
                op.valid = False

        new_sg = SubGraph(
            idx=subgraph_idx,
            name=subgraph_name,
            inputs=sg_inputs,
            outputs=sg_outputs,
            operators=operators,
            tensors=tensors,
            activations=activations,
        )

        return new_sg
