import functools
import json

from qbcompiler.logging import get_logger
from qbcompiler.model_dict.common import (
    SubGraph,
    Operator,
    WeightDict,
    LayerType,
)
from qbcompiler.model_dict.parser.graph_transform import (
    RuleSet,
    RuleNew,
    pattern,
    OpTransformResultV2,
)

logger = get_logger(__name__)

SparseMoeRuleSet = RuleSet("SparseMoeRuleSet")


START_TARGET = "sparse_moe_dispatcher"
END_TARGET = "sparse_moe_aggregator"
KIND = "sparse_moe"


def moe_check(op: Operator, target):
    if op.layertype != LayerType.HFPatchedFunction:
        return None
    fn = json.loads(op.options.content)["fn"]
    return fn.split(".")[-1] == target


start_check = functools.partial(moe_check, target=START_TARGET)
end_check = functools.partial(moe_check, target=END_TARGET)


def _parse_arg_map_dispatcher(content):
    """
    {
    "fn": "qbcompiler.model_dict.parser.backend.fx_hf_extensions.transformers.models.qwen3_moe.sparse_moe_dispatcher",
    "arg_map": {"router_logits": "$0", "hidden_states": "$1", "top_k": "8", "norm_topk_prob": "True"}
    }
    """

    arg_map = json.loads(content)["arg_map"]
    norm_topk_prob = arg_map["norm_topk_prob"]
    if isinstance(norm_topk_prob, str):
        if norm_topk_prob.lower() == "true":
            norm_topk_prob = True
        elif norm_topk_prob.lower() == "false":
            norm_topk_prob = False
        else:
            raise ValueError(f"Invalid norm_topk_prob: {norm_topk_prob}")
    elif isinstance(norm_topk_prob, int):
        norm_topk_prob = bool(norm_topk_prob)
    elif isinstance(norm_topk_prob, bool):
        pass
    else:
        raise NotImplementedError(f"Invalid norm_topk_prob: {norm_topk_prob}")
    top_k = int(arg_map["top_k"])
    hidden_states = arg_map["hidden_states"]
    hidden_first = hidden_states == "$0"
    return hidden_first, top_k, norm_topk_prob


def _parse_arg_map_aggregator(content):
    """
    {
        "fn": "qbcompiler.model_dict.parser.backend.fx_hf_extensions.transformers.models.qwen3_moe.sparse_moe_aggregator",
        "arg_map": {"expert_results": "$0", "routing_weights": "$1"},
    }
    """
    arg_map = json.loads(content)["arg_map"]
    expert_results = arg_map["expert_results"]
    expert_out_first = expert_results == "$0"
    return expert_out_first


@SparseMoeRuleSet.register
class SparseMoeNodeRule(RuleNew):
    @pattern
    def dispatcher(
        self, op: Operator, sg: SubGraph, wd: WeightDict = None, *args, **kwargs
    ):
        if start_check(op):
            return op
        return None

    @dispatcher.transform
    def dispatcher(
        self, op: Operator, sg: SubGraph, wd: WeightDict = None, *args, **kwargs
    ):
        dispatcher = self.matched_pattern
        builder = OpTransformResultV2.Builder(wd)

        new_inacts = []
        for iidx in dispatcher.options.inputs:
            inact = sg.activations[iidx]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            builder.add_input_map(new_inact, inact)
            new_inacts.append(new_inact)

        hidden_first, top_k, norm_topk_prob = _parse_arg_map_dispatcher(
            dispatcher.options.content
        )
        router_logits, hidden_states = new_inacts
        if hidden_first:
            hidden_states, router_logits = router_logits, hidden_states
        new_outacts = builder.make_moe_dispatcher(
            (router_logits, hidden_states), top_k=top_k, norm_top_k_prob=norm_topk_prob
        )
        new_router_out, new_hidden_out = new_outacts
        old_router_out, old_hidden_out = (
            sg.activations[x] for x in dispatcher.options.outputs
        )
        if hidden_first:
            old_hidden_out, old_router_out = old_router_out, old_hidden_out
        builder.add_output_map(new_router_out, old_router_out)
        builder.add_output_map(new_hidden_out, old_hidden_out)
        builder.remove_connectivity_and_invalidate(sg, dispatcher)
        return builder.build()

    @pattern
    def aggregator(
        self, op: Operator, sg: SubGraph, wd: WeightDict = None, *args, **kwargs
    ):
        if not end_check(op):
            return None
        pop0 = sg.activations[op.options.inputs[0]].producer_op
        pop1 = sg.activations[op.options.inputs[1]].producer_op
        if pop0 is None or pop1 is None:
            return None
        if (
            pop0.layertype == LayerType.Concatenate
            and pop1.layertype == LayerType.MoeDispatcher
        ):
            return op

        if (
            pop1.layertype == LayerType.Concatenate
            and pop0.layertype == LayerType.MoeDispatcher
        ):
            return op
        return None

    @aggregator.transform
    def aggregator(
        self, op: Operator, sg: SubGraph, wd: WeightDict = None, *args, **kwargs
    ):
        aggrtor = self.matched_pattern
        builder = OpTransformResultV2.Builder(wd)
        inact0 = sg.activations[aggrtor.options.inputs[0]]
        inact1 = sg.activations[aggrtor.options.inputs[1]]
        expert_results_first = _parse_arg_map_aggregator(aggrtor.options.content)
        routing_weights, expert_results = inact0, inact1
        if expert_results_first:
            routing_weights, expert_results = expert_results, routing_weights
        new_routing_weights = builder.copy_activationspec(
            routing_weights, add_input_map=True
        )
        dispatcher = inact0.producer_op
        concat = inact1.producer_op
        if concat.layertype == LayerType.MoeDispatcher:
            dispatcher, concat = concat, dispatcher
        new_inacts = [new_routing_weights]
        for iidx in concat.options.inputs:
            inact = sg.activations[iidx]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            builder.add_input_map(new_inact, inact)
            new_inacts.append(new_inact)

        new_outact = builder.make_moe_aggregator(new_inacts)
        old_outact = sg.activations[aggrtor.options.outputs[0]]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(sg, concat, aggrtor)

        return builder.build()
