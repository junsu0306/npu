import itertools
import math
import operator
from typing import Tuple

from qbcompiler.model_dict.common import (
    LayerType,
    DimValue,
    TensorShape,
    Operator,
    SubGraph,
    WeightDict,
)

_SHAPE_PRESERVING_SINGLE_OP = (
    #   activation functions
    LayerType.Celu,
    LayerType.Clip,
    LayerType.Elu,
    LayerType.Gelu,
    LayerType.HardSigmoid,
    LayerType.HardSwish,
    LayerType.Hardtanh,
    LayerType.LeakyRelu,
    LayerType.Mish,
    LayerType.PRelu,
    LayerType.QuickGelu,
    LayerType.Relu,
    LayerType.Sigmoid,
    LayerType.Swish,
    LayerType.Tanh,
    #   math functions
    LayerType.Erf,
    LayerType.Exp,
    LayerType.Pow,
    LayerType.Sqrt,
    LayerType.Softmax,
    LayerType.Softplus,
    LayerType.Rsqrt,
    LayerType.Logit,
    #  logical operators
    LayerType.Not,
    LayerType.Neg,
    # normalization
    LayerType.Batchnorm,
    LayerType.InstanceNormalization,
    LayerType.RmsNormalization,
    LayerType.LayerNormalization,
    #
    LayerType.Cast,
    LayerType.Not,
    LayerType.CumSum,
)

_CONST_ARITHMETIC_OP = (
    LayerType.AddingConstant,
    LayerType.MultiplyConstant,
    LayerType.SubConstant,
    LayerType.DivConstant,
)

_SHAPE_PRESERVING_BI_OP = (
    LayerType.Adding,
    LayerType.Sub,
    LayerType.Multiply,
    LayerType.Div,
    #
    LayerType.MaskedFill,
)

_REDUCE_OPS = (
    LayerType.ReduceMax,
    LayerType.ReduceMin,
    LayerType.ReduceSum,
    LayerType.ReduceMean,
    LayerType.ReduceProd,
    LayerType.ReduceL2,
)


def _get_broadcast_shape(*shapes):
    if not shapes:
        return ()

    shapes = [tuple(s) for s in shapes]
    max_ndim = max(len(s) for s in shapes)

    padded = [(1,) * (max_ndim - len(s)) + s for s in shapes]

    out = []
    for dims in zip(*padded):
        d = max(dims)
        if any(x != 1 and x != d for x in dims):
            raise ValueError(f"Incompatible dimensions at axis {dims}")
        out.append(d)

    return tuple(out)


def _biop_shape(shape0, shape1):
    def _rev_gen(left_src_shape, right_src_shape):
        for ls, rs in itertools.zip_longest(
            reversed(left_src_shape), reversed(right_src_shape), fillvalue=1
        ):
            left_dynamic = isinstance(ls, DimValue) and ls.dynamic
            right_dynamic = isinstance(rs, DimValue) and rs.dynamic
            v = None
            if left_dynamic and right_dynamic:
                if ls == rs:
                    v = DimValue(int(ls), True)
            elif not left_dynamic and not right_dynamic:
                if ls == rs or ls == 1 or rs == 1:
                    v = DimValue(max(int(ls), int(rs)), False)
            elif left_dynamic and not right_dynamic:
                if rs == 1:
                    v = DimValue(int(ls), True)
                # We allow this for now to handle incomplete information, but it should generally be avoided.
                elif ls == rs:
                    v = DimValue(int(ls), True)
            else:
                if ls == 1:
                    v = DimValue(int(rs), True)
                # We allow this for now to handle incomplete information, but it should generally be avoided.
                elif ls == rs:
                    v = DimValue(int(rs), True)
            if v is not None:
                yield v
            else:
                raise ValueError(
                    f"unable to broadcast: {left_src_shape}, {right_src_shape}"
                )

    return TensorShape(reversed(tuple(_rev_gen(shape0, shape1))))


def _conv_out_size(in_size, pad_front, pad_end, kernel, dilation, stride):
    out_size = math.floor(
        (int(in_size) + (pad_front + pad_end) - dilation * (kernel - 1) - 1) / stride
        + 1
    )
    return DimValue(out_size, isinstance(in_size, DimValue) and in_size.dynamic)


def _mul_tuple(tp):
    return math.prod(map(int, tp))


def _mul_shapes(shapes):
    return DimValue(
        _mul_tuple(shapes), any(isinstance(s, DimValue) and s.dynamic for s in shapes)
    )


def _conv2dlike_shape(input_shape, options, output_channels=None):
    if options.channel_last:
        n, h, w, c = input_shape
    else:
        n, c, h, w = input_shape
    if output_channels is None:
        output_channels = int(c)
    # fmt:off
    h_out = _conv_out_size(h, options.north_padding, options.south_padding, options.h_kernel, options.h_dilation,
                           options.h_stride)
    w_out = _conv_out_size(w, options.west_padding, options.east_padding, options.w_kernel, options.w_dilation,
                           options.w_stride)
    # fmt:on
    if options.channel_last:
        return TensorShape((n, h_out, w_out, output_channels))
    else:
        return TensorShape((n, output_channels, h_out, w_out))


def _conv1d_shape(input_shape, options, output_channels=None):
    if options.channel_last:
        n, x, c = input_shape
    else:
        n, c, x = input_shape
    if output_channels is None:
        output_channels = int(c)
    # fmt:off
    x_out = _conv_out_size(x, options.west_padding, options.east_padding, options.kernel, options.dilation,
                           options.stride)
    # fmt:on
    if options.channel_last:
        return TensorShape((n, x_out, output_channels))
    else:
        return TensorShape((n, output_channels, x_out))


def _reduce_op_shape(input_shape, options):
    dims = set(x if x >= 0 else x + len(input_shape) for x in options.reduce_axes)
    if options.keep_dims:
        output_shape = tuple(1 if ax in dims else d for ax, d in enumerate(input_shape))
    else:
        output_shape = tuple(d for ax, d in enumerate(input_shape) if ax not in dims)
    return TensorShape(output_shape)


def _matmul_shape(left_shape, right_shape, left_transpose=False, right_transpose=False):
    if len(left_shape) >= 2 and len(right_shape) >= 2:
        left_a, left_b = left_shape[-2:]
        right_a, right_b = right_shape[-2:]
        if left_transpose:
            left_a, left_b = left_b, left_a
        if right_transpose:
            right_a, right_b = right_b, right_a
        assert (
            left_b == right_a
        ), f"matmul shape mismatch: {left_shape}, {right_shape}, left_transpose={left_transpose}, right_transpose={right_transpose}"
        max_rank = max(len(left_shape), len(right_shape))
        left_shape = (1,) * (max_rank - len(left_shape)) + left_shape
        right_shape = (1,) * (max_rank - len(right_shape)) + right_shape
        lst = []
        for ls, rs in zip(left_shape[:-2], right_shape[:-2]):
            dynamic = any(isinstance(x, DimValue) and x.dynamic for x in (ls, rs))
            lst.append(DimValue(max(int(ls), int(rs)), dynamic=dynamic))
        lst.append(left_a)
        lst.append(right_b)
        return TensorShape(lst)

    raise NotImplementedError(
        f"shape {left_shape} and shape {right_shape} are not supported."
    )


def _reshape_output_shape(input_shape, new_shape=None):
    if new_shape is None:
        raise NotImplementedError

    num_free_axis = sum(s == -1 for s in new_shape)
    num_inact_dynamic = sum(dim.dynamic for dim in input_shape)

    assert num_free_axis <= 1
    new_shape = list(new_shape)
    for idx, ns in enumerate(new_shape):
        if ns == 0:
            new_shape[idx] = input_shape[idx]

    if num_free_axis == 0:
        output_shape = tuple(DimValue(x) for x in new_shape)
        if num_inact_dynamic == 0:
            output_shape = list(output_shape)
            # If last slice is added in subgraphs.
            if len(input_shape) == len(output_shape):
                if (
                    input_shape[:3] == (1, 1, 1)
                    and output_shape[:2] == [1, 1]
                    and input_shape[3] == output_shape[3]
                    and output_shape[2].dynamic
                ):
                    output_shape[2] = DimValue(1, dynamic=False)
                    output_shape = tuple(output_shape)
        elif len(input_shape) == len(output_shape) + 1:
            if (
                input_shape[:-2] == output_shape[:-1]
                and _mul_tuple(input_shape[-2:]) == output_shape[-1]
            ):
                for a, b in zip(input_shape[:-1], output_shape[:-2]):
                    b.set_dynamic(a.dynamic or b.dynamic)
        elif len(input_shape) == len(output_shape) - 1:
            if (
                input_shape[0] == output_shape[0]
                and input_shape[1:] == output_shape[2:]
                and 1 == output_shape[1]
            ):
                output_shape[0].set_dynamic(
                    input_shape[0].dynamic or output_shape[0].dynamic
                )
                for a, b in zip(input_shape[1:], output_shape[2:]):
                    b.set_dynamic(a.dynamic or b.dynamic)
        elif len(input_shape) == len(output_shape):
            if (
                all(getattr(x, "dynamic", False) for x in output_shape)
                and num_inact_dynamic == 1
            ):
                output_shape = list(output_shape)
                for idx, s in input_shape:
                    output_shape[idx].set_dynamic(s.dynamic)

    else:
        free_axis = new_shape.index(-1)
        total_elements = _mul_tuple(input_shape)
        known_product = _mul_tuple(
            int(x) for idx, x in enumerate(new_shape) if idx != free_axis
        )
        assert known_product > 0
        inferred_value = total_elements // known_product
        output_shape = tuple(
            DimValue(x) if ax != free_axis else DimValue(inferred_value)
            for ax, x in enumerate(new_shape)
        )
        pre_cnt = (
            int(_mul_tuple(new_shape[:free_axis]))
            if len(new_shape[:free_axis]) > 0
            else 0
        )
        related_axes = list(range(len(input_shape)))
        for ax, s in enumerate(input_shape):
            if pre_cnt == 0:
                break
            pre_cnt, r = divmod(pre_cnt, int(s))
            if r > 0:
                if pre_cnt == 0:
                    break
                raise ValueError
            else:
                related_axes.remove(ax)
                if pre_cnt == 1:
                    break
        post_cnt = (
            int(_mul_tuple(new_shape[free_axis + 1 :]))
            if len(new_shape[free_axis + 1 :]) > 0
            else 0
        )
        for ax, s in reversed(list(enumerate(input_shape))):
            if post_cnt == 0:
                break
            post_cnt, r = divmod(post_cnt, int(s))
            if r > 0:
                if post_cnt == 0:
                    break
                raise ValueError
            else:
                related_axes.remove(ax)
                if post_cnt == 1:
                    break
        if any(input_shape[ax].dynamic for ax in related_axes):
            output_shape[free_axis].set_dynamic()

        # new_shape is [25, 1, -1] but input is [dynamic(25),1,2,256] -> output [dynamic(25),1,512]
        if free_axis == 2 and len(new_shape) == 3:
            if output_shape[0] == new_shape[0] and input_shape[0].dynamic:
                output_shape[0].set_dynamic()

    return TensorShape(output_shape)


def _is_dynamic(dim):
    return isinstance(dim, DimValue) and dim.dynamic


def _slice_out_length(seq_len, start, end=None, step=None):
    if step is None:
        step = 1
    seq_len = int(seq_len)
    if end == 0:
        return 0
    elif end is None:
        end = seq_len
    elif end < 0:
        end += seq_len
    else:
        end = min(end, seq_len)  # free end
    if start < 0:
        start += seq_len
    q, r = divmod(max(0, end - start), step)
    if r > 0:
        q += 1
    return q


def infer_shape(
    op: Operator,
    sg: SubGraph,
    wd: WeightDict,
    *input_shapes: Tuple[int | DimValue, ...],
) -> TensorShape | Tuple[TensorShape, ...]:
    if op.layertype in _SHAPE_PRESERVING_SINGLE_OP or op.layertype == LayerType.Output:
        assert len(input_shapes) == 1
        return TensorShape(DimValue(x) for x in input_shapes[0])

    if op.layertype in _SHAPE_PRESERVING_BI_OP:
        assert len(input_shapes) == 2
        return _biop_shape(input_shapes[0], input_shapes[1])

    if op.layertype in _CONST_ARITHMETIC_OP:
        assert len(input_shapes) == 1
        input_shape = input_shapes[0]
        const_shape = TensorShape(sg.tensors[op.options.constant].shape)
        if len(input_shape) > len(const_shape):
            const_shape = (1,) * (len(input_shape) - len(const_shape)) + tuple(
                const_shape
            )
        elif len(input_shape) < len(const_shape):
            input_shape = (1,) * (len(const_shape) - len(input_shape)) + tuple(
                input_shape
            )
        return _biop_shape(input_shape, const_shape)

    if op.layertype in (
        LayerType.Convolution,
        LayerType.DepthwiseConvolution,
        LayerType.GroupConvolution,
    ):
        assert len(input_shapes) == 1
        return _conv2dlike_shape(input_shapes[0], op.options, op.options.out_channels)

    if op.layertype == LayerType.TransposeConvolution:
        assert len(input_shapes) == 1
        n, h, w, c = input_shapes[0]
        strided_in_h = (h - 1) * op.options.h_stride + 1
        strided_in_w = (w - 1) * op.options.w_stride + 1
        h_out = _conv_out_size(
            strided_in_h,
            op.options.north_padding,
            op.options.south_padding,
            op.options.h_kernel,
            op.options.h_dilation,
            1,
        )
        w_out = _conv_out_size(
            strided_in_w,
            op.options.west_padding,
            op.options.east_padding,
            op.options.w_kernel,
            op.options.w_dilation,
            1,
        )
        return TensorShape((n, h_out, w_out, op.options.out_channels))

    if op.layertype in (LayerType.Convolution1d,):
        assert len(input_shapes) == 1
        return _conv1d_shape(input_shapes[0], op.options, op.options.out_channels)

    if op.layertype == LayerType.Pooling:
        assert len(input_shapes) == 1
        return _conv2dlike_shape(input_shapes[0], op.options)

    if op.layertype == LayerType.GemmConstant:
        assert len(input_shapes) == 1
        if op.options.is_const_first:
            A_shape = TensorShape(sg.tensors[op.options.constant].shape)
            B_shape = input_shapes[0]
            return _matmul_shape(A_shape, B_shape, op.options.transA, op.options.transB)
        else:
            A_shape = input_shapes[0]
            B_shape = TensorShape(sg.tensors[op.options.constant].shape)
            return _matmul_shape(A_shape, B_shape, op.options.transA, op.options.transB)

    if op.layertype == LayerType.GlobalAveragePooling:
        assert len(input_shapes) == 1
        input_shape = input_shapes[0]
        outact_src_shape = list(input_shape)

        if op.options.channel_last:
            outact_src_shape[1:-1] = [1] * (len(outact_src_shape) - 2)
            outact_src_shape = tuple(outact_src_shape)
            return TensorShape(outact_src_shape)
        else:
            outact_src_shape[2:] = [1] * (len(outact_src_shape) - 2)
            outact_src_shape = tuple(outact_src_shape)
            return TensorShape(outact_src_shape)

    if op.layertype == LayerType.Resize:
        assert len(input_shapes) == 1
        input_shape = input_shapes[0]
        if op.options.sizes is not None:
            output_shape = op.options.sizes
        elif op.options.scales is not None:
            assert len(op.options.scales) == len(input_shape)
            assert op.options.scales == tuple(x for x in op.options.scales)
            # fixme: what if x*s is not an integer?
            output_shape = [x * s for x, s in zip(input_shape, op.options.scales)]
        else:
            raise NotImplementedError
        return TensorShape(output_shape)

    if op.layertype == LayerType.Concatenate:
        cc_axis = op.options.axis
        if cc_axis is None:
            cc_axis = op.options.original_axis
        if cc_axis is None:
            raise ValueError

        cmp_cc_axis = cc_axis
        cmps = []
        if cc_axis < 0:
            cmp_cc_axis = cc_axis + len(input_shapes[0])

        for ishape in input_shapes:
            cmps.append(tuple(x for idx, x in enumerate(ishape) if idx != cmp_cc_axis))
        assert all(cmps[0] == x for x in cmps)
        output_shape = list(input_shapes[0])
        output_shape[cc_axis] = DimValue(
            sum(x[cc_axis] for x in input_shapes),
            any(_is_dynamic(x[cc_axis]) for x in input_shapes),
        )

        return TensorShape(output_shape)

    if op.layertype == LayerType.Embedding:
        output_shape = input_shapes[0] + (DimValue(op.options.embedding_dim),)
        return TensorShape(output_shape)

    if op.layertype == LayerType.Slice:
        if len(op.options.axis) > 1:
            raise NotImplementedError
        input_shape = input_shapes[0]
        output_shape = list(input_shape)
        axis = op.options.axis[0]
        start = op.options.start[0]
        end = op.options.end[0]
        step = op.options.step[0] if op.options.step is not None else 1
        seqlen = input_shape[axis]
        is_free_end = end is None or end >= 2147483647
        is_dynamic = _is_dynamic(seqlen) and (start > 0 and is_free_end)
        output_shape[axis] = DimValue(
            _slice_out_length(seqlen, start, end, step), is_dynamic
        )
        return TensorShape(output_shape)

    if op.layertype == LayerType.Transpose:
        assert len(input_shapes) == 1
        input_shape = input_shapes[0]
        return TensorShape(operator.itemgetter(*op.options.transpose_axes)(input_shape))

    if op.layertype == LayerType.Reshape:
        assert len(input_shapes) == 1
        input_shape = input_shapes[0]
        new_shape = op.options.new_shape
        if new_shape is None:
            new_shape = TensorShape(
                sg.activations[op.options.outputs[0]].get_act_src_shape()
            )
        return _reshape_output_shape(input_shape, new_shape)

    if op.layertype == LayerType.Flatten:
        assert len(input_shapes) == 1
        input_shape = input_shapes[0]
        axis = int(op.options.axis)
        # see: https://onnx.ai/onnx/operators/onnx__Flatten.html
        if axis == 0:
            return TensorShape((1, _mul_shapes(input_shape)))
        pre, post = input_shape[:axis], input_shape[axis:]
        return TensorShape((_mul_shapes(pre), _mul_shapes(post)))

    if op.layertype == LayerType.Unsqueeze:
        assert len(input_shapes) == 1
        if len(op.options.axes) != 1:
            raise NotImplementedError
        input_shape = input_shapes[0]
        axis = int(op.options.axes[0])
        if axis < 0:
            axis += len(input_shape) + 1
        output_shape = input_shape[:axis] + (1,) + input_shape[axis:]
        return TensorShape(output_shape)

    if op.layertype == LayerType.Squeeze:
        assert len(input_shapes) == 1
        shape_ = input_shapes[0]
        squeeze_axes = op.options.squeeze_axes
        if squeeze_axes is not None:
            squeeze_axes = tuple(x if x >= 0 else x + len(shape_) for x in squeeze_axes)
            output_shape = []
            for idx, x in enumerate(shape_):
                if idx not in squeeze_axes:
                    output_shape.append(x)
                else:
                    assert x == 1
        else:
            output_shape = tuple(dim for dim in shape_ if dim != 1)

        return TensorShape(output_shape)

    if op.layertype in _REDUCE_OPS:
        assert len(input_shapes) == 1
        return _reduce_op_shape(input_shapes[0], op.options)

    if op.layertype == LayerType.Pad:
        assert len(input_shapes) == 1
        input_shape = input_shapes[0]
        rank = len(input_shape)
        if not op.options.padding_list:
            raise NotImplementedError
        pre_padding = op.options.padding_list[:rank]
        post_padding = op.options.padding_list[rank:]

        output_shape = []
        for pre, x, post in zip(pre_padding, input_shape, post_padding):
            output_shape.append(pre + x + post)
        return TensorShape(output_shape)

    if op.layertype == LayerType.Split:
        assert len(input_shapes) == 1
        input_shape = input_shapes[0]
        assert input_shape[op.options.axis] == sum(op.options.split)
        output_shape = list(input_shape)
        output_shape[op.options.axis] = op.options.split[op.options.split_index]
        return TensorShape(output_shape)

    if op.layertype == LayerType.Expand:
        assert len(input_shapes) == 1
        assert not op.options.is_const_first
        input_shape = input_shapes[0]
        const_shape = wd.get_weight_by_name(sg.tensors[op.options.constant].name)
        assert len(input_shape) == len(const_shape)
        output_shape = []
        for a, b in zip(input_shape, const_shape):
            if b == -1:
                output_shape.append(a)
            else:
                if a != b and b != 1:
                    output_shape.append(b)
                else:
                    output_shape.append(a)
        return TensorShape(output_shape)

    if op.layertype == LayerType.Equal:
        input_shape = input_shapes[0]
        const_shape = wd.get_weight_by_name(sg.tensors[op.options.constant].name).shape
        broadcast_shape = _get_broadcast_shape(input_shape, const_shape)
        return TensorShape(broadcast_shape)

    if op.layertype == LayerType.InputConstant:
        assert len(input_shapes) == 0
        const_shape = sg.tensors[op.options.constant].shape
        return TensorShape(const_shape)
    if op.layertype == LayerType.MatMul:
        assert len(input_shapes) == 2
        return _matmul_shape(input_shapes[0], input_shapes[1])

    if op.layertype == LayerType.Tile:
        assert len(input_shapes) == 1
        input_shape = input_shapes[0]
        assert len(input_shape) == len(op.options.repeats)
        output_shape = tuple(i * r for i, r in zip(input_shape, op.options.repeats))
        return TensorShape(output_shape)

    if op.layertype == LayerType.ScatterND:
        if len(input_shapes) == 2:
            if op.options.constant_indices != -1:
                data = sg.activations[op.options.inputs[0]]
                output_shape = data.get_act_src_shape()
        else:
            raise NotImplementedError
        return TensorShape(output_shape)
    if op.layertype == LayerType.GatherConstant:
        if op.options.is_const_first:
            input_shape = input_shapes[0]
            data_shape = sg.tensors[op.options.constant].shape
            if len(data_shape) == 2 and len(input_shape) == 2:
                output_shape = input_shape + (data_shape[-1],)
            else:
                raise NotImplementedError
        else:
            input_shape = input_shapes[0]
            indices_shape = sg.tensors[op.options.constant].shape
            if len(indices_shape) == 0:
                axis = op.options.axis
                if axis < 0:
                    axis += len(input_shape)
                output_shape = tuple(
                    x for idx, x in enumerate(input_shape) if idx != axis
                )
            else:
                raise NotImplementedError
        return TensorShape(output_shape)
    if op.layertype == LayerType.Identity:
        return TensorShape(input_shapes[0])
    if op.layertype in (LayerType.Cos, LayerType.Sin):
        return TensorShape(input_shapes[0])
    if op.layertype in (
        LayerType.StatefulRNNWrapper,
        LayerType.StatefulGRUWrapper,
        LayerType.StatefulLSTMWrapper,
    ):
        is_dynamic = False
        for i, x in enumerate(op.options.input_mask):
            if x == "i":
                is_dynamic = input_shapes[i][-2].dynamic
        output_shape = tuple(
            TensorShape(sg.activations[oidx].get_act_src_shape())
            for oidx in op.options.outputs
        )
        for i, s in enumerate(op.options.output_mask):
            if s == "o":
                output_shape[i][-2].set_dynamic(is_dynamic)
        return output_shape
    if op.layertype == LayerType.StatefulKVCacheWrapper:
        in_shape = input_shapes[0]
        output_shape = TensorShape(in_shape)
        output_shape[-2].set_dynamic(True)
        return output_shape
    if op.layertype == LayerType.StatefulRoPEWrapper:
        in_shape = input_shapes[0]
        output_shape = TensorShape(in_shape)
        return output_shape
    if op.layertype == LayerType.StatefulAttentionMaskWrapper:
        in_shape = input_shapes[0]
        output_shape = TensorShape(in_shape)
        return output_shape
    if op.layertype == LayerType.HeaderView:
        in_shape = input_shapes[0]
        n, h, w, c = in_shape
        g = op.options.num_heads
        output_shape = TensorShape((n, h * g, w, c // g))
        return output_shape
    if op.layertype == LayerType.HeaderViewRevert:
        in_shape = input_shapes[0]
        n, h, w, c = in_shape
        g = op.options.num_heads
        output_shape = TensorShape((n, h // g, w, c * g))
        return output_shape

    raise NotImplementedError(
        f"infer_shape not implemented for layertype={op.layertype}."
    )
