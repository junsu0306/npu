import dataclasses
import torch

from qbcompiler.model_dict.common import SubGraph
from qbcompiler.model_dict.common.dtypes import TensorIndex
from qbcompiler.model_dict.common.item_specs import ActivationSpec
from qbcompiler.model_dict.common.model_dict import WeightDict
from qbcompiler.model_dict.common.tensor import WrappedTensor, DataFormat
from qbcompiler.model_dict.common.layers import get_layer_cls

_DT_CAST = {
    "float64": torch.float64,
    "float32": torch.float32,
    "float16": torch.float16,
    "bfloat16": torch.bfloat16,
    "uint8": torch.uint8,
    "bool": torch.bool,
    "int32": torch.int32,
    "int64": torch.int64,
    "int": torch.int64,
}


def get_random_tensor(shape, dtype):
    return torch.rand(size=shape, dtype=to_torch_dtype(dtype))


def to_torch_dtype(dtype_: str):
    if dtype_.lower() not in _DT_CAST:
        raise NotImplementedError(f"dtype:{dtype_}")
    return _DT_CAST[dtype_.lower()]


def validate_dtype_and_shape(
    act: ActivationSpec, data_: WrappedTensor, check_dtype=True
):
    if data_.dataformat == DataFormat.UNKNOWN:
        return

    if check_dtype and to_torch_dtype(act.dtype) != to_torch_dtype(data_.dtype):
        if set((to_torch_dtype(act.dtype), to_torch_dtype(data_.dtype))) not in [
            set((torch.bfloat16, torch.float32)),
            set((torch.bfloat16, torch.float16)),
            set((torch.float16, torch.float32)),
            set((torch.float16, torch.float64)),
            set((torch.float32, torch.float64)),
        ]:
            raise Exception(
                f"different dtype: {act.dtype}!={data_.dtype} at {act.name}"
            )


def _is_supported_shape(inact: ActivationSpec):
    """
    input shape HWC has valid values or src_shape is supported shape(NHWC)
    """
    if inact.src_shape == (-1, -1, -1):
        return -1 not in inact.shape
    if inact.shape == (-1, -1, -1):
        return len(inact.src_shape) == 4 and inact.src_shape[0] == 1
    return (
        inact.shape == inact.src_shape[1:]
        and len(inact.src_shape) == 4
        and inact.src_shape[0] == 1
    )


def _is_supported_activation(act: ActivationSpec):
    return act.dataformat == DataFormat.NHWC and _is_supported_shape(act)


def _get_act_shape_as_supported(inact: ActivationSpec):
    """
    returns act shape as if it is input to supported layer.
    returns None if not
    """
    if _is_supported_shape(inact):
        return inact.shape if -1 not in inact.shape else inact.src_shape[1:]
    return None


def get_act_src_shape(act: ActivationSpec):
    if _is_supported_activation(act):
        return (1,) + _get_act_shape_as_supported(act)
    return act.src_shape


def get_torch_op(
    options,
    layer_name: str,
    device,
    is_npu: bool,
    subgraph: SubGraph,
    weight_dict: WeightDict,
    **kwargs,
):
    op_name = options.__class__.__name__[:-7]
    kwargs_ = {}

    custom_fn = kwargs.pop("custom_fn", None)

    for k, v in dataclasses.asdict(options).items():
        if k in ("inputs", "outputs"):
            kwargs_[k] = tuple(subgraph.activations[x] for x in v)
        elif isinstance(v, TensorIndex):
            if v != -1:
                kwargs_[k] = weight_dict.get_weight_by_name(subgraph.get_tensor(v).name)
            else:
                kwargs_[k] = None
        else:
            kwargs_[k] = v
    layer_cls = get_layer_cls(op_name)
    kwargs_["is_npu"] = is_npu
    kwargs_["quantizer_save"] = kwargs.get("quantizer_save", False)
    kwargs_["target_device"] = kwargs.get("target_device", None)
    if (
        op_name == "Concatenate" and options.input_index is not None
    ):  # supported channel concat is assumed.
        kwargs_["original_input_channels"] = tuple(
            get_act_src_shape(subgraph.activations[x])[-1]
            for x in options.original_inputs
        )
    kwargs_.update(kwargs)
    obj = layer_cls(layer_name, device, **kwargs_)
    obj.custom_fn = custom_fn
    return obj
