from collections import defaultdict
from typing import Union, Dict, List, Optional
from pathlib import Path

import torch
import torch.nn as nn

import collections
import dataclasses
import itertools
import json

from itertools import permutations
from collections import Counter
from typing import Dict, Optional, List, Any

import numpy
import torch

try:
    import transformers

    _TRANSFORMERS_AVAILABLE = True
except ImportError as e:
    transformers = None
    _TRANSFORMERS_AVAILABLE = False

from qbcompiler.model_dict.serialize import SerializeMeta
from qbcompiler.model_dict.common import SubGraph, Operator
from qbcompiler.model_dict.common.item_specs import ActivationSpec, TensorSpec
from qbcompiler.model_dict.common.model_dict import (
    ModelDict,
    WeightDict,
    ValueDict,
)
from qbcompiler.model_dict.common.options import LayerType
from qbcompiler.model_dict.common.tensor import WrappedTensor, DataFormat, InputSG
from qbcompiler.model_dict.common.value_wrapper import ValueWrapper
from qbcompiler.model_dict.serialize import InferenceValueSerializeMeta
from qbcompiler.model_dict.parser.graph_transform import ActivationTracer, ActTraceT0
from .utils import to_torch_dtype, validate_dtype_and_shape, get_torch_op


def _can_align_by_squeeze_transpose(a: torch.Tensor, b: torch.Tensor) -> bool:
    dims_a = [d for d in a.shape if d != 1]
    dims_b = [d for d in b.shape if d != 1]

    return Counter(dims_a) == Counter(dims_b)


class OperatorInference:
    def __init__(
        self,
        options,
        layer_name: str,
        device="cpu",
        is_npu: bool = False,
        subgraph: SubGraph = None,
        weight_dict: WeightDict = None,
        quantizer_save: bool = False,
        **kwargs,
    ):
        self.compute_fn = get_torch_op(
            options,
            layer_name,
            device,
            is_npu,
            subgraph,
            weight_dict,
            quantizer_save=quantizer_save,
            **kwargs,
        )
        self._num_inputs = len(options.inputs)
        self._num_outputs = len(options.outputs)

    def __call__(self, input_data):
        return self.compute_fn(*input_data)

    def fwd(self, in_acts):
        return self.compute_fn.dformat_fwd(*in_acts)

    def bwd(self, out_act):
        return self.compute_fn.dformat_bwd(out_act)

    def folding_fwd(self, input_data):
        return self.compute_fn.folding_fwd(*input_data)

    def get_ops(self):
        return self.compute_fn.get_ops()


class OperatorInferenceModule(nn.Module):
    def __init__(
        self,
        options,
        layer_name: str,
        device="cuda",
        is_npu: bool = False,
        subgraph: SubGraph = None,
        weight_dict: WeightDict = None,
        quantizer_save: bool = False,
        **kwargs,
    ):
        super().__init__()
        self.impl = OperatorInference(
            options=options,
            layer_name=layer_name,
            device=device,
            is_npu=is_npu,
            subgraph=subgraph,
            weight_dict=weight_dict,
            quantizer_save=quantizer_save,
            **kwargs,
        )

    def forward(self, input_data):
        out = self.impl.compute_fn(*input_data)
        return out if isinstance(out, (tuple, list)) else (out,)


@dataclasses.dataclass
class OpInferenceResult:
    subgraph: int
    layertype: LayerType
    opname: str
    outact: str
    has_ref_value: bool
    all_close: Optional[bool] = None
    different_shape: Optional[str] = None
    mape_masked: Optional[float] = None
    max_rel_error_masked: Optional[float] = None
    abs_rpd_masked_max: Optional[float] = None
    abs_rpd_masked_mean: Optional[float] = None
    max_diff: Optional[float] = None
    hl_inference_max_value: Optional[float] = None
    source_inference_max_value: Optional[float] = None
    rel_err_cnt: Optional[int] = None
    all_elem_cnt: Optional[int] = None


class SubgraphState:
    def __init__(self):
        self._states = {}

    def add_state(self, name: str, value: Any):
        self._states[name] = value

    def get_state(self, name: str, default=None):
        return self._states.get(name, None)

    def __repr__(self):
        return str(self._states)

    def update(self, name: str, new_value):
        self._states[name] = new_value


class SubgraphInference:
    run_count = 0

    def __init__(
        self,
        model_dict: ModelDict,
        weight_dict: WeightDict,
        value_dict: ValueDict = None,
        activation_tracer: ActivationTracer = None,
        subgraph: SubGraph = None,
        inputsg: InputSG = None,
        output_tensors=None,
        save_all_outputs=True,
        compare_values=True,
        device="cpu",
        use_value_dict_data_for_next_input=True,
        quantizer_save=False,
        subgraph_state: SubgraphState = None,
        clearOutputCache=False,
        **kwargs,
    ) -> None:
        self.device = device
        self.is_npu = not subgraph.unsupported
        if output_tensors is None:
            output_tensors = {}
        if value_dict is None:
            value_dict = {}
        if inputsg is None:
            input_dict = {}
        else:
            input_dict = inputsg.inputs
        self.activation_tracer = activation_tracer
        self._output_tensors = output_tensors
        self._subgraph = subgraph
        self._model_dict = model_dict
        self._weight_dict = weight_dict
        self._value_dict: ValueDict = value_dict
        self._inputsg = inputsg
        self._input_dict = input_dict
        self._save_all_outputs = save_all_outputs
        self._use_value_dict_data_for_next_input = use_value_dict_data_for_next_input
        self._quantizer_save = quantizer_save
        self._subgraph_input_names = []
        self._ops = 0
        self._inference_output_value_dict = ValueDict()
        self._compare_values = compare_values
        self._clear_output_cache = clearOutputCache
        self._input_use_cnt = None

        self.op_inference_result = []
        self.ATOL = 1e-6
        self.RTOL = 1e-6

        self._skip_input_validation = False

        if subgraph_state is not None:
            ss = SubgraphState()
            for k, v in subgraph_state.items():
                ss.add_state(k, v)
            self._state: SubgraphState = ss

        if self._clear_output_cache:
            self._input_use_cnt = self._get_input_use_count()

    def _get_input_use_count(self):
        dct = {}
        for op in self._subgraph.operators:
            for iidx in op.options.inputs:
                key = self._subgraph.activations[iidx].name
                dct[key] = dct.get(key, 0) + 1
        return dct

    def skip_op_input_validation(self):
        self._skip_input_validation = True

    def add_input_data(self, name: str, data: WrappedTensor):
        self._input_dict[name] = data

    def get_output_tensors(self):
        return self._output_tensors

    def get_output_tensor(self, name: str):
        return self._output_tensors[name]

    def get_subgraph_outputs(self):
        dct = {}
        for oact in self._subgraph.output_activations():
            try:
                ts = self._output_tensors[oact.name]
                dct[oact.name] = ts.to("cpu")
            except Exception as e:
                raise e
        return dct

    def _get_op_input_data(self, in_acts: List[ActivationSpec], op: Operator):
        reference_name = op.output_value_reference
        if hasattr(op.output_value_reference, "ref_name"):
            reference_name = reference_name.ref_name
        if op.layertype == LayerType.Input:
            inact = in_acts[0]
            if inact.name in self._output_tensors:
                x = self._output_tensors[inact.name]._t
            elif inact.name in self._input_dict:
                x = self._input_dict[inact.name]._t
            elif reference_name in self._input_dict:
                x = self._input_dict[reference_name]._t
            else:
                raise Exception(inact.name, reference_name)
            return [
                WrappedTensor(
                    data=x,
                    dtype=to_torch_dtype(inact.dtype),
                    dataformat=inact.dataformat,
                )
            ]

        def gen():
            for in_act in in_acts:
                if in_act.name in self._output_tensors:
                    x = self._output_tensors[in_act.name]
                elif in_act.name in self._input_dict:
                    x = self._input_dict[in_act.name]
                elif (
                    isinstance(reference_name, str)
                    and reference_name in self._input_dict
                ):
                    x = self._input_dict[reference_name]
                # elif (
                #     isinstance(reference_name, str)
                #     and reference_name in self._output_tensors
                # ):
                #     x = self._output_tensors[reference_name]
                else:
                    x = None
                if x is not None:
                    if not self._skip_input_validation:
                        validate_dtype_and_shape(in_act, x)
                    yield WrappedTensor(
                        data=x._t,
                        dtype=to_torch_dtype(in_act.dtype),
                        dataformat=in_act.dataformat,
                    )

        return list(gen())

    def _get_kwargs(self, op):
        kw = {}
        if op.layertype == LayerType.Reshape:
            outact = self._subgraph.activations[op.options.outputs[0]]
            if outact.src_shape != (-1, -1, -1):
                kw["output_src_shape"] = outact.src_shape
            else:
                kw["output_src_shape"] = (1,) + outact.shape
            if op.options.new_shape is None:
                kw["new_shape"] = kw["output_src_shape"]
        if op.layertype == LayerType.StatefulRoPEWrapper:
            if not hasattr(self, "_state"):
                self._state = SubgraphState()
            if "seen_tokens" not in self._state._states:
                self._state.add_state("seen_tokens", 0)
            kw["seen_tokens"] = self._state.get_state("seen_tokens")
        if op.layertype == LayerType.StatefulKVCacheWrapper:
            if not hasattr(self, "_state"):
                self._state = SubgraphState()
            if "past_key_values" not in self._state._states:
                self._state.add_state("past_key_values", {"_seen_tokens": 0})
            kw["past_key_values"] = self._state.get_state("past_key_values")

        if op.layertype in (
            LayerType.CustomBiOp,
            LayerType.CustomSingleOp,
            LayerType.CustomOp,
        ):
            kw["custom_fn"] = op.custom_fn
        if op.layertype == LayerType.StatefulCausalConvCacheWrapper:
            kw["conv_cache"] = self._state.get_state("conv_cache")
        if op.layertype == LayerType.DynamicSliceInputConst:
            kw["slice_len"] = self._state.get_state("slice_len")
        return kw

    def _run_stateful_lstm_wrapper(
        self,
        lstm: Operator,
        lstm_sg: SubGraph,
        in_acts: List[ActivationSpec],
        out_acts: List[ActivationSpec],
        in_data: List[WrappedTensor],
    ):
        seq_len = None
        if lstm.options.input_mask == "ihc":
            inact_x, inact_h, inact_c = in_acts
            indata, hidden, cell = in_data
        elif lstm.options.input_mask == "ishc":
            inact_x, input_s, inact_h, inact_c = in_acts
            indata, seq_len, hidden, cell = in_data
            seq_len = int(seq_len._t)
        else:
            raise NotImplementedError(
                f"input_mask:{lstm.options.input_mask} not implemented"
            )

        if lstm.options.batch_first:
            all_seq_len = indata._t.shape[2]
        else:
            all_seq_len = indata._t.shape[1]

        o_src_shape = out_acts[0].src_shape
        h_src_shape = out_acts[1].src_shape
        c_src_shape = out_acts[2].src_shape

        def _wrap(torch_tensor):
            return WrappedTensor(torch_tensor, indata.dtype, indata.dataformat)

        def _gen_sequence(indata, direction, seq_len, batch_first=True):
            if batch_first:
                if seq_len is not None:
                    indata = indata[:, :seq_len, :, :]
                if direction == "forward":
                    for i in range(indata.shape[2]):
                        yield i, indata[:, :, i : i + 1, ...]
                elif direction == "backward":
                    for i in reversed(range(indata.shape[2])):
                        yield i, indata[:, :, i : i + 1, ...]
                else:
                    raise NotImplementedError("code should not be reached!")
            else:
                raise NotImplementedError()

        all_hidden = torch.zeros(size=o_src_shape, dtype=indata._t.dtype)
        for i, seq_data in _gen_sequence(
            indata._t, lstm.options.direction, seq_len, lstm.options.batch_first
        ):
            lstm_sg_inference = SubgraphInference(
                model_dict=self._model_dict,
                weight_dict=self._weight_dict,
                activation_tracer=self.activation_tracer,
                subgraph=lstm_sg,
                save_all_outputs=False,
                device=self.device,
                compare_values=False,
                use_value_dict_data_for_next_input=False,
            )
            lstm_sg_inference.add_input_data(inact_h.name, hidden)
            lstm_sg_inference.add_input_data(inact_c.name, cell)
            lstm_sg_inference.add_input_data(inact_x.name, _wrap(seq_data))
            lstm_sg_inference.run_inference(
                inference_name=f"{lstm.name}({i + 1}/{all_seq_len})"
            )

            cell = lstm_sg_inference.get_output_tensor(lstm.options.cell_state_name)
            hidden = lstm_sg_inference.get_output_tensor(lstm.options.hidden_state_name)
            all_hidden[:, :, i : i + 1, :] = hidden._t

        ret = {"o": _wrap(all_hidden), "h": hidden, "c": cell}
        # return tuple(ret[x] for x in lstm.options.output_mask)
        return tuple(ret[x] for x in "ohc")

    def _run_stateful_rnn_wrapper(
        self,
        rnn: Operator,
        rnn_sg: SubGraph,
        in_acts: List[ActivationSpec],
        out_acts: List[ActivationSpec],
        in_data: List[WrappedTensor],
    ):
        seq_len = None
        if rnn.options.input_mask == "ih":
            inact_x, inact_h = in_acts
            indata, hidden = in_data
        else:
            raise NotImplementedError(
                f"input_mask:{rnn.options.input_mask} not implemented"
            )
        if rnn.options.batch_first:
            all_seq_len = indata._t.shape[2]
        else:
            all_seq_len = indata._t.shape[1]

        o_src_shape = out_acts[0].src_shape

        def _wrap(torch_tensor):
            return WrappedTensor(torch_tensor, indata.dtype, indata.dataformat)

        def _gen_sequence(indata, direction, seq_len, batch_first=True):
            if batch_first:
                if seq_len is not None:
                    indata = indata[:, :, :seq_len, :]
                if direction == "forward":
                    for i in range(indata.shape[2]):
                        yield i, indata[:, :, i : i + 1, ...]
                elif direction == "backward":
                    for i in reversed(range(indata.shape[2])):
                        yield i, indata[:, :, i : i + 1, ...]
                else:
                    raise NotImplementedError("code should not be reached!")
            else:
                raise NotImplementedError()

        all_hidden = torch.zeros(size=o_src_shape, dtype=indata._t.dtype)
        for i, seq_data in _gen_sequence(
            indata._t, rnn.options.direction, seq_len, rnn.options.batch_first
        ):
            sg_inference = SubgraphInference(
                model_dict=self._model_dict,
                weight_dict=self._weight_dict,
                activation_tracer=self.activation_tracer,
                subgraph=rnn_sg,
                save_all_outputs=False,
                device=self.device,
                compare_values=False,
                use_value_dict_data_for_next_input=False,
            )
            sg_inference.add_input_data(inact_h.name, hidden)
            sg_inference.add_input_data(inact_x.name, _wrap(seq_data))
            sg_inference.run_inference(
                inference_name=f"{rnn.name}({i + 1}/{all_seq_len})"
            )

            hidden = sg_inference.get_output_tensor(rnn.options.hidden_state_name)
            all_hidden[:, :, i : i + 1, :] = hidden._t

        ret = {"o": _wrap(all_hidden), "h": hidden}
        # return tuple(ret[x] for x in lstm.options.output_mask)
        return tuple(ret[x] for x in "oh")

    def _run_stateful_gru_wrapper(
        self,
        gru: Operator,
        gru_sg: SubGraph,
        in_acts: List[ActivationSpec],
        out_acts: List[ActivationSpec],
        in_data: List[WrappedTensor],
    ):
        seq_len = None
        if gru.options.input_mask == "ih":
            inact_x, inact_h = in_acts
            indata, hidden = in_data
        else:
            raise NotImplementedError(
                f"input_mask:{gru.options.input_mask} not implemented"
            )
        if gru.options.batch_first:
            all_seq_len = indata._t.shape[2]
        else:
            all_seq_len = indata._t.shape[1]

        o_src_shape = out_acts[0].src_shape

        def _wrap(torch_tensor):
            return WrappedTensor(torch_tensor, indata.dtype, indata.dataformat)

        def _gen_sequence(indata, direction, seq_len, batch_first=True):
            if batch_first:
                if seq_len is not None:
                    indata = indata[:, :, :seq_len, :]
                if direction == "forward":
                    for i in range(indata.shape[2]):
                        yield i, indata[:, :, i : i + 1, ...]
                elif direction == "backward":
                    for i in reversed(range(indata.shape[2])):
                        yield i, indata[:, :, i : i + 1, ...]
                else:
                    raise NotImplementedError("code should not be reached!")
            else:
                raise NotImplementedError()

        all_hidden = torch.zeros(size=o_src_shape, dtype=indata._t.dtype)
        for i, seq_data in _gen_sequence(
            indata._t, gru.options.direction, seq_len, gru.options.batch_first
        ):
            sg_inference = SubgraphInference(
                model_dict=self._model_dict,
                weight_dict=self._weight_dict,
                activation_tracer=self.activation_tracer,
                subgraph=gru_sg,
                save_all_outputs=False,
                device=self.device,
                compare_values=False,
                use_value_dict_data_for_next_input=False,
            )
            sg_inference.add_input_data(inact_h.name, hidden)
            sg_inference.add_input_data(inact_x.name, _wrap(seq_data))
            sg_inference.run_inference(
                inference_name=f"{gru.name}({i + 1}/{all_seq_len})"
            )

            hidden = sg_inference.get_output_tensor(gru.options.hidden_state_name)
            all_hidden[:, :, i : i + 1, :] = hidden._t

        ret = {"o": _wrap(all_hidden), "h": hidden}
        # return tuple(ret[x] for x in lstm.options.output_mask)
        return tuple(ret[x] for x in "oh")

    def _run_op_inference(
        self,
        op: Operator,
        in_acts: List[ActivationSpec],
        out_acts: List[ActivationSpec],
        in_data: List[WrappedTensor],
    ):
        if op.layertype == LayerType.KVCacheInput:
            value = self._value_dict[op.output_value_reference]
            out_data = WrappedTensor(value, value.dtype, DataFormat.UNKNOWN)
            return out_data

        if op.layertype == LayerType.StatefulLSTMWrapper:
            lstm_sg = self._model_dict.get_subgraph_by_name(op.options.subgraph)
            if lstm_sg is None:
                raise Exception(f"subgraph:`{op.options.subgraph}` not found!")
            return self._run_stateful_lstm_wrapper(
                op, lstm_sg, in_acts, out_acts, in_data
            )
        elif op.layertype == LayerType.StatefulRNNWrapper:
            rnn_sg = self._model_dict.get_subgraph_by_name(op.options.subgraph)
            if rnn_sg is None:
                raise Exception(f"subgraph:`{op.options.subgraph}` not found!")
            return self._run_stateful_rnn_wrapper(
                op, rnn_sg, in_acts, out_acts, in_data
            )
        elif op.layertype == LayerType.StatefulGRUWrapper:
            gru_sg = self._model_dict.get_subgraph_by_name(op.options.subgraph)
            if gru_sg is None:
                raise Exception(f"subgraph:`{op.options.subgraph}` not found!")
            return self._run_stateful_gru_wrapper(
                op, gru_sg, in_acts, out_acts, in_data
            )
        kw = self._get_kwargs(op)

        layer_inference = OperatorInference(
            op.options,
            layer_name=op.name,
            inputs=in_acts,
            outputs=out_acts,
            device=self.device,
            is_npu=not op.unsupported,
            subgraph=self._subgraph,
            weight_dict=self._weight_dict,
            quantizer_save=self._quantizer_save,
            **kw,
        )
        return layer_inference(in_data)

    def _add_to_inference_output_value_dict(
        self, out_acts: List[ActivationSpec], out_data: List
    ):
        for oa, od in zip(out_acts, out_data):
            self._inference_output_value_dict.add(oa.name, od, od.dataformat)

    def _compare_output_value(
        self, op: Operator, out_acts, out_data, output_value_reference
    ):
        replaced_od = []
        for oa, od, oref in zip(out_acts, out_data, output_value_reference):
            err_dct = {
                "subgraph": self._subgraph.idx,
                "layertype": op.layertype.name,
                "opname": op.name,
                "outact": oa.name,
                "has_ref_value": bool(oref),
            }
            if od._t.dtype == torch.bfloat16:
                val = od._t.float().cpu().detach().numpy()
            else:
                val = od._t.cpu().detach().numpy()
            ref = self._value_dict.get_value(oref)
            if isinstance(ref, ValueWrapper):
                ref = ref.value
            if isinstance(ref, torch.Tensor):
                if ref.dtype == torch.bfloat16:
                    ref = ref.to(torch.float32)
                ref = ref.cpu().detach().numpy()

            if numpy.isnan(ref).any():
                return None

            if _can_align_by_squeeze_transpose(ref, val):
                best_error_result = self._best_alignment_all(ref, val, _compute_error)
            else:
                return None  # TODO when outact data are reshaped ref: (1,20,20,300), val: (1,300,400,1)
            err_res = best_error_result[-1]
            replaced_value = best_error_result[0]
            replaced_od.append(
                WrappedTensor(torch.tensor(replaced_value), str(replaced_value.dtype))
            )
            err_dct.update(err_res)
            self.op_inference_result.append(OpInferenceResult(**err_dct))

        return replaced_od

    def _get_output_value_reference(self, op, out_acts):
        outact_names = [act.name for act in out_acts]
        if set(outact_names).issubset(set(self.activation_tracer.act_trace.keys())):
            if all(
                isinstance(
                    self.activation_tracer.act_trace[name], ActTraceT0
                )  # traced original activation
                for name in outact_names
            ):
                origin_names = [
                    self.activation_tracer.act_trace[name].name for name in outact_names
                ]
                for outact_name, org_name in zip(outact_names, origin_names):
                    if (
                        self.inverted_tracer[org_name][-1] != outact_name
                    ):  # only considering final transformed activation from original activation
                        return None
                return origin_names

        return None

    def _set_output_value(self, op, out_acts: List[ActivationSpec], out_data: List):
        check_dtype = op.layertype != LayerType.Floor
        for oa, od in zip(out_acts, out_data):
            validate_dtype_and_shape(oa, od, check_dtype)
            self._output_tensors[oa.name] = od.to(self.device).to(
                to_torch_dtype(oa.dtype)
            )

    def run_inference(self, inference_name=None, use_subgraph_operator_order=False):
        if inference_name is None:
            print(f"run inference: subgraph[{self._subgraph.name}]")
        else:
            print(f"run inference: {inference_name}")

        exec_queue = collections.deque()
        if use_subgraph_operator_order:
            for op in self._subgraph.operators:
                exec_queue.append(op)
        else:
            for act in self._subgraph.input_activations():
                if act.producer_op is not None:
                    exec_queue.append(act.producer_op)
                else:
                    exec_queue.extend(act.consumer_ops)
            for op in self._subgraph.operators:
                if op.layertype in (
                    LayerType.InputConstant,
                    LayerType.AttentionMaskInput,
                    LayerType.KVCacheInput,
                ):
                    exec_queue.append(op)

        self.op_inference_result = []
        visited = set()

        op_act_names = [op.name for op in self._subgraph.operators] + [
            act.name for act in self._subgraph.activations
        ]

        def ts_memsize(ts):
            return ts.numel() * ts.element_size()

        cache_size = 0
        cnt = 0
        # f = open('/data01/resust.txt', 'w')
        while exec_queue:
            op: Operator = exec_queue.popleft()
            # print(cnt, op.name)
            cnt += 1
            if op.name in visited:
                continue
            # print(f"cache_size={cache_size / (1024**2):.2f} MB, opname={op.name}")
            in_acts = [self._subgraph.activations[x] for x in op.options.inputs]
            out_acts = [self._subgraph.activations[x] for x in op.options.outputs]
            in_data = self._get_op_input_data(in_acts, op)

            if len(in_acts) > len(in_data):
                continue
            visited.add(op.name)

            if self._clear_output_cache:
                for in_act in in_acts:
                    self._input_use_cnt[in_act.name] -= 1
                    if self._input_use_cnt[in_act.name] < 1:
                        if in_act.name in self._output_tensors:
                            cache_size -= ts_memsize(
                                self._output_tensors[in_act.name]._t
                            )
                            self._output_tensors.pop(in_act.name)

            try:
                out_data = self._run_op_inference(op, in_acts, out_acts, in_data)
            except Exception as e:
                print(
                    f"Failed to run layer inference. layer_name={op.name}, inputs={in_acts}"
                )
                raise e
            if len(out_acts) == 1 and not isinstance(out_data, (list, tuple)):
                out_data = (out_data,)

            # instancenormalization with num_features=1 makes a lot of shape ambiguity.
            if op.layertype != LayerType.InstanceNormalization:
                if self._save_all_outputs:
                    if (
                        op.layertype == LayerType.Concatenate
                        and not op.options.input_index
                        and not op.unsupported
                    ):
                        pass
                    else:
                        self._add_to_inference_output_value_dict(out_acts, out_data)

                if self.activation_tracer is not None:
                    inverted_tracer = defaultdict(list)
                    for a, b in self.activation_tracer.act_trace.items():
                        inverted_tracer[b.name].append(
                            a
                        )  # original_name: [actname1, actname2]
                    self.inverted_tracer = dict(inverted_tracer)
                    for key, values in self.inverted_tracer.items():
                        self.inverted_tracer[key] = [
                            v for v in values if v in op_act_names
                        ]  # Filtering out unused names
                    self.inverted_tracer = {
                        key: value
                        for key, value in self.inverted_tracer.items()
                        if value
                    }  # Filtering out empty cases
                    ovalue_ref = self._get_output_value_reference(op, out_acts)
                    if ovalue_ref is not None:
                        if self._compare_values and all(
                            ovref in self._value_dict for ovref in ovalue_ref
                        ):
                            try:
                                replaced_od = self._compare_output_value(
                                    op, out_acts, out_data, ovalue_ref
                                )
                            except Exception as e:
                                print(
                                    f"Failed to check output error. layer_name={op.name}"
                                )
                                replaced_od = None

                            if self._use_value_dict_data_for_next_input and replaced_od:
                                for x in replaced_od:
                                    if x.dtype == "bfloat16":
                                        x._t = x._t.to(torch.float32)
                                out_data = replaced_od
                else:
                    if self._use_value_dict_data_for_next_input:
                        raise ValueError(
                            "To use the valuedict data as the input for the next node, an activation tracer is required."
                        )

            self._set_output_value(op, out_acts, out_data)
            for od in out_data:
                cache_size += ts_memsize(od._t)

            if not use_subgraph_operator_order:
                if op.layertype != LayerType.Output:
                    for oact in out_acts:
                        for cop in oact.consumer_ops:
                            exec_queue.append(cop)

        SubgraphInference.run_count += 1

    def _best_alignment_all(self, a: numpy.ndarray, b: numpy.ndarray, A_func):
        a0 = numpy.squeeze(a)
        b0 = numpy.squeeze(b)
        k = a0.ndim

        best_val = float("inf")
        best_perm = None
        best_a = None
        best_res = None

        for perm in itertools.permutations(range(k)):
            if not all(a0.shape[perm[i]] == b0.shape[i] for i in range(k)):
                continue

            a_perm = numpy.transpose(a0, axes=perm)

            a_cand = a_perm
            for dim, size in enumerate(b.shape):
                if size == 1:
                    a_cand = numpy.expand_dims(a_cand, axis=dim)

            res = A_func(a_cand, b, eps=1e-12, atol=self.ATOL, rtol=self.RTOL)
            if res["all_close"]:
                return a_cand, b, perm, res
            else:
                val = res["max_diff"]
                if val < best_val:
                    best_val = val
                    best_perm = perm
                    best_a = a_cand
                    best_res = res

        return best_a, b, best_perm, best_res

    def _check_output_error(self, outdata, ref_val_name):
        if outdata._t.dtype == torch.bfloat16:
            val = outdata._t.float().cpu().detach().numpy()
        else:
            val = outdata._t.cpu().detach().numpy()
        ref = self._value_dict.get_value(ref_val_name)
        if isinstance(ref, ValueWrapper):
            ref = ref.value
        if isinstance(ref, torch.Tensor):
            if ref.dtype == torch.bfloat16:
                ref = ref.to(torch.float32)
            ref = ref.cpu().detach().numpy()
        if _can_align_by_squeeze_transpose(ref, val):
            best_error_result = self._best_alignment_all(ref, val, _compute_error)
            return best_error_result[-1]

        return None


def match_two_tensor_transpose(val, ref):
    if sorted(ref.shape) != sorted(val.shape):
        raise ValueError("Tensors have incompatible shapes and cannot be made equal.")

    for perm in permutations(range(len(val.shape))):
        trans_val = numpy.transpose(val, perm)
        if trans_val.shape == ref.shape and numpy.allclose(
            trans_val, ref, rtol=1e-05, atol=1e-06
        ):
            return trans_val, ref

    return val, ref


def rpd(ref, val, eps=1e-12):
    # relative percent difference
    return 2.0 * ((ref - val) / numpy.maximum(eps, (numpy.abs(ref) + numpy.abs(val))))


def abs_rel_err(ref, val, eps=1e-12):
    return numpy.abs(ref - val) / numpy.maximum(eps, (numpy.abs(ref)))


def mape(ref, val, eps=1e-12):
    v = 100.0 * numpy.mean(
        numpy.abs((ref - val) / numpy.maximum(eps, (numpy.abs(ref))))
    )
    return float(v)


def smallvaluewarning(ref, thres=1e-5):
    if numpy.abs(ref).mean() < thres:
        print(
            f"The reference values are too small, with a mean value of {numpy.abs(ref).mean()}. Sometimes it shows a prediction error, even though the operation result is correct."
        )


def masked_err(ref, val, thres, err_fn):
    mask = numpy.abs(ref) < thres
    masked_ref = numpy.ma.masked_array(ref, mask)
    masked_val = numpy.ma.masked_array(val, mask)
    return err_fn(masked_ref, masked_val, thres)


def allclose(ref, val, atol=1e-6, rtol=1e-5):
    if isinstance(ref, torch.Tensor) and ref.dtype == torch.bfloat16:
        ref = ref.to(torch.float32).cpu().numpy()
    return numpy.allclose(ref, val, atol=atol, rtol=rtol) or numpy.allclose(
        val, ref, atol=atol, rtol=rtol
    )


def _compute_error(ref, val, eps=1e-12, atol=1e-7, rtol=1e-6):
    all_close_val = allclose(ref, val, atol=atol, rtol=rtol)
    dct = {"all_close": all_close_val}
    if all_close_val:
        return dct

    if ref.dtype == val.dtype == numpy.dtype("bool"):
        ref = ref.astype(int)
        val = val.astype(int)
    mape_val = masked_err(ref, val, eps, mape)
    dct["mape_masked"] = mape_val
    abs_rel_err_val = masked_err(ref, val, eps, abs_rel_err)
    rel_err_cnt = (abs_rel_err_val > 0.05).sum()
    all_elem_cnt = numpy.prod(val.shape)
    abs_diff = numpy.abs(ref - val)
    mx_rel_err = abs_rel_err_val.max()
    abs_rpd = numpy.abs(masked_err(ref, val, eps, rpd))
    # mx_coords = numpy.where(numpy.abs(mx_rel_err - abs_rel_err_val) < eps)
    # max_rel_error_masked_ref = ref[mx_coords]
    # max_rel_error_masked_val = val[mx_coords]

    dct["max_rel_error_masked"] = float(mx_rel_err)
    dct["abs_rpd_masked_max"] = float(abs_rpd.max())
    dct["abs_rpd_masked_mean"] = float(abs_rpd.mean())
    dct["max_diff"] = float(abs_diff.max())
    dct["hl_inference_max_value"] = float(numpy.abs(val).max())
    dct["source_inference_max_value"] = float(numpy.abs(ref).max())
    dct["rel_err_cnt"] = int(rel_err_cnt)
    dct["all_elem_cnt"] = int(all_elem_cnt)
    return dct


class MbltFileSubgraphModule(nn.Module):
    _get_inference_kwargs = SubgraphInference._get_kwargs

    def __init__(self, subgraph, weight_dict, device="cuda"):
        super().__init__()
        self._subgraph = subgraph
        self.device = device

        self.act_names = [a.name for a in self._subgraph.activations]
        self.act2idx = {name: i for i, name in enumerate(self.act_names)}

        self.input_names = [
            self._subgraph.activations[idx].name for idx in self._subgraph.inputs
        ]
        self.output_names = [
            self._subgraph.activations[idx].name for idx in self._subgraph.outputs
        ]
        self.idx_inputs = self._subgraph.inputs
        self.idx_outputs = self._subgraph.outputs

        ops = []
        for op in self._subgraph.operators:
            inacts = self._subgraph.inacts_from_op(op)
            outacts = self._subgraph.outacts_from_op(op)
            in_idx = [self.act2idx[a.name] for a in inacts]
            out_idx = [self.act2idx[a.name] for a in outacts]

            kw = self._get_inference_kwargs(op)
            layer = OperatorInferenceModule(
                op.options,
                layer_name=op.name,
                inputs=inacts,
                outputs=outacts,
                device=device,
                is_npu=not op.unsupported,
                subgraph=self._subgraph,
                weight_dict=weight_dict,
                quantizer_save=False,
                **kw,
            )
            ops.append((in_idx, out_idx, layer))

        self.ops = nn.ModuleList([l for _, _, l in ops])
        self.ops_io = [(iin, iout) for (iin, iout, _) in ops]

    def forward(self, inputs: Dict[str, torch.Tensor]):
        slots: List[Optional[torch.Tensor]] = [None] * len(self.act_names)

        for n in self.input_names:
            if n not in inputs:
                raise KeyError(f"missing required input: {n}")
            slots[self.act2idx[n]] = inputs[n]

        for (in_idx, out_idx), layer in zip(self.ops_io, self.ops):
            in_tensors = [slots[i] for i in in_idx]
            out = layer(in_tensors)
            for i, t in zip(out_idx, out):
                slots[i] = t

        self.intermediate_value = {
            name: value for name, value in zip(self.act_names, slots)
        }
        return tuple(slots[self.act2idx[n]] for n in self.output_names)

    @property
    def subgraph(self):
        return self._subgraph


class MbltFileModelModule(nn.Module):
    def __init__(
        self,
        mblt_path: Optional[Union[str, Path]] = None,
        model_dict: Optional["ModelDict"] = None,
        weight_dict: Optional["WeightDict"] = None,
        device: str = "cuda",
    ):
        super().__init__()

        if mblt_path is not None:
            model_dict, weight_dict = self._load_mblt_file(mblt_path)

        self._model_dict = model_dict
        self._weight_dict = weight_dict
        self.device = device
        self.to(self.device)
        self.intermediate_values = dict()

        modules = []
        for sg_idx in self._model_dict.graph_order:
            sg = self._model_dict.subgraphs[sg_idx]
            modules.append(
                MbltFileSubgraphModule(
                    subgraph=sg, weight_dict=self._weight_dict, device=self.device
                )
            )
        self.sg_modules = nn.ModuleList(modules)

        self.input_names = list(self._model_dict.inputs)
        self.output_names = list(self._model_dict.outputs)

    def _load_mblt_file(self, mblt_path: Union[str, Path]):
        p = Path(mblt_path)
        if p.suffix.lower() != ".mblt":
            raise ValueError(f"plase use .mblt file, mblt_path: {mblt_path}")

        header = SerializeMeta.get_header(mblt_path)
        md = SerializeMeta.get_model_dict(mblt_path, header=header)
        for sg in md.subgraphs:
            sg.update_op_act_connectivity()
            sg.remove_dangling_activations()
            sg.remove_dangling_tensors()
            sg.update_next_operator()
            sg.update_graph_in_out()
            sg.update_next_operator()
        wd = SerializeMeta.get_weight_dict(mblt_path, header=header)
        if wd.max_buffer_size == 0:
            raise ValueError(
                "Empty weight dict is detected, please use mblt file with weight"
            )
        return md, wd

    @property
    def model_dict(self):
        return self._model_dict

    @property
    def weight_dict(self):
        return self._weight_dict

    def forward(self, inputs: Union[Dict[str, torch.Tensor], List[torch.Tensor]]):
        inputs = self.set_inputs(inputs)
        self.intermediate_values.update(inputs)
        for sg in self.sg_modules:
            inputs = {name: self.intermediate_values[name] for name in sg.input_names}
            # I tried making it traceable to use torch.compile, but it isn’t working well properly. This part may need to be revised to use torch.compile()
            # Therefore, I introduce an intermediate value to simplify access.
            x = sg(inputs)
            self.intermediate_values.update(sg.intermediate_value)

        return self.get_output_values()

    def get_output_values(self):
        return {name: self.intermediate_values[name] for name in self.output_names}

    def set_inputs(
        self, inputs: Union[Dict[str, torch.Tensor], List[torch.Tensor], torch.Tensor]
    ):
        md_inact = []
        for sg_module in self.sg_modules:
            for act in sg_module.subgraph.activations:
                if act.name in self.input_names:
                    md_inact.append(act)
        if isinstance(inputs, dict):
            if set(act.name for act in md_inact) == set(inputs.keys()):
                return inputs
            else:
                raise ValueError(
                    f"model dict input names: {self.input_names}, but we got {list(inputs.keys())}"
                )

        elif isinstance(inputs, torch.Tensor):
            if len(self.input_names) != 1:
                raise ValueError(
                    "This model has one input, use one tensor for inference"
                )
            inact = md_inact[0]
            if tuple(inact.src_shape) == tuple(inputs.shape):
                return {inact.name: inputs}
            else:
                raise ValueError(
                    f"shape mismatch for single-tensor input: got {tuple(inputs.shape)}, "
                    f"expected {tuple(inact.src_shape)} for '{inact.name}'"
                )
        elif isinstance(inputs, (list, tuple)):
            shape2inact = {}
            for ia in md_inact:
                shp = tuple(ia.src_shape)
                if shp in shape2inact:
                    raise ValueError(
                        f"non-unique src_shape detected: {shp} maps to "
                        f"'{shape2inact[shp].name}' and '{ia.name}'"
                    )
                shape2inact[shp] = ia

            if len(inputs) != len(shape2inact):
                raise ValueError(
                    f"number of inputs ({len(inputs)}) does not match required inputs "
                    f"({len(shape2inact)}): expected shapes {list(shape2inact.keys())}"
                )

            input_dict = {}
            used_names = set()
            for t in inputs:
                if not torch.is_tensor(t):
                    raise TypeError(
                        f"list/tuple inputs must be torch Tensors, got {type(t)}"
                    )
                shp = tuple(t.shape)
                ia = shape2inact.get(shp)
                if ia is None:
                    candidates = ", ".join(str(s) for s in shape2inact.keys())
                    raise ValueError(
                        f"no input spec matches tensor shape {shp}. "
                        f"expected one of: {candidates}"
                    )
                if ia.name in used_names:
                    raise ValueError(
                        f"duplicate tensor for input '{ia.name}' (shape {shp})"
                    )
                input_dict[ia.name] = t
                used_names.add(ia.name)

            return input_dict
        else:
            raise TypeError(
                "inputs must be one of: Dict[str, Tensor], Tensor, List[Tensor], Tuple[Tensor, ...]"
            )


class ModelInference:
    def __init__(
        self,
        model_dict: ModelDict,
        weight_dict: WeightDict,
        value_dict: ValueDict,
        activation_tracer: ActivationTracer = None,
        save_all_outputs=True,
        inference_all_outputs_write_path="",
        compare_result_output_path=",",
    ) -> None:
        # todo: implement keep_all_outputs=False case.
        self.model_dict = model_dict
        self.weight_dict = weight_dict
        self.value_dict = value_dict
        self.activation_tracer = activation_tracer
        self.sg_output: Dict[int, Dict[str, Any]] = {}  # only subgraph last outputs
        self._subgraph_inferences: Dict[int, SubgraphInference] = {}
        self.sg_inference_result = {}

        self.MAPE_VAL_THRESHOLD = 5.0

        self.inference_value_dict = WeightDict()
        self.inference_tensors = {}
        self.subgraphs_outtensors = {}
        self.save_all_outputs = save_all_outputs
        self.inference_all_outputs_write_path = inference_all_outputs_write_path
        self.compare_result_output_path = compare_result_output_path

    def _run_subgraph_inference(
        self, sg: SubGraph, inputsg: InputSG, subgraph_state=None, **kwargs
    ):
        sg_inference = SubgraphInference(
            model_dict=self.model_dict,
            weight_dict=self.weight_dict,
            value_dict=self.value_dict,
            activation_tracer=self.activation_tracer,
            subgraph=sg,
            inputsg=inputsg,
            save_all_outputs=self.save_all_outputs,
            output_tensors=self.subgraphs_outtensors,
            is_npu=not sg.unsupported,
            subgraph_state=subgraph_state,
            **kwargs,
        )
        if sg.idx == -1:
            sg.idx = 0
        sg_inference.run_inference()
        self._subgraph_inferences[sg.idx] = sg_inference
        self.sg_output[sg.idx] = sg_inference.get_subgraph_outputs()
        self.sg_inference_result[sg.idx] = sg_inference.op_inference_result
        self.subgraphs_outtensors.update(sg_inference.get_output_tensors())

        if self.save_all_outputs:
            self._inference_info_store(sg_inference)

    def _inference_info_store(self, sg_inference: SubgraphInference):
        for tsname, wtensor in sg_inference._inference_output_value_dict.items():
            self.inference_value_dict.add_weight(
                tsname,
                wtensor._t.detach().to(torch.float32).cpu().numpy(),
                overwrite=True,
            )
            self.inference_tensors[tsname] = TensorSpec(
                name=tsname,
                dtype=str(wtensor._t.dtype).split(".")[-1],
                shape=tuple(wtensor.shape),
            )

    def save_result(self, compare_result_output_path):
        lst = []
        for sgidx in self.model_dict.graph_order:
            for r in self.sg_inference_result[sgidx]:
                dct = dataclasses.asdict(r)
                lst.append(dct)

        with open(compare_result_output_path, "w") as f:
            json.dump(lst, f)

        print(f"[parser] Comparison result written={compare_result_output_path}.")

    def _get_subgraph_inputs(self, sg: SubGraph):
        inputsg = InputSG(self.value_dict)
        inputsg.autoset_value(sg, self.weight_dict, self.subgraphs_outtensors)
        inputsg.validate_input(sg, self.weight_dict)
        return inputsg

    def run_inference(self, inference_save_targets=None, **kwargs):
        self.sg_output = {}
        self.writer = InferenceValueSerializeMeta(
            write_path=self.inference_all_outputs_write_path
        )
        init_model_state = kwargs.pop("init_model_state", None)
        # fixme: 여기서 특정한 키 값으로 사용하는거 좋지 않음.
        for sgidx in self.model_dict.graph_order:
            sg = self.model_dict.subgraphs[sgidx]
            sg_init_state = None
            if init_model_state is not None:
                if sg.name in init_model_state:
                    sg_init_state = init_model_state[sg.name]
            if sg_init_state:
                kv = sg_init_state.pop("past_key_values", None)
                dct = {}
                if _TRANSFORMERS_AVAILABLE and isinstance(
                    kv, transformers.DynamicCache
                ):
                    _seen_tokens = kv._seen_tokens
                elif kv is not None:
                    _seen_tokens = kv["_seen_tokens"]
                    if hasattr(sg, "key_cache_names"):
                        for idx, nm in enumerate(sg.key_cache_names):
                            if kv["key_cache"]:
                                dct[nm] = kv["key_cache"][idx]
                    if hasattr(sg, "value_cache_names"):
                        if kv["value_cache"]:
                            for idx, nm in enumerate(sg.value_cache_names):
                                dct[nm] = kv["value_cache"][idx]
                    if not dct:
                        dct = kv
                sg_init_state["past_key_values"] = dct

                conv_kv = sg_init_state.pop("conv_cache", None)

                if conv_kv is not None:
                    dct = {}
                    if hasattr(sg, "conv_cache_names"):
                        if conv_kv:
                            for idx, nm in enumerate(sg.conv_cache_names):
                                dct[nm] = conv_kv[idx]
                    sg_init_state["conv_cache"] = dct
                    sg_init_state["slice_len"] = (
                        30 if kwargs["target_model"] == "encoder" else 20
                    )
            inputsg = self._get_subgraph_inputs(sg)
            self._run_subgraph_inference(
                sg, inputsg, subgraph_state=sg_init_state, **kwargs
            )

        if self.compare_result_output_path:
            self.save_result(self.compare_result_output_path)

        if self.save_all_outputs:
            self._save_all_inference_outputs(inference_save_targets)

    def _save_all_inference_outputs(self, inference_save_targets=None):
        if set(self.inference_value_dict._weight_dict.keys()) != set(
            self.inference_tensors.keys()
        ):
            raise ValueError(
                "Weight dict in inference_value_dict and inference_tensors are different"
            )
        if inference_save_targets:
            tensor_names = list(self.inference_tensors.keys())
            for k in tensor_names:
                if k not in inference_save_targets:
                    self.inference_value_dict._weight_dict.pop(k)
                    self.inference_tensors.pop(k)

        self.inference_value_dict.compute_weight_buffer_info()
        for tp in self.inference_value_dict.weight_buffer_info:
            _, buff_start_idx, buff_offset = tp
            self.inference_tensors[tp[0]].buffer_idx = buff_start_idx
            self.inference_tensors[tp[0]].offset = buff_offset
        self.inference_value_dict._tensorspec = self.inference_tensors
        self.writer.serialize(self.inference_value_dict)

        with open(self.inference_all_outputs_write_path, "wb") as f:
            if isinstance(self.writer.b, bytes):
                f.write(self.writer.b)
            else:
                self.writer.b.write(f)
            print(
                f"inference_all_outputs_write_path:{self.inference_all_outputs_write_path}"
            )

    def get_large_error_desc(self, res: OpInferenceResult):
        if not res.has_ref_value or res.all_close:
            return f"[{res.layertype}] {res.opname}"
        if res.different_shape:
            return f"[{res.layertype}], name: {res.opname}\n  different_shape           : {res.different_shape}"
        if res.mape_masked <= self.MAPE_VAL_THRESHOLD:
            return f"[{res.layertype}], name: {res.opname}\n  mape(masked)              : {res.mape_masked}"
        return (
            f"[{res.layertype}], name: {res.opname}"
            f"\n  mape(masked)              : {res.mape_masked}"
            f"\n  max_rel_err(masked)       : {res.max_rel_error_masked}"
            f"\n  abs_rpd(masked)           : max={res.abs_rpd_masked_max}, mean={res.abs_rpd_masked_mean}"
            f"\n  Max Diff.                 : {res.max_diff}"
            f"\n  HL Inference Max Value    : {res.hl_inference_max_value}"
            f"\n  Source Inference Max Value: {res.source_inference_max_value}"
            f"\n  {res.rel_err_cnt / res.all_elem_cnt * 100.:.2f}% ({res.rel_err_cnt}/{res.all_elem_cnt}) of values has relative error > 5%."
        )

    def get_error_info(self):
        large_mape = {}
        diff_shape = {}
        for sgidx in self.model_dict.graph_order:
            large_mape[sgidx] = []
            diff_shape[sgidx] = []
            for r in self.sg_inference_result[sgidx]:
                if r.has_ref_value and not r.all_close:
                    if r.different_shape:
                        diff_shape[sgidx].append(r)
                    elif r.mape_masked > self.MAPE_VAL_THRESHOLD:
                        large_mape[sgidx].append(r)

        msg = []
        max_err_thres = 1e-5
        for sgidx in self.model_dict.graph_order:
            num_ops = len(self.model_dict.subgraphs[sgidx].operators)
            num_ref_vals = sum(r.has_ref_value for r in self.sg_inference_result[sgidx])
            content = f"subgraph={sgidx}, num_ops={num_ops}, compared={num_ref_vals}"
            large_mape_results = large_mape[sgidx]
            large_max_err_results = [
                r for r in large_mape_results if r.max_diff > max_err_thres
            ]
            num_diff_shape = len(diff_shape[sgidx])
            if num_ref_vals > 0:
                content += f", num_large_mape={len(large_mape_results)} ({len(large_mape_results) / num_ref_vals * 100:.2f}%)"
                content += f", num_max_err(>{max_err_thres})={len(large_max_err_results)} ({len(large_max_err_results) / num_ref_vals * 100:.2f}%)"
                content += f", num_diff_shape={num_diff_shape} ({num_diff_shape / num_ref_vals * 100:.2f}%)"
            msg.append(content)

        return large_mape, diff_shape, msg

    def check_error(self):
        large_mape, diff_shape, _ = self.get_error_info()
        occur_err = not all([err_list == [] for err_list in large_mape.values()])
        return occur_err

    def print_result(self):
        large_mape, diff_shape, msg = self.get_error_info()
        for sgidx in self.model_dict.graph_order:
            if large_mape[sgidx]:
                print(f"[large mape subgraph{sgidx}]")
                for r in large_mape[sgidx]:
                    print(self.get_large_error_desc(r) + "\n")
            if diff_shape[sgidx]:
                print(f"[different shape subgraph{sgidx}]")
                for r in diff_shape[sgidx]:
                    print(self.get_large_error_desc(r) + "\n")

        print("[Inference value compare result]")
        for m in msg:
            print("  " + m)

    @property
    def model_dict(self):
        return self._model_dict

    @model_dict.setter
    def model_dict(self, md):
        self._model_dict = md

    @property
    def weight_dict(self):
        return self._weight_dict

    @weight_dict.setter
    def weight_dict(self, wd):
        self._weight_dict = wd
