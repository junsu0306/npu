from typing import Dict

from qbcompiler.model_dict.common import SubGraph, LayerType, TensorShape, WeightDict
from qbcompiler.model_dict.common.subgraph_util import sort_operators
from qbcompiler.model_dict.inference.shape.infer_shape import infer_shape
from qbcompiler.logging import get_logger

logger = get_logger(__name__)


class GraphShapeInference:
    def __init__(self, subgraph: SubGraph, weight_dict: WeightDict):
        self.subgraph = subgraph
        self.weight_dict = weight_dict
        self.inferred_shapes = {}  # (output_activation, shape)
        self.input_shapes = None

    def do_inference(self, input_shapes: Dict):
        self.inferred_shapes = {}  # (output_activation, shape)
        self.input_shapes = input_shapes
        self.subgraph.update_op_act_connectivity()
        self.subgraph.remove_dangling_activations()
        self.subgraph.update_graph_in_out()
        sorted_ops = sort_operators(self.subgraph, False)
        for op in sorted_ops:
            if op.layertype == LayerType.Input:
                shape_out = self.input_shapes.get(op.name, None)
                if shape_out is None:
                    input_act = self.subgraph.activations[op.options.outputs[0]]
                    shape_out = input_act.get_act_src_shape()
                shape_out = TensorShape(shape_out)
            else:
                try:
                    input_shapes = tuple(
                        self.inferred_shapes[self.subgraph.activations[i]]
                        for i in op.options.inputs
                    )
                    shape_out = infer_shape(
                        op, self.subgraph, self.weight_dict, *input_shapes
                    )
                except Exception as e:
                    logger.info(
                        f"shape inference failed: {op.name}, type={op.layertype}. use existing output shape."
                    )
                    shape_out = tuple(
                        self.subgraph.activations[oidx].src_shape
                        for oidx in op.options.outputs
                    )
            if isinstance(shape_out, TensorShape):
                shape_out = (shape_out,)

            for oidx, shape in zip(op.options.outputs, shape_out):
                self.inferred_shapes[self.subgraph.activations[oidx]] = shape
