import copy
import dataclasses
import math
import os
from typing import Union, List

import msgpack
import numpy

from qbcompiler.model_dict.common import DataFormat, ActivationSpec, Operator
from qbcompiler.model_dict.common.buffer import NaiveBuffer, MmapBuffer
from qbcompiler.model_dict.common.dtypes import TensorIndex
from qbcompiler.model_dict.common.dtypes import uint8, uint64
from qbcompiler.model_dict.common.item_specs import DimValue, TensorSpec
from qbcompiler.model_dict.common.model_dict import ModelDict, WeightDict
from qbcompiler.model_dict.common.options import LayerOptions


class ChainedByteObj:
    def __init__(self, max_chunk_size=2**32):
        self.chunks: List[numpy.ndarray | bytes] = []
        self.max_chunk_size = max_chunk_size

    def write(self, file_obj):
        for chunk in self:
            file_obj.write(chunk)

    def _bsize(self, v: numpy.ndarray | bytes) -> int:
        if isinstance(v, numpy.ndarray):
            if len(v.shape) == 0:
                return numpy.dtype(v.dtype).itemsize
            return math.prod(map(int, v.shape)) * numpy.dtype(v.dtype).itemsize
        return len(bytes)

    def add(self, chunk: numpy.ndarray | bytes) -> None:
        if isinstance(chunk, numpy.ndarray):
            if self._bsize(chunk) > self.max_chunk_size:
                raise ValueError(
                    f"Each chunksize should not exceed {self.max_chunk_size} bytes."
                )
        elif isinstance(chunk, bytes):
            if len(chunk) > self.max_chunk_size:
                raise ValueError(
                    f"Each chunksize should not exceed {self.max_chunk_size} bytes."
                )
        else:
            raise ValueError(f"type={chunk}")

        self.chunks.append(chunk)

    def __bytes__(self):
        return b"".join(x if isinstance(x, bytes) else x.tobytes() for x in self.chunks)

    def __iter__(self):
        return iter(x if isinstance(x, bytes) else x.tobytes() for x in self.chunks)

    def __len__(self):
        return sum(self._bsize(chunk) for chunk in self.chunks)


def _is_dataclass_instance(obj):
    """Returns True if obj is an instance of a dataclass."""
    return hasattr(type(obj), "__dataclass_fields__")


def _asdict_kernel(obj):
    if isinstance(obj, DataFormat):
        return obj.name
    elif isinstance(obj, LayerOptions):
        dct = {
            field.name: _asdict_kernel(getattr(obj, field.name))
            for field in dataclasses.fields(obj)
        }
        # LayerOptions cannot be deserialzed without its concrete type.
        dct["type"] = obj.__class__.__name__
        return dct
    elif isinstance(obj, TensorIndex):
        return int(obj)
    elif numpy.issubdtype(type(obj), numpy.integer):
        return int(obj)
    elif numpy.issubdtype(type(obj), numpy.floating):
        # 일부 옵션이 여기로 들어오는 경우가 있음.
        return float(obj)
    elif isinstance(obj, DimValue):
        dct = {"value": obj.value, "dynamic": obj.dynamic}
        return dct
    elif isinstance(obj, ActivationSpec):
        keys = ("name", "dtype", "shape", "src_shape", "dataformat")
        return {key: _asdict_kernel(getattr(obj, key)) for key in keys}
    elif obj.__class__.__name__ == "ActivationSpecWithValue":
        keys = ("name", "dtype", "shape", "src_shape", "dataformat")
        return {key: _asdict_kernel(getattr(obj, key)) for key in keys}
    elif _is_dataclass_instance(obj):
        return {
            field.name: _asdict_kernel(getattr(obj, field.name))
            for field in dataclasses.fields(obj)
        }
    elif isinstance(obj, (tuple, list)):
        return type(obj)(_asdict_kernel(v) for v in obj)
    elif isinstance(obj, dict):
        return {_asdict_kernel(k): _asdict_kernel(v) for k, v in obj.items()}
    elif isinstance(obj, Operator):
        keys = obj.serialize_keys
        dct = {}
        for k, v in vars(obj).items():
            if k not in keys:
                continue
            k = keys[k]
            dct[k] = _asdict_kernel(v)
        return dct
    elif hasattr(obj, "__dict__"):
        return {k: _asdict_kernel(v) for k, v in vars(obj).items()}
    else:
        return copy.deepcopy(obj)


def asdict(obj):
    return _asdict_kernel(obj)


class SerializeMeta:
    """
    model_dict_size(8 bytes): denotes the size of the model_dict.
    mode(1 byte): buffer read mode.
    max_buffer_size(8 bytes): denotes the maximum size of a single buffer.
    last_buffer_size(8 bytes): denotes the size of the last buffer.
    num_buffers(8 bytes): denotes the number of buffers.
    model_dict(model_dict_size bytes)
    weights(* bytes)

    |weight_buffers(*)|model_dict(model_dict_size)|num_buffers(8)|last_buffer_size(8)|max_buffer_size(8)|mode(1)|model_dict_size(8)|
    """

    HEADERS = (
        ("num_buffers", uint64),
        ("last_buffer_size", uint64),
        ("max_buffer_size", uint64),
        ("mode", uint8),
        ("model_dict_size", uint64),
    )

    def __init__(
        self,
        write_path="",
        write_to_file=False,
        num_buffers=0,
        last_buffer_size=0,
        max_buffer_size=0,
        mode=1,
        model_dict_size=0,
    ):
        if write_to_file and not write_path:
            raise ValueError(f"write_to_file is set but write_path is empty.")

        self.num_buffers = num_buffers
        self.last_buffer_size = last_buffer_size
        self.max_buffer_size = max_buffer_size
        self.mode = mode
        self.model_dict_size = model_dict_size
        self._b: bytes | ChainedByteObj = None
        self.write_path = write_path
        self.write_to_file = write_to_file

    def serialize(
        self, model_dict: ModelDict, weight_dict: WeightDict, ignore_weight=False
    ):
        if self.write_to_file:
            raise NotImplementedError(f"write_to_file not implemented")

        # filter unused weight values.
        wd = {}
        for sg in model_dict.subgraphs:
            for ts in sg.tensors:
                wd[ts.name] = weight_dict.get_weight_by_name(ts.name)
        weight_dict = WeightDict()
        weight_dict._weight_dict = wd

        if not ignore_weight:
            self._calculate_buff_info(weight_dict, model_dict)
            self.max_buffer_size = weight_dict.max_buffer_size
            self.num_buffers = weight_dict.num_buffers
            self.last_buffer_size = weight_dict.last_buffer_size
            self._write_weight_dict(weight_dict)
            if weight_dict.num_buffers > 1:
                self.mode = 1
        self._write_model_dict(model_dict)
        self._write_header()
        return self._b

    def _calculate_buff_info(self, weight_dict: WeightDict, model_dict: ModelDict):
        weight_dict.compute_weight_buffer_info()
        weight_buff_info = {}
        for tp in weight_dict.weight_buffer_info:
            weight_buff_info[tp[0]] = tp

        for sg in model_dict.subgraphs:
            for ts in sg.tensors:
                if ts.name not in weight_buff_info:
                    raise ValueError(f"weight not exists:{ts.name}")
                _, buff_start_idx, buff_offset = weight_buff_info[ts.name]
                ts.buffer_idx = buff_start_idx
                ts.offset = buff_offset

    def _write_weight_dict(self, weight_dict: WeightDict):
        if self._b is None:
            self._b = b""
        if self.num_buffers > 1:
            self._b = ChainedByteObj(max_chunk_size=weight_dict.max_buffer_size)
            for winfo in weight_dict.weight_buffer_info:
                wname, buff_start_idx, buff_offset = winfo
                self._b.add(weight_dict.get_weight_by_name(wname))
        else:
            self._b += b"".join(
                weight_dict.get_weight_by_name(winfo[0]).tobytes()
                for winfo in weight_dict.weight_buffer_info
            )

    def _write_model_dict(self, model_dict: ModelDict):
        sg_delete_attrs = ["_all_activation_names", "_all_tensor_names"]
        op_delete_attrs = [
            "valid",
            "subgraph_idx",
            "idx",
            "op_transform_generated_reshape",
        ]
        for sg in model_dict.subgraphs:
            for attr in sg_delete_attrs:
                if hasattr(sg, attr):
                    delattr(sg, attr)
            for op in sg.operators:
                for attr in op_delete_attrs:
                    if hasattr(op, attr):
                        delattr(op, attr)

        model_json = {
            k: asdict(v)
            for k, v in vars(model_dict).items()
            if k not in ("weight_dict", "activation_trace", "init_model_state")
        }
        b_model_dict = msgpack.packb(model_json)
        self.model_dict_size = len(b_model_dict)
        if self._b is None:
            self._b = b""

        if isinstance(self._b, bytes):
            self._b += b_model_dict
        elif isinstance(self._b, ChainedByteObj):
            self._b.add(b_model_dict)
        else:
            raise Exception(type(self._b))

    def _write_header(self):
        b_header = b"".join(h[1](self.__dict__[h[0]]).tobytes() for h in self.HEADERS)
        if isinstance(self._b, bytes):
            self._b += b_header
        elif isinstance(self._b, ChainedByteObj):
            self._b.add(b_header)
        else:
            raise Exception

    @staticmethod
    def get_weight_dict(path_to_file, header: "SerializeMeta"):
        md = SerializeMeta.get_model_dict(path_to_file, header)
        if header.mode == 0:
            buffer = NaiveBuffer(
                buffer_file_path=path_to_file,
                max_buffer_size=header.max_buffer_size,
                last_buffer_size=header.last_buffer_size,
                num_buffers=header.num_buffers,
            )
        elif header.mode == 1:
            buffer = MmapBuffer(
                buffer_file_path=path_to_file,
                max_buffer_size=header.max_buffer_size,
                last_buffer_size=header.last_buffer_size,
                num_buffers=header.num_buffers,
            )
        else:
            raise NotImplementedError(f"Unsupported mode {header.mode}")
        wd = WeightDict(max_buffer_size=header.max_buffer_size, buffer_mode=header.mode)
        wd.set_buffer(buffer)

        for sg in md.subgraphs:
            for ts in sg.tensors:
                wd._tensorspec[ts.name] = ts
        return wd

    @staticmethod
    def get_model_dict(path_to_file, header):
        with open(path_to_file, "rb") as f:
            hlen = SerializeMeta.header_len()
            mdsize = header.model_dict_size
            f.seek(-(hlen + mdsize), os.SEEK_END)
            return ModelDict.from_dict(msgpack.unpackb(f.read(mdsize)))

    @staticmethod
    def get_buffer(path_to_file, header):
        if header.mode == 0:
            buffer = NaiveBuffer(
                path_to_file,
                header.max_buffer_size,
                header.last_buffer_size,
                header.num_buffers,
            )
        else:
            buffer = MmapBuffer(
                path_to_file,
                header.max_buffer_size,
                header.last_buffer_size,
                header.num_buffers,
            )
        return buffer

    @staticmethod
    def get_header(path_to_file):
        with open(path_to_file, "rb") as f:
            f.seek(-SerializeMeta.header_len(), os.SEEK_END)
            barr = f.read()
            return SerializeMeta.decode_buffer_header(barr)

    @staticmethod
    def header_len():
        return sum(int(numpy.dtype(h[1]).itemsize) for h in SerializeMeta.HEADERS)

    @staticmethod
    def decode_buffer_header(barr: Union[bytearray, bytes]):
        hbytes = barr[-SerializeMeta.header_len() :]
        header = {}
        pos = 0
        for h in SerializeMeta.HEADERS:
            rsize = int(numpy.dtype(h[1]).itemsize)
            header[h[0]] = int(numpy.frombuffer(hbytes[pos : pos + rsize], dtype=h[1]))
            pos += rsize

        return SerializeMeta(**header)


class InferenceValueSerializeMeta:
    """
    tensorspecs_size(8 bytes): denotes the size of the metadata.
    mode(1 byte): buffer read mode.
    max_buffer_size(8 bytes): denotes the maximum size of a single buffer.
    last_buffer_size(8 bytes): denotes the size of the last buffer.
    num_buffers(8 bytes): denotes the number of buffers.
    tensorspecs(tensorspecs_size bytes)
    weights(* bytes)

    |weight_buffers(*)|tensorspecs(tensorspecs_size bytes)|num_buffers(8)|last_buffer_size(8)|max_buffer_size(8)|mode(1)|tensorspecs_size(8)|
    """

    HEADERS = (
        ("num_buffers", numpy.uint64),
        ("last_buffer_size", numpy.uint64),
        ("max_buffer_size", numpy.uint64),
        ("mode", numpy.uint8),
        ("tensorspecs_size", numpy.uint64),
    )

    def __init__(
        self,
        write_path="",
        num_buffers=0,
        last_buffer_size=0,
        max_buffer_size=0,
        mode=1,
        tensorspecs_size=0,
    ):
        if not write_path:
            raise ValueError(f"write_path is empty.")

        self.num_buffers = num_buffers
        self.last_buffer_size = last_buffer_size
        self.max_buffer_size = max_buffer_size
        self.mode = mode
        self.tensorspecs_size = tensorspecs_size
        self._b = None
        self.write_path = write_path

    @staticmethod
    def header_len():
        return sum(
            int(numpy.dtype(h[1]).itemsize) for h in InferenceValueSerializeMeta.HEADERS
        )

    @staticmethod
    def get_header(path_to_file):
        with open(path_to_file, "rb") as f:
            f.seek(-InferenceValueSerializeMeta.header_len(), os.SEEK_END)
            barr = f.read()
            return InferenceValueSerializeMeta.decode_buffer_header(barr)

    @staticmethod
    def decode_buffer_header(barr: Union[bytearray, bytes]):
        hbytes = barr[-InferenceValueSerializeMeta.header_len() :]
        header = {}
        pos = 0
        for h in InferenceValueSerializeMeta.HEADERS:
            rsize = int(numpy.dtype(h[1]).itemsize)
            header[h[0]] = int(numpy.frombuffer(hbytes[pos : pos + rsize], dtype=h[1]))
            pos += rsize

        return InferenceValueSerializeMeta(**header)

    @staticmethod
    def get_weight_dict(path_to_file, header: "InferenceValueSerializeMeta"):
        with open(path_to_file, "rb") as f:
            hlen = InferenceValueSerializeMeta.header_len()
            ts_size = header.tensorspecs_size
            f.seek(-(hlen + ts_size), os.SEEK_END)
            dct = msgpack.unpackb(f.read(ts_size))
            tensorspecs = []
            for v in dct["values"]:
                tensorspecs.append(TensorSpec(**v))

        if header.mode == 0:
            buffer = NaiveBuffer(
                buffer_file_path=path_to_file,
                max_buffer_size=header.max_buffer_size,
                last_buffer_size=header.last_buffer_size,
                num_buffers=header.num_buffers,
            )
        elif header.mode == 1:
            buffer = MmapBuffer(
                buffer_file_path=path_to_file,
                max_buffer_size=header.max_buffer_size,
                last_buffer_size=header.last_buffer_size,
                num_buffers=header.num_buffers,
            )
        else:
            raise NotImplementedError(f"Unsupported mode {header.mode}")

        wd = WeightDict(max_buffer_size=header.max_buffer_size, buffer_mode=header.mode)
        wd.set_buffer(buffer)

        for ts in tensorspecs:
            wd._tensorspec[ts.name] = ts
        return wd

    def serialize(self, inference_value_dict: WeightDict):
        self.max_buffer_size = inference_value_dict.max_buffer_size
        self.mode = inference_value_dict.buffer_mode
        self.num_buffers = inference_value_dict.num_buffers
        self.last_buffer_size = inference_value_dict.last_buffer_size
        if inference_value_dict.num_buffers > 1:
            self.mode = 1

        if self._b is None:
            self._b = b""
        if self.num_buffers > 1:
            self._b = ChainedByteObj(
                max_chunk_size=inference_value_dict.max_buffer_size
            )
            for winfo in inference_value_dict.weight_buffer_info:
                wname, buf_start_idx, buff_offset = winfo
                self._b.add(inference_value_dict.get_weight_by_name(wname))
        else:
            self._b += b"".join(
                inference_value_dict.get_weight_by_name(winfo[0]).tobytes()
                for winfo in inference_value_dict.weight_buffer_info
            )

        values_json = {
            "values": [x.asdict() for x in inference_value_dict._tensorspec.values()]
        }
        for item in values_json["values"]:
            item["shape"] = tuple(int(x) for x in item["shape"])
        b_values_json = msgpack.packb(values_json)
        self.tensorspecs_size = len(b_values_json)

        header_b = b""
        for h in self.HEADERS:
            header_b += h[1](self.__dict__[h[0]]).tobytes()

        if isinstance(self._b, bytes):
            self._b += b_values_json
            self._b += header_b
        else:
            self._b.add(b_values_json)
            self._b.add(header_b)

        return self._b

    @property
    def b(self):
        return self._b


def load_mblt_model(path_to_mblt, load_weight=True):
    header = SerializeMeta.get_header(path_to_mblt)
    md = SerializeMeta.get_model_dict(path_to_mblt, header=header)
    for sg in md.subgraphs:
        sg.update_op_act_connectivity()
        sg.remove_dangling_activations()
        sg.remove_dangling_tensors()
        sg.update_next_operator()
        sg.update_graph_in_out()
        sg.update_next_operator()
    if load_weight:
        wd = SerializeMeta.get_weight_dict(path_to_mblt, header=header)
    else:
        wd = None
    return md, wd
