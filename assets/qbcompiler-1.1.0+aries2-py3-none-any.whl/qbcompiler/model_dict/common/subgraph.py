import collections
import dataclasses
import itertools
import sys
from collections import deque
from typing import List

from .dataformat import DataFormat
from .device import DeviceType
from .dtypes import TensorIndex, int64
from .item_specs import TensorSpec, ActivationSpec
from .operator import Operator
from .options import LayerType
from .common_utils import timeout


class SubGraph:
    def __init__(
        self,
        idx: int = -1,
        name: str = "",
        operators: List[Operator] = None,
        tensors: List[TensorSpec] = None,
        inputs: List[int64] = None,
        outputs: List[int64] = None,
        activations: List[ActivationSpec] = None,
        unsupported: bool = True,
        stateful: bool = False,
        **kwargs,
    ) -> None:
        self.idx = idx
        self.name: str = name
        self.operators: List[Operator] = operators
        self.tensors: List[TensorSpec] = tensors
        self.inputs = inputs
        self.outputs = outputs
        self.activations = activations
        self.unsupported: bool = unsupported
        self.stateful: bool = stateful

        self._all_activation_names = {}
        self._all_tensor_names = {}

    def __repr__(self):
        return f"{self.name}, idx={self.idx}, unsupported={self.unsupported}, num_ops={len(self.operators)}"

    def get_act_idx(self, act_name: str):
        return self._all_activation_names[act_name]

    def get_act_indices(self, names: List[str]):
        return [
            idx
            for name in names
            for idx, act in enumerate(self.activations)
            if act.name == name
        ]

    def init_all_act_tensor_names(self):
        self._all_activation_names.clear()
        for idx, activation in enumerate(self.activations):
            self._all_activation_names[activation.name] = idx
        if len(self._all_activation_names) != len(self.activations):
            cnt = set()
            for a in self.activations:
                if a.name not in cnt:
                    cnt.add(a.name)
                else:
                    raise Exception(f"duplicate activation name:{a.name}")
            raise Exception("len(self._all_activation_names) != len(self.activations)")

        self._all_tensor_names.clear()
        for idx, tensor in enumerate(self.tensors):
            self._all_tensor_names[tensor.name] = idx
        if len(self._all_tensor_names) != len(self.tensors):
            raise Exception(
                f"len(self._all_tensor_names){len(self._all_tensor_names)} != len(self.tensors){len(self.tensors)}"
            )

    def update_op_act_connectivity(self):
        for act in self.activations:
            if act is None:
                continue
            act.consumer_ops.clear()
        for op in self.operators:
            if op.layertype != LayerType.Output:
                for oidx in op.options.outputs:
                    self.activations[oidx].producer_op = op
            if op.layertype not in (
                LayerType.Input,
                LayerType.AttentionMaskInput,
                LayerType.KVCacheInput,
            ):
                for iidx in op.options.inputs:
                    self.activations[iidx].consumer_ops.append(op)

    def get_valid_act_name(self, candidate: str):
        i = 0
        while True:
            nc = candidate + "_" + str(i)
            if nc not in self._all_activation_names:
                return nc
            i += 1

    def get_valid_ts_name(self, candidate: str):
        i = 0
        while True:
            nc = candidate + "_" + str(i)
            if nc not in self._all_tensor_names:
                return nc
            i += 1

    def is_duplicate_act_name(self, candidate: str):
        return candidate in self._all_activation_names

    def is_duplicate_ts_name(self, candidate: str):
        return candidate in self._all_tensor_names

    @staticmethod
    def from_dict(data):
        from types import SimpleNamespace

        ns = SimpleNamespace(**data)
        return SubGraph(
            ns.idx,
            name=ns.name,
            operators=[Operator(**x) for x in ns.operators],
            tensors=[TensorSpec(**x) for x in ns.tensors],
            inputs=ns.inputs,
            outputs=ns.outputs,
            activations=[ActivationSpec.from_dict(x) for x in ns.activations],
            unsupported=ns.unsupported,
        )

    def get_op_inputs(self, op: Operator):
        return tuple(self.activations[i] for i in op.options.inputs)

    def input_activations(self):
        return [self.activations[x] for x in self.inputs]

    def output_activations(self):
        return [self.activations[x] for x in self.outputs]

    def _get_outact_to_op(self):
        dct = {}
        for op_idx, op in enumerate(self.operators):
            for oidx in op.outputs:
                dct[oidx] = op_idx
        return dct

    def update_next_operator(self):
        map_ = {}
        map_output = {}
        for idx, op in enumerate(self.operators):
            if op.layertype == LayerType.Output:
                map_output[op.name] = idx
            else:
                map_[op.name] = idx
        for op in self.operators:
            op.next_operators = []
            if op.layertype == LayerType.Output:
                continue
            for oidx in op.options.outputs:
                for cop in self.activations[oidx].consumer_ops:
                    if cop.layertype == LayerType.Output:
                        op.next_operators.append(map_output[cop.name])
                    else:
                        op.next_operators.append(map_[cop.name])

    def fill_supported_actshape(self):
        if not self.unsupported:
            # to fill the npu shape (some special operation have unkown dataformat)
            for act in self.activations:
                b, h, w, c = act.get_act_src_shape()
                act.shape = (h, w, c)

    def opname_to_outactname(self):
        for op in self.operators:
            op.name = self.activations[op.options.outputs[0]].name
            if len(op.options.outputs) != 1:
                print(f"{op.name} have multiple output activations")

    def operators_rearrange(self):
        visit = set()
        q = deque(self.operators)
        op_list = []
        op_names = set([op.name for op in self.operators])
        while q:
            op = q.popleft()
            input_names = set()
            if op.name in visit:
                if op.layertype == LayerType.Output:
                    op_list.append(op)
                continue
            for iidx in op.options.inputs:
                input_names.add(self.activations[iidx].name)
            if not input_names.issubset(op_names):
                raise ValueError(
                    f"input name: {input_names} is not included in operator names"
                )
            if input_names.issubset(visit):
                op_list.append(op)
                visit.add(op.name)
            elif op.layertype == (
                LayerType.Input,
                LayerType.AttentionMaskInput,
                LayerType.KVCacheInput,
                LayerType.InputConstant,
            ):
                op_list.append(op)
                visit.add(op.name)
            else:
                notvisit = input_names - visit
                q.extendleft([op for op in self.operators if op.name in notvisit])
        if len(self.operators) != len(op_list):
            raise ValueError(
                f"the length of operators and sorted op_list are different"
            )
        self.operators = op_list

    def update_actiavtion_shape_info(self):
        for act in self.activations:
            if act.src_dim == 4 and act.src_shape[0] == 1:
                if act.shape == (-1, -1, -1):
                    act.shape = (act.src_shape[1], act.src_shape[2], act.src_shape[3])
                else:
                    pass
            if act.src_shape == (-1, -1, -1):
                act.src_shape = (1, act.shape[0], act.shape[1], act.shape[2])

        if not self.unsupported:
            for op in self.operators:
                if not op.unsupported:
                    for iidx in op.options.inputs:
                        inact = self.activations[iidx]
                        inact.dataformat = DataFormat.NHWC
                        inact.shape = inact.get_act_src_shape()[1:]

    def sg_supported(self):
        self.unsupported = any([op.unsupported for op in self.operators])

    def check_activations_dataformat(self, device_type: DeviceType):
        if self.unsupported:
            return
        if device_type == DeviceType.Aries:
            for act in self.activations:
                if act.dataformat != DataFormat.NHWC:
                    raise Exception(f"activation is not in NHWC: {act.name}")

    def remove_dangling_tensors(self):
        tensors_to_idx = dict()
        for op in self.operators:
            for _, tidx in op.options.iter_tensorindex():
                if tidx == -1:
                    continue
                tensors_to_idx[self.tensors[tidx].name] = None

        _tensors = []
        for ts in self.tensors:
            if ts is None:
                continue
            if ts.name in tensors_to_idx:
                tensors_to_idx[ts.name] = len(_tensors)
                _tensors.append(ts)

        for k, v in tensors_to_idx.items():
            if v is None:
                raise Exception(
                    f"{v} is used in some operator but not exists in subgraph.tensors"
                )

        for op in self.operators:
            ts_dct = {}
            for field_name, tidx in op.options.iter_tensorindex():
                if tidx == -1:
                    continue
                ts_dct[field_name] = tensors_to_idx[self.tensors[tidx].name]
            if ts_dct:
                new_opt = dataclasses.replace(op.options, **ts_dct)
                op.options = new_opt
        self.tensors = _tensors

    def update_graph_in_out(self):
        """
        note that self.inputs may contain constant inputs.
        """
        all_inputs = set()
        all_outputs = set()
        maybe_add_outputs = set()
        for op in self.operators:
            if op.layertype == LayerType.Input:
                all_inputs.add(op.options.outputs[0])
            elif op.layertype == LayerType.Output:
                if (
                    self.activations[op.options.inputs[0]].producer_op.layertype
                    != LayerType.Input
                ):
                    all_outputs.add(op.options.inputs[0])
                maybe_add_outputs.add(op.options.inputs[0])
            elif op.layertype == LayerType.StatefulLSTMWrapper:
                for i in op.options.inputs:
                    all_inputs.add(i)
                for i, mask in zip(op.options.outputs, "ohc"):
                    if mask in op.options.output_mask:
                        all_outputs.add(i)
            else:
                for i in op.options.inputs:
                    all_inputs.add(i)
                for i in op.options.outputs:
                    all_outputs.add(i)

        self.inputs = list(all_inputs - all_outputs)
        self.outputs = all_outputs - all_inputs
        # we need this since the above can remove some output in the middle of graph.
        self.outputs.update(maybe_add_outputs)
        self.outputs = list(self.outputs)

        # Subgraph inputs and outputs are sorted to match the order of their source shapes.
        self.inputs = sorted(
            self.inputs, key=lambda i: self.activations[i].get_act_src_shape()
        )
        self.outputs = sorted(
            self.outputs, key=lambda i: self.activations[i].get_act_src_shape()
        )

    def remove_dangling_activations(self):
        act_to_idx = dict()
        for op in self.operators:
            for iidx in itertools.chain(op.options.inputs, op.options.outputs):
                act_to_idx[self.activations[iidx].name] = None

        _acts = []
        for act in self.activations:
            if act is None:
                continue
            if act.name in act_to_idx:
                act_to_idx[act.name] = len(_acts)
                _acts.append(act)

        for k, v in act_to_idx.items():
            if v is None:
                raise Exception(
                    f"{v} is used in some operator but not exists in subgraph.activations"
                )

        # input output idx update after removing dangling activations
        inputs = []
        outputs = []
        for in_idx in self.inputs:
            if self.activations[in_idx].name in act_to_idx:
                inputs.append(act_to_idx[self.activations[in_idx].name])
        for out_idx in self.outputs:
            if self.activations[out_idx].name in act_to_idx:
                outputs.append(act_to_idx[self.activations[out_idx].name])
        self.inputs = inputs
        self.outputs = outputs

        for op in self.operators:
            try:
                inputs = tuple(
                    act_to_idx[self.activations[i].name] for i in op.options.inputs
                )
            except Exception as e:
                s = f"{op.name}, {op.layertype}, {op.options}"
                raise ValueError(s) from e
            outputs = tuple(
                act_to_idx[self.activations[i].name] for i in op.options.outputs
            )
            kw = {}
            if op.layertype == LayerType.Concatenate:
                if op.options.original_inputs:
                    kw["original_inputs"] = tuple(
                        act_to_idx[self.activations[i].name]
                        for i in op.options.original_inputs
                    )
            op.options = dataclasses.replace(op.options, inputs=inputs, outputs=outputs)

        self.activations = _acts

    def add_tensor(self, ts: TensorSpec) -> TensorIndex:
        if ts.name in self._all_tensor_names:
            ts.name = self.get_valid_ts_name(ts.name)
        """add tensorspec and returns tensor index to tensorspec"""
        self.tensors.append(ts)
        self._all_tensor_names[ts.name] = TensorIndex(len(self.tensors) - 1)
        return self._all_tensor_names[ts.name]

    def get_idx_exists(self, tensorname):
        if tensorname in self._all_tensor_names:
            return self._all_tensor_names[tensorname]
        return -1

    def get_tensor(self, idx: TensorIndex) -> TensorSpec:
        return self.tensors[idx]

    def add_activation(self, act: ActivationSpec) -> int64:
        if act.name in self._all_activation_names:
            raise ValueError(f"activation name already exists: {act.name}")
        idx = len(self.activations)
        self.activations.append(act)
        self._all_activation_names[act.name] = idx
        return idx

    def compute_op_depths(self):
        sys_max = sys.maxsize  # int max

        depths = {}
        q = collections.deque()

        for op in self.operators:
            if op.layertype in (
                LayerType.Input,
                LayerType.AttentionMaskInput,
                LayerType.KVCacheInput,
                LayerType.InputConstant,
            ):
                depths[op.name] = 0
                for oidx in op.options.outputs:
                    for cop in self.activations[oidx].consumer_ops:
                        q.append(cop)
            else:
                depths[op.name] = sys_max
                if any(
                    self.activations[iidx].producer_op is None
                    for iidx in op.options.inputs
                ):
                    q.append(op)

        while q:
            op = q.popleft()
            if depths[op.name] != sys_max:
                continue
            pop_depth_max = max(
                (
                    0
                    if self.activations[i].producer_op is None
                    else depths[self.activations[i].producer_op.name]
                )
                for i in op.options.inputs
            )

            if pop_depth_max == sys_max:
                q.append(op)
            else:
                depths[op.name] = pop_depth_max + 1
                for oidx in op.options.outputs:
                    for cop in self.activations[oidx].consumer_ops:
                        q.append(cop)
        return depths

    @timeout(150, message="A timeout occurred while running sort_operators.")
    def sort_operators(self):
        sorted_ops = [None] * len(self.operators)
        op_cnt = 0
        stk = []
        output_acts = set()
        # op_depths = self.compute_op_depths()
        op_depths = self._calculate_reverse_depth()

        def _visit(op: Operator, op_cnt: int) -> int:
            sorted_ops[op_cnt] = op
            op_cnt += 1
            if (op.layertype == LayerType.Output) or (
                op.layertype == LayerType.DeviceBridge
                and not self.activations[op.outputs[0]].consumer_ops
            ):
                return op_cnt

            for oidx in reversed(op.options.outputs):
                output_acts.add(oidx)
                sorted_consumers = sorted(
                    self.activations[oidx].consumer_ops,
                    key=lambda cop: op_depths[cop.name],
                    reverse=True,  # Deeper operators processed last in stack
                )
                for cop in sorted_consumers:
                    if (
                        cop.layertype == LayerType.Output
                        or cop.options.outputs[0] not in output_acts
                    ):
                        stk.append(cop)
            return op_cnt

        # initialize stack
        for x in reversed(self.inputs):
            inact = self.activations[x]
            if inact.producer_op is None:
                # subgraph inputs may not have input layers in unsupported subgraph.
                stk.extend(inact.consumer_ops)
                output_acts.add(x)
            elif inact.producer_op.layertype in (
                LayerType.Input,
                LayerType.DeviceBridge,
            ):
                stk.append(inact.producer_op)
        # # deal with input_const->output case
        # for op in self.operators:
        #     if op.layertype in (LayerType.Output, LayerType.DeviceBridge):
        #         if (
        #             pop := self.activations[op.options.inputs[0]].producer_op
        #         ).layertype == LayerType.InputConstant:
        #             stk.append(pop)

        while stk:
            op = stk.pop()
            if (  # already visited
                op.options.outputs[0] in output_acts
                and op.layertype != LayerType.Output
            ):
                continue

            if set(op.options.inputs).issubset(output_acts):
                op_cnt = _visit(op, op_cnt)
            else:  # if some inputs of this node are not ready
                if op.layertype == LayerType.Input or (
                    op.layertype == LayerType.DeviceBridge
                    and op.options.inputs[0] in self.inputs
                ):
                    op_cnt = _visit(op, op_cnt)
                else:
                    for iidx in op.options.inputs:
                        if iidx not in output_acts:
                            if self.activations[iidx].producer_op is not None:
                                # None should not be the case
                                stk.append(self.activations[iidx].producer_op)

        if op_cnt != len(self.operators):
            # multiple components로 구성된 graph의 경우 input_const로 시작하면 위에서 방문이 불가능 함.
            sorted_names = set(op.name for op in sorted_ops if op is not None)
            stk = []
            for op in self.operators:
                if op.name not in sorted_names:
                    if op.layertype in (
                        LayerType.InputConstant,
                        LayerType.AttentionMaskInput,
                        LayerType.KVCacheInput,
                    ):
                        stk.append(op)
            while stk:
                op = stk.pop()
                if (  # already visited
                    op.options.outputs[0] in output_acts
                    and op.layertype != LayerType.Output
                ):
                    continue

                if set(op.options.inputs).issubset(output_acts):
                    op_cnt = _visit(op, op_cnt)
                else:  # if some inputs of this node are not ready
                    if op.layertype == LayerType.Input or (
                        op.layertype == LayerType.DeviceBridge
                        and op.options.inputs[0] in self.inputs
                    ):
                        op_cnt = _visit(op, op_cnt)
                    else:
                        for iidx in op.options.inputs:
                            if iidx not in output_acts:
                                if self.activations[iidx].producer_op is not None:
                                    # None should not be the case
                                    stk.append(self.activations[iidx].producer_op)

        if op_cnt != len(self.operators):
            raise Exception(
                f"op_cnt != len(self.operators),{op_cnt}!={len(self.operators)}"
            )
        # for x in sorted_ops:
        #     print(x.layertype, x.name)
        self.operators = sorted_ops

    @property
    def num_operators(self):
        return len(self.operators)

    def sort_inouts(self, activation_tracer, origin_input_list, origin_output_list):
        def sort_indices(indices, origin_names, desired_order, key_getter):
            if set(origin_names) == set(desired_order):
                order_map = {name: i for i, name in enumerate(desired_order)}
                sorted_pairs = sorted(
                    zip(indices, origin_names), key=lambda pair: order_map[pair[1]]
                )
                return [idx for idx, _ in sorted_pairs]
            else:
                sorted_pairs = sorted(
                    zip(indices, [key_getter(idx) for idx in indices]),
                    key=lambda pair: pair[1],
                )
                return [idx for idx, _ in sorted_pairs]

        inacts = [self.activations[inidx] for inidx in self.inputs]
        outacts = [self.activations[outidx] for outidx in self.outputs]

        origin_in_tracer = [activation_tracer.get(inact.name, None) for inact in inacts]
        origin_out_tracer = [
            activation_tracer.get(outact.name, None) for outact in outacts
        ]

        origin_in_names = (
            [] if None in origin_in_tracer else [act.name for act in origin_in_tracer]
        )
        origin_out_names = (
            [] if None in origin_out_tracer else [act.name for act in origin_out_tracer]
        )

        self.inputs = sort_indices(
            self.inputs,
            origin_in_names,
            origin_input_list,
            lambda idx: self.activations[idx].get_act_src_shape(),
        )

        self.outputs = sort_indices(
            self.outputs,
            origin_out_names,
            origin_output_list,
            lambda idx: self.activations[idx].get_act_src_shape(),
        )

    def is_terminal_node(self, op):
        if op.layertype == LayerType.Output:
            return True
        if (
            op.layertype == LayerType.DeviceBridge
            and op.options.outputs[0] in self.outputs
        ):
            return True
        if all(not self.activations[oidx].consumer_ops for oidx in op.options.outputs):
            return True
        return False

    def _calculate_reverse_depth(self):
        reverse_graph = collections.defaultdict(list)
        q = collections.deque()
        depth = collections.defaultdict(int)
        key = lambda op: (op.name, op.layertype)

        for parent in self.operators:
            # Layer of the type Output has the same name as the preceding layer.
            if parent.layertype != LayerType.Output:
                for oidx in parent.options.outputs:
                    oact = self.activations[oidx]
                    for child in oact.consumer_ops:
                        reverse_graph[key(child)].append(parent)
            if self.is_terminal_node(parent):
                q.append(parent)
                if parent.layertype == LayerType.Output:
                    depth[key(parent)] = -1
                else:
                    depth[key(parent)] = 0

        visited = set()
        while q:
            op = q.popleft()
            if key(op) in visited:
                continue
            visited.add(key(op))
            curr_depth = depth[key(op)]
            for parent in reverse_graph[key(op)]:
                depth[key(parent)] = max(depth[key(parent)], curr_depth + 1)
                q.append(parent)

        depth_max = max(depth.values())
        for k in depth.keys():
            depth[k] = depth_max - depth[k]
        for k in depth.keys():
            if k[1] == LayerType.Output:
                depth[k] = depth[key(reverse_graph[k][0])] + 1
        return depth

    def strip_unused_operators(self):
        changed = True
        while changed:
            changed = False
            self.update_op_act_connectivity()
            for op in self.operators:
                if 0 == sum(
                    len(self.activations[x].consumer_ops) for x in op.options.outputs
                ):
                    op.valid = False
                    changed = True
            self.operators = [op for op in self.operators if op.valid]
        self.remove_dangling_tensors()
        self.remove_dangling_activations()

    def outacts_from_op(self, op: Operator):
        outacts = tuple(self.activations[oidx] for oidx in op.options.outputs)
        return outacts

    def inacts_from_op(self, op: Operator):
        inacts = tuple(self.activations[iidx] for iidx in op.options.inputs)
        return inacts

    def update_dynamic_axis(self):
        # fixme: 일단 임시로 만들어 둠. 그냥 shape_inference구현 필요함
        def _single_op_update(op):
            inact = self.activations[op.options.inputs[0]]
            outact = self.activations[op.options.outputs[0]]
            for in_shape, out_shape in zip(
                inact.get_act_src_shape(), outact.get_act_src_shape()
            ):
                out_shape.set_dynamic(in_shape.dynamic)
            return outact.consumer_ops

        def _update(op):
            if op.layertype == LayerType.MatMul:
                left_inact = self.activations[op.options.inputs[0]]
                right_inact = self.activations[op.options.inputs[1]]
                out_act = self.activations[op.options.outputs[0]]
                out_act.get_act_src_shape()[-2].set_dynamic(
                    left_inact.get_act_src_shape()[-2].dynamic
                )
                out_act.get_act_src_shape()[-1].set_dynamic(
                    right_inact.get_act_src_shape()[-1].dynamic
                )
                return out_act.consumer_ops
            if (
                (
                    op.layertype
                    in (LayerType.MultiplyConstant, LayerType.AddingConstant)
                    and len(self.tensors[op.options.constant].shape) <= 1
                )
                or op.layertype == LayerType.StatefulKVCacheWrapper
                or op.layertype == LayerType.StatefulAttentionMaskWrapper
                or op.layertype == LayerType.Softmax
            ):
                _single_op_update(op)
                return self.activations[op.options.outputs[0]].consumer_ops
            if op.layertype == LayerType.Unsqueeze and 1 == len(op.options.axes):
                inact = self.activations[op.options.inputs[0]]
                outact = self.activations[op.options.outputs[0]]
                ogen = (
                    ox
                    for idx, ox in enumerate(outact.get_act_src_shape())
                    if idx != op.options.axes[0]
                )
                for a, b in zip(inact.get_act_src_shape(), ogen):
                    b.set_dynamic(a.dynamic)
                return outact.consumer_ops
            if op.layertype == LayerType.Expand:
                inact = self.activations[op.options.inputs[0]]
                outact = self.activations[op.options.outputs[0]]
                if len(inact.get_act_src_shape()) == len(outact.get_act_src_shape()):
                    for a, b in zip(
                        inact.get_act_src_shape(), outact.get_act_src_shape()
                    ):
                        b.set_dynamic(a.dynamic)
                    return outact.consumer_ops
            if op.layertype == LayerType.Reshape:
                inact = self.activations[op.options.inputs[0]]
                outact = self.activations[op.options.outputs[0]]
                # backward dim match
                ax = 0

                for a, b in zip(
                    reversed(inact.get_act_src_shape()),
                    reversed(outact.get_act_src_shape()),
                ):
                    if a != b:
                        break
                    ax -= 1
                if ax < 0:
                    for a, b in zip(
                        inact.get_act_src_shape()[ax:], outact.get_act_src_shape()[ax:]
                    ):
                        b.set_dynamic(a.dynamic)
                    return outact.consumer_ops
            if op.layertype == LayerType.Transpose:
                inact_src_shape = self.activations[
                    op.options.inputs[0]
                ].get_act_src_shape()
                outact = self.activations[op.options.outputs[0]]
                for i, x in enumerate(outact.get_act_src_shape()):
                    x.set_dynamic(inact_src_shape[op.options.transpose_axes[i]].dynamic)
                return outact.consumer_ops

            return None

        init_sets = set()
        queue = collections.deque()
        for op in self.operators:
            if op.layertype == LayerType.StatefulKVCacheWrapper:
                res = _update(op)
                if res is not None:
                    for next_op in res:
                        queue.append(next_op)
                        init_sets.add(next_op)

        while queue:
            op = queue.popleft()
            if (res := _update(op)) is not None:
                for next_op in res:
                    if next_op not in init_sets:
                        queue.append(next_op)

    def fix_axis(self):
        def to_positive(ax, src_dim):
            if isinstance(ax, tuple):
                return tuple(x if x >= 0 else x + src_dim for x in ax)
            return ax if ax >= 0 else ax + src_dim

        axis_ops = (
            LayerType.Concatenate,
            LayerType.Softmax,
            LayerType.Slice,
        )
        reduce_axes_ops = (
            LayerType.ReduceMax,
            LayerType.ReduceMean,
            LayerType.ReduceSum,
            LayerType.ReduceL2,
            LayerType.ReduceMin,
            LayerType.ReduceProd,
        )

        for op in self.operators:
            if op.layertype in axis_ops:
                src_dim = self.activations[op.options.inputs[0]].src_dim
                op.options = dataclasses.replace(
                    op.options, axis=to_positive(op.options.axis, src_dim)
                )
            elif op.layertype in reduce_axes_ops:
                src_dim = self.activations[op.options.inputs[0]].src_dim
                op.options = dataclasses.replace(
                    op.options, reduce_axes=to_positive(op.options.reduce_axes, src_dim)
                )
