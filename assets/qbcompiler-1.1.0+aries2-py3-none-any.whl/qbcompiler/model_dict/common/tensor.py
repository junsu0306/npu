import numpy
import torch
import operator

from typing import List, Union, Any, Dict
from qbcompiler.model_dict.common import (
    DataFormat,
    SubGraph,
    WeightDict,
    LayerType,
    ActivationSpec,
)
from qbcompiler.model_dict.common.dtypes import get_dtype_str, dtype_to_torchformat
from qbcompiler.model_dict.common.model_dict import ValueDict
from qbcompiler.model_dict.common.value_wrapper import ValueWrapper


class WrappedTensor:
    # todo: subclassing would be better.... however, we got segfault when do that...
    def __init__(
        self,
        data,
        dtype,
        dataformat: DataFormat = DataFormat.UNKNOWN,
        **kwargs,
    ):
        if isinstance(data, numpy.ndarray):
            self._t = torch.from_numpy(data).type(dtype_to_torchformat(dtype))
        elif isinstance(data, torch.Tensor):
            self._t = data
        else:
            self._t = torch.as_tensor(data, **kwargs).type(dtype_to_torchformat(dtype))
        self._dataformat = dataformat

    def __repr__(self):
        return f"{self.shape}, {self.dtype}, {self.dataformat}"

    def to(self, *args, **kwargs):
        self._t = self._t.to(*args, **kwargs)
        return self

    def set_dataformat(self, data_format):
        self._dataformat = data_format

    @property
    def dtype(self):
        return str(self._t.dtype).split(".")[-1]  # ex) torch.float32 -> float32

    @property
    def shape(self):
        return tuple(self._t.shape)

    @property
    def src_shape(self):
        return tuple(self._t.shape)

    @property
    def dataformat(self) -> DataFormat:
        return self._dataformat

    @property
    def mean(self):
        return self._t.mean()

    @property
    def min(self):
        return self._t.min()

    @property
    def max(self):
        return self._t.max()

    @classmethod
    def __torch_function__(cls, func, types, args=(), kwargs=None):
        if kwargs is None:
            kwargs = {}
        args = [getattr(a, "_t", a) for a in args]
        ret = func(*args, **kwargs)
        return WrappedTensor(ret, dtype=ret.dtype)


class InputSG:
    act_compat_list = ["dtype", "src_shape"]

    def __init__(self, value_dict: ValueDict = None):
        if value_dict is None:
            value_dict = {}
        self._inputs: Dict[str, WrappedTensor] = {}
        self.value_dict: ValueDict = value_dict

    def append(
        self,
        input: Union[WrappedTensor, torch.Tensor, numpy.ndarray],
        name: List[str],
        **kwargs,
    ):
        if isinstance(input, WrappedTensor):
            pass
        elif isinstance(input, (torch.Tensor, numpy.ndarray)):
            input = WrappedTensor(
                data=input, dtype=get_dtype_str(input), dataformat=DataFormat.UNKNOWN
            )
        else:
            raise ValueError("check the input type")
        self._inputs.update({name: input})

    def extend(
        self,
        inputs: List[Union[WrappedTensor, torch.Tensor]],
        names: List[str],
        **kwargs,
    ):
        assert len(inputs) == len(names)
        if list_type_check(WrappedTensor, inputs):
            pass
        elif list_type_check(torch.Tensor, inputs) or list_type_check(
            numpy.ndarray, inputs
        ):
            inputs = [
                WrappedTensor(
                    data=input,
                    dtype=get_dtype_str(input),
                    dataformat=DataFormat.UNKNOWN,
                )
                for input in inputs
            ]
        else:
            raise ValueError("check the input types")
        self._inputs.update({name: inputs[i] for i, name in enumerate(names)})

    def autoset_value(self, sg: SubGraph, wd: WeightDict, subgraphs_outtensors):
        inputs_dict = {}
        for iact in sg.input_activations():
            if wd.isin(iact.name):
                continue
            if iact.producer_op is not None:
                if iact.producer_op.output_value_reference is not None:
                    ref_name = iact.producer_op.output_value_reference
                else:
                    if iact.producer_op.layertype == LayerType.AttentionMaskInput:
                        w = wd.get_weight_by_name(
                            sg.tensors[iact.producer_op.options.sample_mask].name
                        )
                        subgraphs_outtensors[iact.name] = WrappedTensor(w, str(w.dtype))
                    else:
                        ref_name = iact.name
            else:
                ref_name = iact.name

            if iact.name in subgraphs_outtensors:
                inputs_dict[iact.name] = subgraphs_outtensors[iact.name]
                continue
            if ref_name not in self.value_dict:
                if iact.name in self.value_dict:
                    ref_name = iact.name
                    iact.producer_op.output_value_reference = ref_name
                else:
                    if ref_name is None:
                        raise ValueError(
                            f"reference name of iact.producer_op of {iact.name} is None, please check the input fusing process"
                        )
            try:
                if hasattr(ref_name, "ref_name"):
                    ref_name = ref_name.ref_name
                value_dict_data = self.value_dict[ref_name]
            except Exception as e:
                raise e
            if isinstance(value_dict_data, ValueWrapper):
                value_dict_data = value_dict_data.value

            value_dict_dformat = self.value_dict.get_dataformat(ref_name)
            if value_dict_dformat in (
                DataFormat.NCHW,
                DataFormat.UNKNOWN,
            ) and self.rank4ordermatching(iact, value_dict_data):
                value_dict_data = numpy.transpose(value_dict_data, (0, 2, 3, 1))
            elif iact.src_shape == (1,) + value_dict_data.shape:
                value_dict_data = numpy.expand_dims(value_dict_data, axis=0)
            else:
                pass

            inputs_dict[ref_name] = WrappedTensor(
                data=value_dict_data,
                dtype=get_dtype_str(value_dict_data),
                dataformat=iact.dataformat,
            )
        self._inputs = inputs_dict
        return inputs_dict

    def validate_input(self, sg: SubGraph, wd: WeightDict):
        for iact in sg.input_activations():
            if wd.isin(iact.name):
                continue
            if iact.producer_op is not None:
                if iact.producer_op.output_value_reference is not None:
                    ref_name = iact.producer_op.output_value_reference
                else:
                    ref_name = iact.name
            else:
                ref_name = iact.name

            if ref_name not in self._inputs:
                if iact.name in self.value_dict:
                    ref_name = iact.name
                    iact.producer_op.output_value_reference = ref_name
                else:
                    continue
            for element in InputSG.act_compat_list:
                input_element = getattr(self._inputs[ref_name], element)
                act_element = getattr(iact, element)
                if element == "src_shape":
                    if act_element == (-1, -1, -1):
                        act_element = (1,) + getattr(iact, "shape")
                if isinstance(input_element, str):
                    input_element = input_element.lower()
                    act_element = act_element.lower()

    def validate_ref_name(self, ref_name: str, value_dict: dict):
        return ref_name in value_dict

    def rank4ordermatching(sefl, inact: ActivationSpec, value_dict_data: numpy.ndarray):
        inact_src_shape = tuple(int(shape) for shape in inact.src_shape)
        value_dict_src_shape = value_dict_data.shape
        if not len(inact_src_shape) == len(value_dict_src_shape) == 4:
            return False

        if operator.itemgetter(0, 2, 3, 1)(value_dict_src_shape) != inact_src_shape:
            return False

        batch, channels, height, width = value_dict_src_shape

        # assuming NCHW format for the value dict
        if batch != 1 or width == channels or height == channels:
            return False

        return True

    @property
    def dtype(self):
        return [{name: str(tensor.dtype)} for name, tensor in self._inputs.items()]

    @property
    def shape(self):
        return [{name: tensor.shape} for name, tensor in self._inputs.items()]

    @property
    def dataformat(self):
        return [{name: tensor.dataformat} for name, tensor in self._inputs.items()]

    @property
    def inputs(self):
        return self._inputs


def get_types_in_list(data: List[Any]) -> List[Any]:
    """
    Returns a list of types for each element in the input list,
    handling nested lists by recursively processing them.

    Parameters:
    data (list): The list whose elements' types are to be determined.

    Returns:
    list: A list of types corresponding to the elements in the input list.
    """
    types = []

    for element in data:
        if isinstance(element, list):
            types.extend(get_types_in_list(element))
        else:
            types.append(type(element))

    return types


def list_type_check(cls_type, inputs: List[Any]):
    return all([cls_type == types for types in get_types_in_list(inputs)])


#
# class WrappedTensor(torch.Tensor):
#     @staticmethod
#     def __new__(cls, x, data_format=DataFormat.UNKNOWN, *args, **kwargs):
#         return super().__new__(cls, x, *args, **kwargs)
#
#     def __init__(self, x, data_format=DataFormat.UNKNOWN):
#         self._data_format = data_format
#
#     def clone(self, *args, **kwargs):
#         return WrappedTensor(super().clone(*args, **kwargs), self._data_format)
#
#     def set_dataformat(self, data_format):
#         self._data_format = data_format
#
#     @property
#     def data_format(self):
#         return self._data_format
#
#     def to(self, *args, **kwargs):
#         new_obj = WrappedTensor([], self._data_format)
#         ts = super().to(*args, **kwargs)
#         new_obj.data = ts.data
#         new_obj.requires_grad = ts.requires_grad
#         return new_obj
#
#     @classmethod
#     def __torch_function__(cls, func, types, args=(), kwargs=None):
#         if kwargs is None:
#             kwargs = {}
#         args = [getattr(a, "_t", a) for a in args]
#         ret = func(*args, **kwargs)
#         return WrappedTensor(ret)
