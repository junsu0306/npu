import abc

import numpy


class ValueProviderABC(abc.ABC):
    @property
    @abc.abstractmethod
    def value(self, *args, **kwargs):
        ...

    @property
    @abc.abstractmethod
    def shape(self):
        ...

    @property
    @abc.abstractmethod
    def dtype(self):
        ...

    @property
    @abc.abstractmethod
    def available(self):
        ...


class ValueWrapper:
    def __init__(self, value: numpy.ndarray | ValueProviderABC = None):
        self._value = value

    def __float__(self):
        self._value = self._value.astype(numpy.float32)
        if isinstance(self._value, ValueProviderABC):
            return float(self._value.value)
        elif isinstance(self._value, numpy.ndarray):
            return float(self._value)
        else:
            raise NotImplementedError

    def __int__(self):
        if isinstance(self._value, ValueProviderABC):
            return int(self._value.value)
        elif isinstance(self._value, numpy.ndarray):
            return int(self._value)
        else:
            raise NotImplementedError

    @property
    def kind(self):
        return type(self._value).__qualname__

    @property
    def value(self):
        if isinstance(self._value, numpy.ndarray):
            return self._value
        return self._value.value

    @property
    def shape(self):
        if isinstance(self._value, numpy.ndarray):
            return self._value.shape
        return self._value.shape

    @property
    def dtype(self):
        if isinstance(self._value, numpy.ndarray):
            return self._value.dtype
        return self._value.dtype

    @property
    def value_provider(self):
        if issubclass(type(self._value), ValueProviderABC):
            return self._value
        raise ValueError(
            f"The current ValueWrapper instance contains a value of the type {type(self._value)}"
        )
