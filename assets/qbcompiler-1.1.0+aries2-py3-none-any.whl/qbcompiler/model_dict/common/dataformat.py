import enum
from typing import Tuple


class DataFormat(enum.Enum):
    UNKNOWN = enum.auto()
    NHWC = enum.auto()
    NCHW = enum.auto()
    NXC = enum.auto()
    NCX = enum.auto()
    NC = enum.auto()  # for data shape [1, 10001]
    NX = enum.auto()  # we need this sometimes e.g, llama token length.


DATAFORMAT_LIST = [name for name in DataFormat.__members__]


class DIMENSION(enum.Enum):
    N = enum.auto()
    C = enum.auto()
    H = enum.auto()
    W = enum.auto()


def validate_src_shape_dformat(src_shape: Tuple[int, ...], dformat: DataFormat):
    err_msg = f"src_shape: {src_shape} dformat: {dformat.name} are not matched"
    if dformat == DataFormat.UNKNOWN:
        pass
    elif len(src_shape) == len(dformat.name):
        pass
    else:
        raise ValueError
