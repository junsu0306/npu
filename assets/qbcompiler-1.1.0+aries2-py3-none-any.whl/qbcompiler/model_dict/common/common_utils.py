import signal
from contextlib import contextmanager


@contextmanager
def timeout(seconds, message=None):
    def handler(signum, frame):
        msg = message or f"Timed out after {seconds} seconds"
        raise TimeoutError(msg)

    old = signal.signal(signal.SIGALRM, handler)
    signal.alarm(int(seconds))
    try:
        yield
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, old)
