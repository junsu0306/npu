import dataclasses
import math
import operator
from typing import Tuple, List, Optional

import numpy
import torch

from qbcompiler.model_dict.common.dataformat import DataFormat
from qbcompiler.model_dict.common.dtypes import int64, TypeEnforced, uint32


def to_str_dtype(obj):
    if isinstance(obj, torch.dtype):
        return obj.__str__().split(".")[-1].lower()
    if isinstance(obj, numpy.dtype):
        return obj.name.lower()
    if isinstance(obj, str):
        return obj.lower()
    return obj


class DimValue:
    __slots__ = ("_value", "_dynamic")

    def __init__(self, value: int = -1, dynamic: bool = False):
        if isinstance(value, DimValue):
            self._value: int = value.value
            self._dynamic = bool(value.dynamic or dynamic)
        elif isinstance(value, (int, numpy.integer)):
            self._value = int(value)
            self._dynamic = bool(dynamic)
        elif isinstance(value, float) and int(value) == value:  # fix truediv
            self._value = int(value)
            self._dynamic = bool(dynamic)
        else:
            try:
                self._value = int(value)
                self._dynamic = bool(getattr(value, "dynamic", dynamic))
            except Exception as e:
                raise TypeError(
                    f"DimValue must be an integer but got={value}, {type(value)}"
                )

    def __int__(self):
        return self._value

    def __hash__(self):
        return hash((self._value, self._dynamic))

    @property
    def value(self):
        return self._value

    @property
    def dynamic(self):
        return self._dynamic

    def set_dynamic(self, value=True):
        self._dynamic = value

    def __repr__(self):
        return f"dyn({self._value})" if self._dynamic else str(self._value)

    def _num_ker(self, other, op_):
        if isinstance(other, DimValue):
            return DimValue(op_(self.value, other.value), self._dynamic | other.dynamic)
        if isinstance(other, int) or numpy.issubdtype(type(other), numpy.integer):
            return DimValue(op_(self.value, int(other)), self._dynamic)

        return DimValue(op_(self.value, other), self._dynamic)
        # raise NotImplementedError(f"Cannot {op_.__name__} DimValue and {type(other)}")

    def _cmp_ker(self, other, op_):
        if isinstance(other, DimValue):
            return op_(self.value, other.value)
        if isinstance(other, (int, numpy.integer)):
            return op_(self.value, other)
        return op_(self.value, other)
        # raise NotImplementedError(f"Cannot {op_.__name__} DimValue and {type(other)}")

    def __add__(self, other):
        return self._num_ker(other, operator.add)

    def __sub__(self, other):
        return self._num_ker(other, operator.sub)

    def __rsub__(self, other):
        return self._num_ker(other, lambda x, y: y - x)

    def __mul__(self, other):
        return self._num_ker(other, operator.mul)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __truediv__(self, other):
        return self._num_ker(other, operator.truediv)

    def __floordiv__(self, other):
        return self._num_ker(other, operator.floordiv)

    def __radd__(self, other):
        return self.__add__(other)

    def __mod__(self, other):
        return self._num_ker(other, operator.mod)

    def __eq__(self, other):
        return self._cmp_ker(other, operator.eq)

    def __lt__(self, other):
        return self._cmp_ker(other, operator.lt)

    def __le__(self, other):
        return self == other or self < other

    def __gt__(self, other):
        return not (self <= other)

    def __ge__(self, other):
        return not (self < other)

    def __neg__(self):
        return DimValue(-self._value, self._dynamic)

    def __index__(self):
        """Make DimValue behave like an int in indexing operations.
        For example, tensor reshaping in torch or numpy.
        """
        return self._value


class TensorShape(tuple):
    def __new__(cls, args):
        return super(TensorShape, cls).__new__(cls, (DimValue(arg) for arg in args))


class ActivationSpec:
    def __init__(
        self,
        name: str,
        dtype: str,
        shape: Tuple[DimValue, DimValue, DimValue] | None = None,
        src_shape: Tuple[DimValue, ...] = (-1, -1, -1),
        dataformat: DataFormat = DataFormat.UNKNOWN,
    ):
        self.name: str = name
        self.dtype: str = to_str_dtype(dtype)
        # for ease of deserialization, we will set this value as (-1, -1, -1) if shape is None
        if shape is None:
            shape = (-1, -1, -1)
        self._shape: Tuple[DimValue, DimValue, DimValue] = tuple(
            DimValue(x) for x in shape
        )
        self._src_shape: Tuple[DimValue, ...] = tuple(DimValue(x) for x in src_shape)
        self.dataformat: DataFormat = dataformat
        # The following fields are used for convenience only and will not be serialized.
        # Operator that generate this activation as output.
        self.producer_op: "Operator" = None
        # Operators that take this activation as input.
        self.consumer_ops: List["Operator"] = []
        self._post_init()

    def __repr__(self):
        return f"src_shape={self.src_shape},{self.dtype}, {self.dataformat}, name={self.name}"

    @property
    def shape(self):
        return self._shape

    @shape.setter
    def shape(self, value):
        self._shape = tuple(DimValue(x) for x in value)

    @property
    def src_shape(self):
        return self.get_act_src_shape()

    @src_shape.setter
    def src_shape(self, value):
        self._src_shape = tuple(DimValue(x) for x in value)

    @property
    def contain_dynamic(self):
        return any(dimvalue.dynamic for dimvalue in self.src_shape)

    @staticmethod
    def from_dict(dct):
        if isinstance(dct["dataformat"], str):
            dct["dataformat"] = DataFormat[dct["dataformat"]]

        def _to_dim_value(k):
            for x in dct[k]:
                yield DimValue(**x) if isinstance(x, dict) else x

        dct["src_shape"] = tuple(_to_dim_value("src_shape"))
        dct["shape"] = tuple(_to_dim_value("shape"))
        return ActivationSpec(**dct)

    def get_src_dim(self):
        return len(self.get_act_src_shape())

    @property
    def src_dim(self):
        return len(self.get_act_src_shape())

    def _post_init(self):
        # (1,h,w,c)=> supported shape
        if self.shape is None:
            self.shape = (-1, -1, -1)
        if len(self.shape) != 3:
            raise ValueError(f"shape should be of the length 3 but shape={self.shape}")

        if self._src_shape is None or self._src_shape == (-1, -1, -1):
            # should be supported case
            if not (self.shape != (-1, -1, -1)):
                raise ValueError(
                    f"src_shape={self._src_shape}, shape={self.shape} and dataformat={self.dataformat} are not compatible."
                )
            self._src_shape = (DimValue(1),) + self.shape
        else:
            if (  # fill shape if it does not have value
                self.dataformat == DataFormat.NHWC
                and len(self._src_shape) == 4
                and self._src_shape[0] == 1
                and self.shape == (-1, -1, -1)
            ):
                self.shape = self._src_shape[1:]
        if isinstance(self._src_shape, list):
            self._src_shape = tuple(self._src_shape)

    def copy(self, name=None, dtype=None, shape=None, src_shape=None, dataformat=None):
        """Returns new object, replacing specified attribute, except producer_op, and consumer_ops."""
        if name is None:
            name = self.name
        if dtype is None:
            dtype = self.dtype
        if shape is None and src_shape is None:
            shape = self.shape
            src_shape = self.src_shape
        elif shape is None:
            shape = (-1, -1, -1)
        elif src_shape is None:
            src_shape = (-1, -1, -1)

        if self.src_dim == 4:
            dataformat = DataFormat.NHWC
        else:
            dataformat = DataFormat.UNKNOWN
        # to support subtype of ActivaionSpec
        return type(self)(
            name, dtype, shape, src_shape=src_shape, dataformat=dataformat
        )

    def is_supported_activation(self):
        return self.is_supported_shape()

    def is_supported_shape(self):
        """
        input shape HWC has valid values or src_shape is supported shape(NHWC)
        """
        if self._src_shape == (-1, -1, -1):
            return -1 not in self.shape
        if self.shape == (-1, -1, -1):
            return len(self._src_shape) == 4 and self._src_shape[0] == 1
        return len(self._src_shape) == 4 and self._src_shape[0] == 1

    def get_act_shape_as_supported(self):
        """
        returns act shape as if it is input to supported layer.
        returns None if not
        """
        if self.is_supported_shape():
            return self.shape if -1 not in self.shape else self._src_shape[1:]
        return None

    def get_act_src_shape(
        self, idx: Optional[int] = None
    ) -> Tuple[int | DimValue, ...] | int | DimValue:
        if self._src_shape != (-1, -1, -1):
            ret = self._src_shape
        elif self.is_supported_activation():
            # todo: remove this branch.
            ret = (DimValue(1),) + self.get_act_shape_as_supported()
        else:
            ret = self._src_shape
        return ret[idx] if idx is not None else ret


@dataclasses.dataclass
class TensorSpec(TypeEnforced):
    name: str
    dtype: str
    shape: Tuple[int64, ...]
    # a single tensor can be splitted and saved into several buffers, however,
    # we only need to know its starting position since data is sequentially saved.
    # will be filled during serialization
    buffer_idx: uint32 = numpy.uint32(numpy.iinfo(numpy.uint32).max)
    offset: uint32 = numpy.uint32(numpy.iinfo(numpy.uint32).max)

    def asdict(self):
        return {
            "name": self.name,
            "dtype": self.dtype,
            "shape": self.shape,
            "buffer_idx": self.buffer_idx,
            "offset": self.offset,
        }

    @property
    def tensorsize(self) -> int:
        if len(tuple(self.shape)) == 0:
            return numpy.dtype(self.dtype).itemsize
        else:
            return math.prod(map(int, self.shape)) * numpy.dtype(self.dtype).itemsize

    def copy(self, name=None, dtype=None, shape=None):
        """returns new one by replacing given attributes."""
        if name is None:
            name = self.name
        if dtype is None:
            dtype = self.dtype
        if shape is None:
            shape = self.shape
        return TensorSpec(name, dtype, shape)

    def __eq__(self, other):
        return (
            self.name == other.name
            and self.dtype == other.dtype
            and self.shape == other.shape
        )

    def __ne__(self, other):
        return not self.__eq__(other)
