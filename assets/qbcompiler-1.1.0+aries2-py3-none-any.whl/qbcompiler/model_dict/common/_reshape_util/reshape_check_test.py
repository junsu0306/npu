from reshape_check import reshape_check


def make_vars(k):
    # a,b,c,..., z, A,B,... as 필요 시 확장
    letters = [chr(i) for i in range(ord("a"), ord("z") + 1)] + [
        chr(i) for i in range(ord("A"), ord("Z") + 1)
    ]
    if k > len(letters):
        raise ValueError("Too many base variables requested")
    return letters[:k]


def random_partition(n):
    # 0..n-1 사이 컷을 선택하여 연속 그룹 파티션 생성
    if n == 0:
        return []
    cuts = [0]
    for i in range(1, n):
        if random.random() < 0.5:
            cuts.append(i)
    cuts.append(n)
    groups = []
    for i in range(len(cuts) - 1):
        if cuts[i] < cuts[i + 1]:
            groups.append((cuts[i], cuts[i + 1]))
    if not groups:
        groups = [(0, n)]
    return groups


def insert_ones(num_slots):
    # 각 슬롯 위치에 1을 넣을지 여부 반환
    return [random.random() < 0.25 for _ in range(num_slots)]


def fmt_term(var_seq):
    if not var_seq:
        return "1"
    if len(var_seq) == 1:
        return var_seq[0]
    return "(" + " ".join(var_seq) + ")"


def build_side(vars_seq, groups, ones_before_flags):
    terms = []
    for idx, (sidx, eidx) in enumerate(groups):
        if ones_before_flags[idx]:
            terms.append("1")
        terms.append(fmt_term(vars_seq[sidx:eidx]))
    # 마지막 뒤에도 1을 넣을지 랜덤 추가
    if ones_before_flags and random.random() < 0.2:
        terms.append("1")
    # 콤마 없이 연결: 예) 1a(b c)d
    return "".join(terms)


def build_shape(values, groups, ones_before_flags):
    shape = []
    for idx, (sidx, eidx) in enumerate(groups):
        if ones_before_flags[idx]:
            shape.append(1)
        prod = 1
        for v in values[sidx:eidx]:
            prod *= v
        shape.append(prod)
    if ones_before_flags and random.random() < 0.2:
        shape.append(1)
    return tuple(shape)


# 1) 양성(Valid reshape) 케이스 생성기
def gen_positive_case():
    # 1) 기본 변수 수와 각 변수 값 선택
    k = random.choice([1, 2, 3, 4, 5, 6, 7])
    vars_seq = make_vars(k)
    values = [random.randint(1, 9) for _ in range(k)]

    # 2) LHS/RHS 파티션(연속 구간) 선택
    lhs_groups = random_partition(k)
    rhs_groups = random_partition(k)

    # 3) 1 삽입 여부 결정 (각 그룹 앞에 넣을 수 있음)
    lhs_ones = insert_ones(len(lhs_groups))
    rhs_ones = insert_ones(len(rhs_groups))

    # 4) 문자열/shape 구성
    lhs_str = build_side(vars_seq, lhs_groups, lhs_ones)
    rhs_str = build_side(vars_seq, rhs_groups, rhs_ones)
    pattern = f"{lhs_str} -> {rhs_str}"

    in_shape = build_shape(values, lhs_groups, lhs_ones)
    out_shape = build_shape(values, rhs_groups, rhs_ones)

    if reshape_check(pattern, in_shape, out_shape):
        return (pattern, in_shape, out_shape, True)
    return None


# 2) 음성(Negative) 케이스 생성기들
def gen_neg_size_mismatch():
    # 총 요소수 불일치
    a = random.randint(2, 9)
    b = random.randint(2, 9)
    s = "ab -> (a b)"
    in_shape = (a, b)
    out_shape = (a * b + 1,)
    return (s, in_shape, out_shape, False)


def gen_neg_rank_mismatch():
    # 랭크 불일치
    a = random.randint(2, 9)
    b = random.randint(2, 9)
    s = "ab -> ab"
    in_shape = (a, b)
    out_shape = (a, b, 1)  # rank +1
    return (s, in_shape, out_shape, False)


def gen_neg_const_term_non1():
    # 상수만(1)으로 구성된 term이 1이 아닌 축 길이에 매핑
    x = random.randint(2, 9)
    s = "a -> 1"
    in_shape = (x,)
    out_shape = (x,)
    return (s, in_shape, out_shape, False)


def gen_neg_var_inconsistency():
    # 변수 불일치: a, b -> a, c (총 요소수는 맞추되 a 값이 충돌하도록)
    p = random.randint(2, 9)
    q = random.randint(2, 9)
    while q == p:
        q = random.randint(2, 9)
    s = "ab -> ac"
    in_shape = (p, q)
    out_shape = (q, p)
    return (s, in_shape, out_shape, False)


if __name__ == "__main__":
    import random

    random.seed(20251127)

    # 양/음성 비율 설정
    POS_TARGET = 300
    NEG_TARGET = 200

    TEST_SETS = []

    NEG_GENERATORS = [
        gen_neg_size_mismatch,
        gen_neg_rank_mismatch,
        gen_neg_const_term_non1,
        gen_neg_var_inconsistency,
    ]

    # 생성 루프
    pos_cnt = 0
    neg_cnt = 0

    # 양성 생성
    safety = 0
    while pos_cnt < POS_TARGET and safety < 100000:
        safety += 1
        case = gen_positive_case()
        if case is None:
            continue
        TEST_SETS.append(case)
        pos_cnt += 1

    # 음성 생성
    for _ in range(NEG_TARGET):
        gen = random.choice(NEG_GENERATORS)
        case = gen()
        TEST_SETS.append(case)

    # 셔플(재현성을 위해 시드가 고정이므로 순서만 랜덤화)
    random.shuffle(TEST_SETS)

    # 결과 확인 출력
    for case_no, case in enumerate(TEST_SETS):
        s, in_shape, out_shape, ans = case
        res = reshape_check(s, in_shape, out_shape)
        if res != ans:
            raise Exception(
                f"old: {case_no}, pattern=[{s}]",
                f"[{in_shape}]",
                f"[{out_shape}]",
                f"res={res}, pass={ans == res}",
            )
        print(
            f"{case_no}, pattern=[{s}]",
            f"[{in_shape}]",
            f"[{out_shape}]",
            f"res={res}, ans={ans} pass={ans == res}",
        )
