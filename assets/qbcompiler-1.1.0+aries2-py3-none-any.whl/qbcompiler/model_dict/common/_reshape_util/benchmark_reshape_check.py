#!/usr/bin/env python3
"""
reshape_check Python vs Cython 벤치마크 스크립트

사용법 예시:

  # 기본(양성 5k, 음성 5k, 워밍업 1k, 3회 반복 평균)으로 두 구현 비교
  python benchmark_reshape_check.py

  # 데이터 크기/반복 횟수 조절
  python benchmark_reshape_check.py --pos 20000 --neg 20000 --warmup 2000 --repeat 5

  # 특정 구현만 테스트
  python benchmark_reshape_check.py --impls py
  python benchmark_reshape_check.py --impls c

  # 결과만 간단히 (검증 비활성화)
  python benchmark_reshape_check.py --no-check

주의:
- Cython 구현이 아직 빌드되지 않았다면, 첫 실행 시 자동 빌드를 시도합니다.
  빌드 실패 시 C 모드는 건너뜁니다.
"""

from __future__ import annotations

import argparse
import statistics
import sys
import time
import random
from typing import List, Tuple

try:
    from reshape_check import reshape_check, select_parse_impl, get_current_impl
except Exception as e:
    raise SystemExit(f"reshape_check 모듈 임포트 실패: {e}")


# ------------------------- 케이스 생성 유틸 -------------------------
def make_vars(k: int) -> List[str]:
    letters = [chr(i) for i in range(ord("a"), ord("z") + 1)] + [
        chr(i) for i in range(ord("A"), ord("Z") + 1)
    ]
    if k > len(letters):
        raise ValueError("Too many base variables requested")
    return letters[:k]


def random_partition(n: int):
    if n == 0:
        return []
    cuts = [0]
    for i in range(1, n):
        if random.random() < 0.5:
            cuts.append(i)
    cuts.append(n)
    groups = []
    for i in range(len(cuts) - 1):
        if cuts[i] < cuts[i + 1]:
            groups.append((cuts[i], cuts[i + 1]))
    if not groups:
        groups = [(0, n)]
    return groups


def insert_ones(num_slots: int):
    return [random.random() < 0.25 for _ in range(num_slots)]


def fmt_term(var_seq: List[str]) -> str:
    if not var_seq:
        return "1"
    if len(var_seq) == 1:
        return var_seq[0]
    return "(" + " ".join(var_seq) + ")"


def build_side(vars_seq: List[str], groups, ones_before_flags) -> str:
    terms = []
    for idx, (sidx, eidx) in enumerate(groups):
        if ones_before_flags[idx]:
            terms.append("1")
        terms.append(fmt_term(vars_seq[sidx:eidx]))
    if ones_before_flags and random.random() < 0.2:
        terms.append("1")
    return "".join(terms)


def build_shape(values: List[int], groups, ones_before_flags):
    shape = []
    for idx, (sidx, eidx) in enumerate(groups):
        if ones_before_flags[idx]:
            shape.append(1)
        prod = 1
        for v in values[sidx:eidx]:
            prod *= v
        shape.append(prod)
    if ones_before_flags and random.random() < 0.2:
        shape.append(1)
    return tuple(shape)


def gen_positive_case() -> Tuple[str, tuple, tuple, bool]:
    """구성상 참이 되도록 만드는 양성 케이스 (검증 호출 없이 생성)."""
    k = random.choice([1, 2, 3, 4, 5, 6, 7])
    vars_seq = make_vars(k)
    values = [random.randint(1, 9) for _ in range(k)]
    lhs_groups = random_partition(k)
    rhs_groups = random_partition(k)
    lhs_ones = insert_ones(len(lhs_groups))
    rhs_ones = insert_ones(len(rhs_groups))
    lhs_str = build_side(vars_seq, lhs_groups, lhs_ones)
    rhs_str = build_side(vars_seq, rhs_groups, rhs_ones)
    pattern = f"{lhs_str} -> {rhs_str}"
    in_shape = build_shape(values, lhs_groups, lhs_ones)
    out_shape = build_shape(values, rhs_groups, rhs_ones)
    return pattern, in_shape, out_shape, True


def gen_neg_size_mismatch():
    a = random.randint(2, 9)
    b = random.randint(2, 9)
    s = "ab -> (a b)"
    in_shape = (a, b)
    out_shape = (a * b + 1,)
    return (s, in_shape, out_shape, False)


def gen_neg_rank_mismatch():
    a = random.randint(2, 9)
    b = random.randint(2, 9)
    s = "ab -> ab"
    in_shape = (a, b)
    out_shape = (a, b, 1)
    return (s, in_shape, out_shape, False)


def gen_neg_const_term_non1():
    x = random.randint(2, 9)
    s = "a -> 1"
    in_shape = (x,)
    out_shape = (x,)
    return (s, in_shape, out_shape, False)


def gen_neg_var_inconsistency():
    p = random.randint(2, 9)
    q = random.randint(2, 9)
    while q == p:
        q = random.randint(2, 9)
    s = "ab -> ac"
    in_shape = (p, q)
    out_shape = (q, p)
    return (s, in_shape, out_shape, False)


NEG_GENERATORS = [
    gen_neg_size_mismatch,
    gen_neg_rank_mismatch,
    gen_neg_const_term_non1,
    gen_neg_var_inconsistency,
]


def build_dataset(n_pos: int, n_neg: int, seed: int):
    """
    공정 비교를 위해 단일 고정 데이터셋을 생성한다.
    - 양성 케이스는 Python 구현으로 실제 검증하여 True 인 것만 채택한다.
    - 음성 케이스는 구성상 False로 설계되어 있으나, 라벨은 명시적으로 False 로 설정한다.
    """
    random.seed(seed)
    cases = []

    # 현재 구현 상태 저장 후 Python 구현으로 전환해 검증 생성
    try:
        prev = get_current_impl()
    except Exception:
        prev = "py"
    try:
        select_parse_impl("py")
    except Exception:
        # 파이썬 구현 전환 실패는 사실상 없겠지만, 실패 시 그대로 진행
        pass

    # 양성: 실제로 True 가 되는 케이스만 수집
    safety = 0
    while len(cases) < n_pos and safety < n_pos * 100:
        safety += 1
        s, in_shape, out_shape, _ = gen_positive_case()
        if reshape_check(s, in_shape, out_shape):
            cases.append((s, in_shape, out_shape, True))

    # 음성 샘플
    for _ in range(n_neg):
        gen = random.choice(NEG_GENERATORS)
        s, in_shape, out_shape, _ = gen()
        cases.append((s, in_shape, out_shape, False))

    # 기존 구현 복원 시도
    try:
        select_parse_impl(prev)
    except Exception:
        pass

    random.shuffle(cases)
    return cases


# ------------------------- 벤치마크 루틴 -------------------------
def time_impl(cases, impl: str, warmup: int, repeat: int, check: bool):
    # 구현 선택
    try:
        selected = select_parse_impl(impl)
    except Exception as e:
        return {
            "impl": impl,
            "available": False,
            "error": str(e),
        }

    # 워밍업
    w_n = min(warmup, len(cases))
    for i in range(w_n):
        s, inp, out, ans = cases[i]
        _ = reshape_check(s, inp, out)

    # 타이밍: repeat 회 측정 후 평균
    timings = []
    total_checked = 0
    total_errors = 0
    for _ in range(max(1, repeat)):
        t0 = time.perf_counter()
        err = 0
        for s, inp, out, ans in cases:
            res = reshape_check(s, inp, out)
            if check:
                total_checked += 1
                if res != ans:
                    err += 1
        dt = time.perf_counter() - t0
        timings.append(dt)
        total_errors += err

    return {
        "impl": selected,
        "available": True,
        "timings": timings,
        "mean": statistics.fmean(timings),
        "stdev": (statistics.pstdev(timings) if len(timings) > 1 else 0.0),
        "n_cases": len(cases),
        "checked": total_checked,
        "errors": total_errors,
    }


def main():
    ap = argparse.ArgumentParser(description="reshape_check Python/Cython 벤치마크")
    ap.add_argument("--pos", type=int, default=5000, help="양성 케이스 수")
    ap.add_argument("--neg", type=int, default=5000, help="음성 케이스 수")
    ap.add_argument("--seed", type=int, default=20251127, help="랜덤 시드")
    ap.add_argument("--warmup", type=int, default=1000, help="워밍업 호출 수")
    ap.add_argument("--repeat", type=int, default=3, help="반복 측정 횟수")
    ap.add_argument(
        "--impls",
        type=str,
        default="py,c",
        help="테스트할 구현 목록 'py', 'c'를 쉼표로",
    )
    ap.add_argument("--no-check", action="store_true", help="정답 검증 생략")
    args = ap.parse_args()

    cases = build_dataset(args.pos, args.neg, args.seed)
    print(
        f"데이터셋 준비: 총 {len(cases)}개 (양성 {args.pos}, 음성 {args.neg}) | seed={args.seed}"
    )

    impl_list = [x.strip() for x in args.impls.split(",") if x.strip()]
    results = []
    for impl in impl_list:
        print(f"\n[ {impl} ] 구현 선택 및 벤치마크 중...")
        r = time_impl(cases, impl, args.warmup, args.repeat, not args.no_check)
        if not r.get("available"):
            print(f"  - 사용 불가: {r.get('error')}")
            continue
        mean = r["mean"]
        st = r["stdev"]
        n = r["n_cases"]
        cps = n / mean
        print(f"  - 선택됨: {r['impl']}")
        print(f"  - 측정: {args.repeat}회, 평균 {mean:.6f}s (±{st:.6f}), 케이스 {n}개")
        print(f"  - 처리 속도: {cps:.2f} cases/s")
        if not args.no_check:
            print(f"  - 검증: checked={r['checked']} errors={r['errors']}")
        results.append((impl, mean, cps))

    if len(results) >= 2:
        # 간단 속도 비교 요약
        print("\n요약:")
        # py와 c가 모두 있으면 배속 출력
        map_res = {k: (m, s) for k, m, s in results}
        if "py" in map_res and "c" in map_res:
            py_mean, py_cps = map_res["py"]
            c_mean, c_cps = map_res["c"]
            if py_mean > 0:
                speedup = py_mean / c_mean
                print(
                    f"  - Speedup (c vs py): ×{speedup:.2f}  (py {py_cps:.0f} cps → c {c_cps:.0f} cps)"
                )
    print("\n완료.")


if __name__ == "__main__":
    sys.argv.extend(["--pos", "50000"])
    sys.argv.extend(["--neg", "50000"])
    sys.argv.extend(["--repeat", "100"])
    main()
