import importlib
import math

__all__ = ["reshape_check", "select_parse_impl", "get_current_impl"]

import os
import sys

from qbcompiler.logging import get_logger

logger = get_logger(__name__)


def _parse_expr_py(chars: str):
    root = []
    curr = root  # cache
    stack = [root]

    for c in chars:
        if c.isalpha() or c == "1":
            curr.append(c)
        elif c == "(":
            new_group = []
            stack.append(new_group)
            curr = new_group
        elif c == ")":
            if len(stack) == 1:
                raise ValueError(f"Too many closing parentheses: {chars}")
            finished_group = stack.pop()
            if not finished_group:
                raise ValueError(f"Empty parenthesis group is not allowed: {chars}")
            # 부모 그룹(스택의 top)을 다시 현재 작업 대상으로 설정하고 추가
            curr = stack[-1]
            curr.append(finished_group)
        elif c.isspace() or c == ",":
            continue
        else:
            raise ValueError(f"Invalid character '{c}' found in: {chars!r}")

    if len(stack) != 1:
        raise ValueError("Unclosed opening parenthesis: %r" % chars)
    return stack[0]


def _collect_vars_py(ast):
    vars_set = set()
    stack = [ast]
    while stack:
        node = stack.pop()
        if isinstance(node, (list, tuple)):
            stack.extend(node)
        elif isinstance(node, str):
            if node != "1":
                vars_set.add(node)
        else:
            # 알 수 없는 노드 타입은 무시하지 말고 실패 처리
            raise TypeError(f"Invalid AST node: {node!r}")
    return vars_set


def _map_and_assign_py(side_ast, shape, assigned):
    if len(side_ast) != len(shape):
        return None, None  # rank mismatch
    unassigned = []
    for term, dim in zip(side_ast, shape):
        if not isinstance(dim, int):
            if hasattr(dim, "__index__"):
                dim = int(dim)
            else:
                raise TypeError(f"Shape must contain ints, got {dim!r}")
        powers = {}
        stack = [term]
        while stack:
            node = stack.pop()
            if isinstance(node, str):
                if node != "1":
                    powers[node] = powers.get(node, 0) + 1
            elif isinstance(node, list):
                stack.extend(node)
            else:
                raise TypeError(f"Invalid AST node: {node!r}")
        # '1'만 있는 경우는 dim이 반드시 1이어야 함
        if not powers and dim != 1:
            return None, None

        if len(powers) == 1:
            k = next(iter(powers))
            if powers[k] == 1:
                if k in assigned:
                    if assigned[k] != dim:
                        return (
                            None,
                            None,
                        )  # lhs and rhs already have different dim assignment
                else:
                    assigned[k] = dim
                continue
        unassigned.append((powers, dim))
    return unassigned, assigned


# backend function pointers (initialized by select_parse_impl)
_PARSE_EXPR = None
_MAP_AND_ASSIGN = None
_SATISFY_EXPR = None
_COLLECT_VARS = None


def _try_import_cython_impl():
    try:
        from _reshape_check import _parse_expr_c, _map_and_assign_c, _satisfy_equations_pre_assign_c, _collect_vars_c  # type: ignore

        return (
            _parse_expr_c,
            _map_and_assign_c,
            _satisfy_equations_pre_assign_c,
            _collect_vars_c,
        )
    except Exception:
        return None


def _try_pyximport_and_import():
    try:
        import pyximport  # type: ignore

        logger.info(
            "Attempting to build/import reshape_check Cython extension using pyximport..."
        )
        cwd = os.path.dirname(__file__) if "__file__" in globals() else os.getcwd()
        pyx_path = os.path.join(cwd, "_reshape_check.pyx")
        build_dir = os.path.join(cwd, "_pyxbuild")

        # Ensure build directory exists
        os.makedirs(build_dir, exist_ok=True)

        # Make sure package dir is importable
        if cwd not in sys.path:
            sys.path.insert(0, cwd)

        # Clear any previous import and caches
        importlib.invalidate_caches()
        sys.modules.pop("_reshape_check", None)

        # Let pyximport handle compilation to an extension module and import by name
        pyximport.install(language_level=3, build_dir=build_dir, inplace=True)

        mod = importlib.import_module("_reshape_check")

        logger.info(f"Successfully built/imported Cython module: {pyx_path}")
        logger.info(f"Build directory: {build_dir}")
        return (
            getattr(mod, "_parse_expr_c", None),
            getattr(mod, "_map_and_assign_c", None),
            getattr(mod, "_satisfy_expr_c", None),
            getattr(mod, "_collect_vars_c", None),
        )
    except Exception as e:
        logger.info(
            "Failed to load reshape_check Cython extension using pyximport...", e
        )
        return None


def select_parse_impl(impl: str = "auto") -> str:
    impl = (impl or "auto").lower()
    if impl not in ("py", "c", "auto"):
        raise ValueError("impl must be one of {'py','c','auto'}")

    def set_py():
        global _PARSE_EXPR, _MAP_AND_ASSIGN, _SATISFY_EXPR, _COLLECT_VARS
        _PARSE_EXPR = _parse_expr_py
        _MAP_AND_ASSIGN = _map_and_assign_py
        _SATISFY_EXPR = _satisfy_expr_py
        _COLLECT_VARS = _collect_vars_py
        logger.info(
            "Parser is configured to use reshape_check_util (Python implementation)."
        )
        return "py"

    if impl == "py":
        return set_py()

    # try C backend
    c_funcs = _try_import_cython_impl()
    if c_funcs is None and impl in ("c", "auto"):
        c_funcs = _try_pyximport_and_import()
    if c_funcs is not None:
        global _PARSE_EXPR, _MAP_AND_ASSIGN, _SATISFY_EXPR, _COLLECT_VARS
        parse_c, map_c, satisfy_c, collect_c = c_funcs
        _PARSE_EXPR = parse_c
        _MAP_AND_ASSIGN = map_c
        _SATISFY_EXPR = satisfy_c
        _COLLECT_VARS = collect_c
        logger.info(
            "Parser is configured to use reshape_check_util (Cython implementation)."
        )
        return "c"
    if impl == "c":
        logger.info(
            "Cython backend (_reshape_check) not available. fallback to py-impl."
        )
    return set_py()


def get_current_impl() -> str:
    if _PARSE_EXPR is _parse_expr_py:
        return "py"
    return "c"


def parse_reshape_expr(expr: str):
    """
    Parses a string case into an (lhs, rhs) structure.
    - Input format: "<lhs>-><rhs>"
    - lhs/rhs can consist of alphabetic characters, the number '1', and groups formed by parentheses '()'.
    - Return format: (lhs_ast, rhs_ast)
      where 'ast' is a list with the following recursive structure:
        - Characters (single alphabet letter or '1') are stored as str.
        - Parenthesis groups are stored as list, containing elements following the same rules.

    Example:
      "nhwc->n(hw)c" => (
          ['n', 'h', 'w', 'c'],
          ['n', ['h', 'w'], 'c']
      )
    """

    if not isinstance(expr, str):
        raise TypeError("parse(s): s must be str")
    parts = expr.split("->", 1)
    if len(parts) != 2:
        raise ValueError(f"Input missing '->' separator: {expr}")
    return _PARSE_EXPR(parts[0]), _PARSE_EXPR(parts[1])


def _satisfy_expr_py(active_equations, assign):
    """
    Try to find a consistent assignment for variables to satisfy equations.
    Optimized to remove solved equations from the pool and perform checks inline.
    """
    while True:
        progressed = False
        next_active = []

        for vp, target in active_equations:
            # Calculate current product from knowns
            known_prod = 1
            unknowns = []
            for v, p in vp.items():
                if v in assign:
                    known_prod *= assign[v] ** p
                else:
                    unknowns.append((v, p))

            # Divisibility check (Fail early)
            if target % known_prod != 0:
                return False

            residual = target // known_prod

            if not unknowns:
                if residual != 1:
                    return False
                continue

            if len(unknowns) == 1:
                v, p = unknowns[0]
                if p == 1:
                    val = residual
                else:
                    # to deal with something like n(ww)c = (1,9,256)
                    # Integer p-th root check
                    # Using float approximation is much faster than binary search for typical sizes
                    try:
                        root = int(residual ** (1 / p))
                    except Exception:
                        # Fallback or fail for extremely large numbers
                        return False
                    if root**p == residual:
                        val = root
                    elif (root + 1) ** p == residual:
                        val = root + 1
                    else:  # No integer root exists
                        return False
                if v in assign:  # dimension mismatch! terminate
                    if assign[v] != val:
                        return False
                else:
                    assign[v] = val
                    progressed = True
                continue

            # Multiple unknowns: keep for next pass
            # We already checked divisibility (target % known_prod == 0)
            next_active.append((vp, target))

        if not progressed:
            break
        active_equations = next_active
        if not active_equations:
            return True

    return True


def reshape_check(expr: str, in_shape, out_shape) -> bool:
    prod_in = math.prod(map(int, in_shape))
    prod_out = math.prod(map(int, out_shape))
    if prod_in != prod_out:
        return False
    if not isinstance(expr, str):
        return False
    try:
        ast_left, ast_right = parse_reshape_expr(expr)
    except Exception as e:
        return False
    if _COLLECT_VARS(ast_left) != _COLLECT_VARS(ast_right):
        return False

    var_left_unassigned, assigned = _MAP_AND_ASSIGN(ast_left, in_shape, {})
    if var_left_unassigned is None:
        return False
    var_right_unassigned, assigned = _MAP_AND_ASSIGN(ast_right, out_shape, assigned)
    if var_right_unassigned is None:
        return False
    unassiged = var_left_unassigned + var_right_unassigned
    ok = _SATISFY_EXPR(unassiged, assigned)
    return ok


# 모듈 로드 시 기본은 'auto'로 선택 (모든 파이썬 구현이 정의된 이후 실행)
try:
    # fixme: 일단 테스트 끝나기 전까지 py로 유지
    # select_parse_impl("auto")
    select_parse_impl("py")
except Exception:
    # fallback to python implementation
    _PARSE_EXPR = _parse_expr_py
    _MAP_AND_ASSIGN = _map_and_assign_py
    _SATISFY_EXPR = _satisfy_expr_py
    _COLLECT_VARS = _collect_vars_py
