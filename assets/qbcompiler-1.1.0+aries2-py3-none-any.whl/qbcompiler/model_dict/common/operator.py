import dataclasses
from typing import Union, List

from .dtypes import int64
from .options import LayerOptions, Registry, LayerType


class Operator:
    _serialize_keys = {
        "name": "name",
        "_options": "options",
        "unsupported": "unsupported",
        "next_operators": "next_operators",
    }

    def __init__(
        self,
        name: str,
        options: LayerOptions,
        unsupported: bool = True,
        next_operators: Union[List[int64]] = None,
        fused_activation_function: str = "NONE",
        output_value_reference=None,
        op_transform_generated_reshape=False,
    ) -> None:
        if next_operators is None:
            next_operators = []

        self.name: str = name
        self._options: LayerOptions = self._get_options(options)
        self.unsupported: bool = unsupported
        self.next_operators: List[int64] = list(next_operators)  # OUTPUT

        # helper attributes for intermediate parsing steps.
        self.fused_activation_function: str = fused_activation_function
        self.valid = True
        self.subgraph_idx = -1
        self.idx = -1
        self.output_value_reference = output_value_reference
        self.op_transform_generated_reshape = op_transform_generated_reshape
        self.concat_group = -1

    def is_optype(self, layertype: LayerType) -> bool:
        return self.layertype == layertype

    @property
    def serialize_keys(self):
        return self._serialize_keys

    @property
    def options(self):
        return self._options

    def _get_options(self, options):
        if isinstance(options, dict):
            option_type = options.pop("type")
            option_cls = Registry.getcls(option_type[:-7])
            if option_type == "LayerNormalizationOptions" and "norm_axis" in options:
                options.pop("norm_axis")
            return self._get_options(option_cls(**options))
        elif isinstance(options, LayerOptions):
            if Registry.get_option_type(options) == LayerType.Input:
                if options.inputs != options.outputs:
                    return dataclasses.replace(options, inputs=options.outputs)
            elif Registry.get_option_type(options) == LayerType.Output:
                if options.inputs != options.outputs:
                    return dataclasses.replace(options, outputs=options.inputs)
            return options
        else:
            raise NotImplementedError(f"`{options}` NotImplemented")

    @options.setter
    def options(self, options: LayerOptions):
        self._options = self._get_options(options)

    def __repr__(self):
        return f"{self.layertype.name}[{self.options.inputs}->{self.options.outputs}, {self.name}]"

    @property
    def layertype(self) -> LayerType:
        return Registry.get_option_type(self.options)

    @property
    def outputs(self) -> List:
        return self.options.outputs

    @property
    def inputs(self) -> List:
        return self.options.inputs
