import dataclasses
import enum
import typing
from typing import Union

import numpy
import torch

_CODE_SHOULD_NOT_BE_REACHED = RuntimeError("code should not be reached!")


def _type_unmachted_error(value, dtype, name):
    return TypeError(
        f"The value `{value}` of type {type(value)} assigned to the field `{name}` of type `{dtype}`"
    )


"""this module defines basic dtypes, aliases and provides strict type checks.
"""

__all__ = [
    "int8",
    "int16",
    "int32",
    "int64",
    "float32",
    "float64",
    "uint8",
    "uint32",
    "uint64",
    "TypeEnforced",
    "TensorIndex",
    "Symbol",
    "parse_annotation",
    "parse_dataclass_annotations",
    "symbol_to_type",
    "type_to_symbol",
    "is_signed_int_types",
    "is_uint_types",
    "is_floating_types",
    "dtype_to_torchformat",
    "get_dtype_str",
]


class TensorIndex(int):
    """
    This type definition makes it clear if a field represents a tensor and facilitates
    easy implementation of tensor handling routines.
    For example, we prefer `weight: TensorIndex` over `weight: int64`.
    """

    def __new__(cls, value, *args, **kwargs):
        return super().__new__(cls, value)

    def __repr__(self):
        return f"TensorIndex({int(self)})"


int8 = numpy.int8
int16 = numpy.int16
int32 = numpy.int32
int64 = numpy.int64

float32 = numpy.float32
float64 = numpy.float64

uint8 = numpy.uint8
uint32 = numpy.uint32
uint64 = numpy.uint64


class Symbol(enum.Enum):
    NoneType = enum.auto()
    Ellipsis = enum.auto()
    bool = enum.auto()
    int = enum.auto()
    float = enum.auto()
    str = enum.auto()
    list = enum.auto()
    tuple = enum.auto()
    union = enum.auto()

    #     numpy types
    int8 = enum.auto()
    int16 = enum.auto()
    int32 = enum.auto()
    int64 = enum.auto()

    uint8 = enum.auto()
    uint32 = enum.auto()
    uint64 = enum.auto()

    float32 = enum.auto()
    float64 = enum.auto()
    # defined type
    TensorIndex = enum.auto()


def is_value_type(s: Symbol):
    return s not in (
        Symbol.NoneType,
        Symbol.Ellipsis,
        Symbol.list,
        Symbol.tuple,
        Symbol.union,
    )


_SYMBOL_TO_TYPE = {
    Symbol.NoneType: None,
    Symbol.bool: bool,
    Symbol.str: str,
    Symbol.list: list,
    Symbol.tuple: tuple,
}

_SYMBOL_TO_TYPE_SIGNED_INT = {
    Symbol.int: int,
    Symbol.int8: numpy.int8,
    Symbol.int16: numpy.int16,
    Symbol.int32: numpy.int32,
    Symbol.int64: numpy.int64,
}
_SYMBOL_TO_TYPE_UNSIGNED_INT = {
    Symbol.uint8: numpy.uint8,
    Symbol.uint32: numpy.uint32,
    Symbol.uint64: numpy.uint64,
}
_SYMBOL_TO_TYPE_FLOATING = {
    Symbol.float: float,
    Symbol.float32: numpy.float32,
    Symbol.float64: numpy.float64,
}
_SYMBOL_TO_TYPE.update(_SYMBOL_TO_TYPE_SIGNED_INT)
_SYMBOL_TO_TYPE.update(_SYMBOL_TO_TYPE_UNSIGNED_INT)
_SYMBOL_TO_TYPE.update(_SYMBOL_TO_TYPE_FLOATING)


_TYPE_TO_SYMBOL = {
    v.__name__: k for k, v in _SYMBOL_TO_TYPE.items() if k != Symbol.NoneType
}


def is_signed_int_types(s: Symbol):
    return s in _SYMBOL_TO_TYPE_SIGNED_INT


def is_uint_types(s: Symbol):
    return s in _SYMBOL_TO_TYPE_UNSIGNED_INT


def is_floating_types(s: Symbol):
    return s in _SYMBOL_TO_TYPE_FLOATING


def _tuple_to_symbol(t):
    v = tuple(annotations_to_symbol(x) for x in t)
    return v


def _typing_genericalias_to_symbol(t):
    name, args_t = t._name, t.__args__
    if name == "List":
        if len(args_t) == 0 or str(args_t[0]) == "~T":
            return (Symbol.list,)
        return Symbol.list, annotations_to_symbol(args_t)
    if name == "Tuple":
        if len(args_t) == 0:
            return Symbol.tuple
        v = annotations_to_symbol(args_t)
        return Symbol.tuple, v

    if name == "Optional":
        # typing.Optional python version 3.10
        return Symbol.union, annotations_to_symbol(args_t)
    if name is None:
        # typing.Optional python version 3.8
        if str(t).startswith("typing.Union") or str(t).startswith("Union"):
            return Symbol.union, annotations_to_symbol(args_t)
    raise NotImplementedError(str(t))


def type_to_symbol(t, value=None):
    if t.__name__ == "NoneType":
        return Symbol.NoneType
    if t.__name__ == "TensorIndex":
        return Symbol.TensorIndex
    return _TYPE_TO_SYMBOL[t.__name__]


def symbol_to_type(s):
    if s in _SYMBOL_TO_TYPE:
        return _SYMBOL_TO_TYPE[s]
    raise NotImplementedError(s)


def annotations_to_symbol(t):
    if isinstance(t, Symbol):
        return t
    if str(t) == "Ellipsis":
        return Symbol.Ellipsis
    if str(t) == "typing.Tuple":  # due to the typing version issue
        return Symbol.tuple
    if isinstance(t, tuple):
        v = _tuple_to_symbol(t)
        return v
    if isinstance(t, type):
        return type_to_symbol(t)
    if isinstance(t, typing._GenericAlias):
        v = _typing_genericalias_to_symbol(t)
        return v
    raise NotImplementedError(t)


def parse_annotation(field_annotation):
    return annotations_to_symbol(field_annotation)


def parse_dataclass_annotations(obj):
    if not dataclasses.is_dataclass(obj):
        return TypeError("obj is not a dataclass.")

    annotations = obj.__annotations__
    dct = {}
    for k, v in annotations.items():
        dct[k] = annotations_to_symbol(v)

    return dct


def symbol_to_type_wrapper(symbol: Symbol):
    if symbol == Symbol.TensorIndex:
        return TensorIndex
    return symbol_to_type(symbol)


def _get_value_if_numarr(value):
    if isinstance(value, numpy.ndarray):
        if len(value.shape) == 0 and value.size == 1:
            if numpy.issubdtype(value.dtype, numpy.integer):
                return value.item()
            if numpy.issubdtype(value.dtype, numpy.floating):
                return value.item()
        if value.shape == (1,) and value.size == 1:
            return value[0]
    return value


def _int_casting_rules(value, dtype):
    return (is_signed_int_types(dtype) or is_uint_types(dtype)) and numpy.issubdtype(
        type(value), numpy.integer
    )


def _float_casting_rules(value, dtype):
    return is_floating_types(dtype) and (
        numpy.issubdtype(type(value), numpy.floating)
        or numpy.issubdtype(type(value), numpy.integer)
    )


def coercion_(value, dtype, field_name):
    def _dim_value_to_int(v):
        if v.__class__.__name__ == "DimValue":
            v = int(v)
        return v

    if isinstance(value, tuple):
        value = tuple(_dim_value_to_int(x) for x in value)
    elif isinstance(value, list):
        value = list(_dim_value_to_int(x) for x in value)
    else:
        value = _dim_value_to_int(value)

    if isinstance(dtype, tuple):
        if len(dtype) == 1:
            raise NotImplementedError
        if dtype[0] == Symbol.tuple:
            args_t = dtype[1]
            if Symbol.Ellipsis in args_t:
                args_t = tuple(
                    symbol_to_type_wrapper(args_t[0]) for _ in range(len(value))
                )
            else:
                args_t = tuple(symbol_to_type_wrapper(x) for x in args_t)
            if len(value) != len(args_t):
                raise ValueError(
                    f"number of items are different for field `{field_name}`: {value}, {args_t}"
                )
            return tuple(item_t(item) for item, item_t in zip(value, args_t))
        if dtype[0] == Symbol.list:
            args_t = dtype[1]
            args_t = tuple(symbol_to_type_wrapper(args_t[0]) for _ in range(len(value)))
            return list(item_t(item) for item, item_t in zip(value, args_t))

        if dtype[0] == Symbol.union:
            if Symbol.NoneType in dtype[1]:
                if value is None:
                    return value
                if len(dtype[1]) > 2:
                    raise NotImplementedError(dtype)
                return coercion_(value, dtype[1][0], field_name)
            raise NotImplementedError
        raise NotImplementedError
    # here we define casting rules.
    value = _get_value_if_numarr(value)
    if dtype == Symbol.tuple:
        if isinstance(value, list) and len(value) == 0:
            return tuple()
    if dtype == Symbol.str:
        return value
    if dtype == Symbol.TensorIndex:
        return TensorIndex(value)
    if dtype == Symbol.bool and value in (0, 1):
        return bool(value)
    if _int_casting_rules(value, dtype):
        return symbol_to_type_wrapper(dtype)(value)
    if _float_casting_rules(value, dtype):
        return symbol_to_type_wrapper(dtype)(value)
    return value


def _check_primitive(value, dtype, name):
    if not isinstance(value, dtype):
        raise _type_unmachted_error(value, dtype, name)


def _interprete_tuple_arg_types(dtype, num_values):
    if Symbol.Ellipsis in dtype:
        return tuple(symbol_to_type_wrapper(dtype[0]) for _ in range(num_values))
    else:
        return tuple(symbol_to_type_wrapper(x) for x in dtype)


def get_value_type(value):
    sym = type_to_symbol(type(value), value)
    if sym in (Symbol.list, Symbol.tuple):
        if value:
            return sym, (get_value_type(value[0]),)
        return sym
    if sym in (Symbol.Ellipsis, Symbol.union):
        raise _CODE_SHOULD_NOT_BE_REACHED
    return sym


def _check_tuple(value, dtype, name):
    if not isinstance(value, tuple):
        raise _type_unmachted_error(value, dtype, name)
    if not value:  # vacuous truth
        return
    if Symbol.Ellipsis in dtype:
        dtype = [dtype[0] for _ in range(len(value))]
    val_t = [get_value_type(v) for v in value]
    if len(dtype) == len(val_t) and all(vt == dt for vt, dt in zip(val_t, dtype)):
        return


def _check_list(value, dtype, name):
    if not isinstance(value, list):
        raise _type_unmachted_error(value, dtype, name)

    if not value:
        return
    if all(get_value_type(v) == dtype[0] for v in value):
        return


def _check_union(value, dtype, name):
    # to deal with union(typexx, NoneType)
    # we do not allow union types such as union[int32, float32]
    if Symbol.NoneType in dtype[1]:
        if len(dtype[1]) > 2:
            raise _CODE_SHOULD_NOT_BE_REACHED
        if value is None:
            return
        check_type(value, dtype[1][0], name)
    else:
        raise _CODE_SHOULD_NOT_BE_REACHED


def check_type(value, dtype, name):
    if isinstance(dtype, tuple):
        if len(dtype) == 1:
            raise _CODE_SHOULD_NOT_BE_REACHED
        if dtype[0] == Symbol.tuple:
            _check_tuple(value, dtype[1], name)
        elif dtype[0] == Symbol.list:
            _check_list(value, dtype[1], name)
        elif dtype[0] == Symbol.union:
            _check_union(value, dtype, name)
        else:
            raise _type_unmachted_error(value, dtype, name)
    else:
        if not get_value_type(value) == dtype:
            raise _type_unmachted_error(value, dtype, name)


def get_dtype_str(data: Union[torch.Tensor, numpy.ndarray]):
    if isinstance(data, torch.Tensor):
        # torch.dtype string looks like 'torch.float32'; normalize to 'float32'
        return str(data.dtype).split(".")[-1]
    elif isinstance(data, numpy.ndarray) or isinstance(data, numpy.generic):
        # numpy dtypes stringify to 'float32', 'int64', etc.
        return str(numpy.dtype(data.dtype))
    else:
        raise TypeError(f"Cannot get dtype string for type={type(data)}")


def dtype_to_torchformat(dtype: str):
    if isinstance(dtype, torch.dtype):
        return dtype
    # Accept string or numpy.dtype and map safely to torch.dtype
    if isinstance(dtype, numpy.dtype):
        key = str(dtype)
    elif isinstance(dtype, str):
        key = dtype
    else:
        raise TypeError(f"Unsupported dtype type: {type(dtype)}")

    # Normalize common aliases
    aliases = {
        "float": "float32",
        "double": "float64",
        "half": "float16",
        "long": "int64",
        "int": "int32",
        "short": "int16",
        "byte": "uint8",
        "char": "int8",
    }
    key = aliases.get(key, key)
    td = getattr(torch, key, None)
    if isinstance(td, torch.dtype):
        return td
    raise ValueError(f"Unknown torch dtype: {dtype}")


@dataclasses.dataclass
class TypeEnforced:
    # implement recursive onnx_parser if there is a need for more complex types.

    @classmethod
    def summary(cls):
        attr = []
        for k, v in cls.__annotations__.items():
            if hasattr(v, "__name__"):
                attr.append((k, v.__name__))
            else:
                attr.append((k, str(v).replace("numpy.", "").replace("typing.", "")))
        return {"name": cls.__name__[:-7], "attributes": attr}

    def __post_init__(self):
        for field_name, field_value in self.__annotations__.items():
            parsed = parse_annotation(field_value)
            value = self.__dict__[field_name]
            try:
                self.__dict__[field_name] = coercion_(value, parsed, field_name)
            except Exception as e:
                import re

                expected = re.sub(
                    r"(numpy\.|typing\.)(?!ndarray)", "", str(field_value)
                )
                raise TypeError(
                    f"Attempted to set {self.__class__.__name__}.{field_name} with value={value}, but expected={expected}."
                )
            check_type(self.__dict__[field_name], parsed, field_name)
