import math
from typing import List, Dict, Any

import numpy

from qbcompiler.model_dict.common import DataFormat
from qbcompiler.model_dict.common.buffer import NaiveBuffer, MmapBuffer
from qbcompiler.model_dict.common.dtypes import int64
from qbcompiler.model_dict.common.item_specs import TensorSpec
from qbcompiler.model_dict.common.subgraph import SubGraph
from qbcompiler.model_dict.common.value_wrapper import ValueWrapper


class ValueDict:
    def __init__(self):
        self._value_dict = {}
        self._dataformats = {}

    def add(self, name: str, value, dataformat: DataFormat = DataFormat.UNKNOWN):
        self._value_dict[name] = value
        self._dataformats[name] = dataformat

    def get_value(self, name):
        return self._value_dict[name]

    def get_dataformat(self, name, default=DataFormat.UNKNOWN):
        return self._dataformats.get(name, default)

    def update_dataformat(self, name, dformat):
        self._dataformats[name] = dformat

    def __getitem__(self, item):
        return self._value_dict[item]

    def __setitem__(self, key, value):
        self._value_dict[key] = value
        self._dataformats[key] = DataFormat.UNKNOWN

    def __len__(self):
        return len(self._value_dict)

    def __contains__(self, item):
        return item in self._value_dict

    def __iter__(self):
        return iter(self._value_dict)

    def items(self):
        return self._value_dict.items()

    def keys(self):
        return self._value_dict.keys()

    def values(self):
        return self._value_dict.values()

    def update(self, other):
        self._value_dict.update(other)


class WeightDict:
    def __init__(self, max_buffer_size=2**32, buffer_mode=1):
        self._weight_dict = {}  # (weight_name, weight)
        self._tensorspec = {}  # (weight_name, tensor_spec)
        self._max_buffer_size = max_buffer_size

        self.weight_buffer_info = []
        self.num_buffers = 0
        self.last_buffer_size = 0
        self._buffer_mode = buffer_mode

        self._buffer = None
        self._all_tensor_names = set()

    def items(self):
        return self._weight_dict.items()

    def keys(self):
        return self._weight_dict.keys()

    def __contains__(self, name: str):
        return name in self._weight_dict

    def set_weights(self, wd: Dict):
        self._weight_dict = wd

    def set_buffer(self, buffer):
        self._buffer = buffer

    @property
    def buffer(self):
        return self._buffer

    def set_mmap_mode(self, path_to_buffer_file):
        self._buffer.set_mmap_read_mode(path_to_buffer_file)

    @property
    def max_buffer_size(self):
        return self._max_buffer_size

    @property
    def buffer_mode(self):
        return self._buffer_mode

    def get_weight(self, ts: TensorSpec) -> numpy.ndarray:
        return numpy.frombuffer(
            self._buffer.read_bytes(ts.buffer_idx, ts.offset, ts.tensorsize),
            dtype=ts.dtype,
        ).reshape(ts.shape)

    def get_tensors(self, compute_tensor_idx=False):
        tensors = [
            TensorSpec(name=k, shape=tuple(v.shape), dtype=str(v.dtype))
            for k, v in self._weight_dict.items()
            if v is not None
        ]
        if compute_tensor_idx:
            self.compute_weight_buffer_info()
            buff_info = {wbi[0]: wbi[1:] for wbi in self.weight_buffer_info}
            for ts in tensors:
                ts.buffer_idx, ts.offset = buff_info[ts.name]
        return tensors

    def close(self):
        self._buffer.close()

    def get_weight_by_name(self, weight_name):
        if weight_name in self._weight_dict:
            v = self._weight_dict[weight_name]
        elif weight_name in self._tensorspec:
            v = self.get_weight(self._tensorspec[weight_name])
        else:
            raise ValueError(f"weight not found!: {weight_name}")
        if isinstance(v, ValueWrapper):
            v = v.value
        return v

    def add_weight(self, weight_name, weight_val, overwrite=False):
        if weight_name in self._weight_dict:
            if not overwrite:
                raise KeyError(
                    f"{weight_name},{weight_val} already exists in weight dict."
                )
        self._weight_dict[weight_name] = weight_val

    def __setitem__(self, key, value):
        self.add_weight(key, value)

    def isin(self, weight_name):
        return weight_name in self._weight_dict

    def get_valid_tensor_name(self, candidate: str):
        i = 0
        while True:
            nc = candidate + "_" + str(i)
            if nc not in self._weight_dict:
                return nc
            i += 1

    @staticmethod
    def from_bytes(
        tensors: List[TensorSpec],
        buffer_mode,
        buffer_file_path,
        max_buffer_size,
        last_buffer_size,
        num_buffers,
    ):
        wd = WeightDict(max_buffer_size=max_buffer_size, buffer_mode=buffer_mode)
        if buffer_mode == 0:
            bf = NaiveBuffer(
                buffer_file_path, max_buffer_size, last_buffer_size, num_buffers
            )
        elif buffer_mode == 1:
            bf = MmapBuffer(
                buffer_file_path, max_buffer_size, last_buffer_size, num_buffers
            )
        else:
            raise NotImplementedError
        wd.set_buffer(bf)

        for ts in tensors:
            wd._tensorspec[ts.name] = ts

        return wd

    def compute_weight_buffer_info(self):
        def weight_bsize(v):
            if len(v.shape) == 0:
                return numpy.dtype(v.dtype).itemsize
            return math.prod(map(int, v.shape)) * numpy.dtype(v.dtype).itemsize

        curr_buff_idx = 0
        curr_buff_len = 0
        weights_info = []  # list of (weight_name, start_buffer_idx, offset)
        total_weight_size = 0
        for k, w in self._weight_dict.items():
            if w is None:
                # weights_info.append((k, -1, 0))
                continue
            weight_size = weight_bsize(w)
            total_weight_size += weight_size
            weights_info.append((k, curr_buff_idx, curr_buff_len))
            while weight_size > 0:
                wsize = min(weight_size, self.max_buffer_size - curr_buff_len)
                curr_buff_len += wsize
                weight_size -= wsize
                if curr_buff_len == self.max_buffer_size:
                    curr_buff_idx += 1
                    curr_buff_len = 0
            if weight_size != 0:
                raise Exception(f"weight size!={weight_size}")

        self.weight_buffer_info = weights_info

        q, r = divmod(total_weight_size, self._max_buffer_size)
        self.num_buffers = q if r == 0 else q + 1
        self.last_buffer_size = self._max_buffer_size if r == 0 else r


class ModelDict:
    def __init__(self):
        self.model_backend = ""
        self.source_file = ""
        self.hw_type = ""
        self.inputs: List[str] = []  # model_input_list
        self.outputs: List[str] = []  # model_output_list
        self.subgraphs: List[SubGraph] = []  # group_info
        self.graph_order: List[int64] = [0]  # group_order
        self.activation_trace: Dict[
            str, Any
        ] = {}  # activation origin information (name, src_shape)
        self._main_sg_idx = 0

    def set_main_sg(self, idx: int):
        self._main_sg_idx = idx

    def sg_main(self):
        return self.subgraphs[self._main_sg_idx]

    def opset(self):
        lst = []
        for sg in self.subgraphs:
            for op in sg.operators:
                if op.layertype.name not in lst:
                    lst.append(op.layertype.name)
        return lst

    def get_subgraph_by_name(self, subgraph_name: str):
        for sg in self.subgraphs:
            if sg.name == subgraph_name:
                return sg
        return None

    def set_hw_device(self, target_device):
        self.hw_type = str(target_device.name).lower()

    @staticmethod
    def from_dict(data):
        from types import SimpleNamespace

        ns = SimpleNamespace(**data)
        md = ModelDict()

        for k, v in ns.__dict__.items():
            if k == "subgraphs":
                v = [SubGraph.from_dict(x) for x in v]
            setattr(md, k, v)

        return md

    def _parse_info(self, info):
        for group_info in info["group_info_list"]:
            sg = SubGraph()
            self.subgraphs.append(sg)

    def set_output_value_reference(self, value_dict: ValueDict):
        if not value_dict:
            return
        for sg in self.subgraphs:
            for op in sg.operators:
                if op.output_value_reference is not None:
                    continue
                if len(op.options.outputs) == 1:
                    oact = sg.activations[op.options.outputs[0]]
                    if oact.name in value_dict:
                        op.output_value_reference = oact.name
                else:
                    lst = []
                    for oidx in op.options.outputs:
                        oact = sg.activations[oidx]
                        if oact.name in value_dict:
                            lst.append(oact.name)
                        else:
                            lst.append(None)
                    if any(x is not None for x in lst):
                        op.output_value_reference = lst

    def get_body_model_dict(self, weight_dict: WeightDict):
        num_operators = 0
        idx = -1
        for order in self.graph_order:
            sg = self.subgraphs[order]
            if not sg.unsupported:
                if sg.num_operators >= num_operators:
                    num_operators = sg.num_operators
                    idx = order
            else:
                pass

        if idx == -1:
            raise ValueError("All subgraphs are unsupported")

        sg = self.subgraphs[idx]
        single_weight_dict = WeightDict()
        for ts in sg.tensors:
            weight_val = weight_dict.get_weight_by_name(ts.name)
            single_weight_dict.add_weight(ts.name, weight_val)

        inputs = [sg.activations[iidx].name for iidx in sg.inputs]
        outputs = [sg.activations[oidx].name for oidx in sg.outputs]

        model_dict = ModelDict()

        model_dict.model_backend = self.model_backend
        model_dict.source_file = self.source_file
        model_dict.inputs = inputs
        model_dict.outputs = outputs
        model_dict.subgraphs = [sg]
        model_dict.graph_order = [0]
        model_dict.activation_trace = self.activation_trace

        for act in sg.activations:
            if act.name in self.activation_trace:
                model_dict.activation_trace[act.name] = self.activation_trace[act.name]

        return model_dict, single_weight_dict

    def get_all_seperated_model_dicts(self, weight_dict: WeightDict):
        seperated_model_dicts = []
        seperated_weight_dicts = []

        for sg in self.subgraphs:
            single_weight_dict = WeightDict()
            for ts in sg.tensors:
                weight_val = weight_dict.get_weight_by_name(ts.name)
                single_weight_dict.add_weight(ts.name, weight_val)

            inputs = [sg.activations[iidx].name for iidx in sg.inputs]
            outputs = [sg.activations[oidx].name for oidx in sg.outputs]

            single_model_dict = ModelDict()

            single_model_dict.model_backend = self.model_backend
            single_model_dict.source_file = self.source_file
            single_model_dict.inputs = inputs
            single_model_dict.outputs = outputs
            single_model_dict.subgraphs = [sg]
            single_model_dict.graph_order = [0]
            single_model_dict.activation_trace = self.activation_trace

            seperated_model_dicts.append(single_model_dict)
            seperated_weight_dicts.append(single_weight_dict)

        return seperated_model_dicts, seperated_weight_dicts

    def get_act_origin_name(self, name, default=None):
        if name in self.activation_trace:
            return self.activation_trace[name][0]
        return default

    def get_act_origin_shape(self, name):
        if name in self.activation_trace:
            return self.activation_trace[name][1]
        return None

    def rearrange_subgraphs(self):
        original_order = list(self.graph_order)
        order_set = set(original_order)

        main_subgraph = [self.subgraphs[i] for i in original_order]
        sequential_subgraph = [
            sg for idx, sg in enumerate(self.subgraphs) if idx not in order_set
        ]

        self.subgraphs = main_subgraph + sequential_subgraph
        self.graph_order = list(range(len(main_subgraph)))

        for idx, sg in enumerate(self.subgraphs):
            if idx < len(self.graph_order):
                sg.name = f"sg_{idx}"
            sg.idx = idx

    def single_subgraph_inout_order(self):
        if len(self.subgraphs) == 1:
            subgraph = self.subgraphs[0]
            subgraph_input_names = [
                subgraph.activations[iidx].name for iidx in subgraph.inputs
            ]
            subgraph_output_names = [
                subgraph.activations[oidx].name for oidx in subgraph.outputs
            ]
            if set(subgraph_input_names) == set(self.inputs) and set(
                subgraph_output_names
            ) == set(self.outputs):
                subgraph.inputs = subgraph.get_act_indices(self.inputs)
                subgraph.outputs = subgraph.get_act_indices(self.outputs)
            else:
                self.inputs = subgraph_input_names
                self.outputs = subgraph_output_names
        else:
            pass
