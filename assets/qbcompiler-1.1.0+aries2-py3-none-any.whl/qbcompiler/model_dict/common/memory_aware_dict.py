import gc
import pathlib
import shutil
from os import PathLike
from types import BuiltinFunctionType, BuiltinMethodType
from typing import Optional, Union

import numpy
import torch

_ARRAY_TYPE_MAP = {numpy.ndarray: 0, torch.Tensor: 1}
_ARRAY_TYPES = tuple(_ARRAY_TYPE_MAP.keys())
_PRIMITIVE_TYPES = (int, str, float, bool, type(None))
_TORCH_SPECIAL_TYPES = (
    torch.dtype,
    torch.device,
    torch.Size,
    BuiltinFunctionType,
    BuiltinMethodType,
)

_DIRECTLY_STORE_TYPES = _PRIMITIVE_TYPES + _TORCH_SPECIAL_TYPES


class MemoryAwareDict(dict):
    def __init__(self, temp_dir, threshold_mb=None):
        super().__init__()
        if threshold_mb is None:
            if torch.cuda.is_available():
                total_memory = torch.cuda.get_device_properties(0).total_memory
                threshold_mb = (total_memory * 0.9) / (1024 * 1024)  # 85% in MB
            else:
                threshold_mb = 10 * 1024  # Default 10GB if no CUDA
        self.threshold_mb = threshold_mb
        self.temp_dir = self._make_unique_folder(temp_dir)
        if self.temp_dir is None:
            raise ValueError("Failed to create temporary directory")

    def _make_unique_folder(self, base_path: str) -> str:
        base = pathlib.Path(base_path)
        if base.exists():
            shutil.rmtree(base)
        base.mkdir(parents=True, exist_ok=True)
        return str(base)

    def _check_and_manage_memory(self):
        if torch.cuda.is_available():
            current_memory = torch.cuda.memory_allocated() / (1024 * 1024)
            if current_memory > self.threshold_mb:
                print(f"curr memory: {current_memory} / {self.threshold_mb}")
                # First, try moving CUDA tensors to CPU
                for k, v in self.items():
                    if (
                        isinstance(v, ArrayWrapper)
                        and v.is_torch
                        and v._state == "cuda"
                    ):
                        print(f"Moving `{k}` to CPU")
                        v.to_cpu()
                # If still over threshold, write to file and release
                # But only write tensors that were originally on CUDA
                torch.cuda.empty_cache()
                torch.cuda.synchronize()
                current_memory = torch.cuda.memory_allocated() / (1024 * 1024)
                if current_memory > self.threshold_mb:
                    for k, v in self.items():
                        if (
                            isinstance(v, ArrayWrapper)
                            and v.is_loaded_in_memory()
                            and v.is_torch
                            and v.device is not None
                            and "cuda" == v._state
                        ):  # Only write if originally on CUDA
                            print(f"Write `{k}` to file (was originally on CUDA).")
                            v.write_to_file_and_release()
                            gc.collect()

                # Final CUDA cache cleanup
                torch.cuda.empty_cache()
                torch.cuda.synchronize()
                current_memory = torch.cuda.memory_allocated() / (1024 * 1024)
                print(f"final memory: {current_memory} / {self.threshold_mb}")

    def _get_unique_path(self, key: str, suffix: str = "") -> str:
        if self.temp_dir is None:
            raise ValueError("Temporary directory is not initialized")
        filename = f"{key}.pt"
        return str(pathlib.Path(self.temp_dir).joinpath(filename))

    def _is_tensor(self, obj) -> bool:
        return isinstance(obj, (torch.Tensor, numpy.ndarray))

    def _process_tensor(
        self, tensor: Union[torch.Tensor, numpy.ndarray], path: str
    ) -> "ArrayWrapper":
        wrapper = ArrayWrapper(tensor, path=path)
        # Keep tensor in memory initially - only write to file when memory threshold is exceeded
        return wrapper

    def _process_recursively(self, obj, base_key: str):
        """
        Recursively process containers, wrapping tensors with ArrayWrapper
        while preserving the original structure
        """

        if isinstance(obj, _ARRAY_TYPES):
            try:
                path = self._get_unique_path(base_key)
            except Exception as e:
                print(f"Error creating unique path for {base_key}: {e}")
                return obj
            return self._process_tensor(obj, path)
        elif isinstance(obj, _DIRECTLY_STORE_TYPES):
            return obj
        elif hasattr(obj, "value"):
            # Handle objects with .value attribute
            value = obj.value
            if value is None:
                return None  # ValueNotSet case
            return self._process_recursively(value, base_key)
        elif isinstance(obj, dict):
            processed_dict = {}
            for k, v in obj.items():
                processed_dict[k] = self._process_recursively(v, f"{base_key}_{k}")
            return processed_dict
        elif isinstance(obj, (list, tuple)):
            return type(obj)(
                self._process_recursively(item, f"{base_key}_{i}")
                for i, item in enumerate(obj)
            )
        else:
            # For unknown types, try to store directly
            return obj

    def __setitem__(self, key, value):
        processed_value = self._process_recursively(value, str(key))
        super().__setitem__(key, processed_value)
        self._check_and_manage_memory()

    def __getitem__(self, item):
        v = super().__getitem__(item)
        if isinstance(v, ArrayWrapper):
            return v.value
        else:
            return v


    def update(self, *args, **kwargs):
        super().update(*args, **kwargs)
        self._check_and_manage_memory()


class ArrayWrapper:
    """
    Enhanced wrapper for tensors and numpy arrays with disk-based memory management.
    Provides automatic serialization/deserialization with improved error handling.
    """

    def __init__(
        self,
        value: Optional[numpy.ndarray | torch.Tensor] = None,
        path: Optional[str | PathLike] = None,
    ):
        self._value = None
        self._path = pathlib.Path(path) if path is not None else None
        self.is_torch = None
        self.device = None
        self.shape = None
        self.dtype = None
        self._state = "file"  # States: "file", "cpu", "cuda"

        if value is not None:
            self._set_value(value)
        elif path is not None and pathlib.Path(path).exists():
            self._load_metadata_from_file()
        elif path is not None:
            # Path provided but file doesn't exist yet - this is okay, will be created later
            pass
        else:
            raise ValueError("Either value or path must be provided")

    def __repr__(self):
        if self.shape is not None:
            return f"ArrayWrapper({self.dtype}{tuple(self.shape)}, state={self._state})"
        return f"ArrayWrapper(uninitialized, state={self._state})"

    def _set_value(self, value: numpy.ndarray | torch.Tensor):
        """Set the wrapped value and update metadata, ensuring tensors are moved to CPU"""
        if not isinstance(value, (numpy.ndarray, torch.Tensor)):
            raise TypeError(
                f"Expected numpy.ndarray or torch.Tensor, got {type(value)}"
            )

        # Store original device for metadata but move tensor to CPU to save CUDA memory
        if isinstance(value, torch.Tensor):
            original_device = str(value.device)
            self._value = value.detach().cpu()  # Always move to CPU
            self.is_torch = True
            self.device = original_device  # Keep original device info for metadata
        else:
            self._value = value
            self.is_torch = False
            self.device = None

        self.shape = value.shape
        self.dtype = value.dtype
        # Always set state to CPU since we moved the tensor there
        self._state = "cpu"

    def _load_metadata_from_file(self):
        """Load tensor metadata without loading the actual data"""
        if self._path is None or not self._path.exists():
            return

        try:
            # Try to determine if it's torch or numpy from file extension or content
            with open(self._path, "rb") as f:
                # Read first few bytes to determine format
                header = f.read(8)
                f.seek(0)

                if header.startswith(b"PK"):  # ZIP format (torch)
                    self.is_torch = True
                    # Load tensor to get metadata, then release
                    temp_tensor = torch.load(f)
                    self.shape = temp_tensor.shape
                    self.dtype = temp_tensor.dtype
                    self.device = (
                        str(temp_tensor.device)
                        if hasattr(temp_tensor, "device")
                        else None
                    )
                    del temp_tensor
                else:  # Assume numpy
                    self.is_torch = False
                    temp_array = numpy.load(f)
                    self.shape = temp_array.shape
                    self.dtype = temp_array.dtype
                    self.device = None
                    del temp_array
        except Exception:
            # If we can't load metadata, we'll get it when the value is actually loaded
            pass

    def write_to_file_and_release(self):
        """Save tensor to file and release from memory"""
        if self._value is None:
            return  # Nothing to save

        self.save_to_file()

        # Release memory with improved cleanup
        if self._value is not None:
            # Check if tensor is on CUDA before deletion
            is_cuda_tensor = (
                self.is_torch
                and hasattr(self._value, "device")
                and "cuda" in str(self._value.device)
            )

            # Delete the tensor
            del self._value
            self._value = None

            # Force garbage collection for better memory cleanup
            gc.collect()

            # Clear CUDA cache if tensor was on CUDA
            if is_cuda_tensor and torch.cuda.is_available():
                torch.cuda.empty_cache()
                torch.cuda.synchronize()  # Ensure all CUDA operations are complete

        self._state = "file"

    @property
    def value(self):
        """Lazy loading of tensor value"""
        if self._value is not None:
            return self._value
        return self.read_from_file()

    def read_from_file(self):
        if self._path is None:
            raise ValueError("No file path specified for ArrayWrapper")
        if not self._path.exists():
            raise FileNotFoundError(f"ArrayWrapper file not found: {self._path}")
        try:
            with open(self._path, "rb") as f:
                if self.is_torch is None:
                    # Auto-detect format if not known
                    header = f.read(8)
                    f.seek(0)
                    self.is_torch = header.startswith(b"PK")
                if self.is_torch:
                    self._value = torch.load(
                        f, map_location="cpu"
                    )  # Always load to CPU
                else:
                    self._value = numpy.load(f)
            # Update metadata if not set
            if self.shape is None:
                self._set_value(self._value)
            else:
                # Always set state to CPU since we load to CPU to save CUDA memory
                self._state = "cpu"

            return self._value

        except Exception as e:
            raise IOError(f"Error loading ArrayWrapper file {self._path}: {str(e)}")

    def save_to_file(self, path: Optional[str | PathLike] = None):
        """Save tensor to file with enhanced error handling"""
        if path is not None:
            self._path = pathlib.Path(path)

        if self._path is None:
            raise ValueError("No file path specified for ArrayWrapper")

        if self._value is None:
            raise ValueError("No data to save in ArrayWrapper")

        # Ensure parent directory exists
        self._path.parent.mkdir(parents=True, exist_ok=True)
        print(self._path)

        try:
            with open(self._path, "wb") as f:
                if self.is_torch:
                    torch.save(self._value, f)
                else:
                    numpy.save(f, self._value)
        except Exception as e:
            raise IOError(f"Error saving ArrayWrapper to file {self._path}: {str(e)}")

    def is_loaded_in_memory(self) -> bool:
        """Check if tensor is currently loaded in memory"""
        return self._value is not None

    def get_memory_usage(self) -> int:
        """Get approximate memory usage in bytes"""
        if self._value is None:
            return 0

        if self.is_torch:
            return self._value.element_size() * self._value.nelement()
        else:
            return self._value.nbytes

    def to_device(self, device: str):
        """Move tensor to specified device (torch tensors only). Loads from file if needed."""
        if not self.is_torch:
            raise ValueError("Device transfer only supported for torch tensors")

        # Load tensor from file if not in memory
        if self._value is None:
            self.read_from_file()

        if self._value is not None:
            # Only move if not already on the target device
            current_device = str(self._value.device)
            if current_device != device:
                self._value = self._value.to(device)
                self.device = str(device)
                # Update state based on new device
                if "cuda" in str(device):
                    self._state = "cuda"
                else:
                    self._state = "cpu"

        return self._value

    def to_cpu(self):
        """Move tensor to CPU to free CUDA memory. Loads from file if needed."""
        if not self.is_torch:
            return self._value  # Numpy arrays are always on CPU

        # Load tensor from file if not in memory
        if self._value is None:
            self.read_from_file()  # This already loads to CPU

        if self._value is not None and "cuda" in str(self._value.device):
            self._value = self._value.cpu()
            self._state = "cpu"
            # Clear CUDA cache after moving to CPU
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        return self._value

    def cuda_operation_context(self, device: str = "cuda:0"):
        """Context manager for CUDA operations with automatic cleanup"""
        return CudaOperationContext(self, device)


class CudaOperationContext:
    """Context manager for CUDA operations with automatic memory cleanup"""

    def __init__(self, array_wrapper: ArrayWrapper, device: str = "cuda:0"):
        self.wrapper = array_wrapper
        self.device = device
        self.original_state = None
        self.was_on_cuda_originally = False

    def __enter__(self):
        """Move tensor to CUDA for operation"""
        if not self.wrapper.is_torch:
            return self.wrapper.value  # Numpy arrays don't need device management

        # Store original state
        self.original_state = self.wrapper._state
        self.was_on_cuda_originally = self.wrapper._state == "cuda"

        # Move to CUDA for operation
        return self.wrapper.to_device(self.device)

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Automatically move back to CPU and clean up CUDA memory"""
        if not self.wrapper.is_torch:
            return

        # Only move back to CPU if it wasn't originally on CUDA
        if not self.was_on_cuda_originally and self.wrapper._state == "cuda":
            self.wrapper.to_cpu()

        # Always clean up CUDA cache after operations
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
