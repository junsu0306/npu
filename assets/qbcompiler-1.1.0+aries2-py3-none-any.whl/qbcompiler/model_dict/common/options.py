"""
last_build: 2026-03-16 13:47:33
version: 0.0.1
"""

import dataclasses
import enum
from typing import List, Tuple, Union, Optional

from .dtypes import int32, int64, float32, TensorIndex, TypeEnforced


@dataclasses.dataclass
class LayerOptions(TypeEnforced):
    def iter_tensorindex(self):
        """iterate over field whose type is TensorIndex. yields (key, value)"""
        for field in dataclasses.fields(self):
            v = getattr(self, field.name)
            if isinstance(v, TensorIndex):
                yield field.name, v


class LayerType(enum.Enum):
    Abs = enum.auto()
    AddPartial = enum.auto()
    AddingConstant = enum.auto()
    Adding = enum.auto()
    And = enum.auto()
    ArgMax = enum.auto()
    AMax = enum.auto()
    BatchToSpaceND = enum.auto()
    Batchnorm = enum.auto()
    Cast = enum.auto()
    Ceil = enum.auto()
    Celu = enum.auto()
    ChannelBroadcast = enum.auto()
    ChannelSlice = enum.auto()
    Clip = enum.auto()
    Concatenate = enum.auto()
    ConstantOfShape = enum.auto()
    Convolution1d = enum.auto()
    Convolution3d = enum.auto()
    Convolution = enum.auto()
    Cos = enum.auto()
    Crop = enum.auto()
    CustomOp = enum.auto()
    CustomBiOp = enum.auto()
    GroupQueryAttention = enum.auto()
    Skipsimplifiedlayernormalization = enum.auto()
    CustomSingleOp = enum.auto()
    CumSum = enum.auto()
    DepthToSpace = enum.auto()
    DepthwiseConvolution = enum.auto()
    DeviceBridge = enum.auto()
    DivConstant = enum.auto()
    Div = enum.auto()
    Einsum = enum.auto()
    Elu = enum.auto()
    Equal = enum.auto()
    Erf = enum.auto()
    Exp = enum.auto()
    Expand = enum.auto()
    Flatten = enum.auto()
    Unflatten = enum.auto()
    Flip = enum.auto()
    FloorDiv = enum.auto()
    FloorMod = enum.auto()
    Floor = enum.auto()
    Full = enum.auto()
    GatherConstant = enum.auto()
    GatherElements = enum.auto()
    GatherElementsConstant = enum.auto()
    GatherND = enum.auto()
    Gather = enum.auto()
    Gelu = enum.auto()
    Selu = enum.auto()
    GLU = enum.auto()
    GemmConstant = enum.auto()
    Gemm = enum.auto()
    Greater = enum.auto()
    GridSample = enum.auto()
    GroupConvolution = enum.auto()
    GroupNormalization = enum.auto()
    HardSigmoid = enum.auto()
    Hardtanh = enum.auto()
    HardSwish = enum.auto()
    HeaderView = enum.auto()
    HeaderViewRevert = enum.auto()
    Identity = enum.auto()
    InputConstant = enum.auto()
    Input = enum.auto()
    InstanceNormalization = enum.auto()
    L1Normalization = enum.auto()
    L2Normalization = enum.auto()
    LSTM = enum.auto()
    LayerNormalization = enum.auto()
    Logit = enum.auto()
    RNN = enum.auto()
    GRU = enum.auto()
    LeakyRelu = enum.auto()
    Less = enum.auto()
    LessV2 = enum.auto()
    LessThenOrEqual = enum.auto()
    Log = enum.auto()
    LogSigmoid = enum.auto()
    MaskSoftmax = enum.auto()
    MatMul = enum.auto()
    MinMaxNormalization = enum.auto()
    Minimum = enum.auto()
    MinimumConstant = enum.auto()
    Maximum = enum.auto()
    MaximumConstant = enum.auto()
    Mish = enum.auto()
    Mod = enum.auto()
    ModV2 = enum.auto()
    MultiplyConstant = enum.auto()
    Multiply = enum.auto()
    Neg = enum.auto()
    NonMaxSuppression = enum.auto()
    NonZero = enum.auto()
    Not = enum.auto()
    Or = enum.auto()
    Output = enum.auto()
    PRelu = enum.auto()
    Pack = enum.auto()
    Pad = enum.auto()
    PadChannel = enum.auto()
    Pad3d = enum.auto()
    PadGeneric = enum.auto()
    Pad1d = enum.auto()
    Pooling = enum.auto()
    Pooling1d = enum.auto()
    GlobalAveragePooling = enum.auto()
    Pow = enum.auto()
    QuickGelu = enum.auto()
    Random = enum.auto()
    Range = enum.auto()
    Reciprocal = enum.auto()
    ReduceL2 = enum.auto()
    ReduceMax = enum.auto()
    ReduceMin = enum.auto()
    ReduceMean = enum.auto()
    ReduceProd = enum.auto()
    ReduceSum = enum.auto()
    Relu = enum.auto()
    RepeatN = enum.auto()
    Reshape = enum.auto()
    ReshapeV2 = enum.auto()
    Resize = enum.auto()
    RmsNormalization = enum.auto()
    RotaryEmbedding = enum.auto()
    Rsqrt = enum.auto()
    Rstd = enum.auto()
    ScalarInt = enum.auto()
    ScalarStr = enum.auto()
    ScatterND = enum.auto()
    Shape = enum.auto()
    TensorAttribute = enum.auto()
    Sigmoid = enum.auto()
    Sin = enum.auto()
    Slice = enum.auto()
    Softmax = enum.auto()
    Softplus = enum.auto()
    SpaceToBatchND = enum.auto()
    SpaceToDepth = enum.auto()
    SpatialBroadcast = enum.auto()
    Split = enum.auto()
    SplitV2 = enum.auto()
    Sqrt = enum.auto()
    SquaredDifference = enum.auto()
    Squeeze = enum.auto()
    StaggeredPadding = enum.auto()
    StatefulAttentionMaskWrapper = enum.auto()
    StatefulKVCacheWrapper = enum.auto()
    StatefulCausalConvCacheWrapper = enum.auto()
    StatefulLSTMWrapper = enum.auto()
    StatefulRNNWrapper = enum.auto()
    StatefulGRUWrapper = enum.auto()
    StatefulRoPEWrapper = enum.auto()
    StridedSlice = enum.auto()
    SubConstant = enum.auto()
    Sub = enum.auto()
    Swish = enum.auto()
    Tanh = enum.auto()
    TemporaryNode = enum.auto()
    Threshold = enum.auto()
    Tile = enum.auto()
    TopKIndices = enum.auto()
    TopK = enum.auto()
    TopKValues = enum.auto()
    TransposeConvolution1d = enum.auto()
    TransposeConvolution = enum.auto()
    Transpose = enum.auto()
    Unpack = enum.auto()
    Unsqueeze = enum.auto()
    Upsampling = enum.auto()
    Weightedsum = enum.auto()
    OrderedPatchify = enum.auto()
    Where = enum.auto()
    TensorCmp = enum.auto()
    Xor = enum.auto()
    DynamicSliceInputConst = enum.auto()
    BatchNorm1d = enum.auto()
    RelShift = enum.auto()
    Embedding = enum.auto()
    AttentionMaskInput = enum.auto()
    KVCacheInput = enum.auto()
    GetItem = enum.auto()
    MaskedFill = enum.auto()
    Arange = enum.auto()
    Repeat = enum.auto()
    Ones = enum.auto()
    Zeros = enum.auto()
    Tril = enum.auto()
    Roll = enum.auto()
    HFCache = enum.auto()
    HFCacheUpdate = enum.auto()
    HFPatchedFunction = enum.auto()
    MeloTTSPiecewiseRationalQuadraticTransform = enum.auto()
    IndexedItemSelector = enum.auto()
    ChannelwiseApply = enum.auto()
    SubgraphCall = enum.auto()
    SubgraphScope = enum.auto()
    MoeDispatcher = enum.auto()
    MoeAggregator = enum.auto()


class Registry:
    _registry = {}  # (LayerType, LayerOptionCls)
    _inv_registry = {}  # (LayerOptionCls_name, LayerType)

    @staticmethod
    def register(layertype: LayerType):
        def _register(cls):
            Registry._registry[layertype] = cls
            Registry._inv_registry[cls.__name__] = layertype
            return cls

        return _register

    @staticmethod
    def getcls(layertype: Union[LayerType, str]):
        if isinstance(layertype, str):
            if layertype in LayerType.__members__:
                return Registry._registry[LayerType[layertype]]
            raise ValueError(f"{layertype} not in LayerType")
        return Registry._registry[layertype]

    @staticmethod
    def is_registered(option_obj):
        return option_obj.__class__.__name__ in Registry._inv_registry

    @staticmethod
    def get_option_type(option_obj) -> LayerType:
        return Registry._inv_registry[option_obj.__class__.__name__]


@Registry.register(LayerType.Abs)
@dataclasses.dataclass
class AbsOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.AddPartial)
@dataclasses.dataclass
class AddPartialOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    is_input0_larger: bool


@Registry.register(LayerType.AddingConstant)
@dataclasses.dataclass
class AddingConstantOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: TensorIndex
    is_const_first: bool = False


@Registry.register(LayerType.Adding)
@dataclasses.dataclass
class AddingOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.And)
@dataclasses.dataclass
class AndOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    constant: TensorIndex = -1
    is_const_first: bool = False


@Registry.register(LayerType.ArgMax)
@dataclasses.dataclass
class ArgMaxOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: int32
    keepdims: bool = True
    select_last: bool = False


@Registry.register(LayerType.AMax)
@dataclasses.dataclass
class AMaxOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: Tuple[int32, ...]
    keepdims: bool = True


@Registry.register(LayerType.BatchToSpaceND)
@dataclasses.dataclass
class BatchToSpaceNDOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    block_shape: TensorIndex
    crops: TensorIndex


@Registry.register(LayerType.Batchnorm)
@dataclasses.dataclass
class BatchnormOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    gamma: TensorIndex
    beta: TensorIndex
    moving_mean: TensorIndex
    moving_var: TensorIndex
    epsilon: TensorIndex
    channel_last: bool = True


@Registry.register(LayerType.Cast)
@dataclasses.dataclass
class CastOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    data_type: str


@Registry.register(LayerType.Ceil)
@dataclasses.dataclass
class CeilOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Celu)
@dataclasses.dataclass
class CeluOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    alpha: float32


@Registry.register(LayerType.ChannelBroadcast)
@dataclasses.dataclass
class ChannelBroadcastOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    out_channels: int32


@Registry.register(LayerType.ChannelSlice)
@dataclasses.dataclass
class ChannelSliceOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    start: int32
    end: int32


@Registry.register(LayerType.Clip)
@dataclasses.dataclass
class ClipOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    clip_max_value: Optional[float32] = None
    clip_min_value: Optional[float32] = None


@Registry.register(LayerType.Concatenate)
@dataclasses.dataclass
class ConcatenateOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    original_key: Optional[str] = None
    axis: Optional[int32] = None
    original_axis: Optional[int32] = None
    original_inputs: Optional[Tuple[int32, ...]] = None
    input_index: Optional[Tuple[int32, ...]] = None
    input_names: Optional[Tuple[str, ...]] = None


@Registry.register(LayerType.ConstantOfShape)
@dataclasses.dataclass
class ConstantOfShapeOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    value: float32


@Registry.register(LayerType.Convolution1d)
@dataclasses.dataclass
class Convolution1dOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    in_channels: int32
    out_channels: int32
    kernel: int32
    stride: int32
    dilation: int32
    west_padding: int32
    east_padding: int32
    group_number: int32
    weight: TensorIndex
    padding_list: Tuple[int32, ...] = ()
    bias: TensorIndex = -1
    channel_last: bool = True


@Registry.register(LayerType.Convolution3d)
@dataclasses.dataclass
class Convolution3dOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    in_channels: int32
    out_channels: int32
    h_kernel: int32
    w_kernel: int32
    d_kernel: int32
    h_stride: int32
    w_stride: int32
    d_stride: int32
    h_dilation: int32
    w_dilation: int32
    d_dilation: int32
    west_padding: int32
    east_padding: int32
    north_padding: int32
    south_padding: int32
    front_padding: int32
    back_padding: int32
    group_number: int32
    weight: TensorIndex
    padding_list: Tuple[int32, ...] = ()
    bias: TensorIndex = -1
    channel_last: bool = True


@Registry.register(LayerType.Convolution)
@dataclasses.dataclass
class ConvolutionOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    in_channels: int32
    out_channels: int32
    h_kernel: int32
    w_kernel: int32
    h_stride: int32
    w_stride: int32
    h_dilation: int32
    w_dilation: int32
    west_padding: int32
    east_padding: int32
    north_padding: int32
    south_padding: int32
    group_number: int32
    weight: TensorIndex
    padding_list: Tuple[int32, ...] = ()
    bias: TensorIndex = -1
    channel_last: bool = True


@Registry.register(LayerType.Cos)
@dataclasses.dataclass
class CosOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Crop)
@dataclasses.dataclass
class CropOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    crop_width: int32
    crop_height: int32
    w_offset: int32 = 0
    h_offset: int32 = 0


@Registry.register(LayerType.CustomOp)
@dataclasses.dataclass
class CustomOpOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, ...]
    content: str


@Registry.register(LayerType.CustomBiOp)
@dataclasses.dataclass
class CustomBiOpOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    content: str


@Registry.register(LayerType.GroupQueryAttention)
@dataclasses.dataclass
class GroupQueryAttentionOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    seqlens_k: int32
    total_sequence_length: int32
    num_heads: int32
    kv_num_heads: int32
    scale: float32
    do_rotary: int32
    rotary_interleaved: int32
    cos_cache: TensorIndex
    sin_cache: TensorIndex
    past_key: str
    past_value: str


@Registry.register(LayerType.Skipsimplifiedlayernormalization)
@dataclasses.dataclass
class SkipsimplifiedlayernormalizationOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, ...]
    gamma: TensorIndex
    epsilon: TensorIndex


@Registry.register(LayerType.CustomSingleOp)
@dataclasses.dataclass
class CustomSingleOpOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    content: str


@Registry.register(LayerType.CumSum)
@dataclasses.dataclass
class CumSumOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: int32
    exclusive: int32 = 0
    reverse: int32 = 0


@Registry.register(LayerType.DepthToSpace)
@dataclasses.dataclass
class DepthToSpaceOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    block_size: int32
    mode: str = "DCR"
    channel_last: bool = True


@Registry.register(LayerType.DepthwiseConvolution)
@dataclasses.dataclass
class DepthwiseConvolutionOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    in_channels: int32
    out_channels: int32
    h_kernel: int32
    w_kernel: int32
    h_stride: int32
    w_stride: int32
    h_dilation: int32
    w_dilation: int32
    west_padding: int32
    east_padding: int32
    north_padding: int32
    south_padding: int32
    group_number: int32
    weight: TensorIndex
    padding_list: Tuple[int32, ...] = ()
    bias: TensorIndex = -1
    channel_last: bool = True


@Registry.register(LayerType.DeviceBridge)
@dataclasses.dataclass
class DeviceBridgeOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    squeeze_axes: Tuple[int32, ...]
    unsqueeze_axes: Tuple[int32, ...]
    permute_axes: Tuple[int64, ...]
    device: Optional[str] = None


@Registry.register(LayerType.DivConstant)
@dataclasses.dataclass
class DivConstantOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: TensorIndex
    is_const_first: bool


@Registry.register(LayerType.Div)
@dataclasses.dataclass
class DivOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Einsum)
@dataclasses.dataclass
class EinsumOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    equation: str
    constant: TensorIndex = -1
    is_const_first: bool = False


@Registry.register(LayerType.Elu)
@dataclasses.dataclass
class EluOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    leaky_alpha: float32


@Registry.register(LayerType.Equal)
@dataclasses.dataclass
class EqualOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: TensorIndex = -1
    is_const_first: bool = False


@Registry.register(LayerType.Erf)
@dataclasses.dataclass
class ErfOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Exp)
@dataclasses.dataclass
class ExpOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Expand)
@dataclasses.dataclass
class ExpandOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    is_const_first: bool
    constant: TensorIndex = -1


@Registry.register(LayerType.Flatten)
@dataclasses.dataclass
class FlattenOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: int32


@Registry.register(LayerType.Unflatten)
@dataclasses.dataclass
class UnflattenOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    dim: int32
    sizes: Tuple[int32, ...]


@Registry.register(LayerType.Flip)
@dataclasses.dataclass
class FlipOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: Tuple[int32, ...]


@Registry.register(LayerType.FloorDiv)
@dataclasses.dataclass
class FloorDivOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    constant: TensorIndex = -1
    is_const_first: bool = False


@Registry.register(LayerType.FloorMod)
@dataclasses.dataclass
class FloorModOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    constant: TensorIndex = -1
    is_const_first: bool = False


@Registry.register(LayerType.Floor)
@dataclasses.dataclass
class FloorOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Full)
@dataclasses.dataclass
class FullOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    value: float32


@Registry.register(LayerType.GatherConstant)
@dataclasses.dataclass
class GatherConstantOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32, ...]
    axis: int32
    constant: TensorIndex
    is_const_first: bool
    batch_dims: Optional[int32] = None


@Registry.register(LayerType.GatherElements)
@dataclasses.dataclass
class GatherElementsOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32, ...]
    axis: int32


@Registry.register(LayerType.GatherElementsConstant)
@dataclasses.dataclass
class GatherElementsConstantOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32, ...]
    axis: int32
    constant: TensorIndex
    is_const_first: bool


@Registry.register(LayerType.GatherND)
@dataclasses.dataclass
class GatherNDOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    batch_dims: int32
    constant: TensorIndex = -1


@Registry.register(LayerType.Gather)
@dataclasses.dataclass
class GatherOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32, ...]
    axis: int32
    batch_dims: Optional[int32] = None


@Registry.register(LayerType.Gelu)
@dataclasses.dataclass
class GeluOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    approximate: bool = False


@Registry.register(LayerType.Selu)
@dataclasses.dataclass
class SeluOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    alpha: float32 = 1.67326
    gamma: float32 = 1.0507


@Registry.register(LayerType.GLU)
@dataclasses.dataclass
class GLUOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.GemmConstant)
@dataclasses.dataclass
class GemmConstantOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: TensorIndex
    bias: TensorIndex
    is_const_first: bool = False
    alpha: float32 = 1.0
    beta: float32 = 1.0
    transA: bool = False
    transB: bool = False


@Registry.register(LayerType.Gemm)
@dataclasses.dataclass
class GemmOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    bias: TensorIndex
    alpha: float32 = 1.0
    beta: float32 = 1.0
    transA: bool = False
    transB: bool = False


@Registry.register(LayerType.Greater)
@dataclasses.dataclass
class GreaterOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    constant: TensorIndex = -1
    is_const_first: bool = False


@Registry.register(LayerType.GridSample)
@dataclasses.dataclass
class GridSampleOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    align_corners: int32 = 0
    mode: str = "linear"
    padding_mode: str = "zeros"
    constant: TensorIndex = -1
    is_const_first: bool = False


@Registry.register(LayerType.GroupConvolution)
@dataclasses.dataclass
class GroupConvolutionOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    in_channels: int32
    out_channels: int32
    h_kernel: int32
    w_kernel: int32
    h_stride: int32
    w_stride: int32
    h_dilation: int32
    w_dilation: int32
    west_padding: int32
    east_padding: int32
    north_padding: int32
    south_padding: int32
    group_number: int32
    weight: TensorIndex
    padding_list: Tuple[int32, ...] = ()
    bias: TensorIndex = -1
    channel_last: bool = True


@Registry.register(LayerType.GroupNormalization)
@dataclasses.dataclass
class GroupNormalizationOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    num_groups: int32
    scale: TensorIndex
    epsilon: TensorIndex
    bias: TensorIndex = -1
    channel_last: bool = True


@Registry.register(LayerType.HardSigmoid)
@dataclasses.dataclass
class HardSigmoidOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    alpha: Optional[float32] = None
    beta: Optional[float32] = None


@Registry.register(LayerType.Hardtanh)
@dataclasses.dataclass
class HardtanhOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    min_val: float32 = -1.0
    max_val: float32 = 1.0


@Registry.register(LayerType.HardSwish)
@dataclasses.dataclass
class HardSwishOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.HeaderView)
@dataclasses.dataclass
class HeaderViewOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    view_shape: Tuple[int32, ...] = ()
    num_heads: int32 = -1
    batch_order: int32 = 0


@Registry.register(LayerType.HeaderViewRevert)
@dataclasses.dataclass
class HeaderViewRevertOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    revert_shape: Tuple[int32, ...] = ()
    num_heads: int32 = -1
    batch_order: int32 = 0


@Registry.register(LayerType.Identity)
@dataclasses.dataclass
class IdentityOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.InputConstant)
@dataclasses.dataclass
class InputConstantOptions(LayerOptions):
    outputs: Tuple[int32]
    constant: TensorIndex
    inputs: Tuple = ()


@Registry.register(LayerType.Input)
@dataclasses.dataclass
class InputOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.InstanceNormalization)
@dataclasses.dataclass
class InstanceNormalizationOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    scale: TensorIndex
    epsilon: TensorIndex
    bias: TensorIndex = -1
    channel_last: bool = True
    num_groups: int32 = -1
    group_order: int32 = -1


@Registry.register(LayerType.L1Normalization)
@dataclasses.dataclass
class L1NormalizationOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    norm_axis: Tuple[int32, ...]


@Registry.register(LayerType.L2Normalization)
@dataclasses.dataclass
class L2NormalizationOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    norm_axis: Tuple[int32, ...]
    epsilon: TensorIndex = -1


@Registry.register(LayerType.LSTM)
@dataclasses.dataclass
class LSTMOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    W: TensorIndex
    R: TensorIndex
    lstm_group: str
    input_mask: str
    output_mask: str
    hidden_size: int32
    B: TensorIndex = -1
    P: TensorIndex = -1
    direction: str = "forward"
    batch_first: bool = False


@Registry.register(LayerType.LayerNormalization)
@dataclasses.dataclass
class LayerNormalizationOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    scale: TensorIndex
    epsilon: TensorIndex
    normalized_shape: Tuple[int64, ...] = ()
    bias: TensorIndex = -1


@Registry.register(LayerType.Logit)
@dataclasses.dataclass
class LogitOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    eps: Optional[float32] = None


@Registry.register(LayerType.RNN)
@dataclasses.dataclass
class RNNOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    W: TensorIndex
    R: TensorIndex
    rnn_group: str
    input_mask: str
    output_mask: str
    hidden_size: int32
    B: TensorIndex = -1
    direction: str = "forward"
    batch_first: bool = False


@Registry.register(LayerType.GRU)
@dataclasses.dataclass
class GRUOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    W: TensorIndex
    R: TensorIndex
    gru_group: str
    input_mask: str
    output_mask: str
    hidden_size: int32
    B: TensorIndex = -1
    direction: str = "forward"
    batch_first: bool = False
    linear_before_reset: bool = False


@Registry.register(LayerType.LeakyRelu)
@dataclasses.dataclass
class LeakyReluOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    leaky_alpha: float32


@Registry.register(LayerType.Less)
@dataclasses.dataclass
class LessOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    is_const_first: bool
    constant: TensorIndex = -1


@Registry.register(LayerType.LessV2)
@dataclasses.dataclass
class LessV2Options(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.LessThenOrEqual)
@dataclasses.dataclass
class LessThenOrEqualOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Log)
@dataclasses.dataclass
class LogOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.LogSigmoid)
@dataclasses.dataclass
class LogSigmoidOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.MaskSoftmax)
@dataclasses.dataclass
class MaskSoftmaxOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    beta: float32
    axis: int32


@Registry.register(LayerType.MatMul)
@dataclasses.dataclass
class MatMulOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    constant: TensorIndex = -1
    is_const_first: bool = False
    repeat: Tuple[int32, int32] = (-1, -1)


@Registry.register(LayerType.MinMaxNormalization)
@dataclasses.dataclass
class MinMaxNormalizationOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    norm_axis: Tuple[int32, ...]


@Registry.register(LayerType.Minimum)
@dataclasses.dataclass
class MinimumOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]


@Registry.register(LayerType.MinimumConstant)
@dataclasses.dataclass
class MinimumConstantOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: TensorIndex
    is_const_first: bool = False


@Registry.register(LayerType.Maximum)
@dataclasses.dataclass
class MaximumOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]


@Registry.register(LayerType.MaximumConstant)
@dataclasses.dataclass
class MaximumConstantOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: TensorIndex
    is_const_first: bool = False


@Registry.register(LayerType.Mish)
@dataclasses.dataclass
class MishOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Mod)
@dataclasses.dataclass
class ModOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    is_const_first: bool
    constant: TensorIndex = -1
    fmod: bool = False


@Registry.register(LayerType.ModV2)
@dataclasses.dataclass
class ModV2Options(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    fmod: bool = False


@Registry.register(LayerType.MultiplyConstant)
@dataclasses.dataclass
class MultiplyConstantOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: TensorIndex
    is_const_first: bool = False


@Registry.register(LayerType.Multiply)
@dataclasses.dataclass
class MultiplyOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Neg)
@dataclasses.dataclass
class NegOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.NonMaxSuppression)
@dataclasses.dataclass
class NonMaxSuppressionOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32, ...]
    max_output_size: int64
    iou_threshold: float32
    score_threshold: float32
    soft_nms_sigma: float32
    pad_to_max_output_size: bool
    center_point_box: int32 = 0


@Registry.register(LayerType.NonZero)
@dataclasses.dataclass
class NonZeroOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Not)
@dataclasses.dataclass
class NotOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Or)
@dataclasses.dataclass
class OrOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: TensorIndex = -1
    is_const_first: bool = False


@Registry.register(LayerType.Output)
@dataclasses.dataclass
class OutputOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.PRelu)
@dataclasses.dataclass
class PReluOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    leaky_alpha: TensorIndex


@Registry.register(LayerType.Pack)
@dataclasses.dataclass
class PackOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    values_count: int32
    axis: int32


@Registry.register(LayerType.Pad)
@dataclasses.dataclass
class PadOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    pad_mode: str
    west_padding: int32 = -1
    east_padding: int32 = -1
    south_padding: int32 = -1
    north_padding: int32 = -1
    constant: float32 = 0.0
    padding_list: Optional[Tuple[int32, ...]] = None


@Registry.register(LayerType.PadChannel)
@dataclasses.dataclass
class PadChannelOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    pad_mode: str
    front_padding: int32 = -1
    back_padding: int32 = -1
    constant: float32 = 0.0


@Registry.register(LayerType.Pad3d)
@dataclasses.dataclass
class Pad3dOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    pad_mode: str
    front_padding: int32 = -1
    back_padding: int32 = -1
    west_padding: int32 = -1
    east_padding: int32 = -1
    south_padding: int32 = -1
    north_padding: int32 = -1
    constant: float32 = 0.0
    padding_list: Optional[Tuple[int32, ...]] = None


@Registry.register(LayerType.PadGeneric)
@dataclasses.dataclass
class PadGenericOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    pad_mode: str
    padding_list: Tuple[int32, ...]
    constant: float32 = 0.0


@Registry.register(LayerType.Pad1d)
@dataclasses.dataclass
class Pad1dOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    pad_mode: str
    west_padding: int32 = -1
    east_padding: int32 = -1
    constant: float32 = 0.0
    padding_list: Optional[Tuple[int32, ...]] = None


@Registry.register(LayerType.Pooling)
@dataclasses.dataclass
class PoolingOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    h_kernel: int32
    w_kernel: int32
    h_stride: int32
    w_stride: int32
    west_padding: int32
    east_padding: int32
    north_padding: int32
    south_padding: int32
    pool_type: str
    pad_mode: str
    h_dilation: int32 = 1
    w_dilation: int32 = 1
    padding_list: Tuple[int32, ...] = ()
    is_ceil_mode: bool = False
    is_include_pad: bool = False
    channel_last: bool = True


@Registry.register(LayerType.Pooling1d)
@dataclasses.dataclass
class Pooling1dOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    kernel: int32
    stride: int32
    west_padding: int32
    east_padding: int32
    pool_type: str
    pad_mode: str
    dilation: int32 = 1
    padding_list: Optional[Tuple[int32, ...]] = None
    is_ceil_mode: bool = False
    is_include_pad: bool = False
    channel_last: bool = True


@Registry.register(LayerType.GlobalAveragePooling)
@dataclasses.dataclass
class GlobalAveragePoolingOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    channel_last: bool = True


@Registry.register(LayerType.Pow)
@dataclasses.dataclass
class PowOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    exponent: float32


@Registry.register(LayerType.QuickGelu)
@dataclasses.dataclass
class QuickGeluOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Random)
@dataclasses.dataclass
class RandomOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    distribution: str = "standard_normal"


@Registry.register(LayerType.Range)
@dataclasses.dataclass
class RangeOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    start: TensorIndex = -1
    limit: TensorIndex = -1
    delta: TensorIndex = -1


@Registry.register(LayerType.Reciprocal)
@dataclasses.dataclass
class ReciprocalOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.ReduceL2)
@dataclasses.dataclass
class ReduceL2Options(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    keep_dims: bool
    reduce_axes: Tuple[int32, ...]
    noop_with_empty_axes: int32


@Registry.register(LayerType.ReduceMax)
@dataclasses.dataclass
class ReduceMaxOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    keep_dims: bool
    reduce_axes: Tuple[int32, ...]
    noop_with_empty_axes: int32


@Registry.register(LayerType.ReduceMin)
@dataclasses.dataclass
class ReduceMinOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    keep_dims: bool
    reduce_axes: Tuple[int32, ...]
    noop_with_empty_axes: int32


@Registry.register(LayerType.ReduceMean)
@dataclasses.dataclass
class ReduceMeanOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    keep_dims: bool
    reduce_axes: Tuple[int32, ...]
    noop_with_empty_axes: int32


@Registry.register(LayerType.ReduceProd)
@dataclasses.dataclass
class ReduceProdOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    keep_dims: bool
    reduce_axes: Tuple[int32, ...]
    noop_with_empty_axes: int32


@Registry.register(LayerType.ReduceSum)
@dataclasses.dataclass
class ReduceSumOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    keep_dims: bool
    reduce_axes: Tuple[int32, ...]
    noop_with_empty_axes: int32


@Registry.register(LayerType.Relu)
@dataclasses.dataclass
class ReluOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.RepeatN)
@dataclasses.dataclass
class RepeatNOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: int32
    repeat: int32


@Registry.register(LayerType.Reshape)
@dataclasses.dataclass
class ReshapeOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    new_shape: Optional[Tuple[int32, ...]] = None
    allowzero: int32 = 0
    is_const_first: bool = False


@Registry.register(LayerType.ReshapeV2)
@dataclasses.dataclass
class ReshapeV2Options(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    allowzero: int32
    is_const_first: bool = False


@Registry.register(LayerType.Resize)
@dataclasses.dataclass
class ResizeOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    resize_type: Optional[str] = None
    resize_mode: Optional[str] = None
    nearest_mode: Optional[str] = None
    transform_mode: Optional[str] = None
    roi: Optional[Tuple[int32, ...]] = None
    scales: Optional[Tuple[float32, ...]] = None
    sizes: Optional[Tuple[int32, ...]] = None
    cubic_coeff_a: Optional[float32] = None
    exclude_outside: Optional[int32] = None
    extrapolation_value: Optional[float32] = None
    antialias: Optional[int32] = None
    axes: Optional[Tuple[int32, ...]] = None
    keep_aspect_ratio_policy: Optional[str] = None


@Registry.register(LayerType.RmsNormalization)
@dataclasses.dataclass
class RmsNormalizationOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    epsilon: TensorIndex
    scale: TensorIndex
    normalized_shape: Tuple[int64, ...] = ()


@Registry.register(LayerType.RotaryEmbedding)
@dataclasses.dataclass
class RotaryEmbeddingOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32, int32]
    inv_freq: TensorIndex
    attention_scaling: float32


@Registry.register(LayerType.Rsqrt)
@dataclasses.dataclass
class RsqrtOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Rstd)
@dataclasses.dataclass
class RstdOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    reduce_axes: Tuple[int32, ...]
    epsilon: TensorIndex
    num_groups: int32 = 1


@Registry.register(LayerType.ScalarInt)
@dataclasses.dataclass
class ScalarIntOptions(LayerOptions):
    outputs: Tuple[int32]
    value: int64
    inputs: Tuple = ()


@Registry.register(LayerType.ScalarStr)
@dataclasses.dataclass
class ScalarStrOptions(LayerOptions):
    outputs: Tuple[int32]
    value: str
    inputs: Tuple = ()


@Registry.register(LayerType.ScatterND)
@dataclasses.dataclass
class ScatterNDOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    constant_data: TensorIndex = -1
    constant_indices: TensorIndex = -1


@Registry.register(LayerType.Shape)
@dataclasses.dataclass
class ShapeOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    start: Optional[int32] = None
    end: Optional[int32] = None


@Registry.register(LayerType.TensorAttribute)
@dataclasses.dataclass
class TensorAttributeOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    attr: str


@Registry.register(LayerType.Sigmoid)
@dataclasses.dataclass
class SigmoidOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    alpha: float32 = 1.0


@Registry.register(LayerType.Sin)
@dataclasses.dataclass
class SinOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Slice)
@dataclasses.dataclass
class SliceOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: Tuple[int32, ...]
    start: Tuple[int64, ...]
    end: Tuple[int64, ...]
    step: Optional[Tuple[int64, ...]] = None


@Registry.register(LayerType.Softmax)
@dataclasses.dataclass
class SoftmaxOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: int32
    beta: float32 = 1.0


@Registry.register(LayerType.Softplus)
@dataclasses.dataclass
class SoftplusOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    beta: float32 = 1.0
    threshold: float32 = 20.0


@Registry.register(LayerType.SpaceToBatchND)
@dataclasses.dataclass
class SpaceToBatchNDOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    block_shape: TensorIndex
    paddings: TensorIndex


@Registry.register(LayerType.SpaceToDepth)
@dataclasses.dataclass
class SpaceToDepthOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    block_size: int32
    channel_last: bool = True


@Registry.register(LayerType.SpatialBroadcast)
@dataclasses.dataclass
class SpatialBroadcastOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    output_spatial_shape: Tuple[int32, int32]


@Registry.register(LayerType.Split)
@dataclasses.dataclass
class SplitOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: int32
    split: Tuple[int64, ...]
    num_outputs: int32
    split_index: int32


@Registry.register(LayerType.SplitV2)
@dataclasses.dataclass
class SplitV2Options(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32, ...]
    axis: int32
    split: Tuple[int64, ...]
    num_outputs: int32


@Registry.register(LayerType.Sqrt)
@dataclasses.dataclass
class SqrtOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.SquaredDifference)
@dataclasses.dataclass
class SquaredDifferenceOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Squeeze)
@dataclasses.dataclass
class SqueezeOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    squeeze_axes: Optional[Tuple[int32, ...]] = None


@Registry.register(LayerType.StaggeredPadding)
@dataclasses.dataclass
class StaggeredPaddingOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: int32 = 3
    reverse: bool = False
    window_size: int32 = -1


@Registry.register(LayerType.StatefulAttentionMaskWrapper)
@dataclasses.dataclass
class StatefulAttentionMaskWrapperOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    past_seqlen: int32 = 0
    is_sliding: bool = False
    sliding_window: int32 = 1024
    mask_type: str = "causal_mask"


@Registry.register(LayerType.StatefulKVCacheWrapper)
@dataclasses.dataclass
class StatefulKVCacheWrapperOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    cache_name: str
    past_seqlen: int32 = 0
    is_sliding: bool = False
    sliding_window: int32 = 1024
    max_cache_len: int32 = 8192


@Registry.register(LayerType.StatefulCausalConvCacheWrapper)
@dataclasses.dataclass
class StatefulCausalConvCacheWrapperOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    cache_name: str
    cache_len: int32 = 0


@Registry.register(LayerType.StatefulLSTMWrapper)
@dataclasses.dataclass
class StatefulLSTMWrapperOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, int32, int32]
    W: TensorIndex
    R: TensorIndex
    input_mask: str
    output_mask: str
    hidden_size: int32
    hidden_state_name: str
    cell_state_name: str
    subgraph: str
    B: TensorIndex = -1
    P: TensorIndex = -1
    direction: str = "forward"
    batch_first: bool = False


@Registry.register(LayerType.StatefulRNNWrapper)
@dataclasses.dataclass
class StatefulRNNWrapperOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, int32]
    W: TensorIndex
    R: TensorIndex
    input_mask: str
    output_mask: str
    hidden_size: int32
    hidden_state_name: str
    subgraph: str
    B: TensorIndex = -1
    direction: str = "forward"
    batch_first: bool = False


@Registry.register(LayerType.StatefulGRUWrapper)
@dataclasses.dataclass
class StatefulGRUWrapperOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, int32]
    W: TensorIndex
    R: TensorIndex
    input_mask: str
    output_mask: str
    hidden_size: int32
    hidden_state_name: str
    subgraph: str
    B: TensorIndex = -1
    direction: str = "forward"
    batch_first: bool = False
    linear_before_reset: bool = False


@Registry.register(LayerType.StatefulRoPEWrapper)
@dataclasses.dataclass
class StatefulRoPEWrapperOptions(LayerOptions):
    inputs: Tuple[int32, int32, int32]
    outputs: Tuple[int32]
    rope_type: int32 = 0
    seqlen: int32 = 0
    rotary_emb_dim: int32 = 0


@Registry.register(LayerType.StridedSlice)
@dataclasses.dataclass
class StridedSliceOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    begin: Tuple[int64, ...]
    end: Tuple[int64, ...]
    stride: Tuple[int64, ...]
    begin_mask: int32
    end_mask: int32
    ellipsis_mask: int32
    new_axis_mask: int32
    shrink_axis_mask: int32
    offset: bool = False


@Registry.register(LayerType.SubConstant)
@dataclasses.dataclass
class SubConstantOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: TensorIndex
    is_const_first: bool


@Registry.register(LayerType.Sub)
@dataclasses.dataclass
class SubOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Swish)
@dataclasses.dataclass
class SwishOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Tanh)
@dataclasses.dataclass
class TanhOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.TemporaryNode)
@dataclasses.dataclass
class TemporaryNodeOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, ...]
    description: str


@Registry.register(LayerType.Threshold)
@dataclasses.dataclass
class ThresholdOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    lower_threshold: Optional[float32] = None
    lower_value: Optional[float32] = None
    upper_threshold: Optional[float32] = None
    upper_value: Optional[float32] = None


@Registry.register(LayerType.Tile)
@dataclasses.dataclass
class TileOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    repeats: Tuple[int64, ...]
    real_repeats: Optional[Tuple[int32, ...]] = None


@Registry.register(LayerType.TopKIndices)
@dataclasses.dataclass
class TopKIndicesOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: int64 = 100
    axis: Optional[int32] = None
    largest: bool = True
    sorted: bool = True


@Registry.register(LayerType.TopK)
@dataclasses.dataclass
class TopKOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32, int32]
    constant: int64
    axis: Optional[int32] = None
    largest: bool = True
    sorted: bool = True


@Registry.register(LayerType.TopKValues)
@dataclasses.dataclass
class TopKValuesOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: int64 = 100
    axis: Optional[int32] = None
    largest: bool = True
    sorted: bool = True


@Registry.register(LayerType.TransposeConvolution1d)
@dataclasses.dataclass
class TransposeConvolution1dOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    in_channels: int32
    out_channels: int32
    kernel: int32
    stride: int32
    dilation: int32
    west_padding: int32
    east_padding: int32
    group_number: int32
    weight: TensorIndex
    padding_list: Tuple[int32, ...] = ()
    og_padding_list: Tuple[int32, ...] = ()
    og_out_padding_list: Tuple[int32, ...] = ()
    bias: TensorIndex = -1
    channel_last: bool = True


@Registry.register(LayerType.TransposeConvolution)
@dataclasses.dataclass
class TransposeConvolutionOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    in_channels: int32
    out_channels: int32
    h_kernel: int32
    w_kernel: int32
    h_stride: int32
    w_stride: int32
    h_dilation: int32
    w_dilation: int32
    west_padding: int32
    east_padding: int32
    north_padding: int32
    south_padding: int32
    group_number: int32
    weight: TensorIndex
    padding_list: Tuple[int32, ...] = ()
    og_padding_list: Tuple[int32, ...] = ()
    og_out_padding_list: Tuple[int32, ...] = ()
    bias: TensorIndex = -1
    channel_last: bool = True


@Registry.register(LayerType.Transpose)
@dataclasses.dataclass
class TransposeOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    transpose_axes: Tuple[int64, ...]


@Registry.register(LayerType.Unpack)
@dataclasses.dataclass
class UnpackOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32, ...]
    num: int32
    axis: int32
    split_index: int32


@Registry.register(LayerType.Unsqueeze)
@dataclasses.dataclass
class UnsqueezeOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axes: Tuple[int32, ...]


@Registry.register(LayerType.Upsampling)
@dataclasses.dataclass
class UpsamplingOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    up_mode: str
    scales: Tuple[float32, ...]


@Registry.register(LayerType.Weightedsum)
@dataclasses.dataclass
class WeightedsumOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    weight0: TensorIndex
    weight1: TensorIndex


@Registry.register(LayerType.OrderedPatchify)
@dataclasses.dataclass
class OrderedPatchifyOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    h_kernel: int32
    w_kernel: int32
    order: int32 = 0


@Registry.register(LayerType.Where)
@dataclasses.dataclass
class WhereOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    condition_const: TensorIndex = -1
    X_const: TensorIndex = -1
    Y_const: TensorIndex = -1


@Registry.register(LayerType.TensorCmp)
@dataclasses.dataclass
class TensorCmpOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    kind: str = "eq"


@Registry.register(LayerType.Xor)
@dataclasses.dataclass
class XorOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: TensorIndex = -1
    is_const_first: bool = False


@Registry.register(LayerType.DynamicSliceInputConst)
@dataclasses.dataclass
class DynamicSliceInputConstOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    mod: int32
    start: Tuple[int64, ...]
    end: Tuple[int64, ...]
    axis: Tuple[int64, ...]
    step: Optional[Tuple[int64, ...]] = None


@Registry.register(LayerType.BatchNorm1d)
@dataclasses.dataclass
class BatchNorm1dOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    scale: TensorIndex
    bias: TensorIndex
    epsilon: TensorIndex
    moving_mean: TensorIndex
    moving_var: TensorIndex


@Registry.register(LayerType.RelShift)
@dataclasses.dataclass
class RelShiftOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]


@Registry.register(LayerType.Embedding)
@dataclasses.dataclass
class EmbeddingOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    weight: TensorIndex
    num_embeddings: int32
    embedding_dim: int32


@Registry.register(LayerType.AttentionMaskInput)
@dataclasses.dataclass
class AttentionMaskInputOptions(LayerOptions):
    outputs: Tuple[int32]
    sample_mask: TensorIndex
    inputs: Tuple = ()
    attn_mask_type: str = "causal_mask"


@Registry.register(LayerType.KVCacheInput)
@dataclasses.dataclass
class KVCacheInputOptions(LayerOptions):
    outputs: Tuple[int32]
    cache_name: str
    inputs: Tuple = ()


@Registry.register(LayerType.GetItem)
@dataclasses.dataclass
class GetItemOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    sel: Optional[int32] = None


@Registry.register(LayerType.MaskedFill)
@dataclasses.dataclass
class MaskedFillOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    value: float32


@Registry.register(LayerType.Arange)
@dataclasses.dataclass
class ArangeOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    start: Optional[float32] = None
    step: Optional[float32] = None


@Registry.register(LayerType.Repeat)
@dataclasses.dataclass
class RepeatOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    repeats: Optional[Tuple[int32, ...]] = None


@Registry.register(LayerType.Ones)
@dataclasses.dataclass
class OnesOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    dtype: str = "float32"


@Registry.register(LayerType.Zeros)
@dataclasses.dataclass
class ZerosOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    dtype: str = "float32"


@Registry.register(LayerType.Tril)
@dataclasses.dataclass
class TrilOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    diagonal: int32 = 0


@Registry.register(LayerType.Roll)
@dataclasses.dataclass
class RollOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    shifts: Tuple[int32, ...]
    dims: Tuple[int32, ...]


@Registry.register(LayerType.HFCache)
@dataclasses.dataclass
class HFCacheOptions(LayerOptions):
    outputs: Tuple[int32]
    cache_cls: str
    cache_name: str
    content: str
    inputs: Tuple = ()


@Registry.register(LayerType.HFCacheUpdate)
@dataclasses.dataclass
class HFCacheUpdateOptions(LayerOptions):
    inputs: Tuple[int32, int32, int32]
    outputs: Tuple[int32, int32]
    layer_idx: int32
    sliding_window: Optional[int32] = None
    past_seq_len: Optional[int32] = None


@Registry.register(LayerType.HFPatchedFunction)
@dataclasses.dataclass
class HFPatchedFunctionOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, ...]
    target: str
    content: str


@Registry.register(LayerType.MeloTTSPiecewiseRationalQuadraticTransform)
@dataclasses.dataclass
class MeloTTSPiecewiseRationalQuadraticTransformOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    num_bins: int32
    filter_channels: int32
    tail_bound: float32
    reverse: bool


@Registry.register(LayerType.IndexedItemSelector)
@dataclasses.dataclass
class IndexedItemSelectorOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    index: TensorIndex
    axis: int32 = 3
    scale: TensorIndex = -1
    bias: TensorIndex = -1


@Registry.register(LayerType.ChannelwiseApply)
@dataclasses.dataclass
class ChannelwiseApplyOptions(LayerOptions):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    func: TensorIndex
    group_number: int32 = 1
    input_scale: TensorIndex = -1
    input_bias: TensorIndex = -1
    output_scale: TensorIndex = -1
    output_bias: TensorIndex = -1


@Registry.register(LayerType.SubgraphCall)
@dataclasses.dataclass
class SubgraphCallOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, ...]
    subgraph: str
    scope: str
    kind: str


@Registry.register(LayerType.SubgraphScope)
@dataclasses.dataclass
class SubgraphScopeOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, ...]
    subgraph: str
    scope: str
    kind: str
    mode: str = "start"


@Registry.register(LayerType.MoeDispatcher)
@dataclasses.dataclass
class MoeDispatcherOptions(LayerOptions):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32, int32]
    top_k: int32
    norm_top_k_prob: bool = True


@Registry.register(LayerType.MoeAggregator)
@dataclasses.dataclass
class MoeAggregatorOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
