import json
import math
import operator
from collections import defaultdict
from numbers import Real
from typing import Dict, Tuple, List, Optional, Sequence, Any

import numpy
import torch

import qbcompiler.model_dict.common.options as layer_options
from . import (
    ActivationSpec,
    TensorSpec,
    Operator,
    DataFormat,
    SubGraph,
    DimValue,
)
from ..inference.shape.infer_shape import _biop_shape


def _set_producer_op(prod_op, outact):
    outact.producer_op = prod_op


def _get_unique_name(name: str, names):
    i = 0
    while True:
        nm = name + "_" + str(i)
        if nm not in names:
            return nm
        i += 1


def _tighten_end_padding(in_size, out_size, kernel, stride, pad_front, dilation):
    "returns new pad_end"
    pad_height = max(0, (out_size - 1) * stride - in_size + dilation * (kernel - 1) + 1)
    return pad_height - pad_front


def _conv_out_size(in_size: DimValue, pad_front, pad_end, kernel, dilation, stride):
    v = math.floor(
        (int(in_size) + (pad_front + pad_end) - dilation * (kernel - 1) - 1) / stride
        + 1
    )
    return DimValue(v, dynamic=in_size.dynamic)


def _ensure_int(x):
    if isinstance(x, int):
        return x
    if isinstance(x, tuple) and len(x) == 1:
        return x[0]
    raise ValueError(f"unable to get int value from {x}")


def _broadcast_shape(left_src_shape, right_src_shape):
    outact_src_shape = []
    if len(left_src_shape) < len(right_src_shape):
        left_src_shape = (
            (DimValue(1),) * (len(right_src_shape) - len(left_src_shape))
        ) + left_src_shape
    elif len(left_src_shape) > len(right_src_shape):
        right_src_shape = (
            (DimValue(1),) * (len(left_src_shape) - len(right_src_shape))
        ) + right_src_shape

    for ls, rs in zip(left_src_shape, right_src_shape):
        # we should create new instance here.
        if ls == 1 or rs == 1:
            v = DimValue(max(ls, rs))
        elif ls == rs:
            v = DimValue(ls)
        else:
            raise ValueError(f"unable to broadcast:{left_src_shape},{right_src_shape}")
        v.set_dynamic(any(x.dynamic for x in (ls, rs)))
        outact_src_shape.append(v)
    return outact_src_shape


def reduce_constant_for_broadcast(input_shape, output_shape, const):
    if len(const.shape) > len(input_shape):
        return None
    if len(const.shape) < len(input_shape):
        new_shape = (1,) * (len(input_shape) - len(const.shape)) + tuple(const.shape)
        const = numpy.reshape(const, new_shape)
    const_shape = const.shape
    reduce_axes = []
    for ax in range(len(const_shape)):
        if numpy.all(const == numpy.take(const, [0], axis=ax)):
            reduce_axes.append(ax)

    best_shape = list(const_shape)
    for ax in reduce_axes:
        trial = tuple(1 if idx == ax else x for idx, x in enumerate(best_shape))
        broadcastable = all(
            max(ishape, trial[i]) == output_shape[i]
            for i, ishape in enumerate(input_shape)
        )
        if broadcastable:
            best_shape[ax] = 1
    reduced = const
    if tuple(best_shape) != const_shape:
        for ax in range(const.ndim):
            if best_shape[ax] == 1 and const_shape[ax] != 1:
                reduced = numpy.take(reduced, [0], axis=ax)
    if reduced.shape[:-1] == (1,) * (reduced.ndim - 1):
        reduced = reduced.reshape(-1)
    return reduced, tuple(best_shape)


# noinspection PyTypeChecker
class MobilintSubGraphBuilder:
    # fixme: 이 클래스를 상속해서 만들도록 수정. 현재 hf 파싱용으로 작성된 subgraph builder가 SubGraphBuilder의 이름을 가지고 있음. 구현 완료 후 refactor.
    def __init__(
        self,
        global_weight_dict: Optional[Dict] = None,
        builder_name: str = "",
    ):
        self._operators = []
        self._activations = []
        self._tensors = []
        self._act_map: Dict[str, int] = {}
        self.builder_name = builder_name
        if global_weight_dict is None:
            global_weight_dict = {}
        self._weights: Dict = global_weight_dict

    @property
    def _activationspec_cls(self):
        return ActivationSpec

    def activationspec(
        self,
        name: str,
        dtype: str,
        src_shape,
        dataformat=DataFormat.UNKNOWN,
        cls_type=None,
    ) -> ActivationSpec:
        outact = self._activationspec_cls(
            name=name, dtype=dtype, src_shape=src_shape, dataformat=dataformat
        )
        self._add_activation(outact)
        return outact

    def copy_activationspec(
        self,
        x: ActivationSpec,
        name: str = None,
        dtype: str = None,
        shape=None,
        src_shape=None,
        dataformat=None,
        **kwargs,
    ):
        if dataformat is None:
            dataformat = (
                DataFormat.NHWC
                if x.dataformat == DataFormat.NHWC
                else DataFormat.UNKNOWN
            )
        x_copy = x.copy(
            name=name or x.name,
            dtype=dtype or x.dtype,
            shape=shape or x.shape,
            src_shape=src_shape or x.get_act_src_shape(),
            dataformat=dataformat,
        )
        self._add_activation(x_copy)
        return x_copy

    def __repr__(self):
        return f"SgBuilder[{self.builder_name}]"

    def build(self, name="", unsupported=True, stateful=False) -> SubGraph:
        sg = SubGraph()
        sg.name = name
        sg.operators = self._operators
        sg.tensors = self._tensors
        sg.activations = [
            ActivationSpec(
                x.name,
                x.dtype,
                None if hasattr(x, "value") else x.shape,
                x.src_shape if hasattr(x, "src_shape") else tuple(),
                x.dataformat if hasattr(x, "dataformat") else DataFormat.UNKNOWN,
            )
            for x in self._activations
        ]
        sg.unsupported = unsupported
        sg.stateful = stateful
        sg.update_op_act_connectivity()
        sg.update_graph_in_out()

        for op in self._operators:
            op.unsupported = unsupported

        return sg

    def _add_activation(self, act: ActivationSpec) -> int:
        """returns the index of a newly added activation."""
        if act.name in self._act_map:
            act.name = _get_unique_name(act.name, self._act_map)
        self._activations.append(act)
        idx = len(self._activations) - 1
        self._act_map[act.name] = idx
        return idx

    def add_weight(self, tensor_name: str, weight: numpy.ndarray | torch.Tensor) -> int:
        """returns the index of a newly added tensor."""

        if tensor_name in self._weights:
            tensor_name = _get_unique_name(tensor_name, self._weights)
        from .memory_aware_dict import ArrayWrapper

        if isinstance(weight, ArrayWrapper):
            weight = weight.value

        if isinstance(weight, torch.Tensor):
            if "bfloat16" in str(weight.dtype):
                weight = weight.to(torch.float)
            weight = weight.detach().cpu().numpy()
        if isinstance(weight, (int, float)):
            weight = numpy.array(weight)
        if isinstance(weight, (tuple, list)):
            weight = numpy.array(weight)
        ts = TensorSpec(
            name=tensor_name, dtype=weight.dtype.name, shape=tuple(weight.shape)
        )
        self._tensors.append(ts)
        self._weights[tensor_name] = weight
        return len(self._tensors) - 1

    def add_operator(self, op: Operator):
        op.name = self.get_activation(int(op.options.outputs[0])).name
        self._operators.append(op)

    def get_activation(self, name_or_index: int | str):
        if isinstance(name_or_index, str):
            return self._activations[self._act_map[name_or_index]]
        if isinstance(name_or_index, int):
            return self._activations[name_or_index]
        raise ValueError(f"{type(name_or_index)} is not found")

    def set_output_value_reference(
        self, outact: ActivationSpec, output_value_reference=None
    ):
        for op in self._operators:
            if op.name == outact.name:
                if output_value_reference is None:
                    op.output_value_reference = outact.name
                else:
                    op.output_value_reference = output_value_reference
                break

    def get_activation_index(self, act: ActivationSpec):
        return self._act_map[act.name]

    def get_tensor(self, tensor_idx: int):
        return self._tensors[tensor_idx]

    def make_flatten(self, x: ActivationSpec, axis: int = 0, opname=""):
        # follow onnx reshape, not torch
        if not opname:
            opname = x.name + "/flatten"
        inact_src_shape = x.get_act_src_shape()
        if axis < 0:
            axis += x.src_dim

        def flatten_shape(shape):
            cnt = math.prod(map(int, shape))
            dynamic = any(x.dynamic for x in shape)
            return DimValue(cnt, dynamic=dynamic)

        outact_src_shape = (
            flatten_shape(inact_src_shape[:axis]),
            flatten_shape(inact_src_shape[axis:]),
        )

        outact = self.activationspec(opname, x.dtype, outact_src_shape)
        op = Operator(
            name=outact.name,
            options=layer_options.FlattenOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                axis=axis,
            ),
        )
        self.add_operator(op)
        return outact

    def make_transpose(
        self,
        inact: ActivationSpec,
        transpose_axes,
        opname="",
    ):
        if not opname:
            opname = inact.name + "/transpose"
        outact_src_shape = operator.itemgetter(*transpose_axes)(
            inact.get_act_src_shape()
        )
        outact = self.activationspec(opname, inact.dtype, outact_src_shape)
        inact_idx = self.get_activation_index(inact)
        outact_idx = self.get_activation_index(outact)
        op_transpose = Operator(
            name=outact.name,
            options=layer_options.TransposeOptions(
                inputs=(inact_idx,),
                outputs=(outact_idx,),
                transpose_axes=transpose_axes,
            ),
        )
        self.add_operator(op_transpose)
        _set_producer_op(op_transpose, outact)
        return outact

    def make_matmul(
        self, left: ActivationSpec, right: ActivationSpec, repeat=(-1, -1), opname=""
    ):
        if not opname:
            opname = left.name + "/matmul"
        if isinstance(right, torch.Tensor):
            if right.dtype == torch.bfloat16:
                right = right.to(torch.float32).detach().cpu().numpy()
            else:
                right = right.detach().cpu().numpy()

        if isinstance(right, numpy.ndarray):
            if len(right.shape) == 2 and len(left.get_act_src_shape()) == 3:
                n, x, c = left.get_act_src_shape()
                reshaped_inact = self.make_reshape(left, shape=(n, 1, x, c))
                in_channels, out_channels = right.shape
                weight = numpy.transpose(right, (1, 0)).reshape(
                    out_channels, in_channels, 1, 1
                )
                outact = self.make_conv2d(
                    reshaped_inact, in_channels, out_channels, weight=weight
                )
                return self.make_reshape(outact, shape=(n, x, out_channels))
            elif len(right.shape) == len(left.get_act_src_shape()) == 2:
                x, c = left.get_act_src_shape()
                reshaped_inact = self.make_reshape(left, shape=(1, 1, x, c))
                in_channels, out_channels = right.shape
                weight = numpy.transpose(right, (1, 0)).reshape(
                    out_channels, in_channels, 1, 1
                )
                outact = self.make_conv2d(
                    reshaped_inact, in_channels, out_channels, weight=weight
                )
                return self.make_reshape(outact, shape=(x, out_channels))
            elif len(left.get_act_src_shape()) == 4 and len(right.shape) < left.src_dim:
                return self.make_gemmconst(left, right)
            else:
                raise NotImplementedError()

        left_idx = self.get_activation_index(left)
        right_idx = self.get_activation_index(right)

        assert left.get_act_src_shape()[-1] == right.get_act_src_shape()[-2]
        left_shape = left.get_act_src_shape()
        right_shape = right.get_act_src_shape()
        if repeat != (-1, -1):
            assert len(left_shape) == len(right_shape) == 4
            assert repeat[0] == 1 and int(repeat[1]) * int(right_shape[1]) == int(
                left_shape[1]
            )
            mm_out_shape = left_shape[:3] + (right_shape[-1],)
            output_dformat = DataFormat.NHWC
        else:
            if len(left_shape) == len(right_shape) == 4:
                mm_out_shape = left_shape[:3] + (right_shape[-1],)
                output_dformat = DataFormat.NHWC
            elif len(left_shape) == len(right_shape) == 5:
                mm_out_shape = left_shape[:4] + (right_shape[-1],)
                output_dformat = DataFormat.UNKNOWN
            elif len(left_shape) == 4 and len(right_shape) == 2:
                mm_out_shape = left_shape[:3] + (right_shape[-1],)
                output_dformat = DataFormat.NHWC
            elif len(left_shape) == 3 == len(right_shape) == 3:
                mm_out_shape = left_shape[:2] + (right_shape[-1],)
                output_dformat = DataFormat.UNKNOWN
            elif len(left_shape) == 3 and len(right_shape) == 2:
                mm_out_shape = left_shape[:2] + (right_shape[-1],)
                output_dformat = DataFormat.UNKNOWN
            elif len(left_shape) == len(right_shape) == 2:
                mm_out_shape = left_shape[:1] + (right_shape[-1],)
                output_dformat = DataFormat.UNKNOWN
            else:
                raise NotImplementedError(f"{left_shape}, {right_shape}")
        outact = self.activationspec(opname, left.dtype, mm_out_shape, output_dformat)
        op_matmul = Operator(
            outact.name,
            options=layer_options.MatMulOptions(
                inputs=(left_idx, right_idx),
                outputs=(self.get_activation_index(outact),),
                repeat=repeat,
            ),
        )
        self.add_operator(op_matmul)
        _set_producer_op(op_matmul, outact)
        return outact

    def _make_mulconst(
        self,
        inact: ActivationSpec,
        const_val,
        const_name="",
        opname="",
    ):
        if not opname:
            opname = inact.name + "/mul"
        if not const_name:
            const_name = opname + ".const"
        outact = self.activationspec(opname, inact.dtype, inact.src_shape, inact.dtype)
        outact_idx = self.get_activation_index(outact)
        inact_idx = self.get_activation_index(inact)
        if isinstance(const_val, torch.Tensor):
            const_val = const_val.detach().cpu().numpy()
        if not isinstance(const_val, numpy.ndarray):
            const_val = numpy.array(const_val)
        ts_idx = self.add_weight(const_name, const_val)
        mc = Operator(
            name=outact.name,
            options=layer_options.MultiplyConstantOptions(
                inputs=(inact_idx,), outputs=(outact_idx,), constant=ts_idx
            ),
        )
        self.add_operator(mc)
        _set_producer_op(mc, outact)
        return outact

    def make_reduce_l2(
        self,
        inact: ActivationSpec,
        reduce_axes,
        keep_dims,
        noop_with_empty_axes=0,
        opname: str = "",
    ):
        if not opname:
            opname = inact.name + "/reduceL2"

        output_src_shape = list(inact.get_act_src_shape())
        for ax in reduce_axes:
            output_src_shape[ax] = 1
        if not keep_dims:
            output_src_shape = [
                x for idx, x in enumerate(output_src_shape) if idx not in reduce_axes
            ]
        outact = self.copy_activationspec(
            inact,
            name=opname,
            src_shape=output_src_shape,
            dataformat=DataFormat.UNKNOWN,
        )
        op = Operator(
            outact.name,
            options=layer_options.ReduceL2Options(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                keep_dims=keep_dims,
                noop_with_empty_axes=noop_with_empty_axes,
                reduce_axes=reduce_axes,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_reduce_min(
        self,
        inact: ActivationSpec,
        reduce_axes,
        keep_dims,
        noop_with_empty_axes=0,
        opname: str = "",
    ):
        if not opname:
            opname = inact.name + "/reduceMin"

        output_src_shape = list(inact.get_act_src_shape())
        for ax in reduce_axes:
            output_src_shape[ax] = 1
        if not keep_dims:
            output_src_shape = [
                x for idx, x in enumerate(output_src_shape) if idx not in reduce_axes
            ]
        outact = self.copy_activationspec(
            inact,
            name=opname,
            src_shape=output_src_shape,
            dataformat=DataFormat.UNKNOWN,
        )

        op = Operator(
            outact.name,
            options=layer_options.ReduceMinOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                keep_dims=keep_dims,
                noop_with_empty_axes=noop_with_empty_axes,
                reduce_axes=reduce_axes,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_reduce_max(
        self,
        inact: ActivationSpec,
        reduce_axes,
        keep_dims,
        noop_with_empty_axes=0,
        opname: str = "",
    ):
        if not opname:
            opname = inact.name + "/reduceMax"

        output_src_shape = list(inact.get_act_src_shape())
        for ax in reduce_axes:
            output_src_shape[ax] = 1
        if not keep_dims:
            output_src_shape = [
                x for idx, x in enumerate(output_src_shape) if idx not in reduce_axes
            ]
        outact = self.copy_activationspec(
            inact,
            name=opname,
            src_shape=output_src_shape,
            dataformat=DataFormat.UNKNOWN,
        )

        op = Operator(
            outact.name,
            options=layer_options.ReduceMaxOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                keep_dims=keep_dims,
                noop_with_empty_axes=noop_with_empty_axes,
                reduce_axes=reduce_axes,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_reduce_prod(
        self,
        inact: ActivationSpec,
        reduce_axes,
        keep_dims,
        noop_with_empty_axes=0,
        opname: str = "",
    ):
        if not opname:
            opname = inact.name + "/reduceProd"

        output_src_shape = list(inact.get_act_src_shape())
        for ax in reduce_axes:
            output_src_shape[ax] = 1
        if not keep_dims:
            output_src_shape = [
                x for idx, x in enumerate(output_src_shape) if idx not in reduce_axes
            ]
        outact = self.copy_activationspec(
            inact,
            name=opname,
            src_shape=output_src_shape,
            dataformat=DataFormat.UNKNOWN,
        )

        op = Operator(
            outact.name,
            options=layer_options.ReduceProdOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                keep_dims=keep_dims,
                noop_with_empty_axes=noop_with_empty_axes,
                reduce_axes=reduce_axes,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_reduce_mean(
        self,
        inact: ActivationSpec,
        dim: List[int],
        keep_dims=False,
        noop_with_empty_axes=0,
        opname="",
    ):
        # fixme: dim->reduce_axes
        if not opname:
            opname = inact.name + "/mean"
        in_src_shape = inact.get_act_src_shape()
        if isinstance(dim, int):
            dims = (dim,)
        elif isinstance(dim, (list, tuple)):
            dims = dim
        else:
            raise NotImplementedError(
                f"Torch dim value type must be int or sequence container containing int type got {dim}"
            )

        dims_ = tuple(x + len(inact.get_act_src_shape()) if x < 0 else x for x in dims)
        if keep_dims:
            out_src_shape = tuple(
                in_shape if idx not in dims_ else 1
                for idx, in_shape in enumerate(in_src_shape)
            )
        else:
            out_src_shape = tuple(
                in_shape
                for idx, in_shape in enumerate(in_src_shape)
                if idx not in dims_
            )

        outact = self.activationspec(
            opname, inact.dtype, out_src_shape, dataformat=DataFormat.UNKNOWN
        )
        inact_idx = self.get_activation_index(inact)
        outact_idx = self.get_activation_index(outact)

        op_reduce_mean = Operator(
            name=outact.name,
            options=layer_options.ReduceMeanOptions(
                inputs=(inact_idx,),
                outputs=(outact_idx,),
                reduce_axes=dims,
                keep_dims=keep_dims,
                noop_with_empty_axes=noop_with_empty_axes,  # onnx default
            ),
        )

        self.add_operator(op_reduce_mean)
        _set_producer_op(op_reduce_mean, outact)
        return outact

    def make_reshape_v2(
        self,
        inact: ActivationSpec,
        shape: ActivationSpec,
        new_shape_hint,
        is_const_first: bool = False,
        opname: str = "",
    ):
        if is_const_first:
            raise NotImplementedError
        if not opname:
            opname = inact.name + "/reshape"

        def cnt(src):
            return math.prod(map(int, src))

        num_free_axis = sum(s == -1 for s in new_shape_hint)
        assert num_free_axis <= 1
        if num_free_axis == 0:
            outact_src_shape = new_shape_hint
        else:
            free_axis = new_shape_hint.index(-1)

            old_shape = inact.get_act_src_shape()
            total_elements = cnt(old_shape)
            known_product = cnt(
                x for ax, x in enumerate(new_shape_hint) if ax != free_axis
            )
            inferred_value = total_elements // known_product
            outact_src_shape = tuple(
                DimValue(x) if ax != free_axis else DimValue(inferred_value)
                for ax, x in enumerate(new_shape_hint)
            )
            assert all(s > 0 for s in old_shape)
            pre_cnt = (
                int(cnt(new_shape_hint[:free_axis]))
                if len(new_shape_hint[:free_axis]) > 0
                else 0
            )
            related_axes = list(range(len(old_shape)))
            for ax, s in enumerate(old_shape):
                if pre_cnt == 0:
                    break
                pre_cnt, r = divmod(pre_cnt, int(s))
                if r > 0:
                    if pre_cnt == 0:
                        break
                    raise ValueError
                else:
                    related_axes.remove(ax)
                    if pre_cnt == 1:
                        break
            post_cnt = (
                int(cnt(new_shape_hint[free_axis + 1 :]))
                if len(new_shape_hint[free_axis + 1 :]) > 0
                else 0
            )
            for ax, s in reversed(list(enumerate(old_shape))):
                if post_cnt == 0:
                    break
                post_cnt, r = divmod(post_cnt, int(s))
                if r > 0:
                    if post_cnt == 0:
                        break
                    raise ValueError
                else:
                    related_axes.remove(ax)
                    if post_cnt == 1:
                        break

            if any(old_shape[ax].dynamic for ax in related_axes):
                outact_src_shape[free_axis].set_dynamic()

        outact = self.activationspec(opname, inact.dtype, src_shape=outact_src_shape)
        op = Operator(
            name=outact.name,
            options=layer_options.ReshapeV2Options(
                inputs=(
                    self.get_activation_index(inact),
                    self.get_activation_index(shape),
                ),
                outputs=(self.get_activation_index(outact),),
                allowzero=0,
                is_const_first=is_const_first,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_spatial_broadcast(
        self, inact: ActivationSpec, output_spatial_shape, opname: str = ""
    ):
        if not opname:
            opname = inact.name + "/broadcast"
        n, h, w, c = inact.get_act_src_shape()
        output_shape = (n,) + output_spatial_shape + (c,)
        outact = self.activationspec(opname, dtype=inact.dtype, src_shape=output_shape)
        op = Operator(
            name=outact.name,
            options=layer_options.SpatialBroadcastOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                output_spatial_shape=output_spatial_shape,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_reshape(
        self,
        inact: ActivationSpec,
        shape: Tuple[int | DimValue, ...],
        new_dataformat=None,
        opname="",
    ):
        if not opname:
            opname = inact.name + "/reshape"

        def cnt(src):
            return math.prod(map(int, src))

        if new_dataformat is None:
            new_dataformat = DataFormat.UNKNOWN

        in_src_shape = inact.get_act_src_shape()
        num_free = sum(-1 == x for x in shape)

        # todo: 일반화 하기.
        shape = tuple(DimValue(x) for x in shape)
        if len(shape) > 0:
            if (
                all(not x.dynamic for x in shape)
                and len(in_src_shape) == len(shape) + 1
                and in_src_shape[0] == shape[0]
                and in_src_shape[1] == 1
                and in_src_shape[2:] == tuple(shape[1:])
            ):
                #     unsqueeze dim=1
                for idx, v in enumerate(in_src_shape[:1] + in_src_shape[2:]):
                    shape[idx].set_dynamic(v.dynamic)
            elif (
                all(not x.dynamic for x in shape)
                and len(in_src_shape) == len(shape) + 1
                and in_src_shape[0] == shape[0]
                and in_src_shape[3:] == tuple(shape[2:])
                and in_src_shape[1] * in_src_shape[2] == shape[1]
            ):
                #     unsqueeze dim=1
                for idx, v in enumerate(in_src_shape[:1] + in_src_shape[2:]):
                    shape[idx].set_dynamic(v.dynamic)
            elif (
                all(not x.dynamic for x in shape)
                and len(in_src_shape) + 1 == len(shape)
                and in_src_shape[-1] == shape[-1]
                and shape[0] == 1
            ):
                for idx, v in enumerate(in_src_shape):
                    shape[idx + 1].set_dynamic(v.dynamic)

        output_src_shape = list(shape)
        if num_free > 1:
            raise ValueError("can only specify one unknown dimension")
        elif num_free == 1:
            elem_cnt = cnt(in_src_shape)
            denom = cnt((x for x in shape if x != -1))
            inferred_value = elem_cnt // denom
            free_axis = output_src_shape.index(-1)
            output_src_shape = tuple(
                DimValue(x) if ax != free_axis else DimValue(inferred_value)
                for ax, x in enumerate(output_src_shape)
            )
            pre_cnt = int(cnt(shape[:free_axis])) if len(shape[:free_axis]) > 0 else 0
            old_shape = inact.get_act_src_shape()
            related_axes = list(range(len(old_shape)))
            precise_related_axes = True
            for ax, s in enumerate(old_shape):
                if pre_cnt == 0:
                    break
                pre_cnt, r = divmod(pre_cnt, int(s))
                if r > 0:
                    precise_related_axes = False
                    break
                else:
                    related_axes.remove(ax)
                    if pre_cnt == 1:
                        break
            post_cnt = (
                int(cnt(shape[free_axis + 1 :]))
                if len(shape[free_axis + 1 :]) > 0
                else 0
            )
            for ax, s in reversed(list(enumerate(old_shape))):
                if post_cnt == 0:
                    break
                post_cnt, r = divmod(post_cnt, int(s))
                if r > 0:
                    precise_related_axes = False
                    break
                else:
                    related_axes.remove(ax)
                    if post_cnt == 1:
                        break
            if precise_related_axes and any(
                old_shape[ax].dynamic for ax in related_axes
            ):
                output_src_shape[free_axis].set_dynamic()
            elif not precise_related_axes and any(dim.dynamic for dim in old_shape):
                output_src_shape[free_axis].set_dynamic()

        assert cnt(inact.get_act_src_shape()) == cnt(
            output_src_shape
        ), f"{cnt(inact.get_act_src_shape())} == {cnt(output_src_shape)}"
        outact = self.activationspec(
            opname, inact.dtype, tuple(output_src_shape), new_dataformat
        )
        outact_idx = self.get_activation_index(outact)
        inact_idx = self.get_activation_index(inact)
        op = Operator(
            name=outact.name,
            options=layer_options.ReshapeOptions(
                inputs=(inact_idx,),
                outputs=(outact_idx,),
                allowzero=0,
                new_shape=shape,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_squeeze(
        self,
        inact: ActivationSpec,
        squeeze_axes: Optional[Tuple[int, ...]] = None,
        opname="",
    ):
        if not opname:
            opname = inact.name + "/squeeze"

        # To enable multiple squeeze_axes
        # if not (squeeze_axes is None or len(squeeze_axes) == 1):
        #     raise NotImplementedError()

        shape_ = inact.get_act_src_shape()
        new_src_shape = shape_
        if squeeze_axes is not None:
            if inact.get_act_src_shape() == (0,) and tuple(squeeze_axes) == (0,):
                new_src_shape = tuple()
            elif len(squeeze_axes) == 1:
                axis = squeeze_axes[0]
                if axis < 0:
                    axis += len(shape_)
                if shape_[axis] == 1 or shape_[axis] == 0:
                    new_src_shape = shape_[:axis] + shape_[axis + 1 :]
                else:
                    # No change if the specified axis is not 1
                    raise NotImplementedError(
                        f"make_squeeze, shape={shape_}, squeeze_axes={squeeze_axes}"
                    )
            else:
                axes = list(squeeze_axes)
                temp_shape = shape_
                while len(axes) > 0:
                    axis = axes.pop(-1)
                    if axis < 0:
                        axis += len(shape_)
                    if shape_[axis] == 1:
                        temp_shape = temp_shape[:axis] + temp_shape[axis + 1 :]
                    else:
                        continue
                new_src_shape = temp_shape
        else:
            new_src_shape = tuple(dim for dim in shape_ if dim != 1)

        outact = self.activationspec(opname, inact.dtype, new_src_shape)
        op = Operator(
            name=opname,
            options=layer_options.SqueezeOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                squeeze_axes=squeeze_axes,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_headerview_revert(
        self,
        inact: ActivationSpec,
        revert_shape=None,
        num_heads: int = -1,
        batch_order: int = 0,
        opname="",
    ):
        if not opname:
            opname = inact.name + "/headerviewrevert"
        if revert_shape is None:
            assert num_heads > 0, f"num_heads > 0 got num_heads={num_heads}"
            n, h, w, c = inact.get_act_src_shape()
            src_shape = (n, h // num_heads, w, c * num_heads)
        else:
            src_shape = revert_shape
            n, h, w, c = inact.get_act_src_shape()
            num_heads = int(revert_shape[-1]) // int(c)

        outact = self.activationspec(opname, inact.dtype, src_shape=src_shape)
        outact_idx = self.get_activation_index(outact)
        inact_idx = self.get_activation_index(inact)

        op = Operator(
            name=outact.name,
            options=layer_options.HeaderViewRevertOptions(
                inputs=(inact_idx,),
                outputs=(outact_idx,),
                revert_shape=src_shape,
                num_heads=num_heads,
                batch_order=batch_order,
            ),
        )

        self.add_operator(op)
        _set_producer_op(op, outact)

        return outact

    def make_headerview(
        self,
        inact: ActivationSpec,
        view_shape=None,
        num_heads: int = -1,
        batch_order: int = 0,
        opname="",
    ):
        if not opname:
            opname = inact.name + "/headerview"
        if view_shape is None:
            assert num_heads > 0, "num_heads > 0"
            n, h, w, c = inact.get_act_src_shape()
        else:
            n, h, w, c = inact.get_act_src_shape()
            num_heads = int(c) // int(view_shape[-1])
        src_shape = (n, h * num_heads, w, c // num_heads)

        outact = self.activationspec(
            opname, inact.dtype, src_shape=src_shape, dataformat=DataFormat.NHWC
        )
        outact_idx = self.get_activation_index(outact)
        inact_idx = self.get_activation_index(inact)

        op = Operator(
            name=outact.name,
            options=layer_options.HeaderViewOptions(
                inputs=(inact_idx,),
                outputs=(outact_idx,),
                view_shape=tuple(src_shape),
                num_heads=num_heads,
                batch_order=batch_order,
            ),
        )

        self.add_operator(op)
        _set_producer_op(op, outact)

        return outact

    def make_unsqueeze(self, inact: ActivationSpec, axis: int, opname=""):
        if not opname:
            opname = inact.name + "/unsqueeze"
        shape_ = inact.get_act_src_shape()
        if axis < 0:
            axis += len(shape_) + 1
        new_src_shape = shape_[:axis] + (1,) + shape_[axis:]

        outact = self.activationspec(opname, inact.dtype, src_shape=new_src_shape)
        outact_idx = self.get_activation_index(outact)
        inact_idx = self.get_activation_index(inact)
        op = Operator(
            name=outact.name,
            options=layer_options.UnsqueezeOptions(
                inputs=(inact_idx,), outputs=(outact_idx,), axes=(axis,)
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def _make_simple_biop(
        self, left: ActivationSpec, right: ActivationSpec, opkind, opname=""
    ):
        if not opname:
            opname = opkind

        left_src_shape = left.src_shape
        right_src_shape = right.src_shape

        outact_src_shape = _broadcast_shape(left_src_shape, right_src_shape)

        if left.dataformat == right.dataformat:
            dformat = left.dataformat
        elif len(left_src_shape) < len(right_src_shape):
            dformat = right.dataformat
        elif len(right_src_shape) < len(left_src_shape):
            dformat = left.dataformat
        else:
            dformat = DataFormat.UNKNOWN

        outact = self.activationspec(
            opname, left.dtype, outact_src_shape, dformat, cls_type=type(left)
        )
        outact_idx = self.get_activation_index(outact)
        left_idx = self.get_activation_index(left)
        right_idx = self.get_activation_index(right)
        if opkind == "add":
            option_cls = layer_options.AddingOptions
        elif opkind == "mul":
            option_cls = layer_options.MultiplyOptions
        elif opkind == "sub":
            option_cls = layer_options.SubOptions
        elif opkind == "mod":
            option_cls = layer_options.ModV2Options
        elif opkind == "div":
            option_cls = layer_options.DivOptions
        else:
            raise NotImplementedError(f"{opkind} is not implemented.")
        bi_op = Operator(
            name=outact.name,
            options=option_cls(
                inputs=(left_idx, right_idx),
                outputs=(outact_idx,),
            ),
        )
        self.add_operator(bi_op)
        _set_producer_op(bi_op, outact)
        return outact

    def _make_biop_const(
        self,
        x: ActivationSpec | Any,
        const: Any,
        opkind: str,
        is_const_first: bool,
        opname="",
    ):
        if opkind == "add":
            option_cls = layer_options.AddingConstantOptions
        elif opkind == "mul":
            option_cls = layer_options.MultiplyConstantOptions
        elif opkind == "div":
            option_cls = layer_options.DivConstantOptions
        elif opkind == "sub":
            option_cls = layer_options.SubConstantOptions
        elif opkind == "mod":
            option_cls = layer_options.ModOptions
        else:
            raise NotImplementedError(f"{opkind} const is not implemented.")

        if not opname:
            opname = x.name + "/" + opkind
        const_name = opname + ".const"

        if isinstance(const, torch.Tensor):
            if const.dtype == torch.bfloat16:
                const = const.to(torch.float32)
            const = const.detach().cpu().numpy()
        if isinstance(const, DimValue):
            const = int(const)
        if not isinstance(const, numpy.ndarray):  # int, float
            const = numpy.array(const)

        output_shape = _biop_shape(x.src_shape, const.shape)
        reduced = reduce_constant_for_broadcast(
            tuple(map(int, x.src_shape)), tuple(map(int, output_shape)), const
        )
        if reduced is not None:
            const = reduced[0]
        const_rank = const.ndim
        if const.shape[: const_rank - 1] == (1,) * (const_rank - 1):
            const = const.reshape(-1)

        outact = self.copy_activationspec(
            x, name=opname, src_shape=output_shape, shape=None
        )
        op = Operator(
            name=outact.name,
            options=option_cls(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                constant=self.add_weight(const_name, weight=const),
                is_const_first=is_const_first,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def is_act_value_type(self, x):
        return isinstance(x, self._activationspec_cls)

    def _make_biop(
        self, left: ActivationSpec, right: ActivationSpec, opkind, opname=""
    ):
        if self.is_act_value_type(left) and self.is_act_value_type(right):
            return self._make_simple_biop(left, right, opkind=opkind, opname=opname)

        if self.is_act_value_type(left):
            return self._make_biop_const(
                left, const=right, opkind=opkind, is_const_first=False, opname=opname
            )

        if self.is_act_value_type(right):
            return self._make_biop_const(
                right, const=left, opkind=opkind, is_const_first=True, opname=opname
            )

        raise NotImplementedError(f"{left} and {right} are not implemented.")

    def make_add(
        self, left: ActivationSpec | Any, right: ActivationSpec | Any, opname=""
    ):
        return self._make_biop(left, right, opkind="add", opname=opname)

    def make_sub(
        self, left: ActivationSpec | Any, right: ActivationSpec | Any, opname=""
    ):
        return self._make_biop(left, right, opkind="sub", opname=opname)

    def make_mul(
        self, left: ActivationSpec | Any, right: ActivationSpec | Any, opname=""
    ):
        return self._make_biop(left, right, opkind="mul", opname=opname)

    def make_div(
        self, left: ActivationSpec | Any, right: ActivationSpec | Any, opname=""
    ):
        return self._make_biop(left, right, opkind="div", opname=opname)

    def make_softplus(self, x: ActivationSpec, beta=1.0, threshold=20.0, opname=""):
        return self.make_act_func(
            x, act_kind="softplus", beta=beta, threshold=threshold, opname=opname
        )

    def make_softmax(self, inact: ActivationSpec, axis=-1, beta=1, opname=""):
        if not opname:
            opname = inact.name + "/softmax"
        outact = self.copy_activationspec(inact, name=opname)
        outact_idx = self.get_activation_index(outact)
        inact_idx = self.get_activation_index(inact)
        op = Operator(
            name=outact.name,
            options=layer_options.SoftmaxOptions(
                inputs=(inact_idx,), outputs=(outact_idx,), axis=axis, beta=beta
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)

        return outact

    def make_act_func(self, x: ActivationSpec, act_kind, opname="", **kwargs):
        if act_kind == "selu":
            cls = layer_options.SeluOptions
            kwargs["alpha"] = kwargs.get("alpha", 1.67326)
            kwargs["gamma"] = kwargs.get("gamma", 1.0507)
        elif act_kind == "swish":
            cls = layer_options.SwishOptions
        elif act_kind == "hardswish":
            cls = layer_options.HardSwishOptions
        elif act_kind == "mish":
            cls = layer_options.MishOptions
        elif act_kind == "gelu":
            cls = layer_options.GeluOptions
        elif act_kind == "sigmoid":
            cls = layer_options.SigmoidOptions
        elif act_kind == "hardsigmoid":
            cls = layer_options.HardSigmoidOptions
        elif act_kind == "relu":
            cls = layer_options.ReluOptions
        elif act_kind == "exp":
            cls = layer_options.ExpOptions
        elif act_kind == "leakyrelu":
            cls = layer_options.LeakyReluOptions
        elif act_kind == "tanh":
            cls = layer_options.TanhOptions
        elif act_kind == "softplus":
            cls = layer_options.SoftplusOptions
        elif act_kind == "hardtanh":
            cls = layer_options.HardtanhOptions
        elif act_kind == "prelu":
            cls = layer_options.PReluOptions
            kwargs["leaky_alpha"] = self.add_weight(
                opname + ".bias", kwargs["leaky_alpha"]
            )
        elif act_kind == "elu":
            cls = layer_options.EluOptions
        elif act_kind == "celu":
            cls = layer_options.CeluOptions
        elif act_kind == "quickgelu":
            cls = layer_options.QuickGeluOptions
        elif act_kind == "pow":
            cls = layer_options.PowOptions
        elif act_kind == "clip":
            cls = layer_options.ClipOptions
            clip_min_value = kwargs.get("clip_min_value")
            clip_max_value = kwargs.get("clip_max_value")
            if isinstance(clip_min_value, numpy.ndarray):
                arr = numpy.asarray(kwargs["clip_min_value"])
                if arr.size != 1:
                    raise ValueError(
                        f"clip_min_value must be scalar/size-1 ndarray, got shape={arr.shape}"
                    )
                kwargs["clip_min_value"] = (
                    float(arr.item()) if arr.size == 1 else float(arr.flatten()[0])
                )
            elif isinstance(clip_min_value, Real) or clip_min_value is None:
                pass
            else:
                raise ValueError(
                    f"An incorrect clip value was used. Please verify the clip value."
                )

            if isinstance(clip_max_value, numpy.ndarray):
                arr = numpy.asarray(kwargs["clip_max_value"])
                if arr.size != 1:
                    raise ValueError(
                        f"clip_max_value must be scalar/size-1 ndarray, got shape={arr.shape}"
                    )
                kwargs["clip_max_value"] = (
                    float(arr.item()) if arr.size == 1 else float(arr.flatten()[0])
                )
            elif isinstance(clip_max_value, Real) or clip_max_value is None:
                pass
            else:
                raise ValueError(
                    f"An incorrect clip value was used. Please verify the clip value."
                )
        else:
            raise NotImplementedError(f"{act_kind} is not implemented.")
        if not opname:
            opname = x.name + "/" + act_kind
        outact = self.copy_activationspec(x, name=opname)
        act_out_idx = self.get_activation_index(outact)
        act_in_idx = self.get_activation_index(x)
        op = Operator(
            outact.name,
            options=cls(inputs=(act_in_idx,), outputs=(act_out_idx,), **kwargs),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_ceil(self, x: ActivationSpec, opname=""):
        if not opname:
            opname = x.name + "/" + "ceil"
        outact = self.copy_activationspec(x, name=opname)
        op = Operator(
            outact.name,
            options=layer_options.CeilOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_clip(
        self, x: ActivationSpec, clip_min_value=None, clip_max_value=None, opname=""
    ):
        return self.make_act_func(
            x,
            "clip",
            clip_min_value=clip_min_value,
            clip_max_value=clip_max_value,
            opname=opname,
        )

    def make_relu6(self, x: ActivationSpec, opname=""):
        return self.make_clip(x, 0.0, 6.0, opname)

    def make_tanh(self, x: ActivationSpec, opname=""):
        return self.make_act_func(x, "tanh", opname=opname)

    def make_exp(self, x: ActivationSpec, opname=""):
        return self.make_act_func(x, "exp", opname=opname)

    def make_swish(self, x: ActivationSpec, opname=""):
        return self.make_act_func(x, "swish", opname=opname)

    def make_hardswish(self, x: ActivationSpec, opname=""):
        return self.make_act_func(x, "hardswish", opname=opname)

    def make_gelu(self, x: ActivationSpec, approximate=False, opname=""):
        return self.make_act_func(x, "gelu", approximate=approximate, opname=opname)

    def make_relu(self, x: ActivationSpec, opname=""):
        return self.make_act_func(x, "relu", opname=opname)

    def make_hardtanh(self, x: ActivationSpec, opname="", **kwargs):
        return self.make_act_func(x, "hardtanh", opname=opname, **kwargs)

    def make_leaky_relu(self, x: ActivationSpec, leaky_alpha=0.01, opname=""):
        return self.make_act_func(
            x, "leakyrelu", leaky_alpha=leaky_alpha, opname=opname
        )

    def make_threshold(
        self,
        x: ActivationSpec,
        lower_threshold: float = None,
        lower_value: float = None,
        upper_threshold: float = None,
        upper_value: float = None,
        opname: str = "",
    ) -> ActivationSpec:
        if not opname:
            opname = x.name + "/threshold"

        outact = self.copy_activationspec(x, name=opname)
        inact_idx = self.get_activation_index(x)
        outact_idx = self.get_activation_index(outact)

        op = Operator(
            name=outact.name,
            options=layer_options.ThresholdOptions(
                inputs=(inact_idx,),
                outputs=(outact_idx,),
                lower_threshold=lower_threshold,
                lower_value=lower_value,
                upper_threshold=upper_threshold,
                upper_value=upper_value,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_conv1d(
        self,
        inact: ActivationSpec,
        in_channels,
        out_channels,
        kernel=1,
        stride=1,
        dilation=1,
        west_padding=0,
        east_padding=0,
        group_number=1,
        weight=None,
        bias=None,
        opname="",
    ):
        if not opname:
            opname = inact.name + "/conv1d"

        # TODO: Question
        assert len(inact.get_act_src_shape()) == 3

        n, w, c = inact.get_act_src_shape()
        if c != in_channels:
            raise ValueError(
                f"conv1d in_channels does not match with input_shape={(n, w, c)}"
            )

        kernel = _ensure_int(kernel)
        dilation = _ensure_int(dilation)
        stride = _ensure_int(stride)

        w_out = _conv_out_size(w, west_padding, east_padding, kernel, dilation, stride)

        outact = self.activationspec(
            opname, inact.dtype, (n, w_out, out_channels), DataFormat.NXC
        )
        outact_idx = self.get_activation_index(outact)
        inact_idx = self.get_activation_index(inact)

        in_ch = in_channels // group_number
        if isinstance(weight, torch.Tensor):
            conv_weight = weight.reshape((out_channels, in_ch, kernel)).to(torch.float)
        else:
            conv_weight = weight.reshape((out_channels, in_ch, kernel)).astype(
                numpy.float32
            )
        conv_weight_idx = self.add_weight(opname + ".weight", conv_weight)

        conv_bias_idx = -1
        if bias is not None:
            if isinstance(weight, torch.Tensor):
                conv_bias = bias.to(torch.float)
            else:
                conv_bias = bias.astype(numpy.float32)
            conv_bias_idx = self.add_weight(opname + ".bias", conv_bias)

        op = Operator(
            name=outact.name,
            options=layer_options.Convolution1dOptions(
                inputs=(inact_idx,),
                outputs=(outact_idx,),
                in_channels=in_channels,
                out_channels=out_channels,
                kernel=kernel,
                stride=stride,
                dilation=dilation,
                west_padding=west_padding,
                east_padding=east_padding,
                group_number=group_number,
                weight=conv_weight_idx,
                bias=conv_bias_idx,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_transposeconv1d(
        self,
        inact: ActivationSpec,
        in_channels,
        out_channels,
        kernel=1,
        stride=1,
        dilation=1,
        west_padding=0,
        east_padding=0,
        group_number=1,
        weight=None,
        bias=None,
        opname="",
    ):
        if not opname:
            opname = inact.name + "/tconv1d"

        n, w, c = inact.get_act_src_shape()
        if c != in_channels:
            raise ValueError(
                f"tconv1d in_channels does not match with input_shape={(n, w, c)}"
            )

        kernel = _ensure_int(kernel)
        dilation = _ensure_int(dilation)
        stride = _ensure_int(stride)

        strided_input_len = (w - 1) * stride + 1
        out_len = _conv_out_size(
            strided_input_len, west_padding, east_padding, kernel, dilation, 1
        )

        outact = self.copy_activationspec(
            inact, name=opname, src_shape=(n, out_len, out_channels)
        )
        outact_idx = self.get_activation_index(outact)
        inact_idx = self.get_activation_index(inact)

        in_ch = in_channels // group_number
        conv_weight = weight.reshape((out_channels, in_ch, kernel)).to(torch.float)
        conv_weight_idx = self.add_weight(outact.name + ".weight", conv_weight)

        conv_bias_idx = -1
        if bias is not None:
            conv_bias = bias.to(torch.float)
            conv_bias_idx = self.add_weight(outact.name + ".bias", conv_bias)

        op = Operator(
            name=outact.name,
            options=layer_options.TransposeConvolution1dOptions(
                inputs=(inact_idx,),
                outputs=(outact_idx,),
                in_channels=in_channels,
                out_channels=out_channels,
                kernel=kernel,
                stride=stride,
                dilation=dilation,
                west_padding=west_padding,
                east_padding=east_padding,
                group_number=group_number,
                weight=conv_weight_idx,
                bias=conv_bias_idx,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_transposeconv2d(
        self,
        inact: ActivationSpec,
        in_channels,
        out_channels,
        h_kernel=1,
        w_kernel=1,
        h_stride=1,
        w_stride=1,
        h_dilation=1,
        w_dilation=1,
        west_padding=0,
        east_padding=0,
        north_padding=0,
        south_padding=0,
        padding_list=None,
        group_number=1,
        weight=None,
        bias=None,
        opname="",
    ):
        if not opname:
            opname = inact.name + "/tconv2d"
        assert (
            inact.src_dim == 4
        ), f"expected dim=4, but got {inact.get_act_src_shape()}"

        n, h, w, c = inact.get_act_src_shape()
        if c != in_channels:
            raise ValueError(
                f"tconv2d in_channels={in_channels} does not match with input_shape={(n, h, w, c)}"
            )
        strided_input_h = (h - 1) * h_stride + 1
        strided_input_w = (w - 1) * w_stride + 1

        h_out = _conv_out_size(
            strided_input_h, north_padding, south_padding, h_kernel, h_dilation, 1
        )
        w_out = _conv_out_size(
            strided_input_w, west_padding, east_padding, w_kernel, w_dilation, 1
        )
        outact = self.activationspec(
            opname, inact.dtype, (n, h_out, w_out, out_channels), DataFormat.NHWC
        )
        in_ch = in_channels // group_number
        if isinstance(weight, torch.Tensor):
            conv_weight = weight.reshape((out_channels, in_ch, h_kernel, w_kernel)).to(
                torch.float
            )
        else:
            conv_weight = weight.reshape(
                (out_channels, in_ch, h_kernel, w_kernel)
            ).astype(numpy.float32)
        conv_weight_idx = self.add_weight(outact.name + ".weight", conv_weight)

        conv_bias_idx = -1
        if bias is not None:
            conv_bias = bias.to(torch.float)
            conv_bias_idx = self.add_weight(outact.name + ".bias", conv_bias)

        if padding_list is None:
            padding_list = tuple()

        op = Operator(
            name=outact.name,
            options=layer_options.TransposeConvolutionOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                in_channels=in_channels,
                out_channels=out_channels,
                h_kernel=h_kernel,
                w_kernel=w_kernel,
                h_stride=h_stride,
                w_stride=w_stride,
                h_dilation=h_dilation,
                w_dilation=w_dilation,
                west_padding=west_padding,
                east_padding=east_padding,
                north_padding=north_padding,
                south_padding=south_padding,
                padding_list=padding_list,
                group_number=group_number,
                weight=conv_weight_idx,
                bias=conv_bias_idx,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_conv2d(
        self,
        inact: ActivationSpec,
        in_channels,
        out_channels,
        h_kernel=1,
        w_kernel=1,
        h_stride=1,
        w_stride=1,
        h_dilation=1,
        w_dilation=1,
        west_padding=0,
        east_padding=0,
        north_padding=0,
        south_padding=0,
        padding_list=None,
        group_number=1,
        weight=None,
        bias=None,
        opname="",
        output_value_reference="",
    ):
        if not opname:
            opname = inact.name + "/conv2d"
        assert (
            inact.src_dim == 4
        ), f"expected dim=4, but got {inact.get_act_src_shape()}"

        n, h, w, c = inact.get_act_src_shape()
        if c != in_channels:
            raise ValueError(
                f"conv2d in_channels={in_channels} does not match with input_shape={(n, h, w, c)}"
            )

        h_out = _conv_out_size(
            h, north_padding, south_padding, h_kernel, h_dilation, h_stride
        )
        w_out = _conv_out_size(
            w, west_padding, east_padding, w_kernel, w_dilation, w_stride
        )

        outact = self.activationspec(
            opname, inact.dtype, (n, h_out, w_out, out_channels), DataFormat.NHWC
        )
        in_ch = in_channels // group_number
        if isinstance(weight, torch.Tensor):
            conv_weight = weight.reshape((out_channels, in_ch, h_kernel, w_kernel)).to(
                torch.float
            )
        else:
            conv_weight = weight.reshape(
                (out_channels, in_ch, h_kernel, w_kernel)
            ).astype(numpy.float32)
        conv_weight_idx = self.add_weight(outact.name + ".weight", conv_weight)

        conv_bias_idx = -1
        if bias is not None:
            if isinstance(bias, torch.Tensor):
                conv_bias = bias.to(torch.float)
            elif isinstance(bias, numpy.ndarray):
                conv_bias = bias.astype(numpy.float32)
            else:
                raise NotImplementedError
            conv_bias_idx = self.add_weight(outact.name + ".bias", conv_bias)

        if padding_list is None:
            padding_list = tuple()

        op = Operator(
            name=outact.name,
            options=layer_options.ConvolutionOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                in_channels=in_channels,
                out_channels=out_channels,
                h_kernel=h_kernel,
                w_kernel=w_kernel,
                h_stride=h_stride,
                w_stride=w_stride,
                h_dilation=h_dilation,
                w_dilation=w_dilation,
                west_padding=west_padding,
                east_padding=east_padding,
                north_padding=north_padding,
                south_padding=south_padding,
                padding_list=padding_list,
                group_number=group_number,
                weight=conv_weight_idx,
                bias=conv_bias_idx,
            ),
            output_value_reference=output_value_reference,
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_conv3d(
        self,
        inact: ActivationSpec,
        in_channels,
        out_channels,
        d_kernel=1,
        h_kernel=1,
        w_kernel=1,
        d_stride=1,
        h_stride=1,
        w_stride=1,
        d_dilation=1,
        h_dilation=1,
        w_dilation=1,
        front_padding=0,
        back_padding=0,
        west_padding=0,
        east_padding=0,
        north_padding=0,
        south_padding=0,
        padding_list=None,
        group_number=1,
        weight=None,
        bias=None,
        opname="",
        output_value_reference="",
    ):
        if not opname:
            opname = inact.name + "/conv3d"
        assert (
            inact.src_dim == 5
        ), f"expected dim=5, but got {inact.get_act_src_shape()}"

        n, d, h, w, c = inact.get_act_src_shape()
        if c != in_channels:
            raise ValueError(
                f"conv3d in_channels={in_channels} does not match with input_shape={(n,h,w,d,c)}"
            )
        d_out = _conv_out_size(
            d, front_padding, back_padding, d_kernel, d_dilation, d_stride
        )
        h_out = _conv_out_size(
            h, north_padding, south_padding, h_kernel, h_dilation, h_stride
        )
        w_out = _conv_out_size(
            w, west_padding, east_padding, w_kernel, w_dilation, w_stride
        )
        outact = self.activationspec(
            opname,
            inact.dtype,
            (n, d_out, h_out, w_out, out_channels),
            DataFormat.UNKNOWN,
        )
        in_ch = in_channels // group_number
        if isinstance(weight, torch.Tensor):
            conv_weight = weight.reshape(
                (out_channels, in_ch, d_kernel, h_kernel, w_kernel)
            ).to(torch.float)
        else:
            conv_weight = weight.reshape(
                (out_channels, in_ch, d_kernel, h_kernel, w_kernel)
            ).astype(numpy.float32)
        conv_weight_idx = self.add_weight(outact.name + ".weight", conv_weight)

        conv_bias_idx = -1
        if bias is not None:
            if isinstance(bias, torch.Tensor):
                conv_bias = bias.to(torch.float)
            elif isinstance(bias, numpy.ndarray):
                conv_bias = bias.astype(numpy.float32)
            else:
                raise NotImplementedError
            conv_bias_idx = self.add_weight(outact.name + ".bias", conv_bias)

        if padding_list is None:
            padding_list = tuple()

        op = Operator(
            name=outact.name,
            options=layer_options.Convolution3dOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                in_channels=in_channels,
                out_channels=out_channels,
                h_kernel=h_kernel,
                w_kernel=w_kernel,
                d_kernel=d_kernel,
                h_stride=h_stride,
                w_stride=w_stride,
                d_stride=d_stride,
                h_dilation=h_dilation,
                w_dilation=w_dilation,
                d_dilation=d_dilation,
                west_padding=west_padding,
                east_padding=east_padding,
                north_padding=north_padding,
                south_padding=south_padding,
                front_padding=front_padding,
                back_padding=back_padding,
                padding_list=padding_list,
                group_number=group_number,
                weight=conv_weight_idx,
                bias=conv_bias_idx,
            ),
            output_value_reference=output_value_reference,
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_gemmconst(
        self,
        inact: ActivationSpec,
        constant: numpy.ndarray,
        bias=None,
        is_const_first=False,
        alpha=1,
        beta=1,
        transA=False,
        transB=False,
        opname="",
    ):
        if not opname:
            opname = inact.name + "/gemmconst"
        assert (
            inact.src_dim == 4
        ), f"expected dim=4, but got {inact.get_act_src_shape()}"

        n, h, w, c = inact.get_act_src_shape()

        if transA or transB:
            raise NotImplementedError

        if not is_const_first:
            if len(constant.shape) == 2:
                if c != constant.shape[0]:
                    raise ValueError
                outact = self.activationspec(
                    opname, inact.dtype, (n, h, w, constant.shape[1]), DataFormat.NHWC
                )
            else:
                raise NotImplementedError
            const_idx = self.add_weight(outact.name + ".const", constant)
            bias_idx = -1
            if bias is not None:
                if isinstance(bias, torch.Tensor):
                    bias = bias.to(torch.float)
                else:
                    bias = bias.astype(numpy.float32)
                bias_idx = self.add_weight(outact.name + ".bias", bias)

        else:
            raise NotImplementedError

        op = Operator(
            name=outact.name,
            options=layer_options.GemmConstantOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                constant=const_idx,
                bias=bias_idx,
                is_const_first=is_const_first,
                alpha=alpha,
                beta=beta,
                transA=transA,
                transB=transB,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_depthwise_conv2d(
        self,
        inact: ActivationSpec,
        in_channels,
        out_channels,
        h_kernel=1,
        w_kernel=1,
        h_stride=1,
        w_stride=1,
        h_dilation=1,
        w_dilation=1,
        west_padding=0,
        east_padding=0,
        north_padding=0,
        south_padding=0,
        padding_list=None,
        weight=None,
        bias=None,
        opname="",
    ):
        if not opname:
            opname = inact.name + "/dconv2d"
        assert (
            inact.src_dim == 4
        ), f"expected dim=4, but got {inact.get_act_src_shape()}"

        n, h, w, c = inact.get_act_src_shape()
        if c != in_channels:
            raise ValueError(
                f"dconv2d in_channels does not match with input_shape={(n, h, w, c)}"
            )

        h_out = _conv_out_size(
            h, north_padding, south_padding, h_kernel, h_dilation, h_stride
        )
        w_out = _conv_out_size(
            w, west_padding, east_padding, w_kernel, w_dilation, w_stride
        )

        outact = self.activationspec(
            opname, inact.dtype, (n, h_out, w_out, out_channels), DataFormat.NHWC
        )
        if isinstance(weight, torch.Tensor):
            dconv_weight = weight.reshape((out_channels, 1, h_kernel, w_kernel)).to(
                torch.float
            )
        else:
            dconv_weight = weight.reshape((out_channels, 1, h_kernel, w_kernel)).astype(
                numpy.float32
            )
        dconv_weight_idx = self.add_weight(outact.name + ".weight", dconv_weight)

        dconv_bias_idx = -1
        if bias is not None:
            if isinstance(bias, torch.Tensor):
                dconv_bias = bias.to(torch.float)
            else:
                dconv_bias = bias.astype(numpy.float32)
            dconv_bias_idx = self.add_weight(outact.name + ".bias", dconv_bias)

        if padding_list is None:
            padding_list = tuple()

        op = Operator(
            name=outact.name,
            options=layer_options.DepthwiseConvolutionOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                in_channels=in_channels,
                out_channels=out_channels,
                h_kernel=h_kernel,
                w_kernel=w_kernel,
                h_stride=h_stride,
                w_stride=w_stride,
                h_dilation=h_dilation,
                w_dilation=w_dilation,
                west_padding=west_padding,
                east_padding=east_padding,
                north_padding=north_padding,
                south_padding=south_padding,
                padding_list=padding_list,
                group_number=int(in_channels),
                weight=dconv_weight_idx,
                bias=dconv_bias_idx,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_group_query_attention(
        self,
        query: ActivationSpec,
        key: ActivationSpec,
        value: ActivationSpec,
        past_key: str,
        past_value: str,
        seqlens_k: int,
        total_sequence_length: int,
        cos_cache: numpy.ndarray,
        sin_cache: numpy.ndarray,
        num_heads: int,
        kv_num_heads: int,
        scale: float,
        do_rotary: int,
        rotary_interleaved: int,
        opname="",
    ):
        if not opname:
            opname = query.name + "/GroupQueryAttention"
        if key == value == "":
            input_ = query
            input_shape = input_.src_shape
            last_dim = input_shape[-1]
            if last_dim % 3 != 0:
                raise NotImplementedError
            output_shape = input_shape[:-1] + (input_shape[-1] // 3,)
            inact = query
        else:
            raise NotImplementedError

        outact = self.copy_activationspec(inact, name=opname, src_shape=output_shape)
        outact_idx = self.get_activation_index(outact)
        inact_idx = self.get_activation_index(inact)
        cos_cache_idx = self.add_weight(outact.name + "/cos_cache", cos_cache)
        sin_cache_idx = self.add_weight(outact.name + "/sin_cache", sin_cache)
        op = Operator(
            name=outact.name,
            options=layer_options.GroupQueryAttentionOptions(
                inputs=(inact_idx,),
                outputs=(outact_idx,),
                seqlens_k=int(seqlens_k),
                total_sequence_length=int(total_sequence_length),
                num_heads=num_heads,
                kv_num_heads=kv_num_heads,
                scale=scale,
                do_rotary=do_rotary,
                rotary_interleaved=rotary_interleaved,
                cos_cache=cos_cache_idx,
                sin_cache=sin_cache_idx,
                past_key=past_key,
                past_value=past_value,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_skipsimplifiedlayernormalization(
        self,
        input_act: ActivationSpec,
        skip: ActivationSpec,
        gamma: numpy.ndarray,
        epsilon: float,
        output_name="",
        input_skip_bias_sum_name="",
    ):
        if not output_name:
            output_name = input_act.name + "/skipsimplifiedlayernormalization"
        outact_idx = []
        gamma = self.add_weight(output_name + "/gamma", gamma)
        epsilon = self.add_weight(output_name + "/eps", epsilon)
        inact_idx = [
            self.get_activation_index(input_act),
            self.get_activation_index(skip),
        ]

        outact = self.copy_activationspec(input_act, name=output_name)
        outact_idx = self.get_activation_index(outact)

        if input_skip_bias_sum_name != "":
            input_skip_bias_sum = self.copy_activationspec(
                input_act, name=input_skip_bias_sum_name
            )
            input_skip_bias_sum_idx = self.get_activation_index(input_skip_bias_sum)
            output_idx = [outact_idx, input_skip_bias_sum_idx]
        else:
            output_idx = [
                outact_idx,
            ]

        op = Operator(
            name=output_name,
            options=layer_options.SkipsimplifiedlayernormalizationOptions(
                inputs=inact_idx, outputs=output_idx, gamma=gamma, epsilon=epsilon
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        if input_skip_bias_sum_name != "":
            _set_producer_op(op, input_skip_bias_sum)
            return [outact, input_skip_bias_sum]
        else:
            return outact

    def make_minmaxnorm(
        self,
        inact: ActivationSpec,
        norm_axis: Tuple[int, ...],
        opname="",
    ) -> ActivationSpec:
        if not opname:
            opname = inact.name + "/minmaxnorm"
        outact = self.copy_activationspec(inact, name=opname)
        op = Operator(
            name=outact.name,
            options=layer_options.MinMaxNormalizationOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                norm_axis=norm_axis,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_rmsnorm(
        self,
        inact: ActivationSpec,
        epsilon,
        scale,
        normalized_shape: Tuple = None,
        opname="",
    ):
        if not opname:
            opname = inact.name + "/rmsnorm"
        outact = self.copy_activationspec(inact, name=opname)
        outact_idx = self.get_activation_index(outact)
        inact_idx = self.get_activation_index(inact)
        ts_eps_idx = self.add_weight(outact.name + ".eps", epsilon)
        ts_weight_idx = self.add_weight(outact.name + ".scale", scale)
        if normalized_shape is None:
            normalized_shape = (inact.src_shape[-1],)
        op = Operator(
            name=outact.name,
            options=layer_options.RmsNormalizationOptions(
                inputs=(inact_idx,),
                outputs=(outact_idx,),
                epsilon=ts_eps_idx,
                scale=ts_weight_idx,
                normalized_shape=normalized_shape,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_instancenorm(
        self,
        inact: ActivationSpec,
        epsilon,
        scale,
        bias,
        num_groups=-1,
        group_order=-1,
        opname="",
    ):
        if not opname:
            opname = inact.name + "/instancenorm"
        outact = self.copy_activationspec(
            inact, name=opname, dataformat=DataFormat.UNKNOWN, shape=(-1, -1, -1)
        )
        outact_idx = self.get_activation_index(outact)
        inact_idx = self.get_activation_index(inact)
        ts_epsilon_idx = self.add_weight(opname + ".eps", epsilon)
        ts_scale_idx = self.add_weight(opname + ".scale", scale)
        ts_bias_idx = self.add_weight(opname + ".bias", bias)

        op = Operator(
            name=outact.name,
            options=layer_options.InstanceNormalizationOptions(
                inputs=(inact_idx,),
                outputs=(outact_idx,),
                epsilon=ts_epsilon_idx,
                scale=ts_scale_idx,
                bias=ts_bias_idx,
                num_groups=num_groups,
                group_order=group_order,
            ),
        )

        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_layernorm(
        self,
        inact: ActivationSpec,
        normalized_shape,
        epsilon,
        scale,
        bias=None,
        opname="",
    ):
        if not opname:
            opname = inact.name + "/layernorm"
        outact = self.copy_activationspec(inact, name=opname)
        outact_idx = self.get_activation_index(outact)
        inact_idx = self.get_activation_index(inact)
        ts_epsilon_idx = self.add_weight(opname + ".eps", epsilon)
        ts_scale_idx = self.add_weight(opname + ".scale", scale)
        if bias is not None:
            ts_bias_idx = self.add_weight(opname + ".bias", bias)
        else:
            ts_bias_idx = -1

        op = Operator(
            name=outact.name,
            options=layer_options.LayerNormalizationOptions(
                inputs=(inact_idx,),
                outputs=(outact_idx,),
                normalized_shape=normalized_shape,
                epsilon=ts_epsilon_idx,
                scale=ts_scale_idx,
                bias=ts_bias_idx,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_l2norm(
        self,
        inact: ActivationSpec,
        norm_axis: Tuple[int, ...],
        epsilon: Optional = None,
        opname="",
    ):
        if not opname:
            opname = inact.name + "/l2norm"
        if epsilon is None:
            epsilon = 1e-12  # torch default value
        outact = self.copy_activationspec(inact, name=opname)
        ts_epsilon_idx = self.add_weight(opname + ".epsilon", epsilon)
        op = Operator(
            name=outact.name,
            options=layer_options.L2NormalizationOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                norm_axis=norm_axis,
                epsilon=ts_epsilon_idx,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_groupnorm(
        self, inact: ActivationSpec, num_groups, scale, bias, epsilon, opname=""
    ):
        if not opname:
            opname = inact.name + "/groupnorm"

        outact = self.copy_activationspec(inact, name=opname)
        ts_scale_idx = self.add_weight(opname + ".scale", scale)
        ts_bias_idx = self.add_weight(opname + ".shift", bias)
        ts_epsilon_idx = self.add_weight(opname + ".epsilon", epsilon)

        op = Operator(
            name=outact.name,
            options=layer_options.GroupNormalizationOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                num_groups=num_groups,
                scale=ts_scale_idx,
                bias=ts_bias_idx,
                epsilon=ts_epsilon_idx,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_identity(self, x, opname=""):
        outact = self.copy_activationspec(
            x, name=opname if opname else x.name + "/identity"
        )
        op = Operator(
            name=outact.name,
            options=layer_options.IdentityOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_output(self, act):
        op = Operator(
            name=act.name,
            options=layer_options.OutputOptions(
                inputs=(self.get_activation_index(act),),
                outputs=(self.get_activation_index(act),),
            ),
        )
        self.add_operator(op)
        return act

    def make_input(self, act, unsupported=True, output_value_reference=None):
        op = Operator(
            name=act.name,
            options=layer_options.InputOptions(
                inputs=(self.get_activation_index(act),),
                outputs=(self.get_activation_index(act),),
            ),
            unsupported=unsupported,
            output_value_reference=output_value_reference,
        )
        self.add_operator(op)
        _set_producer_op(op, act)
        return act

    def make_attention_mask_input(
        self, act, attn_mask_type: str = "causal_mask", sample_mask=None
    ):
        assert attn_mask_type in ("causal_mask", "padding_mask")
        assert sample_mask is not None

        sample_mask_idx = self.add_weight(act.name + ".sample_mask", sample_mask)
        op = Operator(
            name=act.name,
            options=layer_options.AttentionMaskInputOptions(
                outputs=(self.get_activation_index(act),),
                attn_mask_type=attn_mask_type,
                sample_mask=sample_mask_idx,
            ),
        )
        self.add_operator(op)
        act.producer_op = op
        return act

    def make_kv_cache_input(self, act, cache_name: str):
        op = Operator(
            name=act.name,
            options=layer_options.KVCacheInputOptions(
                outputs=(self.get_activation_index(act),), cache_name=cache_name
            ),
        )
        self.add_operator(op)
        act.producer_op = op
        return act

    def make_inputconst(self, weight, opname=""):
        if not opname:
            opname = "inputconst"
        ts_weight_idx = self.add_weight(opname + ".weight", weight)

        if isinstance(weight, torch.Tensor):
            if weight.dtype == torch.bfloat16:
                weight = weight.to(torch.float32)
            weight = weight.detach().cpu().numpy()
        elif isinstance(weight, int):
            weight = numpy.int32(weight)
        outact = self.activationspec(
            opname, weight.dtype.name, tuple(weight.shape), DataFormat.UNKNOWN
        )
        op = Operator(
            outact.name,
            options=layer_options.InputConstantOptions(
                outputs=(self.get_activation_index(outact),),
                constant=ts_weight_idx,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_stateful_rope_wrapper(
        self,
        state: ActivationSpec,
        cos: ActivationSpec,
        sin: ActivationSpec,
        rope_type=0,
        rotary_emb_dim: Optional[int] = 0,
        opname="",
    ):
        idx_state = self.get_activation_index(state)
        idx_cos = self.get_activation_index(cos)
        idx_sin = self.get_activation_index(sin)
        state_rope = self.copy_activationspec(state, name=opname)
        idx_state_rope = self.get_activation_index(state_rope)
        op_ = Operator(
            name=state_rope.name,
            options=layer_options.StatefulRoPEWrapperOptions(
                inputs=(idx_state, idx_cos, idx_sin),
                outputs=(idx_state_rope,),
                seqlen=int(state.get_act_src_shape()[2]),
                rope_type=rope_type,
                rotary_emb_dim=rotary_emb_dim,
            ),
        )
        self.add_operator(op_)
        return state_rope

    def make_repeat_n(self, hidden_states: ActivationSpec, num_repeat, opname=""):
        if not opname:
            opname = hidden_states.name + "/repeat"

        src_shape = list(hidden_states.get_act_src_shape())
        axis = 1
        src_shape[axis] = src_shape[axis] * num_repeat
        outact = self.copy_activationspec(
            hidden_states, name=opname, shape=None, src_shape=tuple(src_shape)
        )
        outact_idx = self.get_activation_index(outact)
        inact_idx = self.get_activation_index(hidden_states)
        op_repeat = Operator(
            name=outact.name,
            options=layer_options.RepeatNOptions(
                inputs=(inact_idx,), outputs=(outact_idx,), axis=axis, repeat=num_repeat
            ),
        )
        self.add_operator(op_repeat)
        return outact

    def make_stateful_kvcache_wrapper(
        self,
        state,
        cache_name,
        past_seqlen=0,
        is_sliding=False,
        sliding_window=1024,
        max_cache_len=8192,
        output_src_shape=None,
        opname="",
    ):
        if not opname:
            opname = state.name + "/kv_cache"

        if output_src_shape is not None:
            src_shape = output_src_shape
        else:
            x_src_shape = list(state.get_act_src_shape())
            x_src_shape[2] = DimValue(
                x_src_shape[2].value + past_seqlen, x_src_shape[2].dynamic
            )
            src_shape = x_src_shape
        x_update = self.copy_activationspec(
            state, src_shape=src_shape, shape=None, name=opname
        )
        x_update_idx = self.get_activation_index(x_update)
        x_idx = self.get_activation_index(state)

        if sliding_window is None:
            sliding_window = 1024
        op_update = Operator(
            name=x_update.name,
            options=layer_options.StatefulKVCacheWrapperOptions(
                inputs=(x_idx,),
                outputs=(x_update_idx,),
                past_seqlen=past_seqlen,
                cache_name=cache_name,
                is_sliding=is_sliding,
                sliding_window=sliding_window,
                max_cache_len=max_cache_len,
            ),
        )
        self.add_operator(op_update)
        return x_update

    def make_slice(
        self,
        x: ActivationSpec,
        axis: Tuple[int, ...],
        start: Tuple[int, ...],
        end: Tuple[int, ...],
        step: Tuple[int, ...] | None = None,
        opname="",
    ):
        # todo: dynamic shape

        end = tuple(min(2147483647, x) for x in end)  # fix 9223372036854775807

        def slice_out_len(start, end, step, seq_length):
            start_ = max(
                0, min(seq_length, start if start >= 0 else seq_length + start)
            )
            try:
                end_ = max(0, min(seq_length, end if end >= 0 else seq_length + end))
            except Exception as e:
                raise e
            if step > 0:
                length = max(0, (end_ - start_ + step - 1) // step)
            elif step < 0:
                length = max(0, (start_ - end_ - step - 1) // -step)
            else:
                raise ValueError("step cannot be 0")
            return length

        if not opname:
            opname = x.name + "/slice"

        x_src_shape = x.get_act_src_shape()
        new_src_shape = list(x_src_shape)

        if step is None:
            step = [1] * len(axis)
        else:
            step = list(step)
            for i, st in enumerate(step):
                if st is None:
                    step[i] = 1

        def is_dynamic_size(dim, start_, end_):
            if dim.dynamic:
                if start_ >= 0:
                    # select last n elements / until the last
                    return end_ < 0 or end_ >= slice_axis_max
            return False

        slice_axis_max = 2147483647
        for i, _s, _e, _st in zip(axis, start, end, step):
            new_src_shape[i] = DimValue(
                slice_out_len(_s, _e, _st, int(new_src_shape[i])),
                dynamic=is_dynamic_size(new_src_shape[i], _s, _e),
            )

        slice_out = self.copy_activationspec(
            x, name=opname, src_shape=new_src_shape, shape=(-1, -1, -1)
        )
        slice_out_idx = self.get_activation_index(slice_out)
        slice_in_idx = self.get_activation_index(x)
        op_slice = Operator(
            slice_out.name,
            options=layer_options.SliceOptions(
                inputs=(slice_in_idx,),
                outputs=(slice_out_idx,),
                axis=axis,
                start=start,
                end=end,
                step=step,
            ),
        )
        self.add_operator(op_slice)
        _set_producer_op(op_slice, slice_out)
        return slice_out

    def make_chunk(self, x, chunk, dim, opname: List[str] | str = ""):
        c = x.get_act_src_shape()[dim]
        q, r = divmod(int(c), chunk)
        if opname == "":
            opname = x.name + "/chunk"
        if isinstance(opname, str):
            opname = [opname + "." + str(i) for i in range(chunk)]
        if isinstance(opname, list):
            assert len(opname) == chunk

        if r != 0:
            q = int(math.ceil(int(c) / chunk))
            return tuple(
                self.make_slice(
                    x,
                    axis=(dim,),
                    start=(idx * q,),
                    end=(min(c, (idx + 1) * q),),
                    opname=nm,
                )
                for idx, nm in enumerate(opname)
            )
        else:
            return tuple(
                self.make_slice(
                    x, axis=(dim,), start=(idx * q,), end=((idx + 1) * q,), opname=nm
                )
                for idx, nm in enumerate(opname)
            )

    def make_concatenate(
        self, inputs: List[ActivationSpec], dim: int, opname: str = ""
    ):
        if not opname:
            opname = inputs[0].name + "/concat"
        outact_src_shape = list(inputs[0].get_act_src_shape())
        if len(outact_src_shape) == 0 and dim == 0:
            outact_src_shape = [len(inputs)]
        else:
            outact_src_shape[dim] = sum(x.get_act_src_shape()[dim] for x in inputs)
        outact = self.copy_activationspec(
            inputs[0],
            name=opname,
            src_shape=tuple(outact_src_shape),
            shape=(-1, -1, -1),
        )
        outact_idx = self.get_activation_index(outact)
        inputs = tuple(self.get_activation_index(x) for x in inputs)
        concat = Operator(
            name=outact.name,
            options=layer_options.ConcatenateOptions(
                inputs=inputs, outputs=(outact_idx,), axis=dim
            ),
        )
        self.add_operator(concat)
        outact.producer_op = concat
        return outact

    def make_topk(
        self,
        x: ActivationSpec,
        constant,
        axis,
        largest=True,
        sorted=True,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/topk"
        in_src_shape = list(x.get_act_src_shape())
        if isinstance(constant, Real):
            pass
        else:
            raise NotImplementedError
        in_src_shape[axis] = DimValue(constant)
        out_src_shape = in_src_shape
        outact_kvalue = self.copy_activationspec(
            x,
            name=opname + "_value",
            src_shape=out_src_shape,
        )
        outact_kidx = self.copy_activationspec(
            x,
            name=opname + "_idx",
            src_shape=out_src_shape,
        )

        topk = Operator(
            name=opname,
            options=layer_options.TopKOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(
                    self.get_activation_index(outact_kvalue),
                    self.get_activation_index(outact_kidx),
                ),
                constant=constant,
                largest=largest,
                sorted=sorted,
                axis=axis,
            ),
        )

        self.add_operator(topk)

        return outact_kvalue, outact_kidx

    def apply_attention_mask(
        self,
        attn_weight: ActivationSpec,
        attn_mask: ActivationSpec = None,
        past_seq_len: int = 0,
        is_sliding=False,
        sliding_window=1024,
        mask_type="causal_mask",
        opname="",
    ):
        masked = self.copy_activationspec(attn_weight, name=opname + "/attn_mask")
        outact_idx = self.get_activation_index(masked)
        inact_idx = self.get_activation_index(attn_weight)
        inputs = [
            inact_idx,
        ]

        if mask_type == "custom_mask":
            if attn_mask is None:
                raise ValueError("attn_mask was not set correctly.")
            inputs.append(self.get_activation_index(attn_mask))

        if mask_type in ("custom_mask", "causal_mask"):
            op_attn_mask = Operator(
                name=masked.name,
                options=layer_options.StatefulAttentionMaskWrapperOptions(
                    inputs=tuple(inputs),
                    outputs=(outact_idx,),
                    past_seqlen=past_seq_len,
                    is_sliding=is_sliding,
                    sliding_window=sliding_window,
                    mask_type=mask_type,
                ),
            )
        else:
            raise NotImplementedError("Not implemented ")
        self.add_operator(op_attn_mask)
        return masked

    def make_einsum(
        self, x: ActivationSpec | Tuple[ActivationSpec], equation, opname=""
    ):
        def interpret_equation(equation, inputs):
            if "->" in equation:
                input_dims, output_dims = equation.split("->")
                input_dims = [x.replace(" ", "") for x in input_dims.split(",")]
                output_dims = output_dims.replace(" ", "")
                axis_map = defaultdict(list)
                for input_idx, input_label in enumerate(input_dims):
                    for axis, char in enumerate(input_label):
                        axis_map[char].append((input_idx, axis))

                output_src_shape = []
                for output_axis, char in enumerate(output_dims):
                    shapes = set()
                    dynamic = []
                    for input_idx, input_axis in axis_map[char]:
                        d = inputs[input_idx].get_act_src_shape()[input_axis]
                        shapes.add(int(d))
                        dynamic.append(d.dynamic)
                    if not (
                        all(x == dynamic[0] for x in dynamic)
                        and (len(shapes) == 1 or (len(shapes) == 2 and 1 in shapes))
                    ):
                        raise ValueError("activation shapes are not broadcastable.")
                    output_src_shape.append(DimValue(max(shapes), dynamic=any(dynamic)))
                return tuple(output_src_shape)
            else:
                raise NotImplementedError(f"equation={equation}")

        if isinstance(x, ActivationSpec):
            if not opname:
                opname = x.name + "/einsum"

            if "->" in equation:
                input_dims, output_dims = equation.split("->")
            else:
                raise NotImplementedError(f"make_einsum with equation={equation}")

            if "," in input_dims:
                raise NotImplementedError(
                    f"make_einsum with equation={equation} and num_inputs=1"
                )
            input_indices = list(input_dims)
            if len(set(input_indices)) < len(input_indices):
                raise NotImplementedError

            if output_dims is not None:
                if set(output_dims) == set(input_dims):
                    output_indices = list(output_dims)
                    transpose_order = [input_indices.index(d) for d in output_indices]
                    return self.make_transpose(
                        x, transpose_axes=tuple(transpose_order), opname=opname
                    )
        else:
            if not opname:
                opname = x[0].name + "/einsum"
            output_src_shape = interpret_equation(equation, x)

            # BGHID,BGHJD->BGHIJ
            # (1,64,2,49,32), (1,64,2,49,32)->(1,64,2,49,49)
            # for the sake of clarity
            output_ts = torch.einsum(
                equation, *(torch.empty(*t.get_act_src_shape()) for t in x)
            )
            assert output_src_shape == output_ts.shape

            outact = self.activationspec(opname, x[0].dtype, output_src_shape)
            op = Operator(
                name=outact.name,
                options=layer_options.EinsumOptions(
                    inputs=tuple(self.get_activation_index(a) for a in x),
                    outputs=(self.get_activation_index(outact),),
                    equation=equation,
                ),
            )
            self.add_operator(op)

            return outact

        raise NotImplementedError

    def make_custom_biop(
        self,
        inputs: Sequence[ActivationSpec],
        output_src_shape,
        output_dtype,
        output_dataformat=DataFormat.UNKNOWN,
        content: str = "",
        custom_fn=None,
        opname="",
    ):
        if not opname:
            opname = inputs[0].name + "/custom_biop"
        outact = self.activationspec(
            opname, output_dtype, output_src_shape, output_dataformat
        )
        op = Operator(
            name=outact.name,
            options=layer_options.CustomBiOpOptions(
                inputs=tuple(self.get_activation_index(a) for a in inputs),
                outputs=(self.get_activation_index(outact),),
                content=content,
            ),
        )
        op.custom_fn = custom_fn
        self.add_operator(op)
        return outact

    def make_custom_singleop(
        self,
        input: ActivationSpec,
        output_src_shape,
        output_dtype,
        output_dataformat=DataFormat.UNKNOWN,
        content: str = "",
        custom_fn=None,
        opname="",
    ):
        if not opname:
            opname = input.name + "/custom_single_op"
        outact = self.activationspec(
            opname, output_dtype, output_src_shape, output_dataformat
        )
        op = Operator(
            name=outact.name,
            options=layer_options.CustomSingleOpOptions(
                inputs=(self.get_activation_index(input),),
                outputs=(self.get_activation_index(outact),),
                content=content,
            ),
        )
        op.custom_fn = custom_fn
        self.add_operator(op)
        return outact

    def make_temporary_operator(
        self,
        inputs: Sequence[ActivationSpec],
        output_src_shape,
        output_dtype,
        output_dataformat=DataFormat.UNKNOWN,
        description: str = "",
        custom_fn=None,
        opname="",
    ):
        if not opname:
            opname = inputs[0].name + "/temporary_operator"

        outact = self.activationspec(
            opname, output_dtype, output_src_shape, dataformat=output_dataformat
        )

        op = Operator(
            name=outact.name,
            options=layer_options.TemporaryNodeOptions(
                inputs=tuple(self.get_activation_index(a) for a in inputs),
                outputs=(self.get_activation_index(outact),),
                description=description,
            ),
        )
        op.custom_fn = custom_fn
        self.add_operator(op)

        return outact

    def make_resize(
        self,
        x: ActivationSpec,
        sizes,
        resize_type,
        transform_mode="half_pixel",
        nearest_mode="round_prefer_floor",
        antialias=None,
        scales=None,
        opname="",
        **kwargs,
    ):
        if not opname:
            opname = x.name + "/resize"
        if sizes:
            output_shape = sizes
        elif scales:
            output_shape = [
                DimValue(round(float(x) * s), x.dynamic)
                for x, s in zip(x.get_act_src_shape(), scales)
            ]
        else:
            raise NotImplementedError
        outact = self.activationspec(
            name=opname, dtype=x.dtype, src_shape=output_shape, dataformat=x.dataformat
        )
        op = Operator(
            name=outact.name,
            options=layer_options.ResizeOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                resize_type=resize_type,
                transform_mode=transform_mode,
                nearest_mode=nearest_mode,
                antialias=antialias,
                scales=scales,
                sizes=sizes,
                **kwargs,
            ),
        )
        self.add_operator(op)
        return outact

    def make_interpolate(
        self,
        x: ActivationSpec,
        size=None,
        scale_factor=None,
        mode="nearest",
        align_corners=None,
        recompute_scale_factor=None,
        antialias=False,
        opname="",
    ):
        if not opname:
            opname = x.name + "/interpolate"
        if len(x.get_act_src_shape()) != 4:
            raise NotImplementedError(
                f"make_interpolate input dataformat={x.get_act_src_shape()}"
            )
        n, input_h, input_w, input_c = x.get_act_src_shape()
        input_h = int(input_h)
        input_w = int(input_w)

        if scale_factor is not None:
            if isinstance(scale_factor, float):
                scale_factor_h = scale_factor_w = scale_factor
            else:
                scale_factor_h, scale_factor_w = scale_factor
            output_h = math.floor(float(scale_factor_h) * float(input_h))
            output_w = math.floor(float(scale_factor_w) * float(input_w))
            sizes = (n, output_h, output_w, input_c)
        elif size is not None:
            sizes = size
        else:
            raise NotImplementedError

        if align_corners is None:
            align_corners = False
        if align_corners:
            raise NotImplementedError("align_corners not implemented")

        if mode == "bicubic":
            mode = "cubic"
        if mode == "bilinear":
            mode = "linear"
        if mode in ("nearest", "cubic", "linear"):
            return self.make_resize(
                x,
                resize_type=mode,
                sizes=sizes,
                transform_mode="asymmetric",
                nearest_mode="floor",
                opname=opname,
            )
        else:
            raise NotImplementedError(f"make_interpolate mode={mode}")

    def make_sigmoid(self, x: ActivationSpec, alpha=None, opname=""):
        if alpha is None:
            alpha = 1.0
        return self.make_act_func(x, act_kind="sigmoid", opname=opname, alpha=alpha)

    def make_hardsigmoid(self, x: ActivationSpec, alpha=0.2, beta=0.5, opname=""):
        return self.make_act_func(
            x, "hardsigmoid", alpha=alpha, beta=beta, opname=opname
        )

    def make_argmax(
        self,
        x: ActivationSpec,
        axis,
        keepdims: bool = True,
        select_last: bool = False,
        opname="",
    ):
        if not opname:
            opname = x.name + "/argmax"

        if axis != -1:
            raise NotImplementedError

        if keepdims:
            src_shape = (1,) * len(x.get_act_src_shape())
            dataformat = x.dataformat
        else:
            raise NotImplementedError

        outact = self.copy_activationspec(
            x, name=opname, src_shape=src_shape, dataformat=dataformat
        )

        op = Operator(
            name=outact.name,
            options=layer_options.ArgMaxOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                axis=axis,
                keepdims=keepdims,
                select_last=select_last,
            ),
        )
        self.add_operator(op)
        return outact

    def make_expand(self, x: ActivationSpec, constant, is_const_first=False, opname=""):
        if not opname:
            opname = x.name + "/expand"
        src_shape = []
        if isinstance(constant, tuple):
            constant = numpy.array([x for x in constant])
        assert len(constant.shape) == 1
        if isinstance(constant, torch.Tensor):
            assert constant.shape[0] >= x.src_dim
        else:
            assert constant.shape[0] == x.src_dim

        x_src_shape = x.get_act_src_shape()
        len_diff = constant.shape[0] - x.src_dim
        for i, c in enumerate(constant):
            if i - len_diff < 0:
                src_shape.append(DimValue(int(c)))
            else:
                s = x_src_shape[i - len_diff]
                if c == -1:
                    src_shape.append(s)
                else:
                    if s != c:
                        # ambiguous to determine dynamic?
                        src_shape.append(DimValue(int(max(s, int(c)))))
                    else:
                        src_shape.append(s)

        outact = self.activationspec(
            name=opname, src_shape=tuple(src_shape), dtype=x.dtype
        )
        op = Operator(
            name=opname,
            options=layer_options.ExpandOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                is_const_first=is_const_first,
                constant=self.add_weight(outact.name + ".const", constant),
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_gather(
        self,
        x: ActivationSpec | torch.Tensor | torch.nn.Parameter,
        indices: ActivationSpec | int,
        axis,
        opname="",
    ):
        if not opname:
            opname = x.name + "/gather"

        def gather_output_shape(input_shape, indices_shape, axis):
            if isinstance(input_shape, torch.Size):
                input_shape = tuple(int(x) for x in input_shape)
            if isinstance(indices_shape, int):
                return input_shape[:axis] + input_shape[axis + 1 :]
            return input_shape[:axis] + indices_shape + input_shape[axis + 1 :]

        if self.is_act_value_type(x) and self.is_act_value_type(indices):
            outact_src_shape = gather_output_shape(
                x.get_act_src_shape(), indices.get_act_src_shape(), axis
            )
            outact = self.copy_activationspec(
                x, name=opname, src_shape=outact_src_shape
            )
            op = Operator(
                name=outact.name,
                options=layer_options.GatherOptions(
                    inputs=(
                        self.get_activation_index(x),
                        self.get_activation_index(indices),
                    ),
                    outputs=(self.get_activation_index(outact),),
                    axis=axis,
                ),
            )
            self.add_operator(op)
            return outact

        if self.is_act_value_type(x) and isinstance(indices, int):
            outact_src_shape = gather_output_shape(x.get_act_src_shape(), indices, axis)
            if outact_src_shape == tuple():
                outact_src_shape = (1,)
            # fixme: should we allow zero-rank tensor?
            outact = self.copy_activationspec(
                x,
                name=opname,
                src_shape=outact_src_shape,
                dataformat=DataFormat.UNKNOWN,
            )
            constant_ts_idx = self.add_weight(opname + "/indices", indices)
            op = Operator(
                name=outact.name,
                options=layer_options.GatherConstantOptions(
                    inputs=(self.get_activation_index(x),),
                    outputs=(self.get_activation_index(outact),),
                    axis=axis,
                    constant=constant_ts_idx,
                    is_const_first=False,
                ),
            )
            self.add_operator(op)
            return outact

        if isinstance(
            x, (torch.Tensor | torch.nn.Parameter)
        ) and self.is_act_value_type(indices):
            outact_src_shape = gather_output_shape(
                x.shape, indices.get_act_src_shape(), axis
            )
            outact = self.activationspec(opname, "float32", outact_src_shape)
            constant_ts_idx = self.add_weight(opname + "/weight", x)
            op = Operator(
                name=outact.name,
                options=layer_options.GatherConstantOptions(
                    inputs=(self.get_activation_index(indices),),
                    outputs=(self.get_activation_index(outact),),
                    axis=axis,
                    constant=constant_ts_idx,
                    is_const_first=True,
                ),
            )
            self.add_operator(op)
            return outact

        if isinstance(x, numpy.ndarray) and self.is_act_value_type(indices):
            outact_src_shape = gather_output_shape(
                x.shape, indices.get_act_src_shape(), axis
            )
            outact = self.activationspec(opname, "float32", outact_src_shape)
            constant_ts_idx = self.add_weight(opname + "/weight", x)
            op = Operator(
                name=outact.name,
                options=layer_options.GatherConstantOptions(
                    inputs=(self.get_activation_index(indices),),
                    outputs=(self.get_activation_index(outact),),
                    axis=axis,
                    constant=constant_ts_idx,
                    is_const_first=True,
                ),
            )
            self.add_operator(op)
            return outact
        raise NotImplementedError

    def make_staggered_padding(
        self, x: ActivationSpec, axis=3, reverse=False, window_size=-1, opname: str = ""
    ):
        if not opname:
            opname = x.name + "/staggered_padding"
        if axis != 3:
            raise NotImplementedError
        if x.dataformat != DataFormat.NHWC:
            raise NotImplementedError

        n, h, w, c = x.get_act_src_shape()

        if not reverse:
            if c != (window_size * 2 + 1):
                raise ValueError
            output_channel_size = int(w - 1 + c) - 2 * window_size
            if output_channel_size != w:
                raise ValueError
        else:
            if c != w:
                raise ValueError
            output_channel_size = 2 * window_size + 1
        output_channel_size = DimValue(output_channel_size, dynamic=w.dynamic)
        outact = self.copy_activationspec(
            x, name=opname, src_shape=(n, h, w, output_channel_size), shape=(-1, -1, -1)
        )

        op = Operator(
            name=outact.name,
            options=layer_options.StaggeredPaddingOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                axis=axis,
                reverse=reverse,
                window_size=window_size,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_gather_elements(
        self,
        x: ActivationSpec,
        indices: ActivationSpec,
        axis,
        opname="",
    ):
        if not opname:
            opname = x.name + "/gatherelements"

        output_src_shape = indices.get_act_src_shape()
        outact = self.copy_activationspec(x, name=opname, src_shape=output_src_shape)
        op = Operator(
            name=outact.name,
            options=layer_options.GatherElementsOptions(
                inputs=(
                    self.get_activation_index(x),
                    self.get_activation_index(indices),
                ),
                outputs=(self.get_activation_index(outact),),
                axis=axis,
            ),
        )
        self.add_operator(op)
        return outact

    def make_split(
        self,
        x: ActivationSpec,
        split_size_or_sections: int | List[int],
        dim=0,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/split"

        size_total = int(x.get_act_src_shape()[dim])
        if isinstance(split_size_or_sections, int):
            q, r = divmod(size_total, split_size_or_sections)
            chunk_sizes = [split_size_or_sections] * q
            if r > 0:
                chunk_sizes.append(r)
        else:
            _to_int = lambda x: int(x.value) if hasattr(x, "value") else int(x)
            _split_size_or_sections_int = map(_to_int, split_size_or_sections)
            if sum(_split_size_or_sections_int) != size_total:
                raise ValueError(
                    f"split_size_or_sections={split_size_or_sections}, {_split_size_or_sections_int} but size_total={size_total}"
                )
            chunk_sizes = split_size_or_sections

        outacts = []
        acc = 0
        for i, chunk_size in enumerate(chunk_sizes):
            outact_src_shape = list(x.get_act_src_shape())
            outact_src_shape[dim] = chunk_size
            outact_i = self.copy_activationspec(
                x, name=opname + str(i), src_shape=outact_src_shape
            )
            outacts.append(outact_i)

            split_i = Operator(
                name=outact_i.name,
                options=layer_options.SliceOptions(
                    inputs=(self.get_activation_index(x),),
                    outputs=(self.get_activation_index(outact_i),),
                    axis=(dim,),
                    start=(acc,),
                    end=(acc + chunk_size,),
                ),
            )
            acc += chunk_size
            self.add_operator(split_i)

        return outacts

    def make_reduce_sum(
        self,
        x: ActivationSpec,
        reduce_axes,
        keep_dims=True,
        noop_with_empty_axes=0,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/" + "sum"

        output_src_shape = list(x.get_act_src_shape())
        reduce_axes = [r + len(output_src_shape) if r < 0 else r for r in reduce_axes]
        for ax in reduce_axes:
            output_src_shape[ax] = 1
        if not keep_dims:
            output_src_shape = [
                x for idx, x in enumerate(output_src_shape) if idx not in reduce_axes
            ]
        outact = self.copy_activationspec(
            x, name=opname, src_shape=output_src_shape, dataformat=DataFormat.UNKNOWN
        )

        op = Operator(
            name=outact.name,
            options=layer_options.ReduceSumOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                keep_dims=keep_dims,
                reduce_axes=reduce_axes,
                noop_with_empty_axes=noop_with_empty_axes,
            ),
        )
        self.add_operator(op)
        return outact

    def make_flip(self, x: ActivationSpec, axis: List[int], opname=""):
        if not opname:
            opname = x.name + "/flip"

        outact = self.copy_activationspec(x, name=opname)
        op = Operator(
            name=outact.name,
            options=layer_options.FlipOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                axis=axis,
            ),
        )
        self.add_operator(op)
        return outact

    def make_not(self, x: ActivationSpec, opname=""):
        if not opname:
            opname = x.name + "/not"
        outact = self.copy_activationspec(x, name=opname)
        op = Operator(
            name=outact.name,
            options=layer_options.NotOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)
        return outact

    def make_neg(self, x: ActivationSpec, opname=""):
        if not opname:
            opname = x.name + "/neg"
        outact = self.copy_activationspec(x, name=opname)
        op = Operator(
            name=outact.name,
            options=layer_options.NegOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)
        return outact

    def make_abs(self, x: ActivationSpec, opname=""):
        if not opname:
            opname = x.name + "/abs"
        outact = self.copy_activationspec(x, name=opname)
        op = Operator(
            name=outact.name,
            options=layer_options.AbsOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)
        return outact

    def make_random(
        self, size: ActivationSpec, size_hint, distribution="standard_normal", opname=""
    ):
        if not opname:
            opname = size.name + "/random"
        if size_hint is None:
            raise NotImplementedError("size_hint is not given.")
        if distribution != "standard_normal":
            raise NotImplementedError(
                f"distribution={distribution} is not implemented."
            )
        outact = self.activationspec(opname, "float32", size_hint)
        op = Operator(
            name=outact.name,
            options=layer_options.RandomOptions(
                inputs=(self.get_activation_index(size),),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)
        return outact

    def make_minimum(self, left, right, opname=""):
        if not opname:
            opname = left.name + "/minimum"
        outact = self.copy_activationspec(left, name=opname)
        op = Operator(
            name=outact.name,
            options=layer_options.MinimumOptions(
                inputs=(
                    self.get_activation_index(left),
                    self.get_activation_index(right),
                ),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)
        return outact

    def make_maximum(self, left, right, opname=""):
        if not opname:
            opname = left.name + "/maximum"
        outact = self.copy_activationspec(left, name=opname)
        op = Operator(
            name=outact.name,
            options=layer_options.MaximumOptions(
                inputs=(
                    self.get_activation_index(left),
                    self.get_activation_index(right),
                ),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)
        return outact

    def make_tensor_cmp(self, left, right, kind: str = "eq", opname=""):
        if not opname:
            opname = left.name + "/kind"
        output_shape = _broadcast_shape(
            left.get_act_src_shape(), right.get_act_src_shape()
        )
        outact = self.copy_activationspec(
            left, src_shape=output_shape, dataformat=DataFormat.UNKNOWN, name=opname
        )
        op = Operator(
            name=outact.name,
            options=layer_options.TensorCmpOptions(
                inputs=(
                    self.get_activation_index(left),
                    self.get_activation_index(right),
                ),
                outputs=(self.get_activation_index(outact),),
                kind=kind,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_greater(self, left: ActivationSpec, right: ActivationSpec, opname=""):
        if isinstance(left, self._activationspec_cls) and isinstance(
            right, self._activationspec_cls
        ):
            if not opname:
                opname = left.name + "/greater"
            outact = self.copy_activationspec(left, name=opname, dtype="bool")

            op = Operator(
                name=outact.name,
                options=layer_options.GreaterOptions(
                    inputs=(
                        self.get_activation_index(left),
                        self.get_activation_index(right),
                    ),
                    outputs=(self.get_activation_index(outact),),
                ),
            )
            self.add_operator(op)
            return outact
        elif not isinstance(left, self._activationspec_cls) and not isinstance(
            right, self._activationspec_cls
        ):
            return left > right
        else:
            if isinstance(left, self._activationspec_cls):
                is_const_first = False
                ref_act, const_val = left, right
            else:
                is_const_first = True
                ref_act, const_val = right, left
            if not opname:
                opname = ref_act.name + "/greater"

            outact = self.copy_activationspec(ref_act, name=opname, dtype="bool")
            constant_idx = self.add_weight(opname + "/const", const_val)
            op = Operator(
                name=outact.name,
                options=layer_options.GreaterOptions(
                    inputs=(self.get_activation_index(left),),
                    outputs=(self.get_activation_index(outact),),
                    is_const_first=is_const_first,
                    constant=constant_idx,
                ),
            )
            self.add_operator(op)
            return outact

    def make_constant_of_shape(self, shape, value, opname=""):
        if not opname:
            opname = shape.name + "/const"
        outact = self.activationspec(
            name=opname, dtype=shape.dtype, src_shape=shape.src_shape
        )
        op = Operator(
            name=opname,
            options=layer_options.ConstantOfShapeOptions(
                inputs=(self.get_activation_index(shape),),
                outputs=(self.get_activation_index(outact),),
                value=value,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op
        return outact

    def make_log(self, x: ActivationSpec, opname=""):
        if not opname:
            opname = x.name + "/log"
        outact = self.copy_activationspec(x, name=opname)
        op = Operator(
            name=outact.name,
            options=layer_options.LogOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_erf(self, x: ActivationSpec, opname=""):
        if not opname:
            opname = x.name + "/erf"
        outact = self.copy_activationspec(x, name=opname)
        op = Operator(
            name=outact.name,
            options=layer_options.ErfOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_pow(self, x: ActivationSpec, exponent: float, opname=""):
        if not opname:
            opname = x.name + "/pow"
        outact = self.copy_activationspec(x, name=opname)
        op = Operator(
            name=outact.name,
            options=layer_options.PowOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                exponent=exponent,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_pad(
        self,
        inact: ActivationSpec,
        pad_mode: str,
        west_padding=0,
        east_padding=0,
        north_padding=0,
        south_padding=0,
        constant=0.0,
        padding_list=tuple(),
        opname="",
    ):
        if not opname:
            opname = inact.name + "/pad"
        assert (
            inact.src_dim == 4
        ), f"expected dim=4, but got {inact.get_act_src_shape()}"
        n, h, w, c = inact.src_shape
        h_out = h + north_padding + south_padding
        w_out = w + east_padding + west_padding
        outact = self.activationspec(
            opname, inact.dtype, (n, h_out, w_out, c), DataFormat.NHWC
        )

        op = Operator(
            name=outact.name,
            options=layer_options.PadOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                pad_mode=pad_mode,
                west_padding=west_padding,
                east_padding=east_padding,
                north_padding=north_padding,
                south_padding=south_padding,
                constant=constant,
                padding_list=padding_list,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_pad_channel(
        self,
        inact: ActivationSpec,
        pad_mode: str,
        front_padding=0,
        back_padding=0,
        constant=0.0,
        opname="",
    ):
        if not opname:
            opname = inact.name + "/pad"
        assert (
            inact.src_dim == 4
        ), f"expected dim=4, but got {inact.get_act_src_shape()}"
        n, h, w, c = inact.src_shape
        c_out = c + front_padding + back_padding
        outact = self.activationspec(
            opname, inact.dtype, (n, h, w, c_out), DataFormat.NHWC
        )

        op = Operator(
            name=outact.name,
            options=layer_options.PadChannelOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                pad_mode=pad_mode,
                front_padding=front_padding,
                back_padding=back_padding,
                constant=constant,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_pad_generic(
        self,
        inact: ActivationSpec,
        pad_mode: str,
        constant=0.0,
        padding_list=tuple(),
        opname="",
    ):
        if not opname:
            opname = inact.name + "/pad"
        rank = len(inact.get_act_src_shape())
        pre_pad, post_pad = padding_list[:rank], padding_list[rank:]

        output_src_shape = []
        for pre, s, post in zip(pre_pad, inact.get_act_src_shape(), post_pad):
            output_src_shape.append(pre + s + post)

        outact = self.activationspec(opname, inact.dtype, tuple(output_src_shape))

        op = Operator(
            name=outact.name,
            options=layer_options.PadGenericOptions(
                inputs=(self.get_activation_index(inact),),
                outputs=(self.get_activation_index(outact),),
                pad_mode=pad_mode,
                constant=constant,
                padding_list=padding_list,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_cast(self, x: ActivationSpec, data_type: str, opname=""):
        if not opname:
            opname = x.name + "/cast"
        outact = self.copy_activationspec(x, name=opname, dtype=data_type)
        op = Operator(
            name=outact.name,
            options=layer_options.CastOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                data_type=data_type,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_batchnorm(
        self,
        x: ActivationSpec,
        gamma,
        beta,
        moving_mean,
        moving_var,
        epsilon,
        opname="",
    ):
        if not opname:
            opname = x.name + "/batchnorm"

        outact = self.copy_activationspec(x, name=opname)

        gamma_idx = self.add_weight(opname + ".gamma", gamma)
        beta_idx = self.add_weight(opname + ".beta", beta)
        moving_mean_idx = self.add_weight(opname + ".moving_mean", moving_mean)
        moving_var_idx = self.add_weight(opname + ".moving_var", moving_var)
        epsilon_idx = self.add_weight(opname + ".epsilon", epsilon)
        op = Operator(
            name=outact.name,
            options=layer_options.BatchnormOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                gamma=gamma_idx,
                beta=beta_idx,
                moving_mean=moving_mean_idx,
                moving_var=moving_var_idx,
                epsilon=epsilon_idx,
            ),
        )
        self.add_operator(op)
        return outact

    def _make_pooling(
        self,
        x: ActivationSpec,
        h_kernel: int,
        w_kernel: int,
        h_stride: int,
        w_stride: int,
        west_padding: int,
        east_padding: int,
        north_padding: int,
        south_padding: int,
        pool_type: str,
        pad_mode: str,
        h_dilation: int,
        w_dilation: int,
        padding_list=None,
        is_ceil_mode=False,
        is_include_pad=False,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/pooling"

        in_n, in_h, in_w, in_c = x.get_act_src_shape()
        out_h = _conv_out_size(
            in_h, north_padding, south_padding, h_kernel, h_dilation, h_stride
        )
        out_w = _conv_out_size(
            in_w, west_padding, east_padding, w_kernel, w_dilation, w_stride
        )

        outact_src_shape = (in_n, out_h, out_w, in_c)
        outact = self.activationspec(opname, x.dtype, outact_src_shape, DataFormat.NHWC)

        if padding_list is None:
            padding_list = tuple()

        op = Operator(
            name=outact.name,
            options=layer_options.PoolingOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                h_kernel=h_kernel,
                w_kernel=w_kernel,
                h_stride=h_stride,
                w_stride=w_stride,
                west_padding=west_padding,
                east_padding=east_padding,
                north_padding=north_padding,
                south_padding=south_padding,
                pool_type=pool_type,
                pad_mode=pad_mode,
                h_dilation=h_dilation,
                w_dilation=w_dilation,
                padding_list=padding_list,
                is_ceil_mode=is_ceil_mode,
                is_include_pad=is_include_pad,
            ),
        )
        self.add_operator(op)
        return outact

    def make_global_avgpool(self, x: ActivationSpec, opname: str = ""):
        if not opname:
            opname = x.name + "/global_avgpool"
        n, h, w, c = x.get_act_src_shape()
        if h.dynamic or w.dynamic:
            raise NotImplementedError
        return self._make_pooling(
            x,
            h_kernel=int(h),
            w_kernel=int(w),
            w_stride=1,
            h_stride=1,
            west_padding=0,
            east_padding=0,
            north_padding=0,
            south_padding=0,
            pool_type="AvgPool",
            pad_mode="constant",
            h_dilation=1,
            w_dilation=1,
            padding_list=None,
            is_ceil_mode=False,
            is_include_pad=False,
            opname=opname,
        )

    def make_global_avgpool_nd(
        self, x: ActivationSpec, channel_last: bool = True, opname: str = ""
    ):
        if not opname:
            opname = x.name + "/global_avgpool_nd"

        outact_src_shape = list(x.src_shape)
        if channel_last:
            outact_src_shape[1:-1] = [1] * (len(outact_src_shape) - 2)
            outact_src_shape = tuple(outact_src_shape)
            outact = self.activationspec(
                opname, x.dtype, outact_src_shape, DataFormat.UNKNOWN
            )
        else:
            outact_src_shape[2:] = [1] * (len(outact_src_shape) - 2)
            outact_src_shape = tuple(outact_src_shape)
            outact = self.activationspec(
                opname, x.dtype, outact_src_shape, DataFormat.UNKNOWN
            )

        op = Operator(
            name=outact.name,
            options=layer_options.GlobalAveragePoolingOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                channel_last=channel_last,
            ),
        )
        self.add_operator(op)
        return outact

    def make_avgpool(
        self,
        x: ActivationSpec,
        h_kernel: int,
        w_kernel: int,
        h_stride: int,
        w_stride: int,
        west_padding: int,
        east_padding: int,
        north_padding: int,
        south_padding: int,
        pad_mode: str = "constant",
        h_dilation=1,
        w_dilation=1,
        padding_list=None,
        is_ceil_mode=False,
        is_include_pad=False,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/avgpool"
        return self._make_pooling(
            x,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            w_stride=w_stride,
            h_stride=h_stride,
            west_padding=west_padding,
            east_padding=east_padding,
            north_padding=north_padding,
            south_padding=south_padding,
            pool_type="AvgPool",
            pad_mode=pad_mode,
            h_dilation=h_dilation,
            w_dilation=w_dilation,
            padding_list=padding_list,
            is_ceil_mode=is_ceil_mode,
            is_include_pad=is_include_pad,
            opname=opname,
        )

    def make_maxpool(
        self,
        x: ActivationSpec,
        h_kernel: int,
        w_kernel: int,
        h_stride: int,
        w_stride: int,
        west_padding: int,
        east_padding: int,
        north_padding: int,
        south_padding: int,
        pad_mode: str,
        h_dilation=1,
        w_dilation=1,
        padding_list=None,
        is_ceil_mode=False,
        is_include_pad=False,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/maxpool"
        return self._make_pooling(
            x,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            h_stride=h_stride,
            w_stride=w_stride,
            west_padding=west_padding,
            east_padding=east_padding,
            north_padding=north_padding,
            south_padding=south_padding,
            pool_type="MaxPool",
            pad_mode=pad_mode,
            h_dilation=h_dilation,
            w_dilation=w_dilation,
            padding_list=padding_list,
            is_ceil_mode=is_ceil_mode,
            is_include_pad=is_include_pad,
            opname=opname,
        )

    def make_custom_op(
        self,
        inputs: Tuple[ActivationSpec],
        output_src_shapes: Tuple,
        output_dtypes: Tuple = None,
        output_dataformats: Tuple = None,
        content: str = "",
        custom_fn=None,
        opname="",
    ):
        if not opname:
            opname = inputs[0].name + "/custom_op"

        if output_dtypes is None:
            output_dtypes = [inputs[0].dtype] * len(output_src_shapes)
        if output_dataformats is None:
            output_dataformats = [DataFormat.UNKNOWN] * len(output_src_shapes)

        outputs = []
        for idx, (oss, odt, odf) in enumerate(
            zip(output_src_shapes, output_dtypes, output_dataformats)
        ):
            if len(output_src_shapes) > 1:
                opname = opname + str(idx)
            outact = self.activationspec(opname, odt, oss, odf)
            outputs.append(outact)

        op = Operator(
            name=outputs[0].name,
            options=layer_options.CustomOpOptions(
                inputs=tuple(self.get_activation_index(a) for a in inputs),
                outputs=tuple(self.get_activation_index(a) for a in outputs),
                content=content,
            ),
        )
        op.custom_fn = custom_fn
        self.add_operator(op)
        for oact in outputs:
            _set_producer_op(op, oact)
        return tuple(outputs)

    def make_roll(
        self,
        x: ActivationSpec,
        shifts: int | Tuple[int, ...],
        dims: Optional[int | Tuple[int, ...]] = None,
        opname="",
    ):
        if not opname:
            opname = x.name + "/roll"

        if isinstance(shifts, int):
            shifts = (shifts,)
        if isinstance(dims, int):
            dims = (dims,)
        assert (dims is None and len(shifts) == 1) or len(dims) == len(shifts)

        outact = self.activationspec(
            opname, dtype=x.dtype, src_shape=x.src_shape, dataformat=x.dataformat
        )
        op = Operator(
            name=outact.name,
            options=layer_options.RollOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                shifts=shifts,
                dims=dims,
            ),
        )
        self.add_operator(op)
        return outact

    def make_mod(self, x: ActivationSpec, other, opname: str = ""):
        if not opname:
            opname = x.name + "/mod"
        return self._make_biop(x, other, "mod", opname=opname)

    def make_scatter_nd(
        self, data: ActivationSpec, indices, updates: Any, opname: str = ""
    ):
        if not opname:
            opname = data.name + "/scatter_nd"

        outact = self.activationspec(
            name=opname,
            dtype=data.dtype,
            src_shape=data.src_shape,
            dataformat=data.dataformat,
        )
        updates_idx = self.add_weight(opname + ".updates", updates)
        indices_idx = self.add_weight(opname + ".indices", indices)

        op = Operator(
            name=outact.name,
            options=layer_options.ScatterNDOptions(
                inputs=(self.get_activation_index(data),),
                outputs=(self.get_activation_index(outact),),
                constant_data=updates_idx,
                constant_indices=indices_idx,
            ),
        )
        self.add_operator(op)
        return outact

    def make_equal(self, left: ActivationSpec, right: ActivationSpec, opname=""):
        if not opname:
            opname = left.name + "/equal"
        if self.is_act_value_type(left) and not self.is_act_value_type(right):
            if isinstance(right, (int, float)):
                outact = self.copy_activationspec(left, name=opname, dtype="bool")
                constant = self.add_weight(opname + ".right", right)
                kw = {
                    "inputs": (self.get_activation_index(left),),
                    "outputs": (self.get_activation_index(outact),),
                    "constant": constant,
                    "is_const_first": False,
                }
            else:
                raise NotImplementedError(type(right), left, right)
        else:
            raise NotImplementedError
        op = Operator(name=outact.name, options=layer_options.EqualOptions(**kw))
        self.add_operator(op)
        return outact

    def make_cumsum(
        self, x: ActivationSpec, axis, exclusive=0, reverse=0, opname: str = ""
    ):
        if not opname:
            opname += "/cumsum"
        outact = self.copy_activationspec(x, name=opname)
        op = Operator(
            name=outact.name,
            options=layer_options.CumSumOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                axis=axis,
                exclusive=exclusive,
                reverse=reverse,
            ),
        )
        self.add_operator(op)
        return outact

    def make_rsqrt(self, x: ActivationSpec, opname: str = ""):
        if not opname:
            opname += "/rsqrt"
        outact = self.copy_activationspec(x, name=opname)
        op = Operator(
            name=outact.name,
            options=layer_options.RsqrtOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_rstd(
        self,
        x: ActivationSpec,
        reduce_axes: Tuple[int, ...],
        epsilon,
        num_groups: int = 1,
        opname: str = "",
    ):
        if not opname:
            opname += "/rstddev"
        assert len(x.get_act_src_shape()) == 4, "rstddev only supports 4D"
        n, h, w, c = x.get_act_src_shape()
        assert 0 == int(c) % num_groups, "num_groups must divide channel"
        if reduce_axes == (1, 2, 3):
            if num_groups > 1:
                src_shape = (n, 1, 1, num_groups)
            else:
                src_shape = (n, 1, 1, 1)
        else:
            raise NotImplementedError
        outact = self.activationspec(
            name=opname, dtype=x.dtype, src_shape=src_shape, dataformat=DataFormat.NHWC
        )
        epsilon_idx = self.add_weight(outact.name + ".epsilon", epsilon)
        op = Operator(
            name=outact.name,
            options=layer_options.RstdOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                reduce_axes=reduce_axes,
                epsilon=epsilon_idx,
                num_groups=num_groups,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_sqrt(self, x: ActivationSpec, opname: str = ""):
        if not opname:
            opname += "/sqrt"
        outact = self.copy_activationspec(x, name=opname)
        op = Operator(
            name=outact.name,
            options=layer_options.SqrtOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)
        return outact

    def make_less(self, left, right, opname: str = ""):
        if not opname:
            opname += "/less"

        if isinstance(left, self._activationspec_cls):
            if isinstance(right, self._activationspec_cls):
                outact_src_shape = _broadcast_shape(
                    left.get_act_src_shape(), right.get_act_src_shape()
                )
                outact = self.copy_activationspec(
                    left, name=opname, src_shape=outact_src_shape
                )
                op = Operator(
                    name=outact.name,
                    options=layer_options.LessV2Options(
                        inputs=(
                            self.get_activation_index(left),
                            self.get_activation_index(right),
                        ),
                        outputs=(self.get_activation_index(outact),),
                    ),
                )
            else:
                outact = self.copy_activationspec(left, name=opname)
                op = Operator(
                    name=outact.name,
                    options=layer_options.LessOptions(
                        inputs=(self.get_activation_index(left),),
                        outputs=(self.get_activation_index(outact),),
                        is_const_first=False,
                        constant=self.add_weight(opname + ".right", right),
                    ),
                )
        else:
            raise NotImplementedError
        self.add_operator(op)
        return outact

    def make_less_than_or_equal(self, left, right, opname: str = ""):
        if not opname:
            opname += "/le"

        if isinstance(left, self._activationspec_cls):
            if isinstance(right, self._activationspec_cls):
                outact_src_shape = _broadcast_shape(
                    left.get_act_src_shape(), right.get_act_src_shape()
                )
                outact = self.copy_activationspec(
                    left, name=opname, src_shape=outact_src_shape, dtype="bool"
                )
                op = Operator(
                    name=outact.name,
                    options=layer_options.LessThenOrEqualOptions(
                        inputs=(
                            self.get_activation_index(left),
                            self.get_activation_index(right),
                        ),
                        outputs=(self.get_activation_index(outact),),
                    ),
                )
            else:
                raise NotImplementedError
        else:
            raise NotImplementedError
        self.add_operator(op)
        _set_producer_op(op, outact)
        return outact

    def make_shape(self, x: ActivationSpec, start=None, end=None, opname=""):
        if not opname:
            opname = x.name + "/shape"
        s = start
        e = end
        if start is None:
            start = 0
        if start < 0:
            start = x.src_dim + start
        if end is None:
            end = x.src_dim
        src_shape = (end - start,)

        outact = ActivationSpec(opname, dtype="int64", src_shape=src_shape)
        self._add_activation(outact)
        outact.builder = self
        op = Operator(
            name=outact.name,
            options=layer_options.ShapeOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                start=s,
                end=e,
            ),
        )
        self.add_operator(op)
        return outact

    def make_cos(self, x: ActivationSpec, opname=""):
        if not opname:
            opname = x.name + "/cos"
        outact = self.copy_activationspec(x, name=opname)
        op = Operator(
            name=outact.name,
            options=layer_options.CosOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)
        return outact

    def make_sin(self, x: ActivationSpec, opname=""):
        if not opname:
            opname = x.name + "/sin"
        outact = self.copy_activationspec(x, name=opname)
        op = Operator(
            name=outact.name,
            options=layer_options.SinOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
            ),
        )
        self.add_operator(op)
        return outact

    def make_stateful_lstm_wrapper(
        self,
        X,
        sequence_length=None,
        init_hidden_state=None,
        init_cell_state=None,
        W=None,
        R=None,
        B=None,
        P=None,
        output_mask: str = "",
        hidden_size: int = "",
        hidden_state_name: str = "",
        cell_state_name: str = "",
        subgraph: str = "",
        direction: str = "forward",
        batch_first: bool = True,
    ):
        assert bool(subgraph)
        assert direction in ("forward", "backward")

        if not batch_first:
            raise NotImplementedError
        else:
            seq_len = X.get_act_src_shape()[2]

        input_mask = ""
        for imask, item in zip(
            ("ishc"), (X, sequence_length, init_hidden_state, init_cell_state)
        ):
            if item is not None:
                input_mask += imask

        inputs = []
        for item in (X, sequence_length, init_hidden_state, init_cell_state):
            if item is not None:
                inputs.append(self.get_activation_index(item))
        outact_o = self.copy_activationspec(
            X,
            # src_shape=(1, 1, DimValue(seq_len, dynamic=True), hidden_size),
            src_shape=(1, 1, seq_len, hidden_size),
            name=subgraph,
        )
        outact_h = self.copy_activationspec(
            X, src_shape=(1, 1, 1, hidden_size), name=hidden_state_name
        )
        outact_c = self.copy_activationspec(
            X, src_shape=(1, 1, 1, hidden_size), name=cell_state_name
        )
        outputs = tuple(
            self.get_activation_index(item) for item in (outact_o, outact_h, outact_c)
        )

        W_idx = self.add_weight(outact_o.name + ".W", W)
        R_idx = self.add_weight(outact_o.name + ".R", R)
        if B is not None:
            B_idx = self.add_weight(outact_o.name + ".B", B)
        else:
            B_idx = -1
        if P is not None:
            P_idx = self.add_weight(outact_o.name + ".P", P)
        else:
            P_idx = -1

        op = Operator(
            name=outact_o.name,
            options=layer_options.StatefulLSTMWrapperOptions(
                inputs=tuple(inputs),
                outputs=outputs,
                W=W_idx,
                R=R_idx,
                input_mask=input_mask,
                output_mask=output_mask,
                hidden_size=hidden_size,
                hidden_state_name=hidden_state_name,
                cell_state_name=cell_state_name,
                subgraph=subgraph,
                B=B_idx,
                P=P_idx,
                direction=direction,
                batch_first=batch_first,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact_o)
        _set_producer_op(op, outact_h)
        _set_producer_op(op, outact_c)
        return [outact_o, outact_h, outact_c]

    def make_stateful_rnn_wrapper(
        self,
        X,
        sequence_length=None,
        init_hidden_state=None,
        W=None,
        R=None,
        B=None,
        output_mask: str = "",
        hidden_size: int = "",
        hidden_state_name: str = "",
        subgraph: str = "",
        direction: str = "forward",
        batch_first: bool = True,
    ):
        assert bool(subgraph)
        assert direction in ("forward", "backward")

        if not batch_first:
            raise NotImplementedError
        else:
            seq_len = X.get_act_src_shape()[2]

        input_mask = ""
        for imask, item in zip(("ish"), (X, sequence_length, init_hidden_state)):
            if item is not None:
                input_mask += imask

        inputs = []
        for item in (X, sequence_length, init_hidden_state):
            if item is not None:
                inputs.append(self.get_activation_index(item))
            if item is X:
                X.get_act_src_shape()[-2].set_dynamic()
        outact_o = self.copy_activationspec(
            X,
            # src_shape=(1, 1, DimValue(seq_len, True), hidden_size),
            src_shape=(1, 1, seq_len, hidden_size),
            name=subgraph,
        )
        outact_h = self.copy_activationspec(
            X, src_shape=(1, 1, 1, hidden_size), name=hidden_state_name
        )
        outputs = tuple(
            self.get_activation_index(item) for item in (outact_o, outact_h)
        )

        W_idx = self.add_weight(outact_o.name + ".W", W)
        R_idx = self.add_weight(outact_o.name + ".R", R)
        if B is not None:
            B_idx = self.add_weight(outact_o.name + ".B", B)
        else:
            B_idx = -1
        op = Operator(
            name=outact_o.name,
            options=layer_options.StatefulRNNWrapperOptions(
                inputs=tuple(inputs),
                outputs=outputs,
                W=W_idx,
                R=R_idx,
                input_mask=input_mask,
                output_mask=output_mask,
                hidden_size=hidden_size,
                hidden_state_name=hidden_state_name,
                subgraph=subgraph,
                B=B_idx,
                direction=direction,
                batch_first=batch_first,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact_o)
        _set_producer_op(op, outact_h)
        return [outact_o, outact_h]

    def make_stateful_gru_wrapper(
        self,
        X,
        sequence_length=None,
        init_hidden_state=None,
        W=None,
        R=None,
        B=None,
        output_mask: str = "",
        hidden_size: int = "",
        hidden_state_name: str = "",
        subgraph: str = "",
        direction: str = "forward",
        batch_first: bool = True,
        linear_before_reset: bool = False,
    ):
        assert bool(subgraph)
        assert direction in ("forward", "backward")

        if not batch_first:
            raise NotImplementedError
        else:
            seq_len = X.get_act_src_shape()[2]

        input_mask = ""
        for imask, item in zip(("ish"), (X, sequence_length, init_hidden_state)):
            if item is not None:
                input_mask += imask

        inputs = []
        for item in (X, sequence_length, init_hidden_state):
            if item is not None:
                inputs.append(self.get_activation_index(item))
        outact_o = self.copy_activationspec(
            X,
            # src_shape=(1, 1, DimValue(seq_len, True), hidden_size),
            src_shape=(1, 1, seq_len, hidden_size),
            name=subgraph,
        )
        outact_h = self.copy_activationspec(
            X, src_shape=(1, 1, 1, hidden_size), name=hidden_state_name
        )
        outputs = tuple(
            self.get_activation_index(item) for item in (outact_o, outact_h)
        )

        W_idx = self.add_weight(outact_o.name + ".W", W)
        R_idx = self.add_weight(outact_o.name + ".R", R)
        if B is not None:
            B_idx = self.add_weight(outact_o.name + ".B", B)
        else:
            B_idx = -1

        op = Operator(
            name=outact_o.name,
            options=layer_options.StatefulGRUWrapperOptions(
                inputs=tuple(inputs),
                outputs=outputs,
                W=W_idx,
                R=R_idx,
                input_mask=input_mask,
                output_mask=output_mask,
                hidden_size=hidden_size,
                hidden_state_name=hidden_state_name,
                subgraph=subgraph,
                B=B_idx,
                direction=direction,
                batch_first=batch_first,
                linear_before_reset=linear_before_reset,
            ),
        )
        self.add_operator(op)
        _set_producer_op(op, outact_o)
        _set_producer_op(op, outact_h)
        return [outact_o, outact_h]

    def make_ordered_patchfy(
        self,
        x: ActivationSpec,
        h_kernel: int,
        w_kernel: int,
        order: int = 0,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/ordered_patchfy"
        n, h, w, c = x.src_shape
        h_kernel = int(h_kernel)
        w_kernel = int(w_kernel)
        h_grid = int(h) // h_kernel
        w_grid = int(w) // w_kernel
        if order == 0:
            src_shape = (n, h_grid * w_grid, h_kernel * w_kernel, c)
        elif order == 1:
            src_shape = (n, h_kernel * w_kernel, h_grid * w_grid, c)
        elif order == 2:
            src_shape = (n, h_grid * w_grid, h_kernel * w_kernel, c)
        else:
            raise NotImplementedError("order must be 0, 1 or 2")
        outact = self.activationspec(
            name=opname, dtype=x.dtype, src_shape=src_shape, dataformat=DataFormat.NHWC
        )
        op = Operator(
            name=outact.name,
            options=layer_options.OrderedPatchifyOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                h_kernel=h_kernel,
                w_kernel=w_kernel,
                order=order,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op

        return outact

    def make_tile(self, x: ActivationSpec, repeats: List[int], opname: str = ""):
        if not opname:
            opname = x.name + "/tile"
        assert x.src_dim == len(repeats)
        output_src_shape = tuple(i * r for i, r in zip(x.src_shape, repeats))
        outact = self.copy_activationspec(
            x, name=opname, src_shape=output_src_shape, shape=(-1, -1, -1)
        )
        op = Operator(
            name=outact.name,
            options=layer_options.TileOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                repeats=tuple(repeats),
            ),
        )
        self.add_operator(op)
        outact.producer_op = op
        return outact

    def make_logit(self, x: ActivationSpec, eps=None, opname: str = ""):
        if not opname:
            opname = x.name + "/logit"
        outact = self.copy_activationspec(x, name=opname, shape=(-1, -1, -1))
        op = Operator(
            name=outact.name,
            options=layer_options.LogitOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                eps=eps,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op
        return outact

    def make_grid_sample(
        self,
        x: ActivationSpec,
        grid: Any,
        mode="linear",
        padding_mode="zeros",
        align_corners: int = 0,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/grid_sample"

        kw = {}
        if self.is_act_value_type(x) and self.is_act_value_type(grid):
            n_out, h_out, w_out, _ = grid.src_shape
            inputs = (self.get_activation_index(x), self.get_activation_index(grid))
        elif self.is_act_value_type(x):
            n_out, h_out, w_out, _ = grid.shape
            inputs = (self.get_activation_index(x),)
            kw["is_const_first"] = False
            kw["constant"] = self.add_weight(opname + ".grid", grid)
        else:
            raise NotImplementedError("make_grid_sample with nonconst input")

        n, h, w, c = x.src_shape
        assert n_out == n

        outact = self.copy_activationspec(
            x, name=opname, src_shape=(n, h_out, w_out, c), shape=(-1, -1, -1)
        )
        op = Operator(
            name=outact.name,
            options=layer_options.GridSampleOptions(
                inputs=inputs,
                outputs=(self.get_activation_index(outact),),
                mode=mode,
                padding_mode=padding_mode,
                align_corners=align_corners,
                **kw,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op
        return outact

    def make_indexed_item_selector(
        self,
        x: ActivationSpec,
        axis=3,
        index=None,
        scale=None,
        bias=None,
        opname: str = "",
    ):
        if not opname:
            opname = f"item{axis}_sel"
        assert index is not None
        assert index.ndim == 1
        if scale is not None:
            assert axis == 3 and scale.shape == index.shape
        if bias is not None:
            assert axis == 3 and bias.shape == index.shape
        output_shape = list(x.src_shape)
        output_shape[axis] = int(index.shape[0])
        outact = self.copy_activationspec(
            x, name=opname, src_shape=tuple(output_shape), shape=(-1, -1, -1)
        )
        weight_idx = self.add_weight(outact.name + ".index", index)
        scale_idx = bias_idx = -1
        if scale is not None:
            scale_idx = self.add_weight(outact.name + ".scale", scale)
        if bias is not None:
            bias_idx = self.add_weight(outact.name + ".bias", bias)
        op = Operator(
            name=outact.name,
            options=layer_options.IndexedItemSelectorOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                axis=axis,
                index=weight_idx,
                scale=scale_idx,
                bias=bias_idx,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op
        return outact

    def make_channelwise_apply(
        self,
        x: ActivationSpec,
        func,
        input_scale=None,
        input_bias=None,
        output_scale=None,
        output_bias=None,
        opname: str = "",
    ):
        if not opname:
            opname = f"capply"
        in_channels = int(x.src_shape[-1])
        group_number = in_channels // func.shape[1]
        assert in_channels % group_number == 0
        output_shape = list(x.src_shape)
        output_shape[-1] = int(func.shape[0])
        outact = self.copy_activationspec(
            x, name=opname, src_shape=tuple(output_shape), shape=(-1, -1, -1)
        )
        func_idx = self.add_weight(outact.name + ".func", func)
        input_scale_idx = -1
        if input_scale is not None:
            input_scale_idx = self.add_weight(outact.name + ".input_scale", input_scale)
        input_bias_idx = -1
        if input_bias is not None:
            input_bias_idx = self.add_weight(outact.name + ".input_bias", input_bias)
        output_scale_idx = -1
        if output_scale is not None:
            output_scale_idx = self.add_weight(
                outact.name + ".output_scale", output_scale
            )
        output_bias_idx = -1
        if output_bias is not None:
            output_bias_idx = self.add_weight(outact.name + ".output_bias", output_bias)

        op = Operator(
            name=outact.name,
            options=layer_options.ChannelwiseApplyOptions(
                inputs=(self.get_activation_index(x),),
                outputs=(self.get_activation_index(outact),),
                func=func_idx,
                group_number=int(group_number),
                input_scale=input_scale_idx,
                input_bias=input_bias_idx,
                output_scale=output_scale_idx,
                output_bias=output_bias_idx,
            ),
        )
        self.add_operator(op)
        outact.producer_op = op
        return outact

    def make_subgraph_call(
        self,
        inputs: Tuple[ActivationSpec, ...],
        outputs,
        kind,
        subgraph,
        **kwargs,
    ):
        if not subgraph:
            raise NotImplementedError("subgraph name is not provided!")
        op = Operator(
            name=outputs[0].name,
            options=layer_options.SubgraphCallOptions(
                inputs=tuple(self.get_activation_index(a) for a in inputs),
                outputs=tuple(self.get_activation_index(a) for a in outputs),
                subgraph=subgraph,
                kind=kind,
                scope=subgraph,
            ),
        )
        self.add_operator(op)
        for oact in outputs:
            _set_producer_op(op, oact)
        return tuple(outputs)

    def make_moe_dispatcher(
        self,
        inputs: Tuple[ActivationSpec, ...],
        top_k: int = 8,
        norm_top_k_prob: bool = False,
        opname="",
    ):
        if not opname:
            opname = f"moe_dispatcher"
        logits, hidden_states = inputs
        topk_prob = self.copy_activationspec(
            logits,
            name=opname + "/selected",
            shape=(-1, -1, -1),
        )
        new_hidden_states = self.copy_activationspec(
            hidden_states,
            name=opname,
            shape=(-1, -1, -1),
        )
        new_outacts = (topk_prob, new_hidden_states)
        new_op = Operator(
            name=new_outacts[0].name,
            options=layer_options.MoeDispatcherOptions(
                inputs=tuple(self.get_activation_index(x) for x in inputs),
                outputs=tuple(self.get_activation_index(x) for x in new_outacts),
                top_k=top_k,
                norm_top_k_prob=norm_top_k_prob,
            ),
        )
        self.add_operator(new_op)
        for outact in new_outacts:
            _set_producer_op(new_op, outact)
        return new_outacts

    def make_moe_aggregator(self, inputs: Tuple[ActivationSpec, ...], opname=""):
        if not opname:
            opname = f"moe_aggregator"
        weights, hidden_states = inputs[0], inputs[1:]
        weight_shape = weights.src_shape  # (1,1,10,128)
        target_shape = hidden_states[1].src_shape  # (1,1,10,2048)
        if not (
            weight_shape[:3] == target_shape[:3] and all(target_shape != h.src_shape)
            for h in hidden_states
        ):
            raise ValueError("shape mismatch between weights and hidden_states")

        new_outact = self.copy_activationspec(
            hidden_states[1], name=opname, shape=(-1, -1, -1)
        )
        new_op = Operator(
            name=new_outact.name,
            options=layer_options.MoeAggregatorOptions(
                inputs=tuple(self.get_activation_index(x) for x in inputs),
                outputs=(self.get_activation_index(new_outact),),
            ),
        )
        self.add_operator(new_op)
        _set_producer_op(new_op, new_outact)
        return new_outact

    def make_subgraph_scope(
        self,
        inputs: Tuple[ActivationSpec, ...],
        kind: str,
        scope: str,
        mode: str = "start",
        subgraph="",
        **kwargs,
    ):
        if not subgraph:
            raise NotImplementedError("subgraph name is not provided!")
        new_inputs = []
        new_outputs = []
        if mode == "start":
            append_name = "_input."
        elif mode == "end":
            append_name = "_output."
        else:
            raise ValueError(f"mode must be start or end, got {mode}")

        for i, iput in enumerate(inputs):
            if iput.src_dim < 4:
                new_shape = (1,) * (4 - iput.src_dim) + iput.src_shape
                iput = self.make_reshape(iput, new_shape)
            oput = self.copy_activationspec(
                iput, namename=subgraph + append_name + str(i)
            )
            new_inputs.append(iput)
            new_outputs.append(oput)

        op = Operator(
            name=new_outputs[0].name,
            options=layer_options.SubgraphScopeOptions(
                inputs=tuple(self.get_activation_index(a) for a in new_inputs),
                outputs=tuple(self.get_activation_index(a) for a in new_outputs),
                kind=kind,
                scope=scope,
                mode=mode,
                subgraph=subgraph,
            ),
        )
        self.add_operator(op)
        for oact in new_outputs:
            _set_producer_op(op, oact)
        outputs = []
        for iput, oput in zip(inputs, new_outputs):
            if iput.src_shape != oput.src_shape:
                oput = self.make_reshape(oput, iput.src_shape)
            outputs.append(oput)
        return tuple(outputs)
