import enum
from typing import Any


class DeviceType(enum.Enum):
    Aries = 0
    Aries_devel = 1
    Regulus = 2
    Aries2 = 3
    Regulus2 = 4


DeviceType_LIST = [name.lower() for name in DeviceType.__members__]

# todo:  `_missing_` hook is not working. but don't know why.
#     @classmethod
#     def _missing_(cls, value: Any):
#
#         if isinstance(value, str):
#             value = value.lower()
#             for member in cls:
#                 if member.lower() == value:
#                     return member
#         return None


def get_device_from_str(device: str):
    case_insensitive_map = {v.lower(): v for v in DeviceType.__members__}
    if device.lower() not in case_insensitive_map:
        raise ValueError(f"device type={device} not found!")
    return DeviceType[case_insensitive_map[device.lower()]]
