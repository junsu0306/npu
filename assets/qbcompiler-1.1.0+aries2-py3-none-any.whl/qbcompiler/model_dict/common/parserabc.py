import abc
from typing import Dict, Any

import numpy


class MobilintParserInputs:

    def __init__(
        self,
        model=None,
        in_shapes: Dict[str, Any] = None,
        in_dformats: Dict[str, Any] = None,
        dynamic_axes: Dict[str, Any] = None,
        feed_dict: Dict[str, Any] = None,
        large_value_dict_path: str = None,
        **kwargs,
    ):
        self.model = model
        self.in_shapes: Dict[str, Any] = in_shapes
        self.in_dformats: Dict[str, Any] = in_dformats
        self.dynamic_axes: Dict[str, Any] = dynamic_axes
        self.feed_dict: Dict[str, Any] = feed_dict
        self.large_value_dict_path: str = large_value_dict_path
        for k, v in kwargs.items():
            setattr(self, k, v)


class MobilintParserOutputs:
    def __init__(self, model_dict=None, const_dict=None, value_dict=None):
        self.model_dict = model_dict
        self.const_dict = const_dict
        self.value_dict = value_dict
        self.origin_input_names = []
        self.origin_output_names = []

    def __iter__(self):
        yield from (self.model_dict, self.const_dict, self.value_dict)


class MobilintParserOutputsCommon:
    def __init__(self, model_dict, const_dict, value_dict):
        self._model_dict = model_dict
        self._const_dict = const_dict
        self._value_dict = value_dict
        self._origin_input_names = []
        self._origin_output_names = []

    @property
    def model_dict(self):
        return self._model_dict

    @property
    def const_dict(self):
        return self._const_dict

    @property
    def value_dict(self):
        return self._value_dict

    @property
    def origin_input_names(self):
        return self._origin_input_names

    @origin_input_names.setter
    def origin_input_names(self, value):
        self._origin_input_names = value

    @property
    def origin_output_names(self):
        return self._origin_output_names

    @origin_output_names.setter
    def origin_output_names(self, value):
        self._origin_output_names = value


class ParserABC(abc.ABC):
    def __init__(self, path_to_model: str, backend: str, seed: int = 12345):
        self._rng = numpy.random.default_rng(seed)
        self._path_to_model = path_to_model
        self.backend = backend

    @abc.abstractmethod
    def parse(
        self, parser_inputs: MobilintParserInputs, **kwargs
    ) -> MobilintParserOutputs: ...

    @property
    def path_to_model(self):
        return self._path_to_model

    @path_to_model.setter
    def path_to_model(self, path_to_model):
        self._path_to_model = path_to_model
