import collections
import functools
from typing import Callable, List, Any

from qbcompiler.model_dict.common import SubGraph, LayerType, Operator
from ._reshape_util import reshape_check as _base_reshape_check


def reshape_check(sg, x, expr: str):
    if x is None:
        return False
    if x.layertype != LayerType.Reshape:
        return False
    inact = sg.activations[x.options.inputs[0]]
    outact = sg.activations[x.options.outputs[0]]
    return _base_reshape_check(expr, inact.src_shape, outact.src_shape)


def is_act_func_type(x):
    if isinstance(x, LayerType):
        lt = x
    else:
        lt = x.layertype
    return lt in (
        LayerType.Relu,
        LayerType.Erf,
        LayerType.LeakyRelu,
        LayerType.PRelu,
        LayerType.Clip,
        LayerType.Exp,
        LayerType.Softplus,
        LayerType.Sigmoid,
        LayerType.Pow,
        LayerType.Gelu,
        LayerType.QuickGelu,
        LayerType.Swish,
        LayerType.HardSwish,
        LayerType.HardSigmoid,
        LayerType.Tanh,
        LayerType.Elu,
    )


def is_biop(x):
    if x is None:
        return False
    if isinstance(x, LayerType):
        lt = x
    else:
        lt = x.layertype
    return lt in (
        LayerType.Adding,
        LayerType.Multiply,
        LayerType.Div,
        LayerType.Sub,
    )


_BIOP_CONST = [
    LayerType.AddingConstant,
    LayerType.MultiplyConstant,
    LayerType.SubConstant,
    LayerType.DivConstant,
]


def is_biop_constant(x):
    if x is None:
        return False
    if isinstance(x, LayerType):
        return x in _BIOP_CONST
    return x.layertype in _BIOP_CONST


def is_biop_constant(x):
    if x is None:
        return False
    if isinstance(x, LayerType):
        lt = x
    else:
        lt = x.layertype
    return lt in (
        LayerType.AddingConstant,
        LayerType.MultiplyConstant,
        LayerType.DivConstant,
        LayerType.SubConstant,
    )


def _is_graph_terminal_node(sg: SubGraph, op):
    return (
        op.layertype == LayerType.Output
        or (
            op.layertype == LayerType.DeviceBridge
            and op.options.outputs[0] in sg.outputs
        )
        or all(not sg.activations[oidx].consumer_ops for oidx in op.options.outputs)
    )


def _get_reverse_op_depth(sg: SubGraph):
    reverse_graph = collections.defaultdict(list)
    q = collections.deque()
    depth = collections.defaultdict(int)
    for parent in sg.operators:
        # Layer of the type Output has the same name as the preceding layer.
        if parent.layertype != LayerType.Output:
            for oidx in parent.options.outputs:
                oact = sg.activations[oidx]
                for child in oact.consumer_ops:
                    reverse_graph[child].append(parent)
        if _is_graph_terminal_node(sg, parent):
            q.append(parent)
            depth[parent] = -1 if parent.layertype == LayerType.Output else 0

    visited = set()
    while q:
        op = q.popleft()
        if op in visited:
            continue
        visited.add(op)
        curr_depth = depth[op]
        for parent in reverse_graph[op]:
            depth[parent] = max(depth[parent], curr_depth + 1)
            q.append(parent)

    depth_max = max(depth.values())
    for k in depth.keys():
        depth[k] = depth_max - depth[k]
    for k in depth.keys():
        if k.layertype == LayerType.Output:
            depth[k] = depth[reverse_graph[k][0]] + 1
    return depth


def sort_operators(sg: SubGraph, update_subgraph=False):
    sorted_ops = [None] * len(sg.operators)
    output_act_indices = set()
    op_depths = _get_reverse_op_depth(sg)
    op_cnt = 0

    def visit(stk, op: Operator, op_cnt: int) -> int:
        sorted_ops[op_cnt] = op
        op_cnt += 1
        if op.layertype == LayerType.Output or (
            op.layertype == LayerType.DeviceBridge
            and not sg.activations[op.outputs[0]].consumer_ops
        ):
            return op_cnt
        for oidx in reversed(op.options.outputs):
            output_act_indices.add(oidx)
            stk.extend(
                filter(
                    lambda cop: cop.layertype == LayerType.Output
                    or cop.options.outputs[0] not in output_act_indices,
                    sorted(
                        sg.activations[oidx].consumer_ops,
                        key=lambda cop: op_depths[cop.name],
                        reverse=True,  # Deeper operators processed last in stack
                    ),
                )
            )
        return op_cnt

    def get_stk(is_init=True):
        if is_init:
            stk = []
            for x in reversed(sg.inputs):  # 여기 왜 reversed했지?
                inact = sg.activations[x]
                if inact.producer_op is None:
                    # subgraph inputs may not have input layers in unsupported subgraph.
                    stk.extend(inact.consumer_ops)
                    output_act_indices.add(x)
                elif inact.producer_op.layertype in (
                    LayerType.Input,
                    LayerType.DeviceBridge,
                ):
                    stk.append(inact.producer_op)
            return stk
        else:
            already_sorted = {x for x in sorted_ops if x is not None}
            # multiple components로 구성된 graph의 경우 input_const로 시작하면 한번에 방문이 불가능 함.
            stk = []
            for op in sg.operators:
                if op not in already_sorted:
                    if op.layertype == LayerType.InputConstant:
                        stk.append(op)
            return stk

    while op_cnt < len(sorted_ops):
        stk = get_stk(op_cnt == 0)
        if not stk:
            invalid_ops = [x for x in sg.operators if not x.valid]
            raise RuntimeError(
                f"Failed to sort operators: graph may contain invalid op nodes: {invalid_ops}"
            )
        while stk:
            op = stk.pop()
            # 0. already visited
            if (
                op.options.outputs[0] in output_act_indices
                and op.layertype != LayerType.Output
            ):
                continue
            # 1. we can visit this op
            if set(op.options.inputs).issubset(output_act_indices):
                op_cnt = visit(stk, op, op_cnt)
            else:
                # 2. we can visit input ops
                if op.layertype == LayerType.Input or (
                    op.layertype == LayerType.DeviceBridge
                    and op.options.inputs[0] in sg.inputs
                ):
                    op_cnt = visit(stk, op, op_cnt)
                else:
                    # 3. add to stack for visit
                    for iidx in op.options.inputs:
                        if (
                            iidx not in output_act_indices
                            and sg.activations[iidx].producer_op is not None
                        ):
                            # None should not be the case
                            stk.append(sg.activations[iidx].producer_op)

    if op_cnt != len(sg.operators):
        raise Exception(f"op_cnt != len(self.operators), {op_cnt}!={len(sg.operators)}")
    if update_subgraph:
        sg.operators = sorted_ops
    return sorted_ops


def _op_check_fn(op: Operator, layertype: LayerType, **options_to_ckeck) -> bool:
    return (
        op is not None
        and op.layertype == layertype
        and all(
            getattr(op.options, k, object()) == v for k, v in options_to_ckeck.items()
        )
    )


def conv_compare(conv0, conv1):
    return _op_check_fn(
        conv0,
        layertype=conv1.layertype,
        in_channels=conv1.options.in_channels,
        out_channels=conv1.options.out_channels,
        group_number=conv1.options.group_number,
        h_kernel=conv1.options.h_kernel,
        w_kernel=conv1.options.w_kernel,
        h_stride=conv1.options.h_stride,
        w_stride=conv1.options.w_stride,
        h_dilation=conv1.options.h_dilation,
        w_dilation=conv1.options.w_dilation,
        east_padding=conv1.options.east_padding,
        west_padding=conv1.options.west_padding,
        north_padding=conv1.options.north_padding,
        south_padding=conv1.options.south_padding,
        channel_last=conv1.options.channel_last,
    )


def is_linear_conv(op) -> bool:
    """
    Checks whether an operator is a convolution that is effectively equivalent to a linear layer.
    """
    return _op_check_fn(
        op,
        layertype=LayerType.Convolution,
        h_kernel=1,
        w_kernel=1,
        h_stride=1,
        w_stride=1,
        h_dilation=1,
        w_dilation=1,
        east_padding=0,
        west_padding=0,
        north_padding=0,
        south_padding=0,
        group_number=1,
        channel_last=True,
    )


def is_transpose_with_axes(*transpose_axes: int) -> Callable[[Operator], bool]:
    """
    Returns a function that checks whether an operator is a Transpose with the specified axes.
    Example:
        check = is_transpose_with_axes(0, 3, 1, 2)
        check(op)
    """
    return functools.partial(
        _op_check_fn, layertype=LayerType.Transpose, transpose_axes=transpose_axes
    )


def is_concatenate_with_axis(*axes: int) -> Callable[[Operator], bool]:
    """
    Returns a function that checks whether an operator is a Concatenate with one of the specified axes.

    If multiple axes are provided, the returned function returns True if the operator's axis
    matches any of them.

    Example:
        check = is_concatenate_with_axis(3)
        if check(op):
            print("Concatenate along axis 3.")

        check = is_concatenate_with_axis(-1, 3)
        if check(op):
            print("Concatenate along axis -1 or 3.")

    """
    checks = (
        functools.partial(_op_check_fn, layertype=LayerType.Concatenate, axis=a)
        for a in axes
    )

    def check_fn(op: Operator) -> bool:
        return any(check(op) for check in checks)

    return check_fn


_CHECK_CONV = functools.partial(_op_check_fn, layertype=LayerType.Convolution)
_CHECK_MATMUL = functools.partial(_op_check_fn, layertype=LayerType.MatMul)
_CHECK_RESHAPE = functools.partial(_op_check_fn, layertype=LayerType.Reshape)
_CHECK_SLICE = functools.partial(_op_check_fn, layertype=LayerType.Slice)
_CHECK_TRANSPOSE = functools.partial(_op_check_fn, layertype=LayerType.Transpose)


@functools.lru_cache(maxsize=256)
def _parse_str_pattern(s: str) -> tuple:
    results = []
    j = 0
    n = len(s)
    while j < n:
        c = s[j]
        if c == "C":
            results.append(_CHECK_CONV)
            j += 1
        elif c == "L":
            results.append(is_linear_conv)
            j += 1
        elif c == "R":
            results.append(_CHECK_RESHAPE)
            j += 1
        elif c == "S":
            results.append(_CHECK_SLICE)
            j += 1
        elif c == "T":
            j += 1
            axes = []
            while j < n and s[j].isdigit():
                axes.append(int(s[j]))
                j += 1
            if axes:
                results.append(is_transpose_with_axes(*axes))
            else:
                results.append(_CHECK_TRANSPOSE)
        elif c == "M":
            if j + 1 < n and s[j + 1] == "m":
                results.append(_CHECK_MATMUL)
                j += 2
            else:
                raise Exception(f"Unsupported layertype character : {c}")
        elif c == "a":
            if s.startswith("actfn", j):
                results.append(is_act_func_type)
                j += 5
            else:
                raise Exception(f"Unsupported layertype character : {c}")
        elif c == "b":
            if s.startswith("biop", j):
                results.append(is_biop)
                j += 4
            else:
                raise Exception(f"Unsupported layertype character : {c}")
        else:
            raise Exception(f"Unsupported layertype character : {c}")
    return tuple(results)


def parse_layer_sequence(seq: List[str | Callable | LayerType]) -> List[Any]:
    """
    This function supports shorthand notation for layer types which simplifying
    the specification of commonly used layer type patterns.

    Example:
        - The string "RTC" is parsed as:
              [LayerType.Reshape, LayerType.Transpose, LayerType.Convolution]
        - The string "T0231" is parsed as:
              (LayerType.Transpose, (0, 2, 3, 1))

        If `layer_types` is provided as a mixed type sequence like:
            (func1, "CT0231R", func2, "SR")
        it is interpreted as:
            [
              func1,
              LayerType.Convolution,
              (LayerType.Transpose, (0, 2, 3, 1)),
              LayerType.Reshape,
              func2,
              LayerType.Slice,
              LayerType.Reshape
            ]

    Supported shorthand include:
        "actfn" -> is_act_func_type (activation function checker).
        "biop" -> (Adding, Multiply, Div, Sub)
        "C" -> Convolution
        "L" -> Linear
        "Mm" -> Matmul
        "R" -> Reshape
        "S" -> Slice
        "T" -> Transpose. support transpose_axes. for exmaple `T0231`
    """

    result = []
    i = 0
    n = len(seq)
    while i < n:
        if callable(seq[i]) or isinstance(seq[i], LayerType):
            result.append(seq[i])
            i += 1
        elif isinstance(seq[i], str):
            acc = []
            while i < n and isinstance(seq[i], str):
                acc.append(seq[i].replace(" ", ""))
                i += 1
            full_str = "".join(acc)
            if full_str:
                result.extend(_parse_str_pattern(full_str))
        else:
            raise TypeError(f"Unsupported element in sequence: {seq[i]}")
    return result


def find_operator_sequence(
    sg: SubGraph,
    op_last: Operator,
    *layer_types: LayerType | str | Callable,
    strict_search=False,
) -> tuple[Operator, ...] | None:
    """
    Finds a sequence of operators in the subgraph that matches the given layer types.
    The search starts from the last operator for efficiency, leveraging subgraph connectivity.
    All operators in the sequence must have a single input.
    """

    layer_types = parse_layer_sequence(layer_types)

    op_sequence = []
    for pat in reversed(layer_types):
        if op_last is None:
            break
        if not op_last.valid:
            break
        if isinstance(pat, LayerType):
            if op_last.layertype != pat:
                break
        elif callable(pat):
            if not pat(op_last):
                break
        else:
            raise NotImplementedError(f"unsupported pattern type: {type(pat)}")
        op_sequence.append(op_last)

        if len(op_sequence) == len(layer_types):
            break
        if len(op_last.options.inputs) > 1:
            break
        op_last = sg.activations[op_last.options.inputs[0]].producer_op
        if not op_last.valid:
            break
        if strict_search:
            if not (
                op_last is not None
                and 1 == len(sg.activations[op_last.options.outputs[0]].consumer_ops)
            ):
                op_last = None
    if len(op_sequence) == len(layer_types):
        return tuple(reversed(op_sequence))
    return None


def find_operator_sequence_bwd_until(
    sg: SubGraph, op_last: Operator, op_condition: Callable, until_: Callable
):
    op_sequence = []
    while True:
        if not op_last.valid:
            return None
        if len(op_last.options.inputs) > 1:
            return None
        if until_(op_last):
            op_sequence.append(op_last)
            return tuple(reversed(op_sequence))
        if op_condition(op_last):
            op_sequence.append(op_last)
            op_last = sg.activations[op_last.options.inputs[0]].producer_op
            if op_last is None:
                return None
        else:
            return None
