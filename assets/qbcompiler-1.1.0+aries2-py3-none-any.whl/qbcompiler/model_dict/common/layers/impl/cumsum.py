import torch

from qbcompiler.model_dict.common import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class CumSum(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("axis", "exclusive", "reverse")

    def get_ops(self):
        return 0

    def _predict(
        self, input_: torch.Tensor, dataformat: DataFormat, **kwargs
    ) -> torch.Tensor:
        if self.exclusive == 1 or self.reverse == 1:
            raise NotImplementedError
        return torch.cumsum(input_.to(self.device), dim=self.axis)
