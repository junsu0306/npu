import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class Shape(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        shape_ = tuple(input_.shape)[self.start : self.end]
        return torch.tensor(shape_).to(self.device)

    def get_ops(self):
        return 0
