import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class ConstantOfShape(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("value",)

    def get_ops(self):
        return 0

    def _predict(self, input0: torch.Tensor, **kwargs) -> torch.Tensor:
        return torch.full_like(input0, self.value)
