import numpy
import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class SpaceToDepth(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_: torch.Tensor, **kwargs):
        if self.channel_last:
            input_ = input_.permute(0, 3, 1, 2)
        x = input_.detach().cpu().numpy()
        n, c, h, w = shape = x.shape
        blocksize = self.block_size
        tmp = numpy.reshape(
            x, [n, c, h // blocksize, blocksize, w // blocksize, blocksize]
        )
        tmp = numpy.transpose(tmp, [0, 3, 5, 1, 2, 4])
        y = numpy.reshape(
            tmp, [n, c * (blocksize**2), h // blocksize, w // blocksize]
        )
        if self.channel_last:
            return (
                torch.tensor(y, dtype=input_.dtype)
                .permute((0, 2, 3, 1))
                .to(self.device)
            )
        else:
            return torch.tensor(y, dtype=input_.dtype).to(self.device)

    def get_ops(self):
        return 0
