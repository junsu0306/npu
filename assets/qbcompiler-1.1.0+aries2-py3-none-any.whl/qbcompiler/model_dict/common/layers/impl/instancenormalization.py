import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class InstanceNormalization(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = (
        "bias",
        "epsilon",
        "scale",
    )

    def _predict_channel_first(self, input_: torch.Tensor, **kwargs):
        return torch.nn.functional.instance_norm(
            input_,
            weight=self.scale.to(input_.device),
            bias=self.bias.to(input_.dtype).to(self.device)
            if self.bias is not None
            else None,
            eps=self.epsilon,
        )

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if self.channel_last:
            if len(input_.shape) == 4:
                num_features = self.scale.shape[0]
                inorm = torch.nn.InstanceNorm2d(
                    num_features=num_features, affine=True, device=input_.device
                )
                inorm.training = False
                inorm.weight = torch.nn.parameter.Parameter(
                    self.scale.to(input_.device)
                )
                inorm.bias = torch.nn.parameter.Parameter(self.bias.to(input_.device))
                inorm.eps = self.epsilon.to(input_.device)

                if self.num_groups != -1:
                    assert len(input_.shape) == 4
                    n, h, w, c = input_.shape
                    if self.group_order == 1:
                        # (1,112,112,64)
                        x = input_.reshape(
                            n, -1, c // self.num_groups, self.num_groups
                        ).permute(
                            0, 3, 1, 2
                        )  # (1,2,112*112,32)
                        x = torch.nn.functional.instance_norm(
                            x.permute(0, 3, 1, 2),
                            weight=self.scale.to(x.device),
                            bias=self.bias.to(x.device),
                            eps=self.epsilon,
                        ).permute(0, 2, 3, 1)
                        x = x.permute(0, 2, 3, 1)  # (1,112*112,32,2)
                        x = x.reshape(n, h, w, c)
                        return x
                    else:
                        raise NotImplementedError

                return inorm(input_.permute(0, 3, 1, 2)).permute(0, 2, 3, 1)
            if len(input_.shape) == 3:
                num_features = self.scale.shape[0]
                inorm = torch.nn.InstanceNorm1d(
                    num_features=num_features, affine=True, device=input_.device
                )
                inorm.training = False
                inorm.weight = torch.nn.parameter.Parameter(
                    self.scale.to(input_.device)
                )
                inorm.bias = torch.nn.parameter.Parameter(self.bias.to(input_.device))
                inorm.eps = self.epsilon.to(input_.device)
                return inorm(input_.permute(0, 2, 1)).permute(0, 2, 1)

        return self._predict_channel_first(input_, **kwargs)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 8 * (get_total_num_elements(output_act.src_shape))
