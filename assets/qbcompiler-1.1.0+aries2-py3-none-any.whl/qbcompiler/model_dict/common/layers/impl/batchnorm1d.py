import torch

from qbcompiler.model_dict.common import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class BatchNorm1d(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("scale", "bias", "epsilon", "moving_mean", "moving_var")

    def get_ops(self):
        output_act = self.outputs[0]
        return 8 * (get_total_num_elements(output_act.src_shape))

    def _predict(
        self, input_: torch.Tensor, dataformat: DataFormat, **kwargs
    ) -> torch.Tensor:
        return torch.nn.functional.batch_norm(
            input_.to(self.device),
            self.moving_mean.to(self.device),
            self.moving_var.to(self.device),
            weight=self.scale.to(self.device),
            bias=self.bias.to(self.device),
            training=False,
            eps=self.epsilon,
        )
