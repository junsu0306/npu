from typing import Tuple

import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    DataFormatGeneric,
    MultiInputsMixin,
)


@register.layer
class Arange(LayerABC, MultiInputsMixin, DataFormatGeneric):
    __slots__ = ("start", "step")

    def get_ops(self):
        return 0

    def _predict(self, inputs: Tuple[torch.Tensor, ...], **kwargs) -> torch.Tensor:
        if len(inputs) == 1:
            return torch.arange(start=self.start, end=inputs[0], step=self.step)

    def folding_fwd(self, input_: torch.Tensor):
        return self._predict([input_])
