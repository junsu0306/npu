import torch

from qbcompiler.model_dict.common import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class StatefulKVCacheWrapper(LayerABC, SingleInputMixin, DataFormatGeneric):
    def get_ops(self):
        return 0

    def _predict(
        self, input_: torch.Tensor, dataformat: DataFormat, **kwargs
    ) -> torch.Tensor:
        if self.cache_name in self.past_key_values:
            cache_ = self.past_key_values[self.cache_name]
            # if cache_.shape[2] != self.past_seqlen:
            #     raise ValueError
            self.past_key_values[self.cache_name] = torch.cat(
                [cache_.to(self.device), input_.to(self.device)], dim=-2
            )
        else:
            # if self.past_seqlen != 0:
            #     raise ValueError(
            #         "self.past_seq_len != 0 and cache value does not exist"
            #     )
            self.past_key_values[self.cache_name] = input_
        return self.past_key_values[self.cache_name]
