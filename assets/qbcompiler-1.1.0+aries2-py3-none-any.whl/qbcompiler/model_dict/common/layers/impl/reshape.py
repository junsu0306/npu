from typing import List
import torch

from qbcompiler.model_dict.common.dataformat import DataFormat
from qbcompiler.model_dict.common.item_specs import DimValue
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


def _reshape_get_new_shape(new_shape, output_src_shape):
    if new_shape == output_src_shape:  # TODO: temporary code
        return output_src_shape
    if -1 in new_shape:
        if len(new_shape) == len(output_src_shape):
            ret = []
            for ns, ss in zip(new_shape, output_src_shape):
                if ns == -1:
                    if ss == -1:
                        raise NotImplementedError(
                            f"new_shape={new_shape}, output_src_shape={output_src_shape}",
                        )
                    else:
                        if isinstance(ss, DimValue):
                            ret.append(ss.value)
                        else:
                            ret.append(ss)
                else:
                    ret.append(ns)
            return tuple(ret)
    else:
        return tuple(new_shape)
    raise NotImplementedError


@register.reshape
class Reshape(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("new_shape",)

    def _interpret_new_shape(self, input_):
        if self.new_shape is not None:
            _new_shape = tuple(
                (
                    x
                    if isinstance(x, DimValue)
                    else (DimValue(x, dynamic=True) if x == -1 else DimValue(x))
                )
                for x in self.new_shape
            )
        else:
            _new_shape = self.outputs[0].src_shape
        # fix special case.
        input_src_shape = self.inputs[0].get_act_src_shape()
        output_src_shape = self.outputs[0].get_act_src_shape()
        if (
            len(input_src_shape) == 3
            and len(output_src_shape) == 4
            and input_src_shape[:2] == output_src_shape[:2] == _new_shape[:2]
            and input_src_shape[1].dynamic
            and output_src_shape[1].dynamic
        ):
            _new_shape = (
                tuple(DimValue(int(x)) for x in input_.shape[:2]) + _new_shape[2:]
            )
        elif (
            len(input_src_shape) == 4
            and len(output_src_shape) == 3
            and input_src_shape[:2] == output_src_shape[:2] == _new_shape[:2]
            and input_src_shape[1].dynamic
            and output_src_shape[1].dynamic
        ):
            _new_shape = (
                tuple(DimValue(int(x)) for x in input_.shape[:2]) + _new_shape[2:]
            )
        elif (
            len(input_src_shape) == 5
            and len(output_src_shape) == 4
            and input_src_shape[3].dynamic
            and input_src_shape[0] == output_src_shape[0]
            and input_src_shape[1] * input_src_shape[2] == output_src_shape[1]
            and input_src_shape[-2:] == output_src_shape[-2:] == _new_shape[-2:]
        ):
            _new_shape = _new_shape[:2] + tuple(
                DimValue(int(x)) for x in input_.shape[3:]
            )
        elif (
            len(input_src_shape) == 4
            and len(output_src_shape) == 4
            and input_src_shape[:2] == (1, 1)
            and input_src_shape[2].dynamic
            and input_src_shape[3] == output_src_shape[2] * output_src_shape[3]
            and output_src_shape[:2] == (1, input_src_shape[2])
        ):
            _new_shape = (
                output_src_shape[0],
                input_src_shape[2],
                output_src_shape[2],
                output_src_shape[3],
            )

        num_dyn = sum(x.dynamic for x in _new_shape)
        if num_dyn > 1:
            if all((not x.dynamic or (x.dynamic and x > 0)) for x in _new_shape):
                return tuple(int(x) for x in _new_shape)
            raise NotImplementedError(f"num dynamic dim value={num_dyn}")
        if num_dyn == 1:
            return tuple(-1 if x.dynamic else int(x) for x in _new_shape)

        dynamic_cnt = 0
        if -1 in _new_shape:
            if len(_new_shape) == len(self.outputs[0].src_shape):
                ret = []
                for ns, ss in zip(_new_shape, self.outputs[0].src_shape):
                    if ns == -1:
                        if ss == -1:
                            ret.append(ss)
                            dynamic_cnt += 1
                        else:
                            ret.append(ss)
                    else:
                        ret.append(ns)
                if dynamic_cnt > 1:
                    raise ValueError("The number of dynamic axis is more than 1")
                return tuple(int(x) for x in ret)
        else:
            output_src_shape = self.outputs[0].get_act_src_shape()
            if sum(x.dynamic for x in output_src_shape) == 1 and all(
                (a == b) or b.dynamic for a, b, in zip(_new_shape, output_src_shape)
            ):
                return tuple(
                    -1 if b.dynamic else int(b)
                    for a, b, in zip(_new_shape, output_src_shape)
                )

            return tuple(int(x) for x in _new_shape)

        raise NotImplementedError

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return input_.to(self.device).reshape(self._interpret_new_shape(input_))

    def get_ops(self):
        return 0

    def folding_fwd(self, input_: torch.Tensor):
        if self.new_shape is None:
            self.new_shape = self.outputs[0].src_shape
        return input_.to(self.device).reshape(tuple(self.new_shape))
