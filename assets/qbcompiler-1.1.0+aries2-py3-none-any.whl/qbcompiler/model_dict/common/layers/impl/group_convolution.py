from numbers import Number

import torch
import torch.nn.functional as F

from qbcompiler.model_dict.common.dataformat import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatSupportedGroup,
)
from qbcompiler.model_dict.common.layers.layers_utils import _DT_CAST


@register.layer
class GroupConvolution(LayerABC, SingleInputMixin, DataFormatSupportedGroup):
    __slots__ = (
        "west_padding",
        "east_padding",
        "south_padding",
        "north_padding",
        "pad_value",
        "h_dilation",
        "w_dilation",
        "h_kernel",
        "w_kernel",
        "in_channels",
        "out_channels",
        "h_stride",
        "w_stride",
        "group_number",
        "weight",
        "bias",
    )

    def _pad_input(self, x):
        paddings = (
            self.west_padding,
            self.east_padding,
            self.south_padding,
            self.north_padding,
        )
        if hasattr(self, "pad_value"):
            if isinstance(self.pad_value, Number):
                temp_bias = torch.full(
                    (self.in_channels,), self.pad_value, device=self.device
                )
            elif isinstance(self.pad_value, torch.Tensor):
                temp_bias = self.pad_value.to(self.device)
            else:
                raise NotImplementedError(
                    f"unsupported pad value type: {type(self.pad_value)} at layer: {self.layer_name}"
                )

            x = x.to(self.device) - temp_bias.reshape(1, -1, 1, 1)
            x = torch.nn.ConstantPad2d(paddings, 0).to(self.device)(x)
            x += temp_bias.reshape(1, -1, 1, 1)
        else:
            x = torch.nn.ConstantPad2d(paddings, 0).to(self.device)(x)
        return x

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if self.channel_last:
            input_ = input_.permute(0, 3, 1, 2)
        x = self._pad_input(input_)
        dtype = _DT_CAST[self.outputs[0].dtype.lower()]
        if self.bias is not None:
            bias = self.bias.to(self.device).to(dtype)
        else:
            bias = self.bias

        if self.channel_last:
            return (
                F.conv2d(
                    input=x.to(self.device),
                    weight=self.weight.to(self.device).to(dtype),
                    bias=bias,
                    stride=(self.h_stride, self.w_stride),
                    padding=0,
                    dilation=(self.h_dilation, self.w_dilation),
                    groups=self.group_number,
                )
                .permute(0, 2, 3, 1)
                .to(dtype)
            )
        else:
            return F.conv2d(
                input=x.to(self.device),
                weight=self.weight.to(self.device).to(dtype),
                bias=bias,
                stride=(self.h_stride, self.w_stride),
                padding=0,
                dilation=(self.h_dilation, self.w_dilation),
                groups=self.group_number,
            ).to(dtype)

    def get_ops(self):
        output_shape = [int(shape) for shape in self.outputs[0].shape]
        return (
            (
                2
                * (self.in_channels // self.group_number)
                * self.h_kernel
                * self.w_kernel
                - 1
            )
            * output_shape[0]
            * output_shape[1]
            * output_shape[2]
        )
