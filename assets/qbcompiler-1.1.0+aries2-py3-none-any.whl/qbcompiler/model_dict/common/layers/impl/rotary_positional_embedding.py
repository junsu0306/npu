from typing import Tuple

import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    MultiInputsMixin,
    DataFormatGeneric,
)


@register.layer
class StatefulRoPEWrapper(LayerABC, MultiInputsMixin, DataFormatGeneric):
    def get_ops(self):
        return 0

    def _rotate_half_type0(self, x):
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat((-x2, x1), dim=-1)

    def _rotate_half_type1(self, x):
        # Split and rotate. Note that this function is different from e.g. llama.
        # we found this in cohere2.
        x1 = x[..., ::2]
        x2 = x[..., 1::2]
        rot_x = torch.stack([-x2, x1], dim=-1).flatten(-2)
        return rot_x

    def _predict(self, inputs: Tuple[torch.Tensor, ...], **kwargs) -> torch.Tensor:
        q, cos, sin = inputs
        curr_token_len = q.shape[2]
        past_seen_tokens = self.seen_tokens
        if past_seen_tokens > 0:
            position_ids = torch.tensor([[past_seen_tokens]])
        else:
            position_ids = torch.arange(curr_token_len)[None, :]
        cos = cos[:, :, position_ids.reshape(-1), :]
        sin = sin[:, :, position_ids.reshape(-1), :]

        if self.rope_type == 0:
            if self.rotary_emb_dim and self.rotary_emb_dim > 0:
                q_rot = q[..., : self.rotary_emb_dim]
                q_pass = q[..., self.rotary_emb_dim :]
                cos = cos[..., : self.rotary_emb_dim]
                sin = sin[..., : self.rotary_emb_dim]
                q_embed = q_rot * cos + self._rotate_half_type0(q_rot) * sin
                q_embed = torch.cat([q_embed, q_pass], dim=-1)
            else:
                q_embed = (q * cos) + (self._rotate_half_type0(q) * sin)
        elif self.rope_type == 1:
            if self.rotary_emb_dim:
                raise NotImplementedError
            q_embed = (q * cos) + (self._rotate_half_type1(q) * sin)
        elif self.rope_type == 2:
            rotary_dim = cos.shape[-1]
            q_rot, q_pass = q[..., :rotary_dim], q[..., rotary_dim:]
            q_embed = torch.cat(
                [(q_rot * cos) + (self._rotate_half_type0(q_rot) * sin), q_pass], dim=-1
            )
        else:
            raise NotImplementedError

        return q_embed
