import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    SingleInputMixin,
    LayerABC,
    DataFormatGeneric,
)


@register.layer
class Cast(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if self.data_type.lower() == "float32":
            return input_.to(self.device).to(torch.float32)
        if self.data_type.lower() == "float16":
            return input_.to(self.device).to(torch.float16)
        if self.data_type.lower() == "int32":
            return input_.to(self.device).to(torch.int32)
        if self.data_type.lower() == "int64":
            return input_.to(self.device).to(torch.int64)
        if self.data_type.lower() == "bfloat16":
            return input_.to(self.device).to(torch.bfloat16)
        raise NotImplementedError(f"cast failed: {self.data_type.lower()}")

    def get_ops(self):
        return 0
