import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    SingleInputMixin,
    LayerABC,
    DataFormatGeneric,
)


@register.reshape
class Transpose(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("transpose_axes",)

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if len(input_.shape) != len(self.transpose_axes):
            raise ValueError(
                f"input_shape={input_.shape}, transpose_axes={self.transpose_axes}"
            )
        return input_.to(self.device).permute(self.transpose_axes)

    def get_ops(self):
        return 0

    def folding_fwd(self, input_: torch.Tensor):
        return self._predict(input_)
