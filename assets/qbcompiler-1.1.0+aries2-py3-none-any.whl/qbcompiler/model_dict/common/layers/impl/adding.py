import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    BiInputsMixin,
    SingleInputMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class Adding(LayerABC, BiInputsMixin, DataFormatGeneric):
    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        return input0.to(self.device) + input1.to(self.device)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)


@register.layer
class AddingConstant(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("constant",)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return input_ + torch.tensor(self.constant).to(self.device)

    def _kernel(self, input_):
        return input_.to(self.device) + self.constant.to(self.device)

    def folding_fwd(self, input_):
        return self._kernel(input_)


@register.layer
class AddPartial(LayerABC, BiInputsMixin, DataFormatGeneric):
    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        if self.is_input0_larger:
            x = torch.zeros_like(input0).to(self.device)
            x[..., : input1.shape[-1]] = input1.to(self.device)
            return input0 + x
        else:
            x = torch.zeros_like(input1).to(self.device)
            x[..., : input0.shape[-1]] = input0.to(self.device)
            return x + input1

    def get_ops(self):
        if self.is_input0_larger:
            input_act = self.inputs[1]
        else:
            input_act = self.inputs[0]
        return get_total_num_elements(input_act.src_shape)
