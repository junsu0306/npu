import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)
import importlib

DEVICEBRIDGE_OPMAPPER = {
    "squeeze_axes": [".squeeze", "Squeeze"],
    "unsqueeze_axes": [".unsqueeze", "Unsqueeze"],
    "permute_axes": [".transpose", "Transpose"],
    "identity": [".input", "Input"],  # identity device bridge use input layer
}


@register.reshape
class DeviceBridge(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("squeeze_axes", "permute_axes", "unsqueeze_axes")

    def __init__(self, *args, **kwargs):
        layer_name = args[0]
        device = args[1]
        del kwargs[
            "device"
        ]  # device option in device bridge will be ignored when we inference
        super().__init__(layer_name, device, **kwargs)
        moduleinfo = DEVICEBRIDGE_OPMAPPER[self.get_attributes_check()]
        self.get_opinstance(moduleinfo, layer_name, device, **kwargs)

    def get_opinstance(self, moduleinfo, layer_name, device, **kwargs):
        module = importlib.import_module(moduleinfo[0], package=__package__)
        if moduleinfo[1] == "Squeeze":
            pass
        elif moduleinfo[1] == "Input":
            pass
        elif moduleinfo[1] == "Unsqueeze":
            kwargs["axes"] = kwargs.pop("unsqueeze_axes")
        elif moduleinfo[1] == "Transpose":
            kwargs["transpose_axes"] = kwargs.pop("permute_axes")
        else:
            raise NotImplementedError
        self.opinstance = getattr(module, moduleinfo[1])(layer_name, device, **kwargs)

    def get_attributes_check(self):
        optype = [slot for slot in self.__slots__ if getattr(self, slot) != ()]
        if len(optype) == 1:
            return optype[0]
        elif len(optype) == 0:
            return "identity"
        else:
            raise ValueError("multiple option in device bridge operation.")

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return self.opinstance._predict(input_, **kwargs)

    def get_ops(self):
        return self.opinstance.get_ops()
