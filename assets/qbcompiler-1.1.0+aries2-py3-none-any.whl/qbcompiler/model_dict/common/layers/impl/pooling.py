import torch
import torch.nn.functional as F

from qbcompiler.model_dict.common.dataformat import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatSupportedGroup,
)


@register.layer
class Pooling(LayerABC, SingleInputMixin, DataFormatSupportedGroup):
    __slots__ = (
        "pool_type",
        "west_padding",
        "east_padding",
        "south_padding",
        "north_padding",
        "pad_mode",
        "is_include_pad",
        "h_kernel",
        "w_kernel",
        "h_stride",
        "w_stride",
    )

    def _pad_input(self, x, pad_const_value=0):
        paddings_ = (
            self.west_padding,
            self.east_padding,
            self.south_padding,
            self.north_padding,
        )
        if self.pad_mode == "constant":
            return torch.nn.ConstantPad2d(paddings_, pad_const_value)(x)
        elif self.pad_mode == "reflect":
            return torch.nn.ReflectionPad2d(paddings_)(x)
        elif self.pad_mode == "-inf":
            return torch.nn.ConstantPad2d(paddings_, float("-inf"))(x)
        raise NotImplementedError(f"Unknown pad mode: {self.pad_mode}")

    def _avgpool(self, x):
        # if not hasattr(self, "is_include_pad"):
        #     self.is_include_pad = False
        if self.is_include_pad:
            if self.pad_mode == "-inf":
                raise ValueError("pad_mode cannot be -inf in avgpool")
            x = self._pad_input(x)
            return F.avg_pool2d(
                x.to(self.device),
                kernel_size=(self.h_kernel, self.w_kernel),
                stride=(self.h_stride, self.w_stride),
                padding=0,
            )
        else:
            max_pad_h = max(self.south_padding, self.north_padding)
            max_pad_w = max(self.east_padding, self.west_padding)
            x = F.avg_pool2d(
                x.to(self.device),
                kernel_size=(self.h_kernel, self.w_kernel),
                stride=(1, 1),
                padding=(max_pad_h, max_pad_w),
                count_include_pad=False,
            )
            start_h = max(0, self.north_padding - self.south_padding)
            start_w = max(0, self.east_padding - self.west_padding)
            return x[:, :, start_h :: self.h_stride, start_w :: self.w_stride]

    def _maxpool(self, x):
        if self.pad_mode == "constant":
            x = self._pad_input(x, 0)
        elif self.pad_mode == "-inf":
            x = self._pad_input(x, float("-inf"))
        return F.max_pool2d(
            x,
            kernel_size=(self.h_kernel, self.w_kernel),
            stride=(self.h_stride, self.w_stride),
            padding=0,
        )

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if self.channel_last:
            x = input_.permute(0, 3, 1, 2)
            if self.pool_type == "AvgPool":
                x = self._avgpool(x)
            elif self.pool_type == "MaxPool":
                x = self._maxpool(x)
            else:
                raise NotImplementedError(f"Unknown pool type: {self.pool_type}")
            return x.permute(0, 2, 3, 1)
        else:
            if self.pool_type == "AvgPool":
                return self._avgpool(x)
            elif self.pool_type == "MaxPool":
                return self._maxpool(x)
            else:
                raise NotImplementedError(f"Unknown pool type: {self.pool_type}")

    def get_ops(self):
        output_shape = [int(shape) for shape in self.outputs[0].shape]
        if self.pool_type == "MaxPool":
            return (
                (self.w_kernel * self.h_kernel - 1)
                * output_shape[0]
                * output_shape[1]
                * output_shape[2]
            )
        elif self.pool_type == "AvgPool":
            return (
                (2 * self.w_kernel * self.h_kernel - 1)
                * output_shape[0]
                * output_shape[1]
                * output_shape[2]
            )
        else:
            return 0
