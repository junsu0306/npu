import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class OrderedPatchify(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        h_kernel = int(self.h_kernel)
        w_kernel = int(self.w_kernel)
        if self.order == 0:
            n, h, w, c = input_.shape
            grid_h = h // h_kernel
            grid_w = w // w_kernel
            return (
                input_.reshape(n, grid_h, h_kernel, grid_w, w_kernel, c)
                .permute(0, 1, 3, 2, 4, 5)
                .reshape(1, grid_h * grid_w, h_kernel * w_kernel, -1)
            )
        elif self.order == 1:
            n, h, w, c = input_.shape
            grid_h = h // h_kernel
            grid_w = w // w_kernel
            return (
                input_.reshape(n, grid_h, h_kernel, grid_w, w_kernel, c)
                .permute(0, 2, 4, 1, 3, 5)
                .reshape(1, h_kernel * w_kernel, grid_h * grid_w, -1)
            )
        elif self.order == 2:
            n, h, w, c = input_.shape
            grid_h = h // h_kernel
            grid_w = w // w_kernel
            return (
                input_.reshape(n, grid_h, h_kernel, grid_w, w_kernel, c)
                .permute(0, 3, 1, 4, 2, 5)
                .reshape(1, grid_h * grid_w, h_kernel * w_kernel, -1)
            )
        else:
            raise NotImplementedError

    def get_ops(self):
        return 0
