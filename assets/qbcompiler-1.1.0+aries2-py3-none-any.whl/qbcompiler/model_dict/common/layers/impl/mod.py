import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class Mod(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("is_const_first", "constant", "fmod")

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if self.is_const_first:
            return self._kernel(self.constant, input_)
        else:
            return self._kernel(input_, self.constant)

    def _kernel(self, left, right):
        if self.fmod:
            return torch.fmod(left.to(self.device), right.to(self.device))
        return torch.remainder(left.to(self.device), right.to(self.device))

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 3 * get_total_num_elements(output_act.src_shape)

    def folding_fwd(self, input_, **kwargs) -> torch.Tensor:
        return self._predict(input_, **kwargs)


@register.layer
class ModV2(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("fmod",)

    def _predict(self, left, right):
        if self.fmod:
            return torch.fmod(left.to(self.device), right.to(self.device))
        return torch.remainder(left.to(self.device), right.to(self.device))

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 3 * get_total_num_elements(output_act.src_shape)
