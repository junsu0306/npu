import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.dataformat import DataFormat
from qbcompiler.model_dict.common.tensor import WrappedTensor
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    DataFormatGeneric,
)


@register.layer
class ScalarInt(LayerABC, DataFormatGeneric):
    def __call__(self, *args, **kwargs):
        out = self._predict()
        return WrappedTensor(
            out,
            dtype=str(out.dtype).split(".")[-1],
            dataformat=DataFormat.UNKNOWN,
        )

    def _predict(self, *args, **kwargs) -> torch.Tensor:
        return self.value

    def get_ops(self):
        return 0
