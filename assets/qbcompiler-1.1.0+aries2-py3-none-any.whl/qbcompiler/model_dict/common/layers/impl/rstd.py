import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class Rstd(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        num_groups = self.num_groups
        if self.reduce_axes == (1, 2, 3):
            assert 4 == len(input_.shape)
            if num_groups == 1:
                x = input_.var(dim=(-1, -2, -3), keepdim=True, unbiased=False)
            else:
                c = int(input_.shape[-1] // num_groups)
                res = []
                for input_i in torch.split(input_, c, dim=-1):
                    x = input_i.var(dim=(-1, -2, -3), keepdim=True, unbiased=False)
                    res.append(x)
                x = torch.cat(res, dim=-1)
            return torch.rsqrt(x + self.epsilon)
        else:
            raise NotImplementedError(f"Not implemented {self.reduce_axes}")

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 2 * get_total_num_elements(output_act.src_shape)
