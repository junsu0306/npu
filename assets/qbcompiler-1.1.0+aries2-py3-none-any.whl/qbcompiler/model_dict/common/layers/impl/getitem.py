import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class GetItem(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("sel",)

    def get_ops(self):
        return 0

    def _predict(self, input0: torch.Tensor, **kwargs) -> torch.Tensor:
        return input0.to(self.device).__getitem__(self.sel)

    def folding_fwd(self, input_, **kwargs) -> torch.Tensor:
        return self._predict(input_, **kwargs)
