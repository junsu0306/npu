from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    SingleInputMixin,
    LayerABC,
    DataFormatGeneric,
)


@register.layer
class Output(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_, **kwargs):
        return input_

    def get_ops(self):
        return 0
