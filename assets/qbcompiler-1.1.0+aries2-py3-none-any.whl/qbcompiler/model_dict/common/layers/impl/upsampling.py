import torch
import torch.nn.functional as F

from qbcompiler.model_dict.common.dataformat import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    SingleInputMixin,
    LayerABC,
    DataFormatGeneric,
)


@register.layer
class Upsampling(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("up_mode", "scales")

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        inact = self.inputs[0]
        outact = self.outputs[0]

        in_shape = inact.src_shape
        out_shape = outact.src_shape

        if (
            len(in_shape) == len(out_shape) == 4
            and in_shape[0] == out_shape[0]
            and in_shape[3] == out_shape[3]
            and in_shape[1:3] != out_shape[1:3]
        ):
            input_ = input_.permute(0, 3, 1, 2)
            if len(self.scales) != 4:
                raise NotImplementedError
            torch_scale = (
                self.scales[1],
                self.scales[2],
            )  # only getting height and width scales
            output_h, output_w, output_c = [
                int(shape) for shape in self.outputs[0].shape
            ]
            if self.up_mode == "linear":
                return F.interpolate(
                    input_.to(self.device), mode="bilinear", size=(output_h, output_w)
                ).permute(0, 2, 3, 1)
            elif self.up_mode == "nearest":
                return F.interpolate(
                    input_.to(self.device), mode="nearest", size=(output_h, output_w)
                ).permute(0, 2, 3, 1)
            else:
                raise NotImplementedError
        else:
            raise NotImplementedError

    def get_ops(self):
        input_shape = [int(shape) for shape in self.inputs[0].shape]
        output_shape = [int(shape) for shape in self.outputs[0].shape]
        return (
            (
                2
                * (output_shape[0] / input_shape[0] + 1)
                * (2 * output_shape[1] / input_shape[1] + 1)
                - 1
            )
            * output_shape[0]
            * output_shape[1]
            * output_shape[2]
        )
