from qbcompiler.model_dict.common import ActivationSpec
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    SingleInputMixin,
    LayerABC,
    DataFormatGeneric,
)
import torch


def is_supported_shape(inact: ActivationSpec):
    """
    input shape HWC has valid values or src_shape is supported shape(NHWC)
    """
    return (-1 not in inact.shape) or (
        len(inact.src_shape) == 4 and inact.src_shape[0] == 1
    )


def get_act_shape_as_supported(inact: ActivationSpec):
    """
    returns act shape as if it is input to supported layer.
    returns None if not
    """
    if is_supported_shape(inact):
        return inact.shape if -1 not in inact.shape else inact.shape[1:]
    return None


@register.layer
class GemmConstant(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict_NC(self, input_):
        # Y = alpha * A’ * B’ + beta * C,
        if self.transA:
            raise NotImplementedError
        if len(self.constant.shape) != 2:
            raise ValueError
        A = input_
        B = self.constant.permute(1, 0) if self.transB else self.constant
        C = self.bias
        if C is None:
            return self.alpha * torch.matmul(A, B)
        return self.alpha * torch.matmul(A, B) + self.beta * C

    def _predict_NC_const_first(self, input_):
        if self.transB:
            raise NotImplementedError
        A = self.constant.permute(1, 0) if self.transA else self.constant
        B = input_
        C = self.bias
        if C is None:
            return self.alpha * torch.matmul(A, B)
        return self.alpha * torch.matmul(A, B) + self.beta * C

    def _predict_HWC(self, input_):
        if self.transA or self.transB:
            raise NotImplementedError
        A = input_
        B = self.constant
        C = self.bias
        if C is None:
            return self.alpha * torch.matmul(A, B)
        return self.alpha * torch.matmul(A, B) + self.beta * C

    def _predict_common(self, input_):
        if self.is_const_first:
            A = self.constant
            B = input_
        else:
            A = input_
            B = self.constant
        A = A.permute(1, 0) if self.transA else A
        B = B.permute(1, 0) if self.transB else B
        C = self.bias
        if C is not None:
            return self.alpha * torch.matmul(A, B) + self.beta * C
        else:
            return self.alpha * torch.matmul(A, B)

    def _predict(self, input_, **kwargs):
        return self._predict_common(input_)

    def get_ops(self):
        return 0
