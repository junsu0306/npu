from typing import Tuple
import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    MultiInputsMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class Range(LayerABC, MultiInputsMixin, DataFormatGeneric):
    __slots__ = ("start", "limit", "delta")

    def _predict(self, inputs: Tuple[torch.Tensor], **kwargs) -> torch.Tensor:
        params = [self.start, self.limit, self.delta]
        names = ["start", "limit", "delta"]

        in_iter = iter(inputs)
        resolved = []

        for name, p in zip(names, params):
            if p is None:
                try:
                    t = next(in_iter)
                except StopIteration as e:
                    raise ValueError(
                        f"Range._predict: '{name}' is None but not enough inputs. "
                        f"Need {sum(x is None for x in params)} inputs."
                    ) from e
                resolved.append(t)
            else:
                resolved.append(p)

        try:
            extra = next(in_iter)
            raise ValueError(
                f"Range._predict: too many inputs. Unused extra input with shape {tuple(extra.shape)}."
            )
        except StopIteration:
            pass

        start_t, limit_t, delta_t = resolved

        def _align(t: torch.Tensor) -> torch.Tensor:
            return t.to(device=self.device)

        start_t = _align(start_t)
        limit_t = _align(limit_t)
        delta_t = _align(delta_t)

        def _scalar(name: str, t: torch.Tensor):
            if t.numel() != 1:
                raise ValueError(
                    f"Range._predict: '{name}' must be a scalar tensor (numel==1), got shape {tuple(t.shape)}."
                )
            return t.reshape(()).item()

        s = _scalar("start", start_t)
        e = _scalar("limit", limit_t)
        d = _scalar("delta", delta_t)

        if d == 0:
            raise ValueError("Range._predict: delta must be non-zero.")

        return torch.arange(s, e, d, device=self.device)

    def get_ops(self):
        output_act = self.outputs[0]
        return get_total_num_elements(output_act.src_shape)
