import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class Ones(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("dtype",)

    def _predict(self, *args, **kwargs) -> torch.Tensor:
        shape = tuple(int(x) for x in args[0])
        if self.dtype == "float32":
            dt = torch.float32
        else:
            raise NotImplementedError
        return torch.ones(shape, dtype=dt).to(self.device)

    def get_ops(self):
        return 0
