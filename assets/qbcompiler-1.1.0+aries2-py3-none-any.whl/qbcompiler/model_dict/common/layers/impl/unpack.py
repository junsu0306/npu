import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    SingleInputMixin,
    LayerABC,
    DataFormatGeneric,
)


@register.layer
class Unpack(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_, **kwargs):
        in_shape = input_.shape
        if in_shape[self.axis] != self.num:
            raise NotImplementedError
        return [
            torch.index_select(input_, self.axis, torch.tensor(i)).squeeze(self.axis)
            for i in range(self.num)
        ]

    def get_ops(self):
        return 0
