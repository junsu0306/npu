from typing import Tuple

import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    MultiInputsMixin,
    DataFormatGeneric,
)


@register.layer
class LSTM(LayerABC, MultiInputsMixin, DataFormatGeneric):
    def _predict_forward(
        self, inputs: Tuple[torch.Tensor, ...], **kwargs
    ) -> torch.Tensor:
        initial_h = initial_c = None
        if self.input_mask == "ihc":
            X, initial_h, initial_c = inputs
        else:
            raise NotImplementedError(f"input_mask:{self.input_mask}")
        # it = f(Xt * (Wi ^ T) + Ht - 1 * (Ri ^ T) + Pi(.)
        # Ct - 1 + Wbi + Rbi)
        seq_len, batch_size, input_size = X.shape
        hidden_size = self.hidden_size

        num_directions = 1
        P = self.P
        if P is None:
            P = torch.zeros(size=(num_directions, 3 * hidden_size))
        pi, po, pf = torch.split(P, [hidden_size] * 3, dim=-1)

        Ht, Ct = initial_h, initial_c
        if Ht is None:
            Ht = torch.zeros(size=(num_directions, batch_size, hidden_size))
        if Ct is None:
            Ct = torch.zeros(size=(num_directions, batch_size, hidden_size))

        W = torch.transpose(self.W, 2, 1)
        R = torch.transpose(self.R, 2, 1)

        B = self.B
        if B is None:
            B = torch.zeros(size=(num_directions, 8 * hidden_size))
        Wb, Rb = torch.split(B, [hidden_size * 4] * 2, dim=-1)

        act_f = torch.sigmoid
        act_g = torch.tanh
        act_h = torch.tanh
        hts = []
        for Xt in X:
            gates = torch.matmul(Xt, W) + torch.matmul(Ht, R) + Wb + Rb
            i, o, f, c = torch.split(gates, [hidden_size] * 4, dim=-1)
            Ct = act_f(f + pf * Ct) * Ct + act_f(i + pi * Ct) * act_g(c)
            Ht = act_f(o + po * Ct) * act_h(Ct)
            hts.append(Ht)

        Y = torch.stack(hts)
        if self.batch_first:
            Y = torch.permute(Y, [2, 0, 1, 3])

        if self.output_mask == "o":
            return Y
        if self.output_mask == "h":
            return Ht
        if self.output_mask == "c":
            return Ct
        raise Exception("code should not be reached!")

    def _predict_bidirectional(
        self, inputs: Tuple[torch.Tensor, ...], **kwargs
    ) -> torch.Tensor:
        initial_h = initial_c = None
        if self.input_mask == "ihc":
            X, initial_h, initial_c = inputs
        else:
            raise NotImplementedError(f"input_mask:{self.input_mask}")
        # it = f( Xt * (Wi ^ T) + Ht_1 * (Ri ^ T) + Pi(.)Ct_1 + Wbi + Rbi )
        seq_len, batch_size, input_size = X.shape
        hidden_size = self.hidden_size

        num_directions = 2
        P = self.P
        if P is None:
            P = torch.zeros(size=(num_directions, 3 * hidden_size))
        pi, po, pf = torch.split(P, [hidden_size] * 3, dim=-1)

        Ht, Ct = initial_h, initial_c
        if Ht is None:
            Ht = torch.zeros(size=(num_directions, batch_size, hidden_size))
        if Ct is None:
            Ct = torch.zeros(size=(num_directions, batch_size, hidden_size))

        W = torch.transpose(self.W, 2, 1)
        R = torch.transpose(self.R, 2, 1)

        B = self.B
        if B is None:
            B = torch.zeros(size=(num_directions, 8 * hidden_size))
        Wb, Rb = torch.split(B, [hidden_size * 4] * 2, dim=-1)

        act_f = torch.sigmoid
        act_g = torch.tanh
        act_h = torch.tanh

        def data_iter(X, d):
            if d == 0:
                for idx, Xt in enumerate(X):
                    yield idx, Xt
            elif d == 1:
                for idx, Xt in zip(reversed(range(seq_len)), reversed(X)):
                    yield idx, Xt

        Y = torch.zeros(size=(seq_len, num_directions, batch_size, hidden_size))
        for d in range(num_directions):
            for i_seq, Xt in data_iter(X, d):
                gates = (
                    torch.matmul(Xt, W[d : d + 1, ...])
                    + torch.matmul(Ht[d : d + 1, ...], R[d : d + 1, ...])
                    + Wb[d : d + 1, ...]
                    + Rb[d : d + 1, ...]
                )
                i, o, f, c = torch.split(gates, [hidden_size] * 4, dim=-1)
                Ctd = Ct[d : d + 1, ...]
                Ctd = act_f(f + pf[d : d + 1, ...] * Ctd) * Ctd + act_f(
                    i + pi[d : d + 1, ...] * Ctd
                ) * act_g(c)
                Htd = act_f(o + po[d : d + 1, ...] * Ctd) * act_h(Ctd)
                Ct[d, ...] = Ctd
                Ht[d, ...] = Htd
                Y[i_seq : i_seq + 1, d : d + 1, ...] = Htd

        if self.batch_first:
            Y = torch.permute(Y, [2, 0, 1, 3])

        if self.output_mask == "o":
            return Y
        if self.output_mask == "h":
            return Ht
        if self.output_mask == "c":
            return Ct
        raise Exception("code should not be reached!")

    def _predict(self, inputs: Tuple[torch.Tensor, ...], **kwargs) -> torch.Tensor:
        if self.direction == "forward":
            return self._predict_forward(inputs, **kwargs)
        if self.direction == "bidirectional":
            return self._predict_bidirectional(inputs, **kwargs)
        raise NotImplementedError()

    def get_ops(self):
        return 0
