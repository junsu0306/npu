import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class Roll(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ["shifts", "dims"]

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return torch.roll(input_, shifts=self.shifts, dims=self.dims)

    def get_ops(self):
        return 0
