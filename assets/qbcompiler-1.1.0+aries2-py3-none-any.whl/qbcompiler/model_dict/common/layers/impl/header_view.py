from typing import List

import torch

from qbcompiler.model_dict.common import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    SingleInputMixin,
    LayerABC,
    DataFormatGeneric,
)


@register.reshape
class HeaderView(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("view_shape",)

    def get_ops(self):
        return 0

    def _predict(
        self, input_: torch.Tensor, dataformat: DataFormat, **kwargs
    ) -> torch.Tensor:
        if self.batch_order == 0:
            axes = (0, 1, 3, 2, 4)
        elif self.batch_order == 1:
            axes = (0, 3, 1, 2, 4)
        else:
            raise ValueError
        if self.num_heads == -1:
            num_heads = input_.shape[3] // self.view_shape[3]
        else:
            num_heads = self.num_heads
        # (1,1,4096,24*64)->(1,4096,24,64)->(1,24,4096,64)
        n, h, w, c = input_.shape
        return (
            input_.to(self.device)
            .reshape((n, h, w, num_heads, c // num_heads))
            .permute(*axes)
            .reshape((n, h * num_heads, w, c // num_heads))
        )


@register.reshape
class HeaderViewRevert(LayerABC, SingleInputMixin, DataFormatGeneric):
    def get_ops(self):
        return 0

    def _predict(
        self, input_: torch.Tensor, dataformat: DataFormat, **kwargs
    ) -> torch.Tensor:
        n, h, w, c = input_.shape
        if self.num_heads != -1:
            num_heads = self.num_heads
        else:
            num_heads = int(h // self.revert_shape[1])
        if self.batch_order == 0:
            axes = (0, 1, 3, 2, 4)
            shape0 = (n, h // num_heads, num_heads, w, c)
        else:
            axes = (0, 2, 3, 1, 4)
            shape0 = (n, num_heads, h // num_heads, w, c)
        return (
            input_.to(self.device)
            .reshape(shape0)
            .permute(*axes)
            .reshape((n, h // num_heads, w, c * num_heads))
        )
