import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)

import functools
import operator


@register.reshape
class Flatten(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if not self.is_npu:
            pre = functools.reduce(operator.mul, input_.shape[: self.axis], 1)
            return input_.to(self.device).reshape(pre, -1)
        raise NotImplementedError

    def get_ops(self):
        return 0
