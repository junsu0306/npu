import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    BiInputsMixin,
    DataFormatGeneric,
)


@register.reshape
class NonMaxSuppression(LayerABC, BiInputsMixin, DataFormatGeneric):
    __slot__ = (
        "max_output_size",
        "iou_threshold",
        "score_threshold",
        "soft_nms_sigma",
        "pad_to_max_output_size",
        "center_point_box",
    )

    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        boxes = input0
        scores = input1

        if bool(self.center_point_box):
            self.boxes_to_center(boxes)
        boxes, scores = self.box_scores_format_fix_from_tf(boxes, scores)
        batch_size = scores.shape[0]
        num_class = scores.shape[1]

        selected_indices = []

        for i in range(batch_size):
            for j in range(num_class):
                cls_score = scores[i, j]
                cls_box = boxes[i, :, :]
                map_indices = {i: i for i in range(cls_score.shape[0])}
                if self.score_threshold is not None:
                    index = scores[i][j] > self.score_threshold
                    if index.sum() == 0:
                        continue
                    cls_score = scores[i, j][index]
                    cls_box = boxes[i, index, :]
                    map_indices = {
                        i: idx.item() for i, idx in enumerate(torch.nonzero(index))
                    }

                x1, y1, x2, y2 = (
                    cls_box[:, 0],
                    cls_box[:, 1],
                    cls_box[:, 2],
                    cls_box[:, 3],
                )
                area = torch.mul(abs(x2 - x1), abs(y2 - y1))

                v, idx = cls_score.sort(0, descending=True)
                idx = idx[: v.shape[0]]

                cls_indices = []
                while idx.numel() > 0:
                    k = idx[0].item()

                    if cls_score[k] <= 0:
                        break

                    cls_indices.append([i, j, map_indices[k]])

                    if idx.numel() == 1:
                        break

                    if len(cls_indices) >= self.max_output_size:
                        break

                    idx = idx[1:]
                    xx1 = torch.clamp(x1[idx], min=x1[k])
                    yy1 = torch.clamp(y1[idx], min=y1[k])
                    xx2 = torch.clamp(x2[idx], max=x2[k])
                    yy2 = torch.clamp(y2[idx], max=y2[k])

                    w = torch.clamp(xx2 - xx1, min=0)
                    h = torch.clamp(yy2 - yy1, min=0)

                    inter = w * h
                    ovr = inter / (area[k] + area[idx] - inter)

                    idx = idx[ovr <= self.iou_threshold]

                selected_indices += cls_indices

        return torch.Tensor(selected_indices).to(boxes)

    def box_scores_format_fix_from_tf(self, boxes, scores):
        if boxes.ndim == 2 and scores.ndim == 1:
            # TF's NMS input shape is different with ONNX's.
            boxes = boxes.unsqueeze(
                0
            )  # (numbox, 4) -> (1, numbox, 4): assume single batch
            scores = scores.reshape(
                1, 1, -1
            )  # (numbox,) -> (1, 1, numbox): assume single batch and single class
        return boxes, scores

    def boxes_to_center(self, boxes):
        boxes[:, :, 0] = boxes[:, :, 0] - boxes[:, :, 2] * 0.5
        boxes[:, :, 1] = boxes[:, :, 1] - boxes[:, :, 3] * 0.5
        boxes[:, :, 2] = boxes[:, :, 0] + boxes[:, :, 2]
        boxes[:, :, 3] = boxes[:, :, 1] + boxes[:, :, 3]

    def get_ops(self):
        return 0
