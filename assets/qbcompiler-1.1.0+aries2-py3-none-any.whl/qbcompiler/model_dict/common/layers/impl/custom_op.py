from typing import Tuple

import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    BiInputsMixin,
    SingleInputMixin,
    MultiInputsMixin,
    DataFormatGeneric,
)


@register.layer
class CustomSingleOp(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("custom_fn",)

    def get_ops(self):
        return 0

    def _predict(self, input0: torch.Tensor, **kwargs) -> torch.Tensor:
        return self.custom_fn(input0.to(self.device))


@register.layer
class CustomBiOp(LayerABC, BiInputsMixin, DataFormatGeneric):
    __slots__ = ("custom_fn",)

    def get_ops(self):
        return 0

    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        return self.custom_fn(input0.to(self.device), input1.to(self.device))


@register.layer
class CustomOp(LayerABC, MultiInputsMixin, DataFormatGeneric):
    __slots__ = ("custom_fn",)

    def get_ops(self):
        return 0

    def _predict(self, inputs: Tuple[torch.Tensor, ...], **kwargs) -> torch.Tensor:
        if self.custom_fn is None:
            raise ValueError
        return self.custom_fn(*tuple(x.to(self.device) for x in inputs))
