from typing import Tuple

import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    MultiInputsMixin,
    DataFormatGeneric,
)


@register.layer
class Where(LayerABC, MultiInputsMixin, DataFormatGeneric):
    __slots__ = ("axis", "constant", "largest", "sorted")

    def _predict(self, inputs: Tuple[torch.Tensor, ...], **kwargs) -> torch.Tensor:
        if len(inputs) == 1:
            if self.condition_const is None:
                return torch.where(
                    inputs[0].to(self.device), self.X_const, self.Y_const
                )
        elif len(inputs) == 2:
            return torch.where(inputs[0].to(self.device), inputs[1], self.Y_const)

        elif len(inputs) == 3:
            return torch.where(inputs[0].bool(), *inputs[1:])
        else:
            raise NotImplementedError(f"len(inputs)={len(inputs)}")

    def get_ops(self):
        return 0
