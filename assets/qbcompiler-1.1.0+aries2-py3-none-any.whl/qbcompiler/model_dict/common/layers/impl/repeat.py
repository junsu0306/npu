import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    SingleInputMixin,
    LayerABC,
    DataFormatGeneric,
)


@register.layer
class Repeat(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("repeats",)

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return input_.repeat(*self.repeats)

    def get_ops(self):
        return 0
