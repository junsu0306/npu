from numbers import Number

import torch
import torch.nn.functional as F
from qbcompiler.model_dict.common.dataformat import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatSupportedGroup,
)


@register.layer
class TransposeConvolution(LayerABC, SingleInputMixin, DataFormatSupportedGroup):
    __slots__ = (
        "west_padding",
        "east_padding",
        "south_padding",
        "north_padding",
        "pad_value",
        "h_dilation",
        "w_dilation",
        "h_kernel",
        "w_kernel",
        "in_channels",
        "out_channels",
        "h_stride",
        "w_stride",
        "group_number",
        "weight",
        "bias",
    )

    def _pad_input(self, x):
        paddings = (
            self.west_padding,
            self.east_padding,
            self.south_padding,
            self.north_padding,
        )
        if hasattr(self, "pad_value"):
            if isinstance(self.pad_value, Number):
                temp_bias = torch.full(
                    (self.in_channels,), self.pad_value, device=self.device
                )
            elif isinstance(self.pad_value, torch.Tensor):
                temp_bias = self.pad_value.to(self.device)
            else:
                raise NotImplementedError(
                    f"unsupported pad value type: {type(self.pad_value)} at layer: {self.layer_name}"
                )

            x = x.to(self.device) - temp_bias.reshape(1, -1, 1, 1)
            x = torch.nn.ConstantPad2d(paddings, 0).to(self.device)(x)
            x += temp_bias.reshape(1, -1, 1, 1)
        else:
            x = torch.nn.ConstantPad2d(paddings, 0).to(self.device)(x)
        return x

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if self.channel_last:
            perm0 = (0, 3, 1, 2)
            perm1 = (0, 2, 3, 1)
            input_ = input_.permute(*perm0)
            b, c, h, w = input_.shape

            x = torch.zeros(
                b,
                self.in_channels,
                (h - 1) * self.h_stride + 1,
                (w - 1) * self.w_stride + 1,
                device=self.device,
                dtype=input_.dtype,
            )
            x[:, :, :: self.h_stride, :: self.w_stride] = input_.to(self.device)

            x = self._pad_input(x)
            if self.bias is not None:
                bias = self.bias.to(self.device)
            else:
                bias = self.bias
            return F.conv2d(
                input=x.to(self.weight),
                weight=self.weight.to(self.device),
                bias=bias,
                stride=(1, 1),
                padding=0,
                dilation=(self.h_dilation, self.w_dilation),
                groups=1,
            ).permute(*perm1)
        else:
            b, c, h, w = input_.shape

            x = torch.zeros(
                b,
                self.in_channels,
                (h - 1) * self.h_stride + 1,
                (w - 1) * self.w_stride + 1,
                device=self.device,
                dtype=input_.dtype,
            )
            x[:, :, :: self.h_stride, :: self.w_stride] = input_.to(self.device)

            x = self._pad_input(x)
            if self.bias is not None:
                bias = self.bias.to(self.device)
            else:
                bias = self.bias
            return F.conv2d(
                input=x.to(self.weight),
                weight=self.weight.to(self.device),
                bias=bias,
                stride=(1, 1),
                padding=0,
                dilation=(self.h_dilation, self.w_dilation),
                groups=1,
            )

    def get_ops(self):
        output_shape = [int(shape) for shape in self.outputs[0].shape]
        return (
            (2 * self.in_channels * self.h_kernel * self.w_kernel - 1)
            * output_shape[0]
            * output_shape[1]
            * output_shape[2]
        )
