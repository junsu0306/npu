import numpy
import torch


from qbcompiler.model_dict.common.dataformat import (
    DataFormat,
)
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class Expand(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(
        self, input_: torch.Tensor, dataformat: DataFormat, **kwargs
    ) -> torch.Tensor:
        if isinstance(self.constant, torch.Tensor):
            try:
                input_src_shape = self.inputs[0].get_act_src_shape()
                output_src_shape = self.outputs[0].get_act_src_shape()
                if (
                    5 == len(input_src_shape) == len(output_src_shape)
                    and input_src_shape[:2]
                    == output_src_shape[:2]
                    == tuple(int(x) for x in self.constant[:2])
                    and input_src_shape[3:]
                    == output_src_shape[3:]
                    == tuple(int(x) for x in self.constant[3:])
                    and input_src_shape[3].dynamic
                    and output_src_shape[3].dynamic
                    and input_src_shape[2] != output_src_shape[2]
                ):
                    expand_shape = [int(x) for x in input_.shape]
                    expand_shape[2] = int(self.constant[2])
                    return input_.to(self.device).expand(expand_shape)
                else:
                    return input_.to(self.device).expand(
                        [int(x) for x in self.constant]
                    )
            except RuntimeError as e:
                x = input_.detach().cpu().numpy()
                shape_ = self.constant.detach().cpu().numpy()
                return torch.from_numpy(x * numpy.ones(shape_)).to(self.device)
        return input_.to(self.device).expand(self.constant)

    def get_ops(self):
        return 0

    def folding_fwd(self, input_):
        if not self.is_const_first:
            return input_.to(self.device).expand([int(x) for x in self.constant])
        else:
            return self.constant.to(self.device).expand([int(x) for x in input_])
