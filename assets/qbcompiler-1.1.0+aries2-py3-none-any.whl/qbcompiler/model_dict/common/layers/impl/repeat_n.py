import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class RepeatN(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("axis", "repeat")

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        # n_repeat_dims = list(x for x in input_.shape)
        n, h, w, c = input_.shape
        unsqz_dim = self.axis + 1
        expand_shape = (
            input_.shape[:unsqz_dim] + (self.repeat,) + input_.shape[unsqz_dim:]
        )
        reshape_shape = list(input_.shape)
        reshape_shape[self.axis] *= self.repeat
        reshape_shape = tuple(reshape_shape)
        return input_.unsqueeze(unsqz_dim).expand(*expand_shape).reshape(*reshape_shape)

    def get_ops(self) -> torch.Tensor:
        return 0
