import abc

import torch
import torch.nn.functional as F

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


class ActivationFunction(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return self._kernel(input_.to(self.device))

    def get_ops(self):
        return 0

    @abc.abstractmethod
    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        ...


@register.actfunc
class Relu(ActivationFunction, DataFormatGeneric):
    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return F.relu(input_)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)


@register.actfunc
class Selu(ActivationFunction, DataFormatGeneric):
    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return F.selu(input_)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)


@register.actfunc
class Hardtanh(ActivationFunction, DataFormatGeneric):
    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return F.hardtanh(input_, min_val=self.min_val, max_val=self.max_val)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)


@register.actfunc
class Celu(ActivationFunction, DataFormatGeneric):
    __slots__ = ("alpha",)

    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return F.celu(input_, self.alpha)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)


@register.actfunc
class Erf(ActivationFunction, DataFormatGeneric):
    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return torch.erf(input_)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)


@register.actfunc
class LeakyRelu(ActivationFunction, DataFormatGeneric):
    __slots__ = ("leaky_alpha",)

    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return F.leaky_relu(input_, self.leaky_alpha)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 2 * get_total_num_elements(output_act.src_shape)


@register.actfunc
class PRelu(ActivationFunction, DataFormatGeneric):
    __slots__ = ("leaky_alpha",)

    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return F.prelu(input_, self.leaky_alpha)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 2 * get_total_num_elements(output_act.src_shape)


@register.actfunc
class Clip(ActivationFunction, DataFormatGeneric):
    __slots__ = ("clip_min_value", "clip_max_value")

    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return torch.clamp(input_, min=self.clip_min_value, max=self.clip_max_value)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 2 * get_total_num_elements(output_act.src_shape)


@register.actfunc
class Exp(ActivationFunction, DataFormatGeneric):
    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return torch.exp(input_)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)


@register.actfunc
class Softmax(ActivationFunction, DataFormatGeneric):
    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return F.softmax(input_, dim=self.axis)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 3 * get_total_num_elements(output_act.src_shape)


@register.actfunc
class Softplus(ActivationFunction, DataFormatGeneric):
    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return F.softplus(input_)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 4 * get_total_num_elements(output_act.src_shape)


@register.actfunc
class Sigmoid(ActivationFunction, DataFormatGeneric):
    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if self.alpha is None:
            return input_.sigmoid()
        else:
            return 1.0 / (1.0 + torch.exp(-self.alpha * input_))

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 4 * get_total_num_elements(output_act.src_shape)


@register.actfunc
class Pow(ActivationFunction, DataFormatGeneric):
    __slots__ = ("exponent",)

    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return input_.to(self.device).pow(self.exponent)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)


@register.actfunc
class Gelu(ActivationFunction, DataFormatGeneric):
    __slots__ = ("exponent",)

    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return F.gelu(input_.to(self.device))

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 11 * get_total_num_elements(output_act.src_shape)


@register.actfunc
class Elu(ActivationFunction, DataFormatGeneric):
    __slots__ = ("leaky_alpha",)

    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return F.elu(input_.to(self.device), alpha=self.leaky_alpha)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 4 * get_total_num_elements(output_act.src_shape)


@register.actfunc
class QuickGelu(ActivationFunction, DataFormatGeneric):
    __slots__ = ("exponent",)

    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return input_.to(self.device) * F.sigmoid(1.702 * input_.to(self.device))

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 11 * get_total_num_elements(output_act.src_shape)


@register.actfunc
class HardSwish(ActivationFunction, DataFormatGeneric):
    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        x = input_.to(self.device)
        return x * torch.clamp(x + 3, 0, 6) / 6

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 4 * get_total_num_elements(output_act.src_shape)


@register.actfunc
class HardSigmoid(ActivationFunction, DataFormatGeneric):
    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        x = input_.to(self.device)
        if self.alpha is not None:
            # note that below two methods can results in very different values if x > 6 and alpha=0.16667.
            if self.beta is None:
                y = F.relu6(x) * self.alpha
                return y
            else:
                y = torch.maximum(
                    torch.tensor(0.0),
                    torch.minimum(torch.tensor(1.0), self.alpha * x + self.beta),
                )
                return y
        return F.hardsigmoid(x)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 4 * get_total_num_elements(output_act.src_shape)


@register.actfunc
class Tanh(ActivationFunction, DataFormatGeneric):
    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return torch.tanh(input_.to(self.device))

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 5 * get_total_num_elements(output_act.src_shape)


@register.actfunc
class Swish(ActivationFunction, DataFormatGeneric):
    # __slots__ = ("alpha",)

    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        x = input_.to(self.device)
        # return x * F.sigmoid(self.alpha * x)
        return x * F.sigmoid(x)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 2 * get_total_num_elements(output_act.src_shape)


@register.actfunc
class Mish(ActivationFunction, DataFormatGeneric):
    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return F.mish(input_.to(self.device))

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 6 * get_total_num_elements(output_act.src_shape)


@register.actfunc
class Cos(ActivationFunction, DataFormatGeneric):
    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return torch.cos(input_.to(self.device))

    def get_ops(self):
        return 0


@register.actfunc
class Sin(ActivationFunction, DataFormatGeneric):
    def _kernel(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return torch.sin(input_.to(self.device))

    def get_ops(self):
        return 0
