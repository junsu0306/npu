import numpy
import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    SingleInputMixin,
    LayerABC,
    DataFormatGeneric,
)


def convert_onnx_pads_to_torch(onnx_pads: list) -> tuple:
    n = len(onnx_pads) // 2
    begins = onnx_pads[:n]
    ends = onnx_pads[n:]
    return tuple(v for pair in zip(reversed(begins), reversed(ends)) for v in pair)


@register.layer
class Pad(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict_unsupported(self, input_: torch.Tensor, **kwargs):
        rank = len(input_.shape)
        pad_width = [
            (x, y) for x, y in zip(self.padding_list[:rank], self.padding_list[rank:])
        ]
        if self.pad_mode in ["constant", "reflect"]:
            x = numpy.pad(
                input_.detach().cpu().numpy(),
                pad_width=pad_width,
                mode=self.pad_mode,
                constant_values=self.constant,
            )
            return torch.from_numpy(x)
        raise NotImplementedError

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if not self.is_npu:
            return self._predict_unsupported(input_, **kwargs)

        if self.pad_mode in ["constant", "reflect"]:
            # (padding_left, padding_right, padding_top, padding_bottom)
            # NPU's north, south is inversed
            # pad = [
            #     max(0, self.west_padding),
            #     max(0, self.east_padding),
            #     max(0, self.south_padding),
            #     max(0, self.north_padding),
            # ]
            pad = [
                self.west_padding,
                self.east_padding,
                self.south_padding,
                self.north_padding,
            ]
            perm0 = (0, 3, 1, 2)
            perm1 = (0, 2, 3, 1)
            x = input_.permute(*perm0)
            x = torch.nn.functional.pad(
                x.to(self.device), pad=pad, mode=self.pad_mode, value=self.constant
            )
            return x.permute(*perm1)
        else:
            raise NotImplementedError

    def get_ops(self):
        return 0


@register.layer
class Pad1d(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        torch_pad = convert_onnx_pads_to_torch(self.padding_list)
        if self.pad_mode in ["constant", "reflect"]:
            return torch.nn.functional.pad(
                input_.to(self.device),
                pad=torch_pad,
                mode=self.pad_mode,
                value=self.constant,
            )
        raise NotImplementedError

    def get_ops(self):
        return 0


@register.layer
class PadGeneric(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        torch_pad = convert_onnx_pads_to_torch(self.padding_list)
        if self.pad_mode in ["constant", "reflect"]:
            return torch.nn.functional.pad(
                input_.to(self.device),
                pad=torch_pad,
                mode=self.pad_mode,
                value=self.constant,
            )
        raise NotImplementedError

    def get_ops(self):
        return 0


@register.layer
class PadChannel(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if self.pad_mode in ["constant", "reflect"]:
            # (padding_left, padding_right, padding_top, padding_bottom)
            # NPU's north, south is inversed
            pad = [max(0, self.front_padding), max(0, self.back_padding)]
            x = torch.nn.functional.pad(
                input_.to(self.device), pad=pad, mode=self.pad_mode, value=self.constant
            )
            return x
        else:
            raise NotImplementedError

    def get_ops(self):
        return 0
