import torch
import torch.nn.functional as F

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import _DT_CAST
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class Batchnorm(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("gamma", "beta", "moving_mean", "moving_var", "epsilon")

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        dtype = _DT_CAST[self.outputs[0].dtype]
        if self.channel_last:
            inact_dim = self.inputs[0].src_dim
            if inact_dim != 4:
                raise ValueError("Batchnorm rule should be implemented")
            if self.channel_last:
                return (
                    F.batch_norm(
                        input=input_.to(dtype).permute(0, 3, 1, 2),
                        running_mean=self.moving_mean.to(dtype),
                        running_var=self.moving_var.to(dtype),
                        training=False,
                        weight=self.gamma.to(dtype),
                        bias=self.beta.to(dtype),
                        eps=float(self.epsilon),
                    )
                    .to(dtype)
                    .permute(0, 2, 3, 1)
                )
            else:
                return F.batch_norm(
                    input=input_.to(dtype),
                    running_mean=self.moving_mean.to(dtype),
                    running_var=self.moving_var.to(dtype),
                    training=False,
                    weight=self.gamma.to(dtype),
                    bias=self.beta.to(dtype),
                    eps=float(self.epsilon),
                ).to(dtype)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 2 * get_total_num_elements(output_act.src_shape)
