import abc

import torch
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    BiInputsMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


class Comparison(LayerABC, BiInputsMixin, DataFormatGeneric):
    __slots__ = ("is_const_first", "constant")

    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        if input1 is None:
            if self.is_const_first:
                return self._kernel(self.constant, input0)
            return self._kernel(input0, self.constant)
        else:
            return self._kernel(input0, input1)

    @abc.abstractmethod
    def _kernel(self, left: torch.Tensor, right: torch.Tensor) -> torch.Tensor:
        ...

    def get_ops(self):
        return 0


@register.layer
class Less(Comparison):
    def _kernel(self, left: torch.Tensor, right: torch.Tensor) -> torch.Tensor:
        return torch.less(left.to(self.device), right.to(self.device))

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 2 * get_total_num_elements(output_act.src_shape)


@register.layer
class Greater(Comparison):
    def _kernel(self, left: torch.Tensor, right: torch.Tensor) -> torch.Tensor:
        return torch.greater(left.to(self.device), right.to(self.device))

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 2 * get_total_num_elements(output_act.src_shape)


@register.layer
class Equal(Comparison):
    def _kernel(self, left: torch.Tensor, right: torch.Tensor) -> torch.Tensor:
        return left.to(self.device) == right.to(self.device)

    def get_ops(self):
        return 0


@register.layer
class LessThenOrEqual(Comparison):
    def _kernel(self, left: torch.Tensor, right: torch.Tensor) -> torch.Tensor:
        return torch.le(left.to(self.device), right.to(self.device))

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 2 * get_total_num_elements(output_act.src_shape)
