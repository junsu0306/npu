import torch

from qbcompiler.model_dict.common.dataformat import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)

# def _get_indexer(axis, start, end, step, len_):
#     lst = []
#     cnt = 0
#     for ax in range(len_):
#         if ax not in axis:
#             lst.append(Ellipsis)
#         else:
#             lst.append(numpy.s_[start[cnt] : end[cnt] : step[cnt]])
#             cnt += 1
#     return lst


def slice_tensor(
    data: torch.Tensor, starts, ends, axes=None, steps=None, output_src_shape=None
):
    if axes is None:
        axes = list(range(len(starts)))
    if steps is None:
        steps = [1] * len(starts)

    slices = [slice(None)] * data.ndimension()

    for start, end, axis, step in zip(starts, ends, axes, steps):
        if start < 0:
            start += data.size(axis)
        if end < 0:
            end += data.size(axis)
            # fix onnx bug
            if (end - start) // step != output_src_shape[axis]:
                end = start + (output_src_shape[axis]) * step
        if axis < 0:
            axis += data.ndimension()

        slices[axis] = slice(start, end, step)

    return data[tuple(slices)]


@register.reshape
class Slice(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        # for i, axis in enumerate(axis_list):
        #     axis_len = axis_len[axis]
        #     start = start_list[i]
        #     if start < 0: start = start + axis_len
        #     end = min(end_list[i], axis_len)
        #     if end < 0: end = end + axis_len
        #     # FIXME How to deal with cases when sliced size == 0
        #     if start == end:
        #         raise ValueError("Sliced size of dimension {} is 0.".format(axis))
        #     step = step_list[i] if step_list is not None else 1
        #     indices = torch.arange(start, end, step).to(output).long()
        #     output = output.index_select(axis, indices.long())

        # indexer = _get_indexer(
        #     self.axis, self.start, self.end, self.step, len(input_.shape)
        # )
        # permutator = tuple(range(len(indexer)))
        # if kwargs["dataformat"] == DataFormat.NCHW:
        #     permutator = channel_axis_permutator(DataFormat.NHWC)
        # if kwargs["dataformat"] == DataFormat.CHW:
        #     permutator = channel_axis_permutator(DataFormat.HWC)
        # indexer_p = tuple(indexer[p] for p in permutator)
        oact = self.outputs[0]
        oact_src_shape = oact.src_shape
        if oact.dataformat == DataFormat.NHWC:
            if oact_src_shape == (-1, -1, -1):
                oact_src_shape = (1,) + oact.shape

        return slice_tensor(
            input_,
            self.start,
            self.end,
            axes=self.axis,
            steps=self.step,
            output_src_shape=oact_src_shape,
        )

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)

    def folding_fwd(self, inputs_: torch.Tensor):
        return slice_tensor(
            inputs_,
            self.start,
            self.end,
            axes=self.axis,
            steps=self.step,
            output_src_shape=self.outputs[0].src_shape,
        )


@register.layer
class ChannelSlice(LayerABC, SingleInputMixin, DataFormatGeneric):
    def get_ops(self):
        return 0

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return input_.to(self.device)[..., self.start : self.end]


@register.reshape
class DynamicSliceInputConst(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        oact_src_shape = self.outputs[0].src_shape
        ret = slice_tensor(
            input_,
            self.start,
            (self.start[0] + self.slice_len,),
            axes=self.axis,
            steps=self.step,
            output_src_shape=oact_src_shape,
        )
        return ret

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)
