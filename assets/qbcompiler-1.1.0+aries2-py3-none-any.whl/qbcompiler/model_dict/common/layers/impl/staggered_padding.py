import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


def convert_pad_shape(pad_shape):
    layer = pad_shape[::-1]
    pad_shape = [item for sublist in layer for item in sublist]
    return pad_shape


@register.layer
class StaggeredPadding(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        n, n_heads, w, c = input_.shape
        if self.axis != 3:
            raise NotImplementedError

        output_shape = (n, n_heads, w, w + c - 1)
        output_ = torch.zeros(*output_shape, dtype=input_.dtype).to(self.device)
        if self.reverse:
            for i in range(w):
                output_[:, :, w - 1 - i, i : i + c] = input_[:, :, w - 1 - i, :]
            pad_length = w - (self.window_size + 1)
            output_ = output_[
                :, :, :, pad_length : pad_length + 2 * self.window_size + 1
            ]
        else:
            for i in range(w):
                output_[:, :, i, i : i + c] = input_[:, :, i, :]
            output_ = output_[:, :, :, self.window_size : -self.window_size]
        return output_

    def get_ops(self):
        return 0
