from functools import reduce
from operator import mul

import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class RmsNormalization(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slot__ = ("epsilon", "scale")

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if not self.normalized_shape:
            variance = input_.pow(2).mean(dim=-1, keepdim=True)
            x = input_ * torch.rsqrt(variance + self.epsilon)
            return self.scale * x
        else:
            return torch.nn.functional.rms_norm(
                input_, self.normalized_shape, weight=self.scale, 
                eps=float(self.epsilon if self.epsilon is not None else torch.finfo(x.dtype).eps)
            )

    def get_ops(self):
        output_shape = [int(shape) for shape in self.outputs[0].shape]
        return reduce(mul, output_shape)
