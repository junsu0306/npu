from typing import Tuple

import numpy
import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    MultiInputsMixin,
    DataFormatGeneric,
)


@register.reshape
class Concatenate(LayerABC, MultiInputsMixin, DataFormatGeneric):
    __slots__ = ("axis", "original_axis")

    def __init__(
        self,
        layer_name: str,
        device,
        is_npu,
        **kwargs,
    ):
        super().__init__(layer_name, device, is_npu, **kwargs)

    def _predict_concat2_inputs(self, inputs, **kwargs):
        if self.axis == -1:
            dim = 3
        else:
            dim = self.axis
        input0 = inputs[0].to(self.device)
        input1 = inputs[1].to(self.device)
        if not self.input_index:
            return torch.cat([input0, input1], dim=dim)
        else:  # last concat
            cc_out = torch.cat([input0, input1], dim=dim)
            channel_split_sizes = [
                int(self.original_input_channels[x]) for x in self.input_index
            ]
            cc_splits = torch.split(cc_out, channel_split_sizes, dim=-1)
            x = torch.cat(
                [cc_splits[int(x)] for x in numpy.argsort(self.input_index)], dim=-1
            )
            return x

    def _predict_concat_inputs(self, inputs, **kwargs):
        axis = self.axis
        return torch.cat(inputs, dim=axis)

    def _predict_npu_concat(self, inputs, **kwargs):
        if len(inputs) == 2:
            return self._predict_concat2_inputs(inputs, **kwargs)
        else:
            return self._predict_concat_inputs(inputs, **kwargs)

    def _predict_unsupported_concat(
        self, inputs: Tuple[torch.Tensor, ...], **kwargs
    ) -> torch.Tensor:
        axis = self.axis
        if any(in_data.dim() == 0 for in_data in inputs):
            inputs = [
                in_data.unsqueeze(0) if in_data.dim() == 0 else in_data
                for in_data in inputs
            ]
        if axis is None:
            axis = self.original_axis
        return torch.cat([x.to(self.device) for x in inputs], dim=axis)

    def _predict(self, inputs: Tuple[torch.Tensor, ...], **kwargs) -> torch.Tensor:
        if self.is_npu:
            return self._predict_npu_concat(inputs, **kwargs)
        return self._predict_unsupported_concat(inputs, **kwargs)

    def get_ops(self):
        return 0

    def folding_fwd(self, *inputs_):
        return self._predict_unsupported_concat(inputs_)
