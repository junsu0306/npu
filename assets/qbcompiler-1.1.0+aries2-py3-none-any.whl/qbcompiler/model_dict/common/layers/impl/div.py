import torch

from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    SingleInputMixin,
    LayerABC,
    DataFormatGeneric,
    BiInputsMixin,
)


@register.layer
class DivConstant(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("constant", "is_const_first")

    def _kernel(self, input_, const_) -> torch.Tensor:
        if self.is_const_first:
            return const_.to(self.device) / input_.to(self.device)
        return input_.to(self.device) / const_.to(self.device)

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return self._kernel(input_, self.constant)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)

    def folding_fwd(self, input_: torch.Tensor):
        return self._kernel(input_, self.constant)


@register.layer
class Div(LayerABC, BiInputsMixin, DataFormatGeneric):
    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        return input0.to(self.device) / (input1.to(self.device))

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)
