from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    DataFormatGeneric,
    SingleInputMixin,
    MultiInputsMixin,
    LayerABC,
)


@register.layer
class Input(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_, **kwargs):
        return input_

    def get_ops(self):
        return 0


@register.layer
class InputConstant(LayerABC, MultiInputsMixin, DataFormatGeneric):
    def _predict(self, input_, **kwargs):
        return self.constant.to(self.device)

    def get_ops(self):
        return 0


@register.layer
class AttentionMaskInput(LayerABC, MultiInputsMixin, DataFormatGeneric):
    def _predict(self, input_, **kwargs):
        return self.sample_mask.to(self.device)

    def get_ops(self):
        return 0
