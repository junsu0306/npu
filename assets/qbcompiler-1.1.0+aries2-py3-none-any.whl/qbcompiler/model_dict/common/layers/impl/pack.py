from typing import Tuple

import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    MultiInputsMixin,
    DataFormatGeneric,
)


@register.reshape
class Pack(LayerABC, MultiInputsMixin, DataFormatGeneric):
    __slots__ = ("axis", "values_count")

    def _predict(self, inputs: Tuple[torch.Tensor, ...], **kwargs) -> torch.Tensor:
        if all(len(i.shape) == 0 for i in inputs) and self.axis == 0:
            xs = [i.reshape(1) for i in inputs]
            return torch.cat(xs, dim=self.axis)
        raise NotImplementedError

    def get_ops(self):
        return 0
