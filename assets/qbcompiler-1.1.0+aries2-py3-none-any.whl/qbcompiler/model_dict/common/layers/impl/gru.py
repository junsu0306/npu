import torch

from typing import Tuple
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    MultiInputsMixin,
    DataFormatGeneric,
)


@register.layer
class GRU(LayerABC, MultiInputsMixin, DataFormatGeneric):
    def _predict_forward(
        self, inputs: Tuple[torch.Tensor, ...], **kwargs
    ) -> torch.Tensor:
        initial_h = None
        if self.input_mask == "ih":
            X, initial_h = inputs
        else:
            raise NotImplementedError(f"input_mask:{self.input_mask}")
        # Ht = f(Xt*(Wi^T) + Ht-1*(Ri^T) + Wbi + Rbi)
        seq_len, batch_size, input_size = X.shape
        hidden_size = self.hidden_size

        num_directions = 1

        Ht = initial_h
        if Ht is None:
            Ht = torch.zeros(size=(num_directions, batch_size, hidden_size))

        W = torch.transpose(self.W, 2, 1)
        R = torch.transpose(self.R, 2, 1)

        B = self.B
        if B is None:
            B = torch.zeros(size=(num_directions, 6 * hidden_size))
        Wb, Rb = torch.split(B, [hidden_size * 3] * 2, dim=-1)

        act_f = torch.sigmoid
        act_g = torch.tanh
        hts = []
        Wz, Wr, Wh = torch.split(W, [hidden_size] * 3, dim=-1)
        Rz, Rr, Rh = torch.split(R, [hidden_size] * 3, dim=-1)
        Wbz, Wbr, Wbh = torch.split(Wb, [hidden_size] * 3, dim=-1)
        Rbz, Rbr, Rbh = torch.split(Rb, [hidden_size] * 3, dim=-1)
        for Xt in X:
            zt = act_f(torch.matmul(Xt, Wz) + torch.matmul(Ht, Rz) + Wbz + Rbz)
            rt = act_f(torch.matmul(Xt, Wr) + torch.matmul(Ht, Rr) + Wbr + Rbr)
            if self.linear_before_reset:
                ht = act_g(
                    torch.matmul(Xt, Wh) + rt * (torch.matmul(Ht, Rr) + Rbh) + Wbh
                )
            else:
                ht = act_g(torch.matmul(Xt, Wh) + torch.matmul(rt * Ht, Rr) + Rbh + Wbh)

            Ht = (1 - zt) * ht + zt * Ht
            hts.append(Ht)

        Y = torch.stack(hts)
        if self.batch_first:
            Y = torch.permute(Y, [2, 0, 1, 3])

        if self.output_mask == "o":
            return Y
        if self.output_mask == "h":
            return Ht
        raise Exception("code should not be reached!")

    def _predict_bidirectional(
        self, inputs: Tuple[torch.Tensor, ...], **kwargs
    ) -> torch.Tensor:
        initial_h = None
        if self.input_mask == "ih":
            X, initial_h = inputs
        else:
            raise NotImplementedError(f"input_mask:{self.input_mask}")
        seq_len, batch_size, input_size = X.shape
        hidden_size = self.hidden_size

        num_directions = 2
        Ht = initial_h
        if Ht is None:
            Ht = torch.zeros(size=(num_directions, batch_size, hidden_size))

        W = torch.transpose(self.W, 2, 1)
        R = torch.transpose(self.R, 2, 1)

        B = self.B
        if B is None:
            B = torch.zeros(size=(num_directions, 8 * hidden_size))
        Wb, Rb = torch.split(B, [hidden_size] * 2, dim=-1)

        act_f = torch.tanh

        def data_iter(X, d):
            if d == 0:
                for idx, Xt in enumerate(X):
                    yield idx, Xt
            elif d == 1:
                for idx, Xt in zip(reversed(range(seq_len)), reversed(X)):
                    yield idx, Xt

        Y = torch.zeros(size=(seq_len, num_directions, batch_size, hidden_size))
        for d in range(num_directions):
            W_d = W[d : d + 1, ...]
            Ht_d = Ht[d : d + 1, ...]
            R_d = R[d : d + 1, ...]
            Wb_d = Wb[d : d + 1, ...]
            Rb_d = Rb[d : d + 1, ...]
            for i_seq, Xt in data_iter(X, d):
                Ht_d = act_f(
                    torch.matmul(Xt, W_d) + torch.matmul(Ht_d, R_d) + Wb_d + Rb_d
                )
                Ht[d, ...] = Ht_d
                Y[i_seq : i_seq + 1, d : d + 1, ...] = Ht_d

        if self.batch_first:
            Y = torch.permute(Y, [2, 0, 1, 3])

        if self.output_mask == "o":
            return Y
        if self.output_mask == "h":
            return Ht
        raise Exception("code should not be reached!")

    def _predict(self, inputs: Tuple[torch.Tensor, ...], **kwargs) -> torch.Tensor:
        if self.direction == "forward":
            return self._predict_forward(inputs, **kwargs)
        else:
            return self._predict_bidirectional(inputs, **kwargs)

    def get_ops(self):
        return 0
