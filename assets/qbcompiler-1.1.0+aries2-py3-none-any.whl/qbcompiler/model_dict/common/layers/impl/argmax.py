import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class ArgMax(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("axis", "keepdims", "select_last")

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return torch.argmax(input_, dim=self.axis, keepdim=self.keepdims)

    def get_ops(self):
        return 0
