from typing import Tuple

import numpy
import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    MultiInputsMixin,
    DataFormatGeneric,
)


@register.layer
class ScatterND(LayerABC, MultiInputsMixin, DataFormatGeneric):
    """
    todo: very slow.
    """

    def _predict_with_const_indices(self, inputs: Tuple[torch.Tensor, ...], **kwargs):
        data = inputs[0]
        indices = self.constant_indices.detach().cpu().numpy()
        updates = inputs[1]

        x = data.clone().to(self.device)
        update_indices = indices.shape[:-1]
        for idx in numpy.ndindex(update_indices):
            x[tuple(indices[idx])] = updates[idx]
        return x

    def _predict_with_const_indices_const_data(
        self, inputs: Tuple[torch.Tensor, ...], **kwargs
    ):
        updates = inputs[0]
        indices = self.constant_indices.detach().cpu().numpy()
        data = self.constant_data.detach()

        x = data.clone().to(self.device)
        update_indices = indices.shape[:-1]
        for idx in numpy.ndindex(update_indices):
            x[tuple(indices[idx])] = updates[idx]
        return x

    def _predict(self, inputs: Tuple[torch.Tensor, ...], **kwargs) -> torch.Tensor:
        if self.constant_indices is not None and self.constant_data is None:
            return self._predict_with_const_indices(inputs, **kwargs)
        if self.constant_indices is not None and self.constant_data is not None:
            return self._predict_with_const_indices_const_data(inputs, **kwargs)
        raise NotImplementedError

    def get_ops(self):
        return 0
