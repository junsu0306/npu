import abc
import functools, operator
import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


def _identity(x):
    return x


def _fn_compose(f, g):
    return lambda x: g(f(x))


def _reduce_l2(x, dim, keepdim, dtype):
    return torch.sqrt(torch.sum(x * x, dim=dim, keepdim=keepdim, dtype=dtype))


def _get_reduce_op(
    reduce_kind, reduce_axes, keep_dims, noop_with_empty_axes, dtype=None
):
    opset = {
        "mean": torch.mean,
        "max": torch.max,
        "min": torch.min,
        "sum": torch.sum,
        "prod": torch.prod,
        "l2": _reduce_l2,
    }

    if reduce_axes is None or len(reduce_axes) == 0:
        if noop_with_empty_axes:
            return _identity
        if not keep_dims:
            return opset[reduce_kind]

    reduce_axes = sorted(reduce_axes, reverse=True)
    if reduce_kind in ("min", "max"):
        reduce_op = opset[reduce_kind]
    else:
        reduce_op = functools.partial(opset[reduce_kind], dtype=dtype)

    if reduce_kind in ("mean", "sum", "l2"):
        return functools.partial(reduce_op, dim=reduce_axes, keepdim=keep_dims)

    if reduce_kind == "prod":

        def wrapped_op(x, dim, keepdim):
            return reduce_op(x, dim=dim, keepdim=keepdim)

        ops = [
            functools.partial(wrapped_op, dim=a, keepdim=keep_dims) for a in reduce_axes
        ]
        return functools.reduce(_fn_compose, ops, _identity)

    if reduce_kind in ("max", "min"):

        def wrapped_op(x, dim, keepdim):
            return reduce_op(x, dim=dim, keepdim=keepdim).values

        ops = [
            functools.partial(wrapped_op, dim=a, keepdim=keep_dims) for a in reduce_axes
        ]
        return functools.reduce(_fn_compose, ops, _identity)
        # def f(x, dim, keepdim, op):
        #     for d in dim:
        #         x = op(x, dim=d, keepdim=keepdim).values
        #     return x
        # return functools.partial(f,dim=reduce_axes, keepdim=keep_dims,op=reduce_op)
    raise ValueError(
        f"unable to determine reduce operation:"
        f"{reduce_kind}, {reduce_axes}, {keep_dims}, {noop_with_empty_axes}"
    )


class ReduceOp(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("reduce_axes", "keep_dims", "noop_with_empty_axes")

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return self._kernel(input_.to(self.device), self.reduce_axes)

    def get_ops(self):
        input_src_shape = [int(shape) for shape in self.inputs[0].get_act_src_shape()]
        reduce_axis = [
            axis if axis >= 0 else len(input_src_shape) + axis
            for axis in self.reduce_axes
        ]
        op_list = [dim for i, dim in enumerate(input_src_shape) if i not in reduce_axis]
        op_num = functools.reduce(operator.mul, op_list, 1)
        op_axis_list = [
            dim for i, dim in enumerate(input_src_shape) if i in reduce_axis
        ]

        op_axis_num = functools.reduce(operator.mul, op_axis_list, 1) - 1
        op_count = op_axis_num * op_num
        return op_count

    @abc.abstractmethod
    def _kernel(self, input_: torch.Tensor, reduce_axes) -> torch.Tensor:
        ...


@register.layer
class ReduceMean(ReduceOp):
    def _kernel(self, input_: torch.Tensor, reduce_axes, **kwargs) -> torch.Tensor:
        reduce_op = _get_reduce_op(
            "mean",
            reduce_axes,
            self.keep_dims,
            self.noop_with_empty_axes,
            dtype=input_.dtype,
        )
        return reduce_op(input_)


@register.layer
class ReduceSum(ReduceOp):
    def _kernel(self, input_: torch.Tensor, reduce_axes, **kwargs) -> torch.Tensor:
        reduce_op = _get_reduce_op(
            "sum",
            reduce_axes,
            self.keep_dims,
            self.noop_with_empty_axes,
            dtype=input_.dtype,
        )
        return reduce_op(input_)


@register.layer
class ReduceProd(ReduceOp):
    def _kernel(self, input_: torch.Tensor, reduce_axes, **kwargs) -> torch.Tensor:
        reduce_op = _get_reduce_op(
            "prod",
            reduce_axes,
            self.keep_dims,
            self.noop_with_empty_axes,
            dtype=input_.dtype,
        )
        return reduce_op(input_)


@register.layer
class ReduceMax(ReduceOp):
    def _kernel(self, input_: torch.Tensor, reduce_axes, **kwargs) -> torch.Tensor:
        reduce_op = _get_reduce_op(
            "max",
            reduce_axes,
            self.keep_dims,
            self.noop_with_empty_axes,
            dtype=input_.dtype,
        )
        return reduce_op(input_)


@register.layer
class ReduceMin(ReduceOp):
    def _kernel(self, input_: torch.Tensor, reduce_axes, **kwargs) -> torch.Tensor:
        reduce_op = _get_reduce_op(
            "min",
            reduce_axes,
            self.keep_dims,
            self.noop_with_empty_axes,
            dtype=input_.dtype,
        )
        return reduce_op(input_)


@register.layer
class ReduceL2(ReduceOp):
    def _kernel(self, input_: torch.Tensor, reduce_axes, **kwargs) -> torch.Tensor:
        reduce_op = _get_reduce_op(
            "l2",
            reduce_axes,
            self.keep_dims,
            self.noop_with_empty_axes,
            dtype=input_.dtype,
        )
        return reduce_op(input_)
