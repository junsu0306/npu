from typing import List

import torch

from qbcompiler.model_dict.common.dataformat import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
)


@register.layer
class Zeros(LayerABC, SingleInputMixin):
    __slots__ = ("dtype",)

    def _predict(self, *args, **kwargs) -> torch.Tensor:
        shape = tuple(int(x) for x in args[0])
        if self.dtype == "float32":
            dt = torch.float32
        elif self.dtype == "bool":
            dt = torch.bool
        else:
            raise NotImplementedError
        return torch.zeros(shape, dtype=dt).to(self.device)

    def get_ops(self):
        return 0

    def dformat_fwd(self, input_src_shapes: List, input_dataformats: List):
        return DataFormat.UNKNOWN
