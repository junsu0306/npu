from typing import Tuple

import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    MultiInputsMixin,
    DataFormatGeneric,
)


@register.layer
class StatefulAttentionMaskWrapper(LayerABC, MultiInputsMixin, DataFormatGeneric):
    def get_ops(self):
        return 0

    def _predict(self, inputs: Tuple[torch.Tensor, ...], **kwargs) -> torch.Tensor:
        """
            # def scaled_dot_product_attention(query, key, value, attn_mask=None, dropout_p=0.0, is_causal=False,
        #                                  scale=None) -> torch.Tensor:
        #     L, S = query.size(-2), key.size(-2)
        #     scale_factor = 1 / math.sqrt(query.size(-1)) if scale is None else scale
        #     attn_bias = torch.zeros(L, S, dtype=query.dtype)
        #     if is_causal:
        #         assert attn_mask is None
        #         temp_mask = torch.ones(L, S, dtype=torch.bool).tril(diagonal=0)
        #         attn_bias.masked_fill_(temp_mask.logical_not(), float("-inf"))
        #         attn_bias.to(query.dtype)
        #
        #     if attn_mask is not None:
        #         if attn_mask.dtype == torch.bool:
        #             attn_bias.masked_fill_(attn_mask.logical_not(), float("-inf"))
        #         else:
        #             attn_bias += attn_mask
        #     attn_weight = query @ key.transpose(-2, -1) * scale_factor
        #     attn_weight += attn_bias
        #     attn_weight = torch.softmax(attn_weight, dim=-1)
        #     attn_weight = torch.dropout(attn_weight, dropout_p, train=True)
        #     return attn_weight @ value
        """
        attn_weight = inputs[0]  # attn_weight = q @ k.transpose
        q_size, k_size = attn_weight.shape[-2:]  # L, S = query.size(-2), key.size(-2)
        attn_bias = torch.zeros(q_size, k_size, dtype=attn_weight.dtype)

        # is_causal = True if causal_mask is None and q_len > 1 else False 인데
        # 현재까지는 causal_mask <- attention_mask(=None) 이었음.
        is_causal = q_size > 1

        if is_causal:
            temp_mask = torch.ones(q_size, k_size, dtype=torch.bool).tril(diagonal=0)
            attn_bias.masked_fill_(temp_mask.logical_not(), float("-inf"))
            attn_bias.to(attn_weight.dtype)

        attn_weight += attn_bias.to(attn_weight.device)
        return attn_weight
