import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    BiInputsMixin,
    SingleInputMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class Multiply(LayerABC, BiInputsMixin, DataFormatGeneric):
    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        return input0.to(self.device) * input1.to(self.device)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)


@register.layer
class MultiplyConstant(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("constant",)

    def _kernel(self, left, right):
        return left.to(self.device) * right.to(self.device)

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if self.constant.ndim > 0 and torch.allclose(self.constant, self.constant[0]):
            self.constant = self.constant[0]
        return self._kernel(input_, torch.as_tensor(self.constant)).to(input_.dtype)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)

    def folding_fwd(self, input_: torch.Tensor):
        return self._kernel(input_, self.constant)
