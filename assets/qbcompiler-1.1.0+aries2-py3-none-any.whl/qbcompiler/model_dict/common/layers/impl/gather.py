import torch
import numpy

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    BiInputsMixin,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.reshape
class Gather(LayerABC, BiInputsMixin, DataFormatGeneric):
    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        if input0.dim() == input1.dim() and len(input0.shape) == 2:
            return torch.tensor(
                numpy.take(numpy.array(input0), numpy.array(input1), axis=self.axis)
            )
        elif input0.dim() == input1.dim():
            return torch.gather(
                input0.to(self.device), dim=self.axis, index=input1.to(self.device)
            )
        else:
            positions = input1.to(self.device).int()
            if len(positions.shape) != 1:
                positions = positions.reshape(-1)
            return torch.index_select(
                input0.to(self.device), dim=self.axis, index=positions
            )

    def get_ops(self):
        return 0


@register.reshape
class GatherConstant(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("constant", "axis")

    def _predict(self, input0: torch.Tensor, **kwargs) -> torch.Tensor:
        if self.is_const_first:
            indices = input0.to(self.device)
            data = self.constant.to(self.device)
        else:
            indices = self.constant.to(self.device)
            data = input0.to(self.device)

        q = len(indices.shape)
        r = len(data.shape)
        out_rank = q + (r - 1)
        if q == 0:
            output_shape = tuple(x for i, x in enumerate(data.shape) if i != self.axis)
        else:
            os_pre = tuple(data.shape[: self.axis])
            os_post = tuple(data.shape[self.axis + 1 :])
            output_shape = os_pre + tuple(indices.shape) + os_post
        if q == 0:
            indices = indices.reshape(-1)
            indices[indices == -1] = data.shape[self.axis] - 1
            x = torch.index_select(data, dim=self.axis, index=indices).squeeze(
                self.axis
            )
        else:
            x = torch.index_select(
                data, dim=self.axis, index=indices.reshape(-1)
            ).reshape(*output_shape)
            # x = torch.take_along_dim(data, indices, dim=self.axis).reshape(*output_shape)
        if len(x.shape) != out_rank:
            raise Exception
        return x
        # if self.is_const_first:  # input data is constant
        #     positions = input0.to(self.device)
        #     index_shape = tuple(positions.shape)
        #     data = self.constant.to(self.device)
        #     data_dim = tuple(x for i, x in enumerate(data.shape) if i != self.axis)
        #     x = torch.index_select(data, dim=self.axis, index=positions.reshape(-1))
        #     return x.reshape(index_shape + data_dim).to(self.device)
        # else:
        #     positions = self.constant.to(self.device).int()
        #     if len(positions.shape) != 1:
        #         positions = positions.reshape(-1)
        #     if len(positions) == 1:
        #         return torch.index_select(
        #             input0.to(self.device), dim=self.axis, index=positions
        #         ).squeeze(self.axis)
        #     else:
        #         return torch.index_select(
        #             input0.to(self.device), dim=self.axis, index=positions
        #         )

    def get_ops(self):
        return 0


@register.reshape
class GatherElements(LayerABC, BiInputsMixin, DataFormatGeneric):
    __slots__ = ("axis",)

    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        expanded_indices = [
            torch.arange(s, device=input0.device).view(
                [1 if i != dim else -1 for i, s in enumerate(input0.shape)]
            )
            for dim, s in enumerate(input0.shape)
        ]

        expanded_indices[self.axis] = input1
        result = input0[tuple(expanded_indices)]

        return result

    def get_ops(self):
        return 0
