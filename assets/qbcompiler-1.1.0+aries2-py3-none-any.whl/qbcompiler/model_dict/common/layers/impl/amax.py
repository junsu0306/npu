import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class AMax(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return torch.amax(input_, dim=self.axis, keepdim=self.keepdims)

    def get_ops(self):
        output_act = self.inputs[0]
        return get_total_num_elements(output_act.src_shape)
