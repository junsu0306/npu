from typing import List

import numpy
import torch

from qbcompiler.model_dict.common.dataformat import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)

numpy_to_torch_dtype_dict = {
    "float32": torch.float32,
}


@register.layer
class Full(LayerABC, SingleInputMixin, DataFormatGeneric):
    def _predict(self, input0: torch.Tensor, **kwargs) -> torch.Tensor:
        return torch.full(
            size=[int(x) for x in input0],
            fill_value=self.value.item(),
            dtype=numpy_to_torch_dtype_dict[self.value.dtype.name],
        ).to(self.device)

    def get_ops(self):
        pass
