import numpy
import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class DepthToSpace(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("mode",)

    def _predict(self, input_: torch.Tensor, **kwargs):
        if self.channel_last:
            input_ = input_.permute(0, 3, 1, 2)
        else:
            raise NotImplementedError
        if self.mode == "DCR":
            return self._predict_DCR(input_)
        elif self.mode == "CRD":
            return self._predict_CRD(input_)
        else:
            raise NotImplementedError

    def _predict_DCR(self, input):
        x = input.detach().cpu().numpy()
        n, c, h, w = shape = x.shape
        blocksize = self.block_size
        tmp = numpy.reshape(
            x, [n, blocksize, blocksize, c // (blocksize * blocksize), h, w]
        )
        tmp = numpy.transpose(tmp, [0, 3, 4, 1, 5, 2])
        y = numpy.reshape(
            tmp, [n, c // (blocksize * blocksize), h * blocksize, w * blocksize]
        )
        if self.channel_last:
            return (
                torch.tensor(y, dtype=input.dtype).permute((0, 2, 3, 1)).to(self.device)
            )
        else:
            return torch.tensor(y, dtype=input.dtype).to(self.device)

    def _predict_CRD(self, input):
        x = input.detach().cpu().numpy()
        n, c, h, w = shape = input.shape
        blocksize = self.block_size
        tmp = numpy.reshape(x, [n, c // (blocksize**2), blocksize, blocksize, h, w])
        tmp = numpy.transpose(tmp, [0, 1, 4, 2, 5, 3])
        y = numpy.reshape(tmp, [n, c // (blocksize**2), h * blocksize, w * blocksize])
        if self.channel_last:
            return (
                torch.tensor(y, dtype=input.dtype).permute((0, 2, 3, 1)).to(self.device)
            )
        else:
            return torch.tensor(y, dtype=input.dtype).to(self.device)

    def get_ops(self):
        return 0
