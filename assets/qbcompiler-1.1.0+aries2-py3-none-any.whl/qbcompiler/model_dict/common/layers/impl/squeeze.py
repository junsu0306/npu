import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.reshape
class Squeeze(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("squeeze_axes",)

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if self.squeeze_axes is None:
            output = torch.squeeze(input_.to(self.device))
        elif len(self.squeeze_axes) == 1:
            dim = self.squeeze_axes[0]
            output = torch.squeeze(input_.to(self.device), dim=dim)
        elif len(self.squeeze_axes) >= 2:
            output = input_
            for i, axis in enumerate(sorted(self.squeeze_axes)):
                dim = axis - i
                output = torch.squeeze(output.to(self.device), dim=dim)
        else:
            raise NotImplementedError

        return output

    def get_ops(self):
        return 0

    def folding_fwd(self, input_):
        return self._predict(input_)
