import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.reshape
class Unsqueeze(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("axes",)

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if len(self.axes) == 1:
            dim = self.axes[0]
            return torch.unsqueeze(input_.to(self.device), dim=dim)
        raise NotImplementedError()

    def get_ops(self):
        return 0

    def folding_fwd(self, input_):
        return self._predict(input_)
