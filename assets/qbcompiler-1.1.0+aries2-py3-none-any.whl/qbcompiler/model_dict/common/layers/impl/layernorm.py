import torch

from qbcompiler.model_dict.common import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class LayerNormalization(LayerABC, SingleInputMixin, DataFormatGeneric):
    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 8 * (get_total_num_elements(output_act.src_shape))

    def _predict(
        self, input_: torch.Tensor, dataformat: DataFormat, **kwargs
    ) -> torch.Tensor:
        if self.bias is not None and torch.allclose(
            self.bias, torch.tensor(0).to(self.bias)
        ):
            self.bias = None
        # input_ = input_.to(self.device).to(torch.bfloat16)
        eps = self.epsilon
        if isinstance(eps, torch.Tensor):
            eps = float(self.epsilon.to(input_))
        else:
            eps = float(eps)
        return torch.nn.functional.layer_norm(
            input_,
            self.normalized_shape,
            weight=self.scale.to(input_),
            bias=self.bias.to(input_) if self.bias is not None else None,
            eps=eps,
        )

        # input_ = input_.to(self.device)
        # x = input_.permute(0,3,1,2)
        # u = x.mean(1, keepdim=True)
        # s = (x - u).pow(2).mean(1, keepdim=True)
        # x = (x - u) / torch.sqrt(s + self.epsilon)
        # x = self.scale[:, None, None] * x + bias[:, None, None]
        # return x.permute(0,2,3,1)
