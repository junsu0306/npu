import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    BiInputsMixin,
    LayerABC,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class GridSample(LayerABC, BiInputsMixin, DataFormatGeneric):
    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        if input1 is None:
            X, grid = input0, self.constant
            if self.is_const_first:
                X, grid = grid, X
        else:
            X, grid = input0, input1
        mode = self.mode
        if mode == "linear":
            mode = "bilinear"
        # 여기서는 channel first로 바꿔서 해야 함.
        return torch.nn.functional.grid_sample(
            X.permute(0, 3, 1, 2),
            grid,
            mode=mode,
            padding_mode=self.padding_mode,
            align_corners=bool(self.align_corners),
        ).permute(0, 2, 3, 1)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 7 * (get_total_num_elements(output_act.src_shape))
