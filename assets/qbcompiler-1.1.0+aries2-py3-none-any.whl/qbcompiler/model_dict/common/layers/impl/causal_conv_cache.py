import torch

from qbcompiler.model_dict.common import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class StatefulCausalConvCacheWrapper(LayerABC, SingleInputMixin, DataFormatGeneric):
    def get_ops(self):
        return 0

    def _predict(
        self, input_: torch.Tensor, dataformat: DataFormat, **kwargs
    ) -> torch.Tensor:
        if self.conv_cache is None:
            self.conv_cache = {}
            self.conv_cache[op.name]

        if self.conv_cache is not None and self.cache_name in self.conv_cache:
            cache_ = self.conv_cache[self.cache_name]
            new_input = torch.cat(
                [cache_.to(self.device), input_.to(self.device)], dim=2
            )
        else:
            new_input = input_

        self.conv_cache[self.cache_name] = new_input[:, :, -self.cache_len :, :]
        return new_input
