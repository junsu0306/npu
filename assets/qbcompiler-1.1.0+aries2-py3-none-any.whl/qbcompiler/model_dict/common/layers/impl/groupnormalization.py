import torch

from qbcompiler.model_dict.common import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class GroupNormalization(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("bias", "epsilon", "scale", "num_groups")

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if not self.channel_last:
            raise NotImplementedError
        dim = self.inputs[0].src_dim
        if dim == 4:
            x = input_.permute(0, 3, 1, 2).to(self.device)
            x = torch.nn.functional.group_norm(
                x,
                num_groups=self.num_groups,
                weight=self.scale.to(x),
                bias=self.bias.to(x),
                eps=self.epsilon,
            )
            return x.permute(0, 2, 3, 1)
        elif dim == 3:
            x = input_.permute(0, 2, 1).to(self.device)
            x = torch.nn.functional.group_norm(
                x,
                num_groups=self.num_groups,
                weight=self.scale.to(self.device),
                bias=self.bias.to(self.device),
                eps=self.epsilon,
            )
            return x.permute(0, 2, 1)
        else:
            raise NotImplementedError

    def get_ops(self):
        return 0
