from functools import reduce
from operator import mul

import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class L2Normalization(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slot__ = "norm_axis"

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if self.epsilon is not None:
            eps = self.epsilon.reshape(-1)[0]
        else:
            eps = 1e-6
        if len(self.norm_axis) == 1:
            dim_axis = self.norm_axis[0]
            norm = torch.norm(input_, p=2, dim=dim_axis, keepdim=True)
            return input_ / (norm + eps)
        else:
            raise NotImplementedError("Not implemented L2Normalization")

    def get_ops(self):
        output_shape = [int(shape) for shape in self.outputs[0].shape]
        return reduce(mul, output_shape)
