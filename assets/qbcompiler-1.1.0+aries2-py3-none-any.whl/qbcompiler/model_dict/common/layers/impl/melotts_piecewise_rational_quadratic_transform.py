from typing import List

import torch

from qbcompiler.model_dict.common import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    BiInputsMixin,
    LayerABC,
)


@register.layer
class MeloTTSPiecewiseRationalQuadraticTransform(LayerABC, BiInputsMixin):

    def get_ops(self):
        return 0

    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        import math
        from melo.transforms import piecewise_rational_quadratic_transform

        x1, h = input0, input1

        is_rank4 = len(x1.shape) == 4

        if is_rank4:
            x1 = x1.permute(0, 1, 3, 2).squeeze(1)
            h = h.permute(0, 1, 3, 2).squeeze(1)

        num_bins = int(self.num_bins)
        filter_channels = int(self.filter_channels)
        reverse = bool(self.reverse)
        tail_bound = float(self.tail_bound)

        b, c, t = x1.shape
        h = h.reshape(int(b), int(c), -1, int(t)).permute(
            0, 1, 3, 2
        )  # [b, cx?, t] -> [b, c, t, ?]

        unnormalized_widths = h[..., :num_bins] / math.sqrt(filter_channels)
        unnormalized_heights = h[..., num_bins : 2 * num_bins] / math.sqrt(
            filter_channels
        )
        unnormalized_derivatives = h[..., 2 * num_bins :]

        x1, logabsdet = piecewise_rational_quadratic_transform(
            x1,
            unnormalized_widths.to(x1.device),
            unnormalized_heights.to(x1.device),
            unnormalized_derivatives.to(x1.device),
            inverse=reverse,
            tails="linear",
            tail_bound=tail_bound,
        )
        if is_rank4:
            x1 = x1.unsqueeze(1).permute(0, 1, 3, 2)
        return x1

    def dformat_fwd(self, input_src_shapes: List, input_dataformats: List):
        return DataFormat.UNKNOWN
