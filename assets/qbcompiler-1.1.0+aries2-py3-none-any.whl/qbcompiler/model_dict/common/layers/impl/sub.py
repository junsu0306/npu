import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    BiInputsMixin,
    SingleInputMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class Sub(LayerABC, BiInputsMixin, DataFormatGeneric):
    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        return input0.to(self.device) - input1.to(self.device)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)


@register.layer
class SubConstant(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("is_const_first", "constant")

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        input_ = input_.to(self.device)
        # broadcasting should be available at this point
        if self.is_const_first:
            return self.constant - input_
        else:
            return input_ - self.constant

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)

    def folding_fwd(self, input_):
        return self._predict(input_)
