from typing import List

import torch

from qbcompiler.model_dict.common import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class Embedding(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("embedding_dim", "num_embeddings", "weight")

    def get_ops(self):
        return 0

    def _predict(
        self, input_: torch.Tensor, dataformat: DataFormat, **kwargs
    ) -> torch.Tensor:
        assert (self.num_embeddings, self.embedding_dim) == self.weight.shape
        return torch.nn.functional.embedding(input_, self.weight.to(input_.device))
