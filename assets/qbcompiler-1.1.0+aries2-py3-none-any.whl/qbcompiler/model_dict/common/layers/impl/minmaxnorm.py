from functools import reduce
from operator import mul

import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class MinMaxNormalization(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slot__ = "norm_axis"

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if len(self.norm_axis) == 1:
            dim_axis = self.norm_axis[0]
            x_min = torch.amin(input_, dim=dim_axis, keepdim=True)
            x_max = torch.amax(input_, dim=dim_axis, keepdim=True)
            denom = x_max - x_min
            return (input_ - x_min) / denom
        else:
            dim_axes = list(self.norm_axis)
            x_min = input_
            x_max = input_
            for ax in sorted(dim_axes, reverse=True):
                x_min = torch.amin(x_min, dim=ax, keepdim=True)
                x_max = torch.amax(x_max, dim=ax, keepdim=True)
            denom = x_max - x_min
            return (input_ - x_min) / denom

    def get_ops(self):
        output_shape = [int(shape) for shape in self.outputs[0].shape]
        return reduce(mul, output_shape)
