import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    BiInputsMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class FloorMod(LayerABC, BiInputsMixin, DataFormatGeneric):
    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        """
        This follows Python semantics in that the result here is consistent with a flooring divide. E.g. floor(x / y) * y + floormod(x, y) = x, regardless of the signs of x and
        """
        if self.constant is not None:
            if self.is_const_first:
                i0, i1 = self.constant, input0
            else:
                i0, i1 = input0, self.constant
        else:
            i0, i1 = input0, input1
        return i0 - torch.floor(i0 / i1) * i1

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)
