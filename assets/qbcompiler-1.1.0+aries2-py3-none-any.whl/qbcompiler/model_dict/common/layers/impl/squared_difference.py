import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    BiInputsMixin,
    DataFormatGeneric,
)


@register.layer
class SquaredDifference(LayerABC, BiInputsMixin, DataFormatGeneric):
    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        return (input0.to(self.device) - input1.to(self.device)) ** 2

    def get_ops(self):
        return 0
