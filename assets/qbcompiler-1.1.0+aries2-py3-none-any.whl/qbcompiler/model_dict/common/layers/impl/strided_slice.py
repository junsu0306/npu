import numpy
import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    SingleInputMixin,
    LayerABC,
    DataFormatGeneric,
)


def _parse_mask(mask_int, begin_value):
    return tuple(map(int, bin(mask_int)[2:].zfill(len(begin_value))[-1::-1]))


def _interpret_slice(b, e, s, dim, mask_b, mask_e):
    if s == 0:
        raise ValueError("code should not be reached!")
    if mask_b == 1:
        b = 0 if s > 0 else -1
    if mask_e == 1:
        e = dim if s > 0 else -(dim + 1)
    return b, e


@register.reshape
class StridedSlice(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = (
        "begin",
        "end",
        "stride",
        "begin_mask",
        "end_mask",
        "ellipsis_mask",
        "new_axis_mask",
        "shrink_axis_mask",
    )

    def _get_indexer(self, input_shape):
        begin_value = self.begin
        end_value = self.end
        stride_value = self.stride

        begin_mask = _parse_mask(self.begin_mask, begin_value)
        end_mask = _parse_mask(self.end_mask, begin_value)
        ellipsis_mask = _parse_mask(self.ellipsis_mask, begin_value)
        new_axis_mask = _parse_mask(self.new_axis_mask, begin_value)
        shrink_axis_mask = _parse_mask(self.shrink_axis_mask, begin_value)
        shrink_axis_mask = tuple(i for i, x in enumerate(shrink_axis_mask) if x == 1)

        indexer = []
        for idx, (b, e, s) in enumerate(zip(begin_value, end_value, stride_value)):
            if new_axis_mask[idx] == 1:
                indexer.append(numpy.newaxis)
            elif ellipsis_mask[idx] == 1:
                indexer.append(Ellipsis)
            else:
                # it seems that stride clamping is automatically dealt with. If not implelment.
                # s == 0 should be fall into this case
                b, e = _interpret_slice(
                    b, e, s, input_shape[idx], begin_mask[idx], end_mask[idx]
                )
                indexer.append(numpy.s_[b:e:s])
        return indexer, shrink_axis_mask

    def _predict_nchw(self, input_, **kwargs):
        perm0 = (0, 2, 3, 1)
        perm1 = (0, 3, 1, 2)
        x = input_.to(self.device).permute(*perm0)
        indexer, shrink_axis_mask = self._get_indexer(tuple(x.shape))
        has_neg_step = False
        for slc in indexer:
            if slc.step < 0:
                has_neg_step = True
                break
        if has_neg_step:
            x = x.detach().cpu().numpy()
            x = x[tuple(indexer)].copy()  # eager execution to make it exists.
            x = torch.from_numpy(x)
        else:
            x = x[tuple(indexer)]
        if not shrink_axis_mask:
            return x.permute(*perm1)

        x = x[tuple(indexer)]
        "if the following fails, numpy.squeeze will work."
        if len(shrink_axis_mask) > 1:
            """Changed in version 2.0: dim now accepts tuples of dimensions."""
            raise NotImplementedError
        x = torch.squeeze(x, shrink_axis_mask[0])
        return x.permute(*perm1)

    def _predict_nhwc(self, input_, **kwargs):
        x = input_.to(self.device)
        indexer, shrink_axis_mask = self._get_indexer(tuple(x.shape))
        has_neg_step = False
        for slc in indexer:
            if slc.step < 0:
                has_neg_step = True
                break
        if has_neg_step:
            x = x.detach().cpu().numpy()
            x = x[tuple(indexer)].copy()  # eager execution to make it exists.
            x = torch.from_numpy(x)
        else:
            x = x[tuple(indexer)]
        if not shrink_axis_mask:
            return x

        x = x[tuple(indexer)]
        "if the following fails, numpy.squeeze will work."
        if len(shrink_axis_mask) > 1:
            """Changed in version 2.0: dim now accepts tuples of dimensions."""
            raise NotImplementedError
        x = torch.squeeze(x, shrink_axis_mask[0])
        return x

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        return self._predict_nhwc(input_, **kwargs)

    def get_ops(self):
        return 0
