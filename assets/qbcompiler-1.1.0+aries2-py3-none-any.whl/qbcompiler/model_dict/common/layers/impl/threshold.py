from typing import Tuple

import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)


@register.layer
class Threshold(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("lower_threshold", "lower_value", "upper_threshold", "upper_value")

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        if self.lower_threshold is not None and self.upper_threshold is not None:
            assert (
                self.lower_threshold < self.upper_threshold
            ), "lower_threshold must be smaller than upper_threshold"
        if self.lower_threshold is not None:
            assert self.lower_value is not None
        if self.upper_threshold is not None:
            assert self.upper_value is not None
        x = input_
        out = x
        if self.lower_threshold is not None:
            lower_value = torch.as_tensor(
                self.lower_value, dtype=x.dtype, device=x.device
            )
            out = torch.where(x > self.lower_threshold, out, lower_value)
        if self.upper_threshold is not None:
            upper_value = torch.as_tensor(
                self.upper_value, dtype=x.dtype, device=x.device
            )
            out = torch.where(x < self.upper_threshold, out, upper_value)
        return out

    def get_ops(self):
        return 0
