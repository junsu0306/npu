import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    BiInputsMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class FloorDiv(LayerABC, BiInputsMixin, DataFormatGeneric):
    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        if self.constant is not None:
            if self.is_const_first:
                return torch.floor_divide(
                    self.constant.to(self.device), input0.to(self.device)
                )
            else:
                return torch.floor_divide(
                    input0.to(self.device), self.constant.to(self.device)
                )
        return torch.floor_divide(input0.to(self.device), input1.to(self.device))

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return get_total_num_elements(output_act.src_shape)
