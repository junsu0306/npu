import torch

from qbcompiler.model_dict.common.dataformat import DataFormat
from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    SingleInputMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements

__all__ = ["TopKIndices", "TopKValues"]


@register.layer
class TopKIndices(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("axis", "constant", "largest", "sorted")

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        axis = 1 if self.axis is None else self.axis
        vv = torch.topk(
            input=input_.to(self.device),
            k=self.constant,
            dim=axis,
            largest=self.largest,
            sorted=self.sorted,
        )
        return vv.indices.to(torch.int32)

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 2 * get_total_num_elements(output_act.src_shape)


@register.layer
class TopKValues(LayerABC, SingleInputMixin, DataFormatGeneric):
    __slots__ = ("axis", "constant", "largest", "sorted")

    def _predict(self, input_: torch.Tensor, **kwargs) -> torch.Tensor:
        axis = 1 if self.axis is None else self.axis
        vv = torch.topk(
            input=input_.to(self.device),
            k=self.constant,
            dim=axis,
            largest=self.largest,
            sorted=self.sorted,
        )
        return vv.values

    def get_ops(self):
        output_act = self.outputs[0]  # single output activationspec
        return 2 * get_total_num_elements(output_act.src_shape)
