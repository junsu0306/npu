import torch

from qbcompiler.model_dict.common.layers import register
from qbcompiler.model_dict.common.layers.layerabc import (
    LayerABC,
    BiInputsMixin,
    DataFormatGeneric,
)
from qbcompiler.model_dict.common.layers.layers_utils import get_total_num_elements


@register.layer
class MatMul(LayerABC, BiInputsMixin, DataFormatGeneric):
    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        repeat_input_idx, repeat_cnt = self.repeat
        if self.constant is None:
            left, right = input0, input1
            # repeat works onlyif nhwc
            if repeat_input_idx == 0:
                t = tuple(left.shape)
                v = torch.unsqueeze(left, dim=2)
                v = v.expand(t[:2] + (repeat_cnt,) + t[2:])
                new_shape = (t[0], t[1] * repeat_cnt) + t[2:]
                left = v.reshape(new_shape)
            elif repeat_input_idx == 1:
                t = tuple(right.shape)  # (1,8,64,52)
                v = torch.unsqueeze(right, dim=2)  # (1,8,64,52) -> (1,8,1,64,52)
                v = v.expand(t[:2] + (repeat_cnt,) + t[2:])  # (1,8,4,64,52)
                new_shape = (t[0], t[1] * repeat_cnt) + t[2:]
                right = v.reshape(new_shape)
            if left.dtype != right.dtype:
                left = left.to(torch.float32)
                right = right.to(torch.float32)
                return torch.matmul(left.to(self.device), right.to(self.device))
            return torch.matmul(left.to(self.device), right.to(self.device))
        else:
            if self.is_const_first:
                return torch.matmul(
                    self.constant.to(self.device), input0.to(self.device)
                )
            else:
                return torch.matmul(
                    input0.to(self.device), self.constant.to(self.device)
                )

    def get_ops(self):
        if self.constant is None:
            input_src_shape_0 = self.inputs[0].src_shape
        else:
            if self.is_const_first:
                input_src_shape_0 = self.constant.shape
            else:
                input_src_shape_0 = self.inputs[0].src_shape
        output_src_shape = self.outputs[0].src_shape
        return get_total_num_elements(output_src_shape) * (
            2 * int(input_src_shape_0[-1]) - 1
        )
