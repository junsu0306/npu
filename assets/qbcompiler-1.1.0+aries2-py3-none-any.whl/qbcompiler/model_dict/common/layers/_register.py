__all__ = ["register", "get_layer_cls"]


LAYERS = {}
ACTIVATION_FUNCTIONS = {}
RESHAPE = {}


class _Register:
    _is_ready = False

    @staticmethod
    def layer(fn):
        """decorator to register function type."""
        LAYERS[fn.__name__] = fn
        return fn

    @staticmethod
    def actfunc(fn):
        """decorator to register activation function type."""
        ACTIVATION_FUNCTIONS[fn.__name__] = fn
        return fn

    @staticmethod
    def reshape(fn):
        """decorator to register reshape type."""
        RESHAPE[fn.__name__] = fn
        return fn

    def get_layer_cls(self, opname):
        if opname in LAYERS:
            return LAYERS[opname]
        if opname in ACTIVATION_FUNCTIONS:
            return ACTIVATION_FUNCTIONS[opname]
        if opname in RESHAPE:
            return RESHAPE[opname]
        raise NotImplementedError(
            f"{opname} not implemented in (LAYERS / ACTIVATION_FUNCTIONS / RESHAPE)"
        )

    def has_layer_cls(self, opname):
        return opname in LAYERS or opname in ACTIVATION_FUNCTIONS or opname in RESHAPE


register = _Register()


def get_layer_cls(opname):
    return register.get_layer_cls(opname)


def has_layer_cls(opname):
    return register.has_layer_cls(opname)
