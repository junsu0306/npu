import operator
import torch

from functools import reduce
from typing import Tuple
from qbcompiler.model_dict.common.item_specs import DimValue


def get_total_num_elements(src_shape: Tuple[int | DimValue]):
    return reduce(operator.mul, (int(shape) for shape in src_shape)) if src_shape else 0


_DT_CAST = {
    "float64": torch.float64,
    "float32": torch.float32,
    "float16": torch.float16,
    "bfloat16": torch.bfloat16,
    "uint8": torch.uint8,
    "bool": torch.bool,
    "int32": torch.int32,
    "int64": torch.int64,
}
