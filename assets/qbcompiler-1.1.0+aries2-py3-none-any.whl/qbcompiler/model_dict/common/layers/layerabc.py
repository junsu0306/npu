import abc
from typing import Tuple, List

import numpy
import torch

from qbcompiler.model_dict.common.dataformat import DataFormat
from qbcompiler.model_dict.common.tensor import WrappedTensor


class LayerABC(abc.ABC):
    def __init__(
        self,
        layer_name: str,
        device,
        is_npu,
        **kwargs,
    ):
        self.layer_name = layer_name
        self.device = device
        self.is_npu = is_npu
        self.use_onnx_inference = False

        for k, v in kwargs.items():
            if isinstance(v, numpy.ndarray):
                v = torch.from_numpy(v.copy()).to(device)
            setattr(self, k, v)

    @abc.abstractmethod
    def get_ops(self):
        ...


class SingleInputMixin(abc.ABC):
    """layer with single input"""

    def __call__(self, *args, **kwargs):
        if args and all(isinstance(tensor, torch.Tensor) for tensor in args):
            data = args[0]
            return self._predict(data, dataformat=DataFormat.UNKNOWN)
        else:
            data, dformat = args[0]._t, args[0].dataformat
            x = self._predict(data, dataformat=dformat)
            return WrappedTensor(
                x,
                dtype=str(x.dtype).split(".")[-1],
                dataformat=self.dformat_fwd([data.shape], [dformat]),
            )

    @abc.abstractmethod
    def _predict(
        self,
        input_: torch.Tensor,
        dataformat: DataFormat,
        **kwargs,
    ) -> torch.Tensor:
        ...


class BiInputsMixin(abc.ABC):
    """base layer with two inputs."""

    def __call__(self, *args, **kwargs):
        if len(args) == 1 and hasattr(self, "constant"):
            # less is parsed to reach here
            if all(isinstance(tensor, torch.Tensor) for tensor in args):
                data = args[0]
                return self._predict(
                    data, dataformat0=DataFormat.UNKNOWN, dataformat1=None
                )
            else:
                data, dformat = args[0]._t, args[0].dataformat
                x = self._predict(data, None, dataformat0=dformat, dataformat1=None)
                return WrappedTensor(
                    x,
                    dtype=str(x.dtype).split(".")[-1],
                    dataformat=self.dformat_fwd([data.shape, None], [dformat, None]),
                )

        if args and all(isinstance(tensor, torch.Tensor) for tensor in args):
            return self._predict(
                args[0],
                args[1],
                dataformat0=DataFormat.UNKNOWN,
                dataformat1=DataFormat.UNKNOWN,
            )
        else:
            x = self._predict(
                args[0]._t,
                args[1]._t,
                dataformat0=args[0].dataformat,
                dataformat1=args[1].dataformat,
            )
            return WrappedTensor(
                x,
                dtype=str(x.dtype).split(".")[-1],
                dataformat=self.dformat_fwd(
                    [args[0]._t.shape, args[1]._t.shape],
                    [args[0].dataformat, args[1].dataformat],
                ),
            )

    @abc.abstractmethod
    def _predict(
        self, input0: torch.Tensor, input1: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        ...


class MultiInputsMixin(abc.ABC):
    def __call__(self, *args, **kwargs):
        if args and all(isinstance(tensor, torch.Tensor) for tensor in args):
            inputs_ = args
            kw = {
                f"dataformat{idx}": DataFormat.UNKNOWN for idx, arg in enumerate(args)
            }
            return self._predict(inputs_, **kw)
        else:
            inputs_ = tuple(arg._t for arg in args)
            _dfs = tuple(arg.dataformat for arg in args)
            kw = {f"dataformat{idx}": arg.dataformat for idx, arg in enumerate(args)}
        x = self._predict(inputs_, **kw)

        return WrappedTensor(
            x,
            dataformat=self.dformat_fwd([arg._t.shape for arg in args], _dfs),
            dtype=str(x.dtype).split(".")[-1],
        )

    @abc.abstractmethod
    def _predict(self, inputs: Tuple[torch.Tensor, ...], **kwargs) -> torch.Tensor:
        ...


class DataFormatGeneric:
    def dformat_fwd(self, input_src_shapes: List, input_dataformats: List):
        if all(act.src_dim == 4 for act in self.inputs + self.outputs):
            return DataFormat.NHWC
        else:
            out_dformat = DataFormat.UNKNOWN
        if len(self.outputs) == 1:
            return out_dformat
        else:
            return [out_dformat] * len(self.outputs)

    def dformat_bwd(
        self, output_src_shapes: List, output_dataformats: List, input_dataformats: List
    ):
        return input_dataformats


class DataFormatSupportedGroup:
    def dformat_fwd(self, input_src_shapes: List, input_dataformats: List):
        dformat = DataFormat.NHWC
        if len(self.outputs) == 1:
            return dformat
        return [dformat] * len(self.outputs)

    def dformat_bwd(
        self, output_src_shapes: List, output_dataformats: List, input_dataformats: List
    ):
        return input_dataformats
