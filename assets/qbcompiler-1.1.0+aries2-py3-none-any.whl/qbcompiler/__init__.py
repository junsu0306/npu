import os
import torch
import qbcompiler.mobilint_transformers

if "TF_CPP_MIN_LOG_LEVEL" not in os.environ or not os.environ["TF_CPP_MIN_LOG_LEVEL"]:
    os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"  # tensorflow loglevel set
    # '0': Display all logs (default behavior), '1': Display only warnings and errors
    # '2': Display only errors, '3': Display no logs

if (
    "QBCOMPILER_HAD_MATRIX_PATH" not in os.environ
    or not os.environ["QBCOMPILER_HAD_MATRIX_PATH"]
):
    import importlib.resources

    os.environ["QBCOMPILER_HAD_MATRIX_PATH"] = str(
        importlib.resources.files("qbcompiler") / "had_matrix"
    )


def has_gpu() -> bool:
    return torch.cuda.is_available()


def ensure_onnxruntime_installed():
    try:
        import onnxruntime
    except ImportError as e:
        onnx_type = "onnxruntime-gpu" if has_gpu() else "onnxruntime"
        e.msg = (
            f"Please install {onnx_type} >= 1.19.2. "
            "Without onnxruntime, qbcompiler will not function properly."
        )
        raise e


ensure_onnxruntime_installed()

from .version import __version__
from .frontend import *
