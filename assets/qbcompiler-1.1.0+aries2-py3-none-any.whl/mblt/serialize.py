import os
import pathlib
from typing import List, Union, BinaryIO

import msgpack
import numpy

from mblt.logger import get_logger

# Make torch optional to avoid heavyweight dependency at install time
try:  # pragma: no cover - optional dependency
    import torch  # type: ignore

    _TORCH_AVAILABLE = True
except Exception:  # pragma: no cover - if torch is not installed
    torch = None  # type: ignore
    _TORCH_AVAILABLE = False

from mblt.core import ArrayWrapper
from mblt.manifest import Manifest
from mblt.model_dict import ModelDict

LOGGER = get_logger("serialize")


if _TORCH_AVAILABLE:
    _CHUNK_TYPES = Union[numpy.ndarray, torch.Tensor, bytes, ArrayWrapper]
    tensor_types = (numpy.ndarray, ArrayWrapper, torch.Tensor)
else:
    _CHUNK_TYPES = Union[numpy.ndarray, bytes, ArrayWrapper]
    tensor_types = (numpy.ndarray, ArrayWrapper)


def _size_in_bytes(data: _CHUNK_TYPES) -> int:
    if isinstance(data, tensor_types):
        return int(data.nbytes)
    return len(data)


class ChunkWrapper:
    def __init__(self, chunk: _CHUNK_TYPES):
        self.chunk = chunk

    def tobytes(self) -> bytes:
        if _TORCH_AVAILABLE and isinstance(self.chunk, torch.Tensor):
            return bytes(self.chunk.untyped_storage())
        elif isinstance(self.chunk, numpy.ndarray):
            return self.chunk.tobytes()
        elif isinstance(self.chunk, bytes):
            return self.chunk
        else:
            raise NotImplementedError


class ChunkedByteBuffer:
    def __init__(self, max_chunk_size: int = 2**32):
        self._chunks: List[ChunkWrapper] = []
        self._max_chunk_size = max_chunk_size

    def write_to(self, f: BinaryIO) -> None:
        for chunk in self:
            if isinstance(chunk, bytes):
                f.write(chunk)
            else:
                f.write(chunk.tobytes())

    def add_chunk(self, chunk: _CHUNK_TYPES) -> None:
        if not isinstance(chunk, tensor_types + (bytes,)):
            raise TypeError(
                f"Chunk must be numpy.ndarray or torch.Tensor, bytes, got {type(chunk).__name__}"
            )
        if (chunk_size := _size_in_bytes(chunk)) > self._max_chunk_size:
            raise ValueError(
                f"Chunk size ({chunk_size} bytes) exceeds maximum allowed "
                f"size ({self._max_chunk_size} bytes)"
            )
        self._chunks.append(ChunkWrapper(chunk))

    def to_bytes(self) -> bytes:
        return b"".join(
            x if isinstance(x, bytes) else x.tobytes() for x in self._chunks
        )

    @property
    def total_size(self) -> int:
        return sum(_size_in_bytes(chunk) for chunk in self._chunks)

    @property
    def chunk_count(self) -> int:
        """저장된 청크의 개수"""
        return len(self._chunks)

    def clear(self) -> None:
        """모든 청크를 제거"""
        self._chunks.clear()

    def __len__(self) -> int:
        """총 바이트 크기 반환 (total_size와 동일)"""
        return self.total_size

    def __bytes__(self) -> bytes:
        """bytes() 변환 지원 (to_bytes()와 동일)"""
        return self.to_bytes()

    def __iter__(self):
        return iter(x if isinstance(x, bytes) else x.tobytes() for x in self._chunks)

    def __repr__(self) -> str:
        return (
            f"ChunkedByteBuffer(chunks={self.chunk_count}, "
            f"total_size={self.total_size:,} bytes)"
        )


_BYTE_TYPE_MAPPER = {1: numpy.uint8, 4: numpy.uint32, 8: numpy.uint64}


class SerializeMeta:
    """
    MAGIC_NUMBER(4 bytes) = b'MBLT'
    manifest_size(8 bytes): denotes the size of the manifest.
    model_dict_size(8 bytes): denotes the size of the model_dict.
    max_buffer_size(8 bytes): denotes the maximum size of a single buffer.
    last_buffer_size(8 bytes): denotes the size of the last buffer.
    num_buffers(8 bytes): denotes the number of buffers.
    manifest(a bytes)
    model_dict(m bytes)
    weights(w bytes)

    |weight_buffers(w)|model_dict(m)|manifest(a)|num_buffers(8)|last_buffer_size(8)|max_buffer_size(8)|model_dict_size(8)|manifest_size(8)|MAGIC_NUMBER(4)|


    ############ old version(without manifest) ############

    model_dict_size(8 bytes): denotes the size of the model_dict.
    mode(1 byte): buffer read mode.
    max_buffer_size(8 bytes): denotes the maximum size of a single buffer.
    last_buffer_size(8 bytes): denotes the size of the last buffer.
    num_buffers(8 bytes): denotes the number of buffers.
    model_dict(m bytes)
    weights(w bytes)

    |weight_buffers(w)|model_dict(m)|num_buffers(8)|last_buffer_size(8)|max_buffer_size(8)|mode(1)|model_dict_size(8)|
    """

    HEADERS = (
        ("num_buffers", 8),
        ("last_buffer_size", 8),
        ("max_buffer_size", 8),
        ("model_dict_size", 8),
        ("manifest_size", 8),
        ("MAGIC_NUMBER", 4),
    )

    LEGACY_HEADERS = (
        ("num_buffers", 8),
        ("last_buffer_size", 8),
        ("max_buffer_size", 8),
        ("mode", 1),
        ("model_dict_size", 8),
    )

    HEADER_SIZE = sum(h[1] for h in HEADERS)
    LEGACY_HEADER_SIZE = sum(h[1] for h in LEGACY_HEADERS)
    MAGIC_NUMBER = b"MBLT"
    SINGLE_BUFFER_SIZE_LIMIT = 2**32

    def __init__(
        self,
        generator="qubee",
        generator_version="",
        model_dict_size=0,
        manifest_size=0,
        max_buffer_size=2**32,
        last_buffer_size=0,
        num_buffers=0,
        is_legacy=False,
    ):
        self.model_dict_size = model_dict_size
        self.manifest_size = manifest_size
        self.max_buffer_size = min(max_buffer_size, self.SINGLE_BUFFER_SIZE_LIMIT)
        self.last_buffer_size = last_buffer_size
        self.num_buffers = num_buffers
        self._b: ChunkedByteBuffer = None
        self.generator = generator
        self.generator_version = generator_version
        self.is_legacy = is_legacy

    def __repr__(self) -> str:
        manifest_info = (
            f"manifest_size={self.manifest_size}"
            if not self.is_legacy
            else "legacy_format"
        )
        return (
            f"SerializeMeta("
            f"model_dict_size={self.model_dict_size}, "
            f"{manifest_info}, "
            f"num_buffers={self.num_buffers}, "
            f"max_buffer_size={self.max_buffer_size}, "
            f"last_buffer_size={self.last_buffer_size}, "
            f"generator='{self.generator}', "
            f"generator_version='{self.generator_version}'"
            f")"
        )

    def serialize(self, model_dict, ignore_weight=False):
        self._b = ChunkedByteBuffer()
        if not ignore_weight:
            self._serialize_weights(model_dict)
        self._serialize_model_dict(model_dict)
        self._serialize_manifest(
            generator=self.generator,
            generator_version=self.generator_version,
            model_name=model_dict.name,
            model_version=model_dict.version,
        )
        self._serialize_header()
        return self._b

    def write_to_file(self, write_path: str) -> None:
        if self._b is None:
            raise RuntimeError("No serialized data available. Call serialize() first.")
        p = pathlib.Path(write_path)
        if not p.parent.exists():
            p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("wb") as f:
            self._b.write_to(f)

    def serialize_and_write(self, model_dict, write_path: str, ignore_weight=False):
        self.serialize(model_dict, ignore_weight=ignore_weight)
        self.write_to_file(write_path)

    def _serialize_header(self):
        b_header = b"".join(
            _BYTE_TYPE_MAPPER[h[1]](getattr(self, h[0])).tobytes()
            for h in self.HEADERS[:-1]
        )
        b_header += self.MAGIC_NUMBER
        self._b.add_chunk(b_header)

    def _serialize_model_dict(self, model_dict):
        b_model_dict = msgpack.packb(model_dict.to_dict())
        self.model_dict_size = len(b_model_dict)
        self._b.add_chunk(b_model_dict)

    def _serialize_weights(self, model_dict):
        """
        does not serialize immediately to minimize memory usage.
        """
        self.update_weight_buffer_info(model_dict.subgraphs)
        for sg in model_dict.subgraphs:
            for tensor in sg.tensors:
                if tensor.buffer_idx == -1 or tensor.offset == -1:
                    raise ValueError(
                        "Weight tensor does not have buffer_idx or offset set."
                    )
                self._b.add_chunk(tensor.value)

    def _serialize_manifest(
        self, generator, generator_version, model_name, model_version
    ):
        manifest = Manifest(
            generator=generator,
            generator_version=generator_version,
            model_name=model_name,
            model_version=model_version,
            model_hash="",
        )
        b_manifest = msgpack.packb(manifest.to_dict())
        self.manifest_size = len(b_manifest)
        self._b.add_chunk(b_manifest)

    @classmethod
    def read_header(cls, path_to_mblt: str) -> "SerializeMeta":
        p = pathlib.Path(path_to_mblt)
        if not p.exists():
            raise FileNotFoundError(f"File not found: {path_to_mblt}")
        with p.open("rb") as f:
            f.seek(0, os.SEEK_END)  # to the end
            file_size = f.tell()
            f.seek(0)  # to the beginning
            if file_size < 4:
                raise ValueError(
                    f"File is too small to contain valid header: {file_size} bytes"
                )
            f.seek(-4, os.SEEK_END)
            magic_number = f.read(4)
            if magic_number != cls.MAGIC_NUMBER:
                return cls._read_legacy_header(f, file_size)
            return cls._read_current_header(f, file_size)

    @classmethod
    def _read_current_header(cls, f: BinaryIO, file_size: int) -> "SerializeMeta":
        """현재 포맷의 헤더 읽기"""
        if file_size < cls.HEADER_SIZE:
            raise ValueError(
                f"File is too small to contain valid header: {file_size} bytes"
            )

        f.seek(-cls.HEADER_SIZE, os.SEEK_END)
        header_bytes = f.read(cls.HEADER_SIZE)
        offset = 0
        header_values = {}
        for field_name, field_size in cls.HEADERS:
            dtype = _BYTE_TYPE_MAPPER[field_size]
            if field_name == "MAGIC_NUMBER":
                magic = header_bytes[offset : offset + field_size]
                if magic != cls.MAGIC_NUMBER:
                    raise ValueError(
                        f"Invalid magic number: {magic}. Expected {cls.MAGIC_NUMBER}"
                    )
                header_values[field_name] = magic
            else:
                value = numpy.frombuffer(
                    header_bytes[offset : offset + field_size], dtype=dtype
                )[0]
                header_values[field_name] = int(value)
            offset += field_size

        return cls(
            model_dict_size=header_values["model_dict_size"],
            manifest_size=header_values["manifest_size"],
            max_buffer_size=header_values["max_buffer_size"],
            last_buffer_size=header_values["last_buffer_size"],
            num_buffers=header_values["num_buffers"],
            is_legacy=False,
        )

    @classmethod
    def _read_legacy_header(cls, f: BinaryIO, file_size: int) -> "SerializeMeta":
        """레거시 포맷의 헤더 읽기"""
        if file_size < cls.LEGACY_HEADER_SIZE:
            raise ValueError(
                f"File is too small to contain valid legacy header: {file_size} bytes"
            )

        # 헤더 읽기 (파일 끝에서부터)
        f.seek(-cls.LEGACY_HEADER_SIZE, os.SEEK_END)
        header_bytes = f.read(cls.LEGACY_HEADER_SIZE)

        # 헤더 파싱
        offset = 0
        header_values = {}
        for field_name, field_size in cls.LEGACY_HEADERS:
            dtype = _BYTE_TYPE_MAPPER[field_size]
            value = numpy.frombuffer(
                header_bytes[offset : offset + field_size], dtype=dtype
            )[0]
            header_values[field_name] = int(value)
            offset += field_size

        return cls(
            model_dict_size=header_values["model_dict_size"],
            manifest_size=0,  # 레거시 포맷에는 manifest 없음
            max_buffer_size=header_values["max_buffer_size"],
            last_buffer_size=header_values["last_buffer_size"],
            num_buffers=header_values["num_buffers"],
            is_legacy=True,
        )

    def update_weight_buffer_info(self, subgraphs):
        """
        Compute buffer allocation information for weights against the given maximum buffer size.
        returns total_weight_size

        This method distributes weights across multiple buffers, each with a maximum size.
        For each weight, it records which buffer it starts in and the offset within that buffer.
        """

        curr_buff_idx = 0
        curr_buff_offset = 0
        total_weight_size = 0

        for sg in subgraphs:
            for tensor in sg.tensors:
                weight_size = tensor.nbytes
                total_weight_size += weight_size
                tensor.buffer_idx = curr_buff_idx
                tensor.offset = curr_buff_offset

                # Allocate space for this weight across one or more buffers
                remaining_size = weight_size
                while remaining_size > 0:
                    available_space = self.max_buffer_size - curr_buff_offset
                    alloc_size = min(remaining_size, available_space)
                    curr_buff_offset += alloc_size
                    remaining_size -= alloc_size
                    # Move to next buffer if current one is full
                    if curr_buff_offset >= self.max_buffer_size:
                        curr_buff_idx += 1
                        curr_buff_offset = 0
        n_buffers, size_rem = divmod(total_weight_size, self.max_buffer_size)
        if size_rem > 0:
            self.num_buffers = n_buffers + 1
            self.last_buffer_size = size_rem
        else:
            self.num_buffers = n_buffers
            self.last_buffer_size = self.max_buffer_size

    @staticmethod
    def get_model_dict(path_to_mblt: str, load_weight_policy="default") -> ModelDict:
        header = SerializeMeta.read_header(path_to_mblt)
        LOGGER.info(f"MBLT HEADER {header}")
        p = pathlib.Path(path_to_mblt)
        with p.open("rb") as f:
            if header.is_legacy:
                hlen = SerializeMeta.LEGACY_HEADER_SIZE
                md_size = header.model_dict_size
                md_start = hlen + md_size
            else:
                hlen = SerializeMeta.HEADER_SIZE
                md_size = header.model_dict_size
                manifest_size = header.manifest_size
                f.seek(-(hlen + manifest_size), os.SEEK_END)
                manifest = Manifest.from_dict(msgpack.unpackb(f.read(manifest_size)))
                LOGGER.info(f"MBLT MANIFEST {manifest}")
                md_start = hlen + manifest_size + md_size
            f.seek(-md_start, os.SEEK_END)
            model_dict = ModelDict.from_dict(msgpack.unpackb(f.read(md_size)))
        header._load_weight(model_dict, header, path_to_mblt, load_weight_policy)
        return model_dict

    def _load_weight(self, model_dict, header, path_to_mblt, load_weight_policy):
        if load_weight_policy == "default":
            for sg in model_dict.subgraphs:
                for tensor in sg.tensors:
                    if tensor.buffer_idx < 0 or tensor.offset < 0:
                        # No weight recorded for this tensor
                        continue
                    # Default to numpy-backed lazy loading; caller can convert to torch if desired
                    tensor.set_value(
                        ArrayWrapper(
                            path=path_to_mblt,
                            buffer_idx=tensor.buffer_idx,
                            offset=tensor.offset,
                            buffer_size=header.max_buffer_size,
                            shape=tuple(map(int, tensor.shape)),
                            dtype=tensor.dtype,
                        )
                    )
        else:
            raise NotImplementedError(
                f"load_weight_policy={load_weight_policy} not implemented!"
            )


def load_model_dict(path_to_mblt: str):
    model_dict = SerializeMeta.get_model_dict(path_to_mblt)
    return model_dict
