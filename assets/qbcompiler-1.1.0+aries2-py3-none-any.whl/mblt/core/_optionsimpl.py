"""
last_build: 2026-03-24 12:56:47
version: 0.0.1
"""

import dataclasses
from typing import Tuple, Optional, Union

from ._options import TypeEnforcedMixin, LayerOptions
from ._types import int32, float32, TensorIndex, int64
from .util import MbltEnum


class LayerType(MbltEnum):
    Abs = MbltEnum.auto()
    AddPartial = MbltEnum.auto()
    AddingConstant = MbltEnum.auto()
    Adding = MbltEnum.auto()
    Batchnorm = MbltEnum.auto()
    Cast = MbltEnum.auto()
    Ceil = MbltEnum.auto()
    Celu = MbltEnum.auto()
    Clip = MbltEnum.auto()
    Concatenate = MbltEnum.auto()
    Convolution = MbltEnum.auto()
    Convolution3d = MbltEnum.auto()
    Crop = MbltEnum.auto()
    CustomOp = MbltEnum.auto()
    DepthwiseConvolution = MbltEnum.auto()
    DeviceBridge = MbltEnum.auto()
    DivConstant = MbltEnum.auto()
    Div = MbltEnum.auto()
    Elu = MbltEnum.auto()
    Erf = MbltEnum.auto()
    Exp = MbltEnum.auto()
    Expand = MbltEnum.auto()
    Gelu = MbltEnum.auto()
    GLU = MbltEnum.auto()
    GridSample = MbltEnum.auto()
    GroupConvolution = MbltEnum.auto()
    GroupNormalization = MbltEnum.auto()
    HardSigmoid = MbltEnum.auto()
    Hardtanh = MbltEnum.auto()
    HardSwish = MbltEnum.auto()
    Hardshrink = MbltEnum.auto()
    Softshrink = MbltEnum.auto()
    HeaderView = MbltEnum.auto()
    HeaderViewRevert = MbltEnum.auto()
    Identity = MbltEnum.auto()
    InputConstant = MbltEnum.auto()
    Input = MbltEnum.auto()
    InstanceNormalization = MbltEnum.auto()
    L1Normalization = MbltEnum.auto()
    L2Normalization = MbltEnum.auto()
    SumNormalization = MbltEnum.auto()
    LSTM = MbltEnum.auto()
    LayerNormalization = MbltEnum.auto()
    Logit = MbltEnum.auto()
    RNN = MbltEnum.auto()
    GRU = MbltEnum.auto()
    LeakyRelu = MbltEnum.auto()
    Log = MbltEnum.auto()
    LogSigmoid = MbltEnum.auto()
    MaskSoftmax = MbltEnum.auto()
    MatMul = MbltEnum.auto()
    Mish = MbltEnum.auto()
    MultiplyConstant = MbltEnum.auto()
    Multiply = MbltEnum.auto()
    NonMaxSuppression = MbltEnum.auto()
    Output = MbltEnum.auto()
    PRelu = MbltEnum.auto()
    Pad = MbltEnum.auto()
    PadGeneric = MbltEnum.auto()
    Pooling = MbltEnum.auto()
    GlobalAveragePooling = MbltEnum.auto()
    GlobalResponseNormalization = MbltEnum.auto()
    Pow = MbltEnum.auto()
    QuickGelu = MbltEnum.auto()
    ReduceL2 = MbltEnum.auto()
    ReduceMax = MbltEnum.auto()
    ReduceMin = MbltEnum.auto()
    ReduceMean = MbltEnum.auto()
    ReduceProd = MbltEnum.auto()
    ReduceSum = MbltEnum.auto()
    ReduceRMS = MbltEnum.auto()
    MeanCentering = MbltEnum.auto()
    Relu = MbltEnum.auto()
    RepeatN = MbltEnum.auto()
    Reshape = MbltEnum.auto()
    ReshapeV2 = MbltEnum.auto()
    Resize = MbltEnum.auto()
    RmsNormalization = MbltEnum.auto()
    RotaryEmbedding = MbltEnum.auto()
    Rsqrt = MbltEnum.auto()
    Rstd = MbltEnum.auto()
    ScalarInt = MbltEnum.auto()
    ScalarStr = MbltEnum.auto()
    Gather = MbltEnum.auto()
    GatherElements = MbltEnum.auto()
    ScatterND = MbltEnum.auto()
    Selu = MbltEnum.auto()
    Shape = MbltEnum.auto()
    TensorAttribute = MbltEnum.auto()
    Sigmoid = MbltEnum.auto()
    Slice = MbltEnum.auto()
    Softmax = MbltEnum.auto()
    LogSoftmax = MbltEnum.auto()
    Softplus = MbltEnum.auto()
    Softsign = MbltEnum.auto()
    Sqrt = MbltEnum.auto()
    StaggeredPadding = MbltEnum.auto()
    StatefulAttentionMaskWrapper = MbltEnum.auto()
    StatefulKVCacheWrapper = MbltEnum.auto()
    StatefulCachedStack = MbltEnum.auto()
    StatefulLSTMWrapper = MbltEnum.auto()
    StatefulRNNWrapper = MbltEnum.auto()
    StatefulGRUWrapper = MbltEnum.auto()
    StatefulRoPEWrapper = MbltEnum.auto()
    SubConstant = MbltEnum.auto()
    Sub = MbltEnum.auto()
    Swish = MbltEnum.auto()
    Tanh = MbltEnum.auto()
    Sin = MbltEnum.auto()
    Cos = MbltEnum.auto()
    TemporaryNode = MbltEnum.auto()
    TransposeConvolution = MbltEnum.auto()
    Transpose = MbltEnum.auto()
    Unsqueeze = MbltEnum.auto()
    OrderedPatchify = MbltEnum.auto()
    DynamicSliceInputConst = MbltEnum.auto()
    RelShift = MbltEnum.auto()
    MeloTTSPiecewiseRationalQuadraticTransform = MbltEnum.auto()
    IndexedItemSelector = MbltEnum.auto()
    ChannelwiseApply = MbltEnum.auto()
    Neg = MbltEnum.auto()
    Einsum = MbltEnum.auto()
    RotateHalf = MbltEnum.auto()
    Where = MbltEnum.auto()
    TensorCmp = MbltEnum.auto()
    MaskedFill = MbltEnum.auto()
    SubgraphCall = MbltEnum.auto()
    SubgraphScope = MbltEnum.auto()
    MoeDispatcher = MbltEnum.auto()
    MoeAggregator = MbltEnum.auto()
    ChannelFactorSlice = MbltEnum.auto()
    TopKValues = MbltEnum.auto()
    TopKIndices = MbltEnum.auto()


class OptionsRegistry:
    _registry = {}  # (LayerType, LayerOptionCls)
    _inv_registry = {}  # (LayerOptionCls_name, LayerType)

    @staticmethod
    def register(layertype: LayerType):
        def _register(cls):
            OptionsRegistry._registry[layertype] = cls
            OptionsRegistry._inv_registry[cls.__name__] = layertype
            return cls
        return _register

    @staticmethod
    def getcls(layertype: Union[LayerType, str]):
        if isinstance(layertype, str):
            if layertype in LayerType.__members__:
                return OptionsRegistry._registry[LayerType[layertype]]
            raise ValueError(f"{layertype} not in LayerType")
        return OptionsRegistry._registry[layertype]

    @staticmethod
    def is_registered(option_obj):
        return option_obj.__class__.__name__ in OptionsRegistry._inv_registry

    @staticmethod
    def get_option_type(option_obj) -> LayerType:
        return OptionsRegistry._inv_registry[option_obj.__class__.__name__]



@OptionsRegistry.register(LayerType.Abs)
@dataclasses.dataclass
class AbsOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.AddPartial)
@dataclasses.dataclass
class AddPartialOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    is_input0_larger: bool

@OptionsRegistry.register(LayerType.AddingConstant)
@dataclasses.dataclass
class AddingConstantOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: TensorIndex
    is_const_first: bool = False
    shape: Tuple[int32, ...] = ()

@OptionsRegistry.register(LayerType.Adding)
@dataclasses.dataclass
class AddingOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.Batchnorm)
@dataclasses.dataclass
class BatchnormOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    gamma: TensorIndex
    beta: TensorIndex
    moving_mean: TensorIndex
    moving_var: TensorIndex
    epsilon: TensorIndex
    channel_last: bool = True

@OptionsRegistry.register(LayerType.Cast)
@dataclasses.dataclass
class CastOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    dtype: str

@OptionsRegistry.register(LayerType.Ceil)
@dataclasses.dataclass
class CeilOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.Celu)
@dataclasses.dataclass
class CeluOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    alpha: float32

@OptionsRegistry.register(LayerType.Clip)
@dataclasses.dataclass
class ClipOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    clip_max_value: Optional[float32] = None
    clip_min_value: Optional[float32] = None

@OptionsRegistry.register(LayerType.Concatenate)
@dataclasses.dataclass
class ConcatenateOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    original_key: Optional[str] = None
    axis: Optional[int32] = None
    original_axis: Optional[int32] = None
    original_inputs: Optional[Tuple[int32, ...]] = None
    input_index: Optional[Tuple[int32, ...]] = None
    input_names: Optional[Tuple[str, ...]] = None

@OptionsRegistry.register(LayerType.Convolution)
@dataclasses.dataclass
class ConvolutionOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    in_channels: int32
    out_channels: int32
    h_kernel: int32
    w_kernel: int32
    h_stride: int32
    w_stride: int32
    h_dilation: int32
    w_dilation: int32
    west_padding: int32
    east_padding: int32
    north_padding: int32
    south_padding: int32
    group_number: int32
    weight: TensorIndex
    padding_list: Tuple[int32, ...] = ()
    bias: TensorIndex = -1
    channel_last: bool = True

@OptionsRegistry.register(LayerType.Convolution3d)
@dataclasses.dataclass
class Convolution3dOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    in_channels: int32
    out_channels: int32
    h_kernel: int32
    w_kernel: int32
    d_kernel: int32
    h_stride: int32
    w_stride: int32
    d_stride: int32
    h_dilation: int32
    w_dilation: int32
    d_dilation: int32
    west_padding: int32
    east_padding: int32
    north_padding: int32
    south_padding: int32
    front_padding: int32
    back_padding: int32
    group_number: int32
    weight: TensorIndex
    padding_list: Tuple[int32, ...] = ()
    bias: TensorIndex = -1
    channel_last: bool = True

@OptionsRegistry.register(LayerType.Crop)
@dataclasses.dataclass
class CropOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    crop_width: int32
    crop_height: int32
    w_offset: int32 = 0
    h_offset: int32 = 0

@OptionsRegistry.register(LayerType.CustomOp)
@dataclasses.dataclass
class CustomOpOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, ...]
    content: str

@OptionsRegistry.register(LayerType.DepthwiseConvolution)
@dataclasses.dataclass
class DepthwiseConvolutionOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    in_channels: int32
    out_channels: int32
    h_kernel: int32
    w_kernel: int32
    h_stride: int32
    w_stride: int32
    h_dilation: int32
    w_dilation: int32
    west_padding: int32
    east_padding: int32
    north_padding: int32
    south_padding: int32
    group_number: int32
    weight: TensorIndex
    padding_list: Tuple[int32, ...] = ()
    bias: TensorIndex = -1
    channel_last: bool = True

@OptionsRegistry.register(LayerType.DeviceBridge)
@dataclasses.dataclass
class DeviceBridgeOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    squeeze_axes: Tuple[int32, ...]
    unsqueeze_axes: Tuple[int32, ...]
    permute_axes: Tuple[int64, ...]
    device: Optional[str] = None

@OptionsRegistry.register(LayerType.DivConstant)
@dataclasses.dataclass
class DivConstantOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: TensorIndex
    is_const_first: bool
    shape: Tuple[int32, ...] = ()

@OptionsRegistry.register(LayerType.Div)
@dataclasses.dataclass
class DivOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.Elu)
@dataclasses.dataclass
class EluOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    leaky_alpha: float32

@OptionsRegistry.register(LayerType.Erf)
@dataclasses.dataclass
class ErfOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.Exp)
@dataclasses.dataclass
class ExpOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.Expand)
@dataclasses.dataclass
class ExpandOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    is_const_first: bool
    constant: TensorIndex = -1

@OptionsRegistry.register(LayerType.Gelu)
@dataclasses.dataclass
class GeluOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    approximate: bool = False

@OptionsRegistry.register(LayerType.GLU)
@dataclasses.dataclass
class GLUOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.GridSample)
@dataclasses.dataclass
class GridSampleOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    align_corners: int32 = 0
    mode: str = "linear"
    padding_mode: str = "zeros"
    constant: TensorIndex = -1
    is_const_first: bool = False

@OptionsRegistry.register(LayerType.GroupConvolution)
@dataclasses.dataclass
class GroupConvolutionOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    in_channels: int32
    out_channels: int32
    h_kernel: int32
    w_kernel: int32
    h_stride: int32
    w_stride: int32
    h_dilation: int32
    w_dilation: int32
    west_padding: int32
    east_padding: int32
    north_padding: int32
    south_padding: int32
    group_number: int32
    weight: TensorIndex
    padding_list: Tuple[int32, ...] = ()
    bias: TensorIndex = -1
    channel_last: bool = True

@OptionsRegistry.register(LayerType.GroupNormalization)
@dataclasses.dataclass
class GroupNormalizationOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    num_groups: int32
    scale: TensorIndex
    epsilon: TensorIndex
    bias: TensorIndex = -1
    channel_last: bool = True

@OptionsRegistry.register(LayerType.HardSigmoid)
@dataclasses.dataclass
class HardSigmoidOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    alpha: Optional[float32] = None
    beta: Optional[float32] = None

@OptionsRegistry.register(LayerType.Hardtanh)
@dataclasses.dataclass
class HardtanhOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    min_val: float32 = -1.0
    max_val: float32 = 1.0

@OptionsRegistry.register(LayerType.HardSwish)
@dataclasses.dataclass
class HardSwishOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.Hardshrink)
@dataclasses.dataclass
class HardshrinkOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    lambd: float32 = 0.5

@OptionsRegistry.register(LayerType.Softshrink)
@dataclasses.dataclass
class SoftshrinkOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    lambd: float32 = 0.5

@OptionsRegistry.register(LayerType.HeaderView)
@dataclasses.dataclass
class HeaderViewOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    view_shape: Tuple[int32, ...] = ()
    num_heads: int32 = -1
    batch_order: int32 = 0

@OptionsRegistry.register(LayerType.HeaderViewRevert)
@dataclasses.dataclass
class HeaderViewRevertOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    revert_shape: Tuple[int32, ...] = ()
    num_heads: int32 = -1
    batch_order: int32 = 0

@OptionsRegistry.register(LayerType.Identity)
@dataclasses.dataclass
class IdentityOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.InputConstant)
@dataclasses.dataclass
class InputConstantOptions(LayerOptions, TypeEnforcedMixin):
    outputs: Tuple[int32]
    constant: TensorIndex
    inputs: Tuple = ()
    dtype: str = ""
    shape: Tuple[int32, ...] = ()

@OptionsRegistry.register(LayerType.Input)
@dataclasses.dataclass
class InputOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    orig_name: str = ""

@OptionsRegistry.register(LayerType.InstanceNormalization)
@dataclasses.dataclass
class InstanceNormalizationOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    scale: TensorIndex
    epsilon: TensorIndex
    bias: TensorIndex = -1
    channel_last: bool = True
    num_groups: int32 = -1
    group_order: int32 = -1

@OptionsRegistry.register(LayerType.L1Normalization)
@dataclasses.dataclass
class L1NormalizationOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    norm_axis: Tuple[int32, ...]

@OptionsRegistry.register(LayerType.L2Normalization)
@dataclasses.dataclass
class L2NormalizationOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    norm_axis: Tuple[int32, ...]
    epsilon: TensorIndex = -1

@OptionsRegistry.register(LayerType.SumNormalization)
@dataclasses.dataclass
class SumNormalizationOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    norm_axis: Tuple[int32, ...]
    epsilon: Optional[float32] = None

@OptionsRegistry.register(LayerType.LSTM)
@dataclasses.dataclass
class LSTMOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    W: TensorIndex
    R: TensorIndex
    lstm_group: str
    input_mask: str
    output_mask: str
    hidden_size: int32
    B: TensorIndex = -1
    P: TensorIndex = -1
    direction: str = "forward"
    batch_first: bool = False

@OptionsRegistry.register(LayerType.LayerNormalization)
@dataclasses.dataclass
class LayerNormalizationOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    scale: TensorIndex
    epsilon: TensorIndex
    normalized_shape: Tuple[int64, ...] = ()
    bias: TensorIndex = -1

@OptionsRegistry.register(LayerType.Logit)
@dataclasses.dataclass
class LogitOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    eps: Optional[float32] = None

@OptionsRegistry.register(LayerType.RNN)
@dataclasses.dataclass
class RNNOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    W: TensorIndex
    R: TensorIndex
    rnn_group: str
    input_mask: str
    output_mask: str
    hidden_size: int32
    B: TensorIndex = -1
    direction: str = "forward"
    batch_first: bool = False

@OptionsRegistry.register(LayerType.GRU)
@dataclasses.dataclass
class GRUOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    W: TensorIndex
    R: TensorIndex
    gru_group: str
    input_mask: str
    output_mask: str
    hidden_size: int32
    B: TensorIndex = -1
    direction: str = "forward"
    batch_first: bool = False
    linear_before_reset: bool = False

@OptionsRegistry.register(LayerType.LeakyRelu)
@dataclasses.dataclass
class LeakyReluOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    leaky_alpha: float32

@OptionsRegistry.register(LayerType.Log)
@dataclasses.dataclass
class LogOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.LogSigmoid)
@dataclasses.dataclass
class LogSigmoidOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.MaskSoftmax)
@dataclasses.dataclass
class MaskSoftmaxOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    beta: float32
    axis: int32

@OptionsRegistry.register(LayerType.MatMul)
@dataclasses.dataclass
class MatMulOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    constant: TensorIndex = -1
    is_const_first: bool = False
    repeat: Tuple[int32, int32] = (-1, -1)

@OptionsRegistry.register(LayerType.Mish)
@dataclasses.dataclass
class MishOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.MultiplyConstant)
@dataclasses.dataclass
class MultiplyConstantOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: TensorIndex
    is_const_first: bool = False
    shape: Tuple[int32, ...] = ()

@OptionsRegistry.register(LayerType.Multiply)
@dataclasses.dataclass
class MultiplyOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.NonMaxSuppression)
@dataclasses.dataclass
class NonMaxSuppressionOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32, ...]
    max_output_size: int64
    iou_threshold: float32
    score_threshold: float32
    soft_nms_sigma: float32
    pad_to_max_output_size: bool
    center_point_box: int32 = 0

@OptionsRegistry.register(LayerType.Output)
@dataclasses.dataclass
class OutputOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    orig_name: str = ""

@OptionsRegistry.register(LayerType.PRelu)
@dataclasses.dataclass
class PReluOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    leaky_alpha: TensorIndex

@OptionsRegistry.register(LayerType.Pad)
@dataclasses.dataclass
class PadOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    pad_mode: str
    west_padding: int32 = -1
    east_padding: int32 = -1
    south_padding: int32 = -1
    north_padding: int32 = -1
    constant: float32 = 0.0
    padding_list: Optional[Tuple[int32, ...]] = None
    channel_last: bool = True

@OptionsRegistry.register(LayerType.PadGeneric)
@dataclasses.dataclass
class PadGenericOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    pad_mode: str
    padding_list: Tuple[int32, ...]
    constant: float32 = 0.0

@OptionsRegistry.register(LayerType.Pooling)
@dataclasses.dataclass
class PoolingOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    h_kernel: int32
    w_kernel: int32
    h_stride: int32
    w_stride: int32
    west_padding: int32
    east_padding: int32
    north_padding: int32
    south_padding: int32
    pool_type: str
    pad_mode: str
    h_dilation: int32 = 1
    w_dilation: int32 = 1
    padding_list: Tuple[int32, ...] = ()
    is_ceil_mode: bool = False
    is_include_pad: bool = False
    channel_last: bool = True

@OptionsRegistry.register(LayerType.GlobalAveragePooling)
@dataclasses.dataclass
class GlobalAveragePoolingOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    channel_last: bool = True

@OptionsRegistry.register(LayerType.GlobalResponseNormalization)
@dataclasses.dataclass
class GlobalResponseNormalizationOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    scale: TensorIndex
    bias: TensorIndex
    epsilon: float32
    channel_last: bool = True

@OptionsRegistry.register(LayerType.Pow)
@dataclasses.dataclass
class PowOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    exponent: float32

@OptionsRegistry.register(LayerType.QuickGelu)
@dataclasses.dataclass
class QuickGeluOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.ReduceL2)
@dataclasses.dataclass
class ReduceL2Options(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    keep_dims: bool
    reduce_axes: Tuple[int32, ...]
    noop_with_empty_axes: int32

@OptionsRegistry.register(LayerType.ReduceMax)
@dataclasses.dataclass
class ReduceMaxOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    keep_dims: bool
    reduce_axes: Tuple[int32, ...]
    noop_with_empty_axes: int32

@OptionsRegistry.register(LayerType.ReduceMin)
@dataclasses.dataclass
class ReduceMinOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    keep_dims: bool
    reduce_axes: Tuple[int32, ...]
    noop_with_empty_axes: int32

@OptionsRegistry.register(LayerType.ReduceMean)
@dataclasses.dataclass
class ReduceMeanOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    keep_dims: bool
    reduce_axes: Tuple[int32, ...]
    noop_with_empty_axes: int32

@OptionsRegistry.register(LayerType.ReduceProd)
@dataclasses.dataclass
class ReduceProdOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    keep_dims: bool
    reduce_axes: Tuple[int32, ...]
    noop_with_empty_axes: int32

@OptionsRegistry.register(LayerType.ReduceSum)
@dataclasses.dataclass
class ReduceSumOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    keep_dims: bool
    reduce_axes: Tuple[int32, ...]
    noop_with_empty_axes: int32

@OptionsRegistry.register(LayerType.ReduceRMS)
@dataclasses.dataclass
class ReduceRMSOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    keep_dims: bool
    reduce_axes: Tuple[int32, ...]
    epsilon: Optional[float32] = None

@OptionsRegistry.register(LayerType.MeanCentering)
@dataclasses.dataclass
class MeanCenteringOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axes: Tuple[int32, ...]

@OptionsRegistry.register(LayerType.Relu)
@dataclasses.dataclass
class ReluOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.RepeatN)
@dataclasses.dataclass
class RepeatNOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: int32
    repeat: int32

@OptionsRegistry.register(LayerType.Reshape)
@dataclasses.dataclass
class ReshapeOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    new_shape: Optional[Tuple[int32, ...]] = None
    allowzero: int32 = 0
    is_const_first: bool = False

@OptionsRegistry.register(LayerType.ReshapeV2)
@dataclasses.dataclass
class ReshapeV2Options(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    allowzero: int32 = 0
    is_const_first: bool = False

@OptionsRegistry.register(LayerType.Resize)
@dataclasses.dataclass
class ResizeOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    resize_type: Optional[str] = None
    resize_mode: Optional[str] = None
    nearest_mode: Optional[str] = None
    transform_mode: Optional[str] = None
    roi: Optional[Tuple[int32, ...]] = None
    scales: Optional[Tuple[float32, ...]] = None
    sizes: Optional[Tuple[int32, ...]] = None
    cubic_coeff_a: Optional[float32] = None
    exclude_outside: Optional[int32] = None
    extrapolation_value: Optional[float32] = None
    antialias: Optional[int32] = None
    axes: Optional[Tuple[int32, ...]] = None
    keep_aspect_ratio_policy: Optional[str] = None

@OptionsRegistry.register(LayerType.RmsNormalization)
@dataclasses.dataclass
class RmsNormalizationOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    epsilon: TensorIndex
    scale: TensorIndex
    normalized_shape: Tuple[int64, ...] = ()
    rms_center: TensorIndex = -1

@OptionsRegistry.register(LayerType.RotaryEmbedding)
@dataclasses.dataclass
class RotaryEmbeddingOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32, int32]
    inv_freq: TensorIndex
    attention_scaling: float32

@OptionsRegistry.register(LayerType.Rsqrt)
@dataclasses.dataclass
class RsqrtOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.Rstd)
@dataclasses.dataclass
class RstdOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    reduce_axes: Tuple[int32, ...]
    epsilon: TensorIndex
    num_groups: int32 = 1

@OptionsRegistry.register(LayerType.ScalarInt)
@dataclasses.dataclass
class ScalarIntOptions(LayerOptions, TypeEnforcedMixin):
    outputs: Tuple[int32]
    value: int64
    inputs: Tuple = ()

@OptionsRegistry.register(LayerType.ScalarStr)
@dataclasses.dataclass
class ScalarStrOptions(LayerOptions, TypeEnforcedMixin):
    outputs: Tuple[int32]
    value: str
    inputs: Tuple = ()

@OptionsRegistry.register(LayerType.Gather)
@dataclasses.dataclass
class GatherOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    axis: int32 = 0

@OptionsRegistry.register(LayerType.GatherElements)
@dataclasses.dataclass
class GatherElementsOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    axis: int32 = 0

@OptionsRegistry.register(LayerType.ScatterND)
@dataclasses.dataclass
class ScatterNDOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    constant_data: TensorIndex = -1
    constant_indices: TensorIndex = -1

@OptionsRegistry.register(LayerType.Selu)
@dataclasses.dataclass
class SeluOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.Shape)
@dataclasses.dataclass
class ShapeOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    start: Optional[int32] = None
    end: Optional[int32] = None

@OptionsRegistry.register(LayerType.TensorAttribute)
@dataclasses.dataclass
class TensorAttributeOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    attr: str

@OptionsRegistry.register(LayerType.Sigmoid)
@dataclasses.dataclass
class SigmoidOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    alpha: float32 = 1.0

@OptionsRegistry.register(LayerType.Slice)
@dataclasses.dataclass
class SliceOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: Tuple[int32, ...]
    start: Tuple[int64, ...]
    end: Tuple[int64, ...]
    step: Optional[Tuple[int64, ...]] = None

@OptionsRegistry.register(LayerType.Softmax)
@dataclasses.dataclass
class SoftmaxOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: int32
    beta: float32 = 1.0

@OptionsRegistry.register(LayerType.LogSoftmax)
@dataclasses.dataclass
class LogSoftmaxOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: int32

@OptionsRegistry.register(LayerType.Softplus)
@dataclasses.dataclass
class SoftplusOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    beta: float32 = 1.0
    threshold: float32 = 20.0

@OptionsRegistry.register(LayerType.Softsign)
@dataclasses.dataclass
class SoftsignOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.Sqrt)
@dataclasses.dataclass
class SqrtOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.StaggeredPadding)
@dataclasses.dataclass
class StaggeredPaddingOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: int32 = 3
    reverse: bool = False
    window_size: int32 = -1

@OptionsRegistry.register(LayerType.StatefulAttentionMaskWrapper)
@dataclasses.dataclass
class StatefulAttentionMaskWrapperOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    past_seqlen: int32 = 0
    is_sliding: bool = False
    sliding_window: int32 = 1024
    mask_type: str = "causal_mask"

@OptionsRegistry.register(LayerType.StatefulKVCacheWrapper)
@dataclasses.dataclass
class StatefulKVCacheWrapperOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    cache_name: str
    past_seqlen: int32 = 0
    is_sliding: bool = False
    sliding_window: int32 = 1024
    max_cache_len: int32 = 8192

@OptionsRegistry.register(LayerType.StatefulCachedStack)
@dataclasses.dataclass
class StatefulCachedStackOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    cache_name: str
    axis: int32 = 2
    cache_len: int32 = 0

@OptionsRegistry.register(LayerType.StatefulLSTMWrapper)
@dataclasses.dataclass
class StatefulLSTMWrapperOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, int32, int32]
    W: TensorIndex
    R: TensorIndex
    input_mask: str
    output_mask: str
    hidden_size: int32
    hidden_state_name: str
    cell_state_name: str
    subgraph: str
    B: TensorIndex = -1
    P: TensorIndex = -1
    direction: str = "forward"
    batch_first: bool = False
    activation_alpha: Optional[Tuple[float32, ...]] = None
    activation_beta: Optional[Tuple[float32, ...]] = None
    activations: Optional[Tuple[str, ...]] = None
    clip: Optional[float32] = None
    input_forget: bool = False

@OptionsRegistry.register(LayerType.StatefulRNNWrapper)
@dataclasses.dataclass
class StatefulRNNWrapperOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, int32]
    W: TensorIndex
    R: TensorIndex
    input_mask: str
    output_mask: str
    hidden_size: int32
    hidden_state_name: str
    subgraph: str
    B: TensorIndex = -1
    direction: str = "forward"
    batch_first: bool = False
    activation_alpha: Optional[Tuple[float32, ...]] = None
    activation_beta: Optional[Tuple[float32, ...]] = None
    activations: Optional[Tuple[str, ...]] = None
    clip: Optional[float32] = None

@OptionsRegistry.register(LayerType.StatefulGRUWrapper)
@dataclasses.dataclass
class StatefulGRUWrapperOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, int32]
    W: TensorIndex
    R: TensorIndex
    input_mask: str
    output_mask: str
    hidden_size: int32
    hidden_state_name: str
    subgraph: str
    B: TensorIndex = -1
    direction: str = "forward"
    batch_first: bool = False
    activation_alpha: Optional[Tuple[float32, ...]] = None
    activation_beta: Optional[Tuple[float32, ...]] = None
    activations: Optional[Tuple[str, ...]] = None
    clip: Optional[float32] = None
    linear_before_reset: bool = False

@OptionsRegistry.register(LayerType.StatefulRoPEWrapper)
@dataclasses.dataclass
class StatefulRoPEWrapperOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, int32, int32]
    outputs: Tuple[int32]
    rope_type: int32 = 0
    seqlen: int32 = 0
    rotary_emb_dim: int32 = 0

@OptionsRegistry.register(LayerType.SubConstant)
@dataclasses.dataclass
class SubConstantOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    constant: TensorIndex
    is_const_first: bool
    shape: Tuple[int32, ...] = ()

@OptionsRegistry.register(LayerType.Sub)
@dataclasses.dataclass
class SubOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.Swish)
@dataclasses.dataclass
class SwishOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.Tanh)
@dataclasses.dataclass
class TanhOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.Sin)
@dataclasses.dataclass
class SinOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.Cos)
@dataclasses.dataclass
class CosOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.TemporaryNode)
@dataclasses.dataclass
class TemporaryNodeOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, ...]
    description: str

@OptionsRegistry.register(LayerType.TransposeConvolution)
@dataclasses.dataclass
class TransposeConvolutionOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    in_channels: int32
    out_channels: int32
    h_kernel: int32
    w_kernel: int32
    h_stride: int32
    w_stride: int32
    h_dilation: int32
    w_dilation: int32
    west_padding: int32
    east_padding: int32
    north_padding: int32
    south_padding: int32
    group_number: int32
    weight: TensorIndex
    padding_list: Tuple[int32, ...] = ()
    og_padding_list: Tuple[int32, ...] = ()
    og_out_padding_list: Tuple[int32, ...] = ()
    bias: TensorIndex = -1
    channel_last: bool = True

@OptionsRegistry.register(LayerType.Transpose)
@dataclasses.dataclass
class TransposeOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    transpose_axes: Tuple[int64, ...]

@OptionsRegistry.register(LayerType.Unsqueeze)
@dataclasses.dataclass
class UnsqueezeOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axes: Tuple[int32, ...]

@OptionsRegistry.register(LayerType.OrderedPatchify)
@dataclasses.dataclass
class OrderedPatchifyOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    h_kernel: int32
    w_kernel: int32
    order: int32 = 0

@OptionsRegistry.register(LayerType.DynamicSliceInputConst)
@dataclasses.dataclass
class DynamicSliceInputConstOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    mod: int32
    start: Tuple[int64, ...]
    end: Tuple[int64, ...]
    axis: Tuple[int64, ...]
    step: Optional[Tuple[int64, ...]] = None

@OptionsRegistry.register(LayerType.RelShift)
@dataclasses.dataclass
class RelShiftOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.MeloTTSPiecewiseRationalQuadraticTransform)
@dataclasses.dataclass
class MeloTTSPiecewiseRationalQuadraticTransformOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    num_bins: int32
    filter_channels: int32
    tail_bound: float32
    reverse: bool

@OptionsRegistry.register(LayerType.IndexedItemSelector)
@dataclasses.dataclass
class IndexedItemSelectorOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: int32 = 3
    index: TensorIndex = -1
    scale: TensorIndex = -1
    bias: TensorIndex = -1
    start: Optional[int32] = None
    end: Optional[int32] = None
    step: Optional[int32] = None
    repeat: Optional[int32] = None

@OptionsRegistry.register(LayerType.ChannelwiseApply)
@dataclasses.dataclass
class ChannelwiseApplyOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    func: TensorIndex
    group_number: int32 = 1
    input_scale: TensorIndex = -1
    input_bias: TensorIndex = -1
    output_scale: TensorIndex = -1
    output_bias: TensorIndex = -1

@OptionsRegistry.register(LayerType.Neg)
@dataclasses.dataclass
class NegOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.Einsum)
@dataclasses.dataclass
class EinsumOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]
    equation: str
    constant: TensorIndex = -1
    is_const_first: bool = False

@OptionsRegistry.register(LayerType.RotateHalf)
@dataclasses.dataclass
class RotateHalfOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    type: int32 = 0

@OptionsRegistry.register(LayerType.Where)
@dataclasses.dataclass
class WhereOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, int32, int32]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.TensorCmp)
@dataclasses.dataclass
class TensorCmpOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    kind: str = "eq"

@OptionsRegistry.register(LayerType.MaskedFill)
@dataclasses.dataclass
class MaskedFillOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32]
    value: float32

@OptionsRegistry.register(LayerType.SubgraphCall)
@dataclasses.dataclass
class SubgraphCallOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, ...]
    subgraph: str
    scope: str
    kind: str

@OptionsRegistry.register(LayerType.SubgraphScope)
@dataclasses.dataclass
class SubgraphScopeOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, ...]
    subgraph: str
    scope: str
    kind: str
    mode: str = "start"

@OptionsRegistry.register(LayerType.MoeDispatcher)
@dataclasses.dataclass
class MoeDispatcherOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, int32]
    outputs: Tuple[int32, int32]
    top_k: int32
    norm_top_k_prob: bool = True

@OptionsRegistry.register(LayerType.MoeAggregator)
@dataclasses.dataclass
class MoeAggregatorOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32]

@OptionsRegistry.register(LayerType.ChannelFactorSlice)
@dataclasses.dataclass
class ChannelFactorSliceOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    factor_shape: Tuple[int32, ...]
    axis: int32
    start: int32
    end: int32
    step: int32

@OptionsRegistry.register(LayerType.TopKValues)
@dataclasses.dataclass
class TopKValuesOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: int32
    k: int32 = 1
    largest: bool = True
    sorted: bool = True

@OptionsRegistry.register(LayerType.TopKIndices)
@dataclasses.dataclass
class TopKIndicesOptions(LayerOptions, TypeEnforcedMixin):
    inputs: Tuple[int32]
    outputs: Tuple[int32]
    axis: int32
    k: int32 = 1
    largest: bool = True
    sorted: bool = True
