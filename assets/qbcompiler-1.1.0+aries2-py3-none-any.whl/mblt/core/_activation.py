from __future__ import annotations

import functools
import operator
from typing import Any, List, TYPE_CHECKING

import numpy

from ._types import SHAPELIKE, DataFormat, Shape

if TYPE_CHECKING:
    from ._operator import Operator


__all__ = ["ActivationSpec"]


class _ValueNotSet:
    def __repr__(self):
        return "<ValueNotSet>"

    def __bool__(self):
        raise ValueError("Cannot determine truth value because the value is not set")

    @property
    def value(self):
        return None


# We need to use special object to denote the state of a value not being set, since `None` is also instance of `NoneType` in python.
ValueNotSet = _ValueNotSet()


class ActivationSpec:
    def __init__(
        self,
        name: str,
        dtype: str,
        src_shape: SHAPELIKE,
        dataformat: DataFormat = DataFormat.UNKNOWN,
    ):
        self.name = name
        self.dtype = dtype
        self._src_shape = Shape(src_shape)
        self.dataformat = dataformat
        self._value: Any = ValueNotSet
        
        if len(src_shape) == 4:
            self.dataformat = DataFormat.NHWC # default dataformat is NHWC for 4D shape, even if N is not 1,
            # dataformat should be NHWC, regardless of the whether the operator is supported or unsupported.

        if dataformat != DataFormat.UNKNOWN:
            if len(dataformat.name) != len(src_shape):
                raise ValueError(
                    f"dataformat is {dataformat.name} but src_shape={src_shape}"
                )


        # The following fields are used in intermediate parsing steps and will not be serialized.

        # Operator that generate this activation as output.
        self.producer_op = None
        # Operators that take this activation as input.
        self.consumer_ops: List[Operator] = []

    def __repr__(self):
        return f"{self.dtype}({self._src_shape}), name={self.name}, has_value={self.has_value}"

    @property
    def has_value(self):
        return self._value is not ValueNotSet

    def set_value(self, value):
        value_shape = getattr(value, "shape", None) # if value is not torch like tensor, DynamicCache or more complex object, it will not have shape attribute
        if value_shape is not None and self.src_shape != value_shape:
            raise ValueError(
                f"set value failed. shape mismatch: {self.src_shape} vs {value.shape}"
            )
        self._value = value

    def release_value(self):
        self._value = ValueNotSet

    @property
    def value(self):
        return self._value

    def copy(self, name=None, dtype=None, src_shape=None, dataformat=None):
        if name is None:
            name = self.name
        if dtype is None:
            dtype = self.dtype
        if src_shape is None:
            src_shape = self.src_shape
        if dataformat is None:
            dataformat = self.dataformat
        return ActivationSpec(
            name=name, dtype=dtype, src_shape=src_shape, dataformat=dataformat
        )

    @property
    def src_shape(self):
        return self._src_shape

    def update_shape(self, new_shape: SHAPELIKE):
        if not isinstance(new_shape, Shape):
            new_shape = Shape(new_shape)
        self._src_shape = new_shape

    @property
    def src_dim(self):
        return len(self.src_shape)

    def is_supported(self):
        return self.dataformat == DataFormat.NHWC and self.src_dim == 4 and self.src_shape[0] == 1

    def tensorsize(self) -> int:
        return (
            int(functools.reduce(operator.mul, self.src_shape, 1))
            * numpy.dtype(self.dtype).itemsize
        )

    def copy(self, name=None, dtype=None, src_shape=None, dataformat=None, **kwargs):
        # to support copy method for subtype of ActivaionSpec
        return type(self)(
            name or self.name,
            dtype or self.dtype,
            src_shape or self.src_shape,
            dataformat or self.dataformat,
        )

    def to_dict(self):
        default_shape = Shape((0,0,0)) # shape field is not used when activation has unsupported source shape.
        return {
            "cls": self.__class__.__name__,
            "name": self.name,
            "dtype": self.dtype,
            "shape": self.src_shape[1:].to_dict() if self.is_supported() else default_shape.to_dict(),
            "src_shape": self.src_shape.to_dict(),
            "dataformat": self.dataformat.name,
        }

    @classmethod
    def from_dict(cls, data: dict):
        return cls(
            name=data["name"],
            dtype=data["dtype"],
            src_shape=Shape.from_dict(data["src_shape"]),
            dataformat=DataFormat.from_dict(data["dataformat"]),
        )
