# Public exports for mblt.core

from mblt.logger import get_logger
from ._activation import ActivationSpec
from ._array_wrapper import ArrayWrapper
from ._operator import Operator, OperatorRegistry
from ._options import LayerOptions, replace_options
from ._optionsimpl import LayerType, OptionsRegistry
from ._subgraph import SubGraph
from ._tensor import TensorSpec
from ._transform import (
    OperatorTransformResult_T,
    OperatorTransformResult,
    RuleSet,
    RuleCase,
    pattern,
    TransformRule,
    OpTransformResultBuilder,
)
from ._types import DimValue, Shape, DataFormat, SHAPELIKE, DIMLIKE, TensorIndex, int32
from ._types import int32

# here we keep copy of original LayerType that is not extended.
# deepcopy on class objects does not create an independent class.
# Use enum snapshot to create a distinct, frozen copy.
# This is not runtime LayerType. only used for specific cases.
MBLT_DEFINED_LAYERTYPE = LayerType.snapshot(name="MBLT_DEFINED_LAYERTYPE", frozen=True)
MBLT_DEFINED_LAYERTYPE_NAMES = frozenset(MBLT_DEFINED_LAYERTYPE.__members__.keys())
TRANSFORM_RULE_TARGET_LAYERTYPE_NAMES = set(MBLT_DEFINED_LAYERTYPE_NAMES)


def register_transform_rule_layertype(type_name: str):
    """Allow a dynamically added layertype to participate in transform rules."""
    TRANSFORM_RULE_TARGET_LAYERTYPE_NAMES.add(type_name)

# Dynamically add CONNECTION_OP to LayerType for use as an intermediate type during graph transformation.
# FIXME: Should this be defined here? It might be better to manage LayerType within a valid
#  context for each subgraph to avoid polluting the global namespace.
LayerType.add("_CONNECTION_OP")

LOGGER = get_logger(__name__)


__all__ = [
    "ActivationSpec",
    "ArrayWrapper",
    "LayerOptions",
    "LayerType",
    "OptionsRegistry",
    "TensorSpec",
    "TensorIndex",
    "DimValue",
    "Shape",
    "DataFormat",
    "SHAPELIKE",
    "DIMLIKE",
    "replace_options",
    "Operator",
    "OperatorRegistry",
    "OperatorTransformResult",
    "OperatorTransformResult_T",
    "OpTransformResultBuilder",
    "RuleSet",
    "RuleCase",
    "pattern",
    "TransformRule",
    "SubGraph",
    "MBLT_DEFINED_LAYERTYPE_NAMES",
    "MBLT_DEFINED_LAYERTYPE",
    "TRANSFORM_RULE_TARGET_LAYERTYPE_NAMES",
    "register_transform_rule_layertype",
]
