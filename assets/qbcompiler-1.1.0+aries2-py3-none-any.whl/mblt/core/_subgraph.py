import collections
import dataclasses
import itertools
from typing import List

from mblt.logger import get_logger
from ._activation import ActivationSpec
from ._operator import Operator
from ._optionsimpl import LayerType
from ._tensor import TensorSpec
from ._types import Shape, TensorIndex
from .util import to_dict_helper

LOGGER = get_logger(__name__)

_DEBUG_MODE = False

if _DEBUG_MODE:
    LOGGER.setLevel("DEBUG")


class ObservableStack(list):
    def append(self, item):
        LOGGER.debug(f"[STACK] append: {item}")
        super().append(item)

    def extend(self, items):
        items_list = list(items)
        LOGGER.debug(f"[STACK] extend: {items_list}")
        super().extend(items_list)

    def pop(self, *args, **kwargs):
        item = super().pop(*args, **kwargs)
        LOGGER.debug(f"[STACK] pop: {item}")
        return item

    def __repr__(self):
        return f"ObservableStack({super().__repr__()})"


class IntSet(set):
    def add(self, item):
        super().add(int(item))

    def update(self, items):
        for item in items:
            self.add(item)


def _get_unique_name(candidate: str, existing_names):
    i = 0
    while True:
        nc = candidate + "_" + str(i)
        if nc not in existing_names:
            return nc
        i += 1


_INPUT_KIND = {
    LayerType.Input,
}

for x in ("AttentionMaskInput", "KVCacheInput"):
    if x in LayerType:
        _INPUT_KIND.add(LayerType[x])
_INPUT_KIND = frozenset(_INPUT_KIND)


class IntSet(set):
    def add(self, item):
        super().add(int(item))

    def update(self, items: IntSet):
        super().update(items)


class SubGraph:
    def __init__(
        self,
        idx: int = -1,
        name: str = "",
        operators: List[Operator] = None,
        tensors: List[TensorSpec] = None,
        inputs: List[int] = None,
        outputs: List[int] = None,
        activations: List[ActivationSpec] = None,
        unsupported: bool = True,
        stateful: bool = False,
        **kwargs,
    ):
        self.idx = idx
        self.name = name
        self.operators: List[Operator] = operators
        self.activations: List[ActivationSpec] = activations
        self.tensors: List[TensorSpec] = tensors
        self.inputs: List[int] = inputs
        self.outputs: List[int] = outputs
        self.unsupported = unsupported
        self.stateful = stateful

        # fields for intermediate parsing steps
        self._all_activation_names = {}
        self._all_tensor_names = {}
        self._connection_op = None

    def init_all_activation_names(self):
        self._all_activation_names.clear()
        for idx, act in enumerate(self.activations):
            self._all_activation_names[act.name] = idx
        if len(self._all_activation_names) != len(self.activations):
            cnt = set()
            for a in self.activations:
                if a.name not in cnt:
                    cnt.add(a.name)
                else:
                    raise Exception(f"duplicate activation name exists: {a.name}")
            raise Exception("len(self._all_activation_names) != len(self.activations)")

    def init_all_tensor_names(self):
        self._all_tensor_names.clear()
        for idx, tensor in enumerate(self.tensors):
            self._all_tensor_names[tensor.name] = idx
        if len(self._all_tensor_names) != len(self.tensors):
            raise Exception(
                f"len(self._all_tensor_names){len(self._all_tensor_names)} != len(self.tensors){len(self.tensors)}"
            )

    def init_all_act_tensor_names(self):
        self.init_all_activation_names()
        self.init_all_tensor_names()

    def __repr__(self):
        return f"{self.name}, idx={self.idx}, unsupported={self.unsupported}, num_ops={len(self.operators)}"

    def __str__(self):
        """
        Return a Graph-IR representation of the SubGraph.
        Shows the computational graph structure with operations, tensor shapes, and connections.
        """
        lines = []

        # Header
        lines.append("=" * 80)
        lines.append(f"SubGraph: {self.name}")
        lines.append(f"  Index: {self.idx}")
        lines.append(f"  Unsupported: {self.unsupported}")
        lines.append(f"  Stateful: {self.stateful}")
        lines.append(f"  Operators: {len(self.operators) if self.operators else 0}")
        lines.append(f"  Tensors: {len(self.tensors) if self.tensors else 0}")
        lines.append(
            f"  Activations: {len(self.activations) if self.activations else 0}"
        )
        lines.append("=" * 80)
        lines.append("")

        def _delete_type_sig(x):
            if isinstance(x, int):
                return int(x)
            if isinstance(x, float):
                return float(x)
            if isinstance(x, (list, tuple)):
                return type(x)(map(_delete_type_sig, x))
            return x

        SHORT_DT = {
            "bfloat16": "bf16",
            "float16": "fp16",
            "float32": "fp32",
            "float64": "fp64",
            "int8": "i8",
            "int16": "i16",
            "int32": "i32",
            "int64": "i64",
            "uint8": "u8",
            "uint16": "u16",
            "uint32": "u32",
            "uint64": "u64",
        }

        def short_dtype(dtype):
            return SHORT_DT.get(dtype.lower(), dtype)

        def _act_dt_shape(x):
            return f"{short_dtype(x.dtype)}[{','.join(map(str, x.src_shape))}]"

        # Graph inputs
        if self.inputs:
            lines.append("Graph Inputs:")
            for inp_idx in self.inputs:
                act = self.activations[inp_idx]
                lines.append(
                    f"  %{int(inp_idx)} : {_act_dt_shape(act)}  # '{act.name}'"
                )
            lines.append("")

        # Operators
        if self.operators:
            lines.append("Operations:")
            for op_idx, op in enumerate(self.operators):
                if op.layertype in (LayerType.Input, LayerType.Output):
                    continue
                # Get input activation info
                if hasattr(op.options, "inputs"):
                    input_strs = [f"%{int(x)}" for x in op.options.inputs]
                else:
                    input_strs = []

                # Get output activation info
                indices = []
                shapes = []
                if hasattr(op.options, "outputs"):
                    for out in op.options.outputs:
                        indices.append(f"%{int(out)}")
                        shapes.append(_act_dt_shape(self.activations[out]))

                # Build operation line
                # fmt: off
                inputs_str = "(" + ", ".join(input_strs) + (",)" if len(input_strs) == 1 else ")")
                # fmt: on
                if indices:
                    outputs_str = f"{', '.join(indices)} : {','.join(shapes)}"
                else:
                    outputs_str = ""

                op_line = f"  {outputs_str} = {op.layertype.name}(inputs={inputs_str}"

                # Add all option values in a single line
                option_attrs = []
                for field in dataclasses.fields(op.options):
                    field_name = field.name
                    # Skip inputs and outputs as they're already in the signature
                    if field_name in ("inputs", "outputs"):
                        continue

                    field_value = getattr(op.options, field_name)

                    # Format tensor indices with shape info if available
                    if field_value.__class__.__name__ == "TensorIndex":
                        if field_value < 0:
                            option_attrs.append(f"{field_name}={None}")
                        else:
                            tensor = self.tensors[field_value]
                            option_attrs.append(
                                f"{field_name}={short_dtype(tensor.dtype)}[{','.join(map(str, tensor.shape))}]"
                            )
                        continue

                    # Regular field - just show the value
                    option_attrs.append(f"{field_name}={_delete_type_sig(field_value)}")

                if option_attrs:
                    op_line += f", {', '.join(option_attrs)}"
                op_line += ")"
                op_line += f"\t# '{op.name}'"
                lines.append(op_line)
            lines.append("")

        # Graph outputs
        if self.outputs:
            lines.append("Graph Outputs:")
            for out_idx in self.outputs:
                act = self.activations[out_idx]
                lines.append(f"  %{out_idx} : {_act_dt_shape(act)}  # '{act.name}'")
            lines.append("")

        lines.append("=" * 80)

        return "\n".join(lines)

    def summary(self):
        num_ops = len(self.operators) if self.operators else 0
        num_unsupported = (
            sum(1 for op in self.operators if op.unsupported) if self.operators else 0
        )
        num_supported = num_ops - num_unsupported
        return {
            "sg_name": self.name,
            "num_ops": num_ops,
            "num_supported": num_supported,
            "num_unsupported": num_unsupported,
            "input_names": self.input_names,
            "output_names": self.output_names,
        }

    def get_operator_support_info(self):
        return {
            "sg_idx": self.idx,
            "sg_name": self.name,
            "sg_unsupported": self.unsupported,
            "operators": [
                {
                    "name": op.name,
                    "layertype": op.layertype.name,
                    "unsupported": op.unsupported,
                }
                for op in self.operators
            ],
        }

    def to_dict(self):
        # Build operator identity→index map so next_operators can be
        # serialized as integer indices (required by C++ parser).
        op_id_to_idx = {id(op): idx for idx, op in enumerate(self.operators)}

        serialized_operators = list()
        for op in self.operators:
            d = op.to_dict()
            # Convert next_operator names → integer indices
            try:
                next_ops = op.next_operators
                d["next_operators"] = [op_id_to_idx[id(nop)] for nop in next_ops]
            except RuntimeError:
                # Subgraph connectivity not set up; leave as empty list
                d["next_operators"] = []
            serialized_operators.append(d)

        return {
            "cls": self.__class__.__name__,
            "idx": self.idx,
            "name": self.name,
            "operators": serialized_operators,
            "tensors": to_dict_helper(self.tensors),
            "inputs": to_dict_helper(self.inputs),
            "outputs": to_dict_helper(self.outputs),
            "activations": to_dict_helper(self.activations),
            "unsupported": self.unsupported,
            "stateful": self.stateful,
        }

    def _legacy_support_fix(self):
        for op in self.operators:
            if op.layertype == LayerType.HeaderView:
                if op.options.num_heads == -1 and op.options.view_shape:
                    inact = op.inacts[0]
                    num_heads = int(inact.src_shape[-1] // op.options.view_shape[-1])
                    op.options = dataclasses.replace(op.options, num_heads=num_heads)

    @classmethod
    def from_dict(cls, data):
        is_legacy = "cls" not in data
        # lazy import.
        operators = [Operator.from_dict(x) for x in data["operators"]]
        obj = cls(
            idx=data["idx"],
            name=data["name"],
            operators=operators,
            tensors=[TensorSpec.from_dict(x) for x in data["tensors"]],
            inputs=data["inputs"],
            outputs=data["outputs"],
            activations=[ActivationSpec.from_dict(x) for x in data["activations"]],
            unsupported=data["unsupported"],
        )
        for op in obj.operators:
            op.set_subgraph(obj)
        obj._legacy_support_fix()
        return obj

    @property
    def input_names(self):
        return [self.activations[i].name for i in self.inputs]

    @property
    def output_names(self):
        return [self.activations[i].name for i in self.outputs]

    def is_terminal_node(self, op):
        return op.layertype == LayerType.Output or (
            op.layertype == LayerType.DeviceBridge
            and op.options.outputs[0] in self.outputs
        )

    def is_root_node(self, op):
        return op.layertype == LayerType.Input or (
            op.layertype == LayerType.DeviceBridge
            and op.options.inputs[0] in self.inputs
        )

    def get_reverse_op_depth(self):
        """
        Calculate the depth of each operator in the forward direction.
        Depth represents the distance from input nodes (depth 0) to each operator.
        Output layers have depth = parent_depth + 1.

        Returns:
            dict: Mapping from operator to its depth value
        """
        reverse_graph = collections.defaultdict(list)
        depth = collections.defaultdict(int)

        q = collections.deque()
        for parent in self.operators:
            # Layer of the type Output has the same name as the preceding layer.
            if parent.layertype != LayerType.Output:
                for oact in parent.outacts:
                    for child in oact.consumer_ops:
                        reverse_graph[child].append(parent)
            if self.is_terminal_node(parent):
                q.append(parent)
                depth[parent] = -1 if parent.layertype == LayerType.Output else 0

        visited = set()
        while q:
            curr_op = q.popleft()
            if curr_op in visited:
                continue
            visited.add(curr_op)
            curr_depth = depth[curr_op]
            for parent in reverse_graph[curr_op]:
                depth[parent] = max(depth[parent], curr_depth + 1)
                q.append(parent)

        depth_max = max(depth.values())
        for k in depth.keys():
            depth[k] = depth_max - depth[k]

        for k in depth.keys():
            if k.layertype == LayerType.Output:
                depth[k] = depth[reverse_graph[k][0]] + 1
        return depth

    #
    # def sort_operators(self):
    #     sorted_ops = [None] * len(self.operators)
    #     generated_act_indices = set()
    #     op_depths = self.get_reverse_op_depth()
    #     sorted_cnt = 0
    #     nodes_in_stack = set()  # add-add 구조에서 무한루프 발생 방지용.
    #
    #     def visit_operator(stk, nodes_in_stack, op: Operator):
    #         nonlocal sorted_cnt
    #         sorted_ops[sorted_cnt] = op
    #         sorted_cnt += 1
    #
    #         if self.is_terminal_node(op):
    #             return
    #
    #         for oidx in reversed(op.options.outputs):
    #             generated_act_indices.add(oidx)
    #             filtered = (
    #                 cop
    #                 for cop in self.activations[oidx].consumer_ops
    #                 if (
    #                     cop.layertype == LayerType.Output
    #                     or cop.options.outputs[0] not in generated_act_indices
    #                 )
    #                 and cop not in nodes_in_stack
    #             )
    #             # Deeper operators processed last in stack
    #             to_add = sorted(
    #                 filtered, key=lambda cop: op_depths[cop.name], reverse=True
    #             )
    #             for item in to_add:
    #                 stk.append(item)
    #                 nodes_in_stack.add(item)
    #
    #     def get_stk():
    #         LOGGER.debug(f"[SORT OPS] get_stk()")
    #         if _DEBUG_MODE:
    #             stk = ObservableStack()
    #         else:
    #             stk = []
    #         if sorted_cnt == 0:
    #             for x in reversed(self.inputs):  # 여기 왜 reversed했지?
    #                 inact = self.activations[x]
    #                 if inact.producer_op is None:
    #                     # fixme: subgraph inputs may not have input layers in unsupported subgraph.
    #                     for cop in inact.consumer_ops:
    #                         stk.append(cop)
    #                     generated_act_indices.add(x)
    #                 elif inact.producer_op.layertype in (
    #                     LayerType.Input,
    #                     LayerType.DeviceBridge,
    #                 ):
    #                     stk.append(inact.producer_op)
    #         else:
    #             # multiple components로 구성된 graph의 경우 input_const로 시작하면 한번에 방문이 불가능 함.
    #             already_sorted = {x for x in sorted_ops if x is not None}
    #             for op in self.operators:
    #                 if op not in already_sorted:
    #                     if op.layertype == LayerType.InputConstant:
    #                         stk.append(op)
    #         return stk
    #
    #     def can_visit_operator(op: Operator) -> bool:
    #         """Check if all input dependencies are satisfied."""
    #         return op.layertype == LayerType.InputConstant or set(
    #             op.options.inputs
    #         ).issubset(generated_act_indices)
    #
    #     def is_visited(op):
    #         return (
    #             op.options.outputs[0] in generated_act_indices
    #             and op.layertype != LayerType.Output
    #         )
    #
    #     while sorted_cnt < len(sorted_ops):
    #         LOGGER.debug(
    #             f"[SORT OPS] sorted_cnt={sorted_cnt}, len(sorted_ops)={len(sorted_ops)}"
    #         )
    #         stk = get_stk()
    #         nodes_in_stack.clear()
    #         for item in stk:
    #             nodes_in_stack.add(item)
    #
    #         if not stk:
    #             invalid_ops = [x for x in self.operators if not x.valid]
    #             raise RuntimeError(
    #                 f"Failed to sort operators: graph may contain invalid op nodes: {invalid_ops}"
    #             )
    #
    #         if _DEBUG_MODE:
    #             while stk:
    #                 op = stk.pop()
    #                 nodes_in_stack.discard(op)
    #                 if is_visited(op):
    #                     LOGGER.debug(f"[SORT OPS] visited op={op.name}")
    #                     continue
    #                 if can_visit_operator(op) or self.is_root_node(op):
    #                     LOGGER.debug(f"[SORT OPS] visit op={op.name}")
    #                     visit_operator(stk, nodes_in_stack, op)
    #                 else:
    #                     LOGGER.debug(f"[SORT OPS] skip op={op.name}")
    #                     for iidx in op.options.inputs:
    #                         if (
    #                             iidx not in generated_act_indices
    #                             and self.activations[iidx].producer_op is not None
    #                         ):
    #                             parent = self.activations[iidx].producer_op
    #                             if parent not in nodes_in_stack:
    #                                 stk.append(parent)
    #                                 nodes_in_stack.add(parent)
    #         else:
    #             while stk:
    #                 op = stk.pop()
    #                 nodes_in_stack.discard(op)
    #                 if is_visited(op):
    #                     continue
    #                 if can_visit_operator(op) or self.is_root_node(op):
    #                     LOGGER.debug(f"[SORT OPS] visit op={op.name}")
    #                     visit_operator(stk, nodes_in_stack, op)
    #                 else:
    #                     for iidx in op.options.inputs:
    #                         if (
    #                             iidx not in generated_act_indices
    #                             and self.activations[iidx].producer_op is not None
    #                         ):
    #                             parent = self.activations[iidx].producer_op
    #                             if parent not in nodes_in_stack:
    #                                 stk.append(parent)
    #                                 nodes_in_stack.add(parent)
    #     # sanity check
    #     if sorted_cnt != len(self.operators):
    #         raise Exception(
    #             f"op_cnt != len(self.operators), {sorted_cnt}!={len(self.operators)}"
    #         )
    #     LOGGER.debug(
    #         f"[SORT OPS] sorted_cnt={sorted_cnt}, len(sorted_ops)={len(sorted_ops)}"
    #     )
    #     self.operators = sorted_ops

    def sort_operators(self):
        in_degree = collections.defaultdict(int)
        consumers = collections.defaultdict(list)
        input_acts = []
        on_demand_ops = set()

        act_to_producer = {}
        for op in self.operators:
            if not op.valid:
                raise RuntimeError(
                    f"Failed to sort operators: graph may contain invalid op nodes: {op}"
                )
            for oidx in op.options.outputs:
                if (
                    op.layertype != LayerType.Output
                ):  # output layer does not produce any activation. it only denote model output
                    act_to_producer[oidx] = op
            if op.layertype == LayerType.Input:
                input_acts.append(op.options.outputs[0])
            if op.layertype == LayerType.InputConstant:
                on_demand_ops.add(op)

        for op in self.operators:
            if op.layertype == LayerType.Input:
                continue
            if op in on_demand_ops:
                continue
            for iidx in op.options.inputs:
                if iidx in act_to_producer:
                    parent = act_to_producer[iidx]
                    consumers[parent].append(op)
                    if parent not in on_demand_ops:
                        in_degree[op] += 1

        op_depths = self.get_reverse_op_depth()
        initial_nodes = [
            op
            for op in self.operators
            if in_degree[op] == 0 and op not in on_demand_ops
        ]
        initial_nodes.sort(key=lambda x: op_depths[x], reverse=True)
        stk = initial_nodes
        sorted_ops = []
        visited_on_demands = set()

        while stk:
            curr_op = stk.pop()

            for iidx in curr_op.options.inputs:
                if iidx in act_to_producer:
                    parent = act_to_producer[iidx]
                    if parent in on_demand_ops and parent not in visited_on_demands:
                        sorted_ops.append(parent)
                        visited_on_demands.add(parent)
            sorted_ops.append(curr_op)

            children = consumers[curr_op]
            # depth가 큰 자식을 나중에 push해야 pop할 때 먼저 나옴
            children.sort(key=lambda x: op_depths[x], reverse=True)

            for child in children:
                in_degree[child] -= 1
                if in_degree[child] == 0:
                    stk.append(child)

        remaining_on_demands = on_demand_ops - visited_on_demands
        if remaining_on_demands:
            sorted_ops.extend(remaining_on_demands)

        if len(sorted_ops) != len(self.operators):
            raise RuntimeError("Graph cycle or unreachable nodes detected.")

        self.operators = sorted_ops

    def update_connectivity(self):
        for act in self.activations:
            act.consumer_ops.clear()
        for op in self.operators:
            if not op.valid:  # this is essential.
                continue
            if op.layertype != LayerType.Output:
                for oidx in op.options.outputs:
                    self.activations[oidx].producer_op = op
            if op.layertype in _INPUT_KIND:
                continue
            for inact in op.inacts:
                inact.consumer_ops.append(op)

    def remove_dangling_activations(self):
        """
        Remove unused activations and remap activation indices.
        Updates all operator inputs/outputs and subgraph inputs/outputs.
        """

        name_to_new_idx = {
            act.name: None
            for op in self.operators
            for act in itertools.chain(op.inacts, op.outacts)
        }

        new_activations = []
        for act in self.activations:
            if act is None:
                continue
            if act.name in name_to_new_idx:
                name_to_new_idx[act.name] = len(new_activations)
                new_activations.append(act)

        def remap_indices(old_indices, ignore_non_exist=False):
            for old_idx in old_indices:
                new_idx = name_to_new_idx.get(self.activations[old_idx].name, None)
                if new_idx is None:
                    if not ignore_non_exist:
                        raise ValueError(
                            f"old activation with index={new_idx} doesn't exist!"
                        )
                else:
                    yield new_idx

        # update subgraph inputs/outputs
        self.inputs = list(remap_indices(self.inputs, True))
        self.outputs = list(remap_indices(self.outputs, True))

        # update operator inputs/outputs
        for op in self.operators:
            kw = {
                "inputs": tuple(remap_indices(op.options.inputs)),
                "outputs": tuple(remap_indices(op.options.outputs)),
            }
            if op.layertype == LayerType.Concatenate:
                if op.options.original_inputs:
                    kw["original_inputs"] = tuple(
                        remap_indices(op.options.original_inputs)
                    )
            op.options = dataclasses.replace(op.options, **kw)

        self.activations = new_activations

    def remove_dangling_tensors(self):
        tensors_to_idx = {
            tensor.name: None for op in self.operators for tensor in op.tensors
        }

        new_tensors = []
        for ts in self.tensors:
            if ts is None:
                continue
            if ts.name in tensors_to_idx:
                tensors_to_idx[ts.name] = len(new_tensors)
                new_tensors.append(ts)

        for op in self.operators:
            tensor_updates = {}
            for field_name, tidx in op.options.iter_tensorindex():
                if tidx == -1:
                    continue
                tensor_updates[field_name] = tensors_to_idx[self.tensors[tidx].name]
            if tensor_updates:
                new_opt = dataclasses.replace(op.options, **tensor_updates)
                op.options = new_opt
        self.tensors = new_tensors

    def remove_dangling_disconnected_nodes(self):
        """
        Remove disconnected subgraph components that are not reachable from
        valid graph entry points (Input, DeviceBridge, InputConstant) and
        do not lead to valid graph exit points (Output, DeviceBridge).

        A connected component is considered dangling if it satisfies BOTH:
          - No op in the component is a valid root (Input, DeviceBridge, InputConstant)
          - No op in the component is a valid terminal (Output, DeviceBridge-output)

        This handles cases like ClassPlaceholder (zero-input, non-Input op)
        connected only to an Output node after its main consumer is removed.
        """
        self.update_connectivity()

        # Build adjacency: undirected connectivity via activations
        adj = collections.defaultdict(set)
        op_set = set(self.operators)
        for op in self.operators:
            for oact in op.outacts:
                for consumer in oact.consumer_ops:
                    if consumer in op_set:
                        adj[op].add(consumer)
                        adj[consumer].add(op)

        # Find connected components via BFS
        visited = set()
        components = []
        for op in self.operators:
            if op in visited:
                continue
            component = []
            queue = collections.deque([op])
            while queue:
                curr = queue.popleft()
                if curr in visited:
                    continue
                visited.add(curr)
                component.append(curr)
                for neighbor in adj[curr]:
                    if neighbor not in visited:
                        queue.append(neighbor)
            components.append(component)

        # Determine which components are valid (reachable from root OR to terminal)
        valid_root_types = _INPUT_KIND | {LayerType.InputConstant}
        for component in components:
            has_root = any(
                op.layertype in valid_root_types or self.is_root_node(op)
                for op in component
            )
            if not has_root:
                LOGGER.debug(
                    f"[DANGLING] Removing disconnected component: "
                    f"{[(op.layertype.name, op.real_name) for op in component]}"
                )
                for op in component:
                    op.set_invalid()

        self.operators = [op for op in self.operators if op.valid]

    def strip_unused_operators(self):
        self.operators = [op for op in self.operators if op.valid]
        changed = True
        while changed:
            changed = False
            self.update_connectivity()
            for op in self.operators:
                acc = 0
                for oact in op.outacts:
                    acc += len(oact.consumer_ops)
                if acc == 0:
                    if op.layertype not in (LayerType.Output, LayerType.DeviceBridge):
                        op.set_invalid()
                        changed = True
            self.operators = [op for op in self.operators if op.valid]
        self.remove_dangling_activations()
        self.remove_dangling_tensors()

    def update_graph_in_out(self):
        """
        note that self.inputs may contain constant inputs.
        """
        all_inputs = IntSet()
        all_outputs = IntSet()
        all_input_const_outputs = IntSet()
        maybe_add_outputs = IntSet()
        for op in self.operators:
            if op.layertype == LayerType.Input:
                all_inputs.add(op.options.outputs[0])
            elif op.layertype == LayerType.Output:
                if (
                    self.activations[op.options.inputs[0]].producer_op.layertype
                    != LayerType.Input
                ):
                    all_outputs.add(op.options.inputs[0])
                maybe_add_outputs.add(op.options.inputs[0])
            elif op.layertype == LayerType.StatefulLSTMWrapper:
                for i in op.options.inputs:
                    all_inputs.add(i)
                for i, mask in zip(op.options.outputs, "ohc"):
                    if mask in op.options.output_mask:
                        all_outputs.add(i)
            elif op.layertype in (
                LayerType.StatefulGRUWrapper,
                LayerType.StatefulRNNWrapper,
            ):
                for i in op.options.inputs:
                    all_inputs.add(i)
                for i, mask in zip(op.options.outputs, "oh"):
                    if mask in op.options.output_mask:
                        all_outputs.add(i)
            else:
                for i in op.options.inputs:
                    all_inputs.add(i)
                for i in op.options.outputs:
                    all_outputs.add(i)
                if op.layertype == LayerType.InputConstant:
                    all_input_const_outputs.add(op.options.outputs[0])

        self.inputs = list(all_inputs - all_outputs)
        outputs = all_outputs - all_inputs - all_input_const_outputs
        # we need this since the above set difference can remove some output in the middle of graph.
        outputs.update(maybe_add_outputs)
        self.outputs = list(outputs)

        # Subgraph inputs and outputs are sorted to match the order of their source shapes.
        self.inputs = sorted(self.inputs, key=lambda i: self.activations[i].src_shape)
        self.outputs = sorted(self.outputs, key=lambda i: self.activations[i].src_shape)

    def update_output_name(self):
        # update graph output activation names to original output names.
        name_act_idx = {}
        for idx, act in enumerate(self.activations):
            name_act_idx[act.name] = idx
        for op in self.operators:
            if op.layertype == LayerType.Output:
                inact = self.activations[op.options.inputs[0]]
                orig_name = op.options.orig_name
                if inact.name != orig_name:
                    if orig_name in name_act_idx:
                        act_with_dup_name = self.activations[name_act_idx[orig_name]]
                        new_name = _get_unique_name(orig_name, name_act_idx)
                        LOGGER.debug(
                            f"Rename activation '{orig_name}' to '{new_name}' to avoid duplication"
                        )
                        act_with_dup_name.name = new_name
                    LOGGER.debug(
                        f"Rename activation '{inact.name}' to '{orig_name}' to revoke output name."
                    )
                    inact.name = orig_name

    def all_layer_types(self):
        return list(set(op.layertype.name for op in self.operators))

    def fuse_npu_concat(self):
        if any(
            op.layertype == LayerType.Concatenate and op.options.original_inputs
            for op in self.operators
        ):
            concat_groups = collections.defaultdict(list)
            for op in self.operators:
                op.valid = True
                if op.layertype == LayerType.Concatenate and op.options.original_inputs:
                    concat_groups[op.options.original_inputs].append(op)

            def revert(cc):
                cc.options = dataclasses.replace(
                    cc.options,
                    inputs=cc.options.original_inputs,
                    original_inputs=None,
                    original_key=None,
                    original_axis=None,
                    input_index=None,
                    input_names=None,
                )

            for cc_group in concat_groups.values():
                if len(cc_group) == 1:
                    revert(cc_group[0])
                else:
                    for cc in cc_group:
                        # last concat. only one last concat exists.
                        if cc.options.input_index is not None:
                            revert(cc)
                        else:
                            cc.set_invalid()

            self.operators = [op for op in self.operators if op.valid]
            self.update_connectivity()
            self.remove_dangling_activations()

    def shape_inference(self, update_shape=True):
        """
        current usage of this method is to update the dynamic dimension of each activation.
        """
        input_shapes = {}
        for op in self.operators:
            if op.layertype == LayerType.Input:
                act = op.outacts[0]
                input_shapes[act.name] = act.src_shape
        inferred_shapes = {}
        for op in self.operators:
            if op.layertype == LayerType.Input:
                input_shapes = [input_shapes[k.name] for k in op.inacts]
                output_shapes = op.infer_shape(*input_shapes)
            else:
                input_shapes = [inferred_shapes[k.name] for k in op.inacts]
                output_shapes = op.infer_shape(*input_shapes)
            if isinstance(output_shapes, Shape):
                inferred_shapes[op.outacts[0].name] = output_shapes
                oshape_ref = op.outacts[0].src_shape
                if output_shapes != oshape_ref:
                    raise ValueError(
                        f"inferred_shape!=ref_shape, {output_shapes[0]}!={oshape_ref}"
                    )
            else:
                raise NotImplementedError(op.layertype, output_shapes)

        if update_shape:
            for act in self.activations:
                if act.name in inferred_shapes:
                    act.update_shape(inferred_shapes[act.name])

    def add_activation(self, act: ActivationSpec):
        """
        returns activation index in this subgraph.
        Fix activation name if the activation has duplicate name.
        """
        if not self._all_activation_names:
            self.init_all_activation_names()
        if act.name in self._all_activation_names:
            act.name = _get_unique_name(act.name, self._all_activation_names)
        index = len(self.activations)
        self.activations.append(act)
        self._all_activation_names[act.name] = index
        return index

    def add_tensor(self, tensor: TensorSpec):
        """returns tensor index in this subgraph.
        Fix tensor name if the tensor has duplicate name.
        """
        if not self._all_tensor_names:
            self.init_all_tensor_names()
        if tensor.name in self._all_tensor_names:
            tensor.name = _get_unique_name(tensor.name, self._all_tensor_names)
        index = len(self.tensors)
        self.tensors.append(tensor)
        self._all_tensor_names[tensor.name] = TensorIndex(index)
        return index

    def get_activation_index(self, act: ActivationSpec):
        if not self._all_activation_names:
            self.init_all_activation_names()
        return self._all_activation_names[act.name]

    def finalize(self):
        self.strip_unused_operators()
        self.remove_dangling_disconnected_nodes()
        self.remove_dangling_activations()
        self.remove_dangling_tensors()
        self.sort_operators()
        self.update_graph_in_out()
        self.update_output_name()
        self._all_activation_names.clear()
        self._all_tensor_names.clear()
