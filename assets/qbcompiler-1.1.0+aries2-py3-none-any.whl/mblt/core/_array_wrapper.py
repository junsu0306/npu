import dataclasses
import enum
import gc
import math
import pathlib
from os import PathLike
from typing import Optional, Union, TYPE_CHECKING

import numpy

# Make torch an optional dependency: NumPy is the default backend, and
# torch paths are enabled only when torch is available.
try:  # pragma: no cover - optional dependency path
    import torch  # type: ignore

    _TORCH_AVAILABLE = True
    _TORCH_TENSOR_TYPES = (torch.Tensor,)  # type: ignore[attr-defined]
except Exception:  # pragma: no cover - torch not installed
    torch = None  # type: ignore
    _TORCH_AVAILABLE = False
    _TORCH_TENSOR_TYPES = tuple()
_TORCH_DEVICE_DEFAULT_CPU = False


def torch_available():
    return _TORCH_AVAILABLE


if TYPE_CHECKING:  # for type checkers only
    import torch as _torch_typing  # type: ignore

_NUMPY_DTYPE_ITEMSIZE = {
    # Floating Point
    "float32": 4,
    "float64": 8,
    "float128": 16,
    "float16": 2,
    # Integers
    "int8": 1,
    "int16": 2,
    "int32": 4,
    "int64": 8,
    "uint8": 1,
    "uint16": 2,
    "uint32": 4,
    "uint64": 8,
    # Boolean & Complex
    "bool": 1,
    "bool_": 1,
    "complex64": 8,
    "complex128": 16,
    "complex256": 32,
    # Python 기본형 대응
    "int": numpy.dtype(int).itemsize,
    "float": numpy.dtype(float).itemsize,
}


_TORCH_DTYPE_ITEMSIZE = {
    # Floating Point
    "float32": 4,
    "float": 4,
    "float64": 8,
    "double": 8,
    "float16": 2,
    "half": 2,
    "bfloat16": 2,
    # Float8
    "float8_e4m3fn": 1,
    "float8_e5m2": 1,
    "float8_e4m3fnuz": 1,
    "float8_e5m2uz": 1,
    # Integers
    "uint8": 1,
    "int8": 1,
    "int16": 2,
    "short": 2,
    "int32": 4,
    "int": 4,
    "int64": 8,
    "long": 8,
    "uint16": 2,
    "uint32": 4,
    "uint64": 8,
    # Complex & Boolean
    "complex32": 4,
    "complex64": 8,
    "complex128": 16,
    "bool": 1,
    # Quantized
    "qint8": 1,
    "quint8": 1,
    "qint32": 4,
}


@dataclasses.dataclass
class FileInfo:
    path: Optional[str] = None
    buffer_idx: Optional[int] = None
    offset: Optional[int] = None
    buffer_size: Optional[int] = None


class _STATE(enum.Enum):
    UNINITIALIZED = enum.auto()
    CPU = enum.auto()
    CUDA = enum.auto()
    FILE = enum.auto()


class ARRAY_BACKEND(enum.Enum):
    NUMPY = enum.auto()
    TORCH = enum.auto()


class ArrayWrapper:
    __slots__ = (
        "_value",
        "_file_info",
        "shape",
        "dtype",
        "backend",
        "_state",
    )

    def __init__(
        self,
        value: Optional[Union[numpy.ndarray, "_torch_typing.Tensor"]] = None,
        path: Optional[str | PathLike] = None,
        buffer_idx: Optional[int] = None,
        offset: Optional[int] = None,
        buffer_size: Optional[int] = None,
        shape: Optional[tuple[int, ...]] = None,
        dtype: Optional[str] = None,
    ):
        if value is not None:
            shape = None
            dtype = None
        self._value = None
        self._file_info = FileInfo(str(path), buffer_idx, offset, buffer_size)
        self.shape = shape
        self.dtype = dtype
        self.backend = None
        self._state = _STATE.UNINITIALIZED

        if value is not None:
            self._set_value(value)
        elif path is not None and pathlib.Path(path).exists():
            self._load_metadata_from_file()
        elif path is not None:
            # Path provided but file doesn't exist yet - this is okay, will be created later
            pass
        else:
            raise ValueError("Either value or path must be provided")

    def __repr__(self):
        return f"ArrayWrapper({self.dtype}{tuple(self.shape)}, state={self._state.name}), backend={self.backend.name}"

    def _set_value(self, value: Union[numpy.ndarray, "_torch_typing.Tensor"]):
        if not isinstance(
            value, (numpy.ndarray, numpy.number, numpy.bool_) + _TORCH_TENSOR_TYPES
        ):
            raise TypeError(
                f"Expected numpy.ndarray or torch.Tensor, got {type(value)}"
            )
        if _TORCH_AVAILABLE and isinstance(value, _TORCH_TENSOR_TYPES):
            self.backend = ARRAY_BACKEND.TORCH
            # when cpu default
            if getattr(value, "is_cuda", False):
                if _TORCH_DEVICE_DEFAULT_CPU:
                    self._value = value.detach().cpu()
                    state = _STATE.CPU
                else:
                    self._value = value.detach()
                    state = _STATE.CUDA
            else:
                self._value = value.detach()
                state = _STATE.CPU
        else:
            state = _STATE.CPU
            self.backend = ARRAY_BACKEND.NUMPY
            self._value = value
        # fill if metadata is not available
        if self.dtype is None:
            self.dtype = str(value.dtype).split(".")[-1]
            self.shape = value.shape
        else:
            assert self.shape == value.shape, "Shape mismatch"
            assert self.dtype == str(value.dtype).split(".")[-1], "Dtype mismatch"
        self._state = state

    def _load_metadata_from_file(self):
        """Load tensor metadata without loading the actual data"""
        if (
            self._file_info.path is None
            or not pathlib.Path(self._file_info.path).exists()
        ):
            return

        try:
            # Try to determine if it's torch or numpy from file extension or content
            with open(self._file_info.path, "rb") as f:
                # Read first few bytes to determine format
                header = f.read(8)
                f.seek(0)
                if header.startswith(b"PK"):  # ZIP format (torch)
                    self.backend = ARRAY_BACKEND.TORCH
                    if not _TORCH_AVAILABLE:
                        # Cannot parse torch metadata without torch installed
                        return
                    temp_array = torch.load(f, map_location="meta")  # type: ignore[name-defined]
                    self.shape = temp_array.shape
                    self.dtype = str(temp_array.dtype).split(".")[-1]
                    del temp_array
                else:  # Assume numpy b'\x93NUMPY'
                    self.backend = ARRAY_BACKEND.NUMPY
                    temp_array = numpy.load(f)
                    self.shape = temp_array.shape
                    self.dtype = str(temp_array.dtype)
                    del temp_array
        except Exception:
            # If we can't load metadata, we'll get it when the value is actually loaded
            pass

    def save_to_file(self, path: Optional[str | PathLike] = None):
        """Save tensor to file with enhanced error handling"""
        if path is not None:
            self._file_info.path = str(path)

        if self._file_info.path is None:
            raise ValueError("No file path specified for ArrayWrapper")

        if self._value is None:
            raise ValueError("No data to save in ArrayWrapper")

        # Ensure parent directory exists
        p = pathlib.Path(self._file_info.path)
        p.parent.mkdir(parents=True, exist_ok=True)
        try:
            with p.open("wb") as f:
                if self.backend == ARRAY_BACKEND.TORCH:
                    if not _TORCH_AVAILABLE:
                        raise ImportError(
                            "Torch backend selected but torch not available."
                        )
                    torch.save(self._value, f)  # type: ignore[name-defined]
                else:
                    numpy.save(f, self._value)
        except Exception as e:
            raise IOError(
                f"Error saving ArrayWrapper to file {self._file_info.path}: {str(e)}"
            )

    def write_to_file_and_release(self):
        """Save tensor to file and release from memory"""
        if self._value is None:
            return  # Nothing to save

        self.save_to_file()

        # Release memory with improved cleanup
        if self._value is not None:
            # Check if tensor is on CUDA before deletion
            is_cuda_tensor = (
                self.backend == ARRAY_BACKEND.TORCH
                and hasattr(self._value, "device")
                and "cuda" in str(getattr(self._value, "device", ""))
            )

            # Delete the tensor
            del self._value
            self._value = None

            # Clear CUDA cache if tensor was on CUDA
            if _TORCH_AVAILABLE and is_cuda_tensor and torch.cuda.is_available():  # type: ignore[name-defined]
                torch.cuda.synchronize()  # type: ignore[name-defined]

            # Force garbage collection for better memory cleanup

            gc.collect()
            if _TORCH_AVAILABLE and is_cuda_tensor and torch.cuda.is_available():  # type: ignore[name-defined]
                torch.cuda.empty_cache()  # type: ignore[name-defined]

        self._state = _STATE.FILE

    @property
    def value(self):
        """lazy loading"""
        if self._value is None:
            return self.read_from_file()
        return self._value

    @property
    def nbytes(self):
        if self.backend == ARRAY_BACKEND.TORCH:
            return math.prod(map(int, self.shape)) * _TORCH_DTYPE_ITEMSIZE[self.dtype]
        else:
            return math.prod(map(int, self.shape)) * _NUMPY_DTYPE_ITEMSIZE[self.dtype]

    def read_from_file(self):
        if self._file_info.path is None:
            raise ValueError("No file path specified for ArrayWrapper")
        p = pathlib.Path(self._file_info.path)
        if not p.exists():
            raise FileNotFoundError(
                f"ArrayWrapper file not found: {self._file_info.path}"
            )
        # non-buffer load
        if self._file_info.buffer_idx is None:
            try:
                with p.open("rb") as f:
                    if self.backend is None:
                        header = f.read(8)
                        f.seek(0)
                        if header.startswith(b"PK"):
                            if not _TORCH_AVAILABLE:
                                raise ImportError(
                                    "Cannot load torch tensor: torch not available."
                                )
                            self.backend = ARRAY_BACKEND.TORCH
                            self._set_value(torch.load(f, map_location="cpu"))  # type: ignore[name-defined]
                        else:
                            self.backend = ARRAY_BACKEND.NUMPY
                            self._set_value(numpy.load(f))
                    else:
                        if self.backend == ARRAY_BACKEND.TORCH:
                            if not _TORCH_AVAILABLE:
                                raise ImportError(
                                    "Cannot load torch tensor: torch not available."
                                )
                            self._set_value(torch.load(f, map_location="cpu"))  # type: ignore[name-defined]
                        else:
                            self._set_value(numpy.load(f))
            except Exception as e:
                raise IOError(
                    f"Error loading ArrayWrapper file {self._file_info.path}: {str(e)}"
                )
        else:
            # buffer load - always uses numpy memmap
            try:
                offset = (
                    self._file_info.buffer_size * self._file_info.buffer_idx
                    + self._file_info.offset
                )
                assert self.shape is not None
                if self.backend is None:
                    self.backend = ARRAY_BACKEND.NUMPY
                data = numpy.memmap(
                    self._file_info.path,
                    dtype=numpy.dtype(self.dtype),
                    offset=offset,
                    mode="r",
                    shape=tuple(map(int, self.shape)),
                )
                self._set_value(data)
            except Exception as e:
                raise IOError(
                    f"Error loading ArrayWrapper buffer from file {self._file_info.path}: {str(e)}"
                )
        return self._value

    def is_loaded_in_memory(self):
        """check if the tensor is loaded in memory"""
        return self._value is not None

    def get_memory_usage(self):
        """get the memory usage of the tensor"""
        return 0 if self._value is None else self._value.nbytes

    def to_device(self, device: str):
        """Move tensor to specified device (torch tensors only). Loads from file if needed."""
        if self._value is None:
            self.read_from_file()
        if self.backend == ARRAY_BACKEND.TORCH:
            if not _TORCH_AVAILABLE:
                raise ImportError("Torch is not installed; to_device requires torch.")
            if str(self._value.device) != device:
                self._value = self._value.to(device)
                # Update state based on new device
                if "cuda" in str(device):
                    self._state = _STATE.CUDA
                else:
                    self._state = _STATE.CPU
        return self._value

    def to_cpu(self):
        """Move tensor to CPU to free CUDA memory. Loads from file if needed."""
        # Numpy arrays are always on CPU
        if self.backend == ARRAY_BACKEND.TORCH:
            if not _TORCH_AVAILABLE:
                raise ImportError("Torch is not installed; to_cpu requires torch.")
            if self._value is None:
                self.read_from_file()  # This already loads to CPU
            if "cuda" in str(self._value.device):
                self._value = self._value.cpu()
                self._state = _STATE.CPU
                # Clear CUDA cache after moving to CPU
                if torch.cuda.is_available():  # type: ignore[name-defined]
                    torch.cuda.empty_cache()  # type: ignore[name-defined]
        return self._value

    def tobytes(self):
        if self._value is None:
            self.read_from_file()
        if self.backend == ARRAY_BACKEND.TORCH:
            if not _TORCH_AVAILABLE:
                raise ImportError(
                    "Torch is not installed; cannot convert torch tensor to bytes."
                )
            if self._value.dtype == torch.bfloat16:  # type: ignore[name-defined]
                return self._value.detach().cpu().float().numpy().tobytes()
            return self._value.detach().cpu().numpy().tobytes()
        return self._value.tobytes()
