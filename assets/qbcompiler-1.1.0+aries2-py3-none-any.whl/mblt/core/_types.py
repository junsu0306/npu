import enum
import operator
from typing import Optional, Tuple, Union

import numpy

_CODE_SHOULD_NOT_BE_REACHED = RuntimeError("code should not be reached!")


# Type Definitions


class TensorIndex(int):
    """
    This type definition makes it clear if a field represents a tensor index
    and facilitates easy implementation of tensor handling routines.

    Example:
        We prefer `weight: TensorIndex` over `weight: int64` for clarity.
    """

    def __new__(cls, value, *args, **kwargs):
        return super().__new__(cls, value)

    def __repr__(self):
        return f"TensorIndex({int(self)})"

    def to_dict(self):
        return {"cls": self.__class__.__class__, "data": int(self)}

    @classmethod
    def from_dict(self, data: dict):
        assert data["cls"] == "TensorIndex"
        return TensorIndex(data["data"])


class _BoundedInt(int):
    """Base class for bounded integer types with automatic range validation"""

    _numpy_type: type

    def __new__(cls, value) -> "_BoundedInt":
        val = int(value)
        info = numpy.iinfo(cls._numpy_type)
        if not (info.min <= val <= info.max):
            raise ValueError(
                f"Value {val} out of range for {cls.__name__} [{info.min}, {info.max}]"
            )
        return super().__new__(cls, val)

    def __repr__(self):
        return f"{self.__class__.__name__}({int(self)})"

    def to_dict(self):
        return {"cls": self.__class__.__class__, "data": int(self)}

    @classmethod
    def from_dict(cls, data: dict):
        assert data["cls"] == cls.__name__
        return cls(data["data"])


class int8(_BoundedInt):
    """Signed 8-bit integer"""

    _numpy_type = numpy.int8


class int16(_BoundedInt):
    """Signed 16-bit integer"""

    _numpy_type = numpy.int16


class int32(_BoundedInt):
    """Signed 32-bit integer"""

    _numpy_type = numpy.int32


class int64(_BoundedInt):
    """Signed 64-bit integer"""

    _numpy_type = numpy.int64


class uint8(_BoundedInt):
    """Unsigned 8-bit integer"""

    _numpy_type = numpy.uint8


class uint32(_BoundedInt):
    """Unsigned 32-bit integer"""

    _numpy_type = numpy.uint32


class uint64(_BoundedInt):
    """Unsigned 64-bit integer"""

    _numpy_type = numpy.uint64


class _BoundedFloat(float):
    """Base class for bounded floating point types with range validation"""

    _numpy_type: type  # numpy dtype to get min/max from

    def __new__(cls, value):
        val = float(value)
        info = numpy.finfo(cls._numpy_type)
        if not (info.min <= val <= info.max):
            raise ValueError(
                f"Value {val} out of range for {cls.__name__} [{info.min}, {info.max}]"
            )
        if numpy.isnan(val):
            raise ValueError(f"NaN is not allowed for {cls.__name__}")
        return super().__new__(cls, val)

    def __repr__(self):
        return f"{self.__class__.__name__}({float(self)})"

    def to_dict(self):
        return {"cls": self.__class__.__class__, "data": float(self)}

    @classmethod
    def from_dict(cls, data: dict):
        assert data["cls"] == cls.__name__
        return cls(data["data"])


class float32(_BoundedFloat):
    """32-bit floating point number"""

    _numpy_type = numpy.float32


class float64(_BoundedFloat):
    """64-bit floating point number"""

    _numpy_type = numpy.float64


class DynamicInt:
    __slots__ = ("_value", "_dynamic")

    def __init__(self, value, dynamic: Optional[bool] = None):
        if dynamic is None:
            if isinstance(value, DynamicInt):
                dynamic = value._dynamic
            else:
                dynamic = False
        self._dynamic = bool(dynamic)
        if isinstance(value, (int, numpy.integer, DynamicInt)):
            self._value = int(value)
        elif isinstance(value, float) and int(value) == value:
            self._value = int(value)
        else:
            raise TypeError(f"Invalid value type={type(value)}, value={value}")

    def to_dict(self):
        return {
            "cls": self.__class__.__name__,
            "value": self.value,
            "dynamic": self.dynamic,
        }

    @classmethod
    def from_dict(cls, data: dict):
        is_legacy = "cls" not in data
        if is_legacy:
            return cls(value=data["value"], dynamic=data["dynamic"])
        else:
            return cls(value=data["value"], dynamic=data["dynamic"])

    def __repr__(self):
        if self._dynamic:
            return f"{self._value}?"
        return str(self._value)

    def __int__(self):
        return self._value

    def __index__(self):
        """Make DynamicInt behave like an int in indexing operations."""
        return self._value

    def __hash__(self):
        # Hash only the integer value so that DynamicInt(3) hashes like int(3).
        # This keeps consistency when equality with ints returns True.
        return hash(self._value)

    @property
    def value(self):
        return self._value

    @property
    def dynamic(self):
        return self._dynamic

    def set_dynamic(self, v=True):
        self._dynamic = v

    def _num_ker(self, other, op_):
        if isinstance(other, _BoundedFloat):
            return DynamicInt(op_(self.value, float(other)), self._dynamic)
        elif isinstance(other, _BoundedInt):
            return DynamicInt(op_(self.value, int(other)), self._dynamic)
        if isinstance(other, DynamicInt):
            return DynamicInt(
                op_(self.value, other.value), self._dynamic or other.dynamic
            )
        if isinstance(other, int) or numpy.issubdtype(type(other), numpy.integer):
            return DynamicInt(op_(self.value, int(other)), self._dynamic)
        raise NotImplementedError(
            f"Cannot {op_.__name__} {type(self)} and {type(other)}"
        )

    # Comparison helpers and operators
    def _coerce_int(self, other):
        if isinstance(other, DynamicInt):
            return other.value
        if isinstance(other, int) or isinstance(other, numpy.integer):
            return int(other)
        if isinstance(other, float) and int(other) == other:
            return int(other)
        raise NotImplementedError(f"Cannot compare {type(self)} and {type(other)}")

    def __eq__(self, other):
        if isinstance(other, DynamicInt):
            # return (self._value == other._value) and (self._dynamic == other._dynamic)
            # 그래프 빌드 상황에서 dynamic까지 비교하기 어려움.
            return self._value == other._value
        return self._value == self._coerce_int(other)

    def __lt__(self, other):
        return self._value < self._coerce_int(other)

    def __le__(self, other):
        return self._value <= self._coerce_int(other)

    def __gt__(self, other):
        return self._value > self._coerce_int(other)

    def __ge__(self, other):
        return self._value >= self._coerce_int(other)

    def __add__(self, other):
        return self._num_ker(other, operator.add)

    def __radd__(self, other):
        return self.__add__(other)

    def __sub__(self, other):
        return self._num_ker(other, operator.sub)

    def __rsub__(self, other):
        return self._num_ker(other, lambda x, y: y - x)

    def __mul__(self, other):
        return self._num_ker(other, operator.mul)

    def __truediv__(self, other):
        # Allow only exact division that results in an integer.
        return self._num_ker(other, operator.truediv)

    def __floordiv__(self, other):
        return self._num_ker(other, operator.floordiv)

    def __mod__(self, other):
        return self._num_ker(other, operator.mod)

    def __neg__(self):
        return DynamicInt(-self._value, self._dynamic)


class DimValue(DynamicInt): ...


class Shape(tuple):
    def __new__(cls, x):
        return super().__new__(cls, (DimValue(arg) for arg in x))

    def __getitem__(self, idx):
        out = tuple.__getitem__(self, idx)

        if isinstance(out, tuple):
            return self.__class__(out)

        return out

    def __repr__(self):
        return super().__repr__().replace(" ", "")

    def numel(self):
        out = DimValue(1)
        for dim in self:
            out *= dim
        return out

    def to_dict(self):
        return [x.to_dict() for x in self]

    @classmethod
    def from_dict(cls, data: dict):
        is_legacy = "cls" not in data

        def g(x):
            if isinstance(x, dict):
                return DimValue.from_dict(x)
            return DimValue(x)

        if is_legacy:
            return cls((g(x) for x in data))
        else:
            return cls((DimValue.from_dict(x) for x in data["data"]))


class DataFormat(enum.Enum):
    UNKNOWN = "UNKNOWN"
    NHWC = "NHWC"
    NXC = "NXC"
    NX = "NX"

    def __repr__(self):
        return self.name

    @classmethod
    def _missing_(cls, value):
        return cls.UNKNOWN

    @staticmethod
    def from_str(s: str) -> "DataFormat":
        return DataFormat[s.upper()]

    def to_dict(self):
        return {"cls": self.__class__.__name__, "value": self.name}

    @classmethod
    def from_dict(cls, s: str) -> "DataFormat":
        is_legacy = "cls" not in s
        if is_legacy:
            return cls.from_str(s)
        else:
            return cls.from_str(s["value"])


DIMLIKE = Union[int, DimValue]
SHAPELIKE = Union[Tuple[DIMLIKE, ...], Shape]