import dataclasses
from typing import Union, TYPE_CHECKING, Optional, NamedTuple

import numpy

# Optional torch dependency: NumPy is default; torch paths active only if available
try:  # pragma: no cover - optional dependency
    import torch  # type: ignore

    _TORCH_AVAILABLE = True
    _TORCH_DTYPE = torch.dtype  # type: ignore[attr-defined]
except Exception:  # pragma: no cover - torch not installed
    torch = None  # type: ignore
    _TORCH_AVAILABLE = False
    _TORCH_DTYPE = object

if TYPE_CHECKING:
    if _TORCH_AVAILABLE:
        import torch as _torch_typing  # type: ignore


def to_dict_helper(obj):
    if isinstance(obj, bool):
        return obj
    if numpy.issubdtype(type(obj), numpy.integer) or isinstance(obj, int):
        return int(obj)
    if numpy.issubdtype(type(obj), numpy.unsignedinteger):
        return int(obj)
    if numpy.issubdtype(type(obj), numpy.floating) or isinstance(obj, float):
        return float(obj)
    if isinstance(obj, str):
        return obj
    if _TORCH_AVAILABLE and isinstance(obj, _TORCH_DTYPE):
        return {"__type__": "torch.dtype", "value": str(obj)}

    from mblt import ArrayWrapper
    if isinstance(obj, ArrayWrapper):
        return {
            "__type__": "ArrayWrapper",
            "dtype": str(obj.dtype),
            "shape": obj.shape,
        }


    if obj is Ellipsis:
        return {"__type__": "Ellipsis"}
    if isinstance(obj, slice):
        return {
            "__type__": "slice",
            "start": obj.start,
            "stop": obj.stop,
            "step": obj.step,
        }
    if obj is None:
        return None

    if hasattr(obj, "to_dict"):
        return obj.to_dict()

    if hasattr(type(obj), "__dataclass_fields__"):
        return {
            field.name: to_dict_helper(getattr(obj, field.name))
            for field in dataclasses.fields(obj)
        }
    if isinstance(obj, (tuple, list)):
        try:
            return type(obj)(to_dict_helper(v) for v in obj)
        except TypeError:
            return {"__type__": str(type(obj)), "value":str(obj)}
    if isinstance(obj, dict):
        return {k: to_dict_helper(v) for k, v in obj.items()}
    if hasattr(obj, "__dict__"):
        return {k: to_dict_helper(v) for k, v in obj.__dict__.items()}

    raise TypeError(f"Unsupported type: {type(obj)}")


def get_dtype_str(data: Union[numpy.ndarray, "_torch_typing.Tensor"]) -> str:
    """
    Get string representation of dtype from tensor or array.

    Args:
        data: Torch tensor or numpy array

    Returns:
        String representation of the dtype (e.g., 'float32', 'int64')

    Raises:
        TypeError: If data is not a tensor or array
    """
    if _TORCH_AVAILABLE and isinstance(data, torch.Tensor):  # type: ignore[name-defined]
        # torch.dtype string looks like 'torch.float32'; normalize to 'float32'
        return str(data.dtype).split(".")[-1]
    elif isinstance(data, numpy.ndarray) or isinstance(data, numpy.generic):
        # numpy dtypes stringify to 'float32', 'int64', etc.
        return str(numpy.dtype(data.dtype))
    else:
        raise TypeError(f"Cannot get dtype string for type={type(data)}")


def dtype_to_torchformat(
    dtype: Union[str, numpy.dtype, "_torch_typing.dtype"],
) -> "_torch_typing.dtype":
    """
    Convert dtype string or numpy dtype to torch.dtype.

    Args:
        dtype: Dtype as string, numpy.dtype, or torch.dtype

    Returns:
        Corresponding torch.dtype

    Raises:
        TypeError: If dtype type is not supported
        ValueError: If dtype string is not recognized
    """
    if not _TORCH_AVAILABLE:
        raise ImportError("Torch is not installed; cannot convert to torch dtype.")

    if isinstance(dtype, torch.dtype):  # type: ignore[name-defined]
        return dtype  # type: ignore[return-value]

    # Accept string or numpy.dtype and map safely to torch.dtype
    if isinstance(dtype, numpy.dtype):
        key = str(dtype)
    elif isinstance(dtype, str):
        key = dtype
    else:
        raise TypeError(f"Unsupported dtype type: {type(dtype)}")

    # Normalize common aliases
    aliases = {
        "float": "float32",
        "double": "float64",
        "half": "float16",
        "long": "int64",
        "int": "int32",
        "short": "int16",
        "byte": "uint8",
        "char": "int8",
    }
    key = aliases.get(key, key)

    td = getattr(torch, key, None)  # type: ignore[name-defined]
    if isinstance(td, torch.dtype):  # type: ignore[name-defined]
        return td  # type: ignore[return-value]

    raise ValueError(f"Unknown torch dtype: {dtype}")


class MBLT_ENUMMETA(type):
    def __int__(cls):
        return (getattr(cls, name) for name in cls._get_member_names())

    def __getitem__(cls, key):
        # LayerType['key'] 형태 지원
        if hasattr(cls, key):
            return getattr(cls, key)
        raise KeyError(f"'{key}' is not a valid member of {cls.__name__}")

    def __contains__(cls, item):
        # 'add' in LayerType 지원
        return hasattr(cls, item)

    def _get_member_names(cls):
        # 내부 헬퍼: 멤버 이름 필터링
        return [
            k
            for k in cls.__dict__
            if not k.startswith("_")
            and not callable(getattr(cls, k))
            and not isinstance(getattr(cls, k), classmethod)
        ]

    def __instancecheck__(cls, instance):
        if isinstance(instance, MbltEnumMember):
            return instance.enum_cls == cls
        return super().__instancecheck__(instance)


class MbltEnumMember(NamedTuple):
    enum_cls: type
    name: str
    value: int

    def __repr__(self):
        return f"<{self.enum_cls.__name__}.{self.name}: {self.value}>"

    def __str__(self):
        return f"{self.enum_cls.__name__}.{self.name}"


class MbltEnum(metaclass=MBLT_ENUMMETA):
    """
    Defines dynamically extendable enum class.
    """

    __members__ = {}
    # Internal flag: if True, dynamic extension (e.g., add) is prohibited
    _MBLT__frozen = False

    class _Auto:
        pass

    def __repr__(self):
        return f"{self.__class__.__name__}"

    @classmethod
    def auto(cls):
        return cls._Auto()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        cls.__members__ = {}
        # initialize frozen state for each subclass
        cls._MBLT__frozen = False

        used_values = set()
        members_to_process = []
        reserved_names = set(dir(MbltEnum))

        for k, v in list(cls.__dict__.items()):
            if (
                not k.startswith("_")
                and not callable(v)
                and not isinstance(v, classmethod)
                and k not in reserved_names  # exclude names reserved by base class
            ):
                if k in cls.__members__:
                    raise ValueError(f"Key '{k}' is already exists.")

                members_to_process.append((k, v))

                if not isinstance(v, cls._Auto) and isinstance(v, int):
                    used_values.add(v)

        # set/process auto
        current_value = 1
        for k, v in members_to_process:
            if isinstance(v, cls._Auto):
                while current_value in used_values:
                    current_value += 1
                real_value = current_value
                used_values.add(current_value)
            else:
                real_value = v

            member = MbltEnumMember(cls, k, real_value)
            setattr(cls, k, member)
            cls.__members__[k] = member

    @classmethod
    def add(cls, name, value=None):
        if cls.is_frozen():
            raise ValueError(f"{cls.__name__} is frozen and cannot be extended.")
        if hasattr(cls, name):
            raise ValueError(f"'{name}' already exists.")

        used_values = {m.value for m in cls.__members__.values()}
        real_value = value

        if real_value is None or isinstance(real_value, cls._Auto):
            candidate = 1
            while candidate in used_values:
                candidate += 1
            real_value = candidate
        else:
            if real_value in used_values:
                for member in cls.__members__.values():
                    if member.value == real_value:
                        raise ValueError(
                            f"Value {real_value} is already used by '{member.name}'."
                        )

        member = MbltEnumMember(cls, name, real_value)
        setattr(cls, name, member)
        cls.__members__[name] = member

    # region: frozen control APIs
    @classmethod
    def set_frozen(cls, flag: bool = True):
        """Set frozen state of this enum class.

        When frozen, dynamic extension via `add` is prohibited.
        """
        cls._MBLT__frozen = bool(flag)

    @classmethod
    def is_frozen(cls) -> bool:
        """Return True if this enum class is frozen."""
        return bool(getattr(cls, "_MBLT__frozen", False))

    # endregion

    @classmethod
    def values(cls):
        return list(cls.__members__.values())

    @classmethod
    def items(cls):
        return cls.__members__.items()

    @classmethod
    def __iter__(cls):
        return iter(cls.__members__.values())

    # region: cloning/snapshot
    @classmethod
    def snapshot(cls, name: Optional[str] = None, frozen: bool = False):
        """Create a new enum class with the same members as this class.

        The resulting class is a distinct class object with an independent frozen state.

        Args:
            name: Optional new class name. If omitted, reuse the current class name.
            frozen: Whether the new class should be created as frozen.

        Returns:
            A new enum class (subclass of MbltEnum) with identical members and
            independent state.
        """
        # Build a namespace where each member is defined with its integer value.
        # __init_subclass__ will convert them into MbltEnumMember entries.
        namespace = {k: m.value for k, m in cls.__members__.items()}
        new_name = name or cls.__name__
        # Create a new class using the metaclass to ensure the same initialization flow.
        new_cls = MBLT_ENUMMETA(new_name, (MbltEnum,), namespace)
        if frozen:
            new_cls.set_frozen(True)
        return new_cls

    # endregion
