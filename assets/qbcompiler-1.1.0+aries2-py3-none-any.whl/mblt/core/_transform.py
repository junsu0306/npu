from __future__ import annotations

from typing import TypeVar, Optional, Any, List, Union, Protocol

from ._operator import Operator
from ._subgraph import SubGraph

OperatorTransformResult_T = TypeVar(
    "OperatorTransformResult_T", bound="OperatorTransformResult"
)


class OperatorTransformResult(Protocol):
    def apply_to_subgraph(
        self, target_sg: SubGraph, visitors: Optional[List] = None
    ) -> None: ...


class OpTransformResultBuilder(Protocol[OperatorTransformResult_T]):
    def build(self) -> OperatorTransformResult_T: ...


class RuleCase:
    """descriptor for defining a rule case."""

    def __init__(self, check_func):
        self.check_func = check_func
        self.transform_func = None
        self.name = check_func.__name__
        self.case_name: str | None = None  # will be set by __set_name__

    def __set_name__(self, owner, name: str):
        # This is the actual method/attribute name used in the class body.
        self.case_name = name

    def transform(self, func):
        """
        Decorator to register the transformation logic for specific case.
        """
        if self.transform_func is not None:
            raise RuntimeError("transform function already registered.")
        self.transform_func = func
        return self

    def __get__(self, inst, owner):
        """Descriptor method to bind the check function to the instance."""
        if inst is None:
            return self
        return self.check_func.__get__(inst, owner)

    def __repr__(self):
        return f"{self.case_name or self.name}"


def pattern(func) -> RuleCase:
    """
    Decorator to mark a method as a rule check function.

    Usage:
        @pattern
        def case0(self, ...): ...

        @case0.transform
        def transform_case0(self, ...): ...
    """
    return RuleCase(func)


class _RuleCaseNamespace(dict):
    """
    Prevent silent overwrites of RuleCase attributes.
    """

    def __setitem__(self, key, value):
        if key in self:
            prev = self.get(key)
            if isinstance(prev, RuleCase) or isinstance(value, RuleCase):
                if id(prev) != id(value):
                    raise RuntimeError(
                        f"Duplicate RuleCase name in module='{self['__module__']}', class='{self['__qualname__']}', name='{key}'. Rename one of them."
                    )
        return super().__setitem__(key, value)


class _TransformRuleMeta(type):
    @classmethod
    def __prepare__(mcls, name, bases, **kwargs):
        return _RuleCaseNamespace()


class TransformRule(metaclass=_TransformRuleMeta):
    rule_set_name: str = None

    """
    Base class for rule implementations using the decorator pattern.
    Allows defining multiple cases (check & transform pairs) within a single class.
    """

    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)
        self._matched_case: Optional[RuleCase] = None
        # fixme: matched_pattern을 rulecase가 가지는게 더 나을 것 같은데?
        # fixme: 지금 구현은 matched_patten을 object로 return하지 않기 때문에 병렬화 불가능 함.
        self._matched_pattern: Any = None
        self._rules = []

        for attr_name in dir(self.__class__):
            try:
                cls_attr = getattr(self.__class__, attr_name)
                if isinstance(cls_attr, RuleCase):
                    self._rules.append(cls_attr)
            except AttributeError:
                pass

        self._rules.sort(key=lambda x: x.case_name or x.name)

    def __repr__(self):
        case = self._matched_case if self._matched_case is not None else "NA"
        return f"{self.rule_set_name}.{self.__class__.__qualname__}.{case}"

    def clear_result(self):
        self._matched_pattern = None
        self._matched_case = None

    @property
    def matched_case(self):
        return self._matched_case

    @property
    def matched_pattern(self):
        return self._matched_pattern

    def check(self, op: Operator, **kwargs) -> bool:
        """Iterates and checks all registered cases.
        If a case's check function returns a truthy value (pattern), matches that case and returns True.
        """
        for rule in self._rules:
            # rule.check_func is unbounded, we pass 'self' here.
            res = rule.check_func(self, op, **kwargs)
            if res:
                self._matched_case = rule
                self._matched_pattern = res
                return True
        return False

    def transform(self, *args, **kwargs) -> OperatorTransformResult_T:
        """Executes the transformation logic for the currently matched case."""
        if self._matched_case is None:
            raise NotImplementedError("matched case is None.")
        return self._matched_case.transform_func(self, *args, **kwargs)


class RuleSet:
    def __init__(self, name):
        self._registry = {}
        self._backend_except = {"tf": [], "onnx": [], "tflite": []}
        self._name = name

    def name(self):
        return self._name

    def register_except(self, backend):
        def decorator(rule_cls):
            self._backend_except[backend].append(rule_cls.__name__)

        return decorator

    def register(self, rule_cls):
        if rule_cls.__name__ in self._registry:
            raise KeyError(f"Duplicate rule name: {rule_cls.__name__}")
        rule_cls.rule_set_name = self._name
        self._registry[rule_cls.__name__] = rule_cls
        return rule_cls

    def get(self, rule_name: Union[List[str], str], backend=None, **kwargs):
        if isinstance(rule_name, str):
            return [self._registry[rule_name](**kwargs)]
        lst = []
        for name in rule_name:
            if backend and name in self._backend_except.get(backend, []):
                continue  # We don't add a rule if the rule name is registered as an exception.
            if name not in self._registry:
                raise KeyError("Unknown rule: {}".format(name))
            lst.append(self._registry[name](**kwargs))
        return lst

    def get_all_names(self):
        return list(self._registry.keys())

    def get_all_rules(self) -> List[TransformRule]:
        return list(cls() for cls in self._registry.values())
