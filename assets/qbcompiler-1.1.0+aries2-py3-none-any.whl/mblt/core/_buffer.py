import abc
import mmap
import pathlib
import platform


class BufferBase(abc.ABC):
    def __init__(
        self,
        buffer_file_path,
        max_buffer_size,
        last_buffer_size,
        num_buffers,
        is_single_file=True,
    ):
        self._is_single_file = is_single_file
        self._buffer_file_path = buffer_file_path
        self._max_buffer_size = max_buffer_size
        self._last_buffer_size = last_buffer_size
        self._num_buffers = num_buffers

    @property
    def total_buffer_size(self):
        """Calculate total size of all buffers."""
        return (self._num_buffers - 1) * self._max_buffer_size + self._last_buffer_size

    @abc.abstractmethod
    def _generate_bytes(self, buffer_idx, offset, size):
        """Generate bytes from the buffer. Must be implemented by subclasses."""
        pass

    def read_bytes(self, buffer_idx, offset, size):
        """Read bytes from the buffer at the specified position."""
        return b"".join(self._generate_bytes(buffer_idx, offset, size))

    @abc.abstractmethod
    def close(self):
        """Close the buffer and release resources. Must be implemented by subclasses."""
        pass


class MmapBuffer(BufferBase):
    _MMAP_BLOCKSIZE_MB = 128

    def __init__(
        self,
        buffer_file_path,
        max_buffer_size,
        last_buffer_size,
        num_buffers,
        is_single_file=True,
    ):
        super().__init__(
            buffer_file_path,
            max_buffer_size,
            last_buffer_size,
            num_buffers,
            is_single_file,
        )

        if not is_single_file:
            raise NotImplementedError(f"is_single_file={is_single_file}")

        self._mmap_pagesize = -1
        self._mmap_max_blksize = -1
        # last_mmap_block, last_mmap_block_last_buff
        self._mmap_blksize_last = [-1, -1]
        self._num_mmap_blk_per_buff = [-1, -1]  # not last buffer, last buffer

        self._set_mmap_info()

        self._fp = pathlib.Path(self._buffer_file_path).open("rb")
        self._mm = None
        self._curr_buff_idx = -1
        self._curr_mmap_idx = -1

    def _set_mmap_info(self):
        if platform.system() == "Linux":
            self._mmap_pagesize = mmap.PAGESIZE
        elif platform.system() == "Windows":
            self._mmap_pagesize = mmap.ALLOCATIONGRANULARITY
        else:
            raise NotImplementedError(f"Unsupported platform: {platform.system()}")

        if self._max_buffer_size % self._mmap_pagesize != 0:
            raise NotImplementedError(
                f"max_buffer_size should be multiple of mmap_pagesize, but got"
                f" max_buffer_size={self._max_buffer_size}, mmap_pagesize={self._mmap_pagesize} "
            )
        mm_blk_size = (
            (MmapBuffer._MMAP_BLOCKSIZE_MB * 1024 * 1024) // self._mmap_pagesize
        ) * self._mmap_pagesize
        self._mmap_max_blksize = mm_blk_size

        for idx, bsize in enumerate((self._max_buffer_size, self._last_buffer_size)):
            q, r = divmod(bsize, mm_blk_size)
            self._mmap_blksize_last[idx] = mm_blk_size if r == 0 else r
            self._num_mmap_blk_per_buff[idx] = q if r == 0 else q + 1

    def close(self):
        if self._mm:
            self._mm.close()
        if self._fp:
            self._fp.close()

    def _align_mm(self, buffer_idx, mmap_block_idx, mmap_block_length):
        def _prepare_mm():
            if self._mm:
                self._mm.close()
            if platform.system() == "Windows":
                self._mm = mmap.mmap(
                    self._fp.fileno(),
                    length=mmap_block_length,
                    offset=buffer_idx * self._max_buffer_size
                    + mmap_block_idx * self._mmap_max_blksize,
                    access=mmap.ACCESS_READ,
                )
            else:
                self._mm = mmap.mmap(
                    self._fp.fileno(),
                    length=mmap_block_length,
                    offset=buffer_idx * self._max_buffer_size
                    + mmap_block_idx * self._mmap_max_blksize,
                    prot=mmap.PROT_READ,
                )

        if buffer_idx != self._curr_buff_idx:
            _prepare_mm()
            self._curr_buff_idx = buffer_idx
            self._curr_mmap_idx = mmap_block_idx
        elif mmap_block_idx != self._curr_mmap_idx:
            _prepare_mm()
            self._curr_mmap_idx = mmap_block_idx

    def _mm_blk_info(self, buff_offset_, is_last_buff: int):
        mm_block_idx, mm_offset = divmod(buff_offset_, self._mmap_max_blksize)
        if mm_block_idx == self._num_mmap_blk_per_buff[is_last_buff] - 1:
            return mm_block_idx, mm_offset, self._mmap_blksize_last[is_last_buff]
        return mm_block_idx, mm_offset, self._mmap_max_blksize

    def _generate_bytes(self, buffer_idx, offset, size):
        size_ = int(size)
        offset_ = int(offset)
        buffer_idx_ = int(buffer_idx)
        while size_ > 0:
            is_last_buff = int(buffer_idx_ == self._num_buffers - 1)
            mm_blk_idx, mm_offset, mm_blk_len = self._mm_blk_info(offset_, is_last_buff)
            self._align_mm(buffer_idx_, mm_blk_idx, mm_blk_len)
            self._mm.seek(mm_offset)
            read_size = min(size_, mm_blk_len - mm_offset)
            yield self._mm.read(read_size)
            size_ -= read_size
            if mm_blk_idx == self._num_mmap_blk_per_buff[is_last_buff] - 1:
                # next buffer
                buffer_idx_ += 1
                offset_ = 0
            else:
                offset_ += read_size


class NaiveBuffer(BufferBase):
    _BUFF_SIZE_LIMIT = 2**32  # 4GB

    def __init__(
        self,
        buffer_file_path,
        max_buffer_size,
        last_buffer_size,
        num_buffers,
        is_single_file=True,
    ):
        super().__init__(
            buffer_file_path,
            max_buffer_size,
            last_buffer_size,
            num_buffers,
            is_single_file,
        )

        if not is_single_file:
            raise NotImplementedError(f"is_single_file={is_single_file}")

        self._b = b""

        with pathlib.Path(self._buffer_file_path).open("rb") as f:
            read_size = (
                self._num_buffers - 1
            ) * self._max_buffer_size + self._last_buffer_size
            self._b = f.read(read_size)

    def _generate_bytes(self, buffer_idx, offset, size):
        size_ = int(size)
        offset_ = int(offset)
        buffer_idx_ = int(buffer_idx)
        while size_ > 0:
            is_last_buff = buffer_idx_ == self._num_buffers - 1
            curr_buf_cap = (
                self._last_buffer_size if is_last_buff else self._max_buffer_size
            )
            remaining_in_buf = curr_buf_cap - offset_
            if remaining_in_buf <= 0:
                break
            read_size = min(size_, remaining_in_buf)
            start_ = self._max_buffer_size * buffer_idx_ + offset_
            yield memoryview(self._b)[start_ : start_ + read_size]
            size_ -= read_size
            if size_ <= 0:
                break
            buffer_idx_ += 1
            offset_ = 0

    def close(self):
        return
