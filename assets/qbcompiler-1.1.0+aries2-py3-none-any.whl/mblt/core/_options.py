from __future__ import annotations

import dataclasses
import enum
import numbers
import re
import typing
from typing import Any, Union, Tuple, Optional, Type

import numpy

from ._types import (
    int8,
    int16,
    int32,
    int64,
    uint8,
    uint32,
    uint64,
    float32,
    float64,
    TensorIndex,
)
from .util import to_dict_helper

_CODE_SHOULD_NOT_BE_REACHED = RuntimeError("Code should not be reached!")


def _type_unmachted_error(value: Any, dtype: Any, name: str) -> TypeError:
    """
    Create a TypeError for type mismatch.

    Args:
        value: The actual value provided
        dtype: The expected dtype
        name: The field name

    Returns:
        TypeError with descriptive message
    """
    return TypeError(
        f"The value `{value}` of type {type(value)} assigned to the field `{name}` of type `{dtype}`"
    )


class Symbol(enum.Enum):
    """
    Enumeration of all supported type symbols in the type system.

    Symbols represent both primitive Python types and custom types,
    enabling a uniform type representation system for validation.
    """

    # special types
    NoneType = enum.auto()
    Ellipsis = enum.auto()

    # py built-in types
    bool = enum.auto()
    int = enum.auto()
    float = enum.auto()
    str = enum.auto()

    # py containers
    list = enum.auto()
    tuple = enum.auto()
    union = enum.auto()
    dict = enum.auto()

    # singed int
    int8 = enum.auto()
    int16 = enum.auto()
    int32 = enum.auto()
    int64 = enum.auto()

    # unsigned int
    uint8 = enum.auto()
    uint32 = enum.auto()
    uint64 = enum.auto()

    # floating point
    float32 = enum.auto()
    float64 = enum.auto()

    # domain specific types
    TensorIndex = enum.auto()


_SYMBOL_TO_TYPE = {
    Symbol.NoneType: None,
    Symbol.bool: bool,
    Symbol.str: str,
    Symbol.list: list,
    Symbol.tuple: tuple,
    Symbol.dict: dict,
}

_SYMBOL_TO_TYPE_SIGNED_INT = {
    Symbol.int: int,
    Symbol.int8: int8,
    Symbol.int16: int16,
    Symbol.int32: int32,
    Symbol.int64: int64,
}
_SYMBOL_TO_TYPE_UNSIGNED_INT = {
    Symbol.uint8: uint8,
    Symbol.uint32: uint32,
    Symbol.uint64: uint64,
}
_SYMBOL_TO_TYPE_FLOATING = {
    Symbol.float: float,
    Symbol.float32: float32,
    Symbol.float64: float64,
}
_SYMBOL_TO_TYPE.update(_SYMBOL_TO_TYPE_SIGNED_INT)
_SYMBOL_TO_TYPE.update(_SYMBOL_TO_TYPE_UNSIGNED_INT)
_SYMBOL_TO_TYPE.update(_SYMBOL_TO_TYPE_FLOATING)
_SYMBOL_TO_TYPE[Symbol.TensorIndex] = TensorIndex

# Reverse mapping: type name -> symbol
_TYPE_TO_SYMBOL = {v.__name__: k for k, v in _SYMBOL_TO_TYPE.items() if v is not None}
_TYPE_TO_SYMBOL["NoneType"] = Symbol.NoneType


# Annotation Parsing
def tuple_to_symbol(t):
    """Convert tuple annotation to symbol representation."""
    return tuple(annotations_to_symbol(x) for x in t)


def type_to_symbol(t, value=None):
    """
    Convert a Python type to its corresponding Symbol.
    """
    if (v := _TYPE_TO_SYMBOL.get(t.__name__, None)) is not None:
        return v
    raise NotImplementedError(f"Unknown type: {t.__name__}")


def typing_genericalias_to_symbol(t):
    name, args_t = t._name, t.__args__

    if name == "List":
        if len(args_t) == 0 or str(args_t[0]) == "~T":
            return (Symbol.list,)
        return Symbol.list, annotations_to_symbol(args_t)
    if name == "Tuple":
        if len(args_t) == 0:
            return Symbol.tuple
        v = annotations_to_symbol(args_t)
        return Symbol.tuple, v
    if name == "Optional":
        # typing.Optional python version 3.10
        return Symbol.union, annotations_to_symbol(args_t)
    if name is None:
        # typing.Optional python version 3.8
        if str(t).startswith("typing.Union") or str(t).startswith("Union"):
            return Symbol.union, annotations_to_symbol(args_t)
    raise NotImplementedError(f"Unsupported generic alias: {t}")


def is_nonspecial_value_type(s: Symbol):
    """
    Check if symbol represents a value type (not a container or special type).
    """
    return s not in (
        Symbol.NoneType,
        Symbol.Ellipsis,
        Symbol.list,
        Symbol.tuple,
        Symbol.union,
    )


def _is_int_type(dtype_symbol: Symbol) -> bool:
    return is_signed_int_types(dtype_symbol) or is_uint_types(dtype_symbol)


def _is_float_type(dtype_symbol: Symbol) -> bool:
    return is_floating_types(dtype_symbol)


def is_signed_int_types(s: Symbol) -> bool:
    return s in _SYMBOL_TO_TYPE_SIGNED_INT


def is_uint_types(s: Symbol) -> bool:
    return s in _SYMBOL_TO_TYPE_UNSIGNED_INT


def is_floating_types(s: Symbol) -> bool:
    return s in _SYMBOL_TO_TYPE_FLOATING


def symbol_to_type(s: Symbol) -> Optional[Type]:
    if s in _SYMBOL_TO_TYPE:
        return _SYMBOL_TO_TYPE[s]
    raise NotImplementedError(f"Unknown symbol: {s}")


def symbol_to_type_wrapper(s: Symbol) -> Type:
    if s == Symbol.TensorIndex:
        return TensorIndex
    return symbol_to_type(s)


def _int_casting_rules(value: Any, dtype: Symbol):
    """
    Determine if value can be cast to an integer type.
    """
    return _is_int_type(dtype) and (
        isinstance(value, numbers.Integral)
        or numpy.issubdtype(type(value), numpy.integer)
    )


def _float_casting_rules(value, dtype):
    return is_floating_types(dtype) and (
        numpy.issubdtype(type(value), numpy.floating)
        or numpy.issubdtype(type(value), numpy.integer)
    )


def annotations_to_symbol(t: Any) -> Union[Symbol, Tuple]:
    if isinstance(t, Symbol):
        return t
    if str(t) == "Ellipsis":
        return Symbol.Ellipsis
    if str(t) == "typing.Tuple":  # due to the typing version issue
        return Symbol.tuple
    if str(t) == "typing.Dict":
        return Symbol.dict
    if isinstance(t, tuple):
        return tuple_to_symbol(t)
    if isinstance(t, type):
        return type_to_symbol(t)
    if isinstance(t, typing._GenericAlias):
        return typing_genericalias_to_symbol(t)
    raise NotImplementedError(f"Cannot convert annotation to symbol: {t}")


def parse_annotation(field_annotation: Any) -> Union[Symbol, Tuple]:
    """
    Parse a field annotation and return its symbol representation.

    Args:
        field_annotation: Type annotation from a class field

    Returns:
        Symbol or tuple of symbols representing the annotation
    """
    return annotations_to_symbol(field_annotation)


def parse_dataclass_annotations(obj):
    if not dataclasses.is_dataclass(obj):
        return TypeError("obj is not a dataclass.")

    annotations = obj.__annotations__
    return {k: annotations_to_symbol(v) for k, v in annotations.items()}


def get_value_type(value: Any) -> Union[Symbol, Tuple[Symbol, ...]]:
    """
    Infer the symbol type of a value.
    """
    sym = type_to_symbol(type(value), value)
    if sym in (Symbol.list, Symbol.tuple):
        if value:
            return sym, (get_value_type(value[0]),)
        return sym
    if sym in (Symbol.Ellipsis, Symbol.union):
        raise _CODE_SHOULD_NOT_BE_REACHED
    return sym


def _check_tuple(value, dtype, name):
    """
    Validate tuple type and its elements.
    """
    if not isinstance(value, tuple):
        raise _type_unmachted_error(value, dtype, name)
    if not value:  # vacuous truth
        return
    if Symbol.Ellipsis in dtype:  # homogeneous tuple
        expected_type = dtype[0]
        if not all(get_value_type(v) == expected_type for v in value):
            raise _type_unmachted_error(value, dtype, name)
    else:
        # Heterogeneous tuple - check each element
        if len(value) != len(dtype):
            raise _type_unmachted_error(value, dtype, name)
        val_types = [get_value_type(v) for v in value]
        if not all(vt == dt for vt, dt in zip(val_types, dtype)):
            raise _type_unmachted_error(value, dtype, name)


def _check_list(value, dtype, name):
    if not isinstance(value, list):
        raise _type_unmachted_error(value, dtype, name)
    if not value:
        return
    expected_type = dtype[0]
    if not all(get_value_type(v) == expected_type for v in value):
        raise _type_unmachted_error(value, dtype, name)


def _check_union(value, dtype, name):
    # Handle Optional[T] = Union[T, None]
    # we do not allow union types such as union[int32, float32]
    if Symbol.NoneType in dtype[1]:
        if len(dtype[1]) > 2:
            raise NotImplementedError(f"Complex union type: {dtype}")
        if value is None:
            return
        check_type(value, dtype[1][0], name)
    else:
        raise NotImplementedError(f"Non-optional union type: {dtype}")


def check_type(value, dtype, name):
    if isinstance(dtype, tuple):
        if len(dtype) == 1:
            raise _CODE_SHOULD_NOT_BE_REACHED
        if dtype[0] == Symbol.tuple:
            _check_tuple(value, dtype[1], name)
        elif dtype[0] == Symbol.list:
            _check_list(value, dtype[1], name)
        elif dtype[0] == Symbol.union:
            _check_union(value, dtype, name)
        else:
            raise _type_unmachted_error(value, dtype, name)
    else:
        if not get_value_type(value) == dtype:
            raise _type_unmachted_error(value, dtype, name)


def _dim_value_to_int(v):
    if v.__class__.__name__ == "DimValue":
        v = int(v)
    return v


def _get_value_if_numarr(value: Any) -> Any:
    """
    Extract scalar value from numpy array if applicable.
    """
    if isinstance(value, numpy.ndarray):
        if len(value.shape) == 0 and value.size == 1:
            return value.item()
        if value.shape == (1,) and value.size == 1:
            return value[0]
    return value


def coercion_(value, dtype, field_name):
    """
    Coerce value to the specified dtype with validation.

    Args:
        value: Value to coerce
        dtype: Target dtype as Symbol or tuple of Symbols
        field_name: Name of the field being processed (for error messages)

    Returns:
        Coerced value of the correct type
    """

    if isinstance(value, tuple):
        value = tuple(_dim_value_to_int(x) for x in value)
    elif isinstance(value, list):
        value = list(_dim_value_to_int(x) for x in value)
    else:
        value = _dim_value_to_int(value)

    if isinstance(dtype, tuple):
        if len(dtype) == 1:
            raise NotImplementedError(f"Single-element dtype tuple: {dtype}")

        if dtype[0] == Symbol.tuple:
            args_t = dtype[1]
            if Symbol.Ellipsis in args_t:
                # Tuple[int, ...]
                args_t = tuple(
                    symbol_to_type_wrapper(args_t[0]) for _ in range(len(value))
                )
            else:
                # Tuple[int, str, float]
                args_t = tuple(symbol_to_type_wrapper(x) for x in args_t)

            if len(value) != len(args_t):
                raise ValueError(
                    f"number of items are different for field `{field_name}`: {value}, {args_t}"
                )
            return tuple(item_t(item) for item, item_t in zip(value, args_t))

        if dtype[0] == Symbol.list:  # List[int]
            args_t = dtype[1]
            item_type = symbol_to_type_wrapper(args_t[0])
            return list(item_type(item) for item in value)

        if dtype[0] == Symbol.union:  # Union type (mainly for Optional)
            if Symbol.NoneType in dtype[1]:
                if value is None:
                    return value
                if len(dtype[1]) > 2:
                    raise NotImplementedError(f"Complex union type: {dtype}")
                return coercion_(value, dtype[1][0], field_name)
            raise NotImplementedError(f"{dtype}")
        raise NotImplementedError(f"Unknown complex dtype: {dtype}")

    # here we define casting rules.
    # Handle simple types
    value = _get_value_if_numarr(value)

    if dtype == Symbol.tuple:
        if isinstance(value, list) and len(value) == 0:
            return tuple()
    if dtype == Symbol.str:
        return value
    if dtype == Symbol.TensorIndex:
        return TensorIndex(value)
    if dtype == Symbol.bool and value in (0, 1):
        return bool(value)
    if _int_casting_rules(value, dtype):
        return symbol_to_type_wrapper(dtype)(value)
    if _float_casting_rules(value, dtype):
        return symbol_to_type_wrapper(dtype)(value)
    return value


class TypeEnforcedMixin:
    """
    Mixin class for dataclasses with type enforcement and validation.

    Example:
    @dataclasses.dataclass
    class MyOptions(TypeEnforced):
        count: int32
        values: List[float32]
        optional: Optional[int] = None

    opt = MyOptions(count=10, values=[1.5, 2.5])
    """

    def __post_init__(self):
        """Validate and coerce all fields to their declared types"""
        for field_name, field_type in self.__annotations__.items():
            parsed = parse_annotation(field_type)
            value = getattr(self, field_name)

            try:
                # Coerce value to correct type
                coerced_value = coercion_(value, parsed, field_name)
                # Validate the coerced value
                check_type(coerced_value, parsed, field_name)
                # Set the validated value
                setattr(self, field_name, coerced_value)
            except Exception as e:
                if hasattr(field_type, "__name__"):
                    type_str = field_type.__name__
                else:
                    type_str = str(field_type)
                    # Remove module prefixes
                    type_str = type_str.replace("numpy.", "").replace("typing.", "")
                    # Remove module path from custom types
                    type_str = re.sub(r"<class '[\w.]*\.(\w+)'>", r"\1", type_str)

                raise TypeError(
                    f"Type validation failed for {self.__class__.__name__}.{field_name}: "
                    f"value={value}, expected type={type_str}. {type(e).__name__}: {e}"
                ) from e


class LayerOptions:
    _REGISTRY = None
    inputs: Tuple
    outputs: Tuple

    def iter_tensorindex(self: LayerOptions):
        for field in dataclasses.fields(self):
            v = getattr(self, field.name)
            if isinstance(v, TensorIndex):
                yield field.name, v

    def to_dict(self):
        dct = {
            field.name: to_dict_helper(getattr(self, field.name))
            for field in dataclasses.fields(self)
        }
        # LayerOptions cannot be deserialzed without its concrete type.
        dct["type"] = self.__class__.__name__
        return dct

    @classmethod
    def from_dict(cls, dct):
        type_name = dct.pop("type")

        if cls._REGISTRY is None:
            from mblt.core._optionsimpl import OptionsRegistry

            cls._REGISTRY = OptionsRegistry
        try:
            subclass = cls._REGISTRY.getcls(type_name.replace("Options", ""))
        except Exception as e:
            print(e)
            subclass = cls._REGISTRY.getcls("CustomOp")
            import json

            content = json.dumps(dct, indent=2)
            dct = {
                "inputs": dct["inputs"],
                "outputs": dct["outputs"],
                "content": content,
            }
        return subclass(**dct)

    def iter_fields(self):
        for field in dataclasses.fields(self):
            yield field.name, getattr(self, field.name)


def replace_options(options: LayerOptions, **kwargs):
    return dataclasses.replace(options, **kwargs)
