from __future__ import annotations

from typing import Tuple

from ._array_wrapper import ArrayWrapper
from ._types import Shape

__all__ = ["TensorSpec"]


class TensorSpec:
    def __init__(
        self,
        name: str,
        dtype: str,
        shape: Tuple[int, ...],
        buffer_idx: int = -1,
        offset: int = -1,
    ):
        self.name = name
        self.dtype = dtype
        self.shape = Shape(shape)
        # a single tensor can be splitted and saved into several buffers, however,
        # we only need to know its starting position since data is sequentially saved.
        # will be filled during serialization
        self.buffer_idx = buffer_idx
        self.offset = offset
        self._value: ArrayWrapper = None

    def __repr__(self):
        return f"name={self.name}, {self.dtype}{self.shape}"

    def set_value(self, value=None):
        if isinstance(value, ArrayWrapper):
            self._value = value
        else:
            self._value = ArrayWrapper(value)

    @property
    def value(self):
        if self._value is None:
            raise ValueError("TensorSpec has no value")
        return self._value.value

    @property
    def nbytes(self) -> int:
        assert self._value is not None
        return self._value.nbytes

    @property
    def ndim(self):
        return len(self.shape)

    def copy(self, name=None, dtype=None, shape=None, **kwargs):
        return TensorSpec(
            name or self.name,
            dtype or self.dtype,
            shape or self.shape,
        )

    def to_dict(self):
        return {
            "cls": self.__class__.__name__,
            "name": self.name,
            "dtype": str(self.dtype),
            "shape": tuple(map(int, self.shape)),
            "buffer_idx": self.buffer_idx,
            "offset": self.offset,
        }

    @classmethod
    def from_dict(cls, data: dict):
        is_legacy = "cls" not in data
        inst = cls(
            name=data["name"],
            dtype=data["dtype"],
            shape=Shape.from_dict(data["shape"]),
            offset=data["offset"],
            buffer_idx=data["buffer_idx"],
        )
        return inst
