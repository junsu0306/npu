from __future__ import annotations

from typing import TYPE_CHECKING, Optional, Tuple, Union

from ._activation import ActivationSpec
from ._options import LayerOptions
from ._optionsimpl import LayerType
from ._optionsimpl import OptionsRegistry as LayerOptionsRegistry
from ._tensor import TensorSpec
from ._types import SHAPELIKE, Shape, TensorIndex

if TYPE_CHECKING:
    from ._subgraph import SubGraph


class Operator:

    def __init__(self, name="", options: LayerOptions = None, unsupported: bool = True):
        if options is None:
            raise ValueError("options cannot be None")
        self._name = name
        self.options: LayerOptions = options
        self.unsupported = unsupported

        # field for intermediate parsing steps but not serialized
        self.exclude_from_transform = False
        self.valid = True
        self._sg: Optional[SubGraph] = None

    def set_invalid(self):
        self.valid = False
        self._sg = None

    @property
    def name(self) -> str:
        if self._sg is None:
            return self._name
        return self._sg.activations[self.options.outputs[0]].name

    @property
    def real_name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str):
        self._name = value

    def __call__(self, *args, **kwargs):
        impl_func = OperatorRegistry.get_call_impl(self.layertype)
        return impl_func(self, *args, **kwargs)

    def infer_shape(self, *input_shape: SHAPELIKE, **kwargs) -> Optional[Shape]:
        impl_func = OperatorRegistry.get_shape_inference(self.layertype)
        return impl_func(self, *input_shape, **kwargs)

    def get_ops_count(self, *args, **kwargs):
        impl_func = OperatorRegistry.get_ops_count(self.layertype)
        return impl_func(self, *args, **kwargs)

    def set_subgraph(self, sg: Optional[SubGraph] = None):
        self._sg = sg

    @property
    def subgraph(self) -> SubGraph:
        return self._sg

    def iter_fields(self):
        """
        Iterate over fields in the object's options.

        This method yields key-value pairs from the object's options, with special
        handling for TensorIndex values. When a value is a TensorIndex, it is
        converted to the corresponding tensor from the object's tensor storage.
        If the TensorIndex equals -1, the field is skipped. For non-TensorIndex
        values, the original value is yielded as-is.

        Yields
        ------
        tuple
            Key-value pairs where the value is either a tensor from the tensor
            storage (when key's value is a valid TensorIndex) or the original
            value (for non-TensorIndex values).
        """
        for k, v in self.options.iter_fields():
            if isinstance(v, TensorIndex):
                if v == -1:
                    continue
                yield k, self._sg.tensors[v]
            else:
                yield k, v

    @property
    def next_operators(self):
        if self._sg is None:
            raise RuntimeError(f"Subgraph not initialized for operator '{self.name}'")
        return [op for oact in self.outacts for op in oact.consumer_ops]

    @property
    def inacts(self) -> Tuple[ActivationSpec, ...]:
        if self._sg is None:
            raise RuntimeError(f"Subgraph not initialized for operator '{self.name}'")
        return tuple(self._sg.activations[x] for x in self.options.inputs)

    @property
    def tensors(self) -> Tuple[TensorSpec, ...]:
        if self._sg is None:
            raise RuntimeError(f"Subgraph not initialized for operator '{self.name}'")
        return tuple(
            self._sg.tensors[tidx]
            for _, tidx in self.options.iter_tensorindex()
            if tidx != -1
        )

    def get_tensor(self, tensor_index: TensorIndex):
        if self._sg is None:
            raise RuntimeError(f"Subgraph not initialized for operator '{self.name}'")
        return self._sg.tensors[tensor_index]

    @property
    def outacts(self) -> Tuple[ActivationSpec, ...]:
        if self._sg is None:
            raise RuntimeError(f"Subgraph not initialized for operator '{self.name}'")
        return tuple(self._sg.activations[x] for x in self.options.outputs)

    def __repr__(self):
        inputs = tuple(map(int, self.options.inputs))
        outputs = tuple(map(int, self.options.outputs))
        if self.valid:
            return f"[{id(self._sg)}]{self.layertype.name}[{inputs}->{outputs}, {self.name}, {self.real_name}]"
        else:
            return f"[{id(self._sg)}]{self.layertype.name}[{inputs}->{outputs}, #INVALID, {self.real_name}]"

    @property
    def layertype(self) -> LayerType:
        return LayerOptionsRegistry.get_option_type(self.options)

    def to_dict(self):
        return {
            "name": self.name,
            "options": self.options.to_dict(),
            "unsupported": self.unsupported,
        }

    @classmethod
    def from_dict(cls, data: dict) -> Operator:
        options = LayerOptions.from_dict(data["options"])
        operator = cls(
            name=data["name"],
            options=options,
            unsupported=data.get("unsupported", False),
        )
        return operator


class OperatorRegistry:
    _impl_registry = {}  # (LayerType, callable)
    _shape_inference_registry = {}  # (LayerType, callable)
    _ops_count_registry = {}  # (LayerType, callable)

    @staticmethod
    def get_call_impl(layertype: Union[LayerType, str]):
        if isinstance(layertype, str):
            if layertype not in LayerType.__members__:
                raise ValueError(f"{layertype} not in LayerType")
            layertype = LayerType[layertype]
        impl_func = OperatorRegistry._impl_registry.get(layertype, None)
        if impl_func is None:
            raise NotImplementedError(
                f"__call__ not implemented for this kind: {layertype.name}"
            )
        return impl_func

    @staticmethod
    def register_call_fn(layertype):
        def _register(func):
            OperatorRegistry._impl_registry[layertype] = func
            return func

        return _register
    
    @staticmethod
    def get_ops_count(layertype: Union[LayerType, str]):
        if isinstance(layertype, str):
            if layertype not in LayerType.__members__:
                raise ValueError(f"{layertype} not in LayerType")
            layertype = LayerType[layertype]
        impl_func = OperatorRegistry._ops_count_registry.get(layertype, None)
        if impl_func is None:
            raise NotImplementedError(
                f"ops_count not implemented for this kind: {layertype.name}"
            )
        return impl_func

    @staticmethod
    def register_ops_count(layertype):
        def _register(func):
            OperatorRegistry._ops_count_registry[layertype] = func
            return func

        return _register

    @staticmethod
    def get_shape_inference(layertype: Union[LayerType, str]):
        if isinstance(layertype, str):
            if layertype not in LayerType.__members__:
                raise ValueError(f"{layertype} not in LayerType")
            layertype = LayerType[layertype]
        impl_func = OperatorRegistry._shape_inference_registry.get(layertype, None)
        if impl_func is None:
            raise NotImplementedError(
                f"infer_shape not implemented for this kind: {layertype.name}"
            )
        return impl_func

    @staticmethod
    def register_infer_shape(layertype):
        def _register(func):
            OperatorRegistry._shape_inference_registry[layertype] = func
            return func

        return _register
