from __future__ import annotations

import logging
from typing import Optional, Union


_LOGGER: Optional[logging.Logger] = None


def _create_default_logger() -> logging.Logger:
    """Create and return the default logger for the mblt package.

    The default logger:
    - is named "mblt"
    - logs at INFO level by default
    - writes to stderr with a concise formatter
    - avoids adding duplicate handlers if called multiple times
    """
    logger = logging.getLogger("mblt")
    logger.setLevel(logging.INFO)
    # Prevent duplicate handlers when re-imported
    if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            fmt="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    logger.propagate = False
    return logger


def set_logger(logger: logging.Logger) -> None:
    """Set a custom logger to be used across the entire mblt package.

    Parameters
    ----------
    logger: logging.Logger
        The logger instance to use globally within mblt.
    """
    global _LOGGER
    _LOGGER = logger


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """Get the configured mblt logger or its child.

    If no custom logger was provided via ``set_logger``, a sensible default logger is created
    and returned. When ``name`` is provided, a child logger of the configured base logger is
    returned so that components can have hierarchical names like ``mblt.subgraph.builder``.

    Parameters
    ----------
    name: Optional[str]
        Optional child logger name appended to the base logger's name.

    Returns
    -------
    logging.Logger
        The configured base logger or a child logger.
    """
    base = _LOGGER or _create_default_logger()
    if name:
        # Ensure child is properly namespaced under the base logger
        base_name = base.name or "mblt"
        return logging.getLogger(f"{base_name}.{name}")
    return base


def _coerce_level(level: Union[int, str]) -> int:
    """Convert a level name or numeric value to a logging level integer.

    Accepts common string names like "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL" (case-insensitive),
    as well as their numeric equivalents (e.g., 10, 20...).
    """
    if isinstance(level, int):
        return level
    if isinstance(level, str):
        name = level.upper().strip()
        value = getattr(logging, name, None)
        if isinstance(value, int):
            return value
    raise ValueError(f"Invalid logging level: {level!r}")


def set_log_level(level: Union[int, str]) -> None:
    """Set the log level for the base mblt logger (and its handlers).

    Parameters
    ----------
    level: Union[int, str]
        The desired log level (e.g., "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL" or their numeric values).
    """
    base = _LOGGER or _create_default_logger()
    lvl = _coerce_level(level)
    base.setLevel(lvl)
    # Keep handler levels in sync unless they were explicitly set to something else previously.
    for handler in base.handlers:
        # If handler level is NOTSET, raise it to the chosen level so output respects the base level.
        if handler.level == logging.NOTSET or handler.level > lvl:
            handler.setLevel(lvl)

    # Update all child loggers under the mblt namespace
    base_name = base.name or "mblt"
    for logger_name in list(logging.Logger.manager.loggerDict.keys()):
        if logger_name.startswith(f"{base_name}."):
            child_logger = logging.getLogger(logger_name)
            if isinstance(child_logger, logging.Logger):
                child_logger.setLevel(lvl)


__all__ = ["set_logger", "get_logger", "set_log_level"]
