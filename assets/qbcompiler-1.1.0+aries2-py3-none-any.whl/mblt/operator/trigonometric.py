from typing import Optional


from mblt.core import (
    LayerType,
    SHAPELIKE,
    Shape,
    ActivationSpec,
    Operator,
    OperatorRegistry,
)


@OperatorRegistry.register_infer_shape(LayerType.Sin)
def infer_shape(op: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    assert len(input_shape) == 1
    return Shape(input_shape[0])


@OperatorRegistry.register_call_fn(LayerType.Sin)
def call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name=self.layertype.name.lower(),
        dtype=args[0].dtype,
        src_shape=self.infer_shape(args[0].src_shape),
    )


def trigonometric_ops_count(self: Operator, *args, **kwargs):
    input_shape = self.inacts[0].src_shape
    return input_shape.numel()


@OperatorRegistry.register_infer_shape(LayerType.Cos)
def infer_shape(op: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    assert len(input_shape) == 1
    return Shape(input_shape[0])


@OperatorRegistry.register_call_fn(LayerType.Cos)
def call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name=self.layertype.name.lower(),
        dtype=args[0].dtype,
        src_shape=self.infer_shape(args[0].src_shape),
    )


@OperatorRegistry.register_ops_count(LayerType.Sin)
def sin_ops_count(self: Operator, *args, **kwargs):
    return trigonometric_ops_count(self, *args, **kwargs)


@OperatorRegistry.register_ops_count(LayerType.Cos)
def cos_ops_count(self: Operator, *args, **kwargs):
    return trigonometric_ops_count(self, *args, **kwargs)
