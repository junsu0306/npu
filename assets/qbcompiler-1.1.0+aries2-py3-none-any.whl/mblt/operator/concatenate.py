from typing import Optional

from mblt.core import (
    SHAPELIKE,
    Shape,
    DimValue,
    ActivationSpec,
    Operator,
    OperatorRegistry,
    LayerType,
)
from .utils import is_dynamic


def _shape_except(shape, axis):
    return tuple(x for idx, x in enumerate(shape) if idx != axis)


@OperatorRegistry.register_call_fn(LayerType.Concatenate)
def call_fn(self: Operator, *args, **kwargs):
    act0 = args[0]
    return ActivationSpec(
        name="concat_out",
        dtype=act0.dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )


@OperatorRegistry.register_infer_shape(LayerType.Concatenate)
def infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    assert self.options.axis is not None
    assert len(input_shape) > 1

    axis = int(self.options.axis)
    if axis < 0:
        axis += len(input_shape[0])
    ref_shape = _shape_except(input_shape[0], axis)
    if any(_shape_except(x, axis) != ref_shape for x in input_shape[1:]):
        raise ValueError(
            f"Concatenate input shape error. input_shape={input_shape}, axis={self.options.axis}"
        )
    output_shape = list(input_shape[0])
    output_shape[axis] = DimValue(
        sum(x[axis] for x in input_shape),
        any(is_dynamic(x[axis]) for x in input_shape),
    )
    return Shape(output_shape)

@OperatorRegistry.register_ops_count(LayerType.Concatenate)
def ops_count(self: Operator, *args, **kwargs):
    return 0