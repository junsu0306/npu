from typing import Optional

from mblt.core import (
    DimValue,
    Shape,
    SHAPELIKE,
    LayerType,
    ActivationSpec,
    OperatorRegistry,
    Operator
)
from .utils import slice_out_length


@OperatorRegistry.register_infer_shape(LayerType.Slice)
def infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Shape]:
    output_shape = list(input_shape[0])
    for i, ax in enumerate(self.options.axis):
        start = self.options.start[i]
        end = self.options.end[i]
        step = self.options.step[i] if self.options.step is not None else 1
        seqlen = output_shape[ax]
        is_free_end = end >= 2147483647
        is_dynamic = getattr(seqlen, "dynamic", False) and (start > 0 and is_free_end)
        sliced_len = slice_out_length(*map(int, (seqlen, start, end, step)))
        output_shape[ax] = DimValue(sliced_len, is_dynamic)
    return Shape(output_shape)


@OperatorRegistry.register_call_fn(LayerType.Slice)
def call_fn(self, *args, **kwargs):
    return ActivationSpec(
        name="slice",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )

@OperatorRegistry.register_ops_count(LayerType.Slice)
def ops_count(self: Operator, *args, **kwargs):
    return 0