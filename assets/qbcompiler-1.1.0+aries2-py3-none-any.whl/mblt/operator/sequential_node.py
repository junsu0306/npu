from typing import Optional, Tuple

from mblt.core import (
    Shape,
    SHAPELIKE,
    OperatorRegistry,
    LayerType,
    Operator,
    ActivationSpec,
)


@OperatorRegistry.register_ops_count(LayerType.StatefulLSTMWrapper)
def ops_count(self: Operator, *args, **kwargs):
    if len(self.inacts) < 1:
        raise RuntimeError(f"{self.layertype.name} expects at least 1 input activation")

    X_shape = self.inacts[0].src_shape
    batch_first = self.options.batch_first
    direction = self.options.direction
    hidden_size = self.options.hidden_size

    if not batch_first:
        raise NotImplementedError("batch_first=False is not supported yet.")

    batch_size, _, seq_len, input_size = X_shape
    num_directions = 2 if direction == "bidirectional" else 1

    # LSTM per hidden element:
    # - 4 gates for input/recurrent affine terms: 8I + 8H
    # - pointwise gate activations and state updates: approximate constant cost
    pointwise_cost = 18
    per_hidden_ops = 8 * input_size + 8 * hidden_size + pointwise_cost

    return batch_size * seq_len * num_directions * hidden_size * per_hidden_ops


@OperatorRegistry.register_infer_shape(LayerType.StatefulLSTMWrapper)
def lstm_infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Tuple[Shape, ...]]:
    X_shape = input_shape[0]
    batch_first = self.options.batch_first
    direction = self.options.direction
    hidden_size = self.options.hidden_size

    if direction == "bidirectional":
        num_directions = 2
    else:
        num_directions = 1

    if batch_first:
        batch_size, _, seq_len, input_size = X_shape
    else:
        raise NotImplementedError("batch_first=False is not supported yet.")
    o_shape = Shape((batch_size, num_directions, seq_len, hidden_size))
    h_shape = Shape((batch_size, 1, num_directions, hidden_size))
    c_shape = Shape((batch_size, 1, num_directions, hidden_size))
    return o_shape, h_shape, c_shape


@OperatorRegistry.register_call_fn(LayerType.StatefulLSTMWrapper)
def lstm_call_fn(self, *args, **kwargs):
    o_shape, h_shape, c_shape = self.infer_shape(*(x.src_shape for x in args))

    if self.options.hidden_state_name:
        h_name = self.options.hidden_state_name
    else:
        h_name = "lstm_h"

    if self.options.cell_state_name:
        c_name = self.options.cell_state_name
    else:
        c_name = "lstm_c"

    o_out = ActivationSpec(name="lstm_o", dtype=args[0].dtype, src_shape=o_shape)
    h_out = ActivationSpec(name=h_name, dtype=args[0].dtype, src_shape=h_shape)
    c_out = ActivationSpec(name=c_name, dtype=args[0].dtype, src_shape=c_shape)
    return o_out, h_out, c_out


@OperatorRegistry.register_infer_shape(LayerType.StatefulGRUWrapper)
def gru_infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Tuple[Shape, ...]]:
    X_shape = input_shape[0]
    batch_first = self.options.batch_first
    direction = self.options.direction
    hidden_size = self.options.hidden_size
    if direction == "bidirectional":
        num_directions = 2
    else:
        num_directions = 1
    if batch_first:
        batch_size, _, seq_len, input_size = X_shape
    else:
        raise NotImplementedError("batch_first=False is not supported yet.")
    o_shape = Shape((batch_size, num_directions, seq_len, hidden_size))
    h_shape = Shape((batch_size, 1, num_directions, hidden_size))
    return o_shape, h_shape


@OperatorRegistry.register_call_fn(LayerType.StatefulGRUWrapper)
def gru_call_fn(self, *args, **kwargs):
    o_shape, h_shape = self.infer_shape(*(x.src_shape for x in args))
    if self.options.hidden_state_name:
        h_name = self.options.hidden_state_name
    else:
        h_name = "gru_h"
    o_out = ActivationSpec(name="gru_o", dtype=args[0].dtype, src_shape=o_shape)
    h_out = ActivationSpec(name=h_name, dtype=args[0].dtype, src_shape=h_shape)
    return o_out, h_out


@OperatorRegistry.register_infer_shape(LayerType.StatefulRNNWrapper)
def rnn_infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Tuple[Shape, ...]]:
    X_shape = input_shape[0]
    batch_first = self.options.batch_first
    direction = self.options.direction
    hidden_size = self.options.hidden_size
    if direction == "bidirectional":
        num_directions = 2
    else:
        num_directions = 1
    if batch_first:
        batch_size, _, seq_len, input_size = X_shape
    else:
        raise NotImplementedError("batch_first=False is not supported yet.")
    o_shape = Shape((batch_size, num_directions, seq_len, hidden_size))
    h_shape = Shape((batch_size, 1, num_directions, hidden_size))
    return o_shape, h_shape


@OperatorRegistry.register_call_fn(LayerType.StatefulRNNWrapper)
def rnn_call_fn(self, *args, **kwargs):
    o_shape, h_shape = self.infer_shape(*(x.src_shape for x in args))
    if self.options.hidden_state_name:
        h_name = self.options.hidden_state_name
    else:
        h_name = "rnn_h"
    o_out = ActivationSpec(name="rnn_o", dtype=args[0].dtype, src_shape=o_shape)
    h_out = ActivationSpec(name=h_name, dtype=args[0].dtype, src_shape=h_shape)
    return o_out, h_out
