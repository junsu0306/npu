from typing import Optional

from mblt import LayerType
from mblt.core import SHAPELIKE, Shape, ActivationSpec, Operator, OperatorRegistry


def infer_shape(self: Operator, *input_shape: SHAPELIKE, **kwargs) -> Optional[Shape]:
    assert len(input_shape) == 1
    k = self.options.k
    axis = self.options.axis
    output_shape = list(input_shape[0])
    output_shape[axis] = int(k)
    return Shape(output_shape)


def call_fn(self: Operator, *args, **kwargs):
    name = self.layertype.name.lower()
    return ActivationSpec(
        name=name,
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )


def ops_count(self: Operator, *args, **kwargs):
    input_shape = self.inacts[0].src_shape
    output_shape = self.outacts[0].src_shape
    axis = self.options.axis
    if axis < 0:
        axis += len(input_shape)

    axis_size = int(input_shape[axis])
    if axis_size <= 1:
        return 0

    cost = output_shape.numel() * (axis_size - 1)
    if self.options.sorted and self.options.k > 1:
        num_groups = input_shape.numel() / axis_size
        cost += num_groups * (int(self.options.k) * (int(self.options.k) - 1) // 2)
    return cost


for layertype in (LayerType.TopKValues, LayerType.TopKIndices):
    OperatorRegistry.register_infer_shape(layertype)(infer_shape)
    OperatorRegistry.register_call_fn(layertype)(call_fn)
    OperatorRegistry.register_ops_count(layertype)(ops_count)
