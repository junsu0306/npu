from typing import Optional

from mblt.core import (
    SHAPELIKE,
    Shape,
    ActivationSpec,
    Operator,
    OperatorRegistry,
    LayerType,
)
from .utils import slice_out_length


@OperatorRegistry.register_infer_shape(LayerType.RotateHalf)
def infer_shape(self: Operator, *input_shape: SHAPELIKE, **kwargs) -> Optional[Shape]:
    input_shape = input_shape[0]
    if self.options.type == 0:
        mid = int(input_shape[-1]) // 2
        seqlen = int(input_shape[-1])
        x1_len = slice_out_length(seqlen, 0, mid, 1)
        x2_len = slice_out_length(seqlen, mid, seqlen, 1)
        output_shape = input_shape[:-1] + (x2_len + x1_len,)
        return Shape(output_shape)
    elif self.options.type == 1:
        seqlen = int(input_shape[-1])
        x1_len = slice_out_length(seqlen, 0, seqlen, 2)
        x2_len = slice_out_length(seqlen, 1, seqlen, 2)
        output_shape = input_shape[:-1] + (x2_len + x1_len,)
        return Shape(output_shape)
    raise NotImplementedError(f"not implemented type={self.options.type}")


@OperatorRegistry.register_call_fn(LayerType.RotateHalf)
def call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="rothalf",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )


@OperatorRegistry.register_ops_count(LayerType.RotateHalf)
def ops_count(self: Operator, *args, **kwargs):
    input_shape = self.inacts[0].src_shape
    return input_shape.numel() / 2
