from typing import Optional

from mblt.core import (
    SHAPELIKE,
    Shape,
    LayerType,
    ActivationSpec,
    OperatorRegistry,
    Operator,
)
from .opkind import REDUCE_OPS


def infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Shape]:
    input_shape = input_shape[0]
    dims = set(x if x >= 0 else x + len(input_shape) for x in self.options.reduce_axes)
    if self.options.keep_dims:
        output_shape = tuple(1 if ax in dims else d for ax, d in enumerate(input_shape))
    else:
        output_shape = tuple(d for ax, d in enumerate(input_shape) if ax not in dims)
    return Shape(output_shape)


def call_fn(self, *args, **kwargs):
    return ActivationSpec(
        name=self.layertype.name.lower(),
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )


_REDUCE_OPS_BASE_COST = {
    LayerType.ReduceMax: lambda reduction_size: reduction_size - 1,
    LayerType.ReduceMin: lambda reduction_size: reduction_size - 1,
    LayerType.ReduceSum: lambda reduction_size: reduction_size - 1,
    LayerType.ReduceProd: lambda reduction_size: reduction_size - 1,
    LayerType.ReduceMean: lambda reduction_size: reduction_size,
    LayerType.ReduceL2: lambda reduction_size: 2 * reduction_size,
    LayerType.ReduceRMS: lambda reduction_size: 2 * reduction_size + 1,
}


def _validate_ops_count_table():
    missing = REDUCE_OPS - set(_REDUCE_OPS_BASE_COST)
    extra = set(_REDUCE_OPS_BASE_COST) - REDUCE_OPS
    if missing or extra:
        raise RuntimeError(
            "REDUCE_OPS and _REDUCE_OPS_BASE_COST keys mismatch: "
            f"missing={sorted(x.name for x in missing)}, "
            f"extra={sorted(x.name for x in extra)}"
        )


def _normalized_reduce_axes(input_shape: SHAPELIKE, reduce_axes) -> tuple[int, ...]:
    rank = len(input_shape)
    return tuple(sorted({ax if ax >= 0 else ax + rank for ax in reduce_axes}))


def reduce_ops_count(self: Operator, *args, **kwargs):
    input_shape = self.inacts[0].src_shape
    output_shape = self.outacts[0].src_shape
    reduce_axes = _normalized_reduce_axes(input_shape, self.options.reduce_axes)
    if not reduce_axes:
        return 0

    reduction_size = Shape(input_shape[ax] for ax in reduce_axes).numel()
    return output_shape.numel() * _REDUCE_OPS_BASE_COST[self.layertype](reduction_size)


_validate_ops_count_table()


for layertype in REDUCE_OPS:
    OperatorRegistry.register_infer_shape(layertype)(infer_shape)
    OperatorRegistry.register_call_fn(layertype)(call_fn)
    OperatorRegistry.register_ops_count(layertype)(reduce_ops_count)
