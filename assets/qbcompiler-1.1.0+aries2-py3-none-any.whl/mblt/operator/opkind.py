from mblt.core import LayerType

SIMPLE_ACTIVATION_FUNCTIONS = frozenset(
    {
        LayerType.Abs,
        LayerType.Celu,
        LayerType.Clip,
        LayerType.Elu,
        LayerType.Erf,
        LayerType.Exp,
        LayerType.Gelu,
        LayerType.HardSigmoid,
        LayerType.HardSwish,
        LayerType.Hardtanh,
        LayerType.LeakyRelu,
        LayerType.Log,
        LayerType.Mish,
        LayerType.Pow,
        LayerType.QuickGelu,
        LayerType.Relu,
        LayerType.Rsqrt,
        LayerType.Sigmoid,
        LayerType.Softplus,
        LayerType.Sqrt,
        LayerType.Swish,
        LayerType.Tanh,
    }
)

INDEXED_ACTIVATION_FUNCTIONS = frozenset(
    {
        LayerType.PRelu,  # leaky_alpha: TensorIndex
    }
)

ACTIVATION_FUNCTIONS = SIMPLE_ACTIVATION_FUNCTIONS | INDEXED_ACTIVATION_FUNCTIONS

BIOP_ARITHMETIC = frozenset(
    {LayerType.Multiply, LayerType.Adding, LayerType.Sub, LayerType.Div}
)

BIOP_ARITHMETIC_CONST = frozenset(
    {
        LayerType.MultiplyConstant,
        LayerType.AddingConstant,
        LayerType.SubConstant,
        LayerType.DivConstant,
    }
)

REDUCE_OPS = frozenset(
    {
        LayerType.ReduceMax,
        LayerType.ReduceMin,
        LayerType.ReduceSum,
        LayerType.ReduceMean,
        LayerType.ReduceProd,
        LayerType.ReduceL2,
        LayerType.ReduceRMS,
    }
)

NORMALIZATIONS = frozenset(
    {
        LayerType.Batchnorm,
        LayerType.InstanceNormalization,
        LayerType.RmsNormalization,
        LayerType.LayerNormalization,
        LayerType.GroupNormalization,
        LayerType.L1Normalization,
        LayerType.L2Normalization,
        LayerType.SumNormalization,
        LayerType.GlobalResponseNormalization,
    }
)

STATEFUL_SEQUENTIAL_OPS = frozenset(
    {
        LayerType.StatefulRNNWrapper,
        LayerType.StatefulGRUWrapper,
        LayerType.StatefulLSTMWrapper,
    }
)

BASIC_NHWC_OPS = frozenset(
    {
        LayerType.Convolution,
        LayerType.DepthwiseConvolution,
        LayerType.TransposeConvolution,
        LayerType.GroupConvolution,
        LayerType.Pooling,
        LayerType.MatMul,
    }
)

CONV_LIKE_OPS = frozenset(
    {
        LayerType.Convolution,
        LayerType.DepthwiseConvolution,
        LayerType.TransposeConvolution,
        LayerType.GroupConvolution,
    }
)

# | REDUCE_OPS this one may change the in/out shape if keep_dims=False.
MBLT_SPECIAL_OPS = frozenset(
    {
        LayerType.HeaderView,
        LayerType.HeaderViewRevert,
        LayerType.StaggeredPadding,
        LayerType.OrderedPatchify,
    }
)
NPU_STRIDE_PRESERVING = (
    ACTIVATION_FUNCTIONS
    | BIOP_ARITHMETIC
    | BIOP_ARITHMETIC_CONST
    | NORMALIZATIONS
    | {
        LayerType.Softmax,
        LayerType.Concatenate,
        LayerType.Slice,
        LayerType.PadGeneric,
        LayerType.IndexedItemSelector,
    }
    | BASIC_NHWC_OPS
    | MBLT_SPECIAL_OPS
    | STATEFUL_SEQUENTIAL_OPS
)
