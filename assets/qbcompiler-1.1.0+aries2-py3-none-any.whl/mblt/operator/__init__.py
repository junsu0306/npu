#
from mblt.core import OperatorRegistry
from .activation_functions import *
from .arithmetic_ops import *
from .cached_stack import *
from .cast import *
from .channel_factor_slice import *
from .concatenate import *
from .convolution import *
from .einsum import *
from .expand import *
from .gather import *
from .identity import *
from .identity import *
from .indexed_item_selector import *
from .input_output import *
from .masked_fill import *
from .matmul import *
from .mblt_special_ops import *
from .neg import *
from .normalization import *
from .pad import *
from .pooling import *
from .reduce_ops import *
from .reshape import *
from .resize import *
from .rorate_half import *
from .scatternd import *
from .sequential_node import *
from .slice import *
from .softmax import *
from .statistics import *
from .tensor_cmp import *
from .topk import *
from .transpose import *
from .trigonometric import *
from .where import *


def _default_ops_count(self, *args, **kwargs):
    return 0


_registered_layertypes = set(OperatorRegistry._impl_registry) | set(
    OperatorRegistry._shape_inference_registry
)
for _layertype in _registered_layertypes:
    if _layertype not in OperatorRegistry._ops_count_registry:
        OperatorRegistry.register_ops_count(_layertype)(_default_ops_count)
