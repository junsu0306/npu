from typing import Optional

from mblt.core import (
    SHAPELIKE,
    Shape,
    ActivationSpec,
    Operator,
    OperatorRegistry,
    LayerType,
)


@OperatorRegistry.register_infer_shape(LayerType.StatefulCachedStack)
def infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    axis = int(self.options.axis)
    cache_len = int(self.options.cache_len)
    input_shape = input_shape[0]
    output_shape = list(input_shape)
    output_shape[axis] += cache_len
    return Shape(output_shape)


@OperatorRegistry.register_call_fn(LayerType.StatefulCachedStack)
def call_fn(self: Operator, *args, **kwargs):
    act1 = args[0]
    return ActivationSpec(
        name="cachedstack",
        dtype=act1.dtype,
        src_shape=self.infer_shape(act1.src_shape),
    )


@OperatorRegistry.register_ops_count(LayerType.StatefulCachedStack)
def ops_count(self: Operator, *args, **kwargs):
    return 0
