from typing import Optional

from mblt.core import Shape, SHAPELIKE, LayerType, ActivationSpec, OperatorRegistry
from .utils import conv2d_like_shape


@OperatorRegistry.register_infer_shape(LayerType.Pooling)
def infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Shape]:
    return conv2d_like_shape(input_shape[0], self.options)


@OperatorRegistry.register_call_fn(LayerType.Pooling)
def __call__(self, *args, **kwargs):
    return ActivationSpec(
        name="pool2d",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )


@OperatorRegistry.register_ops_count(LayerType.Pooling)
def ops_count(self, *args, **kwargs):
    output_shape = self.outacts[0].src_shape
    kernel_area = self.options.h_kernel * self.options.w_kernel

    if self.options.pool_type == "MaxPool":
        return output_shape.numel() * (kernel_area - 1)
    if self.options.pool_type == "AvgPool":
        return output_shape.numel() * (2 * kernel_area - 1)
    return 0


@OperatorRegistry.register_infer_shape(LayerType.GlobalAveragePooling)
def infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Shape]:
    input_shape = input_shape[0]
    if self.options.channel_last:
        middle_shape = (1,) * max(len(input_shape) - 2, 0)
        return Shape((input_shape[0], *middle_shape, input_shape[-1]))
    else:
        tail_shape = (1,) * max(len(input_shape) - 2, 0)
        return Shape((input_shape[0], input_shape[1], *tail_shape))


@OperatorRegistry.register_call_fn(LayerType.GlobalAveragePooling)
def __call__(self, *args, **kwargs):
    return ActivationSpec(
        name="globalavgpool2d",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )


@OperatorRegistry.register_ops_count(LayerType.GlobalAveragePooling)
def ops_count(self, *args, **kwargs):
    input_shape = self.inacts[0].src_shape
    output_shape = self.outacts[0].src_shape
    if self.options.channel_last:
        kernel_area = input_shape[1] * input_shape[2]
    else:
        kernel_area = input_shape[2] * input_shape[3]

    return output_shape.numel() * (2 * kernel_area - 1)