from typing import Optional

from mblt.core import (
    OperatorRegistry,
    Shape,
    LayerType,
    SHAPELIKE,
    ActivationSpec,
    Operator,
)
from mblt.operator import broadcast_shape


@OperatorRegistry.register_infer_shape(LayerType.TensorCmp)
def infer_shape(self: Operator, *input_shape: SHAPELIKE, **kwargs) -> Optional[Shape]:
    output_shape = broadcast_shape(input_shape[0], input_shape[1])
    return Shape(output_shape)


@OperatorRegistry.register_call_fn(LayerType.TensorCmp)
def call_fn(self, *args, **kwargs):
    return ActivationSpec(
        name=self.options.kind,
        dtype="bool",
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )


@OperatorRegistry.register_ops_count(LayerType.TensorCmp)
def ops_count(self: Operator, *args, **kwargs):
    output_shape = self.outacts[0].src_shape
    return output_shape.numel()
