from typing import Optional

from mblt.core import (
    DimValue,
    Shape,
    SHAPELIKE,
    LayerType,
    ActivationSpec,
    Operator,
    OperatorRegistry,
)


@OperatorRegistry.register_infer_shape(LayerType.MatMul)
def infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:

    left_shape, right_shape = input_shape
    if len(left_shape) >= 2 and len(right_shape) >= 2:
        left_a, left_b = left_shape[-2:]
        right_a, right_b = right_shape[-2:]
        if left_b != right_a:
            raise AssertionError(f"matmul shape mismatch: {left_shape}, {right_shape}")

        max_rank = max(len(left_shape), len(right_shape))
        left_shape = (1,) * (max_rank - len(left_shape)) + left_shape
        right_shape = (1,) * (max_rank - len(right_shape)) + right_shape
        lst = []
        for ls, rs in zip(left_shape[:-2], right_shape[:-2]):
            dynamic = any(getattr(x, "dynamic", False) for x in (ls, rs))
            lst.append(DimValue(max(int(ls), int(rs)), dynamic=dynamic))
        lst.append(left_a)
        lst.append(right_b)
        return Shape(lst)
    else:
        raise NotImplementedError(
            f"matmul shape not implemented for {left_shape}, {right_shape}"
        )


@OperatorRegistry.register_call_fn(LayerType.MatMul)
def call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="matmul",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )

@OperatorRegistry.register_ops_count(LayerType.MatMul)
def ops_count(self: Operator, *args, **kwargs):
    output_shape = self.outacts[0].src_shape
    left_shape = self.inacts[0].src_shape
    return output_shape.numel() * (2 * left_shape[-1] - 1)