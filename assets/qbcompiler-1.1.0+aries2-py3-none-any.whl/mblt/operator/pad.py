from typing import Optional

from mblt.core import (
    Shape,
    SHAPELIKE,
    LayerType,
    ActivationSpec,
    OperatorRegistry,
    Operator,
)


@OperatorRegistry.register_infer_shape(LayerType.Pad)
def infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    input_shape = input_shape[0]
    # n,h,w,c, NPU's north/south padding is inverted
    pad_pre = map(int, [0, self.options.south_padding, self.options.west_padding, 0])
    pad_post = map(int, [0, self.options.north_padding, self.options.east_padding, 0])
    return Shape(pre + x + post for pre, x, post in zip(pad_pre, input_shape, pad_post))


@OperatorRegistry.register_call_fn(LayerType.Pad)
def call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="pad",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )

@OperatorRegistry.register_ops_count(LayerType.Pad)
def ops_count(self: Operator, *args, **kwargs):
    return 0

@OperatorRegistry.register_infer_shape(LayerType.PadGeneric)
def infer_shape_generic(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    input_shape = input_shape[0]
    padding_list = self.options.padding_list
    src_dim = len(input_shape)
    pad_pre = map(int, padding_list[:src_dim])
    pad_post = map(int, padding_list[src_dim:])
    return Shape(pre + x + post for pre, x, post in zip(pad_pre, input_shape, pad_post))


@OperatorRegistry.register_call_fn(LayerType.PadGeneric)
def call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="pad",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )

@OperatorRegistry.register_ops_count(LayerType.PadGeneric)
def ops_count(self: Operator, *args, **kwargs):
    return 0