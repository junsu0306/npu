from typing import Optional

from mblt.core import (
    SHAPELIKE,
    Shape,
    LayerType,
    ActivationSpec,
    OperatorRegistry,
    Operator,
)
from .utils import permute


@OperatorRegistry.register_infer_shape(LayerType.Transpose)
def infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Shape]:
    return Shape(permute(input_shape[0], *self.options.transpose_axes))


@OperatorRegistry.register_call_fn(LayerType.Transpose)
def call_fn(self, *args, **kwargs):
    return ActivationSpec(
        name="transpose",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(args[0].src_shape),
    )


@OperatorRegistry.register_ops_count(LayerType.Transpose)
def ops_count(self: Operator, *args, **kwargs):
    return 0
