import functools
import math
import operator
from typing import Sequence, Tuple

from mblt.core import DimValue, Shape, SHAPELIKE, DIMLIKE


def is_dynamic(dim):
    return isinstance(dim, DimValue) and dim.dynamic


def permute(tp, *permutation):
    return type(tp)(operator.itemgetter(*permutation)(tp))


def reduce_mul_ints(tp: Sequence[int]):
    return functools.reduce(operator.mul, tp, 1)


def conv_out_size(in_size, pad_front, pad_end, kernel, dilation, stride) -> DimValue:
    # most frameworks use the following floor computaion. do not change to `//`
    out_size = math.floor(
        (int(in_size) + (pad_front + pad_end) - dilation * (kernel - 1) - 1) / stride
        + 1
    )
    return DimValue(out_size, is_dynamic(in_size))


def conv2d_like_shape(input_shape, options, output_channels=None) -> Shape:
    if options.channel_last:
        n, h, w, c = input_shape
    else:
        n, c, h, w = input_shape
    if output_channels is None:
        output_channels = int(c)
    # fmt:off
    h_out = conv_out_size(h, options.north_padding, options.south_padding, options.h_kernel, options.h_dilation,
                          options.h_stride)
    w_out = conv_out_size(w, options.west_padding, options.east_padding, options.w_kernel, options.w_dilation,
                          options.w_stride)
    # fmt:on
    if options.channel_last:
        return Shape((n, h_out, w_out, output_channels))
    else:
        return Shape((n, output_channels, h_out, w_out))


def conv3d_like_shape(input_shape, options, output_channels=None) -> Shape:
    if options.channel_last:
        n, d, h, w, c = input_shape
    else:
        n, c, d, h, w = input_shape
    if output_channels is None:
        output_channels = int(c)
    # fmt:off
    d_out = conv_out_size(d, options.front_padding, options.back_padding, options.d_kernel, options.d_dilation,
                          options.d_stride)
    h_out = conv_out_size(h, options.north_padding, options.south_padding, options.h_kernel, options.h_dilation,
                          options.h_stride)
    w_out = conv_out_size(w, options.west_padding, options.east_padding, options.w_kernel, options.w_dilation,
                          options.w_stride)
    # fmt:on
    if options.channel_last:
        return Shape((n, d_out, h_out, w_out, output_channels))
    else:
        return Shape((n, output_channels, d_out, h_out, w_out))


def _find_reshape_mapping(input_shape: SHAPELIKE, target_shape: SHAPELIKE):
    """
    input_shape: (1,6,4,6)
    output_shape: (1,12,2,1,2,1,3)
    mapping: [([0], [0]),
                 ([1, 2], [1, 2]),
                 ([3], [3, 4, 5, 6])]

    """
    input_vals = [int(d) for d in input_shape]
    target_vals = [int(d) for d in target_shape]

    def generate():
        input_idx = 0
        output_idx = 0
        while input_idx < len(input_vals) and output_idx < len(target_vals):
            input_prod = input_vals[input_idx]
            output_prod = target_vals[output_idx]
            input_start = input_idx
            output_start = output_idx
            while input_prod != output_prod:
                if input_prod < output_prod:
                    input_idx += 1
                    if input_idx < len(input_vals):
                        input_prod *= input_vals[input_idx]
                else:
                    output_idx += 1
                    if output_idx < len(target_vals):
                        output_prod *= target_vals[output_idx]
            input_idx += 1
            output_idx += 1
            yield (
                tuple(range(input_start, input_idx)),
                tuple(range(output_start, output_idx)),
            )

    return tuple(generate())


def _infer_output_dynamic(input_shape, target_shape, mapping):
    target_vals = [int(d) if isinstance(d, DimValue) else d for d in target_shape]

    result = [DimValue(val, dynamic=False) for val in target_vals]

    for input_indices, output_indices in mapping:
        dynamic_inputs = [i for i in input_indices if input_shape[i].dynamic]
        if len(dynamic_inputs) == 0:
            continue
        if len(input_indices) == 1 and len(output_indices) == 1:
            if input_shape[input_indices[0]].dynamic:
                result[output_indices[0]].set_dynamic()
        # 1:N 분할인 경우
        elif len(input_indices) == 1:
            input_dim = input_shape[input_indices[0]]
            if input_dim.dynamic:  # Dynamic(1) -> [1]인 경우는 dynamic 유지
                if (
                    int(input_dim) == 1
                    and len(output_indices) == 1
                    and target_vals[output_indices[0]] == 1
                ):
                    result[output_indices[0]].set_dynamic()
                else:
                    # Dynamic 차원을 분할하는 경우, 1은 static으로 유지 (단, 원본이 1이 아닌 경우)
                    for i in output_indices:
                        if target_vals[i] != 1:
                            result[i].set_dynamic()
        else:
            # Dynamic과 static 입력의 곱 계산
            dynamic_inputs_list = [i for i in input_indices if input_shape[i].dynamic]
            if not dynamic_inputs_list:
                continue
            static_inputs_list = [
                i for i in input_indices if not input_shape[i].dynamic
            ]
            static_prod = (
                reduce_mul_ints(int(input_shape[i]) for i in static_inputs_list)
                if static_inputs_list
                else 1
            )

            # 뒤에서부터 순회하면서 static으로 만들 수 있는 차원 찾기
            remaining_static = static_prod
            static_dims_set = set()

            for i in reversed(output_indices):
                out_val = target_vals[i]
                if out_val == 1:
                    # 1은 나중에 처리
                    continue
                elif remaining_static > 1 and remaining_static % out_val == 0:
                    # Static으로 이 차원을 완전히 만들 수 있음
                    static_dims_set.add(i)
                    remaining_static //= out_val
                # else: 이 차원은 dynamic (계속 진행)

            # 이제 각 차원에 dynamic 표시
            for i in output_indices:
                out_val = target_vals[i]
                if out_val == 1:
                    # 1은 dynamic(1) 입력이 있는 경우에만 dynamic으로
                    if any(
                        int(input_shape[j]) == 1 and input_shape[j].dynamic
                        for j in dynamic_inputs_list
                    ):
                        result[i].set_dynamic()
                elif i not in static_dims_set:
                    result[i].set_dynamic()

    return result


def find_reshape_path(input_shape, target_shape):
    """
    input_shape에서 target_shape로 가는 중간 단계 생성. Dynamic 차원은 가능한 보존.
    """
    input_shape = tuple(
        x if isinstance(x, DimValue) else DimValue(x) for x in input_shape
    )
    mapping = _find_reshape_mapping(input_shape, target_shape)

    # N:M mapping이 존재하면 중가 단계 필요함.
    need_intermediate = any(len(i) > 1 and len(o) > 1 for i, o in mapping)
    if not need_intermediate:
        return (
            input_shape,
            _infer_output_dynamic(input_shape, target_shape, mapping),
        )

    # Dynamic-preserving 중간 단계 생성
    intermediate = []
    for input_indices, output_indices in mapping:
        if len(input_indices) == 1:  # 1:1, 1:N
            intermediate.append(input_shape[input_indices[0]])
        elif len(output_indices) == 1:  # N:1
            has_dynamic = any(input_shape[i].dynamic for i in input_indices)
            merged_val = reduce_mul_ints(int(input_shape[i]) for i in input_indices)
            intermediate.append(DimValue(merged_val, has_dynamic))
        elif not any(input_shape[i].dynamic for i in input_indices):
            # M:N static case.
            merged_val = reduce_mul_ints(int(input_shape[i]) for i in input_indices)
            intermediate.append(DimValue(merged_val, dynamic=False))
        else:  # M:N dynamic case.
            # fixme: 각 경우를 일관성 있게 하기 생각보다 어렵네.
            #  3*8=4*6 같은 경우 때문에 모두 곱하는게 제일 일반적인데 이렇게 하면 dynamic을 다시 분리하기 어려움.
            # (6,4(D),6)->(3,48,3)
            # (3,16(D),6)->(6,16,3)
            intermediate.extend(
                x
                for i in input_indices
                if not ((x := input_shape[i]) == 1 and not x.dynamic)
            )

    # 중간 단계가 입력과 동일하면 생략
    if len(intermediate) == len(input_shape) and all(
        int(a) == int(b) and a.dynamic == b.dynamic
        for a, b in zip(intermediate, input_shape)
    ):
        return input_shape, _infer_output_dynamic(input_shape, target_shape, mapping)

    mapping2 = _find_reshape_mapping(intermediate, target_shape)
    final_output = _infer_output_dynamic(intermediate, target_shape, mapping2)
    return input_shape, intermediate, final_output


def broadcast_dim(dim0: DIMLIKE, dim1: DIMLIKE):
    if dim0 == dim1:
        return DimValue(
            max(int(dim0), int(dim1)),
            dynamic=getattr(dim0, "dynamic", False) or getattr(dim1, "dynamic", False),
        )
    if dim0 == 1 and not getattr(dim0, "dynamic", False):
        return DimValue(dim1)
    if dim1 == 1 and not getattr(dim1, "dynamic", False):
        return DimValue(dim0)
    raise ValueError(f"unable to broadcast: {dim0}, {dim1}")


def broadcast_shape(shape0: SHAPELIKE, shape1: SHAPELIKE) -> Tuple[int, ...]:
    s0 = (1,) * max(0, len(shape1) - len(shape0)) + shape0
    s1 = (1,) * max(0, len(shape0) - len(shape1)) + shape1
    return tuple(broadcast_dim(l, r) for l, r in zip(s0, s1))


def interpret_slice(src_shape, slice_opt):
    assert len(slice_opt.axis) == 1
    seq_len = int(src_shape[slice_opt.axis[0]])
    if slice_opt.step is None:
        step = 1
    else:
        step = slice_opt.step[0]
    start = slice_opt.start[0]
    end = slice_opt.end[0]
    if end < 0:
        end += seq_len
    else:
        end = min(end, seq_len)
    if start < 0:
        start += seq_len
    return start, end, step


def slice_out_length(seq_len: int, start: int, end=None, step=None):
    if step is None:
        step = 1
    if end == 0:
        return 0
    elif end is None:
        end = seq_len
    elif end < 0:
        end += seq_len
    else:
        end = min(end, seq_len)  # free end if large.
    if start < 0:
        start += seq_len
    q, r = divmod(max(0, end - start), step)
    if r > 0:
        q += 1
    return q


def reshape_output_shape(input_shape, new_shape):
    if len(new_shape) == 0:
        assert 1 == math.prod(
            map(int, input_shape)
        ), f"reshape output shape error. input_shape={input_shape}, new_shape={new_shape}"
        return Shape(())

    if new_shape[0] == 0 and len(new_shape) > 1:
        # maybe batch.
        new_shape = (1,) + tuple(new_shape[1:])
    num_free_axis = sum(s == -1 for s in new_shape)
    if num_free_axis > 1:
        raise ValueError(
            f"at most one free axis allowed in new_shape. but new_shape={new_shape}"
        )
    if num_free_axis == 1:
        all_elem_cnt = reduce_mul_ints(map(int, input_shape))
        non_free_cnt = reduce_mul_ints(map(int, (x for x in new_shape if x != -1)))
        new_shape = tuple(
            x if x != -1 else all_elem_cnt // non_free_cnt for x in new_shape
        )
    if 0 in new_shape:
        raise ValueError(
            f"reshape output shape error. input_shape={input_shape}, new_shape={new_shape}"
        )
    if math.prod(map(int, new_shape)) != math.prod(map(int, input_shape)):
        raise ValueError(
            f"reshape output shape error. input_shape={input_shape}, new_shape={new_shape}"
        )
    reshape_path = find_reshape_path(input_shape, new_shape)
    return Shape(reshape_path[-1])
