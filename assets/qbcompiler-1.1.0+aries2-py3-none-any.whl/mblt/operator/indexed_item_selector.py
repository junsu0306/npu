import math
from typing import Optional

import numpy

from mblt import LayerType
from mblt.core import SHAPELIKE, Shape, ActivationSpec, Operator, OperatorRegistry


@OperatorRegistry.register_infer_shape(LayerType.IndexedItemSelector)
def infer_shape(self: Operator, *input_shape: SHAPELIKE, **kwargs) -> Optional[Shape]:
    assert len(input_shape) == 1
    axis = self.options.axis
    index = kwargs["index"]
    output_shape = list(input_shape[0])
    if index is not None:
        output_shape[axis] = math.prod(map(int, index.shape))
    elif self.options.repeat is not None:
        output_shape[axis] = int(self.options.repeat)
    elif self.options.start is not None:
        start = self.options.start
        end = self.options.end
        step = self.options.step
        dim = output_shape[axis]
        if start < 0:
            start += dim
        if end < 0:
            end += dim
        if step is None:
            step = 1
        if step > 0:
            start = min(max(start, 0), dim)
            end = min(max(end, 0), dim)
            index_shape = max(0, (end - start + step - 1) // step)
        else:
            start = min(max(start, 0), dim - 1)
            end = min(max(end, -1), dim - 1)
            index_shape = max(0, (start - end - step - 1) // (-step))
        output_shape[axis] = index_shape
    return Shape(output_shape)


@OperatorRegistry.register_call_fn(LayerType.IndexedItemSelector)
def call_fn(self: Operator, *args, **kwargs):
    name = self.layertype.name.lower()
    index: numpy.ndarray = kwargs.get("index", None)

    return ActivationSpec(
        name=name,
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args), index=index),
    )

@OperatorRegistry.register_ops_count(LayerType.IndexedItemSelector)
def ops_count(self: Operator, *args, **kwargs):
    return 0