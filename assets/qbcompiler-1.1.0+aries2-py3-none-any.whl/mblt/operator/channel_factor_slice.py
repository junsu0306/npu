import math
from typing import Optional

from mblt.core import (
    Shape,
    SHAPELIKE,
    LayerType,
    ActivationSpec,
    OperatorRegistry,
    Operator,
)
from .utils import slice_out_length


@OperatorRegistry.register_infer_shape(LayerType.ChannelFactorSlice)
def infer_shape(self: Operator, *input_shape: SHAPELIKE, **kwargs) -> Optional[Shape]:
    assert len(input_shape) == 1
    axis = self.options.axis
    start = self.options.start
    step = self.options.step
    end = self.options.end
    input_shape = input_shape[0]
    channel_size = list(self.options.factor_shape)
    channel_size[axis] = slice_out_length(channel_size[axis], start, end, step)
    output_shape = input_shape[:3] + (math.prod(map(int, channel_size)),)
    return Shape(output_shape)


@OperatorRegistry.register_call_fn(LayerType.ChannelFactorSlice)
def call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="channel_factor_slice",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(args[0].src_shape),
    )

@OperatorRegistry.register_ops_count(LayerType.ChannelFactorSlice)
def ops_count(self: Operator, *args, **kwargs):
    return 0