from typing import Optional

from mblt.core import (
    Shape,
    SHAPELIKE,
    LayerType,
    ActivationSpec,
    OperatorRegistry,
    Operator,
)


@OperatorRegistry.register_infer_shape(LayerType.Resize)
def infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Shape]:
    input_shape = input_shape[0]
    if self.options.sizes is not None and self.options.sizes:
        output_shape = self.options.sizes
    elif self.options.scales is not None and self.options.scales:
        assert len(self.options.scales) == len(input_shape)
        assert self.options.scales == tuple(x for x in self.options.scales)
        # fixme: what if x*s is not an integer?
        output_shape = [x * s for x, s in zip(input_shape, self.options.scales)]
    else:
        raise NotImplementedError
    return Shape(output_shape)


@OperatorRegistry.register_call_fn(LayerType.Resize)
def call_fn(self, *args, **kwargs):
    return ActivationSpec(
        name="resize",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )


_OPS_PER_OUTPUT_ELEMENT = {
    "nearest": 0,
    "linear": 7,
    "cubic": 31,
}


@OperatorRegistry.register_ops_count(LayerType.Resize)
def ops_count(self: Operator, *args, **kwargs):
    output_shape = self.outacts[0].src_shape
    try:
        per_output_element = _OPS_PER_OUTPUT_ELEMENT[self.options.resize_type]
    except KeyError as exc:
        raise NotImplementedError(
            f"unsupported resize_type for ops_count: {self.options.resize_type}"
        ) from exc
    return output_shape.numel() * per_output_element
