from typing import Optional

from mblt.core import (
    OperatorRegistry,
    SHAPELIKE,
    Shape,
    ActivationSpec,
    LayerType,
    Operator,
)
from mblt.computation.einsum import einsum_output_shape, einsum_ops_count


@OperatorRegistry.register_infer_shape(LayerType.Einsum)
def infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    output_shape = einsum_output_shape(self.options.equation, *input_shape)
    return Shape(output_shape)


@OperatorRegistry.register_call_fn(LayerType.Einsum)
def call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="einsum",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(args[0].src_shape, args[1].src_shape),
    )

@OperatorRegistry.register_ops_count(LayerType.Einsum)
def ops_count(self: Operator, *args, **kwargs):
    return einsum_ops_count(
        self.options.equation, *(inact.src_shape for inact in self.inacts)
    )