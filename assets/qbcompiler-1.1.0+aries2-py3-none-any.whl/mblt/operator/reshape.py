from typing import Optional

from mblt.core import SHAPELIKE, Shape, LayerType, ActivationSpec, OperatorRegistry, Operator
from .utils import reshape_output_shape


@OperatorRegistry.register_infer_shape(LayerType.Reshape)
def infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Shape]:
    input_shape = input_shape[0]
    new_shape = self.options.new_shape
    assert new_shape is not None, "new_shape must be specified for reshape-infer_shape"
    return reshape_output_shape(input_shape, new_shape)


@OperatorRegistry.register_call_fn(LayerType.Reshape)
def call_fn(self, *args, **kwargs):
    return ActivationSpec(
        name="reshape",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )

@OperatorRegistry.register_ops_count(LayerType.Reshape)
def ops_count(self: Operator, *args, **kwargs):
    return 0