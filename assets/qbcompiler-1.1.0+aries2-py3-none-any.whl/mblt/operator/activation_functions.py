from typing import Optional

from mblt.core import (
    SHAPELIKE,
    Shape,
    ActivationSpec,
    Operator,
    OperatorRegistry,
    LayerType,
)
from .opkind import ACTIVATION_FUNCTIONS


def infer_shape(op: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    assert len(input_shape) == 1
    return Shape(input_shape[0])


def actfunc_call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name=self.layertype.name.lower(),
        dtype=args[0].dtype,
        src_shape=self.infer_shape(args[0].src_shape),
    )


_OPS_PER_INPUT_ELEMENT = {
    LayerType.Abs: 1,
    # x >= 0 ? x : alpha * (exp(x / alpha) - 1)
    LayerType.Celu: 5,
    # min(max(x, min), max)
    LayerType.Clip: 2,
    # x >= 0 ? x : alpha * (exp(x) - 1)
    LayerType.Elu: 4,
    LayerType.Erf: 1,
    LayerType.Exp: 1,
    # 0.5 * x * (1 + erf(x / sqrt(2)))
    # div + erf + add + mul + mul
    LayerType.Gelu: 5,
    # clip((x + 3), 0, 6) / 6
    # add + clip(2) + div
    LayerType.HardSigmoid: 4,
    # x * hard_sigmoid(x)
    # mul + hard_sigmoid(4)
    LayerType.HardSwish: 5,
    # clip(x, min, max)
    LayerType.Hardtanh: 2,
    # x >= 0 ? x : alpha * x
    LayerType.LeakyRelu: 2,
    LayerType.Log: 1,
    # x * tanh(softplus(x))
    # softplus(3) + tanh + mul
    LayerType.Mish: 5,
    LayerType.Pow: 1,
    # x >= 0 ? x : alpha * x
    LayerType.PRelu: 2,
    # x * sigmoid(1.702 * x)
    # mul + sigmoid(4) + mul
    LayerType.QuickGelu: 6,
    LayerType.Relu: 1,
    # rsqrt(x) ~= sqrt + reciprocal
    LayerType.Rsqrt: 2,
    # 1 / (1 + exp(-x))
    # neg + exp + add + div
    LayerType.Sigmoid: 4,
    # log(1 + exp(x))
    # exp + add + log
    LayerType.Softplus: 3,
    LayerType.Sqrt: 1,
    # x * sigmoid(x)
    # sigmoid(4) + mul
    LayerType.Swish: 5,
    # tanh(x) treated as one primitive op
    LayerType.Tanh: 1,
}


def _validate_ops_count_table():
    missing = ACTIVATION_FUNCTIONS - set(_OPS_PER_INPUT_ELEMENT)
    extra = set(_OPS_PER_INPUT_ELEMENT) - ACTIVATION_FUNCTIONS
    if missing or extra:
        raise RuntimeError(
            "ACTIVATION_FUNCTIONS and _OPS_PER_INPUT_ELEMENT keys mismatch: "
            f"missing={sorted(x.name for x in missing)}, "
            f"extra={sorted(x.name for x in extra)}"
        )

def actfunc_ops_count(self: Operator, *args, **kwargs):
    input_shape = self.inacts[0].src_shape
    return input_shape.numel() * _OPS_PER_INPUT_ELEMENT[self.layertype]

_validate_ops_count_table()


for layertype in ACTIVATION_FUNCTIONS:
    OperatorRegistry.register_call_fn(layertype)(actfunc_call_fn)
    OperatorRegistry.register_infer_shape(layertype)(infer_shape)
    OperatorRegistry.register_ops_count(layertype)(actfunc_ops_count)
