from typing import Optional

from mblt.core import (
    SHAPELIKE,
    Shape,
    DimValue,
    Operator,
    LayerType,
    ActivationSpec,
    OperatorRegistry,
)


@OperatorRegistry.register_infer_shape(LayerType.HeaderView)
def infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Shape]:
    n, h, w, c = input_shape[0]
    n_heads = self.options.num_heads
    return Shape(map(int, (n, h * n_heads, w, c // n_heads)))


@OperatorRegistry.register_call_fn(LayerType.HeaderView)
def call_fn(self, *args, **kwargs):
    return ActivationSpec(
        name="hview",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )

@OperatorRegistry.register_ops_count(LayerType.HeaderView)
def ops_count(self: Operator, *args, **kwargs):
    return 0

@OperatorRegistry.register_infer_shape(LayerType.HeaderViewRevert)
def infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Shape]:
    n, h, w, c = input_shape[0]
    n_heads = self.options.num_heads
    return Shape(map(int, (n, h // n_heads, w, c * n_heads)))


@OperatorRegistry.register_call_fn(LayerType.HeaderViewRevert)
def call_fn(self, *args, **kwargs):
    return ActivationSpec(
        name="hview_rev",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )
    
@OperatorRegistry.register_ops_count(LayerType.HeaderViewRevert)
def ops_count(self: Operator, *args, **kwargs):
    return 0


@OperatorRegistry.register_infer_shape(LayerType.StatefulAttentionMaskWrapper)
def infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Shape]:
    return Shape(input_shape[0])


@OperatorRegistry.register_call_fn(LayerType.StatefulAttentionMaskWrapper)
def call_fn(self, *args, **kwargs):
    return ActivationSpec(
        name="attn_mask",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )

@OperatorRegistry.register_ops_count(LayerType.StatefulAttentionMaskWrapper)
def ops_count(self: Operator, *args, **kwargs):
    return 0

@OperatorRegistry.register_infer_shape(LayerType.StatefulKVCacheWrapper)
def infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Shape]:
    # return Shape(
    #     DimValue(x, True) if idx == 2 else x for idx, x in enumerate(input_shape[0])
    # )
    return Shape(input_shape[0])


@OperatorRegistry.register_call_fn(LayerType.StatefulKVCacheWrapper)
def call_fn(self, *args, **kwargs):
    return ActivationSpec(
        name="cache",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )

@OperatorRegistry.register_ops_count(LayerType.StatefulKVCacheWrapper)
def ops_count(self: Operator, *args, **kwargs):
    return 0

@OperatorRegistry.register_infer_shape(LayerType.StatefulRoPEWrapper)
def infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Shape]:
    return Shape(input_shape[0])
    # return Shape(
    #     DimValue(x, True) if idx == 2 else x for idx, x in enumerate(input_shape[0])
    # )


@OperatorRegistry.register_call_fn(LayerType.StatefulRoPEWrapper)
def call_fn(self, *args, **kwargs):
    return ActivationSpec(
        name="rope",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )
    
@OperatorRegistry.register_ops_count(LayerType.StatefulRoPEWrapper)
def ops_count(self: Operator, *args, **kwargs):
    return 0


@OperatorRegistry.register_infer_shape(LayerType.OrderedPatchify)
def infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Shape]:
    n, h, w, c = input_shape[0]
    h_kernel = int(self.options.h_kernel)
    w_kernel = int(self.options.w_kernel)
    order = int(self.options.order)
    h_grid = int(h) // h_kernel
    w_grid = int(w) // w_kernel
    if order == 0:
        src_shape = (n, h_grid * w_grid, h_kernel * w_kernel, c)
    elif order == 1:
        src_shape = (n, h_kernel * w_kernel, h_grid * w_grid, c)
    elif order == 2:
        src_shape = (n, h_grid * w_grid, h_kernel * w_kernel, c)
    else:
        raise NotImplementedError("order must be 0, 1 or 2")
    return Shape(src_shape)


@OperatorRegistry.register_call_fn(LayerType.OrderedPatchify)
def call_fn(self, *args, **kwargs):
    return ActivationSpec(
        name="ordered_patchify",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(args[0].src_shape),
    )
    
@OperatorRegistry.register_ops_count(LayerType.OrderedPatchify)
def ops_count(self: Operator, *args, **kwargs):
    return 0


@OperatorRegistry.register_infer_shape(LayerType.StaggeredPadding)
def infer_shape(self, *input_shape: SHAPELIKE) -> Optional[Shape]:
    reverse = self.options.reverse
    window_size = self.options.window_size
    if reverse:
        raise NotImplementedError("StaggeredPadding with Reverse is not supported yet.")

    n, h, w, c = input_shape[0]
    # output_shape = (n, h, w, w + c)  # pad (w,0)
    # output_shape = (n, h, 1, w * (w + c))  # reshape
    # output_shape = (n, h, 1, w * (c + w-1)) # slice
    output_shape = (n, h, w, c + w - 1)  # reshape
    if window_size != -1:
        # slice window_size:-window_size
        output_shape = (n, h, w, c + w - 1 - 2 * window_size)
    return Shape(output_shape)


@OperatorRegistry.register_call_fn(LayerType.StaggeredPadding)
def call_fn(self, *args, **kwargs):
    return ActivationSpec(
        name="staggered_padding",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(args[0].src_shape),
    )

@OperatorRegistry.register_ops_count(LayerType.StaggeredPadding)
def ops_count(self: Operator, *args, **kwargs):
    return 0