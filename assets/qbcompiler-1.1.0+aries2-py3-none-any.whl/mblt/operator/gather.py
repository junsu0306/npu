from typing import Optional

from mblt.core import (
    OperatorRegistry,
    SHAPELIKE,
    Shape,
    ActivationSpec,
    LayerType,
    Operator,
)


@OperatorRegistry.register_infer_shape(LayerType.Gather)
def infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    data_shape, indices_shape = input_shape
    axis = self.options.axis
    if axis < 0:
        axis += len(data_shape)
    output_shape = data_shape[:axis] + indices_shape + data_shape[axis + 1 :]
    return Shape(output_shape)


@OperatorRegistry.register_call_fn(LayerType.Gather)
def call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="gather",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(a.src_shape for a in args)),
    )

@OperatorRegistry.register_ops_count(LayerType.Gather)
def ops_count(self: Operator, *args, **kwargs):
    return 0

@OperatorRegistry.register_infer_shape(LayerType.GatherElements)
def infer_shape_gather_elements(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    data_shape, indices_shape = input_shape
    return Shape(indices_shape)

@OperatorRegistry.register_call_fn(LayerType.GatherElements)
def call_fn_gather_elements(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="gather_elements",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(a.src_shape for a in args)),
    )



@OperatorRegistry.register_ops_count(LayerType.GatherElements)
def ops_count(self: Operator, *args, **kwargs):
    return 0