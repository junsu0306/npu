from typing import Optional

from mblt.core import (
    Shape,
    SHAPELIKE,
    LayerType,
    ActivationSpec,
    OperatorRegistry,
    Operator,
)
from .utils import conv2d_like_shape, conv3d_like_shape, conv_out_size


def conv2d_infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    return conv2d_like_shape(input_shape[0], self.options, self.options.out_channels)


def conv2d_call_fn(self: Operator, *args, **kwargs):
    name = {
        LayerType.Convolution: "conv2d",
        LayerType.TransposeConvolution: "tconv2d",
        LayerType.GroupConvolution: "gconv2d",
        LayerType.DepthwiseConvolution: "dconv2d",
    }
    return ActivationSpec(
        name=name[self.layertype],
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )


def conv2d_ops_count(self: Operator, *args, **kwargs):
    output_shape = self.outacts[0].src_shape
    per_output_element = (
        2
        * (self.options.in_channels // self.options.group_number)
        * self.options.h_kernel
        * self.options.w_kernel
        - 1
    )
    if self.options.bias != -1:
        per_output_element += 1
    return output_shape.numel() * per_output_element


for layertype in (
    LayerType.Convolution,
    LayerType.DepthwiseConvolution,
    LayerType.GroupConvolution,
):
    OperatorRegistry.register_call_fn(layertype)(conv2d_call_fn)
    OperatorRegistry.register_infer_shape(layertype)(conv2d_infer_shape)
    OperatorRegistry.register_ops_count(layertype)(conv2d_ops_count)


@OperatorRegistry.register_infer_shape(LayerType.Convolution3d)
def conv3d_infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    return conv3d_like_shape(input_shape[0], self.options, self.options.out_channels)


@OperatorRegistry.register_call_fn(LayerType.Convolution3d)
def conv3d_call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="conv3d",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )


@OperatorRegistry.register_ops_count(LayerType.Convolution3d)
def conv3d_ops_count(self: Operator, *args, **kwargs):
    output_shape = self.outacts[0].src_shape
    per_output_element = (
        2
        * (self.options.in_channels // self.options.group_number)
        * self.options.d_kernel
        * self.options.h_kernel
        * self.options.w_kernel
        - 1
    )
    if self.options.bias != -1:
        per_output_element += 1
    return output_shape.numel() * per_output_element


@OperatorRegistry.register_infer_shape(LayerType.TransposeConvolution)
def tconv2d_infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    n, h, w, c = input_shape[0]
    strided_in_h = (h - 1) * self.options.h_stride + 1
    strided_in_w = (w - 1) * self.options.w_stride + 1
    h_out = conv_out_size(
        strided_in_h,
        self.options.north_padding,
        self.options.south_padding,
        self.options.h_kernel,
        self.options.h_dilation,
        1,
    )
    w_out = conv_out_size(
        strided_in_w,
        self.options.west_padding,
        self.options.east_padding,
        self.options.w_kernel,
        self.options.w_dilation,
        1,
    )
    return Shape((n, h_out, w_out, self.options.out_channels))


@OperatorRegistry.register_call_fn(LayerType.TransposeConvolution)
def tconv2d_call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="tconv2d_out",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(args[0].src_shape),
    )


@OperatorRegistry.register_ops_count(LayerType.TransposeConvolution)
def tconv2d_ops_count(self: Operator, *args, **kwargs):
    return conv2d_ops_count(self, *args, **kwargs)
