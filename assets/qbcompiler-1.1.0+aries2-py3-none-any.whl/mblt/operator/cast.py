from typing import Optional

from mblt import LayerType
from mblt.core import SHAPELIKE, Shape, ActivationSpec, Operator, OperatorRegistry
from mblt.core import OperatorRegistry

@OperatorRegistry.register_infer_shape(LayerType.Cast)
def infer_shape(op: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    assert len(input_shape) == 1
    return Shape(input_shape[0])


@OperatorRegistry.register_call_fn(LayerType.Cast)
def call_fn(self: Operator, *args, **kwargs):
    dtype = self.options.dtype
    return ActivationSpec(
        name="cast",
        dtype=dtype,
        src_shape=self.infer_shape(args[0].src_shape),
    )

@OperatorRegistry.register_ops_count(LayerType.Cast)
def ops_count(self: Operator, *args, **kwargs):
    input_shape = self.inacts[0].src_shape
    return input_shape.numel()
