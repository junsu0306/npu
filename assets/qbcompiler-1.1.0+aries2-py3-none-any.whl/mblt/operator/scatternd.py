from typing import Optional

from mblt.core import (
    OperatorRegistry,
    SHAPELIKE,
    Shape,
    ActivationSpec,
    LayerType,
    Operator,
)


@OperatorRegistry.register_infer_shape(LayerType.ScatterND)
def infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    return Shape(input_shape[0])


@OperatorRegistry.register_call_fn(LayerType.ScatterND)
def call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="scatternd",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(a.src_shape for a in args)),
    )


@OperatorRegistry.register_ops_count(LayerType.ScatterND)
def ops_count(self: Operator, *args, **kwargs):
    return 0
