from typing import Optional

from mblt.core import (
    SHAPELIKE,
    Shape,
    LayerType,
    ActivationSpec,
    OperatorRegistry,
    Operator,
)


@OperatorRegistry.register_infer_shape(LayerType.Identity)
def infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    return Shape(input_shape[0])


@OperatorRegistry.register_call_fn(LayerType.Identity)
def call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="identity",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )

@OperatorRegistry.register_ops_count(LayerType.Identity)
def ops_count(self: Operator, *args, **kwargs):
    return 0