from typing import Optional

from mblt.core import (
    OperatorRegistry,
    Shape,
    SHAPELIKE,
    ActivationSpec,
    Operator,
)
from .opkind import BIOP_ARITHMETIC, BIOP_ARITHMETIC_CONST
from .utils import broadcast_shape


def infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    assert len(input_shape) == 2
    return Shape(broadcast_shape(*input_shape))


def call_fn(self, *args, **kwargs):
    left, right = args
    return ActivationSpec(
        name=self.layertype.name.lower(),
        dtype=left.dtype,
        src_shape=self.infer_shape(left.src_shape, right.src_shape),
    )


def arithmetic_biop_ops_count(self: Operator, *args, **kwargs):
    output_shape = self.outacts[0].src_shape
    return output_shape.numel()

for layertype in BIOP_ARITHMETIC:
    OperatorRegistry.register_call_fn(layertype)(call_fn)
    OperatorRegistry.register_infer_shape(layertype)(infer_shape)
    OperatorRegistry.register_ops_count(layertype)(arithmetic_biop_ops_count)


def arithmetic_biop_const_infer_shape(
    self: Operator, *input_shape: SHAPELIKE
) -> Optional[Shape]:
    assert len(input_shape) == 1
    return Shape(broadcast_shape(input_shape[0], self.options.shape))


def arithmetic_biop_const_call_fn(self: Operator, *args, **kwargs):
    act = args[0]
    return ActivationSpec(
        name=self.layertype.name.lower(),
        dtype=act.dtype,
        src_shape=self.infer_shape(act.src_shape),
    )


def arithmetic_biop_const_ops_count(self: Operator, *args, **kwargs):
    output_shape = self.outacts[0].src_shape
    return output_shape.numel()


for layertype in BIOP_ARITHMETIC_CONST:
    OperatorRegistry.register_call_fn(layertype)(arithmetic_biop_const_call_fn)
    OperatorRegistry.register_infer_shape(layertype)(arithmetic_biop_const_infer_shape)
    OperatorRegistry.register_ops_count(layertype)(arithmetic_biop_const_ops_count)
