from typing import Optional

from mblt.core import (
    Shape,
    SHAPELIKE,
    LayerType,
    ActivationSpec,
    OperatorRegistry,
    Operator,
)


@OperatorRegistry.register_infer_shape(LayerType.MeanCentering)
def infer_shape(self: Operator, *input_shape: SHAPELIKE, **kwargs) -> Optional[Shape]:
    return Shape(input_shape[0])


@OperatorRegistry.register_call_fn(LayerType.MeanCentering)
def call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="centering",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )


@OperatorRegistry.register_ops_count(LayerType.MeanCentering)
def ops_count(self: Operator, *args, **kwargs):
    input_shape = self.inacts[0].src_shape
    return input_shape.numel() * 2
