from typing import Optional

from mblt import LayerType
from mblt.core import SHAPELIKE, Shape, ActivationSpec, Operator, OperatorRegistry
from mblt.operator import broadcast_shape


@OperatorRegistry.register_infer_shape(LayerType.Expand)
def infer_shape(self: Operator, *input_shape: SHAPELIKE, **kwargs) -> Optional[Shape]:
    assert len(input_shape) == 1
    shape = kwargs["constant"]
    if hasattr(shape, "value"):
        shape = shape.value
    shape = tuple(shape)
    return Shape(broadcast_shape(input_shape[0], shape))


@OperatorRegistry.register_call_fn(LayerType.Expand)
def call_fn(self: Operator, *args, **kwargs):
    name = self.layertype.name.lower()
    constant = kwargs["constant"]
    return ActivationSpec(
        name=name,
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args), constant=constant),
    )

@OperatorRegistry.register_ops_count(LayerType.Expand)
def ops_count(self: Operator, *args, **kwargs):
    return 0