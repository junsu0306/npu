from typing import Optional

from mblt import LayerType
from mblt.core import SHAPELIKE, Shape, Operator, OperatorRegistry, ActivationSpec


@OperatorRegistry.register_infer_shape(LayerType.Softmax)
def infer_shape(op: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    assert len(input_shape) == 1
    return Shape(input_shape[0])


@OperatorRegistry.register_call_fn(LayerType.Softmax)
def actfunc_call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name=self.layertype.name.lower(),
        dtype=args[0].dtype,
        src_shape=self.infer_shape(args[0].src_shape),
    )


@OperatorRegistry.register_ops_count(LayerType.Softmax)
def ops_count(self: Operator, *args, **kwargs):
    input_shape = self.inacts[0].src_shape
    axis = self.options.axis
    if axis < 0:
        axis += len(input_shape)

    axis_size = int(input_shape[axis])
    if axis_size <= 0:
        return 0

    num_groups = input_shape.numel() / axis_size
    cost = num_groups * (3 * axis_size - 1)
    if self.options.beta != 1:
        cost += input_shape.numel()
    return cost
