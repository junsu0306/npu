from typing import Optional

from mblt.core import (
    SHAPELIKE,
    Shape,
    ActivationSpec,
    Operator,
    OperatorRegistry,
    LayerType,
)
from .opkind import NORMALIZATIONS


def infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    assert len(input_shape) == 1
    return Shape(input_shape[0])


def call_fn(self: Operator, *args, **kwargs):
    name = self.layertype.name.lower()
    name = name[: name.find("norm") + 4]
    return ActivationSpec(
        name=name,
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )


_OPS_PER_INPUT_ELEMENT = {
    # (x - mean) * inv_std * scale + bias
    LayerType.Batchnorm: 4,
    # (x - mean) * inv_std * scale + bias
    LayerType.InstanceNormalization: 4,
    # x / sqrt(mean(x^2) + eps)
    # square + reduce-mean handled as per-element average cost + add + rsqrt + mul
    LayerType.RmsNormalization: 4,
    # (x - mean) * inv_std * scale + bias
    LayerType.LayerNormalization: 4,
    # (x - mean) * inv_std * scale + bias
    LayerType.GroupNormalization: 4,
    # x / sum(abs(x))
    LayerType.L1Normalization: 3,
    # x / sqrt(sum(x^2))
    LayerType.L2Normalization: 4,
    # x / sum(x)
    LayerType.SumNormalization: 2,
    # x * gamma / sqrt(mean(x^2) + eps) + beta
    LayerType.GlobalResponseNormalization: 5,
}


def _validate_ops_count_table():
    missing = NORMALIZATIONS - set(_OPS_PER_INPUT_ELEMENT)
    extra = set(_OPS_PER_INPUT_ELEMENT) - NORMALIZATIONS
    if missing or extra:
        raise RuntimeError(
            "NORMALIZATIONS and _OPS_PER_INPUT_ELEMENT keys mismatch: "
            f"missing={sorted(x.name for x in missing)}, "
            f"extra={sorted(x.name for x in extra)}"
        )


def normalization_ops_count(self: Operator, *args, **kwargs):
    return self.inacts[0].src_shape.numel() * _OPS_PER_INPUT_ELEMENT[self.layertype]


_validate_ops_count_table()


for layertype in NORMALIZATIONS:
    OperatorRegistry.register_call_fn(layertype)(call_fn)
    OperatorRegistry.register_infer_shape(layertype)(infer_shape)
    OperatorRegistry.register_ops_count(layertype)(normalization_ops_count)
