from typing import Optional

from mblt.core import (
    Shape,
    SHAPELIKE,
    LayerType,
    ActivationSpec,
    OperatorRegistry,
    Operator,
)


@OperatorRegistry.register_infer_shape(LayerType.Input)
def input_infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    return Shape(input_shape[0])


@OperatorRegistry.register_call_fn(LayerType.Input)
def input_call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="input",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )


@OperatorRegistry.register_ops_count(LayerType.Input)
def input_ops_count(self: Operator, *args, **kwargs):
    return 0


@OperatorRegistry.register_infer_shape(LayerType.Output)
def infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    return Shape(input_shape[0])


@OperatorRegistry.register_call_fn(LayerType.Output)
def output_call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="output",
        dtype=args[0].dtype,
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )


@OperatorRegistry.register_ops_count(LayerType.Output)
def output_ops_count(self: Operator, *args, **kwargs):
    return 0


@OperatorRegistry.register_infer_shape(LayerType.InputConstant)
def infer_shape(self: Operator, *input_shape: SHAPELIKE) -> Optional[Shape]:
    return Shape(self.options.shape)


@OperatorRegistry.register_call_fn(LayerType.InputConstant)
def inputconst_call_fn(self: Operator, *args, **kwargs):
    return ActivationSpec(
        name="inputcons",
        dtype=str(self.options.dtype),
        src_shape=self.infer_shape(*(x.src_shape for x in args)),
    )


@OperatorRegistry.register_ops_count(LayerType.InputConstant)
def inputconst_ops_count(self: Operator, *args, **kwargs):
    return 0
