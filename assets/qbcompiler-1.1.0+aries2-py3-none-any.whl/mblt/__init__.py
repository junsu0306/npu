# Top-level mblt package exports
from __future__ import annotations

try:
    # Prefer runtime package version from installed metadata
    from importlib.metadata import version, PackageNotFoundError  # type: ignore
except Exception:  # pragma: no cover - very old Python
    version = None  # type: ignore
    PackageNotFoundError = Exception  # type: ignore

__version__ = None
if "version" in globals():
    try:
        __version__ = version("mblt")  # type: ignore[arg-type]
    except Exception:
        __version__ = None

# Re-export commonly used items for convenience
from .manifest import Manifest  # noqa: E402,F401
from .model_dict import ModelDict  # noqa: E402,F401
from .serialize import load_model_dict
from .core import (
    LayerType,
    ActivationSpec,
    TensorSpec,
    ArrayWrapper,
    LayerOptions,
    DataFormat,
    SubGraph,
)
from mblt.subgraph import MbltSubGraphBuilder
from mblt.operator import Operator
from .logger import set_logger, get_logger  # noqa: E402,F401
