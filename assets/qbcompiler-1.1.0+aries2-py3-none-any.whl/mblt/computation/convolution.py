from typing import Optional

import numpy
import numpy as np


def numpy_conv2d(
    x: numpy.ndarray,
    weight: numpy.ndarray,
    bias: Optional[numpy.ndarray] = None,
    stride=(1, 1),
    dilation=(1, 1),
    padding=None,
    groups=1,
):
    """
    x: (N, C_in, H, W)
    w: (C_out, C_in, kH, kW)
    bias: (C_out,)
    stride: int or (stride_H, stride_W)
    dilation: int or (dilation_H, dilation_W)
    paddings: int or List[int]
    groups:int
    """

    if isinstance(stride, int):
        stride_H = stride_W = stride
    else:
        stride_H, stride_W = stride

    if isinstance(dilation, int):
        dilation_H = dilation_W = dilation
    else:
        dilation_H, dilation_W = dilation

    N, C_in, H, W = x.shape
    C_out, C_in_w, kH, kW = weight.shape
    assert C_in % groups == 0, "C_in must be divisible by groups"
    assert C_out % groups == 0, "C_out must be divisible by groups"
    assert C_in_w == C_in // groups

    if padding is not None:
        if isinstance(padding, int):
            padding = (padding,) * 4
        assert len(padding) == 4
        h_pad_begin, w_pad_begin, h_pad_end, w_pad_end = padding
        x_padded = numpy.pad(
            x,
            ((0, 0), (0, 0), (h_pad_begin, h_pad_end), (w_pad_begin, w_pad_end)),
            mode="constant",
        )
    else:
        x_padded = x

    N, C_in, H_p, W_p = x_padded.shape

    dilated_kerH = dilation_H * (kH - 1) + 1
    dilated_kerW = dilation_W * (kW - 1) + 1

    out_H = (H_p - dilated_kerH) // stride_H + 1
    out_W = (W_p - dilated_kerW) // stride_W + 1

    sN, sC, sH, sW = x_padded.strides  # original strides

    shape = (N, C_in, out_H, out_W, kH, kW)

    strides = (
        sN,  # batch
        sC,  # channel
        sH * stride_H,  # slide H
        sW * stride_W,  # slide W
        sH * dilation_H,  # kernel vertical jump
        sW * dilation_W,  # kernel horizontal jump
    )
    windows = numpy.lib.stride_tricks.as_strided(x_padded, shape=shape, strides=strides)

    if groups == 1:
        # (N, out_H, out_W, C_out)
        # windows.shape = (N, C_in, out_H, out_W, kH, kW)
        # w.shape = (C_out, C_in, kH, kW)
        out = numpy.tensordot(windows, weight, axes=([1, 4, 5], [1, 2, 3]))
        out = numpy.moveaxis(out, -1, 1)  # -> (N, C_out, out_H, out_W)
    else:
        out = np.zeros((N, C_out, out_H, out_W), dtype=x.dtype)  # buffer
        Cout_g = C_out // groups
        Cin_g = C_in // groups
        for g in range(groups):
            # Input slice per group
            win_g = windows[:, g * Cin_g : (g + 1) * Cin_g]

            # Weight slice per group
            w_g = weight[g * Cout_g : (g + 1) * Cout_g]

            # tensordot: (N, Cin_g, out_H, out_W, kH, kW) x (Cout_g, Cin_g, kH, kW)
            # → (N, out_H, out_W, Cout_g)
            out_g = np.tensordot(win_g, w_g, axes=([1, 4, 5], [1, 2, 3]))

            # Move channel axis to 1 → (N, Cout_g, out_H, out_W)
            out_g = np.moveaxis(out_g, -1, 1)

            # Write result
            out[:, g * Cout_g : (g + 1) * Cout_g] = out_g

    # ---- 5. bias 추가 ----
    if bias is not None:
        out += bias[None, :, None, None]

    return out


def run_test_case(
    N=2,
    C_in=6,
    C_out=8,
    H=12,
    W=13,
    kH=3,
    kW=3,
    stride=(1, 1),
    padding=(1, 1),
    dilation=(1, 1),
    groups=1,
):
    import torch

    # numpy input
    x = np.random.randn(N, C_in, H, W).astype(np.float32)

    # weight shape: (C_out, C_in/groups, kH, kW)
    w = np.random.randn(C_out, C_in // groups, kH, kW).astype(np.float32)
    bias = np.random.randn(C_out).astype(np.float32)

    if isinstance(padding, tuple) and len(padding) == 2:
        paddings_for_np = (padding[0], padding[1], padding[0], padding[1])
    elif isinstance(padding, int):
        paddings_for_np = (padding, padding, padding, padding)
    else:
        raise NotImplementedError(f"padding type {type(padding)} is not supported")
    # NumPy reference
    y_np = numpy_conv2d(
        x,
        w,
        bias=bias,
        stride=stride,
        padding=paddings_for_np,
        dilation=dilation,
        groups=groups,
    )

    # torch version
    x_t = torch.tensor(x)
    w_t = torch.tensor(w)
    b_t = torch.tensor(bias)

    y_t = (
        torch.nn.functional.conv2d(
            x_t,
            w_t,
            bias=b_t,
            stride=stride,
            padding=padding,
            dilation=dilation,
            groups=groups,
        )
        .detach()
        .numpy()
    )

    # errors
    max_err = np.max(np.abs(y_np - y_t))
    mean_err = np.mean(np.abs(y_np - y_t))

    print(f"max error: {max_err:.6f}, mean error: {mean_err:.6f}")

    return max_err, mean_err


def run_random_tests(num_tests=30):
    import torch

    for i in range(num_tests):
        print(f"=== Test {i+1}/{num_tests} ===")

        N = np.random.randint(1, 3)
        C_in = np.random.choice([4, 6, 8])
        groups = np.random.choice([1, 2, 4])  # must divide C_in
        groups = min(groups, C_in) if C_in % groups == 0 else 1

        C_out = np.random.choice([4, 8, 12])
        C_out = (C_out // groups) * groups  # divisible

        H = np.random.randint(20, 30)
        W = np.random.randint(20, 30)

        kH = np.random.choice([1, 3, 5])
        kW = np.random.choice([1, 3, 5])

        stride = (np.random.randint(1, 3), np.random.randint(1, 3))
        padding = (np.random.randint(0, 3), np.random.randint(0, 3))
        dilation = (np.random.randint(1, 3), np.random.randint(1, 3))

        max_err, mean_err = run_test_case(
            N,
            C_in,
            C_out,
            H,
            W,
            kH,
            kW,
            stride=stride,
            padding=padding,
            dilation=dilation,
            groups=groups,
        )

        if max_err > 1e-4:
            print("❌ FAILED")
            return

    print("🎉 All tests passed!")


if __name__ == "__main__":
    run_random_tests(100)
