import unittest

import numpy as np


def scatternd_full_indices(shape):
    grid = np.indices(shape)  # shape = (4, 1,1,3136,196)
    grid = np.moveaxis(grid, 0, -1)  # (1,1,3136,196,4)
    return grid


def scatternd(data, indices, updates, reduction="none"):
    data = np.array(data, copy=True)
    indices = np.asarray(indices)
    updates = np.asarray(updates)

    if indices.ndim == 0:
        raise ValueError("indices must have at least 1 dimension (..., K).")

    # float로 들어와도 "정수 값"이면 허용
    if np.issubdtype(indices.dtype, np.floating):
        if not np.all(np.isfinite(indices)):
            raise ValueError("indices contains NaN/Inf.")
        if not np.all(indices == np.floor(indices)):
            raise TypeError("indices float array contains non-integer values.")
        indices = indices.astype(np.int64, copy=False)
    elif not np.issubdtype(indices.dtype, np.integer):
        raise TypeError(f"indices must be integer dtype, got {indices.dtype}")

    k = indices.shape[-1]
    if k > data.ndim:
        raise ValueError("Index depth K must be <= data rank")

    idx_shape = indices.shape[:-1]
    num_idx = int(np.prod(idx_shape))

    flat_indices = indices.reshape(num_idx, k)

    target_updates_shape = tuple(idx_shape) + tuple(data.shape[k:])
    if updates.shape != target_updates_shape:
        raise ValueError(
            f"updates shape mismatch: expected {target_updates_shape}, got {updates.shape}"
        )

    flat_updates = updates.reshape((num_idx,) + tuple(data.shape[k:]))

    index_tuples = tuple(flat_indices[:, dim] for dim in range(k))
    tail_slices = (slice(None),) * (data.ndim - k)
    full_index = index_tuples + tail_slices

    if reduction == "none":
        data[full_index] = flat_updates
    elif reduction == "add":
        np.add.at(data, full_index, flat_updates)
    elif reduction == "mul":
        np.multiply.at(data, full_index, flat_updates)
    else:
        raise ValueError(f"Unsupported reduction: {reduction}")

    return data


class TestScatterND(unittest.TestCase):
    def test_reduction_none_scalar_updates(self):
        data = np.zeros((3, 3), dtype=np.int64)
        indices = np.array([[0, 1], [2, 2]])
        updates = np.array([5, 9], dtype=np.int64)

        out = scatternd(data, indices, updates, reduction="none")

        expected = np.zeros((3, 3), dtype=np.int64)
        expected[0, 1] = 5
        expected[2, 2] = 9
        np.testing.assert_array_equal(out, expected)

    def test_reduction_none_tail_shape_updates(self):
        data = np.zeros((2, 3, 4), dtype=np.float32)
        indices = np.array([[0], [1]])  # K=1 -> updates shape: (2, 3, 4)
        updates = np.arange(2 * 3 * 4, dtype=np.float32).reshape(2, 3, 4)

        out = scatternd(data, indices, updates, reduction="none")

        expected = np.zeros((2, 3, 4), dtype=np.float32)
        expected[0] = updates[0]
        expected[1] = updates[1]
        np.testing.assert_array_equal(out, expected)

    def test_reduction_add_accumulates_on_duplicates(self):
        data = np.zeros((3,), dtype=np.int64)
        indices = np.array([[1], [1], [2]])
        updates = np.array([3, 4, 5], dtype=np.int64)

        out = scatternd(data, indices, updates, reduction="add")

        expected = np.array([0, 7, 5], dtype=np.int64)
        np.testing.assert_array_equal(out, expected)

    def test_reduction_mul_accumulates_on_duplicates(self):
        data = np.ones((3,), dtype=np.int64)
        indices = np.array([[1], [1], [2]])
        updates = np.array([3, 4, 5], dtype=np.int64)

        out = scatternd(data, indices, updates, reduction="mul")

        expected = np.array([1, 12, 5], dtype=np.int64)
        np.testing.assert_array_equal(out, expected)

    def test_indices_float_integer_values_are_allowed(self):
        data = np.zeros((3,), dtype=np.int64)
        indices = np.array([[1.0], [2.0]], dtype=np.float64)  # float지만 정수값
        updates = np.array([10, 20], dtype=np.int64)

        out = scatternd(data, indices, updates, reduction="none")

        expected = np.array([0, 10, 20], dtype=np.int64)
        np.testing.assert_array_equal(out, expected)

    def test_indices_ndim_zero_raises(self):
        data = np.zeros((3,), dtype=np.int64)
        indices = np.array(1, dtype=np.int64)  # ndim == 0
        updates = np.array([9], dtype=np.int64)

        with self.assertRaises(ValueError):
            scatternd(data, indices, updates)

    def test_indices_float_with_nan_or_inf_raises(self):
        data = np.zeros((3,), dtype=np.int64)
        indices = np.array([[np.nan]], dtype=np.float64)
        updates = np.array([1], dtype=np.int64)

        with self.assertRaises(ValueError):
            scatternd(data, indices, updates)

    def test_indices_float_with_non_integer_values_raises(self):
        data = np.zeros((3,), dtype=np.int64)
        indices = np.array([[1.2]], dtype=np.float64)
        updates = np.array([1], dtype=np.int64)

        with self.assertRaises(TypeError):
            scatternd(data, indices, updates)

    def test_indices_non_integer_dtype_raises(self):
        data = np.zeros((3,), dtype=np.int64)
        indices = np.array([["1"]], dtype=np.str_)
        updates = np.array([1], dtype=np.int64)

        with self.assertRaises(TypeError):
            scatternd(data, indices, updates)

    def test_k_greater_than_data_rank_raises(self):
        data = np.zeros((3,), dtype=np.int64)  # rank=1
        indices = np.array([[0, 0]], dtype=np.int64)  # K=2
        updates = np.array([1], dtype=np.int64)

        with self.assertRaises(ValueError):
            scatternd(data, indices, updates)

    def test_updates_shape_mismatch_raises(self):
        data = np.zeros((3, 2), dtype=np.int64)
        indices = np.array([[0], [1]], dtype=np.int64)  # idx_shape=(2,), K=1
        updates = np.array([1, 2], dtype=np.int64)  # expected (2, 2)

        with self.assertRaises(ValueError):
            scatternd(data, indices, updates)

    def test_unsupported_reduction_raises(self):
        data = np.zeros((3,), dtype=np.int64)
        indices = np.array([[1]], dtype=np.int64)
        updates = np.array([1], dtype=np.int64)

        with self.assertRaises(ValueError):
            scatternd(data, indices, updates, reduction="max")


if __name__ == "__main__":
    unittest.main()
