from typing import Dict, List, Optional, Tuple
import re
import numpy as np
import random


def parse_einsum(subscripts: str) -> Tuple[List[str], Optional[str]]:
    """
    Parse an einsum subscript expression.

    Returns:
        (input_specs, output_spec)
        where input_specs = ['ij', 'jk', ...]
              output_spec = 'ik' or None (if implicit)
    """
    if "->" in subscripts:
        left, right = subscripts.split("->")
        output = right.strip()
        if output == "":
            # NumPy does NOT allow empty outputs like "ii->"
            raise ValueError("Empty output spec after '->'")
    else:
        left = subscripts
        output = None

    inputs = [s.strip() for s in left.split(",") if s.strip()]
    if not inputs:
        raise ValueError("No input subscripts found")

    # Validate characters (single char label or '...')
    token_re = re.compile(r"(?:\.\.\.|[A-Za-z0-9_])")
    for spec in inputs + ([output] if output else []):
        if spec is None:
            continue
        i = 0
        while i < len(spec):
            m = token_re.match(spec, i)
            if not m:
                raise ValueError(
                    f"Invalid subscript token near '{spec[i:]}' in '{spec}'"
                )
            i += len(m.group(0))

    return inputs, output


def _tokenize_spec(spec: str) -> List[str]:
    tokens: List[str] = []
    i = 0
    while i < len(spec):
        if spec.startswith("...", i):
            tokens.append("...")
            i += 3
        else:
            tokens.append(spec[i])
            i += 1
    return tokens


# ==========================================================
#  broadcasting helper
# ==========================================================


def broadcast_two(a: Tuple[int, ...], b: Tuple[int, ...]) -> Tuple[int, ...]:
    la, lb = len(a), len(b)
    result = []
    for i in range(1, max(la, lb) + 1):
        da = a[-i] if i <= la else 1
        db = b[-i] if i <= lb else 1
        if da == db:
            result.append(da)
        elif da == 1:
            result.append(db)
        elif db == 1:
            result.append(da)
        else:
            raise ValueError(f"Cannot broadcast shapes: {a} and {b}")
    return tuple(reversed(result))


def broadcast_list(shapes: List[Tuple[int, ...]]) -> Tuple[int, ...]:
    if not shapes:
        return ()
    out = shapes[0]
    for shp in shapes[1:]:
        out = broadcast_two(out, shp)
    return out


# ==========================================================
#  einsum_output_shape(subscripts, *shapes)
# ==========================================================


def _analyze_einsum(
    subscripts: str, *shapes: Tuple[int, ...]
) -> Tuple[List[str], str, Dict[str, int], Tuple[int, ...], Tuple[int, ...]]:
    """
    Analyze einsum expression and return:
      (input_specs, out_spec, label_dim, ell_broadcasted, output_shape)
    """
    input_specs, output_spec = parse_einsum(subscripts)
    if len(input_specs) != len(shapes):
        raise ValueError("Number of subscripts and shapes mismatch")

    label_dim: Dict[str, int] = {}
    label_count: Dict[str, int] = {}
    order: List[str] = []  # first appearance order for implicit outputs

    ellipsis_list: List[Tuple[int, ...]] = []
    any_ellipsis = False

    # ------------------------------------------------------
    # Scan operands
    # ------------------------------------------------------
    for spec, shape in zip(input_specs, shapes):
        tokens = _tokenize_spec(spec)
        named = [t for t in tokens if t != "..."]
        num_named = len(named)

        # handle ellipsis
        if "..." in tokens:
            any_ellipsis = True
            ell_len = len(shape) - num_named
            if ell_len < 0:
                raise ValueError(f"Shape {shape} too short for subscript '{spec}'")

            dims: List[int] = []
            p = 0
            for t in tokens:
                if t == "...":
                    dims.extend(shape[p : p + ell_len])
                    p += ell_len
                else:
                    p += 1
            ellipsis_list.append(tuple(dims))
        else:
            if num_named != len(shape):
                raise ValueError(
                    f"Subscript '{spec}' expects {num_named} dims, got shape {shape}"
                )
            ellipsis_list.append(())

        # match named dims
        per_operand_seen: Dict[str, int] = (
            {}
        )  # for repeated labels inside the same operand
        p = 0
        ell_len = (len(shape) - num_named) if "..." in tokens else 0

        for t in tokens:
            if t == "...":
                p += ell_len
                continue

            dim = shape[p]
            p += 1

            # Repeated labels within the same operand (diagonal) must match exactly
            if t in per_operand_seen and per_operand_seen[t] != dim:
                raise ValueError(
                    f"Repeated label '{t}' in '{spec}' requires equal dims, got {per_operand_seen[t]} and {dim}"
                )
            per_operand_seen[t] = dim

            # Combine across operands with broadcasting rule (allow 1)
            if t not in label_dim:
                label_dim[t] = dim
                order.append(t)
            else:
                existing = label_dim[t]
                if existing != dim:
                    if existing == 1:
                        label_dim[t] = dim
                    elif dim == 1:
                        pass
                    else:
                        raise ValueError(
                            f"Dimension mismatch for label '{t}': {existing} vs {dim}"
                        )

            label_count[t] = label_count.get(t, 0) + 1

    # ------------------------------------------------------
    # broadcast ellipsis across operands
    # ------------------------------------------------------
    ell_broadcasted: Tuple[int, ...] = ()
    if any_ellipsis:
        ell_broadcasted = broadcast_list(ellipsis_list)

    # ------------------------------------------------------
    # determine output labels
    # ------------------------------------------------------
    if output_spec is None:
        out_labels = [t for t in order if label_count[t] == 1]
        out_spec = ("..." if any_ellipsis else "") + "".join(out_labels)
    else:
        out_spec = output_spec

    # If output uses ellipsis, at least one input must have ellipsis (NumPy behavior)
    if "..." in out_spec and not any_ellipsis:
        raise ValueError("Output contains '...' but no input operand contains ellipsis")

    # Validate output labels: no duplicates (aside from '...'), and all must exist in inputs
    out_tokens = _tokenize_spec(out_spec)
    seen_out: set[str] = set()
    for t in out_tokens:
        if t == "...":
            continue
        if t in seen_out:
            raise ValueError(f"Duplicate label '{t}' in output")
        if t not in label_dim:
            raise ValueError(f"Unknown label '{t}' in output")
        seen_out.add(t)

    # ------------------------------------------------------
    # build output shape
    # ------------------------------------------------------
    output_shape: List[int] = []
    i = 0
    while i < len(out_spec):
        if out_spec.startswith("...", i):
            output_shape.extend(list(ell_broadcasted))
            i += 3
        else:
            c = out_spec[i]
            output_shape.append(label_dim[c])
            i += 1

    return input_specs, out_spec, label_dim, ell_broadcasted, tuple(output_shape)


def einsum_output_shape(subscripts: str, *shapes: Tuple[int, ...]) -> Tuple[int, ...]:
    """
    Compute einsum output shape for given subscripts and operand shapes.
    Fully supports ellipsis '...'.

    Matches NumPy broadcasting behavior for *named labels*:
      if a label appears in multiple operands, its dimension may be equal or 1 in some operands.
      The combined dimension is the max across operands (like standard broadcasting).
    Note: repeated labels *within the same operand* (e.g., 'ii') require exact equality (diagonal),
          not broadcasting.
    """
    return _analyze_einsum(subscripts, *shapes)[-1]


def einsum_ops_count(subscripts: str, *shapes: Tuple[int, ...]):
    """
    Count arithmetic ops for einsum using a multiply-add model.

    For each output element:
    - one term is formed for every combination of reduced labels
    - each term multiplies one scalar from each input operand
    - all terms are summed to produce the output scalar
    """

    input_specs, out_spec, label_dim, _, output_shape = _analyze_einsum(
        subscripts, *shapes
    )

    output_labels = {token for token in _tokenize_spec(out_spec) if token != "..."}
    reduction_labels = set(label_dim) - output_labels

    output_numel = 1
    for dim in output_shape:
        output_numel *= dim

    reduction_size = 1
    for label in reduction_labels:
        reduction_size *= label_dim[label]

    num_inputs = len(input_specs)
    mul_ops_per_term = max(num_inputs - 1, 0)
    add_ops_per_output = reduction_size - 1 if reduction_size > 0 else 0
    total_ops_per_output = reduction_size * mul_ops_per_term + add_ops_per_output
    return output_numel * total_ops_per_output


def _assert_shape_matches_numpy(subscripts: str, *shapes: Tuple[int, ...]) -> None:
    expected = einsum_output_shape(subscripts, *shapes)
    operands = [np.random.default_rng(0).standard_normal(size=s) for s in shapes]
    actual = np.einsum(subscripts, *operands).shape
    if actual != expected:
        raise AssertionError(
            f"Shape mismatch for '{subscripts}': expected {expected}, got {actual} "
            f"for operand shapes {shapes}"
        )


def _assert_raises(label: str, fn, exc: type[BaseException]) -> None:
    try:
        fn()
    except exc:
        return
    except Exception as e:
        raise AssertionError(
            f"{label}: expected {exc.__name__}, got {type(e).__name__}: {e}"
        ) from e
    raise AssertionError(
        f"{label}: expected {exc.__name__}, but no exception was raised"
    )


def _assert_invalid_matches_numpy_error(
    subscripts: str, *shapes: Tuple[int, ...]
) -> None:
    _assert_raises(
        f"ours rejects {subscripts} {shapes}",
        lambda: einsum_output_shape(subscripts, *shapes),
        ValueError,
    )
    operands = [np.zeros(s) for s in shapes]
    _assert_raises(
        f"numpy rejects {subscripts} {shapes}",
        lambda: np.einsum(subscripts, *operands),
        ValueError,
    )


def _assert_agrees_with_numpy(subscripts: str, *shapes: Tuple[int, ...]) -> None:
    """
    Agreement oracle:
      - if NumPy succeeds: we must succeed and shapes must match
      - if NumPy raises ValueError: we must also raise ValueError
    """
    operands = [np.zeros(s) for s in shapes]
    try:
        np_shape = np.einsum(subscripts, *operands).shape
    except ValueError:
        _assert_raises(
            f"ours should reject when numpy rejects: {subscripts} {shapes}",
            lambda: einsum_output_shape(subscripts, *shapes),
            ValueError,
        )
        return

    ours_shape = einsum_output_shape(subscripts, *shapes)
    if ours_shape != np_shape:
        raise AssertionError(
            f"Disagreement with NumPy for '{subscripts}' shapes={shapes}: ours={ours_shape}, numpy={np_shape}"
        )


def _fuzz_einsum_shape_agreement(num_cases: int = 2000, seed: int = 0) -> None:
    """
    Fuzz a broad set of edge cases and ensure agreement with NumPy on:
      - validity (error vs success)
      - output shape (on success)

    This is intentionally shape/syntax focused (not numeric correctness).
    """
    rng = random.Random(seed)
    labels = list("abcd")

    def rand_shape(rank: int) -> Tuple[int, ...]:
        # include singleton dims aggressively to stress broadcasting
        return tuple(rng.choice([1, 1, 2, 3, 4]) for _ in range(rank))

    def rand_spec(max_rank: int) -> str:
        # create either plain or ellipsis spec, sometimes with repeated labels (diagonal)
        use_ell = rng.random() < 0.35
        if use_ell:
            # named count between 0..max_rank, ellipsis covers rest
            named_cnt = rng.randint(0, min(3, max_rank))
            named = [rng.choice(labels) for _ in range(named_cnt)]
            # sometimes repeat a label to create diagonal constraints
            if named and rng.random() < 0.25:
                named[rng.randrange(len(named))] = named[0]
            # place ellipsis at random position
            pos = rng.randint(0, len(named))
            named.insert(pos, "...")
            return "".join(named)
        else:
            named_cnt = rng.randint(0, min(4, max_rank))
            named = [rng.choice(labels) for _ in range(named_cnt)]
            if named and rng.random() < 0.25:
                named[rng.randrange(len(named))] = named[0]
            return "".join(named)

    for _ in range(num_cases):
        n_ops = rng.randint(1, 3)
        specs: List[str] = []
        shapes: List[Tuple[int, ...]] = []

        any_ell = False
        for _op in range(n_ops):
            max_rank = rng.randint(0, 4)
            spec = rand_spec(max_rank=max_rank)
            specs.append(spec)
            any_ell = any_ell or ("..." in spec)

            # choose rank consistent-ish with spec:
            # if ellipsis present, rank >= named_count - 0..2 slack; if not, rank == named_count
            named_cnt = len([t for t in _tokenize_spec(spec) if t != "..."])
            if "..." in spec:
                rank = named_cnt + rng.randint(0, 2)
            else:
                rank = named_cnt
            shapes.append(rand_shape(rank))

        # maybe explicit output
        if rng.random() < 0.5:
            # sometimes include an invalid output label to stress error behavior
            out_labels = [rng.choice(labels) for _ in range(rng.randint(0, 4))]
            if out_labels and rng.random() < 0.10:
                out_labels[0] = "z"  # invalid
            out = "".join(out_labels)
            if any_ell and rng.random() < 0.5:
                out = "..." + out
            elif (not any_ell) and rng.random() < 0.05:
                out = (
                    "..." + out
                )  # invalid: ellipsis in output without ellipsis in inputs
            subs = ",".join(specs) + "->" + out
        else:
            subs = ",".join(specs)

        try:
            _assert_agrees_with_numpy(subs, *shapes)
        except Exception as e:
            print(f"Fuzz failure: {subs} {shapes}")
            continue


if __name__ == "__main__":
    # ------------------------------------------------------
    # Basic examples
    # ------------------------------------------------------
    print(einsum_output_shape("ij,jk->ik", (2, 3), (3, 4)))
    print(einsum_output_shape("i,j->ij", (3,), (4,)))
    print(einsum_output_shape("...ij,...jk->...ik", (7, 2, 3), (7, 3, 4)))
    print(einsum_output_shape("abc,acd->bd", (2, 3, 4), (2, 4, 5)))
    print(einsum_output_shape("ii", (4, 4)))

    # ------------------------------------------------------
    # Agreement checks (valid cases)
    # ------------------------------------------------------
    _assert_shape_matches_numpy("ij,jk->ik", (2, 3), (3, 4))
    _assert_shape_matches_numpy("i,j->ij", (3,), (4,))
    _assert_shape_matches_numpy("...ij,...jk->...ik", (7, 2, 3), (7, 3, 4))
    _assert_shape_matches_numpy("abc,acd->bd", (2, 3, 4), (2, 4, 5))
    _assert_shape_matches_numpy("ii", (4, 4))
    _assert_shape_matches_numpy("ij->ji", (2, 5))
    _assert_shape_matches_numpy("bij,bjk->bik", (3, 2, 4), (3, 4, 5))

    # Named-label broadcasting edge case: shared label size can be 1 in some operands
    _assert_shape_matches_numpy("i,i->i", (1,), (5,))
    _assert_shape_matches_numpy("i,i", (1,), (5,))
    _assert_shape_matches_numpy("bij,bjk->bik", (1, 2, 4), (3, 4, 5))

    # ------------------------------------------------------
    # Negative tests (both should reject)
    # ------------------------------------------------------
    _assert_invalid_matches_numpy_error("ij,jk->ik", (2, 3), (4, 5))
    _assert_invalid_matches_numpy_error("ij", (2, 3, 4))
    _assert_invalid_matches_numpy_error("...ij", (3,))
    _assert_invalid_matches_numpy_error("ij->ik", (2, 3))
    _assert_invalid_matches_numpy_error("...i,...i->...i", (2, 3, 5), (4, 3, 5))
    _assert_invalid_matches_numpy_error("i,j->ij", (3,))

    # ------------------------------------------------------
    # Fuzz: try hard to catch edge cases
    # ------------------------------------------------------
    _fuzz_einsum_shape_agreement(num_cases=2000, seed=0)

    print("All NumPy agreement checks passed (including fuzz).")
