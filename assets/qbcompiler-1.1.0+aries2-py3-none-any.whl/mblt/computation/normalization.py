import numpy


def normalize(x, p=2.0, axis=1, eps=1e-12):
    if not isinstance(axis, tuple):
        axis = (axis,)
    if len(axis) <= 2:
        norm = numpy.linalg.norm(x, ord=p, axis=axis, keepdims=True)
    else:
        norm = numpy.power(
            numpy.sum(numpy.power(numpy.abs(x), p), axis=axis, keepdims=True), 1 / p
        )
    return x / numpy.maximum(norm, eps)
