import numpy


def abs(x):
    return numpy.abs(x)


def celu(x, alpha=1.0):
    return numpy.maximum(0, x) + numpy.minimum(0, alpha * (numpy.exp(x / alpha) - 1))


def clip(x, min_val=None, max_val=None):
    return numpy.clip(x, min_val, max_val)


def relu(x):
    return numpy.maximum(x, 0)


def sigmoid(x, alpha=1.0):
    return 1 / (1 + numpy.exp(-alpha * x))


def softplus(x, beta=1.0, threshold=20.0):
    cond = beta * x > threshold
    val = (1.0 / beta) * numpy.log1p(numpy.exp(beta * x))
    return numpy.where(cond, x, val)


def tanh(x):
    return numpy.tanh(x)


def sqrt(x):
    return numpy.sqrt(x)
