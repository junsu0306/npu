from typing import List

from mblt.core import SubGraph


class ModelDict:
    def __init__(
        self,
        model_backend: str = "",
        inputs=None,
        outputs=None,
        subgraphs=None,
        graph_order=None,
        source_file: str = "",
        hw_type: str = "",
    ):
        self.name = ""
        self.version = ""
        self.model_backend = model_backend
        self.source_file = source_file
        self.hw_type = hw_type
        self.inputs: List[str] = inputs if inputs else []
        self.outputs: List[str] = outputs if outputs else []
        self.subgraphs: List[SubGraph] = subgraphs if subgraphs else []
        self.graph_order: List[int] = graph_order if graph_order else [0]

    @classmethod
    def from_dict(cls, data, weight_buffer=None):
        inst = cls(
            model_backend=data["model_backend"],
            inputs=data["inputs"],
            outputs=data["outputs"],
            subgraphs=[SubGraph.from_dict(x) for x in data["subgraphs"]],
            graph_order=data["graph_order"],
            source_file=data.get("source_file", ""),
        )
        return inst

    def to_dict(self):
        dct = {
            "model_backend": self.model_backend,
            "source_file": self.source_file,
            "hw_type": self.hw_type,
            "inputs": self.inputs,
            "outputs": self.outputs,
            "subgraphs": [x.to_dict() for x in self.subgraphs],
            "graph_order": self.graph_order,
        }
        return dct

    def get_act_origin_name(self, name, default=None):
        if hasattr(self, "activation_trace"):
            if name in self.activation_trace:
                return self.activation_trace[name][0]
        return default

    def summary(self):
        sg_summaries = [sg.summary() for sg in self.subgraphs]
        total_ops = sum(s["num_ops"] for s in sg_summaries)
        total_supported = sum(s["num_supported"] for s in sg_summaries)
        total_unsupported = sum(s["num_unsupported"] for s in sg_summaries)
        return {
            "model_backend": self.model_backend,
            "hw_type": self.hw_type,
            "graph_order": self.graph_order,
            "total_ops": total_ops,
            "total_supported": total_supported,
            "total_unsupported": total_unsupported,
            "inputs": self.inputs,
            "outputs": self.outputs,
            # "subgraphs": sg_summaries, # too much of information
        }

    def get_operator_support_info(self):
        return [sg.get_operator_support_info() for sg in self.subgraphs]

    def update_in_out(self):
        all_sg_inputs = []
        for sg in self.subgraphs:
            for op in sg.operators:
                all_sg_inputs.extend(op.options.inputs)
