"""
Manifest for the mblt model file format.
"""

from __future__ import annotations

import dataclasses
import json
from datetime import datetime, timezone
from typing import Optional, Dict, Any

MBLT_FORMAT_NAME: str = "mblt"
MBLT_FORMAT_VERSION: str = "0.1.0"


def now_iso() -> str:
    """Return current time in UTC as ISO-8601 string with 'Z' suffix."""
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclasses.dataclass
class Manifest:
    # identification and versioning
    format_name: str = MBLT_FORMAT_NAME
    format_version: str = MBLT_FORMAT_VERSION

    created_at: str = dataclasses.field(default_factory=now_iso)
    modified_at: str = dataclasses.field(default_factory=now_iso)

    # Generator/provenance info (e.g., your tool name and version)
    generator: Optional[str] = None
    generator_version: Optional[str] = None

    # High-level model info
    model_name: Optional[str] = None
    model_version: Optional[str] = None
    model_hash: Optional[str] = None  # optional integrity/uniqueness marker

    # Free-form notes and extension bag
    notes: Optional[str] = None
    extra: Dict[str, Any] = dataclasses.field(default_factory=dict)

    def touch_modified(self):
        self.modified_at = now_iso()

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Manifest":
        return cls(**data)

    def to_json(self, indent: Optional[int] = 2) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=indent)

    @classmethod
    def from_json(cls, s: str) -> "Manifest":
        return cls.from_dict(json.loads(s))
