import collections
import itertools
import typing
from typing import Dict

from mblt import SubGraph, LayerType, Operator, ActivationSpec
from mblt.operator.opkind import (
    BASIC_NHWC_OPS,
    ACTIVATION_FUNCTIONS,
    NORMALIZATIONS,
    BIOP_ARITHMETIC_CONST,
    STATEFUL_SEQUENTIAL_OPS,
)
from .device import DeviceType
from ..subgraph.util.pattern_util import is_basic_npu_op


class SupportedCondition(typing.Protocol):
    layertype: LayerType
    device: DeviceType

    def __call__(self, op: Operator) -> bool: ...


class SupportedTable:
    def __init__(self, device: DeviceType):
        self._table: Dict[LayerType, SupportedCondition] = {}
        self.device = device

    def __contains__(self, layertype: LayerType):
        return layertype in self._table

    def is_supported(self, op):
        if op.layertype in self._table:
            condition = self._table[op.layertype]
            return condition(op)
        return False

    def register(self, layertype: LayerType, condition: SupportedCondition):
        self._table[layertype] = condition


class MarkSupportedOps:
    def __init__(
        self,
        basic_table: SupportedTable = None,
        conditional_table: SupportedTable = None,
    ):
        self.basic_table = basic_table
        self.conditional_table = conditional_table

    def process(self, subgraph: SubGraph):
        if self.basic_table:
            for op in subgraph.operators:
                op.unsupported = not self.basic_table.is_supported(op)

        if self.conditional_table:
            self._bfs_forward(subgraph)

        # forward로만 했기 때문에
        # 1. input의 경우 모두 unsupported=True
        # 2. inputconst의 경우 기본 구현을 위해 unsupported=False
        for op in subgraph.operators:
            if op.layertype in (LayerType.Input, LayerType.InputConstant):
                outact = op.outacts[0]
                op.unsupported = all(cop.unsupported for cop in outact.consumer_ops)
            elif op.layertype == LayerType.Output:
                op_inact = op.inacts[0]
                op.unsupported = op_inact.producer_op.unsupported
                if src_shape_dtype_check(op_inact):
                    pop = op_inact.producer_op
                    if pop.layertype in (LayerType.Transpose, LayerType.Reshape):
                        op.unsupported = True
                else:
                    op.unsupported = True
        self._backward_from_outputs(subgraph)

    def _backward_from_outputs(self, subgraph):

        def _topological_sort(subgraph):
            indegree = {}
            queue = collections.deque()

            # init indegree
            for op in subgraph.operators:
                indegree[op] = 0

            # compute indegree
            for op in subgraph.operators:
                if op.layertype == LayerType.Output:
                    continue
                for outact in op.outacts:
                    for cop in outact.consumer_ops:
                        indegree[cop] += 1

            # push all indegree==0
            for op, deg in indegree.items():
                if deg == 0:
                    queue.append(op)

            topo = []

            while queue:
                op = queue.popleft()
                topo.append(op)

                for outact in op.outacts:
                    for cop in outact.consumer_ops:
                        indegree[cop] -= 1
                        if indegree[cop] == 0:
                            if cop.layertype == LayerType.Output:
                                continue
                            queue.append(cop)

            return topo

        topo = _topological_sort(subgraph=subgraph)

        # reverse order: Output → Input
        for op in reversed(topo):
            if op.layertype in (
                LayerType.Input,
                LayerType.InputConstant,
                LayerType.Output,
            ):
                continue
            if op.unsupported:
                continue
            #  여기를 조절해야 함.
            if op.layertype not in (LayerType.Reshape, LayerType.Transpose):
                continue

            all_unsupported = True
            for outact in op.outacts:
                consumers = outact.consumer_ops
                if not consumers:
                    all_unsupported = False
                    break
                # 하나라도 supported consumer가 있으면 유지
                if any(not cop.unsupported for cop in consumers):
                    all_unsupported = False
                    break
            if all_unsupported:
                op.unsupported = True

    def _bfs_forward(self, subgraph: SubGraph):
        queue = collections.deque()
        for op in subgraph.operators:
            if not op.unsupported:
                for outact in op.outacts:
                    queue.extend(cop for cop in outact.consumer_ops)
        while queue:
            op = queue.popleft()
            if not op.unsupported:
                continue
            if self.conditional_table.is_supported(op):
                op.unsupported = False
                for outact in op.outacts:
                    queue.extend(cop for cop in outact.consumer_ops)


def src_shape_dtype_check(activation: ActivationSpec):
    if activation.dtype == "bool":
        return False
    if activation.src_dim == 4:
        b = activation.src_shape[0]
        return b == 1 and not getattr(b, "dynamic", False)
    return False


def src_shape_and_pop_check(activation: ActivationSpec):
    return src_shape_dtype_check(activation) and not activation.producer_op.unsupported


class BasicSupportedOpCondition:
    def __init__(
        self, layertype: LayerType, device: DeviceType = DeviceType.DEFAULT_DEVICE
    ):
        self.layertype = layertype
        self.device = device

    def __call__(self, op: Operator) -> bool:
        return all(src_shape_dtype_check(inact) for inact in op.inacts)


class ForceSupportedCondition:
    def __init__(
        self, layertype: LayerType, device: DeviceType = DeviceType.DEFAULT_DEVICE
    ):
        # we need this for the case when we want to force a layer to be supported.
        # convenient for device extension implementation.
        self.layertype = layertype
        self.device = device

    def __call__(self, *args, **kwargs):
        return True


class ForceUnsupportedCondition:
    def __init__(
        self, layertype: LayerType, device: DeviceType = DeviceType.DEFAULT_DEVICE
    ):
        # we need this for the case when we want to force a layer to be unsupported.
        # convenient for device extension implementation.
        self.layertype = layertype
        self.device = device

    def __call__(self, *args, **kwargs):
        return False


class SingleInputPopCheckCondition:
    def __init__(
        self, layertype: LayerType, device: DeviceType = DeviceType.DEFAULT_DEVICE
    ):
        self.layertype = layertype
        self.device = device

    def __call__(self, op: Operator) -> bool:
        return src_shape_and_pop_check(op.inacts[0])


class BasicSupportedOpTable(SupportedTable):
    def __init__(self, device: DeviceType):
        super().__init__(device)
        for layertype in BASIC_NHWC_OPS:
            if layertype == LayerType.MatMul:
                continue
            self.register(layertype, BasicSupportedOpCondition(layertype, self.device))
        self.register(
            LayerType.InputConstant,
            ForceSupportedCondition(LayerType.InputConstant, self.device),
        )
        self.register(
            LayerType.Resize, ResizeSupportedCondition(self.device)
        )
        for lt in STATEFUL_SEQUENTIAL_OPS:
            self.register(lt, StatefulSequentialOpSupportedCondition(lt, self.device))


class PrevOpSupportedCondition:
    def __init__(
        self, layertype: LayerType, device: DeviceType = DeviceType.DEFAULT_DEVICE
    ):
        self.layertype = layertype
        self.device = device

    def __call__(self, op: Operator) -> bool:
        if all(src_shape_dtype_check(inact) for inact in op.inacts):
            pop = op.inacts[0].producer_op
            return not pop.unsupported
        return False


class ConcatenateSupportedCondition:
    def __init__(self, device: DeviceType = DeviceType.DEFAULT_DEVICE):
        self.layertype = LayerType.Convolution
        self.device = device

    def __call__(self, op: Operator) -> bool:
        axis = op.options.axis
        if axis < 0:
            axis += 4
        return axis in (1, 2, 3) and any(
            src_shape_and_pop_check(inact) for inact in op.inacts
        )


class SliceSupportedCondition:
    def __init__(self, device: DeviceType = DeviceType.DEFAULT_DEVICE):
        self.layertype = LayerType.Slice
        self.device = device

    def __call__(self, op: Operator) -> bool:
        axes = set(ax + 4 if ax < 0 else ax for ax in op.options.axis)
        axes = axes.issubset({1, 2, 3})
        return src_shape_and_pop_check(op.inacts[0]) and axes


class ReduceOpSupportedCondition:
    def __init__(
        self, layertype: LayerType, device: DeviceType = DeviceType.DEFAULT_DEVICE
    ):
        self.layertype = layertype
        self.device = device

    def __call__(self, op: Operator) -> bool:
        axes = set(ax + 4 if ax < 0 else ax for ax in op.options.reduce_axes)
        axes = axes.issubset({1, 2, 3})
        keep_dims = bool(op.options.keep_dims)
        inact = op.inacts[0]
        if any(x.dynamic for x in inact.src_shape):
            return False
        return src_shape_and_pop_check(op.inacts[0]) and axes and keep_dims


class BiopSupportedCondition:
    def __init__(
        self, layertype: LayerType, device: DeviceType = DeviceType.DEFAULT_DEVICE
    ):
        self.layertype = layertype
        self.device = device

    def __call__(self, op: Operator) -> bool:
        if all(src_shape_and_pop_check(inact) for inact in op.inacts):
            return True
        return False


class BiopConstantSupportedCondition:
    def __init__(
        self, layertype: LayerType, device: DeviceType = DeviceType.DEFAULT_DEVICE
    ):
        self.layertype = layertype
        self.device = device

    def __call__(self, op: Operator) -> bool:
        inact = op.inacts[0]
        return src_shape_and_pop_check(inact)


class StatefulSequentialOpSupportedCondition:
    def __init__(
        self, layertype: LayerType, device: DeviceType = DeviceType.DEFAULT_DEVICE
    ):
        self.layertype = layertype
        self.device = device

    def __call__(self, op: Operator) -> bool:
        return op.options.direction in (
            "forward",
            "backward",
        )


class NormalizationSupportedCondition:
    def __init__(
        self, layertype: LayerType, device: DeviceType = DeviceType.DEFAULT_DEVICE
    ):
        self.layertype = layertype
        self.device = device

    def __call__(self, op: Operator) -> bool:
        inact = op.inacts[0]
        if not src_shape_dtype_check(op.inacts[0]):
            return False
        # layernorm, rmsnorm
        normalized_shape = getattr(op.options, "normalized_shape", None)
        if normalized_shape is not None:
            return normalized_shape == (int(inact.src_shape[3]),)
        norm_axis = getattr(op.options, "norm_axis", None)
        if norm_axis is not None:
            norm_axis = tuple(x + 4 if x < 0 else x for x in norm_axis)
            return set(norm_axis).issubset({1, 2, 3})
        return True


class ReshapeSupportedCondition:
    def __init__(self, device: DeviceType = DeviceType.DEFAULT_DEVICE):
        self.layertype = LayerType.Reshape
        self.device = device
        # self.allowable_exprs = [
        #     "1hwc->11(hw)c",
        #     "11(hw)c->1hwc",
        #     "1hwc->1(hw)1c",
        #     "1(hw)1c->1hwc",
        # ]

    def __call__(self, op: Operator) -> bool:
        inact = op.inacts[0]
        if not src_shape_and_pop_check(inact):
            return False
        outact = op.outacts[0]
        if outact.src_dim != 4:
            return False
        n, h, w, c = inact.src_shape
        x, y, z, t = outact.src_shape
        return n == 1 and (n, h * w * c) == (x, y * z * t)
        # for expr in self.allowable_exprs:
        #     if reshape_check(expr, inact.src_shape, outact.src_shape):
        #         return True
        # return False


class WhereSupportedCondition:
    def __init__(self, device: DeviceType = DeviceType.DEFAULT_DEVICE):
        self.layertype = LayerType.Where
        self.device = device

    def __call__(self, op: Operator) -> bool:
        cond, x, y = op.inacts
        return all(src_shape_and_pop_check(inact) for inact in (x, y))


class TransposeSupportedCondition:
    def __init__(self, device: DeviceType = DeviceType.DEFAULT_DEVICE):
        self.layertype = LayerType.Transpose
        self.device = device
        self.allowable_axes = [(0,) + p for p in itertools.permutations([1, 2, 3])]

    def __call__(self, op: Operator) -> bool:
        inact = op.inacts[0]
        if not src_shape_and_pop_check(inact):
            return False
        return op.options.transpose_axes in self.allowable_axes


class SoftMaxSupportedCondition:
    def __init__(self, device: DeviceType = DeviceType.DEFAULT_DEVICE):
        self.layertype = LayerType.Softmax
        self.device = device

    def __call__(self, op: Operator) -> bool:
        axis = op.options.axis
        if axis < 0:
            axis += 4
        return src_shape_dtype_check(op.inacts[0]) and axis in (1, 2, 3)


class MatmulSupportedCondition:
    def __init__(self, device: DeviceType = DeviceType.DEFAULT_DEVICE):
        self.layertype = LayerType.MatMul
        self.device = device

    def __call__(self, op: Operator):
        left, right = op.inacts
        if not (src_shape_dtype_check(left) and src_shape_dtype_check(right)):
            return False
        repeat_input, repeat_cnt = op.options.repeat
        left_src_shape = left.src_shape
        right_src_shape = right.src_shape

        if repeat_input == -1:
            # (1,32,52,64) * (1,32,64,52)
            return (
                left_src_shape[1] == right_src_shape[1]
                and left_src_shape[3] == right_src_shape[2]
            )
        elif repeat_input == 0:  # currently not supported
            return False
            # (1,8,52,64) * (1,32,64,52)
            return (
                not left_src_shape[1].dynamic
                and repeat_cnt * int(left_src_shape[1]) == right_src_shape[1]
                and left_src_shape[3] == right_src_shape[2]
            )
        elif repeat_input == 1:
            # (1,32,52,64) * (1,8,64,52)
            return (
                not right_src_shape[1].dynamic
                and left_src_shape[1] == repeat_cnt * int(right_src_shape[1])
                and left_src_shape[3] == right_src_shape[2]
            )
        else:
            raise NotImplementedError("code should not be reached!")


class PadSuppotedCondition:
    def __init__(self, device: DeviceType = DeviceType.DEFAULT_DEVICE):
        self.layertype = LayerType.Pad
        self.device = device

    def __call__(self, op: Operator):
        if not src_shape_dtype_check(op.inacts[0]):
            return False
        pad_begin = op.options.padding_list[:4]
        pad_end = op.options.padding_list[4:]
        # check is spatial padding?
        return pad_begin[0] == pad_end[0] == 0 and pad_begin[3] == pad_end[3] == 0


class ResizeSupportedCondition:
    def __init__(self, device: DeviceType = DeviceType.DEFAULT_DEVICE):
        self.layertype = LayerType.Resize
        self.device = device

    def __call__(self, op: Operator):
        if src_shape_dtype_check(op.inacts[0]):
            inact = op.inacts[0]
            outact = op.outacts[0]

            in_shape = inact.src_shape
            out_shape = outact.src_shape
            same_idx = set(
                [i for i, (a, b) in enumerate(zip(in_shape, out_shape)) if a == b]
            )
            fixed_idx = {0, 3}  # batch and channel index (NHWC)
            return fixed_idx.issubset(same_idx)
        else:
            outact = op.outacts[0]
            for cop in outact.consumer_ops:
                if is_basic_npu_op(cop):
                    return True
        return False


class ConditionallySupportedOpTable(SupportedTable):
    def __init__(self, device: DeviceType):
        super().__init__(device)
        for lt in ACTIVATION_FUNCTIONS:
            self.register(lt, PrevOpSupportedCondition(lt, self.device))
        for lt in NORMALIZATIONS:
            self.register(lt, NormalizationSupportedCondition(lt, self.device))
        self.register(LayerType.Concatenate, ConcatenateSupportedCondition(self.device))
        self.register(LayerType.Slice, SliceSupportedCondition(self.device))

        for lt in (LayerType.Adding, LayerType.Multiply, LayerType.Sub, LayerType.Div):
            self.register(lt, BiopSupportedCondition(lt, self.device))
        for lt in BIOP_ARITHMETIC_CONST:
            self.register(lt, BiopConstantSupportedCondition(lt, self.device))

        # reduce ops
        for lt in (
            LayerType.ReduceMean,
            LayerType.ReduceMax,
            LayerType.ReduceMin,
            LayerType.ReduceSum,
        ):
            self.register(lt, ReduceOpSupportedCondition(lt, self.device))
        # fmt: off
        self.register(LayerType.Reshape, ReshapeSupportedCondition(self.device))
        self.register(LayerType.Transpose, TransposeSupportedCondition(self.device))
        self.register(LayerType.Softmax, SoftMaxSupportedCondition(self.device))
        self.register(LayerType.MatMul, MatmulSupportedCondition(self.device))
        self.register(LayerType.Pad, PadSuppotedCondition(self.device))
        self.register(LayerType.Resize, ResizeSupportedCondition(self.device))
        self.register(LayerType.Where, WhereSupportedCondition(self.device))
        for lt in (
            LayerType.HeaderView,
            LayerType.HeaderViewRevert,
            LayerType.StaggeredPadding,
            LayerType.OrderedPatchify,
            LayerType.StatefulCachedStack,
            LayerType.StatefulRoPEWrapper,
            LayerType.StatefulKVCacheWrapper,
            LayerType.StatefulAttentionMaskWrapper,
            LayerType.MaskedFill,
        ):
            self.register(lt, SingleInputPopCheckCondition(lt, self.device))
        # fmt: on
