from mblt.core.util import MbltEnum


class DeviceType(MbltEnum):
    DEFAULT_DEVICE = 0  # this is not a real device
