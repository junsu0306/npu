import dataclasses
from collections import defaultdict, deque
from typing import List, Set

from mblt.core import Operator, SubGraph, LayerType, LayerOptions


@dataclasses.dataclass
class Component:
    color: int
    operators: List[Operator] = dataclasses.field(default_factory=list)
    inputs: Set[int] = dataclasses.field(
        default_factory=set
    )  # activation indices, make_input_layer flag
    outputs: Set[int] = dataclasses.field(
        default_factory=set
    )  # activation indices, make_output_layer flag
    input_components: Set[int] = dataclasses.field(default_factory=set)
    output_components: Set[int] = dataclasses.field(default_factory=set)
    idx: int = -1


def make_inout_layer(typename: str, act_idx, unsupported: bool, new_activations):
    act = new_activations[act_idx]
    opname = act.name
    options = {
        "type": typename,
        "inputs": (act_idx,),
        "outputs": (act_idx,),
        "orig_name": opname,
    }
    return Operator(
        name=opname,
        options=LayerOptions.from_dict(options),
        unsupported=unsupported,
    )


def device_bridge_option(op):
    bridge_opt = {
        "type": "DeviceBridge",
        "inputs": op.options.inputs,
        "outputs": op.options.outputs,
        "squeeze_axes": tuple(),
        "unsqueeze_axes": tuple(),
        "permute_axes": tuple(),
    }
    if op.layertype == LayerType.Transpose:
        bridge_opt["permute_axes"] = op.options.transpose_axes
        return LayerOptions.from_dict(bridge_opt)
    elif op.layertype == LayerType.Reshape:
        inact = op.inacts[0]  # 4dim
        outact = op.outacts[0]
        if inact.src_shape == outact.src_shape:
            return None
        if inact.src_dim > outact.src_dim:
            diff = inact.src_dim - outact.src_dim
            if inact.src_shape == (1,) * diff + outact.src_shape:
                bridge_opt["squeeze_axes"] = tuple(range(diff))
                return LayerOptions.from_dict(bridge_opt)
        elif inact.src_shape < outact.src_shape:
            diff = outact.src_dim - inact.src_dim
            if (1,) * diff + inact.src_shape == outact.src_shape:
                bridge_opt["unsqueeze_axes"] = tuple(range(diff))
                return LayerOptions.from_dict(bridge_opt)
    return None


class DeviceAllocator:
    def __init__(self, sg: SubGraph, make_device_bridge=True):
        self.new_activations = None
        self.sg = sg
        self.components: List[Component] = None
        self.make_device_bridge = make_device_bridge
        self.input_graphs = None
        self.output_graphs = None

    def allocate(self, use_merge_v2=True):
        self.make_components()
        self.minimize_components_topologically()

        subgraphs, graph_order = self.components_to_subgraphs()
        if self.make_device_bridge:
            self.device_bridge_post_proc(subgraphs)
        for sg in subgraphs:
            sg.sort_operators()
        return subgraphs, graph_order

    def minimize_components_topologically(self):
        if not self.components:
            return

        # 1. SCC → DAG
        self.compress_scc_preserve_color()

        # 2. DAG 위에서 병합
        self.merge_by_topology()

        # 3. 내부 I/O 정리 (기존 코드 재사용)
        for comp in self.components:
            comp_ops = set(comp.operators)

            new_inputs = set()
            for inact_idx in comp.inputs:
                producer = self.sg.activations[inact_idx].producer_op
                if producer.layertype == LayerType.Input:
                    # Component에 Input이 포함
                    if inact_idx not in self.sg.inputs:
                        raise RuntimeError("Input activation not found in graph inputs")
                    new_inputs.add(inact_idx)
                elif producer not in comp_ops:
                    # producer가 Input이라도 다른 component에 있다면 Input Layer를 추가해야 함.
                    new_inputs.add(inact_idx)
            comp.inputs = new_inputs

            new_outputs = set()
            for outact_idx in comp.outputs:
                outact = self.sg.activations[outact_idx]
                is_external = False
                for cop in outact.consumer_ops:
                    if cop.layertype == LayerType.Output:
                        if outact_idx not in self.sg.outputs:
                            raise RuntimeError(
                                "Output activation not found in graph outputs"
                            )
                        is_external = True
                        break
                    elif cop not in comp_ops:
                        is_external = True
                        break
                if is_external:
                    new_outputs.add(outact_idx)
            comp.outputs = new_outputs

    def compute_scc(self):
        n = len(self.components)
        graph = [list(c.output_components) for c in self.components]

        index = 0
        stack = []
        on_stack = [False] * n
        indices = [-1] * n
        lowlink = [0] * n
        scc_id = [-1] * n
        scc_count = 0

        def strongconnect(v):
            nonlocal index, scc_count
            indices[v] = index
            lowlink[v] = index
            index += 1
            stack.append(v)
            on_stack[v] = True

            for w in graph[v]:
                if indices[w] == -1:
                    strongconnect(w)
                    lowlink[v] = min(lowlink[v], lowlink[w])
                elif on_stack[w]:
                    lowlink[v] = min(lowlink[v], indices[w])

            if lowlink[v] == indices[v]:
                while True:
                    w = stack.pop()
                    on_stack[w] = False
                    scc_id[w] = scc_count
                    if w == v:
                        break
                scc_count += 1

        for v in range(n):
            if indices[v] == -1:
                strongconnect(v)

        return scc_id, scc_count

    def compress_scc_preserve_color(self):
        scc_id, scc_cnt = self.compute_scc()

        bucket = defaultdict(list)
        for i, comp in enumerate(self.components):
            bucket[(scc_id[i], comp.color)].append(comp)

        new_components = []
        key_to_new = {}

        for key, comps in bucket.items():
            new_comp = Component(color=key[1])

            for c in comps:
                new_comp.operators.extend(c.operators)
                new_comp.inputs.update(c.inputs)
                new_comp.outputs.update(c.outputs)

            idx = len(new_components)
            new_components.append(new_comp)
            key_to_new[key] = idx

        # rebuild edges
        for i, comp in enumerate(self.components):
            src_key = (scc_id[i], comp.color)
            src = key_to_new[src_key]

            for j in comp.output_components:
                dst_key = (scc_id[j], self.components[j].color)
                if src_key != dst_key:
                    new_components[src].output_components.add(key_to_new[dst_key])
                    new_components[key_to_new[dst_key]].input_components.add(src)

        self.components = new_components
        self._update_component_dependencies()

    def compute_levels(self):
        n = len(self.components)
        indeg = [0] * n
        for i, c in enumerate(self.components):
            for j in c.output_components:
                indeg[j] += 1

        q = deque()
        level = [0] * n

        for i in range(n):
            if indeg[i] == 0:
                q.append(i)

        while q:
            u = q.popleft()
            for v in self.components[u].output_components:
                level[v] = max(level[v], level[u] + 1)
                indeg[v] -= 1
                if indeg[v] == 0:
                    q.append(v)

        return level

    def component_signature(self, idx, level):
        comp = self.components[idx]
        return (
            level[idx],
            comp.color,
            frozenset(comp.input_components),
            frozenset(comp.output_components),
        )

    def merge_by_topology(self):

        changed = True

        while changed:
            changed = False

            level = self.compute_levels()

            buckets = defaultdict(list)
            for i in range(len(self.components)):
                buckets[level[i]].append(i)

            merged_idx = set()
            new_components = []

            for _, nodes in buckets.items():
                sig_map = defaultdict(list)
                for i in nodes:
                    sig = self.component_signature(i, level)
                    sig_map[sig].append(i)

                for group in sig_map.values():
                    if len(group) == 1:
                        new_components.append(self.components[group[0]])
                        continue

                    # merge group
                    base = Component(color=self.components[group[0]].color)
                    for idx in group:
                        c = self.components[idx]
                        base.operators.extend(c.operators)
                        base.inputs.update(c.inputs)
                        base.outputs.update(c.outputs)
                    new_components.append(base)
                    changed = True

            self.components = new_components
            self._update_component_dependencies()

    def device_bridge_post_proc(self, subgraphs):
        orig_input_names = set()
        orig_output_names = set()
        for iidx in self.sg.inputs:
            orig_input_names.add(self.sg.activations[iidx].name)
        for oidx in self.sg.outputs:
            orig_output_names.add(self.sg.activations[oidx].name)
        for sg in subgraphs:
            if not sg.unsupported:
                continue
            input_bridges = []
            output_bridges = []
            for iidx in sg.inputs:
                inact = sg.activations[iidx]
                for g_idx in self.input_graphs[sg.idx]:
                    input_graph = subgraphs[g_idx]
                    if input_graph.unsupported:
                        continue
                    # make bridge when input is from supported graph
                    for oidx in input_graph.outputs:
                        input_graph_outact = input_graph.activations[oidx]
                        if inact.name != input_graph_outact.name:
                            continue
                        if len(input_graph_outact.consumer_ops) > 1:
                            continue
                        cop = inact.consumer_ops[0]
                        bridge_opt = device_bridge_option(cop)
                        if bridge_opt:
                            cop.options = bridge_opt
                            input_bridges.append(cop)
            for oidx in sg.outputs:
                outact = sg.activations[oidx]
                for g_idx in self.output_graphs[sg.idx]:
                    output_graph = subgraphs[g_idx]
                    if output_graph.unsupported:
                        continue
                    # make bridge when output is used in supported graph
                    for iidx in output_graph.inputs:
                        output_graph_inact = output_graph.activations[iidx]
                        if outact.name != output_graph_inact.name:
                            continue
                        pop = outact.producer_op
                        bridge_opt = device_bridge_option(pop)
                        if bridge_opt:
                            pop.options = bridge_opt
                            output_bridges.append(pop)

            for output_bridge in output_bridges:
                outact = output_bridge.outacts[0]
                if 1 == len(outact.consumer_ops):
                    cop = output_bridge.outacts[0].consumer_ops[0]
                    if (
                        cop.layertype == LayerType.Output
                        and outact.name not in orig_output_names
                    ):
                        cop.valid = False
                    output_bridge.outacts[0].consumer_ops.pop(0)

            for input_bridge in input_bridges:
                inact = input_bridge.inacts[0]
                if (
                    inact.producer_op.layertype == LayerType.Input
                    and inact.name not in orig_input_names
                ):
                    inact.producer_op.valid = False
                    inact.producer_op = None

            sg.operators = [x for x in sg.operators if x.valid]
            sg.strip_unused_operators()

    def components_to_subgraphs(self):
        orig_sg = self.sg
        new_subgraphs = []
        self.input_graphs = {}
        self.output_graphs = {}
        for i, comp in enumerate(self.components):
            copied_ops = []
            new_activations = [None] * len(orig_sg.activations)
            new_tensors = [None] * len(orig_sg.tensors)
            unsupported = comp.operators[0].unsupported
            for op in comp.operators:
                if op.layertype == LayerType.Input:
                    continue
                if op.layertype == LayerType.Output:
                    continue
                op_dict = op.to_dict()
                new_op = Operator.from_dict(op_dict)
                copied_ops.append(new_op)
                for iidx in op.options.inputs:
                    old_inact = orig_sg.activations[iidx]
                    new_activations[iidx] = old_inact.copy()
                for oidx in op.options.outputs:
                    new_activations[oidx] = orig_sg.activations[oidx].copy()
                for _, tidx in op.options.iter_tensorindex():
                    old_tensor = orig_sg.tensors[tidx]
                    ts = old_tensor.copy()
                    ts.set_value(old_tensor.value)
                    new_tensors[tidx] = ts

            # subgraph의 input/output은 새로 생성함.
            for iidx in comp.inputs:
                op = make_inout_layer("Input", iidx, unsupported, new_activations)
                copied_ops.append(op)
            for oidx in comp.outputs:
                op = make_inout_layer("Output", oidx, unsupported, new_activations)
                copied_ops.append(op)

            if orig_sg.name:
                name = f"{orig_sg.name}_{i}"
            else:
                name = f"sg{i}"
            new_sg = SubGraph(
                name=name,
                idx=i,
                operators=copied_ops,
                activations=new_activations,
                tensors=new_tensors,
                inputs=list(comp.inputs),
                outputs=list(comp.outputs),
                unsupported=unsupported,
            )

            for op in new_sg.operators:
                op.set_subgraph(new_sg)
            new_sg.remove_dangling_activations()
            new_sg.remove_dangling_tensors()
            new_sg.strip_unused_operators()
            new_subgraphs.append(new_sg)
            self.input_graphs[new_sg.idx] = set(comp.input_components)
            self.output_graphs[new_sg.idx] = set(comp.output_components)
        graph_order = list(range(len(new_subgraphs)))
        return new_subgraphs, graph_order

    def _update_component_dependencies(self):
        all_op_to_comp = {}
        for i, comp in enumerate(self.components):
            for op in comp.operators:
                all_op_to_comp[op] = i

        for i, comp in enumerate(self.components):
            comp_ops = set(comp.operators)
            comp.input_components = set()
            comp.output_components = set()
            for op in comp.operators:
                for inact_idx in op.options.inputs:
                    inact = self.sg.activations[inact_idx]
                    producer = inact.producer_op
                    if (
                        producer
                        and producer.layertype != LayerType.Input
                        and producer not in comp_ops
                    ):
                        comp.input_components.add(all_op_to_comp[producer])

                for outact_idx in op.options.outputs:
                    outact = self.sg.activations[outact_idx]
                    for cop in outact.consumer_ops:
                        if cop.layertype != LayerType.Output and cop not in comp_ops:
                            comp.output_components.add(all_op_to_comp[cop])

    def make_components(self):
        parent = {op: op for op in self.sg.operators}

        def find(i):
            if parent[i] is i:
                return i
            parent[i] = find(parent[i])
            return parent[i]

        def union(i, j):
            root_i = find(i)
            root_j = find(j)
            if root_i is not root_j:
                parent[root_i] = root_j

        for op in self.sg.operators:
            for out_idx in op.options.outputs:
                out_act = self.sg.activations[out_idx]
                for cop in out_act.consumer_ops:
                    if op.unsupported == cop.unsupported:
                        union(op, cop)

        groups = defaultdict(list)
        for op in self.sg.operators:
            groups[find(op)].append(op)

        all_op_to_comp = {}
        new_components = []
        for idx, ops in enumerate(groups.values()):
            comp = Component(color=int(ops[0].unsupported), idx=idx)
            comp.operators = ops
            new_components.append(comp)
            for op in comp.operators:
                all_op_to_comp[op] = comp.idx

        # check component inputs and outputs.
        for comp in new_components:
            comp_ops = set(comp.operators)
            curr_comp_idx = comp.idx
            for op in comp.operators:
                if op.layertype == LayerType.Input:
                    continue
                for inact_idx in op.options.inputs:
                    inact = self.sg.activations[inact_idx]
                    producer = inact.producer_op
                    if producer.layertype == LayerType.Input:
                        # make_components는 coloring 직후이기 때문에 Input은 subgraph의 input이어야 함.
                        if inact_idx not in self.sg.inputs:
                            raise RuntimeError(
                                "Input activation not found in graph inputs"
                            )
                        # Input OP가 component에 있는지 여부와 상관없이 항상 input이 되어야 함.
                        comp.inputs.add(inact_idx)
                        prod_comp_idx = all_op_to_comp[producer]
                        if prod_comp_idx != curr_comp_idx:
                            comp.input_components.add(prod_comp_idx)
                    elif producer not in comp_ops:
                        comp.inputs.add(inact_idx)
                        comp.input_components.add(all_op_to_comp[producer])

                for outact_idx in op.options.outputs:
                    outact = self.sg.activations[outact_idx]
                    is_external_tensor = False
                    for cop in outact.consumer_ops:
                        if cop.layertype == LayerType.Output:
                            if outact_idx not in self.sg.outputs:
                                raise RuntimeError(
                                    "Output activation not found in graph outputs"
                                )
                            is_external_tensor = True
                        elif cop not in comp_ops:
                            is_external_tensor = True
                            comp.output_components.add(all_op_to_comp[cop])
                            # break를 하지 않아야 모든 consumer_op에 대한 component를 찾을 수 있음.
                    if is_external_tensor:
                        comp.outputs.add(outact_idx)

        self.components = new_components
