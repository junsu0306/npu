import collections

from mblt import LayerType, ModelDict
from mblt.core import SubGraph, MBLT_DEFINED_LAYERTYPE_NAMES
from mblt.logger import get_logger
from mblt.operator.opkind import STATEFUL_SEQUENTIAL_OPS

LOGGER = get_logger(__name__)


def inspect_unprocessed(subgraph: SubGraph):
    UNKNOWN_OPTYPE = collections.defaultdict(list)
    T0312 = []
    T0231 = []
    ITEM_SELECTOR = []
    EXPAND = []
    BATCHNORM = []
    UNSUPPORTED_RANK = []
    UNSUPPORTED_BATCH = []
    SLICE = []
    DIV = []
    SOFTMAX = []
    PAD_GENERIC = []
    SCATTERND = []
    EINSUM = []
    ChannelFactorSlice = []
    for op in subgraph.operators:
        if op.layertype.name not in MBLT_DEFINED_LAYERTYPE_NAMES:
            UNKNOWN_OPTYPE[op.layertype.name].append((op.name, op.options))
            continue

        if op.layertype == LayerType.Transpose:
            if op.options.transpose_axes == (0, 3, 1, 2):
                if not (
                    1 == len(op.outacts[0].consumer_ops)
                    and op.outacts[0].consumer_ops[0].layertype == LayerType.Output
                ):
                    T0312.append(op.name)
            elif op.options.transpose_axes == (0, 2, 3, 1):
                if op.outacts[0].consumer_ops:
                    cop = op.outacts[0].consumer_ops[0]
                    if cop.layertype != LayerType.MatMul:
                        T0231.append(op.name)
        elif op.layertype == LayerType.Slice:
            SLICE.append(op.name)
        elif op.layertype == LayerType.IndexedItemSelector:
            ITEM_SELECTOR.append(op.name)
        elif op.layertype == LayerType.ChannelFactorSlice:
            ChannelFactorSlice.append(op.name)
        elif op.layertype == LayerType.Batchnorm:
            BATCHNORM.append(op.name)
        elif op.layertype == LayerType.Expand:
            EXPAND.append(op.name)
        elif op.layertype == LayerType.Div:
            DIV.append(op.name)
        elif op.layertype == LayerType.ScatterND:
            SCATTERND.append(op.name)
        elif op.layertype == LayerType.Einsum:
            EINSUM.append(op.name)
        elif op.layertype == LayerType.Softmax:
            if op.inacts[0].src_dim == 4 and op.options.axis not in (-1, 3):
                SOFTMAX.append(op.name)
        elif op.layertype == LayerType.PadGeneric:
            PAD_GENERIC.append(op.name)

        for oact in op.outacts:
            if oact.src_dim != 4:
                UNSUPPORTED_RANK.append((oact.src_shape, op.layertype.name, op.name))
            if oact.src_dim == 4 and oact.src_shape[0] != 1:
                UNSUPPORTED_BATCH.append((oact.src_shape, op.layertype.name, op.name))
    result = {
        "T0312": T0312,
        "T0231": T0231,
        "UNKNOWN_OPTYPE": UNKNOWN_OPTYPE,
        "ITEM_SELECTOR": ITEM_SELECTOR,
        "BATCHNORM": BATCHNORM,
        "EXPAND": EXPAND,
        "UNSUPPORTED_RANK": UNSUPPORTED_RANK,
        "UNSUPPORTED_BATCH": UNSUPPORTED_BATCH,
        "SLICE": SLICE,
        "DIV": DIV,
        "SCATTERND": SCATTERND,
        "EINSUM": EINSUM,
        "ChannelFactorSlice": ChannelFactorSlice,
        "SOFTMAX": SOFTMAX,
        "PAD_GENERIC": PAD_GENERIC,
    }
    summary = {k: len(v) for k, v in result.items()}
    result["summary"] = summary
    return result


def _get_subgraphs_stats(subgraphs):
    op_cnt = {}
    op_ops = {}
    for idx, sg in enumerate(subgraphs):
        for op in sg.operators:
            if op.layertype not in op_cnt:
                op_cnt[op.layertype] = [0, 0]  # unsupp,supp
                op_ops[op.layertype] = 0
            if op.unsupported:
                op_cnt[op.layertype][0] += 1
            else:
                op_cnt[op.layertype][1] += 1
            try:
                op_ops[op.layertype] += int(op.get_ops_count())
            except Exception:
                pass

    rows = []
    for k, v in op_cnt.items():
        total_ops = op_ops.get(k, 0)
        supported_pct = round(v[1] / sum(v) * 100, 2)
        gops = round(total_ops / 1e9, 2)
        gmac = round(total_ops / 2e9, 2)
        rows.append([k.name, sum(v), v[0], supported_pct, gops, gmac])
    rows = sorted(rows, key=lambda x: x[0], reverse=False)
    num_all_ops = sum(sum(v) for v in op_cnt.values())
    num_all_unsupported = sum(v[0] for v in op_cnt.values())
    num_all_arith_ops = sum(op_ops.values())
    total_gops = round(num_all_arith_ops / 1e9, 2)
    total_gmac = round(num_all_arith_ops / 2e9, 2)
    coverage = round((num_all_ops - num_all_unsupported) / num_all_ops * 100, 2)
    summary = [
        "All",
        num_all_ops,
        num_all_unsupported,
        coverage,
        total_gops,
        total_gmac,
    ]
    dct = {
        "header": ["OpType", "Count", "Unsupported", "Supported(%)", "GOPS", "GMAC"],
        "rows": rows,
        "summary": summary,
        "num_subgraphs": len(subgraphs),
    }
    return dct


def format_table(header, rows, summary, header_format, row_format, title=""):
    col_sep = "|"
    format_map = {"i": "{:>{}}", "f": "{:>{}.2f}", "s": "{:<{}}"}
    header_map = {"i": "{:>{}}", "f": "{:>{}.2f}", "s": "{:^{}}"}
    row_format = [format_map[i.lower()] for i in row_format]
    header_format = [header_map[i.lower()] for i in header_format]

    table = [header] + rows + [summary]
    table_format = [header_format] + [row_format] * (len(table) - 1)
    col_widths = [0] * len(table[0])
    for row, rformat in zip(table, table_format):
        for idx, (item, item_format) in enumerate(zip(row, rformat)):
            col_widths[idx] = max(len(item_format.format(item, 0)), col_widths[idx])
    col_widths = [c + 2 for c in col_widths]

    row_sep = "+".join("-" * cw for cw in col_widths)
    tb_top_bottom = "=".join("=" * cw for cw in col_widths)

    table_width = sum(col_widths) + len(header)

    def gen_row():
        yield tb_top_bottom
        if title:
            yield "{:^{}}".format(title, table_width)
        yield tb_top_bottom
        for idx, (row, rformat) in enumerate(zip(table, table_format)):
            yield col_sep.join(
                fmt.format(cell_data, col_width)
                for fmt, cell_data, col_width in zip(rformat, row, col_widths)
            )
            if idx == 0 or idx == len(table) - 2:
                yield row_sep
        yield tb_top_bottom

    return "\n".join(gen_row())


def summarize_model_dict(md: ModelDict, stage: str = ""):
    stats = _get_subgraphs_stats(md.subgraphs)
    stats["backend"] = md.model_backend
    title = f"Summary by Operator Type"
    if stage:
        title += f"[{stage}]"
    tb = format_table(
        header=stats["header"],
        rows=stats["rows"],
        summary=stats["summary"],
        header_format="s" * len(stats["header"]),
        row_format="siiiff",
        title=title,
    )

    stateful_seq_model_sg = {}
    for sg in md.subgraphs:
        for op in sg.operators:
            if op.layertype in STATEFUL_SEQUENTIAL_OPS:
                stateful_seq_model_sg[op.options.subgraph] = -1

    for sg in md.subgraphs:
        if sg.name in stateful_seq_model_sg:
            stateful_seq_model_sg[sg.name] = sg.idx

    LOGGER.info("\n\n" + tb + "\n")

    def _get_act_info_str(act_name):
        for sg in md.subgraphs:
            for act in sg.activations:
                if act.name == act_name:
                    name = act.name
                    src_shape = str(act.src_shape).replace(" ", "")
                    dataformat = act.dataformat.name
                    origin_name = md.get_act_origin_name(act.name, "")
                    return f"name: {name}, src_shape: {src_shape}, dataformat: {dataformat}, origin_name: {origin_name}"
        raise ValueError(f"Cannot find activation {act_name}")

    model_inputs = []
    for x in md.inputs:
        model_inputs.append(_get_act_info_str(x))
    model_outputs = []
    for x in md.outputs:
        model_outputs.append(_get_act_info_str(x))

    msg = [
        f"Number of Subgraphs: {stats['num_subgraphs']}",
        f"graph order: {md.graph_order}",
        f"stateful_lstm_subgraphs: {dict((v, k) for k, v in stateful_seq_model_sg.items())}",
        # f"num ops: To be implemented.",
        f"backend: {stats['backend']}",
        f"model inputs: {model_inputs}",
        f"model outputs: {model_outputs}",
    ]
    LOGGER.info("[parser]\n" + "\n".join(msg))
    LOGGER.info("outputs:")
