from __future__ import annotations

import dataclasses
from typing import List, Optional, Tuple, Sequence

import mblt.core._optionsimpl as layer_options
from mblt.core import (
    Operator,
    LayerOptions,
    ActivationSpec,
    LayerType,
    TensorSpec,
    SubGraph,
    OperatorTransformResult,
    OpTransformResultBuilder,
    replace_options,
    OptionsRegistry,
    int32,
)
from mblt.logger import get_logger
from mblt.subgraph import MbltSubGraphBuilder

LOGGER = get_logger(__name__)


__all__ = [
    "OpTransformResultV2Builder",
    "RemoveIdentityResult",
    "OpTransformResultV2",
    "RemoveIdentityResultBuilder",
    "RemoveIdentitySequenceResult",
]

_DEBUG_MODE = False
_USE_SINGLTON_CONNECTION_OP = False


@OptionsRegistry.register(LayerType._CONNECTION_OP)
@dataclasses.dataclass
class _ConnectionOpOptions(LayerOptions):
    inputs: Tuple[int32, ...]
    outputs: Tuple[int32, ...]


class _CONNOp(Operator):
    def __init__(self, name: str):
        super().__init__(name, options=_ConnectionOpOptions((-1,), (-1,)))
        self.maps = {}  # (input_idx, output_idx)
        self.exclude_from_transform = True
        self.valid = True  # this is intentional to allow consumer_ops=[x for x in ops if x.valid]
        self._initialized = True
        self.connection_chain = {}  # (curr, head)
        self._is_connection_op = True

    def __repr__(self):
        return f"_CONNOp({self.name}, num_maps={len(self.maps)})"

    def inacts(self):
        raise RuntimeError("should not be called")

    def outacts(self):
        raise RuntimeError("should not be called")

    def add_map(self, input_idx, output_idx):
        if input_idx not in self.connection_chain:
            self.connection_chain[output_idx] = input_idx
        else:
            while input_idx in self.connection_chain:
                input_idx = self.connection_chain[input_idx]
            self.connection_chain[output_idx] = input_idx
        if input_idx not in self.maps:
            self.maps[input_idx] = [output_idx]
        else:
            if output_idx not in self.maps[input_idx]:
                self.maps[input_idx].append(output_idx)

    def clear_maps(self):
        self.maps.clear()
        self.connection_chain.clear()


class OpTransformResultV2Builder(MbltSubGraphBuilder, OpTransformResultBuilder):
    _activation_cls = ActivationSpec

    def __init__(self, builder_name=""):
        super().__init__()
        if not builder_name:
            builder_name = "OpTransformResultV2Builder"
        self.builder_name = builder_name
        self._input_map = []
        self._output_map = []
        self._invalidate_ops = []

    def copy_activationspec(
        self,
        x: ActivationSpec,
        name: str = None,
        dtype: str = None,
        src_shape=None,
        dataformat=None,
        add_input_map=False,
        **kwargs,
    ):
        # src_shape can be an empty tuple
        src_shape = src_shape if src_shape is not None else x.src_shape
        copied = ActivationSpec(
            name=name or x.name,
            dtype=dtype or x.dtype,
            src_shape=src_shape,
            dataformat=dataformat or x.dataformat,
        )
        self.add_activation(copied)
        if add_input_map:
            self.add_input_map(copied, x)
        return copied

    def build(self, **kwargs) -> OpTransformResultV2:
        self.update_internal_connectivity()
        return OpTransformResultV2(
            self._invalidate_ops,
            self.operators,
            self._input_map,
            self._output_map,
            self.activations,
            self.tensors,
        )

    def add_invalidate_ops(self, *ops):
        unique = tuple(
            o for o in ops if o is not None and o not in self._invalidate_ops
        )
        self._invalidate_ops.extend((o for o in unique))

    def add_input_map(
        self,
        internal_act: ActivationSpec,
        external_act: ActivationSpec,
    ):
        self._input_map.append(TransformActivationMapping(internal_act, external_act))

    def add_output_map(
        self,
        internal_act: ActivationSpec,
        external_act: ActivationSpec,
    ):
        self._output_map.append(TransformActivationMapping(internal_act, external_act))

    def remove_connectivity_and_invalidate(self, *ops: Operator):
        # only works for a sequence of operators
        sg = ops[0].subgraph
        if not isinstance(sg, SubGraph):
            raise Exception(f"sg is not SubGraph: got = {type(sg)}")
        self.add_invalidate_ops(ops[-1])
        if len(ops) == 1:
            last_op = ops[-1]
            for iidx in last_op.options.inputs:
                inact = sg.activations[iidx]
                inact.consumer_ops = [
                    cop for cop in inact.consumer_ops if cop is not last_op
                ]
            return
        assert len(ops) > 1, f"len(ops) > 1 but got len(ops)={len(ops)}"
        for i in range(len(ops) - 1, 0, -1):
            next_op = ops[i]
            op = ops[i - 1]
            outact = sg.activations[op.options.outputs[0]]
            outact.consumer_ops = [
                cop for cop in outact.consumer_ops if cop is not next_op
            ]
            if not outact.consumer_ops:
                self.add_invalidate_ops(op)
            else:
                break


class RemoveIdentityResultBuilder:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        cls._instance._original_op = None
        return cls._instance

    def set_original_op(self, op: Operator):
        self._original_op = op
        return self

    def build(self) -> RemoveIdentityResult:
        if self._original_op is None:
            raise ValueError("original_op must be set before calling build()")
        return RemoveIdentityResult(self._original_op)


class TransformActivationMapping:
    def __init__(self, internal_act: ActivationSpec, external_act: ActivationSpec):
        if internal_act.src_shape != external_act.src_shape:
            raise ValueError(
                f"shape mismatch! {internal_act.src_shape}!= {external_act.src_shape}"
            )
        self.internal_act = internal_act
        self.external_act = external_act


def _get_connection_op(subgraph: SubGraph, inact_idx: int, outact_idx: int):
    inact = subgraph.activations[inact_idx]
    outact = subgraph.activations[outact_idx]
    if inact.src_shape != outact.src_shape:
        raise ValueError(
            f"shape does not match! {inact.src_shape}!= {outact.src_shape}"
        )
    if _USE_SINGLTON_CONNECTION_OP:
        conn_op = getattr(subgraph, "_connection_op", None)
        if conn_op is None:
            conn_op = _CONNOp(f"{subgraph.name}_connection")
            subgraph._connection_op = conn_op
        conn_op.add_map(inact_idx, outact_idx)
        LOGGER.debug(
            f"conn_op({id(conn_op)}): add_map({inact_idx}, {outact_idx}), len={len(conn_op.maps)})"
        )
    else:
        conn_op = Operator(
            name=outact.name,
            options=layer_options.IdentityOptions(
                inputs=(inact_idx,), outputs=(outact_idx,)
            ),
        )
    conn_op.set_subgraph(subgraph)
    if conn_op not in inact.consumer_ops:
        inact.consumer_ops.append(conn_op)
    outact.producer_op = conn_op
    return conn_op


class OpTransformResultV2(OperatorTransformResult):

    def __init__(
        self,
        invalidate_ops,
        generated_ops,
        input_map,
        output_map,
        activations,
        tensors,
        make_node_group=False,
    ):
        self.invalidate_ops = invalidate_ops
        self.generated_ops = generated_ops
        self.input_map: List[TransformActivationMapping] = input_map
        self.output_map: List[TransformActivationMapping] = output_map
        # all activations should be new.
        self.activations: List[ActivationSpec] = activations
        # remind that tensor is uniquely identified with its name in weight_dict.
        self.tensors: List[TensorSpec] = tensors
        self.make_node_group = make_node_group

    def apply_to_subgraph(
        self, target_sg: SubGraph, visitors: Optional[List] = None
    ) -> None:
        for op in self.invalidate_ops:
            op.set_invalid()
        # (local_idx, idx_in_target_sg)
        act_idx_map = {}
        for idx, act in enumerate(self.activations):
            act_idx_map[idx] = target_sg.add_activation(act)
            if _DEBUG_MODE:
                LOGGER.debug(f"[NEW ACT]: {act}")

        # reverse map: (idx_in_target_sg -> local_idx)
        rev_act_idx_map = {v: k for k, v in act_idx_map.items()}

        ts_idx_map = {i: target_sg.add_tensor(ts) for i, ts in enumerate(self.tensors)}
        # update
        for op in self.generated_ops:
            # map activation indices using immutable replace to avoid in-place tuple mutation
            new_inputs = tuple(act_idx_map[x] for x in op.options.inputs)
            new_outputs = tuple(act_idx_map[x] for x in op.options.outputs)
            replace_kwargs = {"inputs": new_inputs, "outputs": new_outputs}
            # map tensor indices if any are present
            if ts_idx_map:
                for k, v in op.options.iter_tensorindex():
                    if v != -1:
                        replace_kwargs[k] = ts_idx_map[v]
            op.options = replace_options(op.options, **replace_kwargs)
            op.set_subgraph(target_sg)

        if visitors is not None:
            for visitor in visitors:
                visitor.visit(self)
        self._add_operators_to_subgraph(target_sg)

    def _add_operators_to_subgraph(self, target_sg: SubGraph):
        if _USE_SINGLTON_CONNECTION_OP:
            conn_op = None
            if self.input_map:
                conn_op = tuple(self._update_input_connectivity(target_sg))[-1]
            target_sg.operators.extend(self.generated_ops)
            if self.output_map:
                conn_op = tuple(self._update_output_connectivity(target_sg))[-1]
            assert conn_op is not None, "conn_op is None"
            target_sg._connection_op = conn_op
        else:
            target_sg.operators.extend(self._update_input_connectivity(target_sg))
            target_sg.operators.extend(self.generated_ops)
            target_sg.operators.extend(self._update_output_connectivity(target_sg))

    def _update_input_connectivity(self, target_sg: SubGraph):
        processed = set()
        for x in self.input_map:
            conn_inact = x.external_act  # act in target_sg
            conn_outact = x.internal_act  # new act
            if conn_inact.name == conn_outact.name:
                raise ValueError(
                    f"conn_inact.name == conn_outact.name, value={conn_inact.name}"
                )
            if conn_inact.has_value:
                conn_outact.set_value(conn_inact.value)
            conn_inact_idx = target_sg.get_activation_index(conn_inact)
            conn_outact_idx = target_sg.get_activation_index(conn_outact)
            # to avoid repeated reshape generation in one-to-many case
            if (conn_inact_idx, conn_outact_idx) not in processed:
                if _DEBUG_MODE:
                    LOGGER.debug(
                        f"[CONN IN] old={conn_inact.name}, new={conn_outact.name}"
                    )
                connection_op = _get_connection_op(
                    target_sg, conn_inact_idx, conn_outact_idx
                )
                processed.add((conn_inact_idx, conn_outact_idx))
                conn_inact.consumer_ops = [
                    io for io in conn_inact.consumer_ops if io.valid
                ]  # 여기서 미리미리 지워야 에러가 적음.
                yield connection_op

    def _update_output_connectivity(self, target_sg: SubGraph):
        for x in self.output_map:
            conn_inact = x.internal_act  # new_act
            conn_outact = x.external_act  # in target_sg
            if conn_outact.has_value:
                conn_inact.set_value(conn_outact.value)
            conn_inact_idx = target_sg.get_activation_index(conn_inact)
            conn_outact_idx = target_sg.get_activation_index(conn_outact)
            if conn_inact_idx == conn_outact_idx:
                raise ValueError(
                    f"conn_inact_idx({conn_inact_idx}) == conn_outact_idx{conn_outact_idx}"
                )
            if _DEBUG_MODE:
                LOGGER.debug(
                    f"[CONN OUT] new={conn_inact.name}, old={conn_outact.name}"
                )
            connection_op = _get_connection_op(
                target_sg, conn_inact_idx, conn_outact_idx
            )
            yield connection_op


class RemoveIdentityResult(OperatorTransformResult):
    def __init__(self, original_op: Operator):
        self.original_identity_op = original_op

    def apply_to_subgraph(
        self, target_sg: SubGraph, visitors: Optional[List] = None
    ) -> None:
        if _USE_SINGLTON_CONNECTION_OP:
            # Without this explicit case handling, the activations registered in _CONNOp would be
            # invalidated by the `else` branch logic, potentially breaking the graph connectivity.
            self.original_identity_op.set_invalid()
            inact_idx = self.original_identity_op.options.inputs[0]
            outact_idx = self.original_identity_op.options.outputs[0]
            conn_op = _get_connection_op(target_sg, inact_idx, outact_idx)
        else:
            self.original_identity_op.set_invalid()
            inact_idx = self.original_identity_op.options.inputs[0]
            inact = target_sg.activations[inact_idx]
            outact_idx = self.original_identity_op.options.outputs[0]
            outact = target_sg.activations[outact_idx]
            # remove this op from input activation
            inact.consumer_ops = [x for x in inact.consumer_ops if x.valid]
            # update input indices of next operators
            for next_op in outact.consumer_ops:
                new_inputs = tuple(
                    inact_idx if iidx == outact_idx else iidx
                    for iidx in next_op.options.inputs
                )
                if next_op.layertype == LayerType.Output:
                    next_op.options = replace_options(
                        next_op.options, inputs=new_inputs, outputs=new_inputs
                    )
                else:
                    next_op.options = replace_options(
                        next_op.options, inputs=new_inputs
                    )
                inact.consumer_ops.append(next_op)
            outact.producer_op = None
            if visitors is not None:
                for visitor in visitors:
                    visitor.visit(self)


class RemoveIdentitySequenceResult(OperatorTransformResult):
    def __init__(self, identity_seq: Sequence[Operator]):
        self.identity_seq = identity_seq

    def apply_to_subgraph(
        self, target_sg: SubGraph, visitors: Optional[List] = None
    ) -> None:
        first_op = self.identity_seq[0]
        last_op = self.identity_seq[-1]

        inact_idx = first_op.options.inputs[0]
        outact_idx = last_op.options.outputs[0]
        inact = target_sg.activations[inact_idx]
        outact = target_sg.activations[outact_idx]

        invalid_outacts = []
        for op in self.identity_seq:
            invalid_outacts.append(op.options.outputs[0])
            op.set_invalid()

        # remove sequence from input activation
        inact.consumer_ops = [x for x in inact.consumer_ops if x.valid]

        # update input indices of next operators
        for next_op in outact.consumer_ops:
            new_inputs = tuple(
                inact_idx if iidx == outact_idx else iidx
                for iidx in next_op.options.inputs
            )
            if next_op.layertype == LayerType.Output:
                next_op.options = replace_options(
                    next_op.options, inputs=new_inputs, outputs=new_inputs
                )
            else:
                next_op.options = replace_options(next_op.options, inputs=new_inputs)
            inact.consumer_ops.append(next_op)

        for x in invalid_outacts:
            x.producer_op = None

        if visitors is not None:
            for visitor in visitors:
                visitor.visit(self)
