from __future__ import annotations

import abc
import collections
import itertools
import time
from typing import List, Optional, Tuple, Dict, TypeVar

from mblt.core import (
    LayerType,
    TransformRule,
    OperatorTransformResult_T,
    SubGraph,
    Operator,
    TRANSFORM_RULE_TARGET_LAYERTYPE_NAMES,
    replace_options,
)
from mblt.logger import get_logger
from .ruleset.cse import SimpleCSE
from .transform_result import OpTransformResultV2

LOGGER = get_logger(__name__)


_DEBUG_MODE = False


def _set_debug_mode(mode: bool):
    _DEBUG_MODE = mode
    if _DEBUG_MODE:
        LOGGER.setLevel("DEBUG")
    else:
        LOGGER.setLevel("INFO")


class _ActivationTrace(abc.ABC):
    __slots__ = ("name", "src_shape")

    def __init__(self, name: str, src_shape: Tuple[int, ...]):
        self.name = name
        self.src_shape = src_shape

    def __repr__(self):
        t = "org" if self.trace_type == 0 else "gen"
        return f"[{t}]{self.name}"

    def __eq__(self, other):
        if not other:
            return False
        return self.trace_type == other.trace_type and self.name == other.name

    @property
    @abc.abstractmethod
    def trace_type(self):
        """
        0: from the model
        1: generated
        """


class ActTraceT0(_ActivationTrace):
    @property
    def trace_type(self):
        return 0


class ActTraceT1(_ActivationTrace):
    @property
    def trace_type(self):
        return 1


ActTrace_T = TypeVar("ActTrace_T", ActTraceT0, ActTraceT1)


class ActivationTracer:
    """
    tracing activations by their name.
    """

    def __init__(self, sg: SubGraph):
        # (act name, (parent act name, flag)). if act_name == parent_act_name then this activation is original one from the loaded model.
        self.act_trace: Dict[str, ActTrace_T] = {
            act.name: ActTraceT0(act.name, act.src_shape) for act in sg.activations
        }
        # reverse activation index map per transform result node
        # stores mapping: (idx_in_target_sg -> local_idx_in_node)
        self._rev_act_idx_map: Dict[OpTransformResultV2, Dict[int, int]] = {}

    def register_index_map(
        self, node: OpTransformResultV2, rev_index_map: Dict[int, int]
    ):
        """Register reverse activation index map for a transform result node.

        rev_index_map maps indices in the target SubGraph to local indices used inside the node.
        """
        self._rev_act_idx_map[node] = rev_index_map

    def get(self, name, default: ActTrace_T | None = None):
        return self.act_trace.get(name, default)

    def _visit_op_transform_result(self, node: OpTransformResultV2):
        _PROPAGATE_TYPES = (LayerType.Transpose, LayerType.Reshape)
        processed_names = set()  # processed in current session
        rev_map = self._rev_act_idx_map.get(node)
        if rev_map is None:
            # Without reverse index map, we cannot safely trace by indices; fallback to no propagation.
            rev_map = {}
        for item in itertools.chain(node.input_map, node.output_map):
            if item.external_act.name in self.act_trace:
                self.act_trace[item.internal_act.name] = self.act_trace[
                    item.external_act.name
                ]
            else:
                self.act_trace[item.internal_act.name] = ActTraceT1(
                    item.external_act.name, item.external_act.src_shape
                )
            processed_names.add(item.internal_act.name)

        def propagate_fwd(cop, trace, op_names):
            q = collections.deque()
            q.append(cop)
            while q:
                cop = q.popleft()
                local_idx = rev_map.get(cop.options.outputs[0])
                if local_idx is None:
                    continue
                outact = node.activations[local_idx]
                if outact.name in processed_names:
                    continue
                self.act_trace[outact.name] = trace
                for c in outact.consumer_ops:
                    if c.layertype in _PROPAGATE_TYPES and c.name in op_names:
                        q.append(c)

        def propagate_bwd(pop, trace, op_names):
            q = collections.deque()
            q.append(pop)
            while q:
                pop = q.popleft()
                local_idx = rev_map.get(pop.options.inputs[0])
                if local_idx is None:
                    continue
                inact = node.activations[local_idx]
                if inact.name in processed_names:
                    continue
                self.act_trace[inact.name] = trace
                if (
                    inact.producer_op.layertype in _PROPAGATE_TYPES
                    and inact.producer_op.name in op_names
                ):
                    q.append(inact.producer_op)

        # propagate references.
        op_names = set(op.name for op in node.generated_ops)
        for item in node.input_map:
            for cop in item.internal_act.consumer_ops:
                if cop.layertype in _PROPAGATE_TYPES:
                    propagate_fwd(cop, self.act_trace[item.internal_act.name], op_names)
        for item in node.output_map:
            if (pop := item.internal_act.producer_op).layertype in _PROPAGATE_TYPES:
                propagate_bwd(pop, self.act_trace[item.internal_act.name], op_names)

    def visit(self, node: OperatorTransformResult_T):
        if isinstance(node, OpTransformResultV2):
            self._visit_op_transform_result(node)


def _exclude_nonconforming_op(op):
    return (op.options.inputs and 0 in op.inacts[0].src_shape) or (
        op.options.outputs and 0 in op.outacts[0].src_shape
    )


def remove_connection_op(sg: SubGraph):
    connection_op = getattr(sg, "_connection_op", None)
    if connection_op is None:
        return
    remove_lst = []
    cleared_outact = set()
    for in_idx, output_indices in connection_op.maps.items():
        inact = sg.activations[in_idx]
        inact.consumer_ops = [
            x for x in inact.consumer_ops if x.name != connection_op.name and x.valid
        ]
        for out_idx in output_indices:
            outact = sg.activations[out_idx]
            # connection_op map에서 outact가 중복될 수 있음.
            if outact.name in cleared_outact:
                continue
            if outact.producer_op.layertype != LayerType._CONNECTION_OP:
                raise Exception(
                    f"outact is not connection op. {outact.producer_op.layertype.name}, {outact.name}"
                )
            # update input indices of next operators
            for next_op in outact.consumer_ops:
                new_inputs = tuple(
                    in_idx if iidx == out_idx else iidx
                    for iidx in next_op.options.inputs
                )
                if next_op.layertype == LayerType.Output:
                    next_op.options = replace_options(
                        next_op.options, inputs=new_inputs, outputs=new_inputs
                    )
                else:
                    next_op.options = replace_options(
                        next_op.options, inputs=new_inputs
                    )
                inact.consumer_ops.append(next_op)
                if _DEBUG_MODE:
                    remove_lst.append((inact, outact, next_op))
            if _DEBUG_MODE:
                LOGGER.debug(
                    f"invalidate outact {outact.name} {outact.producer_op.layertype}"
                )
            outact.producer_op = None
            cleared_outact.add(outact.name)
    if _DEBUG_MODE:
        cnt = len(connection_op.maps)
        LOGGER.debug(f"============ [REMOVE CONNECTION ({cnt})] ============")
        for item in remove_lst:
            inact, outact, next_op = item
            if inact.producer_op is None:
                if inact.name not in cleared_outact:
                    raise Exception(
                        f"inact is not cleared but has no producer_op. {inact.name}"
                    )
            else:
                LOGGER.debug(
                    f"  {inact.producer_op.layertype.name}[{inact.name}] -> {outact.name}, {next_op.layertype.name}[{next_op.name}]"
                )
    connection_op.clear_maps()


class OptState:
    __slots__ = ("stage", "cnt", "stage_to_stop", "cnt_to_stop")

    def __init__(self, stage=None, cnt=0, last_stage=None, last_cnt=0):
        self.stage = stage
        self.cnt = cnt
        self.stage_to_stop = last_stage
        self.cnt_to_stop = last_cnt

    def is_stop(self):
        return (
            self.stage_to_stop is not None
            and self.stage >= self.stage_to_stop
            and self.cnt >= self.cnt_to_stop
        )


class OperatorGraphTransform:
    def __init__(self, rules: List[TransformRule]):
        self.rules: List[TransformRule] = rules
        self._disabled_rules = set()

    def _is_release_mode(self, **kwargs) -> bool:
        return kwargs.get("compilation_mode") == "release"

    def _disable_rule_on_error(self, rule, op, phase: str, exc: Exception):
        self._disabled_rules.add(rule)
        rule.clear_result()
        LOGGER.warning(
            f"release mode: disabling rule after {phase} error. "
            f"rule={rule}, op={op.name}, why={exc}"
        )

    def _is_timeout(self, **kwargs) -> bool:
        deadline = kwargs.get("transform_deadline_s")
        return deadline is not None and time.monotonic() >= deadline

    def _log_timeout(self, opt_state: Optional[OptState]):
        stage = None if opt_state is None else opt_state.stage
        cnt = None if opt_state is None else opt_state.cnt
        LOGGER.warning(
            f"release mode: transform timeout reached, "
            f"skipping remaining transforms in stage={stage}, cnt={cnt}"
        )

    def _pre_proc(self, sg: SubGraph):
        for op in sg.operators:
            op.valid = True
        sg.init_all_act_tensor_names()

    def _match(self, op: Operator, *args, **kwargs) -> Optional[TransformRule]:
        for rule in self.rules:
            rule.clear_result()
            if rule.check(op, **kwargs):
                return rule
        return None
        # release_mode = self._is_release_mode(**kwargs)
        # for rule in self.rules:
        #     if rule in self._disabled_rules:
        #         continue
        #     rule.clear_result()
        #     try:
        #         if rule.check(op, **kwargs):
        #             return rule
        #     except Exception as exc:
        #         if not release_mode:
        #             raise
        #         self._disable_rule_on_error(rule, op, "check", exc)
        # return None

    def process(
        self,
        sg: SubGraph,
        activation_tracer: ActivationTracer = None,
        opt_state: Optional[OptState] = None,
        **kwargs,
    ) -> bool:
        """returns if graph is changed."""

        for op in sg.operators:
            # we cannot check the following condition by `op.layertype in ORIG_LAYERTYPE` since they are different instances.
            if op.layertype.name not in TRANSFORM_RULE_TARGET_LAYERTYPE_NAMES:
                op.exclude_from_transform = True

        self._pre_proc(sg)

        val_ret = False
        is_loop = True

        debug = kwargs.get("debug", False)
        _set_debug_mode(debug)
        release_mode = self._is_release_mode(**kwargs)

        while is_loop:
            if release_mode and self._is_timeout(**kwargs):
                self._log_timeout(opt_state)
                break
            is_loop = False
            # cse
            sg.update_connectivity()
            SimpleCSE().process(sg, **kwargs)
            self._remove_invalid_ops(sg)
            if release_mode and self._is_timeout(**kwargs):
                self._log_timeout(opt_state)
                break

            # rules
            sg.update_connectivity()
            lst = sg.operators.copy()
            for k, op in enumerate(lst):
                if release_mode and self._is_timeout(**kwargs):
                    self._log_timeout(opt_state)
                    break
                if (
                    (not op.valid)
                    or op.exclude_from_transform
                    or _exclude_nonconforming_op(op)
                ):
                    continue
                rule = self._match(op, **kwargs)
                if rule is not None:
                    LOGGER.debug(
                        f"[{opt_state.stage}:{opt_state.cnt}]\t{rule}, op={op.name}"
                    )
                    res = rule.transform(op, **kwargs)
                    res.apply_to_subgraph(sg)
                    # try:
                    #     res = rule.transform(op, **kwargs)
                    #     res.apply_to_subgraph(sg)
                    # except Exception as exc:
                    #     if not release_mode:
                    #         raise
                    #     self._disable_rule_on_error(rule, op, "transform", exc)
                    #     self._remove_invalid_ops(sg)
                    #     sg.update_connectivity()
                    #     if release_mode and self._is_timeout(**kwargs):
                    #         self._log_timeout(opt_state)
                    #         is_loop = False
                    #         break
                    #     continue
                    if activation_tracer:
                        res.accept(activation_tracer)
                    is_loop = True
                    val_ret = True
                    self._remove_invalid_ops(sg)
                    sg.update_connectivity()
                    if release_mode and self._is_timeout(**kwargs):
                        self._log_timeout(opt_state)
                        is_loop = False
                        break
                    if opt_state.is_stop():
                        is_loop = False
                        break
                    opt_state.cnt += 1
            else:
                self._remove_invalid_ops(sg)
                continue
            self._remove_invalid_ops(sg)

        return val_ret

    def _remove_invalid_ops(self, sg):
        remove_connection_op(sg)
        sg.operators = [op for op in sg.operators if op.valid]
