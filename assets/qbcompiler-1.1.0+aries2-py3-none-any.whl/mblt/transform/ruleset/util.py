from mblt import Operator, LayerType
from ..transform_result import OpTransformResultV2Builder


def simple_swap(op: Operator, op_next: Operator):
    """swap two simple singleops. for exmaple tranpose0312 and actfunc."""
    builder = OpTransformResultV2Builder()
    old_inact = op.inacts[0]
    int_act = op.outacts[0]
    kw = {}
    if op.layertype == LayerType.Transpose and op_next.layertype == LayerType.Softmax:
        axis = op_next.options.axis
        new_axis = op.options.transpose_axes[axis]
        kw["axis"] = new_axis
    old_outact = op_next.outacts[0]
    new_outact = builder.copy_activationspec(old_inact, add_input_map=True)
    new_outact = builder.with_new_input_and_options(op_next, new_outact, **kw)
    new_outact = builder.with_new_input_and_options(op, new_outact)
    builder.add_output_map(new_outact, old_outact)
    builder.remove_connectivity_and_invalidate(op, op_next)
    return builder.build()


def make_identity(inact, outact, operator_seq):
    builder = OpTransformResultV2Builder()
    new_inact = builder.copy_activationspec(inact, add_input_map=True)
    new_outact = builder.make_identity(new_inact)
    builder.add_output_map(new_outact, outact)
    builder.remove_connectivity_and_invalidate(*operator_seq)
    return builder.build()
