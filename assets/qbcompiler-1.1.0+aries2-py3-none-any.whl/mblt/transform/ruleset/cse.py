import collections

import numpy

from mblt.core import SubGraph, Operator, LayerType, TensorIndex
from mblt.logger import get_logger
from mblt.operator.opkind import ACTIVATION_FUNCTIONS, MBLT_SPECIAL_OPS
from mblt.subgraph.util.pattern_util import is_biop_wrapper, is_biop_const
from mblt.transform.transform_result import OpTransformResultV2Builder

LOGGER = get_logger(__name__)

_SIMPLE_OP_CSE_TARGETS = (
    ACTIVATION_FUNCTIONS
    | MBLT_SPECIAL_OPS
    | {
        LayerType.Transpose,
        LayerType.Slice,
        LayerType.Resize,
        LayerType.Reshape,
    }
    | {
        LayerType.Cast,
        LayerType.Concatenate,
    }
)

_OP_WITH_TENSORS = frozenset(
    {
        LayerType.Convolution,
        LayerType.DepthwiseConvolution,
        LayerType.GroupConvolution,
        LayerType.TransposeConvolution,
        LayerType.LayerNormalization,
        LayerType.RmsNormalization,
        LayerType.Batchnorm,
        LayerType.IndexedItemSelector,
    }
)


def make_key_simple(op: Operator):
    if op.layertype in (LayerType.MultiplyConstant, LayerType.AddingConstant):
        return op.layertype, True
    elif op.layertype in (LayerType.DivConstant, LayerType.SubConstant):
        return op.layertype, op.options.is_const_first
    elif is_biop_wrapper(op):
        return op.layertype, op.options.inputs
    elif op.layertype == LayerType.Concatenate:
        return op.layertype, op.options.inputs

    def gen():
        yield op.layertype
        for f in sorted(op.options.__dataclass_fields__):
            if f == "outputs":
                continue
            obj = getattr(op.options, f)
            yield obj

    return tuple(gen())


def make_key_simple_with_tensors(op: Operator):
    tensor_keys = []

    def gen():
        yield op.layertype
        for f in sorted(op.options.__dataclass_fields__):
            if f == "outputs":
                continue
            if isinstance(getattr(op.options, f), TensorIndex):
                tensor_keys.append(f)
                continue
            obj = getattr(op.options, f)
            yield obj

    return tuple(gen()), tensor_keys


def build_single_output_case(dct):
    builder = OpTransformResultV2Builder()
    changed = False
    for k, v in dct.items():
        if len(v) <= 1:
            continue
        LOGGER.debug(f"CSE: {k}, {v}")
        changed = True
        remain_op, remove_ops = v[0], v[1:]
        remain_op_outact = remain_op.outacts[0]
        new_inact = builder.copy_activationspec(remain_op_outact, add_input_map=True)
        for rop in remove_ops:
            old_outact = rop.outacts[0]
            new_outact = builder.make_identity(new_inact)
            builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(*remove_ops)
    if changed:
        return builder.build()
    return None


class SimpleCSE:

    def process(self, sg: SubGraph, *args, **kwargs):
        groups = {}
        is_considered_biop = set()

        for act in sg.activations:
            if (
                act.producer_op is None
                or not act.producer_op.valid
                or len(act.consumer_ops) <= 1
            ):
                continue
            group_loc = collections.defaultdict(list)
            for cop in act.consumer_ops:
                if not cop.valid:
                    continue
                if cop.layertype in _SIMPLE_OP_CSE_TARGETS:
                    group_loc[make_key_simple(cop)].append(cop)
                elif is_biop_const(cop):
                    base_key = make_key_simple(cop)
                    val = cop.get_tensor(cop.options.constant).value
                    is_appended = False
                    for key in group_loc.keys():
                        if isinstance(key, tuple) and key[0] != base_key:
                            continue
                        op_key = group_loc[key][0]
                        val_from_key = op_key.get_tensor(op_key.options.constant).value
                        if numpy.allclose(val, val_from_key):
                            group_loc[key].append(cop)
                            is_appended = True
                            break
                    if not is_appended:
                        group_loc[(base_key, id(cop))].append(cop)
                elif is_biop_wrapper(cop):
                    key = make_key_simple(cop)
                    if cop.name not in is_considered_biop:  # biop is considered twice.
                        group_loc[key].append(cop)
                        is_considered_biop.add(cop.name)
                elif cop.layertype in _OP_WITH_TENSORS:
                    # fixme: do this for all optypes with tensorindex.
                    base_key, tensor_keys = make_key_simple_with_tensors(cop)

                    def check_vals(key):
                        op_key = group_loc[key][0]
                        for tk in tensor_keys:
                            ti_key = getattr(op_key.options, tk)
                            val_from_key = (
                                None
                                if ti_key == -1
                                else op_key.get_tensor(ti_key).value
                            )
                            ti_cop = getattr(cop.options, tk)
                            vals_from_cop = (
                                None if ti_cop == -1 else cop.get_tensor(ti_cop).value
                            )
                            if (val_from_key is not None and vals_from_cop is None) or (
                                val_from_key is None and vals_from_cop is not None
                            ):
                                return False
                            if val_from_key is not None and vals_from_cop is not None:
                                if (
                                    val_from_key.shape != vals_from_cop.shape
                                    or not numpy.allclose(val_from_key, vals_from_cop)
                                ):
                                    return False
                        return True

                    is_appended = False
                    for key in group_loc.keys():
                        if isinstance(key, tuple) and key[0] != base_key:
                            continue
                        if check_vals(key):
                            group_loc[key].append(cop)
                            is_appended = True
                            break
                    if not is_appended:
                        group_loc[(base_key, id(cop))].append(cop)

            for k, v in group_loc.items():
                if len(v) > 1:
                    groups[k] = v

        build_res = build_single_output_case(groups)
        if build_res is not None:
            build_res.apply_to_subgraph(sg)
            return True
        return False
