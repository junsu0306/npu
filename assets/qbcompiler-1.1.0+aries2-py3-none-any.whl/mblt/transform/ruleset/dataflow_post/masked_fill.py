from mblt import Operator, LayerType
from mblt.core import TransformRule, pattern
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
)
from mblt.transform.transform_result import (
    OpTransformResultV2Builder,
)
from ._ruleset import ReplaceMaskedFillRuleSet


@ReplaceMaskedFillRuleSet.register
class Maskedfill(TransformRule):
    @pattern
    def case_value0(self, op: Operator, **kwargs):
        """
        if value is 0
        => (1-mask) * input
        """
        pat = find_operator_sequence(op, LayerType.MaskedFill)
        if pat is None:
            return None
        masked_fill = pat[0]
        if masked_fill.options.value == 0:
            return masked_fill
        return None

    @case_value0.transform
    def case_value0(self, op: Operator, **kwargs):
        builder = OpTransformResultV2Builder()
        masked_fill = self.matched_pattern
        inact, mask = masked_fill.inacts
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_mask = builder.copy_activationspec(mask, add_input_map=True)
        if not new_mask.dtype.startswith("int"):
            new_mask = builder.make_cast(new_mask, dtype="int32")
        # if true 0 else x
        new_mask_flipped = builder.make_sub(1, new_mask)
        new_outact = builder.make_mul(new_inact, new_mask_flipped)
        old_outact = masked_fill.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(masked_fill)
        return builder.build()
