import numpy

from mblt.core import TransformRule, pattern, Operator, LayerType
from mblt.transform.transform_result import (
    OpTransformResultV2Builder,
)
from ._ruleset import PostLLMRuleSet


@PostLLMRuleSet.register
class SharingRoPeWrapperCachedValue(TransformRule):
    @pattern
    def sharing_rope(self, op: Operator, **kwargs):
        if op.layertype != LayerType.StatefulRoPEWrapper:
            return None

        sg = op.subgraph
        rope_ops = [
            op_candidate
            for op_candidate in sg.operators
            if op_candidate.valid
            and op_candidate.layertype == LayerType.StatefulRoPEWrapper
            and op_candidate != op
        ]

        if not rope_ops:
            return None

        all_rope_ops = [op] + rope_ops
        rope_type = op.options.rope_type
        seqlen = op.options.seqlen
        rotary_emb_dim = op.options.rotary_emb_dim

        cos_ops = []
        sin_ops = []
        cos_values = []
        sin_values = []

        for rope_op in all_rope_ops:
            cos_op = rope_op.inacts[1].producer_op
            sin_op = rope_op.inacts[2].producer_op
            if cos_op.layertype != LayerType.InputConstant:
                return None
            if sin_op.layertype != LayerType.InputConstant:
                return None

            cos_ops.append(cos_op)
            sin_ops.append(sin_op)
            cos_values.append(cos_op.get_tensor(cos_op.options.constant).value)
            sin_values.append(sin_op.get_tensor(sin_op.options.constant).value)

            if rope_op != op and (
                rope_type != rope_op.options.rope_type
                or seqlen != rope_op.options.seqlen
                or rotary_emb_dim != rope_op.options.rotary_emb_dim
            ):
                return None

        # All cos/sin values must be identical
        for cv in cos_values[1:]:
            if not numpy.all(cos_values[0] == cv):
                return None
        for sv in sin_values[1:]:
            if not numpy.all(sin_values[0] == sv):
                return None

        # If all cos_ops and sin_ops are already the same object, already shared
        all_cos_same = all(c == cos_ops[0] for c in cos_ops)
        all_sin_same = all(s == sin_ops[0] for s in sin_ops)
        if all_cos_same and all_sin_same:
            return None

        return all_rope_ops

    @sharing_rope.transform
    def sharing_rope(self, *args, **kwargs):
        rope_ops = self.matched_pattern
        builder = OpTransformResultV2Builder()
        first_op = rope_ops[0]

        cos_act = first_op.inacts[1]
        sin_act = first_op.inacts[2]
        cos_op = cos_act.producer_op
        sin_op = sin_act.producer_op
        cos_value = cos_op.get_tensor(cos_op.options.constant).value
        sin_value = sin_op.get_tensor(sin_op.options.constant).value

        cos_sub = builder.make_inputconst(cos_value, cos_act.name + "/share")
        sin_sub = builder.make_inputconst(sin_value, sin_act.name + "/share")
        builder.add_input_map(cos_sub, cos_act)
        builder.add_input_map(sin_sub, sin_act)

        for rope_op in rope_ops:
            inact = rope_op.inacts[0]
            inact_sub = builder.copy_activationspec(inact, add_input_map=True)
            rope_sub = builder.make_rope(
                inact_sub,
                cos_sub,
                sin_sub,
                rope_type=rope_op.options.rope_type,
                seq_len=rope_op.options.seqlen,
                rotary_emb_dim=rope_op.options.rotary_emb_dim,
            )

            outact = rope_op.outacts[0]
            builder.add_output_map(rope_sub, outact)
            builder.add_invalidate_ops(rope_op)

        return builder.build()
