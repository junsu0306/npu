import numpy

from mblt.core import TransformRule, Operator, pattern, LayerType
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    check_input_npu_stride,
)
from mblt.transform.ruleset.dataflow_post._ruleset import ChannelFactorSliceRuleSet
from mblt.transform.transform_result import OpTransformResultV2Builder


def _make_channel_slice_index(input_shape, factor, axis, start, end, step=None):
    input_shape = tuple(map(int, input_shape))
    rank = len(input_shape)
    channel_shape = input_shape[-factor:]
    if axis < 0:
        axis += rank
    axis = axis - (rank - factor)
    index = numpy.arange(numpy.prod(channel_shape)).reshape(channel_shape)
    slice_index = [slice(None)] * factor
    slice_index[axis] = slice(start, end, step)
    index = index[tuple(slice_index)].reshape(-1)
    return index


@ChannelFactorSliceRuleSet.register
class ChannelFactorSlice(TransformRule):
    @pattern
    def concat_cfs_case0(self, op: Operator, **kwargs):
        """
        [concat axis3]->(1,14,14,384)-[channel factor slice]->(1,14,14,128)-[reshape]-[headerview]
        """
        pat = find_operator_sequence(
            op, LayerType.Concatenate, LayerType.ChannelFactorSlice
        )
        if pat is None:
            return None
        concat, ref_cfs = pat
        if 2 != len(ref_cfs.options.factor_shape):
            return None
        if ref_cfs.options.axis not in (3, -1):
            return None
        c0, c1 = map(int, ref_cfs.options.factor_shape)
        if concat.options.axis in (3, -1):
            cfs_list = []
            ref_factor_shape = ref_cfs.options.factor_shape
            for cop in concat.outacts[0].consumer_ops:
                if (
                    cop.layertype == LayerType.ChannelFactorSlice
                    and op.options.factor_shape == ref_factor_shape
                    and op.options.axis == ref_cfs.options.axis
                ):
                    cfs = actfn = reshape = hview = None
                    pat = find_operator_sequence(
                        cop,
                        LayerType.ChannelFactorSlice,
                        "R[1hwc->11(hw)c]",
                        LayerType.HeaderView,
                        direction="fwd",
                        strict_search=True,
                    )

                    if pat is not None:
                        cfs, reshape, hview = pat
                    if hview is None:
                        pat = find_operator_sequence(
                            cop,
                            LayerType.ChannelFactorSlice,
                            "actfn R[1hwc->11(hw)c]",
                            LayerType.HeaderView,
                            direction="fwd",
                            strict_search=True,
                        )
                        if pat is not None:
                            cfs, actfn, reshape, hview = pat

                    if hview is None:
                        continue
                    if hview.options.num_heads != c0:
                        continue
                    cfs_list.append((cfs, actfn, reshape, hview))
            if cfs_list:
                return concat, cfs_list
        return None

    @concat_cfs_case0.transform
    def concat_cfs_case0(self, *args, **kwargs):
        concat, cfs_list = self.matched_pattern
        builder = OpTransformResultV2Builder()
        outact = concat.outacts[0]
        new_inact = builder.copy_activationspec(outact, add_input_map=True)
        ref_hview = cfs_list[0][-1]
        n, h, w, c = new_inact.src_shape
        new_inact = builder.make_reshape(new_inact, (n, 1, -1, c))
        new_inact = builder.with_new_input_and_options(ref_hview, new_inact)

        for cfs, actfn, reshape, hview in cfs_list:
            if actfn is not None:
                new_outact = builder.with_new_input_and_options(actfn, new_inact)
            else:
                new_outact = new_inact
            new_outact = builder.make_indexed_item_selector(
                new_outact,
                axis=-1,
                start=cfs.options.start,
                end=cfs.options.end,
                step=cfs.options.step,
            )
            old_outact = hview.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            if actfn is not None:
                builder.remove_connectivity_and_invalidate(cfs, actfn, reshape, hview)
            else:
                builder.remove_connectivity_and_invalidate(cfs, reshape, hview)
        return builder.build()

    @pattern
    def conv_cfs(self, op: Operator, **kwargs):
        """
        fixme: 이게 뒤에 제거하기로 옮겨져야 할 것 같음. 전체 테스트를 돌려야 하므로 여기서는 굉장히 한정적인 것만 일단 처리함.
        """
        pat = find_operator_sequence(op, "C", LayerType.ChannelFactorSlice)
        if pat is None:
            return None
        conv, ref_cfs = pat
        if conv.options.group_number != 1:
            return None
        cfs = []
        ref_factor_shape = ref_cfs.options.factor_shape

        for r in range(1, len(ref_factor_shape) + 1):
            target_axis = (-r, len(ref_factor_shape) - r)  # -1
            for cop in conv.outacts[0].consumer_ops:
                if (
                    cop.layertype == LayerType.ChannelFactorSlice
                    and cop.options.axis in target_axis
                ):
                    if cop.options.factor_shape == ref_factor_shape:
                        cfs.append(cop)
            if len(cfs) == len(conv.outacts[0].consumer_ops):
                return conv, cfs
        return None

    @conv_cfs.transform
    def conv_cfs(self, *args, **kwargs):
        conv, cfs_list = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = conv.outacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        factor_shape = tuple(map(int, cfs_list[0].options.factor_shape))
        input_rank = new_inact.src_dim
        for cfs in cfs_list:
            axis = (
                cfs.options.axis
                if cfs.options.axis < 0
                else cfs.options.axis + input_rank
            )
            index = _make_channel_slice_index(
                new_inact.src_shape[:-1] + factor_shape,
                len(factor_shape),
                axis=axis,
                start=cfs.options.start,
                end=cfs.options.end,
                step=cfs.options.step,
            )
            if bool(numpy.all(index == numpy.arange(index[0], index[0] + index.size))):
                new_outact = builder.make_indexed_item_selector(
                    new_inact,
                    axis=-1,
                    start=index[0],
                    end=index[0] + index.size,
                    step=1,
                )
            else:
                new_outact = builder.make_indexed_item_selector(
                    new_inact, axis=-1, index=index
                )
            old_outact = cfs.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(cfs)
        return builder.build()

    @pattern
    def reshape_cfs(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R", LayerType.ChannelFactorSlice)
        if pat is None:
            return None
        reshape, cfs = pat
        pop = reshape.inacts[0].producer_op
        if check_input_npu_stride(pop):
            return reshape, cfs
        return None

    @reshape_cfs.transform
    def reshape_cfs(self, *args, **kwargs):
        reshape, cfs = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(cfs, new_inact)
        n, h, w, c = inact.src_shape
        new_shape = (n, h, w, -1)
        new_outact = builder.make_reshape(new_outact, new_shape)
        old_outact = cfs.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, cfs)
        return builder.build()
