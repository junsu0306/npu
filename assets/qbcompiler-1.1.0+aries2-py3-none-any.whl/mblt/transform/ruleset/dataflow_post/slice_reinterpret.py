from mblt import Operator, LayerType
from mblt.core import TransformRule, pattern
from mblt.operator.opkind import (
    BIOP_ARITHMETIC_CONST,
    SIMPLE_ACTIVATION_FUNCTIONS,
)
from mblt.operator.utils import interpret_slice
from mblt.subgraph.util.pattern_util import (
    check_input_npu_stride,
    check_forward_direction_until_output_strict,
    find_operator_sequence,
    is_norm_with_last_dim_normalized_shape,
)
from ._ruleset import SliceReinterpretRuleSet
from ...transform_result import OpTransformResultV2Builder


@SliceReinterpretRuleSet.register
class SliceReinterpret(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Concatenate:
            return None
        concat = op
        ax = concat.options.axis
        if ax < 0:
            ax += 4
        cc_cond = False
        intervals = []
        acc = 0
        for inact in concat.inacts:
            if inact.src_shape[ax].dynamic:
                return None
            if not cc_cond:
                cc_cond = check_input_npu_stride(inact.producer_op)
            cc_size = int(inact.src_shape[ax])
            intervals.append((acc, acc + cc_size))
            acc += cc_size
        if not cc_cond:
            return None

        concat_outact = concat.outacts[0]
        for slice_ in concat_outact.consumer_ops:
            if slice_.layertype == LayerType.Slice and 1 == len(slice_.options.axis):
                slice_ax = slice_.options.axis[0]
                if slice_ax < 0:
                    slice_ax += 4
                if ax != slice_ax:
                    continue
                slice_inact = slice_.inacts[0]
                start, end, step = interpret_slice(
                    slice_inact.src_shape, slice_.options
                )
                for int_start, int_end in intervals:
                    if int_start <= start < end <= int_end:
                        terminal_output = check_forward_direction_until_output_strict(
                            slice_, {LayerType.Reshape, LayerType.Transpose}
                        )
                        if terminal_output is None:
                            return concat, slice_
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        concat, slice_ = self.matched_pattern
        slice_inact = slice_.inacts[0]

        start, end, step = interpret_slice(slice_inact.src_shape, slice_.options)
        ax = concat.options.axis
        acc = 0
        new_outact = None
        for inact in concat.inacts:
            cc_start = acc
            cc_size = int(inact.src_shape[ax])
            cc_end = acc + cc_size
            if cc_start <= start < end <= cc_end:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_outact = builder.make_slice(
                    new_inact,
                    axis=(ax,),
                    start=(start - cc_start,),
                    end=(end - cc_start,),
                    step=(step,),
                )
                break
            acc += cc_size
        old_outact = slice_.outacts[0]
        if new_outact is None:
            raise NotImplementedError("code should not reach here")
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(concat, slice_)

        return builder.build()


@SliceReinterpretRuleSet.register
class NormSliceSwap(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        for ax in (1, 2):
            pat = find_operator_sequence(
                op,
                is_norm_with_last_dim_normalized_shape,
                f"S[{ax}L]",
                strict_search=True,
            )
            if pat is not None:
                if pat[-1].inacts[0].src_dim != 4:
                    continue
                return pat

        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        norm, slice_ = self.matched_pattern
        old_inact = norm.inacts[0]
        old_outact = slice_.outacts[0]
        new_inact = builder.copy_activationspec(old_inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_inact)
        new_outact = builder.with_new_input_and_options(norm, new_outact)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(norm, slice_)
        return builder.build()


@SliceReinterpretRuleSet.register
class HeaderViewSliceSwap(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.HeaderView, "S[2L]", strict_search=True
        )
        if pat is None:
            return None
        return pat

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        hview, slice_ = self.matched_pattern
        old_inact = hview.inacts[0]
        old_outact = slice_.outacts[0]
        new_inact = builder.copy_activationspec(old_inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_inact)
        new_outact = builder.with_new_input_and_options(hview, new_outact)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(hview, slice_)
        return builder.build()


@SliceReinterpretRuleSet.register
class HeaderViewRevertSliceSwap(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.HeaderViewRevert, "S[2L]", strict_search=True
        )
        if pat is None:
            return None
        return pat

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        hvr, slice_ = self.matched_pattern
        old_inact = hvr.inacts[0]
        old_outact = slice_.outacts[0]
        new_inact = builder.copy_activationspec(old_inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_inact)
        new_outact = builder.with_new_input_and_options(hvr, new_outact)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(hvr, slice_)
        return builder.build()


@SliceReinterpretRuleSet.register
class LinearSliceSwap(TransformRule):
    @pattern
    def axis12(self, op: Operator, **kwargs):
        for ax in (1, 2):
            pat = find_operator_sequence(op, f"LS[{ax}L]", strict_search=True)
            if pat is not None:
                return pat
        return None

    @axis12.transform
    def axis12(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        conv, slice_ = self.matched_pattern
        old_inact = conv.inacts[0]
        old_outact = slice_.outacts[0]
        new_inact = builder.copy_activationspec(old_inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_inact)
        new_outact = builder.with_new_input_and_options(conv, new_outact)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(conv, slice_)
        return builder.build()


@SliceReinterpretRuleSet.register
class ActfnSliceSwap(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op,
            lambda op: op.layertype in SIMPLE_ACTIVATION_FUNCTIONS,
            "S",
            strict_search=True,
        )
        if pat is None:
            return None
        if pat[-1].inacts[0].src_dim != 4:
            return None
        return pat

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        actfn, slice_ = self.matched_pattern
        old_inact = actfn.inacts[0]
        old_outact = slice_.outacts[0]
        new_inact = builder.copy_activationspec(old_inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_inact)
        new_outact = builder.with_new_input_and_options(actfn, new_outact)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(actfn, slice_)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op,
            LayerType.Softmax,
            "S",
            strict_search=True,
        )
        if pat is None:
            return None
        if pat[-1].inacts[0].src_dim != 4:
            return None
        softmax, slice_ = pat
        softmax_axis = softmax.options.axis
        if softmax_axis < 0:
            softmax_axis += softmax.inacts[0].src_dim
        for ax in slice_.options.axis:
            slice_ax = ax if ax >= 0 else ax + softmax.inacts[0].src_dim
            if slice_ax == softmax_axis:
                return None
        return pat

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        softmax, slice_ = self.matched_pattern
        old_inact = softmax.inacts[0]
        old_outact = slice_.outacts[0]
        new_inact = builder.copy_activationspec(old_inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_inact)
        new_outact = builder.with_new_input_and_options(softmax, new_outact)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(softmax, slice_)
        return builder.build()


@SliceReinterpretRuleSet.register
class AttentionMaskSliceSwap(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        StatefulAttentionMaskWrapper → Slice: pull slice before attention mask.

        (1,H,W,C) → attn_mask → (1,H,W,C) → Slice → (1,H,W',C)
            =>
        (1,H,W,C) → Slice → (1,H,W',C) → attn_mask → (1,H,W',C)
        """
        for ax in (1, 2):
            pat = find_operator_sequence(
                op,
                LayerType.StatefulAttentionMaskWrapper,
                f"S[{ax}L]",
                strict_search=True,
            )
            if pat is not None:
                if pat[-1].inacts[0].src_dim != 4:
                    continue
                return pat
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        attn_mask, slice_ = self.matched_pattern
        old_inact = attn_mask.inacts[0]
        old_outact = slice_.outacts[0]
        new_inact = builder.copy_activationspec(old_inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_inact)
        new_outact = builder.make_attention_mask(
            new_outact,
            past_seqlen=attn_mask.options.past_seqlen,
            is_sliding=attn_mask.options.is_sliding,
            sliding_window=attn_mask.options.sliding_window,
            mask_type=attn_mask.options.mask_type,
        )
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(attn_mask, slice_)
        return builder.build()


@SliceReinterpretRuleSet.register
class BiopConstSliceSwap(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        BiopConst → Slice: pull slice before biopconst, adjust const if needed.

        (1,H,W,C) → BiopConst(const) → (1,H,W,C) → Slice → (1,H,W',C)
            =>
        (1,H,W,C) → Slice → (1,H,W',C) → BiopConst(const') → (1,H,W',C)

        const is sliced on the slice axis only when its size > 1 on that axis.
        Singleton or channel-wise constants don't need adjustment.
        """
        for ax in (1, 2):
            pat = find_operator_sequence(
                op,
                lambda op: op is not None and op.layertype in BIOP_ARITHMETIC_CONST,
                f"S[{ax}L]",
                strict_search=True,
            )
            if pat is not None:
                if pat[-1].inacts[0].src_dim != 4:
                    continue
                return pat
        return pat

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop_const, slice_ = self.matched_pattern
        old_inact = biop_const.inacts[0]
        old_outact = slice_.outacts[0]

        # Apply slice to the activation input first
        new_inact = builder.copy_activationspec(old_inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_inact)

        # Determine if the constant needs slicing
        const_value = biop_const.get_tensor(biop_const.options.constant).value
        extra_kwargs = {}
        for i, ax in enumerate(slice_.options.axis):
            ax_pos = ax if ax >= 0 else ax + 4
            # Broadcasting aligns from the right:
            #   4D activation: (1, H, W, C)
            #   1D const:                (C,)  → const_ax = ax_pos - (4 - ndim)
            const_ax = ax_pos - (4 - const_value.ndim)
            if const_ax >= 0 and const_value.shape[const_ax] > 1:
                # Const has non-singleton size on slice axis -> slice it
                slice_inact = slice_.inacts[0]
                start, end, step = interpret_slice(
                    slice_inact.src_shape, slice_.options
                )
                idx = [slice(None)] * const_value.ndim
                idx[const_ax] = slice(start, end, step)
                const_value = const_value[tuple(idx)]
                extra_kwargs["constant"] = const_value

        # Apply biopconst with (potentially sliced) constant
        new_outact = builder.with_new_input_and_options(
            biop_const, new_outact, **extra_kwargs
        )
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(biop_const, slice_)
        return builder.build()


@SliceReinterpretRuleSet.register
class MatmulSliceSwap(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        MatMul followed by Slice on axis 2: pull slice to left input.

        left(1,H,M,K) @ right(1,H,K,N) -> (1,H,M,N) -> Slice[axis=2] -> (1,H,M',N)
            =>
        left(1,H,M,K) -> Slice[axis=2] -> (1,H,M',K) @ right(1,H,K,N) -> (1,H,M',N)
        """
        pat = find_operator_sequence(
            op,
            LayerType.MatMul,
            f"S[2L]",
            strict_search=True,
        )
        if pat is None:
            return None
        if pat[-1].inacts[0].src_dim != 4:
            return None
        return pat

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        matmul, slice_ = self.matched_pattern
        left_inact = matmul.inacts[0]
        right_inact = matmul.inacts[1]
        old_outact = slice_.outacts[0]

        # Slice the left input on axis 2 (same params as the original slice)
        new_left = builder.copy_activationspec(left_inact, add_input_map=True)
        new_left = builder.with_new_input_and_options(slice_, new_left)

        # Right input stays the same
        new_right = builder.copy_activationspec(right_inact, add_input_map=True)

        # MatMul with sliced left input
        new_outact = builder.make_matmul(
            new_left, new_right, repeat=matmul.options.repeat
        )
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(matmul, slice_)
        return builder.build()


@SliceReinterpretRuleSet.register
class BiopSliceSwap(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Slice:
            return None
        slice_ = op
        if slice_.inacts[0].src_dim != 4:
            return None
        for ax in (1, 2):
            pat = find_operator_sequence(
                slice_,
                "biop",
                f"S[{ax}L]",
                strict_search=True,
            )
            if pat is not None:
                break
        if pat is None:
            return None
        if pat[-1].inacts[0].src_dim != 4:
            return None
        biop = pat[0]
        if not any(
            int(inact.src_shape[ax]) != 1
            for inact in biop.inacts
            for ax in slice_.options.axis
        ):
            return None

        return pat

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop, slice_ = self.matched_pattern
        old_outact = slice_.outacts[0]
        new_inacts = []
        for inact in biop.inacts:
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            slice_axes = []
            slice_starts = []
            slice_ends = []
            slice_steps = []
            for i, ax in enumerate(slice_.options.axis):
                if int(inact.src_shape[ax]) == 1:
                    continue
                slice_axes.append(ax)
                slice_starts.append(slice_.options.start[i])
                slice_ends.append(slice_.options.end[i])
                if slice_.options.step is not None:
                    slice_steps.append(slice_.options.step[i])
            if slice_axes:
                new_inact = builder.make_slice(
                    new_inact,
                    axis=tuple(slice_axes),
                    start=tuple(slice_starts),
                    end=tuple(slice_ends),
                    step=tuple(slice_steps) if slice_steps else None,
                )
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(biop, *new_inacts)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(biop, slice_)
        return builder.build()
