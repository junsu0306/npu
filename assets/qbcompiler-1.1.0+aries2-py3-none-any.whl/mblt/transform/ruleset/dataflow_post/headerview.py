import collections
import math
import operator

import numpy

from mblt.core import TransformRule, pattern, Operator, LayerType
from mblt.operator.opkind import BASIC_NHWC_OPS
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    check_output_npu_stride,
    is_transpose,
    is_norm_with_last_dim_normalized_shape,
    check_input_npu_stride,
    is_linear_conv,
)
from mblt.transform.transform_result import (
    OpTransformResultV2Builder,
)
from ._ruleset import HeaderViewRuleSet


def is_static_one(x):
    return x == 1 and not getattr(x, "dynamic", False)


def get_effective_input_shape_axes(transpose_in_shape, transpose_axes):
    effective_rank = len(transpose_axes)
    if effective_rank == 4:
        return transpose_in_shape, transpose_axes

    def renew_index(axes):
        indices = {ax: idx for idx, ax in enumerate(sorted(axes))}
        return tuple(indices[ax] for ax in axes)

    # Remove leading dimensions equal to non-dynamic 1.
    transpose_out_shape = operator.itemgetter(*transpose_axes)(transpose_in_shape)
    # (1,1,16,196,1,4,1,32) => axes=(0,4,1,5,2,7,6,3) =>(1,1,1,4,16,32,1,196)
    remove_cnt = 0
    for i, x in enumerate(transpose_out_shape):
        if is_static_one(x) and remove_cnt < len(transpose_out_shape) - 4:
            remove_cnt += 1
        else:
            break
    remove_axes = set(transpose_axes[i] for i in range(remove_cnt))
    transpose_in_shape = tuple(
        x for idx, x in enumerate(transpose_in_shape) if idx not in remove_axes
    )
    transpose_axes = renew_index(
        tuple(x for x in transpose_axes if x not in remove_axes)
    )

    # Remove more 1's if needed.
    effective_rank = len(transpose_axes)
    effective_axes = list(transpose_axes)
    effective_shape = []
    cnt = effective_rank - 4
    for i, x in enumerate(reversed(transpose_in_shape)):
        if is_static_one(x) and cnt > 0:
            cnt -= 1
            effective_axes.remove(effective_rank - 1 - i)
            continue
        else:
            effective_shape.append(x)
    effective_shape = tuple(reversed(effective_shape))
    effective_axes = renew_index(effective_axes)
    assert tuple(x for x in transpose_out_shape if not is_static_one(x)) == tuple(
        effective_shape[ax]
        for ax in effective_axes
        if not is_static_one(effective_shape[ax])
    )
    return effective_shape, effective_axes


def split_transpose_axes(axes, c0_idx, c1_idx):
    axes = "".join(str(int(x)) for x in axes)
    c0_idx = str(c0_idx)
    c1_idx = str(c1_idx)
    groups = [axes[0]]
    for prev, curr in zip(axes, axes[1:]):
        if int(curr) - int(prev) == 1 and curr not in (c0_idx, c1_idx):
            groups[-1] += str(curr)
        else:
            groups.append(str(curr))
    return groups


def get_chunk_rearrangement_indices(original):
    sorted_list = sorted(original, key=lambda s: s[0])
    return "".join(str(sorted_list.index(v)) for v in original)


def is_headerview(reshape, transpose):
    # check reshape condition.
    reshape_inact = reshape.inacts[0]
    if 4 != reshape_inact.src_dim:
        return False
    n, h, w, c0 = reshape_inact.src_shape
    if any(x.dynamic for x in (n, h, c0)):
        return False
    reshape_outact = reshape.outacts[0]
    if reshape_outact.src_dim < 4:
        return False

    # remove degenerate cases
    effective_shape, effective_axes = get_effective_input_shape_axes(
        reshape_outact.src_shape, transpose.options.transpose_axes
    )
    g, c1 = effective_shape[-2:]
    if g == 1:
        return False
    if g * c1 != c0:
        return False

    # check transpose condition
    effective_rank = len(effective_axes)
    if not (4 <= effective_rank <= 10):
        return False
    splitted = split_transpose_axes(
        effective_axes, effective_rank - 2, effective_rank - 1
    )
    indices = get_chunk_rearrangement_indices(splitted)
    if indices in ("102", "210"):
        return True
    if len(indices) == 4 and ("02" in indices or "20" in indices):
        return True
    return False


def get_effective_shape(src_shape):
    def gen():
        for s in src_shape:
            if s != 1 or getattr(s, "dynamic", False):
                yield int(s)

    return tuple(gen())


@HeaderViewRuleSet.register
class MatmulFix(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        transpose matmul inputs/outputs so that headerviewrevert can be generated.
        (1,3,32,32)---|-[matmul]->(1,3,32,3136)-[reshape]->(1,1,96,3136)-[transpose0131]->(1,1,3136,96)
        (1,3,32,3136)-|
        =>
        (1,3,32,3136)-[transpose0132]->(1,3,3136,32)-|-[matmul]->(1,3,3136,32)-[transpose0213]->(1,3136,3,32)-[reshape]->(1,1,3136,96)
        (1,3,32,32)-[transpose0132]->(1,3,32,32)-----|
        """
        pat = find_operator_sequence(op, LayerType.MatMul, "R[1hwc->11(hw)c] T0132")
        if pat is None:
            return None
        matmul, reshape, transpose = pat
        if matmul.options.repeat[0] != -1:
            return None
        transpose_outact = transpose.outacts[0]
        for cop in transpose_outact.consumer_ops:
            if cop.valid and check_output_npu_stride(transpose_outact.consumer_ops[0]):
                return matmul, reshape, transpose
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        matmul, reshape, transpose = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact0, inact1 = matmul.inacts

        if is_transpose(inact0.producer_op, (0, 1, 3, 2)):
            transpose0 = inact0.producer_op.inacts[0]
            new_inact0 = builder.copy_activationspec(
                transpose0.inacts[0], add_input_map=True
            )
            builder.remove_connectivity_and_invalidate(transpose0, matmul)
        else:
            new_inact0 = builder.copy_activationspec(inact0, add_input_map=True)
            new_inact0 = builder.make_transpose(new_inact0, (0, 1, 3, 2))

        if is_transpose(inact1.producer_op, (0, 1, 3, 2)):
            transpose1 = inact1.producer_op.inacts[1]
            new_inact1 = builder.copy_activationspec(
                transpose1.inacts[0], add_input_map=True
            )
            builder.remove_connectivity_and_invalidate(transpose1, matmul)
        else:
            new_inact1 = builder.copy_activationspec(inact1, add_input_map=True)
            new_inact1 = builder.make_transpose(new_inact1, (0, 1, 3, 2))

        new_outact = builder.make_matmul(new_inact1, new_inact0)
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        seq_len = new_outact.src_shape[1]
        new_outact = builder.make_reshape(new_outact, (1, 1, seq_len, -1))
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(matmul, reshape, transpose)

        return builder.build()


def is_headerview_useful(start_op, max_depth=6):
    pat = find_operator_sequence(
        start_op, "T0213 R", LayerType.Output, direction="fwd", strict_search=True
    )
    return pat is None
    queue = collections.deque([(start_op, 0)])
    visited = {start_op}
    while queue:
        curr_op, depth = queue.popleft()
        if curr_op is None:
            continue
        if curr_op.layertype in BASIC_NHWC_OPS:
            return True
        if depth < max_depth:
            for outact in curr_op.outacts:
                for next_op in outact.consumer_ops:
                    if next_op.valid and next_op not in visited:
                        visited.add(next_op)
                        queue.append((next_op, depth + 1))
    return False


@HeaderViewRuleSet.register
class HeaderViewGeneral(TransformRule):
    """
    case0) reshape + transpose
        NHWC(1,h,w,c)-[reshape]->(x0,x1,...,xn,g,c/g)-[transpose]
            =>
        NHWC(1,h,w,c)-[headerview]->(1,h*g,w,c/g)->[transpose and reshape]

        Base cases:
            batch_order = 0: (1,h,w,g*c1)->(h,w,g,c1)-[0213]->(h,g,w,c1)->(1,h*g,w,c1)
            batch_order = 1: (1,h,w,g*c1)->(h,w,g,c1)-[2013]->(g,h,w,c1)->(1,g*h,w,c1)

        original_axes=0123456789
        transpose_axes group: 0 = 012, 1 = 34567, 2 = (8), 3 = (9)
        transpose_axes |      expr        | type
        ---------------+------------------+------------
        012(8)34567(9) | 4 -> (0,2,1,3)   | batch_order=0
        012(8)(9)34567 | 4 -> (0,2,3,1)   | batch_order=0 + transpose0132
        34567012(8)(9) | 4 -> (1,0,2,3)   | batch_order=0 + transpose0213
        34567(8)012(9) | 4 -> (1,2,0,3)   | batch_order=1 + transpose0213
        34567(9)012(8) | 4 -> (1,3,0,2)   | batch_order=0 + transpose0231
        34567(9)(8)012 | 4 -> (1,3,2,0)   | batch_order=1 + transpose0231
        (8)01234567(9) | 4 -> (2,0,1,3)   | batch_order=1
                         3 -> (1,0,2)
        (8)012(9)34567 | 4 -> (2,0,3,1)   | batch_order=1 + transpose0132
        (9)012(8)34567 | 4 -> (3,0,2,1)   | batch_order=0 + transpose0312
        (9)34567012(8) | 4 -> (3,1,0,2)   | batch_order=0 + transpose0321
        (9)34567(8)012 | 4 -> (3,1,2,0)   | batch_order=1 + transpose0321
        (9)(8)01234567 | 4 -> (3,2,0,1)   | batch_order=1 + transpose0312
                         3 -> (2,1,0)

    """

    @pattern
    def case0(self, op, **kwargs):
        mid_op = None
        if (pat := find_operator_sequence(op, "RT")) is not None:
            reshape, transpose = pat
        elif (
            pat := find_operator_sequence(op, "R", LayerType.Softmax, "T")
        ) is not None:
            reshape, mid_op, transpose = pat
            reshape_outact = reshape.outacts[0]
            if mid_op.options.axis not in (-1, reshape_outact.src_dim - 1):
                return None
        elif pat := find_operator_sequence(op, "R", "actfn", "T"):
            reshape, mid_op, transpose = pat
        elif (
            pat := find_operator_sequence(
                op, "R", is_norm_with_last_dim_normalized_shape, "T"
            )
        ) is not None:
            reshape, mid_op, transpose = pat
            axes = transpose.options.transpose_axes
            if axes[-1] != len(axes) - 1:
                return None
        else:
            return None
        if not is_headerview(reshape, transpose):
            return None
        effective_shape, _ = get_effective_input_shape_axes(
            reshape.outacts[0].src_shape, transpose.options.transpose_axes
        )
        if effective_shape[-1] == 1 and not getattr(
            effective_shape[-1], "dynamic", False
        ):
            return None
        if is_headerview_useful(transpose):
            return reshape, mid_op, transpose
        return None

    @case0.transform
    def transform0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, mid_op, transpose = self.matched_pattern
        reshape_inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(reshape_inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]

        effective_shape, effective_axes = get_effective_input_shape_axes(
            reshape_outact.src_shape, transpose.options.transpose_axes
        )
        effective_rank = len(effective_axes)
        splitted = split_transpose_axes(
            effective_axes, effective_rank - 2, effective_rank - 1
        )
        expr = get_chunk_rearrangement_indices(splitted)
        g_axis = effective_rank - 2
        c1_channel_axis = effective_rank - 1
        if expr == "102":
            expr = "2013"
        elif expr == "210":
            expr = "3201"
        if len(expr) == 4:
            if "02" in expr:
                batch_order = 0
            else:
                batch_order = 1
        else:
            raise NotImplementedError
        # post_axes = {
        #     "0231": "0132",
        #     "1023": "0213",
        #     "1203": "0213",
        #     "1302": "0231",
        #     "1320": "0231",
        #     "2013": "0123",
        #     "2031": "0132",
        #     "3021": "0312",
        #     "3102": "0321",
        #     "3120": "0321",
        #     "3201": "0312",
        # }[expr]
        post_axes = "0" + expr.replace("02", "x").replace("20", "x").replace(
            "1", "2"
        ).replace("x", "1")
        post_axes = tuple(map(int, post_axes))
        batch_axes = (0, g_axis) if batch_order == 0 else (g_axis, 0)
        batch_size = math.prod(int(effective_shape[x]) for x in batch_axes)
        w_axes = tuple(
            x for x in effective_axes if x not in (g_axis, c1_channel_axis, 0)
        )
        w_size = math.prod(int(effective_shape[x]) for x in w_axes)

        c_size = int(effective_shape[-1])
        g_size = int(effective_shape[-2])

        if reshape_inact.src_shape != (
            1,
            batch_size // g_size,
            w_size,
            g_size * c_size,
        ):
            new_inact = builder.make_reshape(
                new_inact, (1, batch_size // g_size, -1, g_size * c_size)
            )
        new_outact = builder.make_headerview(
            new_inact, num_heads=g_size, batch_order=batch_order
        )
        if mid_op is not None:
            if mid_op.layertype == LayerType.Softmax:
                new_outact = builder.make_softmax(new_outact, axis=-1)
            else:
                new_outact = builder.with_new_input_and_options(mid_op, new_outact)
        if (0, 1, 2, 3) != post_axes:
            new_outact = builder.make_transpose(new_outact, post_axes)
        old_outact = transpose.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, transpose)
        return builder.build()


@HeaderViewRuleSet.register
class HeaderViewOrder0(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, "C R[1hw(cd)->1(hw)cd]", LayerType.L2Normalization, "T0231"
        )
        if pat is None:
            return None
        linear, reshape0, norm, transpose0231 = pat
        reshape0_ianct = reshape0.inacts[0]
        n, h, w, cd = reshape0_ianct.src_shape
        if norm.options.norm_axis == (3,) and (h > 1 or w > 1):
            return reshape0, norm, transpose0231
        return None

    @case0.transform
    def transform0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, norm, transpose0231 = self.matched_pattern
        reshape_inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(reshape_inact, add_input_map=True)
        n, h, w, c = reshape_inact.src_shape
        new_outact = builder.make_reshape(new_inact, (n, 1, -1, c))

        reshape_outact = reshape.outacts[0]
        n, hw, c, d = reshape_outact.src_shape
        new_outact = builder.make_headerview(
            new_outact, num_heads=int(c), batch_order=0
        )
        new_outact = builder.with_new_input_and_options(norm, new_outact)
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
        old_outact = transpose0231.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, norm, transpose0231)
        return builder.build()


@HeaderViewRuleSet.register
class HeaderViewRevertOrder0(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        NHWC(1,g,w,c)->[Transpose 0213]->(1,w,g,c)-[Reshape]->(1,1,w,g*c)
            =>
        NHWC(1,g,w,c)->[HeaderViewRevert, batch_order=0]->(1,1,w,g*c)-[reshape]->(1,1,w,g*c)
        --------------------------------------------------------------------------------------
        NHWC(1,g,h*w,c)->[Transpose 0213]->(1,h*w,g,c)-[Reshape]->(1,h,w,g*c)
            =>
        NHWC(1,g,h*w,c)->[HeaderViewRevert, batch_order=0]->(1,h,w,g*c)-[reshape]->(1,h,w,g*c)
        """
        target_patterns = [
            "T0213 R[1wgc->11w(gc)]",
            "T0213 R[1(hw)gc->1hw(gc)]",
        ]

        for target_pattern in target_patterns:
            pat = find_operator_sequence(op, target_pattern)
            if pat is not None:
                return pat
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        n, h, w, c = new_inact.src_shape
        new_outact = builder.make_headerview_revert(
            new_inact, batch_order=0, num_heads=int(h)
        )
        old_outact = reshape.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_shape = list(-1 if x.dynamic else x for x in old_outact.src_shape)
            new_outact = builder.make_reshape(new_outact, new_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case1(self, op, **kwargs):
        """
        (1,192,49,32)-[reshape]->(1,64,3,49,32)-[transpose01324]->(1,64,49,3,32)-[reshape]->(...,96)
            =>
        (1,192,49,32)-[headerview_revert batch_order=0]->(1,64,49,96)-[reshape]->(...,96)
        ------------------------------------------------------------------------------------------
        (1,192,49,32)-[reshape]->(64,3,49,32)-[transpose0213]->(64,49,3,32)-[reshape]->(...,96)
            =>
        (1,192,49,32)-[headerview_revert batch_order=0]->(1,64,49,96)-[reshape]->(...,96)
        """
        target_patterns = [
            "R[1(hg)wc->1hgwc] T01324 R",
            "R[1(hg)wc->hgwc] T0213 R",
        ]
        for target_pattern in target_patterns:
            pat = find_operator_sequence(op, target_pattern)
            if pat is not None:
                reshape0, transpose, reshape1 = pat
                if reshape1.outacts[0].src_dim < 4:
                    continue
                h, g, w, c = reshape0.outacts[0].src_shape[-4:]
                if h.dynamic or g.dynamic or c.dynamic:
                    return None
                reshape1_outact = reshape1.outacts[0]
                if reshape1_outact.src_shape[-1] != (g * c):
                    return None
                if sum(x.dynamic for x in (h, g, c)) > 1:
                    return None
                return reshape0, transpose, reshape1
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        reshape_inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(reshape_inact, add_input_map=True)
        reshape_outact = reshape0.outacts[0]
        h, g, w, c = reshape_outact.src_shape[-4:]
        new_outact = builder.make_headerview_revert(
            new_inact, batch_order=0, num_heads=int(g)
        )
        old_outact = reshape1.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_shape = tuple(-1 if x.dynamic else x for x in old_outact.src_shape)
            new_outact = builder.make_reshape(new_outact, new_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        """
        NHWC(1,16,196,32)->[transpose0231]->(1,196,32,16)-[reshape]->(1,1,196,512)
            =>
        NHWC(1,16,196,32)->[HeaderViewRevert, batch_order=0]->(1,1,196,512)-[reshape]->(1,196,16,32)-[transpose0132]->(1,196,32,16)-[reshape]->(1,1,196,512)
        """
        target_patterns = [
            "T0231 R[1wcd->11w(cd)] ",
        ]
        for target_pattern in target_patterns:
            pat = find_operator_sequence(op, target_pattern)
            if pat is not None:
                transpose, reshape = pat
                reshape_inact = reshape.inacts[0]
                n, w, c, d = reshape_inact.src_shape
                if d > 1:
                    return transpose, reshape
        return None

    @case2.transform
    def case2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        n, heads, w, c = new_inact.src_shape
        new_outact = builder.make_headerview_revert(
            new_inact, batch_order=0, num_heads=int(heads)
        )
        new_outact = builder.make_reshape(new_outact, (1, w, heads, c))
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
        new_outact = builder.make_reshape(new_outact, (1, 1, w, -1))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)

        return builder.build()

    @pattern
    def case3(self, op: Operator, **kwargs):
        """
        dfl-like shape in damoyolo_tinynasL20. but not dfl...

        conv->(1,4,8400,1)-[mulconst]-[reshape]->(1,1,4,8400)-[transpose0132]->(1,1,8400,4)
        """

        def check_mc_ac(mc):
            if mc.layertype in (LayerType.MultiplyConstant, LayerType.AddingConstant):
                inact = mc.inacts[0]
                outact = mc.outacts[0]
                if (
                    inact.src_dim == 4
                    and inact.src_shape == outact.src_shape
                    and inact.src_shape[0] == 1
                ):
                    value = mc.get_tensor(mc.options.constant).value
                    if value.size == 1 or (
                        value.ndim == 4
                        and value.shape[0] == value.shape[1] == value.shape[3]
                    ):
                        return True
            return False

        pat = find_operator_sequence(
            op, "C", check_mc_ac, "R[1hw1->11hw] T0132", strict_search=True
        )
        if pat is not None:
            conv, mc, reshape, transpose = pat
        else:
            pat = find_operator_sequence(
                op, "C", "R[1hw1->11hw] T0132", strict_search=True
            )
            if pat is None:
                return None
            conv, reshape, transpose = pat
            mc = None

        reshape_inact = reshape.inacts[0]
        n, h, w, c = reshape_inact.src_shape
        if h == 1 or w == 1:
            return None
        return conv, mc, reshape, transpose

    @case3.transform
    def case3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        conv, mc, reshape, transpose = self.matched_pattern

        conv_outact = conv.outacts[0]
        new_inact = builder.copy_activationspec(conv_outact, add_input_map=True)
        n, h, w, c = new_inact.src_shape
        new_outact = builder.make_headerview_revert(
            new_inact, batch_order=0, num_heads=int(h)
        )  # (1,1,8400,4)

        if mc is None:
            old_outact = transpose.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(reshape, transpose)
        else:
            const_value = mc.get_tensor(mc.options.constant).value
            const_value = numpy.transpose(const_value, (0, 3, 2, 1))
            new_outact = builder.make_mul(new_outact, const_value)
            old_outact = transpose.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(mc, reshape, transpose)
        return builder.build()

    @pattern
    def case4(self, op: Operator, **kwargs):
        """
        dfl-like shape in damoyolo_tinynasL20. but not dfl...

        conv->(1,4,8400,1)-[concat axis=2]->(1,4,8400,1)-[reshape]->(1,1,4,8400)-[transpose0132]->(1,1,8400,4)
        """

        pat = find_operator_sequence(
            op,
            LayerType.Concatenate,
            "R[1hw1->11hw] T0132",
            strict_search=True,
        )
        if pat is None:
            return None
        concat, reshape, transpose = pat
        if concat.options.axis != 2:
            return None

        for inact in concat.inacts:
            pop = inact.producer_op
            if is_linear_conv(pop) and pop.options.out_channels == 1:
                continue
            else:
                return None

        reshape_inact = reshape.inacts[0]
        n, h, w, c = reshape_inact.src_shape
        if h == 1 or w == 1:
            return None
        return concat, reshape, transpose

    @case4.transform
    def case4(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        concat, reshape, transpose = self.matched_pattern

        inacts = []

        for inact in concat.inacts:
            new_ianct = builder.copy_activationspec(inact, add_input_map=True)
            new_outact = builder.make_headerview_revert(
                new_ianct, batch_order=0, num_heads=int(inact.src_shape[1])
            )
            inacts.append(new_outact)
        new_outact = builder.make_concatenate(inacts, axis=2)
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(concat, reshape, transpose)

        return builder.build()


@HeaderViewRuleSet.register
class HeaderViewRevertOrder1(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        NHWC(1,64,196,32)->[reshape]->(1,4,16,196,32)-[transpose02341]->(1,16,196,32,4)
            =>
        NHWC(1,64,196,32)->[HeaderViewRevert, batch_order=1]->(1,16,196,128)-[reshape]->(1,16,196,4,32)-[transpose01243]->(1,16,196,32,4)
        """
        target_patterns = [
            "R[1(nh)wc->1nhwc] T02341",
        ]
        for target_pattern in target_patterns:
            pat = find_operator_sequence(op, target_pattern)
            if pat is not None:
                reshape, transpose = pat
                reshape_outact = reshape.outacts[0]
                b, n, h, w, c = reshape_outact.src_shape
                if n > 1 and h > 1:
                    return reshape, transpose
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, transpose = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        n, heads, h, w, c = reshape.outacts[0].src_shape
        new_outact = builder.make_headerview_revert(
            new_inact, batch_order=1, num_heads=int(heads)
        )
        n, h, w, c = new_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, h, w, int(heads), -1))
        new_outact = builder.make_transpose(new_outact, (0, 1, 2, 4, 3))
        old_outact = transpose.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_shape = list(-1 if x.dynamic else x for x in old_outact.src_shape)
            new_outact = builder.make_reshape(new_outact, new_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, transpose)
        return builder.build()


@HeaderViewRuleSet.register
class ConvolutionHeaderViewRevert(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "L", LayerType.HeaderViewRevert)
        if pat is None:
            return None
        conv, hrevert = pat
        if (
            conv.options.in_channels > 1
            and conv.options.out_channels == 1
            and conv.options.bias == -1
        ):
            hrevert_inact = hrevert.inacts[0]
            if (
                hrevert.options.batch_order == 0
                and int(hrevert_inact.src_shape[1]) == hrevert.options.num_heads
                and 1 == int(hrevert_inact.src_shape[-1])
            ):
                return conv, hrevert
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        conv, hrevert = self.matched_pattern
        inact = conv.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        conv_weight = conv.get_tensor(conv.options.weight).value

        in_channels = int(inact.src_shape[-1])
        out_channels = int(hrevert.options.num_heads)
        h_kernel = out_channels

        new_conv_weight = numpy.zeros(
            (out_channels, in_channels, h_kernel, 1), dtype=numpy.float32
        )
        for i in range(out_channels):
            new_conv_weight[i, :, i, :] = conv_weight[0, :, 0, :]

        new_outact = builder.make_conv2d(
            new_inact,
            in_channels=in_channels,
            out_channels=out_channels,
            h_kernel=h_kernel,
            weight=new_conv_weight,
        )
        old_outact = hrevert.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(conv, hrevert)
        return builder.build()


@HeaderViewRuleSet.register
class HeaderViewTransposeL2Normalizaion(TransformRule):
    @pattern
    def case0(self, op, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.HeaderView, "T", LayerType.L2Normalization
        )
        if pat is None:
            return None
        hview, transpose, l2norm = pat
        if 1 != len(l2norm.options.norm_axis):
            return None
        ax = l2norm.options.norm_axis[0]
        if transpose.options.transpose_axes[ax] == 2:

            return hview, transpose, l2norm
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        hview, transpose, l2norm = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = hview.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(
            l2norm, new_inact, norm_axis=(2,)
        )
        new_outact = builder.with_new_input_and_options(hview, new_outact)
        new_outact = builder.with_new_input_and_options(transpose, new_outact)
        old_outact = l2norm.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(hview, transpose, l2norm)
        return builder.build()


@HeaderViewRuleSet.register
class HeaderViewHeaderViewRevert(TransformRule):
    @pattern
    def case0(self, op, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.HeaderView, LayerType.HeaderViewRevert
        )
        if pat is None:
            return None
        hview, hrevert = pat
        if (hview.options.batch_order == hrevert.options.batch_order) and (
            hview.options.num_heads == hrevert.options.num_heads
        ):
            return hview, hrevert
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        hview, hrevert = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = hview.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_identity(new_inact)
        old_outact = hrevert.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(hview, hrevert)
        return builder.build()

    @pattern
    def case1(self, op, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.HeaderView, "S[2]", LayerType.HeaderViewRevert
        )
        if pat is None:
            return None
        hview, slice_, hrevert = pat
        if (hview.options.batch_order == hrevert.options.batch_order) and (
            hview.options.num_heads == hrevert.options.num_heads
        ):
            return hview, slice_, hrevert
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        hview, slice_, hrevert = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = hview.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_inact)
        old_outact = hrevert.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(hview, slice_, hrevert)
        return builder.build()


@HeaderViewRuleSet.register
class ReshapeHeaderViewReshape(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        (1,7,7,384)-[reshape]->(1,49,1,384)-[hview order=1]->(1,3*49,1,128)-[reshape]->(1,3,49,128)
        =>
        (1,7,7,384)-[reshape]->(1,1,49,384)-[hview order=0]->(1,3,49,128)
        """
        pat = find_operator_sequence(
            op, "R[1hwc->1(hw)1c]", LayerType.HeaderView, "R[1(nw)1c->1nwc]"
        )
        if pat is None:
            return None
        reshape0, hview, reshape1 = pat
        if hview.options.batch_order != 1:
            return None
        reshape0_inact = reshape0.inacts[0]
        n, h, w, c = reshape0_inact.src_shape
        reshape1_outact = reshape1.outacts[0]
        n1, h1, w1, c1 = reshape1_outact.src_shape
        if h > 1 and w > 1 and h * w == w1 and int(h1) == hview.options.num_heads:
            return reshape0, hview, reshape1
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, hview, reshape1 = self.matched_pattern
        inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        n, h, w, c = new_inact.src_shape
        new_inact = builder.make_reshape(new_inact, (n, 1, -1, c))
        new_outact = builder.make_headerview(
            new_inact, batch_order=0, num_heads=hview.options.num_heads
        )
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, hview, reshape1)
        return builder.build()


@HeaderViewRuleSet.register
class HeaderViewTransposeReshapeLinearReshapeTranspose(TransformRule):
    """
    (1,288,25,192)-[HeaderView ex)num_head=3]->(1,864,25,64)-[transpose0312]->(1,64,864,25)->Reshape->(1,1,18432,25*3(num_head))->LinearConv
    (1,1,18432,25)->Reshape->(1,64,288,25)->transpose0231->(1,288,25,64)
    =>
    (1,288,25,192)->reshape->(1,288,75,64)->transpose(0,1,3,2)->(1,288,64,75)->LinearConv(modify weight)->(1,288,64,25)->transpose(0,1,3,2)->(1,288,25,64)

    LinearConv’s weights were permuted along the Cin (input-channel) axis from (head, w) to (w, head), so that the operation remains equivalent even after reshaping the input to (1, 288, 75, 64).
    """

    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.HeaderView, "T0312RLRT0231")
        if pat is None:
            return None

        headerview, tr0, re0, linear, re1, tr1 = pat
        num_head = headerview.options.num_heads

        re0_inact = re0.inacts[0]
        re0_outact = re0.outacts[0]
        re1_inact = re1.inacts[0]
        re1_outact = re1.outacts[0]

        if not (
            re0_inact.src_dim == 4
            and re0_outact.src_dim == 4
            and re1_inact.src_dim == 4
            and re1_outact.src_dim == 4
        ):
            return None

        ni, hi, wi, ci = re0_inact.src_shape
        no, ho, wo, co = re0_outact.src_shape
        after_reshape_shape = (ni, hi, wi // num_head, ci)

        if not (
            (ni, no, ho) == (1, 1, 1)
            and hi * wi // num_head == wo
            and ci * num_head == co
        ):
            return None

        ni, hi, wi, ci = re1_inact.src_shape
        no, ho, wo, co = re1_outact.src_shape

        if not ((ni, hi, no) == (1, 1, 1) and wi == ho * wo and ci == co):
            return None

        if re1_outact.src_shape != after_reshape_shape:
            return None

        return pat

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        headerview, tr0, re0, linear, re1, tr1 = self.matched_pattern

        inact = headerview.inacts[0]
        outact = tr1.outacts[0]

        num_head = headerview.options.num_heads
        new_shape = inact.src_shape[:-2] + (
            inact.src_shape[-2] * num_head,
            inact.src_shape[-1] // num_head,
        )
        Worigin = inact.src_shape[-2]

        inact_sub = builder.copy_activationspec(inact, add_input_map=True)
        outact_sub = builder.make_reshape(inact_sub, new_shape)
        outact_sub = builder.make_transpose(outact_sub, (0, 1, 3, 2))

        new_linear_weight = linear.get_tensor(linear.options.weight).value
        Cout, Cin, _, _ = new_linear_weight.shape
        weight_new = (
            new_linear_weight.reshape(
                Cout, num_head, Worigin, 1, 1
            )  # (Cout, s, w, 1, 1)
            .transpose(0, 2, 1, 3, 4)  # (Cout, w, s, 1, 1)
            .reshape(Cout, Cin, 1, 1)  # flatten => k_new = w*heads + s
            .copy()  # numpy는 transpose 후 view가 비연속일 수 있어 copy로 contiguous 보장
        )
        outact_sub = builder.with_new_input_and_options(
            linear, outact_sub, weight=weight_new
        )
        outact_sub = builder.make_transpose(outact_sub, (0, 1, 3, 2))

        builder.add_output_map(outact_sub, outact)
        builder.remove_connectivity_and_invalidate(
            headerview, tr0, re0, linear, re1, tr1
        )

        return builder.build()


@HeaderViewRuleSet.register
class YolovPostSpecial(TransformRule):
    """
    yolo가 빨리 잘 지원되어서 이런 특별 처리를 하지 않는 방향으로.
    """

    @pattern
    def case0(self, op: Operator, **kwargs):
        if not (op.layertype == LayerType.Concatenate and op.options.axis in (3, -1)):
            return None

        def xconst_check(op):
            if op.layertype not in (
                LayerType.MultiplyConstant,
                LayerType.AddingConstant,
            ):
                return False
            const_value = op.get_tensor(op.options.constant).value
            if const_value.size == 1:
                return True
            if const_value.ndim == 4:
                inact = op.inacts[0]
                outact = op.outacts[0]
                if inact.src_shape == outact.src_shape:
                    return True
            return False

        # fmt: off
        target_patterns = [
            (LayerType.ChannelFactorSlice, "R[1hwc->11(hw)c]", LayerType.HeaderView),
            # yolov5s_seg_640_640
            (LayerType.ChannelFactorSlice, "actfn", "R[1hwc->11(hw)c]", LayerType.HeaderView, LayerType.Pow, xconst_check),
            (LayerType.ChannelFactorSlice, "actfn", xconst_check, xconst_check, "R[1hwc->11(hw)c]", LayerType.HeaderView),
            (LayerType.ChannelFactorSlice, "actfn", "R[1hwc->11(hw)c]", LayerType.HeaderView),
            # yolov7
            (LayerType.ChannelFactorSlice, "R[1hwc->11(hw)c]", LayerType.HeaderView, LayerType.Pow, xconst_check),
            (LayerType.ChannelFactorSlice, "R[1hwc->11(hw)c]", LayerType.HeaderView, xconst_check, xconst_check),

        ]
        # fmt: on

        ref_hview = None
        concat = op
        pre_patterns = []
        for inact in concat.inacts:
            for tp in target_patterns:
                pat = find_operator_sequence(inact.producer_op, *tp, strict_search=True)
                if pat is not None:
                    pre_patterns.append(pat)
                    for pp in pat:
                        if pp.layertype == LayerType.HeaderView:
                            hview = pp
                            if ref_hview is None:
                                ref_hview = hview
                            else:
                                if 0 != hview.options.batch_order:
                                    return None
                            break
                    break
        if len(pre_patterns) != len(concat.options.inputs):
            return None
        if ref_hview is None:
            return None
        if ref_hview.options.batch_order != 0:
            return None

        ref_cfs = pre_patterns[0][0]
        if not (
            ref_cfs.options.axis in (-1, 1)
            and 2 == len(ref_cfs.options.factor_shape)
            and ref_cfs.options.factor_shape[0] == ref_hview.options.num_heads
        ):
            return None
        for pp in pre_patterns:
            op0 = pp[0]
            if op0.inacts[0].name != ref_cfs.inacts[0].name:
                return None
            if not (
                op0.options.factor_shape == ref_cfs.options.factor_shape
                and op0.options.axis == ref_cfs.options.axis
            ):
                return None

        pop = ref_cfs.inacts[0].producer_op
        if check_input_npu_stride(pop):
            return pre_patterns, concat
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        pre_patterns, concat = self.matched_pattern

        ref_cfs = pre_patterns[0][0]

        hview_ref = None
        for x in pre_patterns[0]:
            if x.layertype == LayerType.HeaderView:
                hview_ref = x
                break

        inact = ref_cfs.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        n, h, w, c = new_inact.src_shape
        new_inact = builder.make_reshape(new_inact, (n, 1, -1, c))
        new_inact = builder.with_new_input_and_options(hview_ref, new_inact)
        for ppat in pre_patterns:
            new_outact = new_inact
            const_before_hview = True
            for x in ppat:
                if x.layertype == LayerType.Reshape:
                    continue
                if x.layertype == LayerType.HeaderView:
                    const_before_hview = False
                    continue

                if x.layertype == LayerType.ChannelFactorSlice:
                    new_outact = builder.make_slice(
                        new_outact,
                        axis=(-1,),
                        start=(x.options.start,),
                        end=(x.options.end,),
                        step=(x.options.step,),
                    )
                elif x.layertype in (
                    LayerType.MultiplyConstant,
                    LayerType.AddingConstant,
                ):
                    const_value = x.get_tensor(x.options.constant).value
                    if const_value.ndim == 4:
                        if const_before_hview:
                            n, h, w, c = const_value.shape
                            num_heads = int(hview_ref.options.num_heads)
                            const_value = numpy.reshape(
                                const_value, (n, h * w, num_heads, c // num_heads)
                            )
                            const_value = numpy.transpose(const_value, (0, 2, 1, 3))
                    new_outact = builder.with_new_input_and_options(
                        x, new_outact, constant=const_value
                    )
                else:
                    new_outact = builder.with_new_input_and_options(x, new_outact)

            old_outact = ppat[-1].outacts[0]
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(*ppat)

        return builder.build()
