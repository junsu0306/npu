import collections
from typing import Iterable

from mblt import LayerType, Operator
from mblt.core import TransformRule, pattern
from mblt.operator import ACTIVATION_FUNCTIONS, BIOP_ARITHMETIC_CONST
from mblt.subgraph.util.pattern_util import find_operator_sequence
from ._ruleset import PostAttentionBlockRuleSet
from ...transform_result import OpTransformResultV2Builder


def _hview_revert_order0_check(hviewrevert):
    return (
        hviewrevert is not None
        and hviewrevert.layertype == LayerType.HeaderViewRevert
        and hviewrevert.options.batch_order == 0
        and hviewrevert.outacts[0].src_shape[1] > 1
    )


_HVIEW_ALLOWABLE_SIMPLE = ACTIVATION_FUNCTIONS.union(BIOP_ARITHMETIC_CONST)


def _hview_allowable(op: Operator):
    outact = op.outacts[0]
    if 1 != len(outact.consumer_ops):
        return False
    if outact.src_dim != 4 or outact.src_shape[0] != 1:
        return False
    if op.layertype in _HVIEW_ALLOWABLE_SIMPLE:
        return True
    if op.layertype == LayerType.Softmax:
        return op.options.axis in (-1, 3, -2, 2)
    if op.layertype == LayerType.MatMul:
        return op.options.repeat[0] == -1
    if op.layertype == LayerType.Transpose:
        return op.options.transpose_axes[:2] == (0, 1)
    return False


def _hview_order0_check(hview, num_heads, batch_size):
    return (
        hview is not None
        and hview.layertype == LayerType.HeaderView
        and hview.options.batch_order == 0
        and hview.inacts[0].src_shape[1] > 1
        and hview.options.num_heads == num_heads
        and hview.inacts[0].src_shape[0] == batch_size
    )


def trace_headerview_attention_block(last_op: Operator) -> None | Iterable[Operator]:
    pat = find_operator_sequence(
        last_op, LayerType.MatMul, _hview_revert_order0_check, strict_search=True
    )
    if pat is None:
        return None
    matmul1, hviewrevert = pat
    visited = set()
    queue = collections.deque([matmul1])
    attention_nodes = set(pat)

    num_heads = int(hviewrevert.options.num_heads)
    batch_size = int(hviewrevert.outacts[0].src_shape[0])

    while queue:
        curr_node = queue.popleft()
        if curr_node is None or not curr_node.valid:
            return None
        if curr_node in visited:
            continue
        visited.add(curr_node)
        if _hview_allowable(curr_node):
            attention_nodes.add(curr_node)
            for inact in curr_node.inacts:
                pop = inact.producer_op
                if pop not in visited:
                    queue.append(pop)
        elif _hview_order0_check(curr_node, num_heads, batch_size):  # terminal node
            attention_nodes.add(curr_node)
        else:
            return None
    return tuple(attention_nodes)


def _invalidate_attention_block(
    builder, last_op: Operator, attention_block: Iterable[Operator]
):
    attention_block_set = set(attention_block)
    processed_ops = set()

    queue = collections.deque([last_op])
    processed_ops.add(last_op)
    while queue:
        curr_op = queue.popleft()
        if curr_op not in attention_block_set:
            continue

        for inact in curr_op.inacts:
            pop = inact.producer_op
            if pop is not None and pop not in processed_ops:
                builder.remove_connectivity_and_invalidate(pop, curr_op)
                processed_ops.add(pop)
                if pop.layertype == LayerType.HeaderView:
                    continue
                queue.append(pop)


@PostAttentionBlockRuleSet.register
class PostAttentionBlockProc(TransformRule):

    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        headerview batch_order=0 with h>1
        """
        attention_block = trace_headerview_attention_block(op)
        return attention_block

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        attention_block = self.matched_pattern
        headerviews = []
        revert_op = None
        for op in attention_block:
            if op.layertype == LayerType.HeaderView:
                headerviews.append(op)
            elif op.layertype == LayerType.HeaderViewRevert:
                revert_op = op
        if revert_op is None:
            raise ValueError("HeaderViewRevert not found")
        visited = set()
        queue = collections.deque(headerviews)
        new_inact_map = {}
        num_heads = -1
        while queue:
            curr_op = queue.popleft()
            if curr_op in visited:
                continue
            if curr_op.layertype == LayerType.HeaderView:
                if num_heads == -1:
                    num_heads = int(curr_op.options.num_heads)
                else:
                    assert num_heads == int(
                        curr_op.options.num_heads
                    ), "num_heads mismatch"
                inact = curr_op.inacts[0]
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_outact = builder.with_new_input_and_options(
                    curr_op, new_inact, batch_order=1
                )
                old_outact = curr_op.outacts[0]
                next_op = old_outact.consumer_ops[0]
                queue.append(next_op)
                new_inact_map[old_outact] = new_outact
                visited.add(curr_op)
                continue

            # wait until all inputs are ready
            if any(new_inact_map.get(inact, None) is None for inact in curr_op.inacts):
                queue.append(curr_op)
                continue

            visited.add(curr_op)

            # last node.
            if curr_op.layertype == LayerType.HeaderViewRevert:
                assert curr_op.name == revert_op.name, "HeaderViewRevert mismatch"
                new_inact = new_inact_map[curr_op.inacts[0]]
                new_outact = builder.with_new_input_and_options(
                    curr_op, new_inact, batch_order=1
                )
                old_outact = curr_op.outacts[0]
                builder.add_output_map(new_outact, old_outact)

                _invalidate_attention_block(builder, curr_op, attention_block)

                return builder.build()

            if curr_op.layertype == LayerType.MatMul:
                new_left_inact = new_inact_map[curr_op.inacts[0]]
                new_right_inact = new_inact_map[curr_op.inacts[1]]
                new_outact = builder.make_matmul(
                    new_left_inact, new_right_inact, repeat=curr_op.options.repeat
                )
            else:
                kw = {}
                if curr_op.layertype in BIOP_ARITHMETIC_CONST:
                    new_const_value = curr_op.get_tensor(curr_op.options.constant).value
                    const_shape = new_const_value.shape
                    if len(const_shape) > 2 and const_shape[-3] > 1:
                        n = 1
                        assert num_heads != -1, "num_heads not set"
                        total_h, w, head_dim = const_shape[-3:]
                        h = total_h // num_heads
                        # order 0의 레이아웃을 order 1의 레이아웃으로 변환
                        new_const_value = (
                            new_const_value.reshape((n, h, num_heads, w, head_dim))
                            .transpose((0, 2, 1, 3, 4))
                            .reshape(n, num_heads * h, w, head_dim)
                        )
                    kw["constant"] = new_const_value
                new_inact = new_inact_map[curr_op.inacts[0]]
                new_outact = builder.with_new_input_and_options(
                    curr_op, new_inact, **kw
                )
            old_outact = curr_op.outacts[0]
            next_op = old_outact.consumer_ops[0]
            queue.append(next_op)
            new_inact_map[old_outact] = new_outact
        raise NotImplementedError("code should not reach here")
