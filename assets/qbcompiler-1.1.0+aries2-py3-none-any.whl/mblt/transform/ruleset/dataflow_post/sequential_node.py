from mblt import LayerType, Operator
from mblt.core import TransformRule, pattern
from mblt.operator.opkind import STATEFUL_SEQUENTIAL_OPS
from ._ruleset import SequentialNodeRuleSet
from ...transform_result import OpTransformResultV2Builder


@SequentialNodeRuleSet.register
class SequentialNodePost(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if (
            op.layertype in STATEFUL_SEQUENTIAL_OPS
            and op.options.direction == "bidirectional"
            and op.options.batch_first
        ):
            return op
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        seq_op = self.matched_pattern

        B = R = W = P = None
        if seq_op.options.B != -1:
            B = seq_op.get_tensor(seq_op.options.B).value
        if seq_op.options.R != -1:
            R = seq_op.get_tensor(seq_op.options.R).value
        if seq_op.options.W != -1:
            W = seq_op.get_tensor(seq_op.options.W).value

        if seq_op.layertype == LayerType.StatefulLSTMWrapper:
            if seq_op.options.P != -1:
                P = seq_op.get_tensor(seq_op.options.P).value

        collect_outputs = [[] for _ in range(len(seq_op.options.outputs))]

        if seq_op.layertype == LayerType.StatefulLSTMWrapper:
            num_act = 3
        elif seq_op.layertype == LayerType.StatefulGRUWrapper:
            num_act = 2
        elif seq_op.layertype == LayerType.StatefulRNNWrapper:
            num_act = 1
        else:
            raise ValueError(f"Unsupported layer type: {seq_op.layertype}")

        activations = seq_op.options.activations
        if activations:
            if len(seq_op.options.activations) == num_act:
                activations = activations * num_act

        for d in range(2):
            new_inacts = []
            for imask, inact in zip(seq_op.options.input_mask, seq_op.inacts):
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                if imask != "i":
                    new_inact = builder.make_slice(
                        new_inact, axis=(2,), start=(d,), end=(d + 1,)
                    )
                new_inacts.append(new_inact)
            kw = {}
            if B is not None:
                kw["B"] = B[d : d + 1]
            if R is not None:
                kw["R"] = R[d : d + 1]
            if W is not None:
                kw["W"] = W[d : d + 1]
            if P is not None:
                kw["P"] = P[d : d + 1]
            if d == 0:
                kw["direction"] = "forward"
                if activations:
                    kw["activations"] = activations[:num_act]
            else:
                kw["direction"] = "backward"
                subgraph_name = seq_op.options.subgraph + "_backward"
                kw["subgraph"] = subgraph_name
                kw["hidden_state_name"] = subgraph_name + "_hidden_state"
                if hasattr(seq_op.options, "cell_state_name"):
                    kw["cell_state_name"] = subgraph_name + "_cell_state"
                if activations:
                    kw["activations"] = activations[-num_act:]
            new_outact = builder.with_new_input_and_options(seq_op, *new_inacts, **kw)
            for i in range(len(new_outact)):
                collect_outputs[i].append(new_outact[i])

        new_outacts = []
        for i in range(len(collect_outputs)):
            if i == 0:
                new_outact = builder.make_concatenate(collect_outputs[i], axis=1)
            else:
                new_outact = builder.make_concatenate(collect_outputs[i], axis=2)
            new_outacts.append(new_outact)
        old_outacts = seq_op.outacts
        for no, oo in zip(new_outacts, old_outacts):
            builder.add_output_map(no, oo)
        builder.remove_connectivity_and_invalidate(seq_op)
        return builder.build()
