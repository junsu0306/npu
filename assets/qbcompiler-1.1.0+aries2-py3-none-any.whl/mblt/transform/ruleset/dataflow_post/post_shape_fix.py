import numpy

from mblt import LayerType, Operator
from mblt.core import TransformRule, pattern
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    is_transpose,
)
from ._ruleset import PostShapeFixRuleSet
from ...transform_result import OpTransformResultV2Builder


@PostShapeFixRuleSet.register
class NormPatchifyConvFix(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        [LayerNormalization]-[OrderedPatchify]-[convs]->...
            =>
        [OrderedPatchify]-[LayerNormalization]-[convs]->...
        """

        def check_op(op):
            return op.layertype in (
                LayerType.LayerNormalization,
                LayerType.RmsNormalization,
            )

        pat = find_operator_sequence(op, check_op, LayerType.OrderedPatchify, "C")
        if pat is None:
            return None
        lnorm, patchify, conv = pat
        c = int(patchify.inacts[0].src_shape[-1])
        if lnorm.options.normalized_shape != (c,):
            return None
        patchify_outact = patchify.outacts[0]
        if all(
            cop.layertype == LayerType.Convolution
            for cop in patchify_outact.consumer_ops
        ):
            return lnorm, patchify
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        lnorm, patchify = self.matched_pattern
        inact = lnorm.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        old_outact = patchify.outacts[0]
        new_outact = builder.with_new_input_and_options(patchify, new_outact)
        new_outact = builder.with_new_input_and_options(lnorm, new_outact)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(lnorm, patchify)
        return builder.build()


@PostShapeFixRuleSet.register
class InputTransposeConcatenate(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if not (op.layertype == LayerType.Concatenate and op.options.axis == 2):
            return None
        concat = op
        if 2 != len(concat.options.inputs):
            return None
        inact0 = concat.inacts[0]
        inact1 = concat.inacts[1]
        if inact0.producer_op.layertype == LayerType.Input and is_transpose(
            inact1.producer_op, (0, 3, 1, 2)
        ):
            if 2 == len(inact0.consumer_ops):
                for cop in inact0.consumer_ops:
                    if is_transpose(cop, (0, 2, 3, 1)):
                        return concat
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        concat = self.matched_pattern
        new_inacts = []
        for inact in concat.inacts:
            if inact.producer_op.layertype == LayerType.Transpose:
                trans = inact.producer_op
                transpose_inact = trans.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                builder.remove_connectivity_and_invalidate(trans, concat)
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_transpose(new_inact, (0, 2, 3, 1))
            new_inacts.append(new_inact)
        new_outact = builder.make_concatenate(new_inacts, axis=1)
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = concat.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(concat)
        return builder.build()


@PostShapeFixRuleSet.register
class RelocateHeaderView(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        아래 split 형태에서 linear out_channels가 너무 작으면 비효율 적이므로 conv-actfn-reshape-headerview로 시작하도록 split을 재조정 함.

        -|-linear-(actfn)-reshape-headerview
         |-linear-(actfn)-reshape-headerview
         |-linear-(actfn)-reshape-headerview

        """

        target_patterns = [
            ("L actfn R[1hwc->11(hw)c]", LayerType.HeaderView),
            ("L R[1hwc->11(hw)c]", LayerType.HeaderView),
        ]
        linear_ref = actfn_ref = reshape_ref = hview_ref = None
        matched_pattern = None
        for target_pattern in target_patterns:
            pat = find_operator_sequence(op, *target_pattern)
            if pat is not None:
                if len(pat) == 4:
                    matched_pattern = target_pattern
                    linear_ref, actfn_ref, reshape_ref, hview_ref = pat
                    break
                else:
                    linear_ref, reshape_ref, hview_ref = pat
                    actfn_ref = None
                    matched_pattern = target_pattern
                    break
        if matched_pattern is None:
            return None

        post_patterns = []
        has_small_conv = False
        num_heads = hview_ref.options.num_heads
        batch_order = hview_ref.options.batch_order

        linear_inact = linear_ref.inacts[0]
        for cop in linear_inact.consumer_ops:
            pat = find_operator_sequence(
                cop, *matched_pattern, direction="fwd", strict_search=True
            )
            if pat is None:
                continue
            if len(pat) == 4:
                linear, actfn, reshape, hview = pat
            else:
                linear, reshape, hview = pat
                actfn = None
            if linear.options.out_channels < 16:
                has_small_conv = True
            if actfn is not None:
                if actfn.layertype != actfn_ref.layertype:
                    continue
            if not (
                hview.options.batch_order == batch_order
                and hview.options.num_heads == num_heads
            ):
                continue
            post_patterns.append(pat)
        if has_small_conv and len(post_patterns) > 1:
            return post_patterns
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        post_patterns = self.matched_pattern
        builder = OpTransformResultV2Builder()

        if 4 == len(post_patterns[0]):
            linear_ref, actfn_ref, reshape_ref, hview_ref = post_patterns[0]
        else:
            linear_ref, reshape_ref, hview_ref = post_patterns[0]
            actfn_ref = None

        inact = linear_ref.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        conv_weights = []
        conv_bias = []
        steps = []
        has_bias = any(x[0].options.bias != -1 for x in post_patterns)
        for linear, actfn, reshape, hview in post_patterns:
            steps.append(int(hview.outacts[0].src_shape[-1]))
            linear_weight = linear.get_tensor(linear.options.weight).value
            conv_weights.append(linear_weight)
            if linear.options.bias != -1:
                conv_bias.append(linear.get_tensor(linear.options.bias).value)
            elif has_bias:
                conv_bias.append(
                    numpy.zeros(linear.options.out_channels, dtype="float32")
                )
            else:
                conv_bias.append(None)

        total_channel = sum(x.shape[0] for x in conv_weights)
        num_heads = post_patterns[0][-1].options.num_heads

        new_conv_weight = numpy.zeros(
            (total_channel, linear_ref.options.in_channels, 1, 1),
        )
        if has_bias:
            new_conv_bias = numpy.zeros(total_channel, dtype="float32")
        else:
            new_conv_bias = None
        indexer = numpy.arange(total_channel).reshape(num_heads, -1)
        acc = 0
        slices = []
        for old_weight, old_bias, step in zip(conv_weights, conv_bias, steps):
            idx = indexer[:, acc : acc + step].reshape(-1)
            new_conv_weight[idx, ...] = old_weight
            if new_conv_bias is not None:
                new_conv_bias[idx] = old_bias
            slices.append((acc, acc + step))
            acc += step

        new_outact = builder.with_new_input_and_options(
            linear_ref,
            new_inact,
            weight=new_conv_weight,
            bias=new_conv_bias,
            out_channels=new_conv_weight.shape[0],
        )
        if actfn_ref is not None:
            new_outact = builder.with_new_input_and_options(actfn_ref, new_outact)
        n, h, w, c = new_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, 1, -1, c))
        new_outact_hview = builder.with_new_input_and_options(hview_ref, new_outact)
        for idx, pat in enumerate(post_patterns):
            start, end = slices[idx]
            new_outact = builder.make_slice(
                new_outact_hview, axis=(3,), start=(start,), end=(end,)
            )
            hview = pat[-1]
            old_outact = hview.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(*pat)
        return builder.build()


@PostShapeFixRuleSet.register
class Yolo11nPostPattern(TransformRule):

    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        # fixme: 이게 필요하지는 않은데 일단 legacy와 결과를 똑같이 만들기 위해서 구현함.
        [concat]->(1,1,8400,51)-[reshape]->(1,84,17,3)-[slice]->(1,84,17,1)-[addcosnt,mulconst]->(1,84,17,1)-|-[concat]->(1,8400,17,3)
                                            -[slice]->(1,84,17,2)-[sigmoid]----------->(1,84,17,2)-|
        """
        pat = find_operator_sequence(op, LayerType.Concatenate, "R[1wcd->11w(cd)]")
        if pat is None:
            return None
        concat1, reshape1 = pat
        if not (concat1.options.axis in (3, -1) and 2 == len(concat1.options.inputs)):
            return None

        pop0 = concat1.inacts[0].producer_op
        pop1 = concat1.inacts[1].producer_op

        def xconst_check(op):
            if op.layertype not in (
                LayerType.MultiplyConstant,
                LayerType.AddingConstant,
            ):
                return False
            const_value = op.get_tensor(op.options.constant).value
            if const_value.size == 1:
                return True
            if const_value.ndim == 4:
                inact = op.inacts[0]
                outact = op.outacts[0]
                if inact.src_shape == outact.src_shape:
                    return True
            return False

        pat0 = find_operator_sequence(
            pop0, "S[3]", xconst_check, xconst_check, strict_search=True
        )
        if pat0 is None:
            return None
        slice0, mc, ac = pat0
        pat1 = find_operator_sequence(pop1, "S[3] actfn", strict_search=True)
        if pat1 is None:
            return None
        slice1, actfn = pat1
        if slice0.inacts[0].name != slice1.inacts[0].name:
            return None

        pat_pre = find_operator_sequence(
            slice0.inacts[0].producer_op, LayerType.Concatenate, "R[11w(cd)->1wcd]"
        )
        if pat_pre is None:
            return None
        concat0, reshape0 = pat_pre

        if concat0.options.axis not in (2, -2):
            return None
        if not (
            reshape0.outacts[0].src_shape == reshape1.inacts[0].src_shape
            and reshape0.inacts[0].src_shape == reshape1.outacts[0].src_shape
        ):
            return None
        return reshape0, slice0, mc, ac, slice1, actfn, concat1, reshape1

    @case0.transform
    def case0(self, *args, **kwargs):
        reshape0, slice0, mc, ac, slice1, actfn, concat1, reshape1 = (
            self.matched_pattern
        )
        builder = OpTransformResultV2Builder()
        inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        n, h, w, c = reshape0.outacts[0].src_shape
        num_heads = int(w)

        new_inact = builder.make_headerview(
            new_inact, num_heads=num_heads, batch_order=0
        )

        new_inact0 = builder.with_new_input_and_options(slice0, new_inact)

        mc_const_value = mc.get_tensor(mc.options.constant).value
        if mc_const_value.ndim == 4:
            mc_const_value = numpy.transpose(mc_const_value, (0, 2, 1, 3))
        new_inact0 = builder.with_new_input_and_options(
            mc, new_inact0, constant=mc_const_value
        )

        ac_const_value = ac.get_tensor(ac.options.constant).value
        if ac_const_value.ndim == 4:
            ac_const_value = numpy.transpose(ac_const_value, (0, 2, 1, 3))
        new_inact0 = builder.with_new_input_and_options(
            ac, new_inact0, constant=ac_const_value
        )

        new_inact1 = builder.with_new_input_and_options(slice1, new_inact)
        new_inact1 = builder.with_new_input_and_options(actfn, new_inact1)
        new_outact = builder.with_new_input_and_options(
            concat1, (new_inact0, new_inact1)
        )
        new_outact = builder.make_headerview_revert(
            new_outact, num_heads=num_heads, batch_order=0
        )
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(slice0, mc, ac, concat1, reshape1)
        builder.remove_connectivity_and_invalidate(reshape0, slice0)
        builder.remove_connectivity_and_invalidate(slice1, actfn, concat1)
        builder.remove_connectivity_and_invalidate(reshape0, slice1)
        return builder.build()
