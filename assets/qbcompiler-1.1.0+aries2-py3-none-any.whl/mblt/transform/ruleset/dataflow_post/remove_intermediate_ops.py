import numpy

from mblt import Operator, LayerType
from mblt.core import TransformRule, pattern
from mblt.subgraph.util.pattern_util import (
    check_input_npu_stride,
    check_output_npu_stride,
    find_operator_sequence,
)
from . import RemoveIntermediateRuleSet
from ...transform_result import OpTransformResultV2Builder


def _front_fusible(pop):
    return (
        pop is not None
        and pop.layertype == LayerType.Convolution
        and pop.options.group_number == 1
    )


@RemoveIntermediateRuleSet.register
class IndexedItemSelector(TransformRule):
    @pattern
    def selector_to_resize(self, op: Operator, **kwargs):
        if op.layertype != LayerType.IndexedItemSelector:
            return None
        if op.options.axis not in (1, 2):
            return None
        if op.options.repeat is None:
            return None
        return op

    @selector_to_resize.transform
    def selector_to_resize(self, op: Operator, **kwargs):
        builder = OpTransformResultV2Builder()
        selector = self.matched_pattern
        inact = selector.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        sizes = list(int(x) for x in new_inact.src_shape)
        sizes[selector.options.axis] = selector.options.repeat
        new_outact = builder.make_resize(
            new_inact,
            sizes=sizes,
            resize_type="nearest",
            transform_mode="asymmetric",
        )
        old_outact = selector.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(selector)
        return builder.build()

    @pattern
    def selector_to_conv_or_slice(self, op: Operator, **kwargs):
        if op.layertype != LayerType.IndexedItemSelector:
            return None
        if op.options.repeat is not None:
            return None
        if op.inacts[0].src_dim != 4:
            return None
        pop = op.inacts[0].producer_op
        if _front_fusible(pop):
            return None
        if op.options.axis in (3, -1):
            return op
        return None

    @selector_to_conv_or_slice.transform
    def selector_to_conv_or_slice(self, op: Operator, **kwargs):
        builder = OpTransformResultV2Builder()
        selector = self.matched_pattern
        inact = selector.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        if selector.options.index != -1:
            index = selector.get_tensor(selector.options.index).value
            oc = len(index)
            ic = int(inact.src_shape[-1])
            weight = numpy.zeros((oc, ic, 1, 1), dtype=numpy.float32)
            weight[numpy.arange(oc), index, 0, 0] = 1.0
            new_outact = builder.make_conv2d(
                new_inact,
                out_channels=oc,
                in_channels=ic,
                weight=weight,
                opname="selector",
            )
        elif selector.options.start is not None:
            new_outact = builder.make_slice(
                new_inact,
                axis=(selector.options.axis,),
                start=(selector.options.start,),
                end=(selector.options.end,),
                step=(selector.options.step,),
                opname="selector",
            )
        else:
            raise NotImplementedError("code should not reach here")

        old_outact = selector.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(selector)
        return builder.build()


@RemoveIntermediateRuleSet.register
class PadGeneric(TransformRule):
    @pattern
    def pad_hw(self, op: Operator, **kwargs):
        if op.layertype != LayerType.PadGeneric:
            return None
        inact = op.inacts[0]
        if not (4 == inact.src_dim and inact.src_shape[0] == 1):
            return None
        input_stride = check_input_npu_stride(inact.producer_op, 4)
        output_stride = False
        outact = op.outacts[0]
        for cop in outact.consumer_ops:
            if check_output_npu_stride(cop, 4):
                output_stride = True
                break
        if input_stride or output_stride:
            pad_front = op.options.padding_list[:4]
            pad_end = op.options.padding_list[4:]
            if pad_front[0] == pad_front[-1] == pad_end[0] == pad_end[-1] == 0:
                return op
        return None

    @pad_hw.transform
    def pad_hw(self, *args, **kwargs):
        pad = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = pad.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)

        pad_front = pad.options.padding_list[:4]
        pad_end = pad.options.padding_list[4:]
        # NPU's north, south is inversed
        north_padding, south_padding = pad_end[1], pad_front[1]
        west_padding, east_padding = pad_front[2], pad_end[2]
        constant = pad.options.constant
        new_outact = builder.make_pad(
            new_inact,
            pad_mode=pad.options.pad_mode,
            north_padding=north_padding,
            south_padding=south_padding,
            west_padding=west_padding,
            east_padding=east_padding,
            constant=constant,
            padding_list=pad.options.padding_list,
        )
        old_outact = pad.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(pad)
        return builder.build()

    @pattern
    def pad_channel(self, op: Operator, **kwargs):
        if op.layertype != LayerType.PadGeneric:
            return None
        inact = op.inacts[0]
        if not (4 == inact.src_dim and inact.src_shape[0] == 1):
            return None
        if not check_input_npu_stride(inact.producer_op):
            return None
        if op.options.pad_mode != "constant":
            return None
        if any(x.dynamic for x in op.inacts[0].src_shape):
            return None
        pad_front = op.options.padding_list[:4]
        pad_end = op.options.padding_list[4:]
        pf = pad_front[3]
        pe = pad_end[3]
        if pad_front[:3] == pad_end[:3] == (0, 0, 0) and (
            (pf >= 0 and pe >= 0) and (pf > 0 or pe > 0)
        ):
            return op
        return None

    @pad_channel.transform
    def pad_channel(self, *args, **kwargs):
        pad = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = pad.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        constant = pad.options.constant
        pad_front_size = pad.options.padding_list[3]
        pad_last_size = pad.options.padding_list[7]
        n, h, w, c = inact.src_shape
        if pad_front_size > 0:
            const = numpy.full((n, h, w, pad_front_size), fill_value=constant)
            const_out = builder.make_inputconst(const)
            new_outact = builder.make_concatenate([const_out, new_outact], axis=3)
        if pad_last_size > 0:
            const = numpy.full((n, h, w, pad_last_size), fill_value=constant)
            const_out = builder.make_inputconst(const)
            new_outact = builder.make_concatenate([new_outact, const_out], axis=3)
        old_outact = pad.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(pad)
        return builder.build()


def _get_selector_index(selector):
    if selector.options.index != -1:
        return list(map(int, selector.get_tensor(selector.options.index).value))
    if selector.options.start is not None:
        return list(
            range(selector.options.start, selector.options.end, selector.options.step)
        )
    return None


@RemoveIntermediateRuleSet.register
class ChannelFactorSliceRemove(TransformRule):

    @pattern
    def conv_cfs_to_headerview(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "C", LayerType.ChannelFactorSlice)
        if pat is None:
            return None
        conv, ref_cfs = pat
        if conv.options.group_number != 1:
            return None
        cfs = []
        ref_factor_shape = ref_cfs.options.factor_shape
        target_axis = (-1, len(ref_factor_shape) - 1)  # -1
        if 2 != len(ref_factor_shape):
            return None

        make_header_view = False
        for cop in conv.outacts[0].consumer_ops:
            if (
                cop.layertype == LayerType.ChannelFactorSlice
                and cop.options.axis in target_axis
            ):
                if cop.options.factor_shape == ref_factor_shape:
                    cfs.append(cop)
            else:
                pat = find_operator_sequence(
                    cop,
                    "R[1hw(cd)->1(hw)cd] T0213",
                    strict_search=True,
                    direction="fwd",
                )
                if pat is not None:
                    reshape_outact = cop.outacts[0]
                    if reshape_outact.src_shape[-2:] == ref_factor_shape:
                        cfs.append(cop)
                        make_header_view = True
        if len(cfs) == len(conv.outacts[0].consumer_ops) and make_header_view:
            return conv, cfs
        return None

    @conv_cfs_to_headerview.transform
    def conv_cfs_to_headerview(self, *args, **kwargs):
        conv, cfs_list = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = conv.outacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        for cfs in cfs_list:
            if cfs.layertype == LayerType.ChannelFactorSlice:
                factor_shape = cfs.options.factor_shape

        n, h, w, c = inact.src_shape  # (1,16,20,171)
        n_heads = int(factor_shape[0])
        new_inact = builder.make_reshape(new_inact, (n, 1, -1, c))  # (1,1,320,171)
        new_inact = builder.make_headerview(new_inact, n_heads, 0)  # (1,3,320,57)
        for cfs in cfs_list:
            if cfs.layertype == LayerType.ChannelFactorSlice:
                new_outact = builder.make_slice(
                    new_inact,
                    axis=(-1,),
                    start=(cfs.options.start,),
                    end=(cfs.options.end,),
                    step=(cfs.options.step,),
                )  # (1,3,320,51)
                new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
            elif cfs.layertype == LayerType.Reshape:
                new_outact = builder.make_transpose(new_inact, (0, 2, 1, 3))
            else:
                raise NotImplementedError("code should not reach here")
            old_outact = cfs.outacts[0]
            if new_outact.src_shape != old_outact.src_shape:
                new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(cfs)
        return builder.build()

    @pattern
    def revert_naive(self, op: Operator, **kwargs):
        if op.layertype != LayerType.ChannelFactorSlice:
            return None
        return op

    @revert_naive.transform
    def revert_naive(self, *args, **kwargs):
        cfs = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = cfs.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        shape = new_outact.src_shape
        input_rank = inact.src_dim

        # 0,1,2,3,4
        axis = (
            cfs.options.axis if cfs.options.axis < 0 else cfs.options.axis - input_rank
        )
        new_shape = shape[:-1] + tuple(cfs.options.factor_shape)
        new_outact = builder.make_reshape(new_outact, new_shape)
        new_outact = builder.make_slice(
            new_outact,
            axis=(axis,),
            start=(cfs.options.start,),
            end=(cfs.options.end,),
            step=(cfs.options.step,),
        )

        old_outact = cfs.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(cfs)
        return builder.build()
