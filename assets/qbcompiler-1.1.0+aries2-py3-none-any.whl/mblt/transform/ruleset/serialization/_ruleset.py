from mblt.core import RuleSet

SerializationRuleSet = RuleSet("SerializationRuleSet")
