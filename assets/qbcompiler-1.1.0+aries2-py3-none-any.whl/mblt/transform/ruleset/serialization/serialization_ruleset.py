import numpy

from mblt.core import TransformRule, pattern, Operator, LayerType
from mblt.subgraph.util.pattern_util import find_operator_sequence
from mblt.subgraph.util.pattern_util import is_biop_const, is_biop_wrapper
from ._ruleset import SerializationRuleSet
from ...transform_result import OpTransformResultV2Builder


@SerializationRuleSet.register
class BiopConstant(TransformRule):
    @pattern
    def biop_const_to_input_const(self, op: Operator, **kwargs):
        if not is_biop_const(op):
            return None
        xconst = op
        const = xconst.get_tensor(xconst.options.constant)
        if const.ndim != 4:
            return None
        return xconst

    @biop_const_to_input_const.transform
    def biop_const_to_input_const(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        xconst = self.matched_pattern
        inact = xconst.inacts[0]
        is_const_first = xconst.options.is_const_first
        biop_type = xconst.layertype.name[:3].lower()

        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        const_val = xconst.get_tensor(xconst.options.constant).value
        input_const = builder.make_inputconst(const_val)
        if is_const_first:
            new_outact = builder.make_biop(input_const, new_inact, opkind=biop_type)
        else:
            new_outact = builder.make_biop(new_inact, input_const, opkind=biop_type)
        old_outact = xconst.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.add_invalidate_ops(xconst)
        return builder.build()

@SerializationRuleSet.register
class NegativeAxis(TransformRule):
    @staticmethod
    def _copy_inputs(builder, op: Operator):
        new_inacts = []
        for inact in op.inacts:
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inacts.append(new_inact)
        return new_inacts

    @staticmethod
    def _normalize_axes(axes, rank):
        if isinstance(axes, int):
            return rank + axes
        return tuple(rank + axis if axis < 0 else axis for axis in axes)

    @pattern
    def axis(self, op: Operator, **kwargs):
        if not hasattr(op.options, "axis"):
            return None
        if not isinstance(op.options.axis, int):
            return None
        if op.options.axis < 0:
            return op
        return None

    @axis.transform
    def axis(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        op = self.matched_pattern
        old_outact = op.outacts[0]
        new_inacts = self._copy_inputs(builder, op)
        rank = new_inacts[0].src_dim
        new_outact = builder.with_new_input_and_options(
            op, *new_inacts, axis=self._normalize_axes(op.options.axis, rank)
        )
        builder.add_output_map(new_outact, old_outact)
        builder.add_invalidate_ops(op)
        return builder.build()

    @pattern
    def axis_tuple(self, op: Operator, **kwargs):
        if not hasattr(op.options, "axis"):
            return None
        if not isinstance(op.options.axis, tuple):
            return None
        if any(axis < 0 for axis in op.options.axis):
            return op
        return None

    @axis_tuple.transform
    def axis_tuple(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        op = self.matched_pattern
        old_outact = op.outacts[0]
        new_inacts = self._copy_inputs(builder, op)
        rank = new_inacts[0].src_dim
        new_outact = builder.with_new_input_and_options(
            op, *new_inacts, axis=self._normalize_axes(op.options.axis, rank)
        )
        builder.add_output_map(new_outact, old_outact)
        builder.add_invalidate_ops(op)
        return builder.build()

    @pattern
    def reduce_axes(self, op: Operator, **kwargs):
        if not hasattr(op.options, "reduce_axes"):
            return None
        if not isinstance(op.options.reduce_axes, tuple):
            return None
        if any(axis < 0 for axis in op.options.reduce_axes):
            return op
        return None

    @reduce_axes.transform
    def reduce_axes(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        op = self.matched_pattern
        old_outact = op.outacts[0]
        new_inacts = self._copy_inputs(builder, op)
        rank = new_inacts[0].src_dim
        new_outact = builder.with_new_input_and_options(
            op,
            *new_inacts,
            reduce_axes=self._normalize_axes(op.options.reduce_axes, rank),
        )
        builder.add_output_map(new_outact, old_outact)
        builder.add_invalidate_ops(op)
        return builder.build()
    
@SerializationRuleSet.register
class BiopChannelBroadcast(TransformRule):
    @staticmethod
    def _get_expand_info(biop: Operator):
        if not is_biop_wrapper(biop):
            return None
        inact0, inact1 = biop.inacts
        outact = biop.outacts[0]
        if not (inact0.src_dim == inact1.src_dim == outact.src_dim == 4):
            return None

        shape0 = inact0.src_shape
        shape1 = inact1.src_shape
        out_shape = outact.src_shape
        if any(getattr(dim, "dynamic", False) for dim in shape0 + shape1 + out_shape):
            return None

        c0 = int(shape0[-1])
        c1 = int(shape1[-1])
        if c0 == 1 and c1 > 1 and not getattr(c0, "dynamic", False):
            return 0, c1
        if c1 == 1 and c0 > 1 and not getattr(c1, "dynamic", False):
            return 1, c0
        return None

    @staticmethod
    def _is_inputconst_expand(biop: Operator, expand_idx: int):
        pop = biop.inacts[expand_idx].producer_op
        return pop is not None and pop.layertype == LayerType.InputConstant

    @pattern
    def case0(self, op: Operator, **kwargs):
        expand_info = self._get_expand_info(op)
        if expand_info is None:
            return None
        expand_idx, target_c = expand_info
        if self._is_inputconst_expand(op, expand_idx):
            return None
        self.pattern_info = (expand_idx, target_c)
        return op

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop = self.matched_pattern
        expand_idx, target_c = self.pattern_info

        new_inacts = [
            builder.copy_activationspec(inact, add_input_map=True) for inact in biop.inacts
        ]
        weight = numpy.ones((target_c, 1, 1, 1), dtype="float32")
        new_inacts[expand_idx] = builder.make_conv2d(
            new_inacts[expand_idx],
            in_channels=1,
            out_channels=target_c,
            h_kernel=1,
            w_kernel=1,
            h_stride=1,
            w_stride=1,
            h_dilation=1,
            w_dilation=1,
            west_padding=0,
            east_padding=0,
            north_padding=0,
            south_padding=0,
            padding_list=tuple(),
            group_number=1,
            weight=weight,
            bias=None,
        )
        new_outact = builder.with_new_input_and_options(biop, *new_inacts)
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(biop)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        expand_info = self._get_expand_info(op)
        if expand_info is None:
            return None
        expand_idx, target_c = expand_info
        if not self._is_inputconst_expand(op, expand_idx):
            return None
        self.pattern_info = (expand_idx, target_c)
        return op

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop = self.matched_pattern
        expand_idx, target_c = self.pattern_info

        new_inacts = []
        for idx, inact in enumerate(biop.inacts):
            if idx != expand_idx:
                new_inacts.append(
                    builder.copy_activationspec(inact, add_input_map=True)
                )
                continue
            iconst = inact.producer_op
            const_value = iconst.get_tensor(iconst.options.constant).value
            in_shape = tuple(map(int, inact.src_shape))
            if const_value.shape != in_shape:
                const_value = const_value + numpy.zeros(in_shape, dtype=const_value.dtype)
            new_const_value = numpy.repeat(const_value, target_c, axis=-1)
            inconst_inact = builder.make_inputconst(new_const_value)
            new_inacts.append(inconst_inact)
            builder.remove_connectivity_and_invalidate(iconst, biop)
            
        new_outact = builder.with_new_input_and_options(biop, *new_inacts)
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(biop)
        return builder.build()


@SerializationRuleSet.register
class ConvToDepthwiseConvOrGroupConv(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Convolution:
            return None
        if op.options.in_channels == 1:
            return None
        if op.options.group_number > 1:
            return op
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        conv = self.matched_pattern
        inact = conv.inacts[0]
        old_outact = conv.outacts[0]
        opt = conv.options

        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        weight = conv.get_tensor(conv.options.weight).value
        if opt.bias != -1:
            bias = conv.get_tensor(conv.options.bias).value
        else:
            bias = None
        if (
            conv.options.group_number
            == conv.options.in_channels
            == conv.options.out_channels
        ):
            new_outact = builder.make_depthwise_conv2d(
                new_inact,
                in_channels=opt.in_channels,
                out_channels=opt.out_channels,
                h_kernel=opt.h_kernel,
                w_kernel=opt.w_kernel,
                h_stride=opt.h_stride,
                w_stride=opt.w_stride,
                h_dilation=opt.h_dilation,
                w_dilation=opt.w_dilation,
                west_padding=opt.west_padding,
                east_padding=opt.east_padding,
                north_padding=opt.north_padding,
                south_padding=opt.south_padding,
                padding_list=opt.padding_list,
                group_number=opt.group_number,
                weight=weight,
                bias=bias,
            )
        else:
            new_outact = builder.make_group_conv2d(
                new_inact,
                in_channels=opt.in_channels,
                out_channels=opt.out_channels,
                h_kernel=opt.h_kernel,
                w_kernel=opt.w_kernel,
                h_stride=opt.h_stride,
                w_stride=opt.w_stride,
                h_dilation=opt.h_dilation,
                w_dilation=opt.w_dilation,
                west_padding=opt.west_padding,
                east_padding=opt.east_padding,
                north_padding=opt.north_padding,
                south_padding=opt.south_padding,
                padding_list=opt.padding_list,
                group_number=opt.group_number,
                weight=weight,
                bias=bias,
            )
        builder.add_output_map(new_outact, old_outact)
        builder.add_invalidate_ops(conv)
        return builder.build()

@SerializationRuleSet.register
class LinearReshapeHeaderView(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "L R", LayerType.HeaderView)
        if pat is None:
            return None
        linear, reshape, _ = pat
        n, h, w, c = reshape.inacts[0].src_shape
        n1, h1, w1, c1 = reshape.outacts[0].src_shape
        base_inact = linear.inacts[0]

        def check_flatten(reshape):
            inact = reshape.inacts[0]
            outact = reshape.outacts[0]
            return (
                4 == inact.src_dim == outact.src_dim
                and inact.src_shape[:3] == (n, h, w)
                and outact.src_shape[:3] == (n1, h1, w1)
            )

        for cop in base_inact.consumer_ops:
            if cop.name == linear.name:
                continue
            lr_pat = find_operator_sequence(
                cop, "L R", LayerType.HeaderView, direction="fwd"
            )
            if lr_pat is not None:
                _, reshape1, _ = lr_pat
                if check_flatten(reshape1):
                    return pat
            rl_pat = find_operator_sequence(
                cop, "R L", LayerType.HeaderView, direction="fwd"
            )
            if rl_pat is not None:
                reshape1, _, _ = rl_pat
                if check_flatten(reshape1):
                    return pat

        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        linear, reshape, hview = self.matched_pattern
        inact = linear.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        n, h, w, c = reshape.outacts[0].src_shape
        new_inact = builder.make_reshape(new_inact, (n, h, w, -1))
        new_inact = builder.with_new_input_and_options(linear, new_inact)

        linear_outact = linear.outacts[0]
        linear_cop = [cop for cop in linear_outact.consumer_ops]
        for cop in linear_cop:
            if cop.name == reshape.name:
                new_outact = builder.with_new_input_and_options(hview, new_inact)
                old_outact = hview.outacts[0]
                builder.add_output_map(new_outact, old_outact)
                builder.remove_connectivity_and_invalidate(linear, reshape, hview)
            else:
                cop_inact = cop.inacts[0]
                if cop_inact.src_shape != new_inact.src_shape:
                    new_outact = builder.make_reshape(new_inact, cop_inact.src_shape)
                new_outact = builder.with_new_input_and_options(cop, new_outact)
                old_outact = cop.outacts[0]
                builder.add_output_map(new_outact, old_outact)
                builder.remove_connectivity_and_invalidate(linear, cop)
        return builder.build()
    
@SerializationRuleSet.register
class ReshapeLinearReshape(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "RLR")
        if pat is None:
            return None
        reshape0, linear, reshape1 = pat
        acts = (
            reshape0.inacts[0],
            reshape0.outacts[0],
            reshape1.inacts[0],
            reshape1.outacts[0],
        )
        if any(act.src_dim != 4 for act in acts):
            return None
        if len({int(act.src_shape[-1]) for act in acts}) != 1:
            return None
        
        if not (reshape0.inacts[0].src_shape == reshape1.outacts[0].src_shape and
                reshape0.outacts[0].src_shape == reshape1.inacts[0].src_shape):
            return None
        return pat

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, linear, reshape1 = self.matched_pattern
        
        inact = reshape0.inacts[0]
        outact = reshape1.outacts[0]
        
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(
            linear, new_inact
        )
        builder.add_output_map(new_outact, outact)
        builder.remove_connectivity_and_invalidate(reshape0, linear, reshape1)        
        
        return builder.build()
