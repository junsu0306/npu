import math

import numpy

from mblt import LayerType
from mblt.core import pattern
from mblt.operator import Operator
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    check_input_npu_stride,
    check_output_npu_stride,
    is_transpose,
    is_reshape_with_expr,
)
from mblt.transform.graph_transform import TransformRule
from mblt.transform.transform_result import OpTransformResultV2Builder
from ._ruleset import ShapeNormalizeContextual


def is_static_one(x):
    return x == 1 and not getattr(x, "dynamic", False)



def _patchify_post_condition(transpose):
    pat = find_operator_sequence(transpose, "T R", direction="fwd", strict_search=True)
    if pat is None:
        return False
    transpose, reshape = pat
    reshape_outact = reshape.outacts[0]
    reshape_inact = reshape.inacts[0]
    if reshape_inact.src_dim == 6:
        n, a, b, c, d, e = reshape_inact.src_shape
        if (n, a * b, c * d, e) == reshape_outact.src_shape:
            return True
    for cop in reshape_outact.consumer_ops:
        if check_output_npu_stride(cop):
            return True
    return False


@ShapeNormalizeContextual.register
class Transpose(TransformRule):
    @pattern
    def fix_axis(self, op: Operator, **kwargs):
        """fix unnecessary transpose axis 0
        (1,50,1,8,64)-[transpose20314]->(1,1,8,50,64)
        =>
        (1,50,1,8,64)-[transpose02314]->(1,1,8,50,64)
        """
        if op.layertype != LayerType.Transpose:
            return None
        axes = op.options.transpose_axes
        if axes[0] == 0:
            return None
        inact = op.inacts[0]
        outact = op.outacts[0]
        if (
            1 == inact.src_shape[0] == outact.src_shape[0]
            and not inact.src_shape[0].dynamic
            and not outact.src_shape[0].dynamic
        ):
            return op
        return None

    @fix_axis.transform
    def fix_axis(self, *args, **kwargs):
        transpose = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_axes = list(map(int, transpose.options.transpose_axes))
        idx = new_axes.index(0)
        new_axes[idx] = transpose.options.transpose_axes[0]
        new_axes[0] = 0
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_inact, new_axes)
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose)
        return builder.build()

    @pattern
    def axes01423(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T01423 R[nhcws->nhc(ws)]")
        if pat is None:
            return None
        transpose, reshape = pat
        return transpose, reshape

    @axes01423.transform
    def axes01423(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        a, b, c, d, e = new_inact.src_shape
        new_outact = builder.make_reshape(new_inact, (a, b, -1, e))
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
        old_outact = reshape.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def axes013524(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, "R[11(hdwe)c->1hdwec] T013524 R", strict_search=True
        )
        if pat is None:
            pat = find_operator_sequence(
                op, "R[1(hd)(we)c->1hdwec] T013524 R", strict_search=True
            )
            if pat is None:
                return None
        reshape, transpose, reshape1 = pat
        transpose_inact = transpose.inacts[0]
        if not all(x > 1 for x in transpose_inact.src_shape[1:-1]):
            return None
        reshape_inact = reshape.inacts[0]
        reshape1_inact = reshape1.inacts[0]
        reshape1_outact = reshape1.outacts[0]
        if int(reshape1_outact.src_shape[-1]) != math.prod(
            map(int, reshape1_inact.src_shape[-3:])
        ):
            return None
        if check_input_npu_stride(reshape_inact.producer_op):
            return reshape, transpose, reshape1
        return None

    @axes013524.transform
    def axes013524(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, transpose, reshape1 = self.matched_pattern
        reshape_inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(reshape_inact, add_input_map=True)
        transpose_inact = transpose.inacts[0]
        b, h, d, w, e, c = transpose_inact.src_shape  # (1,16,2,8,2,192)
        if new_inact.src_shape != (b, h * d, w * e, c):
            new_inact = builder.make_reshape(new_inact, (b, h * d, w * e, c))
        N_in, H_in, W_in, C_in = map(int, new_inact.src_shape)
        h_kernel = h_stride = int(d)
        w_kernel = w_stride = int(e)
        C_out = C_in * (h_kernel * w_kernel)
        C_out_per_group = h_kernel * w_kernel
        eye_np = numpy.eye(C_out_per_group, dtype=numpy.float32)
        kernel_pattern = eye_np.reshape(C_out_per_group, 1, h_kernel, w_kernel)
        weight = numpy.tile(kernel_pattern, (C_in, 1, 1, 1))
        new_outact = builder.make_depthwise_conv2d(
            new_inact,
            in_channels=C_in,
            out_channels=C_out,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            h_stride=h_stride,
            w_stride=w_stride,
            weight=weight,
        )
        old_outact = reshape1.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, transpose, reshape1)
        return builder.build()

    @pattern
    def axes024135(self, op: Operator, **kwargs):
        """
        (1,32,32,64)-[reshape]->(1,16,2,16,2,64)-[transpose]->(1,2,2,16,16,64)
        =>
        (1,32,32,64)-[oredred_patchify order=1]->(1,4,256,64)->reshape(1,2,2,16,16,64)
        ==============================================================================
        (1,7,7,64)-[reshape]->(1,7,1,7,1,64)-[transpose]->(1,1,1,7,7,64)
        =>
        (1,7,7,64)-[reshape]->(1,1,1,7,7,64)
        """
        pat = find_operator_sequence(op, "R T024135")
        if pat is None:
            return None
        reshape, transpose = pat
        reshape_inact = reshape.inacts[0]
        if reshape_inact.src_dim != 4:
            return None
        if not check_input_npu_stride(reshape_inact.producer_op):
            return None
        transpose_inact = transpose.inacts[0]
        n, grid_h, ker_h, grid_w, ker_w, c = transpose_inact.src_shape
        if n != 1 or c != reshape_inact.src_shape[-1]:
            return None
        for x in (n, grid_h, ker_h, grid_w, ker_w, c):
            if x.dynamic:
                return None
        if all(x > 1 for x in (grid_h, ker_h, grid_w, ker_w)):  # patchify
            if _patchify_post_condition(transpose):
                return reshape, transpose

        if grid_h > 1 and grid_w > 1 and ker_h == ker_w == 1:
            return reshape, transpose
        return None

    @axes024135.transform
    def axes024135(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, transpose = self.matched_pattern
        reshape_inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(reshape_inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        n, grid_h, ker_h, grid_w, ker_w, c = reshape_outact.src_shape

        if grid_h > 1 and grid_w > 1 and ker_h == ker_w == 1:
            new_outact = builder.make_reshape(new_inact, (n, grid_h, grid_w, c))
        elif all(x > 1 for x in (grid_h, ker_h, grid_w, ker_w)):
            new_outact = builder.make_ordered_patchify(
                new_inact, h_kernel=ker_h, w_kernel=ker_w, order=1
            )
        else:
            raise NotImplementedError("code should not reach here")
        old_outact = transpose.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, transpose)
        return builder.build()

    @pattern
    def axes013245(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R T013245")
        if pat is None:
            return None
        reshape, transpose = pat
        reshape_inact = reshape.inacts[0]
        if reshape_inact.src_dim != 4:
            return None
        if not (
            check_input_npu_stride(reshape_inact.producer_op)
            or _patchify_post_condition(transpose)
        ):
            return None
        transpose_inact = transpose.inacts[0]
        n, grid_h, ker_h, grid_w, ker_w, c = transpose_inact.src_shape
        if n != 1 or c != reshape_inact.src_shape[-1]:
            return None
        for x in (n, grid_h, ker_h, grid_w, ker_w, c):
            if x.dynamic:
                return None
        if all(x > 1 for x in (grid_h, ker_h, grid_w, ker_w)):  # patchify/space2depth
            return reshape, transpose
        # (n,1,ker_h,1,ker_w,c) => (n,1,1,ker_h,ker_w,c) => (n,ker_h,ker_w,c)
        if grid_h == grid_w == 1 and ker_h > 1 and ker_w > 1:
            return reshape, transpose
        # (n,1,1,grid_w,ker_w,c) => (n,1,grid_w,1,ker_w,c) => (n,grid_w,ker_w,c)
        if grid_h == ker_h == 1:
            return reshape, transpose
        return None

    @axes013245.transform
    def axes013245(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, transpose = self.matched_pattern
        transpose_inact = transpose.inacts[0]
        n, grid_h, ker_h, grid_w, ker_w, c = transpose_inact.src_shape
        expected_input_shape = (n, grid_h * ker_h, grid_w * ker_w, c)
        reshape_inact = reshape.inacts[0]
        if reshape_inact.src_shape == expected_input_shape:
            inact = reshape_inact
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            builder.remove_connectivity_and_invalidate(reshape, transpose)
        else:
            inact = reshape.outacts[0]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inact = builder.make_reshape(new_inact, expected_input_shape)
            builder.remove_connectivity_and_invalidate(transpose)

        if all(x > 1 for x in (grid_h, ker_h, grid_w, ker_w)):
            new_outact = builder.make_ordered_patchify(
                new_inact, h_kernel=int(ker_h), w_kernel=int(ker_w), order=0
            )
        elif grid_h == grid_w == 1 and ker_h > 1 and ker_w > 1:
            new_outact = builder.make_reshape(new_inact, (n, ker_h, ker_w, c))
        elif grid_h == ker_h == 1:
            new_outact = builder.make_reshape(new_inact, (n, grid_w, ker_w, c))
        else:
            raise NotImplementedError("code should not reach here")
        old_outact = transpose.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        return builder.build()

    @pattern
    def batched_axes0132(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[1(bh)wc->bhwc] T0132 R[bhcw->1(bh)cw]")
        if pat is not None:
            return pat
        return None

    @batched_axes0132.transform
    def batched_axes0132(self, *args, **kwargs):
        reshape0, transpose, reshape1 = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reshape0.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def batched_axes0213(self, op: Operator, **kwargs):
        """
        (1,96,32,32)-[reshape]->(1536,2,16,2)-[transpose0213]->(1536,16,2,2)
        =>
        (1,96,32,32)-[reshape]->(1,96,16,2,16,2)-[transpose012435]->(1,96,16,16,2,2)-[reshape]->(1,1536,16,2,2)
        ====================================================================================================
        (1,16,256,24)-[reshape]->(4,4,256,24)-[transpose0213]->(4,256,4,24)
        =>
        (1,16,256,24)-[reshape]->(1,4,4,256,24)-[transpose01324]->(1,4,256,4,24)-[reshape]->(4,256,4,24)
        """
        if not is_transpose(op, (0, 2, 1, 3)):
            return None
        transpose = op
        inact = transpose.inacts[0]
        if inact.src_shape[0] == 1:
            return None
        patterns = [
            "1c(hd)(we)->(ch)dwe",
            "1(hg)wc->hgwc",
        ]
        transpose_pop = transpose.inacts[0].producer_op
        if not transpose_pop.valid:
            return None
        for idx, reshape_pat in enumerate(patterns):
            if is_reshape_with_expr(reshape_pat)(transpose_pop):
                return transpose_pop, transpose, idx
        return None

    @batched_axes0213.transform
    def batched_axes0213(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, case_no = self.matched_pattern
        if case_no == 0:
            inact = reshape0.inacts[0]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            n_in, c_in, h_in, w_in = inact.src_shape
            reshape_outact = reshape0.outacts[0]
            ch, d, w, e = reshape_outact.src_shape
            new_outact = builder.make_reshape(new_inact, (1, c_in, -1, d, w, e))
            new_outact = builder.make_transpose(new_outact, (0, 1, 2, 4, 3, 5))
            old_outact = transpose.outacts[0]
            if old_outact.src_shape != new_outact.src_shape:
                new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
            builder.add_output_map(new_outact, old_outact)
        elif case_no == 1:
            inact = reshape0.inacts[0]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            reshape_outact = reshape0.outacts[0]
            h, g, w, c = reshape_outact.src_shape
            new_outact = builder.make_reshape(new_inact, (1, h, g, w, c))
            new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2, 4))
            old_outact = transpose.outacts[0]
            if old_outact.src_shape != new_outact.src_shape:
                new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
            builder.add_output_map(new_outact, old_outact)
        else:
            raise NotImplementedError("code should not reach here")
        builder.remove_connectivity_and_invalidate(reshape0, transpose)
        return builder.build()

    @pattern
    def axes04312(self, op: Operator, **kwargs):
        """(1,28,28,116)-[reshape]->(1,28,28,2,58)-[transpose04312]->(1,58,2,28,28)-[reshape]->(1,116,28,28)
        =>
        (1,28,28,116)-[indexed_item_selector]->(1,28,28,116)-[transpose0312]->(1,116,28,28)
        """
        pat = find_operator_sequence(op, "R[nhw(sc)->nhwsc] T04312 R[ncshw->n(cs)hw]")
        if pat is not None:
            reshape0, transpose04312, reshape1 = pat
            old_outact = reshape0.outacts[0]
            n, h, w, s, c = old_outact.src_shape
            if s > 1:
                reshape0_pop = reshape0.inacts[0].producer_op
                if check_input_npu_stride(reshape0_pop):
                    return reshape0, transpose04312, reshape1
        return None

    @pattern
    def axes012435(self, op: Operator, **kwargs):
        """
        (1,4,256,96)-[transpose0321]->(1,96,256,4)-[reshape]->(1,96,16,16,2,2)-[transpose012435]->(1,96,16,2,16,2)-[reshape]->(1,96,32,32)
            =>
        (1,4,256,96)-[reshape]->(1,2,2,16,16,96)-[transpose031425]->(1,16,2,16,2,96)-[reshape]->(1,32,32,96)-[transpose0312]
        """
        pat = find_operator_sequence(
            op, "T0321 R[1c(hw)(de)->1chwde] T012435 R[1chdwe->1c(hd)(we)]"
        )
        return pat

    @axes012435.transform
    def axes012435(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose0321, reshape0, transpose012435, reshape1 = self.matched_pattern
        old_inact = transpose0321.inacts[0]
        new_outact = builder.copy_activationspec(old_inact, add_input_map=True)
        reshape0_outact = reshape0.outacts[0]
        n, c, h, w, d, e = reshape0_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, d, e, h, w, c))
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 4, 2, 5))
        new_outact = builder.make_reshape(new_outact, (n, h * d, w * e, c))
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(
            transpose0321, reshape0, transpose012435, reshape1
        )
        return builder.build()

    @axes04312.transform
    def axes04312(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose04312, reshape1 = self.matched_pattern
        old_inact = reshape0.inacts[0]
        new_outact = builder.copy_activationspec(old_inact, add_input_map=True)
        transpose_inact = transpose04312.inacts[0]
        n, h, w, s, c = map(int, transpose_inact.src_shape)
        index = numpy.arange(s * c).reshape(s, c).transpose(1, 0).reshape(-1)
        new_outact = builder.make_indexed_item_selector(
            new_outact, axis=-1, index=index
        )
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose04312, reshape1)
        return builder.build()

    @pattern
    def axes02341(self, op: Operator, **kwargs):
        """
        11w(cd)-[reshape]->(1w1cd)-[transpose02341]->(11cdw)
            =>
        11w(cd)-[reshape]->(1wcd)-[transpose0231]->(1cdw)->(11cdw)
        """
        pat = find_operator_sequence(op, "R[b1w(cd)->bw1cd] T02341")
        if pat is None:
            return None
        reshape, transpose = pat
        return reshape, transpose

    @axes02341.transform
    def axes02341(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, transpose = self.matched_pattern
        old_inact = reshape.inacts[0]
        new_outact = builder.copy_activationspec(old_inact, add_input_map=True)
        a, w, b, c, d = transpose.inacts[0].src_shape
        new_outact = builder.make_reshape(new_outact, (1, w, c, d))
        new_outact = builder.make_transpose(new_outact, (0, 2, 3, 1))
        old_outact = transpose.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, transpose)
        return builder.build()

    @pattern
    def axes03214(self, op: Operator, **kwargs):
        """
        (1,7,7,2304)-[reshape]->(1,49,1,24,32)-[transpose03214]->(1,24,1,49,32)
        =>
        (1,7,7,2304)-[reshape]->(1,49,24,32)-[transpose0213]->(1,24,49,32)-[reshape]->(1,24,1,49,32)
        """
        pat = find_operator_sequence(op, "R[1hw(cd)->1(hw)1cd] T03214")
        if pat is None:
            return None
        reshape0, transpose03214 = pat
        return reshape0, transpose03214

    @axes03214.transform
    def axes03214(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose03214 = self.matched_pattern
        old_inact = reshape0.inacts[0]
        new_outact = builder.copy_activationspec(old_inact, add_input_map=True)
        b, hw, n, c, d = reshape0.outacts[0].src_shape
        new_outact = builder.make_reshape(new_outact, (b, hw, c, d))
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = transpose03214.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose03214)
        return builder.build()

    @pattern
    def axes02314(self, op: Operator, *args, **kwargs):
        """
        11w(cd)-[reshape]->(1w1cd)-[transpose02314]->(11cwd)
            =>
        11w(cd)-[reshape]->(1wcd)-[transpose0213]->(1cwd)-[reshape]->(11cwd)
        """
        pat = find_operator_sequence(op, "R[b1w(cd)->bw1cd] T02314")
        if pat is None:
            return None
        reshape, transpose = pat
        return reshape, transpose

    @axes02314.transform
    def axes02314(self, *args, **kwargs):
        reshape, transpose = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reshape.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        b, w, e, c, d = reshape_outact.src_shape
        assert e == 1
        new_outact = builder.make_reshape(new_outact, (b, w, c, d))
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = transpose.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, transpose)
        return builder.build()

    @pattern
    def axes052413(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, "R[b(xy)(zt)c->bxyztc] T052413 R[bcxyzt->bc(xy)(zt)]"
        )
        if pat is None:
            return None
        reshape0, transpose, reshape1 = pat
        return reshape0, transpose, reshape1

    @axes052413.transform
    def axes052413(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        inact = reshape0.outacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_outact = reshape0.outacts[0]
        b, x, y, z, t, c = reshape_outact.src_shape  # (1,16,2,16,2,64)
        new_outact = builder.make_transpose(new_outact, (0, 2, 4, 1, 3, 5))
        new_outact = builder.make_reshape(new_outact, (b, y * t, x * z, c))
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape1)
        return builder.build()

    @pattern
    def axes051324(self, op: Operator, **kwargs):
        """
        (1,32,32,96)-[reshape]->(1,16,2,16,2,96)-[transpose051324]->(1,96,16,16,2,2)-[reshape]->(1,96,256,4)-[transpose0321]->(1,4,256,96)
        ==================================================================================================
        (1,32,32,96)-[reshape]->(1,16,2,16,2,96)-[transpose024135]->(1,2,2,16,16,96)-[reshape]->(1,4,256,96)
        """
        pat = find_operator_sequence(
            op, "R[1(hd)(we)c->1hdwec] T051324 R[1chwde->1c(hw)(de)] T0321"
        )
        if pat is None:
            return None
        reshape0, transpose, reshape1, t0321 = pat
        pop = reshape0.inacts[0].producer_op
        if check_input_npu_stride(pop):
            return reshape0, transpose, reshape1, t0321
        return None

    @axes051324.transform
    def axes051324(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1, t0321 = self.matched_pattern
        inact = transpose.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        n, h, d, w, e, c = inact.src_shape
        new_outact = builder.make_transpose(new_outact, (0, 2, 4, 1, 3, 5))
        new_outact = builder.make_reshape(new_outact, (n, d * e, h * w, c))
        old_outact = t0321.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape1, t0321)
        return builder.build()

    @pattern
    def axes031425(self, op: Operator, **kwargs):
        """
        (1,16,49,64)-[reshape]->(1,4,4,7,7,64)-[transpose031425]->(1,7,4,7,4,64)
        =>
        (1,16,49,64)-[ordered_patchify order=2]->(1,28,28,64)->[reshape]->(1,7,4,7,4,64)
        =================================================================================
        (1,1,49,64)-[reshape]->(1,1,1,7,7,64)-[transpose031425]->(1,7,1,7,1,64)
        =>
        (1,1,49,64)-[reshape]->(1,7,1,7,1,64)
        """
        pat = find_operator_sequence(op, "R T031425")
        if pat is None:
            return None
        reshape, transpose = pat
        reshape_inact = reshape.inacts[0]
        if reshape_inact.src_dim != 4:
            return None
        is_proc = check_input_npu_stride(reshape_inact.producer_op)
        if not is_proc:
            pat = find_operator_sequence(
                transpose,
                "T031425 R[1abcde->1(ab)(cd)e]",
                direction="fwd",
                strict_search=True,
            )
            if pat is None:
                return None
            last_reshape_outact = pat[-1].outacts[0]
            for cop in last_reshape_outact.consumer_ops:
                if check_output_npu_stride(cop):
                    is_proc = True
                    break
        if not is_proc:
            return None

        transpose_inact = transpose.inacts[0]
        n, grid_h, ker_h, grid_w, ker_w, c = transpose_inact.src_shape
        if n != 1 or c != reshape_inact.src_shape[-1]:
            return None
        for x in (n, grid_h, ker_h, grid_w, ker_w, c):
            if x.dynamic:
                return None
        if all(x > 1 for x in (grid_h, ker_h, grid_w, ker_w)):
            if _patchify_post_condition(transpose):
                return reshape, transpose
        if grid_h == ker_h == 1:
            return reshape, transpose
        return None

    @axes031425.transform
    def axes031425(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, transpose = self.matched_pattern
        old_inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(old_inact, add_input_map=True)
        transpose_inact = transpose.inacts[0]
        n, grid_h, ker_h, grid_w, ker_w, c = transpose_inact.src_shape
        if new_inact.src_shape != (n, grid_h * ker_h, grid_w * ker_w, c):
            new_inact = builder.make_reshape(
                new_inact, (n, grid_h * ker_h, grid_w * ker_w, c)
            )
        if grid_h == ker_h == 1:
            new_outact = builder.make_reshape(new_inact, (n, grid_w, ker_w, c))
        elif all(x > 1 for x in (grid_h, ker_h, grid_w, ker_w)):
            new_outact = builder.make_ordered_patchify(
                new_inact, h_kernel=ker_h, w_kernel=ker_w, order=2
            )
        else:
            raise NotImplementedError("code should not reach here")
        old_outact = transpose.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, transpose)
        return builder.build()

    @pattern
    def axes031425_case2(self, op: Operator, **kwargs):
        """
        (1,120,160,256)-[reshape]->(1,120,160,64,2,2)
                       -[transpose031425]->(1,64,120,2,160,2)
                       -[reshape]->(1,64,240,320)
        =>
        (1,120,160,256)-[reshape]->(1,120,160,64,2,2)
                       -[transpose014253]->(1,120,2,160,2,64)
                       -[reshape]->(1,240,320,64)
                       -[transpose0312]->(1,64,240,320)
        """
        pat = find_operator_sequence(
            op, "R[1hw(cde)->1hwcde] T031425 R[1hdwec->1h(dw)(ec)]"
        )
        if pat is None:
            return None
        reshape0, transpose, reshape1 = pat
        reshape0_ouatct = reshape0.outacts[0]
        if any(x > 1 for x in reshape0_ouatct.src_shape[-2:]):
            pop = reshape0.inacts[0].producer_op
            if check_input_npu_stride(pop):
                return reshape0, transpose, reshape1
        return None

    @axes031425_case2.transform
    def axes031425_case2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        old_inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(old_inact, add_input_map=True)
        transpose_inact = transpose.inacts[0]
        n, h, w, c, d, e = transpose_inact.src_shape
        new_outact = builder.make_transpose(new_inact, (0, 1, 4, 2, 5, 3))
        new_outact = builder.make_reshape(new_outact, (n, h * d, w * e, c))
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_inact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_inact)
        builder.remove_connectivity_and_invalidate(transpose, reshape1)
        return builder.build()

    @pattern
    def axes03124(self, op: Operator, **kwargs):
        """
        (1,80,80,2)-[reshape]->(1,80,80,1,2)-[transpose03124]->(1,1,80,80,2)
        =>
        (1,80,80,2)-[reshape]->(1,1,80,80,2)
        """
        pat = find_operator_sequence(op, "R[1hwc->1hw1c] T03124")
        return pat

    @axes03124.transform
    def axes03124(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, transpose = self.matched_pattern
        old_inact = reshape.inacts[0]
        new_outact = builder.copy_activationspec(old_inact, add_input_map=True)
        old_outact = transpose.outacts[0]
        new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, transpose)
        return builder.build()

    @pattern
    def axes014253(self, op: Operator, **kwargs):
        """
        (1,120,160,256)-[reshape]->(1,120,160,64,2,2)-[transpose014253]->(1,120,2,160,2,64)-[reshape]->(1,240,320,64)
        """
        pat = find_operator_sequence(
            op, "R[1hw(cde)->1hwcde] T014253 R[1hwcde->1(hw)(cd)e]"
        )
        if pat is None:
            return None
        reshape0, transpose014253, reshape1 = pat
        inact = reshape0.inacts[0]
        if check_input_npu_stride(inact.producer_op):
            return reshape0, transpose014253, reshape1
        return None

    @axes014253.transform
    def axes014253(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose014253, reshape1 = self.matched_pattern
        old_inact = reshape0.inacts[0]
        new_outact = builder.copy_activationspec(old_inact, add_input_map=True)
        reshape0_outact = reshape0.outacts[0]
        n, h, w, c, h_kernel, w_kernel = map(int, reshape0_outact.src_shape)
        in_channels = c * h_kernel * w_kernel
        out_channels = c
        # weight = numpy.zeros(
        #     (in_channels, out_channels, h_kernel, w_kernel), dtype="float32"
        # )
        #
        # for oc in range(out_channels):
        #     for kh in range(h_kernel):
        #         for kw in range(w_kernel):
        #             ic = oc * h_kernel * w_kernel + kh * w_kernel + kw
        #             weight[ic, oc, kh, kw] = 1.0
        # 전체 크기에 맞는 단위 행렬 생성
        total_elements = out_channels * h_kernel * w_kernel
        weight = numpy.eye(total_elements, dtype="float32").reshape(
            out_channels, h_kernel, w_kernel, total_elements
        )
        # 축 순서 변경 (oc, kh, kw, ic) -> (ic, oc, kh, kw)
        weight = weight.transpose(3, 0, 1, 2)
        weight = numpy.transpose(weight[..., ::-1, ::-1], (1, 0, 2, 3)).copy()
        north_padding = south_padding = h_kernel - 1
        west_padding = east_padding = w_kernel - 1

        new_outact = builder.make_transposeconv2d(
            new_outact,
            in_channels=in_channels,
            out_channels=out_channels,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            h_stride=h_kernel,
            w_stride=w_kernel,
            weight=weight,
            north_padding=north_padding,
            south_padding=south_padding,
            west_padding=west_padding,
            east_padding=east_padding,
        )
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose014253, reshape1)
        return builder.build()

    @pattern
    def axes014253_case2(self, op: Operator, **kwargs):
        """
        (1,64,4,256)-[reshape]->(1,64,2,2,16,16)-[transpose014253]->(1,64,16,2,16,2)-[reshape]->(1,64,32,32)-[transpose0231]->(1,32,32,64)
        =>
        (1,64,4,256)-[transpose0231]->(1,4,256,64)-[reshape]->(1,2,2,16,16,64)-[transpose031425]->(1,16,2,16,2,64)-[reshape]->(1,32,32,64)
        """
        pat = find_operator_sequence(
            op, "R[1c(hd)(we)->1chdwe] T014253 R[1cwhed->1c(wh)(ed)] T0231"
        )
        if pat is None:
            return None
        reshape0, transpose014253, reshape1, transpose0231 = pat
        t0231_outact = transpose0231.outacts[0]
        for cop in t0231_outact.consumer_ops:
            if check_output_npu_stride(cop):
                return reshape0, transpose014253, reshape1, transpose0231
        return None

    @axes014253_case2.transform
    def axes014253_case2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose014253, reshape1, transpose0231 = self.matched_pattern
        old_inact = reshape0.inacts[0]
        new_outact = builder.copy_activationspec(old_inact, add_input_map=True)
        reshape0_outact = reshape0.outacts[0]
        n, c, h, d, w, e = reshape0_outact.src_shape
        new_outact = builder.make_transpose(new_outact, (0, 2, 3, 1))
        new_outact = builder.make_reshape(new_outact, (n, h, d, w, e, c))
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 4, 2, 5))
        new_outact = builder.make_reshape(new_outact, (n, w * h, e * d, c))
        old_outact = transpose0231.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(
            reshape0, transpose014253, reshape1, transpose0231
        )
        return builder.build()

    @pattern
    def axes013425(self, op: Operator, **kwargs):
        """
        (1,56,56,96)-[reshape]->(1,28,2,28,2,96)
                    -[transpose013425]->(1,28,28,2,2,96)
                    -[reshape]->(1,28,28,384)
        """

        pat = find_operator_sequence(
            op, "R T013425 R[1hwdec->1hw(dec)]", strict_search=True
        )
        if pat is None:
            return None
        reshape0, transpose013425, reshape1 = pat
        n, h, d, w, e, c = reshape0.outacts[0].src_shape
        if not all(x > 1 for x in (h, d, w, e, c)):
            return None
        pop = reshape0.inacts[0].producer_op
        if check_input_npu_stride(pop):
            return reshape0, transpose013425, reshape1
        return None

    @axes013425.transform
    def axes013425(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        reshape0_outact = reshape0.outacts[0]
        n, grid_h, ker_h, grid_w, ker_w, c = map(int, reshape0_outact.src_shape)
        patches = []
        inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        if inact.src_shape != (n, grid_h * ker_h, grid_w * ker_w, c):
            new_inact = builder.make_reshape(
                new_inact, (n, grid_h * ker_h, grid_w * ker_w, c)
            )

        for kx in range(ker_w):
            for ky in range(ker_h):
                w = numpy.zeros((c, 1, ker_h, ker_w))
                w[:, 0, ky, kx] = 1.0
                new_out = builder.make_conv2d(
                    new_inact,
                    in_channels=c,
                    out_channels=c,
                    h_kernel=ker_h,
                    w_kernel=ker_w,
                    h_stride=ker_h,
                    w_stride=ker_w,
                    weight=w,
                    group_number=c,
                )
                patches.append(new_out)
        new_outact = builder.make_concatenate(patches, -1)
        old_outact = reshape1.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def axes035124(self, op: Operator, **kwargs):
        """
        (1,3,224,224)-[reshape]->(1,3,56,4,56,4)-[transpose035124]->(1,4,4,3,56,56)-[reshape]->(1,48,56,56)-[transpose0231]->(1,56,56,48)
        =>
        (1,3,224,224)-[transpose0231]->(1,224,224,3)-[reshape]->(1,56,4,56,4,3)-[transpose013245]->(1,56,56,4,4,3)-[reshape]->(1,56,56,48)
        """
        pat = find_operator_sequence(
            op, "R[1c(hd)(we)->1chdwe] T035124 R[1abcde->1(abc)de] T0231"
        )
        return pat

    @axes035124.transform
    def axes035124(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1, transpose0231 = self.matched_pattern
        old_inact = reshape0.inacts[0]
        new_outact = builder.copy_activationspec(old_inact, add_input_map=True)
        new_outact = builder.make_transpose(new_outact, (0, 2, 3, 1))
        reshape0_outact = reshape0.outacts[0]
        n, c, h, d, w, e = reshape0_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, h, d, w, e, c))
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2, 4, 5))
        new_outact = builder.make_reshape(new_outact, (n, h, w, -1))
        old_outact = transpose0231.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(
            reshape0, transpose, reshape1, transpose0231
        )
        return builder.build()

    @pattern
    def axes053142(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[1hwc->111hwc] T053142 R[1ch1w1->1chw]")
        return pat

    @axes053142.transform
    def axes053142(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        old_inact = reshape0.inacts[0]
        new_outact = builder.copy_activationspec(old_inact, add_input_map=True)
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = reshape1.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def axes01243(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[1(nh)wc->1nhwc] T01243")
        return pat

    @axes01243.transform
    def axes01243(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose = self.matched_pattern
        old_inact = reshape0.inacts[0]
        new_outact = builder.copy_activationspec(old_inact, add_input_map=True)
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
        old_outact = transpose.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose)
        return builder.build()

    @pattern
    def axes01243_channe_shuffle(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, "R[1hw(cd)->1hwcd] T01243 R[1hwdc->1hw(dc)]", strict_search=True
        )
        if pat is not None:
            reshape0, transpose, reshape1 = pat
            pop = reshape0.inacts[0].producer_op
            if not check_input_npu_stride(pop):
                return None
            output_check = False
            for cop in reshape1.outacts[0].consumer_ops:
                if output_check:
                    break
                output_check = check_output_npu_stride(cop)
            if not output_check:
                return None
            reshape0_outact = reshape0.outacts[0]
            n, h, w, c_out, d_out = reshape0_outact.src_shape
            if h > 1 and w > 1 and c_out > 1 and d_out > 1:
                return reshape0, transpose, reshape1
        return None

    @axes01243_channe_shuffle.transform
    def axes01243_channe_shuffle(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose014253, reshape1 = self.matched_pattern
        inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        c, d = map(int, reshape0.outacts[0].src_shape[-2:])
        index = numpy.arange(c * d).reshape((c, d)).transpose((1, 0)).reshape(-1)
        new_outact = builder.make_indexed_item_selector(new_inact, axis=3, index=index)
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose014253, reshape1)
        return builder.build()

    @pattern
    def axes0132_channe_shuffle(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, "R[11w(cd)->1wcd] T0132 R[1wdc->11w(dc)]", strict_search=True
        )
        if pat is not None:
            reshape0, transpose, reshape1 = pat
            pop = reshape0.inacts[0].producer_op
            if not check_input_npu_stride(pop):
                return None
            output_check = False
            for cop in reshape1.outacts[0].consumer_ops:
                if output_check:
                    break
                output_check = check_output_npu_stride(cop)
            if not output_check:
                return None
            reshape0_outact = reshape0.outacts[0]
            n, w, c_out, d_out = reshape0_outact.src_shape
            if w > 1 and c_out > 1 and d_out > 1:
                return reshape0, transpose, reshape1
        return None

    @axes0132_channe_shuffle.transform
    def axes0132_channe_shuffle(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose0132, reshape1 = self.matched_pattern
        inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        c, d = map(int, reshape0.outacts[0].src_shape[-2:])
        index = numpy.arange(c * d).reshape((c, d)).transpose((1, 0)).reshape(-1)
        new_outact = builder.make_indexed_item_selector(new_inact, axis=3, index=index)
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose0132, reshape1)
        return builder.build()

    @pattern
    def axes034512(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[1hw(cd)->1hw1cd] T034512 R[11cdhw->cdhw]")
        if pat is None:
            return None
        reshape0, transpose, reshape1 = pat
        if check_input_npu_stride(reshape0.inacts[0].producer_op):
            return reshape0, transpose, reshape1
        return None

    @axes034512.transform
    def case9(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        reshape0_outact = reshape0.outacts[0]
        n, h, w, _, c, d = reshape0_outact.src_shape
        new_outact = builder.make_reshape(new_inact, (n, h, w, c, d))
        new_outact = builder.make_transpose(new_outact, (0, 3, 4, 1, 2))
        old_outact = reshape1.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def axes03412(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, "R[1hw(cd)->1hwcd] T03412 R[1cdhw->cdhw] T2031"
        )
        if pat is None:
            return None
        reshape0, transpose, reshape1, transpose1 = pat
        if check_input_npu_stride(reshape0.inacts[0].producer_op):
            return reshape0, transpose, reshape1, transpose1
        return None

    @axes03412.transform
    def axes03412(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        _, transpose, reshape1, transpose1 = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_inact, (0, 1, 3, 2, 4))
        old_outact = transpose1.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape1, transpose1)
        return builder.build()
