from mblt.core import pattern
from mblt.operator import Operator
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
)
from mblt.transform.graph_transform import TransformRule
from mblt.transform.transform_result import OpTransformResultV2Builder
from ._ruleset import ShapeNormalizeContextual


@ShapeNormalizeContextual.register
class Conv2d(TransformRule):
    # fixme: 이게 동작하면 transpose decomposition와 무한루프 생김.
    # @pattern
    # def linear_with_static_w1(self, op: Operator, **kwargs):
    #     pat = find_operator_sequence(op, "L")
    #     if pat is None:
    #         return None
    #     linear = pat[0]
    #     linear_inact = linear.inacts[0]
    #     n, h, w, c = linear_inact.src_shape
    #     if (not w.dynamic) and w == 1 and h != 1:
    #         return linear
    #     return None
    #
    # @linear_with_static_w1.transform
    # def linear_with_static_w1(self, *args, **kwargs):
    #     builder = OpTransformResultV2Builder()
    #     linear = self.matched_pattern
    #     inact = linear.inacts[0]
    #     new_inact = builder.copy_activationspec(inact, add_input_map=True)
    #     new_inact = builder.make_transpose(new_inact, (0, 2, 1, 3))
    #     new_outact = builder.with_new_input_and_options(linear, new_inact)
    #     new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
    #     old_outact = linear.outacts[0]
    #     builder.add_output_map(new_outact, old_outact)
    #     builder.remove_connectivity_and_invalidate(linear)
    #     return builder.build()

    @pattern
    def linear_with_batch_n(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[1n(hw)c->nhwc] L")
        if pat is not None:
            reshape, linear = pat
            linear_inact = linear.inacts[0]
            if linear_inact.src_shape[0] > 1:
                return pat
        return None

    @linear_with_batch_n.transform
    def linear_with_batch_n(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, linear = self.matched_pattern
        reshape_inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(reshape_inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(linear, new_inact)

        reshape_outact = reshape.outacts[0]
        n, h, w, c = reshape_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, h, w, -1))
        old_outact = linear.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, linear)
        return builder.build()

    @pattern
    def linear_with_batch_n_case2(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[1n(hw)c->nhwc] T0213 L")
        if pat is not None:
            reshape, t0213, linear = pat
            linear_inact = linear.inacts[0]
            if linear_inact.src_shape[0] > 1:
                return pat
        return None

    @linear_with_batch_n_case2.transform
    def linear_with_batch_n_case2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, t0213, linear = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(linear, new_inact)

        reshape_outact = reshape.outacts[0]
        n, h, w, c = reshape_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, h, w, -1))
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = linear.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(linear)
        return builder.build()
