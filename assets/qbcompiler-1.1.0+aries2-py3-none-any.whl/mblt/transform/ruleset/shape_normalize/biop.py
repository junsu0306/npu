from mblt import LayerType
from mblt.core import pattern
from mblt.operator import Operator
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    is_reshape_with_expr,
    check_input_npu_stride,
    is_biop_wrapper,
)
from mblt.transform.graph_transform import TransformRule
from mblt.transform.transform_result import OpTransformResultV2Builder

from ._ruleset import ShapeNormalizeContextual


@ShapeNormalizeContextual.register
class BiOp(TransformRule):
    @pattern
    def batch_n(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "biop")
        if pat is None:
            return None
        biop = pat[0]
        for inact in biop.inacts:
            src_shape = inact.src_shape
            if inact.src_dim == 4 and src_shape[0] > 1 and src_shape[1] == 1:
                return biop
        return None

    @batch_n.transform
    def batch_n(self, *args, **kwargs):
        biop = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = []
        for inact in biop.inacts:
            pop = inact.producer_op
            if (
                pop.layertype == LayerType.Transpose
                and (1, 0, 2, 3) == pop.options.transpose_axes
            ):
                transpose_inact = pop.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_transpose(new_inact, (1, 0, 2, 3))
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(biop, new_inacts)
        new_outact = builder.make_transpose(new_outact, (1, 0, 2, 3))
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(biop)
        return builder.build()

    @pattern
    def reshape_3d_4d(self, op: Operator, **kwargs):
        """
        reshape[1abc->abc] -> biop -> reshape[abc->1abc]
        At least one inact has reshape[1abc->abc].
        Bypasses the reshapes and runs biop in 4D.
        """
        pat = find_operator_sequence(op, "biop", "R[abc->1abc]", strict_search=True)
        if pat is None:
            return None
        biop, reshape_out = pat
        for inact in biop.inacts:
            pop = inact.producer_op
            if pop is not None and is_reshape_with_expr("1abc->abc")(pop):
                return biop, reshape_out
        return None

    @reshape_3d_4d.transform
    def reshape_3d_4d(self, *args, **kwargs):
        biop, reshape_out = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = []
        for inact in biop.inacts:
            pop = inact.producer_op
            if is_reshape_with_expr("1abc->abc")(pop):
                reshape_inact = pop.inacts[0]
                new_inact = builder.copy_activationspec(
                    reshape_inact, add_input_map=True
                )
                # strict 하므로 op,
                builder.remove_connectivity_and_invalidate(pop, biop)
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_reshape(
                    new_inact, (1,) + tuple(inact.src_shape)
                )
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(biop, new_inacts)
        old_outact = reshape_out.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.add_invalidate_ops(biop, reshape_out)
        return builder.build()

    @pattern
    def case_rank5_ch_split(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "biop")
        if pat is None:
            return None
        biop = pat[0]
        inact0 = biop.inacts[0]
        inact1 = biop.inacts[1]
        if inact0.src_shape[-2:] != inact1.src_shape[-2:]:
            return None
        if is_reshape_with_expr("1hw(bc)->1hwbc")(
            inact0.producer_op
        ) and is_reshape_with_expr("1hw(bc)->1hwbc")(inact1.producer_op):
            src_shape0 = inact0.producer_op.inacts[0].src_shape
            src_shape1 = inact1.producer_op.inacts[0].src_shape
            if src_shape0[-1] != src_shape1[-1]:
                return None
            # todo: check broadcastable condition. generalize.
            if src_shape0[1:3] == src_shape1[1:3]:
                return biop
            if src_shape0[1:3] == (1, 1) or src_shape1[1:3] == (1, 1):
                return biop
        return None

    @case_rank5_ch_split.transform
    def case_rank5_ch_split(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop = self.matched_pattern
        new_inacts = []
        for inact in biop.inacts:
            reshape = inact.producer_op
            new_inact = builder.copy_activationspec(
                reshape.inacts[0], add_input_map=True
            )
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(biop, new_inacts)
        old_outact = biop.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(biop)
        return builder.build()

    @pattern
    def case_rank5(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "biop")
        if pat is None:
            return None
        biop = pat[0]
        inact0 = biop.inacts[0]
        inact1 = biop.inacts[1]
        if is_reshape_with_expr("11wc->111wc")(
            inact0.producer_op
        ) and is_reshape_with_expr("1hw(bc)->1hwbc")(inact1.producer_op):
            return biop
        if is_reshape_with_expr("11wc->111wc")(
            inact1.producer_op
        ) and is_reshape_with_expr("1hw(bc)->1hwbc")(inact0.producer_op):
            return biop
        return None

    @case_rank5.transform
    def case_rank5(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop = self.matched_pattern
        new_inacts = []
        for inact in biop.inacts:
            n, h, w, b, c = inact.src_shape
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inact = builder.make_reshape(new_inact, (n, -1, b, c))
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(biop, new_inacts)
        old_outact = biop.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(biop)
        return builder.build()

    @pattern
    def case_rank5_biop(self, op: Operator, **kwargs):
        """
        (1,56,56,128)-[reshape]->(1,56,56,2,64)-[transpose03412]->(1,2,64,56,56)-|-[mul]->(1,2,64,56,56)
        (1,1,1,128)-[reshape]->(1,2,64,1,1)-|
        """
        if not is_biop_wrapper(op):
            return None
        biop = op
        inact0, inact1 = biop.inacts

        def check0(trans):
            pat = find_operator_sequence(trans, "R[1hw(cd)->1hwcd] T03412")
            if pat is None:
                return None
            reshape, transpose = pat
            reshape_outact = reshape.outacts[0]
            n, h, w, c, d = reshape_outact.src_shape
            if all(x > 1 for x in (h, w, c, d)):
                return reshape, transpose
            return None

        def check1(pop):
            if not is_reshape_with_expr("111(cd)->1cd11")(pop):
                return None
            return pop

        pat1 = None
        pat0 = check0(inact0.producer_op)
        if pat0 is not None:
            pat1 = check1(inact1.producer_op)
        else:
            pat0 = check0(inact1.producer_op)
            if pat0 is not None:
                pat1 = check1(inact0.producer_op)

        if pat0 is not None and pat1 is not None:
            reshape0, transpose0 = pat0
            reshape1 = pat1
            reshape0_outact = reshape0.outacts[0]
            n, h, w, c0, d = map(int, reshape0_outact.src_shape)
            c1 = reshape1.inacts[0].src_shape[-1]
            if c1 == c0 * d:
                pop0 = reshape0.inacts[0].producer_op
                pop1 = reshape1.inacts[0].producer_op
                if check_input_npu_stride(pop0) or check_input_npu_stride(pop1):
                    return reshape0, transpose0, reshape1, biop
        return None

    @case_rank5_biop.transform
    def case_rank5_biop(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose0, reshape1, biop = self.matched_pattern
        reshape0_inact = reshape0.inacts[0]
        reshape1_inact = reshape1.inacts[0]
        new_inact0 = builder.copy_activationspec(reshape0_inact, add_input_map=True)
        new_inact1 = builder.copy_activationspec(reshape1_inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(biop, (new_inact0, new_inact1))
        n, h, w, c, d = reshape0.outacts[0].src_shape
        new_outact = builder.make_reshape(new_outact, (n, h, w, c, d))
        new_outact = builder.make_transpose(new_outact, (0, 3, 4, 1, 2))
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose0, biop)
        builder.remove_connectivity_and_invalidate(reshape1, biop)
        return builder.build()

    @pattern
    def case_rank5_mul(self, op: Operator, **kwargs):
        """
        [conv]->(1,313,64,32)-[reshape]->(1,313,64,4,8)-[transpose03412]->(1,4,8,313,64)-|-[mul]->(1,4,8,313,64)
        (1,1,64,4)-[reshape]->(1,1,1,64,4)-[transpose04123]->(1,4,1,1,64)----------------|
        """
        if op.layertype != LayerType.Multiply:
            return None
        mul = op
        inact0, inact1 = mul.inacts

        def check0(trans):
            pat = find_operator_sequence(trans, "R[1hw(cd)->1hwcd] T03412")
            if pat is None:
                return None
            reshape, transpose = pat
            reshape_outact = reshape.outacts[0]
            n, h, w, c, d = reshape_outact.src_shape
            if all(x > 1 for x in (h, w, c, d)):
                reshape_pop = reshape.inacts[0].producer_op
                if check_input_npu_stride(reshape_pop, max_depth=3):
                    return reshape, transpose
            return None

        def check1(pop):
            pat = find_operator_sequence(pop, "R[11wc->111wc] T04123")
            if pat is None:
                return None
            reshape, transpose = pat
            reshape_outact = reshape.outacts[0]
            n, h, w, b, c = reshape_outact.src_shape
            if b > 1 and c > 1:
                reshape_pop = reshape.inacts[0].producer_op
                if check_input_npu_stride(reshape_pop, max_depth=3):
                    return reshape, transpose
            return None

        pat1 = None
        pat0 = check0(inact0.producer_op)
        if pat0 is not None:
            pat1 = check1(inact1.producer_op)
        else:
            pat0 = check0(inact1.producer_op)
            if pat0 is not None:
                pat1 = check1(inact0.producer_op)

        if pat0 is not None and pat1 is not None:
            reshape0, transpose0 = pat0
            reshape1, transpose1 = pat1

            reshape0_outact = reshape0.outacts[0]
            n, h, w, c0, d = map(int, reshape0_outact.src_shape)
            w1, c1 = map(int, reshape1.inacts[0].src_shape[-2:])
            if w == w1 and c1 == c0:
                return reshape0, transpose0, reshape1, transpose1, mul
        return None

    @case_rank5_mul.transform
    def case_rank5_mul(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose0, reshape1, transpose1, mul = self.matched_pattern

        reshape0_inact = reshape0.inacts[0]
        reshape1_inact = reshape1.inacts[0]
        new_inact0 = builder.copy_activationspec(reshape0_inact, add_input_map=True)
        new_inact1 = builder.copy_activationspec(reshape1_inact, add_input_map=True)

        reshape0_outact = reshape0.outacts[0]
        n0, h0, w0, c0, d = map(int, reshape0_outact.src_shape)
        n, h, w1, c1 = map(int, reshape1_inact.src_shape)
        new_inact1 = builder.make_reshape(new_inact1, (1, w1, c1, 1))
        new_inact1 = builder.make_indexed_item_selector(new_inact1, axis=-1, repeat=d)
        new_inact1 = builder.make_reshape(new_inact1, (n, h, w1, -1))

        new_outact = builder.make_mul(new_inact0, new_inact1)
        new_outact = builder.make_reshape(new_outact, (n0, h0, w0, c0, d))
        new_outact = builder.make_transpose(new_outact, (0, 3, 4, 1, 2))
        old_outact = mul.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose0, mul)
        builder.remove_connectivity_and_invalidate(reshape1, transpose1, mul)
        return builder.build()
