from mblt.core import pattern, LayerType
from mblt.operator import Operator
from mblt.subgraph.util.pattern_util import (
    is_reshape_with_expr,
)
from mblt.transform.graph_transform import TransformRule
from mblt.transform.transform_result import OpTransformResultV2Builder

from ._ruleset import ShapeNormalizeContextual


@ShapeNormalizeContextual.register
class Concatenate(TransformRule):
    rank5_axis_patterns = {
        1: ["1hwc->11hwc"],
        3: ["1hwc->1hw1c"],
        4: ["1h(ab)c->1habc", "1hwc->11hwc", "1c(hw)d->1chwd"],
    }

    @pattern
    def reshape_rank5(self, concat: Operator, **kwargs):
        for axis, reshape_patterns in self.rank5_axis_patterns.items():
            if (
                concat.layertype == LayerType.Concatenate
                and concat.inacts[0].src_dim == 5
                and concat.options.axis in (axis, axis - 5)
            ):
                for expr in reshape_patterns:
                    if all(
                        is_reshape_with_expr(expr)(inact.producer_op)
                        for inact in concat.inacts
                    ):
                        return concat, axis, expr
        return None

    @reshape_rank5.transform
    def reshape_rank5(self, *args, **kwargs):
        concat, axis, expr = self.matched_pattern
        builder = OpTransformResultV2Builder()

        if axis == 1:
            if expr == "1hwc->11hwc":
                new_inacts = []
                for inact in concat.inacts:
                    reshape = inact.producer_op
                    new_inact = builder.copy_activationspec(
                        reshape.inacts[0], add_input_map=True
                    )
                    new_inacts.append(new_inact)
                    builder.remove_connectivity_and_invalidate(reshape, concat)
                new_outact = builder.make_concatenate(new_inacts, axis=-1)
                n_div = len(concat.options.inputs)
                n, h, w, c = new_outact.src_shape
                new_outact = builder.make_reshape(
                    new_outact, (n, h, w, n_div, c // n_div)
                )
                new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2, 4))
                old_outact = concat.outacts[0]
                builder.add_output_map(new_outact, old_outact)

                return builder.build()
            else:
                raise NotImplementedError(f"code should not reach here: {expr}")

        if axis == 3:
            if expr == "1hwc->1hw1c":
                new_inadts = []
                for inact in concat.inacts:
                    reshape = inact.producer_op
                    new_inact = builder.copy_activationspec(
                        reshape.inacts[0], add_input_map=True
                    )
                    new_inadts.append(new_inact)
                    builder.remove_connectivity_and_invalidate(reshape, concat)
                new_outact = builder.make_concatenate(new_inadts, axis=-1)
                n_div = len(concat.options.inputs)
                n, h, w, c = new_outact.src_shape
                new_outact = builder.make_reshape(
                    new_outact, (n, h, w, n_div, c // n_div)
                )
                old_outact = concat.outacts[0]
                builder.add_output_map(new_outact, old_outact)
                return builder.build()
            else:
                raise NotImplementedError(f"code should not reach here: {expr}")
        if axis == 4:
            new_inacts = []
            if expr == "1h(ab)c->1habc":
                for inact in concat.inacts:
                    reshape_inact = inact.producer_op.inacts[0]
                    new_inact = builder.copy_activationspec(
                        reshape_inact, add_input_map=True
                    )
                    new_inacts.append(new_inact)
            elif expr == "1hwc->11hwc":
                for inact in concat.inacts:
                    reshape_inact = inact.producer_op.inacts[0]
                    new_inact = builder.copy_activationspec(
                        reshape_inact, add_input_map=True
                    )
                    new_inacts.append(new_inact)
            elif expr == "1c(hw)d->1chwd":
                for inact in concat.inacts:
                    reshape_inact = inact.producer_op.inacts[0]
                    new_inact = builder.copy_activationspec(
                        reshape_inact, add_input_map=True
                    )
                    new_inacts.append(new_inact)
            else:
                raise NotImplementedError(f"code should not reach here: {expr}")
            new_outact = builder.make_concatenate(new_inacts, axis=-1)
            old_outact = concat.outacts[0]
            if old_outact.src_shape != new_outact.src_shape:
                new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(concat)
            return builder.build()
