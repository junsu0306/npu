import numpy

from mblt import Operator, LayerType
from mblt.core import TransformRule, pattern
from mblt.operator import REDUCE_OPS, ACTIVATION_FUNCTIONS, NORMALIZATIONS
from mblt.subgraph.util.pattern_util import (
    is_biop_const,
    is_biop_wrapper,
)
from mblt.transform.transform_result import OpTransformResultV2Builder
from ._ruleset import ShapeNormalizeDirect


def _rank4_input_proc(builder, orig_op):
    new_inacts = []
    for inact in orig_op.inacts:
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        missing_rank = 4 - inact.src_dim
        if missing_rank > 0:
            new_shape = (1,) * missing_rank + new_inact.src_shape
            new_inact = builder.make_reshape(new_inact, new_shape)
        new_inacts.append(new_inact)
    return new_inacts


def _rank4_post_proc(builder, new_outact, orig_op):
    old_outact = orig_op.outacts[0]
    if new_outact.src_shape != old_outact.src_shape:
        new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
    builder.add_output_map(new_outact, old_outact)
    builder.remove_connectivity_and_invalidate(orig_op)
    return builder.build()


@ShapeNormalizeDirect.register
class SingleOp(TransformRule):
    target_ops = ACTIVATION_FUNCTIONS

    @pattern
    def rank_leq3(self, op: Operator, **kwargs):
        if op.layertype in self.target_ops and 1 <= op.inacts[0].src_dim < 4:
            return op
        return None

    @rank_leq3.transform
    def rank_leq3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        single_op = self.matched_pattern
        new_inact = _rank4_input_proc(builder, orig_op=single_op)[0]
        kw = {}
        if single_op.layertype == LayerType.Softmax:
            missing_rank = 4 - single_op.inacts[0].src_dim
            if single_op.options.axis < 0:
                kw["axis"] = single_op.options.axis
            else:
                kw["axis"] = single_op.options.axis + missing_rank
        new_outact = builder.with_new_input_and_options(single_op, new_inact)
        return _rank4_post_proc(builder, new_outact, orig_op=single_op)

    @pattern
    def rank5(self, op: Operator, **kwargs):
        if op.layertype in self.target_ops:
            inact = op.inacts[0]
            if inact.src_dim == 5:
                for ax in range(1, 5):
                    dim = inact.src_shape[ax]
                    if dim == 1 and not dim.dynamic:
                        return op, ax
        return None

    @rank5.transform
    def rank5(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        single_op, ax = self.matched_pattern
        inact = single_op.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_shape = tuple(x for i, x in enumerate(inact.src_shape) if i != ax)
        new_inact = builder.make_reshape(new_inact, new_shape)
        new_outact = builder.with_new_input_and_options(single_op, new_inact)
        old_outact = single_op.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(single_op)
        return builder.build()


@ShapeNormalizeDirect.register
class Biop(TransformRule):
    @pattern
    def rank_leq3(self, op: Operator, **kwargs):
        if is_biop_wrapper(op) and 1 <= op.inacts[0].src_dim < 4:
            return op
        return None

    @rank_leq3.transform
    def rank_leq3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop = self.matched_pattern
        new_inacts = _rank4_input_proc(builder, orig_op=biop)
        new_outact = builder.with_new_input_and_options(biop, *new_inacts)
        return _rank4_post_proc(builder, new_outact, orig_op=biop)

    @pattern
    def rank5(self, op: Operator, **kwargs):
        if is_biop_wrapper(op):
            inact0, inact1 = op.inacts
            if inact0.src_dim == inact1.src_dim == 5:
                for ax in range(1, 5):
                    dim0 = inact0.src_shape[ax]
                    dim1 = inact1.src_shape[ax]
                    if dim0 == dim1 == 1 and not dim0.dynamic and not dim1.dynamic:
                        return op, ax
        return None

    @rank5.transform
    def rank5(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop, ax = self.matched_pattern
        new_inacts = []
        for inact in biop.inacts:
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_shape = tuple(x for i, x in enumerate(inact.src_shape) if i != ax)
            new_inact = builder.make_reshape(new_inact, new_shape)
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(biop, *new_inacts)
        old_outact = biop.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(biop)
        return builder.build()


@ShapeNormalizeDirect.register
class BiopConstant(TransformRule):
    @pattern
    def rank_leq3(self, op: Operator, **kwargs):
        if is_biop_const(op) and 1 <= op.inacts[0].src_dim < 4:
            return op
        return None

    @rank_leq3.transform
    def rank_leq3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        xconst = self.matched_pattern
        new_inact = _rank4_input_proc(builder, orig_op=xconst)[0]
        new_outact = builder.with_new_input_and_options(xconst, new_inact)
        return _rank4_post_proc(builder, new_outact, orig_op=xconst)


@ShapeNormalizeDirect.register
class MatMul(TransformRule):
    @pattern
    def rank_leq3(self, matmul: Operator, **kwargs):
        if not (
            matmul.layertype == LayerType.MatMul and matmul.options.repeat[0] == -1
        ):
            return None
        if all(2 <= inact.src_dim <= 4 for inact in matmul.inacts) and any(
            inact.src_dim < 4 for inact in matmul.inacts
        ):
            return matmul
        return None

    @rank_leq3.transform
    def rank_leq3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        matmul = self.matched_pattern
        new_inacts = _rank4_input_proc(builder, orig_op=matmul)
        new_outact = builder.make_matmul(*new_inacts)
        return _rank4_post_proc(builder, new_outact, orig_op=matmul)

    @pattern
    def batched(self, op: Operator, **kwargs):
        """batched matmul"""
        if not (op.layertype == LayerType.MatMul and op.options.repeat[0] == -1):
            return None
        inact0, inact1 = op.inacts
        if inact0.src_dim != inact1.src_dim:
            return None
        b_left = inact0.src_shape[:-2]
        b_right = inact1.src_shape[:-2]
        if b_left != b_right:
            return None
        if any(x.dynamic for x in b_left) or any(x.dynamic for x in b_right):
            return None
        if inact0.src_dim == 4 and b_left[0] > 1:
            return op
        if inact0.src_dim > 4:
            return op
        return None

    @batched.transform
    def batched(self, *args, **kwargs):
        matmul = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = []
        for inact in matmul.inacts:
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_shape = (1, -1) + new_inact.src_shape[-2:]
            new_inact = builder.make_reshape(new_inact, new_shape)
            new_inacts.append(new_inact)
        new_outact = builder.make_matmul(*new_inacts)
        old_outact = matmul.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(matmul)
        return builder.build()


@ShapeNormalizeDirect.register
class Normalization(TransformRule):

    @pattern
    def rank_leq3(self, norm: Operator, **kwargs):
        if norm.layertype in NORMALIZATIONS and 2 <= norm.inacts[0].src_dim < 4:
            return norm
        return None

    @rank_leq3.transform
    def rank_leq3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        norm = self.matched_pattern
        kw = {}
        if norm.layertype in (LayerType.L1Normalization, LayerType.L2Normalization):
            missing_rank = 4 - norm.inacts[0].src_dim
            kw["norm_axis"] = tuple(
                ax if ax < 0 else ax + missing_rank for ax in norm.options.norm_axis
            )
        new_inact = _rank4_input_proc(builder, orig_op=norm)[0]
        new_outact = builder.with_new_input_and_options(norm, new_inact, **kw)
        return _rank4_post_proc(builder, new_outact, orig_op=norm)


@ShapeNormalizeDirect.register
class Reduce(TransformRule):
    @pattern
    def rank_leq3(self, op: Operator, **kwargs):
        if op.layertype not in REDUCE_OPS:
            return None
        if op.inacts[0].src_dim < 4:
            return op
        if op.inacts[0].src_dim == 4 and op.outacts[0].src_dim < 4:
            return op
        return None

    @rank_leq3.transform
    def rank_leq3(self, *args, **kwargs):
        reduce = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inact = _rank4_input_proc(builder, orig_op=reduce)[0]
        missing_rank = 4 - reduce.inacts[0].src_dim
        new_axes = tuple(
            ax if ax < 0 else ax + missing_rank for ax in reduce.options.reduce_axes
        )
        new_outact = builder.with_new_input_and_options(
            reduce, new_inact, keep_dims=True, reduce_axes=new_axes
        )
        return _rank4_post_proc(builder, new_outact, orig_op=reduce)

    @pattern
    def rank5(self, op: Operator, **kwargs):
        if op.layertype not in REDUCE_OPS:
            return None
        inact = op.inacts[0]
        if (
            inact.src_dim == 5
            and inact.src_shape[2] == 1
            and op.options.reduce_axes == (2, 3, 4)
            and op.options.keep_dims
        ):
            return op
        return None

    @rank5.transform
    def rank5(self, *args, **kwargs):
        reduce = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reduce.inacts[0]
        if (
            inact.src_dim == 5
            and inact.src_shape[2] == 1
            and reduce.options.reduce_axes == (2, 3, 4)
            and reduce.options.keep_dims
        ):
            n, c, b, h, w = inact.src_shape
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inact = builder.make_reshape(new_inact, (n, c, h, w))
            new_outact = builder.with_new_input_and_options(
                reduce, new_inact, keep_dims=True, reduce_axes=(2, 3)
            )
            n, h, w, c = new_outact.src_shape
            new_outact = builder.make_reshape(new_outact, (n, h, 1, w, c))
            old_outact = reduce.outacts[0]
            if new_outact.src_shape != old_outact.src_shape:
                new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(reduce)
            return builder.build()
        else:
            raise NotImplementedError("code should not reach here.")


@ShapeNormalizeDirect.register
class Slice(TransformRule):
    @pattern
    def rank_leq3(self, slice_: Operator, **kwargs):
        if slice_.layertype == LayerType.Slice and 2 <= slice_.inacts[0].src_dim < 4:
            return slice_
        return None

    @rank_leq3.transform
    def rank_leq3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        slice_ = self.matched_pattern
        new_inact = _rank4_input_proc(builder, orig_op=slice_)[0]
        missing_rank = 4 - slice_.inacts[0].src_dim
        new_axis = []
        for ax in slice_.options.axis:
            if ax < 0:
                new_axis.append(ax)
            else:
                new_axis.append(ax + missing_rank)
        new_outact = builder.with_new_input_and_options(
            slice_, new_inact, axis=new_axis
        )
        return _rank4_post_proc(builder, new_outact, orig_op=slice_)


@ShapeNormalizeDirect.register
class Transpose(TransformRule):
    @pattern
    def rank_leq3(self, transpose: Operator, **kwargs):
        if (
            transpose.layertype == LayerType.Transpose
            and 2 <= transpose.inacts[0].src_dim < 4
        ):
            return transpose
        return None

    @rank_leq3.transform
    def rank_leq3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose = self.matched_pattern
        new_inact = _rank4_input_proc(builder, orig_op=transpose)[0]
        missing_rank = 4 - transpose.inacts[0].src_dim
        new_axes = tuple(range(missing_rank)) + tuple(
            x + missing_rank for x in transpose.options.transpose_axes
        )
        new_outact = builder.make_transpose(new_inact, transpose_axes=new_axes)
        return _rank4_post_proc(builder, new_outact, orig_op=transpose)


@ShapeNormalizeDirect.register
class Concatenate(TransformRule):

    @pattern
    def rank_leq3(self, concat: Operator, **kwargs):
        if (
            concat.layertype == LayerType.Concatenate
            and 2 <= concat.inacts[0].src_dim < 4
        ):
            return concat
        return None

    @rank_leq3.transform
    def rank_leq3(self, *args, **kwargs):
        concat = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = _rank4_input_proc(builder, orig_op=concat)
        new_axis = concat.options.axis  # 0,1,2
        if new_axis >= 0:
            new_axis += 4 - concat.inacts[0].src_dim
        new_outact = builder.make_concatenate(new_inacts, axis=new_axis)
        return _rank4_post_proc(builder, new_outact, orig_op=concat)


@ShapeNormalizeDirect.register
class Expand(TransformRule):
    @pattern
    def rank_leq3(self, op: Operator, **kwargs):
        if op.layertype == LayerType.Expand and 2 <= op.inacts[0].src_dim < 4:
            return op
        return None

    @rank_leq3.transform
    def rank_leq3(self, *args, **kwargs):
        expand = self.matched_pattern
        builder = OpTransformResultV2Builder()
        expand_size = expand.get_tensor(expand.options.constant).value
        if len(expand_size) < 4:
            expand_size = [1] * (4 - len(expand_size)) + [int(x) for x in expand_size]
            expand_size = numpy.array(expand_size)
        new_inact = _rank4_input_proc(builder, orig_op=expand)[0]
        new_outact = builder.make_expand(new_inact, expand_size)
        return _rank4_post_proc(builder, new_outact, orig_op=expand)

    @pattern
    def rank5(self, op: Operator, **kwargs):
        if op.layertype == LayerType.Expand and not op.options.is_const_first:
            inact = op.inacts[0]
            if inact.src_dim == 5:
                for ax in range(1, 5):
                    dim = inact.src_shape[ax]
                    if dim == 1 and not dim.dynamic:
                        constant = op.get_tensor(op.options.constant).value
                        if constant.shape == (5,) and constant[ax] == 1:
                            return op, ax
        return None

    @rank5.transform
    def rank5(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        expand, ax = self.matched_pattern
        inact = expand.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_shape = tuple(x for i, x in enumerate(inact.src_shape) if i != ax)
        new_inact = builder.make_reshape(new_inact, new_shape)
        const_value = expand.get_tensor(expand.options.constant).value
        new_const_value = list(int(x) for x in const_value)
        new_const_value = list(x for i, x in enumerate(new_const_value) if i != ax)
        new_const_value = numpy.array(new_const_value)
        new_outact = builder.with_new_input_and_options(
            expand, new_inact, constant=new_const_value
        )
        old_outact = expand.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(expand)
        return builder.build()


@ShapeNormalizeDirect.register
class Softmax(TransformRule):

    @pattern
    def rank_leq3(self, op: Operator, **kwargs):
        if op.layertype == LayerType.Softmax and 1 <= op.inacts[0].src_dim < 4:
            return op
        return None

    @rank_leq3.transform
    def rank_leq3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        single_op = self.matched_pattern
        new_inact = _rank4_input_proc(builder, orig_op=single_op)[0]
        kw = {}
        missing_rank = 4 - single_op.inacts[0].src_dim
        if single_op.options.axis < 0:
            kw["axis"] = single_op.options.axis
        else:
            kw["axis"] = single_op.options.axis + missing_rank
        new_outact = builder.with_new_input_and_options(single_op, new_inact, **kw)
        return _rank4_post_proc(builder, new_outact, orig_op=single_op)

    @pattern
    def batchN(self, op: Operator, **kwargs):
        if (
            op.layertype == LayerType.Softmax
            and op.inacts[0].src_dim == 4
            and op.options.axis in (2, 3, -2, -1)
        ):
            inact_shape = op.inacts[0].src_shape
            if inact_shape[0] > 1 and inact_shape[1] == 1:
                return op
        return None

    @batchN.transform
    def batchN(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        softmax = self.matched_pattern
        inact = softmax.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_inact, (1, 0, 2, 3))
        new_outact = builder.make_softmax(new_outact, axis=softmax.options.axis)
        new_outact = builder.make_transpose(new_outact, (1, 0, 2, 3))
        old_outact = softmax.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(softmax)
        return builder.build()


@ShapeNormalizeDirect.register
class PadGeneric(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype == LayerType.PadGeneric:
            inact = op.inacts[0]
            outact = op.outacts[0]
            if inact.src_dim == outact.src_dim and inact.src_dim < 4:
                return op
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        pad_op = self.matched_pattern
        inact = pad_op.inacts[0]
        rank = inact.src_dim
        missing = 4 - rank
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_shape = (1,) * missing + inact.src_shape
        new_outact = builder.make_reshape(new_inact, new_shape)
        pad_front = list(pad_op.options.padding_list[:rank])
        pad_back = list(pad_op.options.padding_list[rank:])
        pad_front_new = [0] * missing + pad_front
        pad_back_new = [0] * missing + pad_back
        padding_list = tuple(pad_front_new + pad_back_new)
        new_outact = builder.with_new_input_and_options(
            pad_op, new_outact, padding_list=padding_list
        )
        old_outact = pad_op.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(pad_op)
        return builder.build()
