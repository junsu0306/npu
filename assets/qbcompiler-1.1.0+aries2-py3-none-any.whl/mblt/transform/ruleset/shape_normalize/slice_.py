from mblt.core import pattern
from mblt.operator import Operator
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
)
from mblt.transform.graph_transform import TransformRule
from mblt.transform.transform_result import OpTransformResultV2Builder

from ._ruleset import ShapeNormalizeContextual


@ShapeNormalizeContextual.register
class Slice(TransformRule):

    @pattern
    def slice_batch_n(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[1n(hw)c->nhwc] S[3]")
        if pat is None:
            return None
        reshape, slice_ = pat
        return reshape, slice_

    @slice_batch_n.transform
    def slice_batch_n(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, slice_ = self.matched_pattern
        reshape_inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(reshape_inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_inact)

        reshape_outact = reshape.outacts[0]
        n, h, w, c = reshape_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, h, w, -1))
        old_outact = slice_.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, slice_)
        return builder.build()

    @pattern
    def case_reshape_slice(self, op: Operator, **kwargs):
        """reshape-slice."""
        pat = find_operator_sequence(op, "RS")
        if pat is None:
            return None
        reshape, slice_ = pat
        if len(slice_.options.axis) > 1:
            return None
        reshape_inact = reshape.inacts[0]
        if reshape_inact.src_dim != 4:
            return None
        slice_inact = slice_.inacts[0]
        if slice_inact.src_dim <= 4:
            return None
        ax = slice_.options.axis[0]
        if ax < 0:
            ax += slice_inact.src_dim
        # check from front
        if reshape_inact.src_shape[: ax + 1] == slice_inact.src_shape[: ax + 1]:
            return reshape, slice_
        # check from backward
        ax -= slice_inact.src_dim
        if reshape_inact.src_shape[ax:] == slice_inact.src_shape[ax:]:
            return reshape, slice_
        return None

    @case_reshape_slice.transform
    def case_reshape_slice(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()

        reshape, slice_ = self.matched_pattern
        reshape_inact = reshape.inacts[0]
        reshape_outact = reshape.outacts[0]
        slice_inact = slice_.inacts[0]
        slice_outact = slice_.outacts[0]
        ax = slice_.options.axis[0]
        if ax < 0:
            ax += slice_inact.src_dim
        new_outact = builder.copy_activationspec(reshape_inact, add_input_map=True)
        if reshape_inact.src_shape[: ax + 1] == slice_inact.src_shape[: ax + 1]:
            new_outact = builder.with_new_input_and_options(
                slice_, new_outact, axis=(ax,)
            )
            new_shape = (
                new_outact.src_shape[: ax + 1] + reshape_outact.src_shape[ax + 1 :]
            )
        else:
            ax -= slice_inact.src_dim
            new_outact = builder.with_new_input_and_options(
                slice_, new_outact, axis=(ax,)
            )
            new_shape = reshape_outact.src_shape[:ax] + new_outact.src_shape[ax:]
        new_outact = builder.make_reshape(new_outact, new_shape)
        builder.add_output_map(new_outact, slice_outact)
        builder.remove_connectivity_and_invalidate(reshape, slice_)
        return builder.build()

    @pattern
    def case_reshape_slice2(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[n1w(cd)->n1wcd] S")
        if pat is None:
            return None
        reshape, slice_ = pat
        ax_targets = (2, 3, 4, -3, -2, -1)
        if 1 == len(slice_.options.axis) and slice_.options.axis[0] in ax_targets:
            return reshape, slice_
        return None

    @case_reshape_slice2.transform
    def case_reshape_slice2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, slice_ = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        ax = slice_.options.axis[0]
        if ax > 0:
            ax -= 1
        n, h, w, c, d = reshape.outacts[0].src_shape
        new_outact = builder.make_reshape(new_inact, (n, w, c, d))
        new_outact = builder.with_new_input_and_options(slice_, new_outact, axis=(ax,))
        old_outact = slice_.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, slice_)
        return builder.build()
    @pattern
    def case_reshape_slice3(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[nhw(cd)->nhwcd] S")
        if pat is None:
            return None
        reshape, slice_ = pat
        ax_targets = (3, 4, -2, -1)
        if 1 == len(slice_.options.axis) and slice_.options.axis[0] in ax_targets:
            return reshape, slice_
        return None

    @case_reshape_slice3.transform
    def case_reshape_slice3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, slice_ = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        ax = slice_.options.axis[0]
        if ax > 0:
            ax -= 1
        n, h, w, c, d = reshape.outacts[0].src_shape
        new_outact = builder.make_reshape(new_inact, (n, -1, c, d))
        new_outact = builder.with_new_input_and_options(slice_, new_outact, axis=(ax,))
        old_outact = slice_.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, slice_)
        return builder.build()

    @pattern
    def case_transpose_slice(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T1023 S[0]")
        if pat is None:
            return None
        transpose, slice_ = pat
        slice_inact = slice_.inacts[0]
        if slice_inact.src_shape[0] > 1:
            return transpose, slice_
        return None

    @case_transpose_slice.transform
    def case_transpose_slice(self, *args, **kwargs):
        transpose, slice_ = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_inact, axis=(1,))
        new_outact = builder.make_transpose(new_outact, (1, 0, 2, 3))
        old_outact = slice_.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, slice_)
        return builder.build()
