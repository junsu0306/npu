from mblt.core import RuleSet

ShapeNormalizeDirect = RuleSet("ShapeNormalizeDirect")

ShapeNormalizeContextual = RuleSet("ShapeNormalizeContextual")

__all__ = ["ShapeNormalizeDirect", "ShapeNormalizeContextual"]
