from mblt import LayerType
from mblt.core import pattern
from mblt.operator import Operator
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
)
from mblt.transform.graph_transform import TransformRule
from mblt.transform.transform_result import OpTransformResultV2Builder
from ._ruleset import ShapeNormalizeContextual


@ShapeNormalizeContextual.register
class Reshape(TransformRule):
    @pattern
    def reshape_matmul(self, reshape: Operator, **kwargs):
        """
        (1,256,16,64)-[reshape]->(1,1,256,16,64)-[matmul]-[1,4,256,16,64]
        we make indexed_item_selector
        """
        pat = find_operator_sequence(reshape, "R[1hwc->11hwc]")
        if pat is None:
            return None
        reshape_outact = reshape.outacts[0]
        for matmul in reshape_outact.consumer_ops:
            if matmul.layertype == LayerType.MatMul and matmul.options.repeat[0] == -1:
                right_inact = matmul.inacts[1]
                if right_inact.name == reshape_outact.name:
                    return reshape, matmul
        return None

    @reshape_matmul.transform
    def reshape_matmul(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, matmul = self.matched_pattern
        reshape_outact = reshape.outacts[0]
        new_inact = builder.copy_activationspec(reshape_outact, add_input_map=True)
        matmul_outact = matmul.outacts[0]
        repeat = int(matmul_outact.src_shape[1])
        new_right_inact = builder.make_indexed_item_selector(
            new_inact, axis=1, repeat=repeat
        )
        matmul_left_inact = matmul.inacts[0]
        new_left_inact = builder.copy_activationspec(
            matmul_left_inact, add_input_map=True
        )
        assert new_right_inact.src_shape[:-2] == matmul_left_inact.src_shape[:-2]
        new_outact = builder.make_matmul(new_left_inact, new_right_inact)
        builder.add_output_map(new_outact, matmul_outact)
        builder.remove_connectivity_and_invalidate(matmul)

        return builder.build()

    @pattern
    def batched_reshaphe(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[1chwde->(ch)wde] R")
        if pat is not None:
            reshape0, reshape1 = pat
            if reshape1.outacts[0].src_shape[0] == 1:
                return reshape0, reshape1
        return None

    @batched_reshaphe.transform
    def batched_reshaphe(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, reshape1 = self.matched_pattern
        inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        old_outact = reshape1.outacts[0]
        new_outact = builder.make_reshape(new_inact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, reshape1)
        return builder.build()
