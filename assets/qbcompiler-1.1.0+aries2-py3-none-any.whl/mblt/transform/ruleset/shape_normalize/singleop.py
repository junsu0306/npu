import operator

import numpy

from mblt import LayerType
from mblt.core import pattern
from mblt.operator import Operator
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    is_actfunc_type,
    is_biop_const,
)
from mblt.transform.graph_transform import TransformRule
from mblt.transform.transform_result import OpTransformResultV2Builder
from ._ruleset import ShapeNormalizeContextual


def single_op_check(op):
    return (
        is_actfunc_type(op)
        or op.layertype == LayerType.Softmax
        or op.layertype == LayerType.Pow
        or op.layertype == LayerType.L2Normalization
    )


@ShapeNormalizeContextual.register
class SingleOp(TransformRule):
    @pattern
    def rank5(self, op: Operator, **kwargs):
        """
        simple op or op with axis=-1
        """
        pat = find_operator_sequence(op, "R", single_op_check)
        if pat is None:
            return None
        reshape, single_op = pat
        reshape_inact = reshape.inacts[0]
        reshape_ouatct = reshape.outacts[0]
        if not (
            reshape_inact.src_dim == 4
            and reshape_ouatct.src_dim == 5
            and reshape_inact.src_shape[0] == reshape_ouatct.src_shape[0] == 1
            and reshape_inact.src_shape[-1] == reshape_ouatct.src_shape[-1]
        ):
            return None

        rank = int(single_op.inacts[0].src_dim)
        if single_op.layertype == LayerType.Softmax:
            axis = int(single_op.options.axis)
            if axis not in (rank - 1, -1):
                return None
        if single_op.layertype in (LayerType.L2Normalization,):
            rank = int(single_op.inacts[0].src_dim)
            norm_axis = op.options.norm_axis
            if norm_axis not in ((-1,), (rank - 1,)):
                return None
        return pat

    @rank5.transform
    def rank5(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, single_op = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        if single_op.layertype == LayerType.Softmax:
            new_outact = builder.make_softmax(
                new_inact, axis=-1, beta=single_op.options.beta
            )
        elif single_op.layertype == LayerType.L2Normalization:
            new_outact = builder.make_l2normalization(
                new_inact, norm_axis=(-1,), epsilon=single_op.options.epsilon
            )
        else:
            new_outact = builder.with_new_input_and_options(single_op, new_inact)
        old_outact = single_op.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, single_op)
        return builder.build()

    @pattern
    def batch_n(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[1(bh)wc->bhwc]", single_op_check)
        if pat is not None:
            reshape, single_op = pat
            if single_op.layertype == LayerType.Softmax:
                axis = single_op.options.axis
                if axis < 0:
                    axis += 4
                if axis in (0, 1):
                    return None
            if single_op.layertype in (LayerType.L2Normalization,):
                rank = int(single_op.inacts[0].src_dim)
                norm_axis = op.options.norm_axis
                if norm_axis not in ((-1,), (rank - 1,)):
                    return None
            return pat
        return None

    @batch_n.transform
    def batch_n(self, *args, **kwargs):
        reshape, single_op = self.matched_pattern
        builder = OpTransformResultV2Builder()
        reshape_inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(reshape_inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(single_op, new_inact)
        reshape_outact = reshape.outacts[0]
        new_outact = builder.make_reshape(new_outact, reshape_outact.src_shape)
        old_outact = single_op.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, single_op)
        return builder.build()


@ShapeNormalizeContextual.register
class BiopConstant(TransformRule):
    @pattern
    def batched(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R", is_biop_const)
        if pat is None:
            return None
        reshape, xconst = pat
        # we don't decrease rank of xconst.
        if reshape.inacts[0].src_dim < 4 and xconst.inacts[0].src_dim == 4:
            return None
        return reshape, xconst

    @batched.transform
    def batched(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, xconst = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        const = xconst.get_tensor(xconst.options.constant).value
        reshape_outact = reshape.outacts[0]

        if const.size == 1 or const.ndim == 0:
            new_const = const.reshape(-1)
        else:
            if (
                inact.src_shape[-1] == reshape_outact.src_shape[-1]
                and (int(inact.src_shape[-1]),) == const.shape
            ):
                new_const = const
            else:
                new_const = (
                    numpy.zeros(
                        tuple(map(int, reshape_outact.src_shape)), dtype=const.dtype
                    )
                    + const
                )
                new_const = new_const.reshape(tuple(map(int, new_inact.src_shape)))

        new_outact = builder.with_new_input_and_options(
            xconst, new_inact, constant=new_const
        )
        new_outact = builder.make_reshape(new_outact, reshape_outact.src_shape)
        old_outact = xconst.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, xconst)

        return builder.build()

    @pattern
    def rank5(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R", is_biop_const)
        if pat is None:
            return None
        reshape, xconst = pat
        if not (reshape.inacts[0].src_dim == 4 and reshape.outacts[0].src_dim == 5):
            return None
        inact = xconst.inacts[0]
        const_value = xconst.get_tensor(xconst.options.constant).value
        if inact.src_shape[0] > 1:
            return None
        for ax in range(1, 5):
            dim = inact.src_shape[ax]
            if dim == 1 and not dim.dynamic:
                if const_value.size == 1:
                    return reshape, xconst, ax
                if const_value.ndim == 5 and const_value.shape[ax] == 1:
                    return reshape, xconst, ax
        return None

    @rank5.transform
    def rank5(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, biop_const, ax = self.matched_pattern

        inact = biop_const.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_shape = tuple(x for i, x in enumerate(inact.src_shape) if i != ax)
        new_inact = builder.make_reshape(new_inact, new_shape)
        const_value = biop_const.get_tensor(biop_const.options.constant).value
        if const_value.size == 1:
            new_const_value = const_value
        elif const_value.ndim == 5:
            new_shape = tuple(
                int(x) for i, x in enumerate(const_value.shape) if i != ax
            )
            new_const_value = const_value.reshape(new_shape)
        else:
            raise NotImplementedError("code should not reached here!")
        new_outact = builder.with_new_input_and_options(
            biop_const, new_inact, constant=new_const_value
        )
        old_outact = biop_const.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(biop_const)
        return builder.build()


@ShapeNormalizeContextual.register
class ReduceSum(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T0213 R[1(nh)1c->nh1c]", LayerType.ReduceSum)
        transpose = None
        if pat is not None:
            transpose, reshape, reduce = pat
        else:
            pat = find_operator_sequence(op, "R[1(nh)1c->nh1c]", LayerType.ReduceSum)
            if pat is None:
                return None
            reshape, reduce = pat
        if not (op.options.reduce_axes == (1,) and op.options.keep_dims):
            return None
        reduce_inact = reduce.inacts[0]
        if reduce_inact.src_shape[0] > 1 and not reduce_inact.src_shape[2].dynamic:
            return transpose, reshape, reduce
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        transpose, reshape, reduce = self.matched_pattern
        builder = OpTransformResultV2Builder()
        if transpose is not None:
            transpose_inact = transpose.inacts[0]
            new_inact = builder.copy_activationspec(transpose_inact, add_input_map=True)
        else:
            reshape_inact = reshape.inacts[0]
            new_inact = builder.copy_activationspec(reshape_inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        n, h, w, c = reshape_outact.src_shape
        new_outact = builder.make_reshape(new_inact, (1, n, h, c))
        new_outact = builder.with_new_input_and_options(
            reduce, new_outact, reduce_axes=(2,)
        )
        old_outact = reduce.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        if transpose is not None:
            builder.remove_connectivity_and_invalidate(transpose, reshape, reduce)
        else:
            builder.remove_connectivity_and_invalidate(reshape, reduce)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        """skresnet18
        (1,56,56,128)-[reshape]->(1,56,56,2,64)-[transpose03412]->(1,2,64,56,56)-[reducesum axis=1]->(1,64,56,56)
        =>
        (1,56,56,128)-[reshape]->(1,3136,2,64)-[reducesum axis=2]->(1,3136,1,64)-[reshape]->(1,56,56,64)-[transpose0312]->(1,64,56,56)
        """
        pat = find_operator_sequence(
            op, "R[1hw(bc)->1hwbc] T03412", LayerType.ReduceSum
        )
        if pat is None:
            return None
        reshape, transpose, reduce = pat
        if reduce.options.reduce_axes != (1,):
            return None
        n, h, w, ndiv, c = map(int, reshape.outacts[0].src_shape)
        if (
            (h > 1 and w > 1)
            or (h == 1 and not h.dynamic)
            or (w == 1 and not w.dynamic)
        ):
            return reshape, transpose, reduce
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, transpose, reduce = self.matched_pattern
        reshape_inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(reshape_inact, add_input_map=True)
        n, h, w, ndiv, c = map(int, reshape.outacts[0].src_shape)
        new_outact = builder.make_reshape(new_inact, (n, -1, ndiv, c))
        new_outact = builder.with_new_input_and_options(
            reduce, new_outact, reduce_axes=(2,)
        )
        new_outact = builder.make_reshape(new_outact, (n, h, w, c))
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = reduce.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, transpose, reduce)
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T03412", LayerType.ReduceSum)
        if pat is None:
            return None
        t03412, reduce = pat
        return t03412, reduce

    @case2.transform
    def case2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reduce = self.matched_pattern
        transpose_inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(transpose_inact, add_input_map=True)
        reduce_axes = tuple(
            transpose.options.transpose_axes[x] for x in reduce.options.reduce_axes
        )
        new_outact = builder.with_new_input_and_options(
            reduce, new_inact, reduce_axes=reduce_axes, keep_dims=True
        )
        new_outact = builder.make_transpose(
            new_outact, transpose.options.transpose_axes
        )
        old_outact = reduce.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reduce)
        return builder.build()

    @pattern
    def case3(self, op: Operator, **kwargs):
        if op.layertype == LayerType.ReduceSum and op.options.reduce_axes == (0,):
            pat = find_operator_sequence(
                op, "T03412 R[1abcd->a1bcd]", LayerType.ReduceSum
            )
            if pat is None:
                return None
            transpose, reshape, reduce = pat
            reshape_outact = reshape.outacts[0]
            if reshape_outact.src_shape[0] > 1:
                return transpose, reshape, reduce
            return None

    @case3.transform
    def case3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape, reduce = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        pre_axis = transpose.options.transpose_axes[1]
        new_outact = builder.with_new_input_and_options(
            reduce, new_inact, reduce_axes=(pre_axis,), keep_dims=False
        )
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = reduce.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape, reduce)
        return builder.build()


@ShapeNormalizeContextual.register
class Where(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        cond: (1,1,160)
        x: inputconst()
        y: (4,1,32,160)

        cond: (1,256,16)
        x: inputconst()
        y: (1,256,16)
        """
        pat = find_operator_sequence(op, LayerType.Where)
        if pat is None:
            return None
        where = pat[0]
        if 3 != len(where.options.inputs):
            return None

        cond, x, y = where.inacts
        if not (cond.src_dim == 3 and cond.src_shape[0] == 1):  # for broadcasting n,h
            return None

        xconst = x.producer_op
        if not (
            xconst.layertype == LayerType.InputConstant
            and (xconst.get_tensor(xconst.options.constant).value.size == 1)
        ):
            return None

        if y.src_dim in (3, 4):
            return where
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        where = self.matched_pattern
        builder = OpTransformResultV2Builder()
        cond, x, y = where.inacts
        new_cond = builder.copy_activationspec(cond, add_input_map=True)
        new_cond = builder.make_reshape(new_cond, (1,) + cond.src_shape)

        x_const = x.producer_op
        x_const_val = x_const.get_tensor(x_const.options.constant).value.reshape(
            1, 1, 1, -1
        )
        new_x = builder.make_inputconst(constant=x_const_val)
        if new_x.src_dim != 4:
            new_x = builder.make_reshape(new_x, (1, 1, 1, x_const_val.size))

        new_y = builder.copy_activationspec(y, add_input_map=True)
        if (new_y.src_dim == 4 and new_y.src_shape[0] > 1) or new_y.src_dim == 3:
            new_shape = (1, -1) + new_y.src_shape[-2:]
            new_y = builder.make_reshape(new_y, new_shape)
        new_outact = builder.make_where(new_cond, new_x, new_y)
        old_outact = where.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(where)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        """
        cond: (32,1,384)
        x: (32,1,384)
        y: (32,1,384)

        """
        pat = find_operator_sequence(op, LayerType.Where)
        if pat is None:
            return None
        where = pat[0]
        if 3 != len(where.options.inputs):
            return None

        cond, x, y = where.inacts
        if not (cond.src_dim == 3 and cond.src_shape == x.src_shape == y.src_shape):
            return None
        return where

    @case1.transform
    def case1(self, *args, **kwargs):
        where = self.matched_pattern
        builder = OpTransformResultV2Builder()
        cond, x, y = where.inacts
        new_cond = builder.copy_activationspec(cond, add_input_map=True)
        new_cond = builder.make_reshape(new_cond, (1,) + cond.src_shape)
        new_x = builder.copy_activationspec(x, add_input_map=True)
        new_x = builder.make_reshape(new_x, (1,) + x.src_shape)
        new_y = builder.copy_activationspec(y, add_input_map=True)
        new_y = builder.make_reshape(new_y, (1,) + y.src_shape)
        new_outact = builder.make_where(new_cond, new_x, new_y)
        old_outact = where.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(where)
        return builder.build()


@ShapeNormalizeContextual.register
class Expand(TransformRule):

    @pattern
    def batch_expand(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.Expand, "R[bhwc->1b(hw)c]")
        if pat is None:
            return None
        expand, reshape = pat
        in_shape = expand.inacts[0].src_shape
        outshape = expand.outacts[0].src_shape
        if not (
            len(in_shape) == 4
            and 1 == in_shape[0] < outshape[0]
            and in_shape[1:] == outshape[1:]
        ):
            return None
        return expand, reshape

    @batch_expand.transform
    def batch_expand(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        expand, reshape = self.matched_pattern
        inact = expand.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        n, h, w, c = new_inact.src_shape
        new_outact = builder.make_reshape(new_inact, (n, 1, -1, c))
        expand_size = int(expand.get_tensor(expand.options.constant).value[0])
        n, h, w, c = new_outact.src_shape
        assert h == 1
        sizes = tuple(map(int, (n, expand_size, w, c)))
        new_outact = builder.make_resize(
            new_outact,
            sizes=sizes,
            resize_type="nearest",
            transform_mode="asymmetric",
        )
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(expand, reshape)
        return builder.build()


@ShapeNormalizeContextual.register
class IndexedItemSelector(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.IndexedItemSelector)
        if pat is None:
            return None
        selector = pat[0]
        inact = selector.inacts[0]
        if not (
            inact.src_dim == 4
            and inact.src_shape[0] > 1
            and inact.src_shape[1:3] == (1, 1)
        ):
            return None
        if not (
            selector.options.axis == 1
            and selector.options.repeat is not None
            and selector.options.repeat > 1
        ):
            return None
        return selector

    @case0.transform
    def case0(self, *args, **kwargs):
        selector = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = selector.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        shape = (1,) + tuple(
            map(int, operator.itemgetter(0, 1, 3)(new_inact.src_shape))
        )
        new_outact = builder.make_reshape(new_inact, shape)
        new_outact = builder.with_new_input_and_options(selector, new_outact, axis=2)
        old_outact = selector.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(selector)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        """
        (1,d,hw,c)->(1,d,h,w,c)->[selector axis=-1]->(1,d,h,w,c1)
        """
        pat = find_operator_sequence(
            op, "R[1d(hw)c->1dhwc]", LayerType.IndexedItemSelector
        )
        if pat is None:
            return None
        reshape, selector = pat
        if selector.options.axis in (-1, 4):
            return reshape, selector
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, selector = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(selector, new_inact, axis=-1)
        old_outact = selector.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, selector)
        return builder.build()


@ShapeNormalizeContextual.register
class Softmax(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[111(cd)->1cd11]", LayerType.Softmax)
        if pat is None:
            return None
        reshape, softmax = pat
        if softmax.options.axis in (1, 2, -3, -4):
            return reshape, softmax
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, softmax = self.matched_pattern
        inact = reshape.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        n, c, d, h, w = reshape_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, 1, c, d))
        axis = softmax.options.axis
        if axis < 0:
            axis += 5
        axis = axis + 1
        new_outact = builder.with_new_input_and_options(softmax, new_outact, axis=axis)
        old_outact = softmax.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(softmax)
        return builder.build()
