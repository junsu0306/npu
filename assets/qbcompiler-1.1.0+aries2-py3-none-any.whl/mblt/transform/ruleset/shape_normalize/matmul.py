from mblt import LayerType
from mblt.core import pattern
from mblt.operator import Operator
from mblt.subgraph.util.pattern_util import find_operator_sequence, is_transpose
from mblt.transform.graph_transform import TransformRule
from mblt.transform.transform_result import OpTransformResultV2Builder
from ._ruleset import ShapeNormalizeContextual


def _check_repeat_chain(inact):
    """
    Check if the inact's producer chain matches:

    Pattern A (no transpose):
        Reshape[1hwc->1h1wc] -> IndexedItemSelector(axis=2, repeat=n) -> Reshape[1abwc->1(ab)wc]

    Pattern B (with transpose):
        Reshape[1hwc->1h1wc] -> IndexedItemSelector(axis=2, repeat=n) -> Reshape[1abwc->1(ab)wc] -> Transpose(0,1,3,2)

    Returns:
        (repeat_value, (reshape1, idxsel, reshape2), original_inact, transpose_op) or None.
        transpose_op is None for Pattern A.
    """
    producer = inact.producer_op
    if producer is None or not producer.valid:
        return None

    # Try Pattern B first: with Transpose(0,1,3,2) at the end
    if is_transpose(producer, axes=(0, 1, 3, 2)):
        transpose_op = producer
        transpose_inact = transpose_op.inacts[0]
        pat = find_operator_sequence(
            transpose_inact.producer_op,
            "R[1hwc->1h1wc]",
            LayerType.IndexedItemSelector,
            "R[1abwc->1(ab)wc]",
        )
        if pat is not None:
            reshape1, idxsel, reshape2 = pat
            if idxsel.options.axis == 2 and idxsel.options.repeat is not None:
                original_inact = reshape1.inacts[0]
                return (
                    idxsel.options.repeat,
                    (reshape1, idxsel, reshape2),
                    original_inact,
                    transpose_op,
                )

    # Try Pattern A: no transpose
    pat = find_operator_sequence(
        producer,
        "R[1hwc->1h1wc]",
        LayerType.IndexedItemSelector,
        "R[1abwc->1(ab)wc]",
    )
    if pat is not None:
        reshape1, idxsel, reshape2 = pat
        if idxsel.options.axis == 2 and idxsel.options.repeat is not None:
            original_inact = reshape1.inacts[0]
            return (
                idxsel.options.repeat,
                (reshape1, idxsel, reshape2),
                original_inact,
                None,
            )

    return None


@ShapeNormalizeContextual.register
class Matmul(TransformRule):
    # @pattern
    # def indexed_item_selector_reshape(self, op: Operator, **kwargs):
    #     if not (op.layertype == LayerType.MatMul and op.options.repeat[0] == -1):
    #         return None
    #     left_inact = op.inacts[0]
    #     right_inact = op.inacts[1]
    #     if not (left_inact.src_dim == right_inact.src_dim == 4):
    #         return None
    #     pat = find_operator_sequence(
    #         right_inact.producer_op, LayerType.IndexedItemSelector, "R[1abwc->1(ab)wc]"
    #     )
    #     if pat is None:
    #         return None
    #     item_selector, reshape = pat
    #     if item_selector.options.axis == 1 and item_selector.options.repeat is not None:
    #         return item_selector, reshape, op
    #     return None
    #
    # @indexed_item_selector_reshape.transform
    # def indexed_item_selector_reshape(self, *args, **kwargs):
    #     item_selector, reshape, matmul = self.matched_pattern
    #     builder = OpTransformResultV2Builder()
    #     left_inact = matmul.inacts[0]
    #     new_left_inact = builder.copy_activationspec(left_inact, add_input_map=True)
    #     repeat = (1, item_selector.options.repeat)
    #     item_selector_inact = item_selector.inacts[0]
    #     new_right_inact = builder.copy_activationspec(
    #         item_selector_inact, add_input_map=True
    #     )
    #     a, b, c, d, e = new_right_inact.src_shape
    #     new_right_inact = builder.make_reshape(new_right_inact, (a, c, d, e))
    #     new_outact = builder.make_matmul(new_left_inact, new_right_inact, repeat=repeat)
    #     old_outact = matmul.outacts[0]
    #     builder.add_output_map(new_outact, old_outact)
    #     builder.remove_connectivity_and_invalidate(item_selector, reshape, matmul)
    #     return builder.build()

    @pattern
    def indexed_item_selector_reshape_2(self, op: Operator, **kwargs):
        """
        Match matmul where either/both inputs have the pattern:
          (1,8,51,64) -> Reshape -> (1,8,1,51,64)
            -> IndexItemSelector(axis=2, repeat=n) -> (1,8,n,51,64)
            -> Reshape -> (1,8n,51,64)
        optionally followed by Transpose(0,1,3,2).

        Fuses the Reshape-IndexItemSelector-Reshape chain into the matmul's repeat parameter.
        If left side has repeat=n and right side has repeat=m, repeat=(n, m).
        When Transpose(0,1,3,2) is present, it is kept (recreated from the original input).
        """
        if op.layertype != LayerType.MatMul:
            return None
        if op.options.repeat != (-1, -1):
            return None

        left_inact, right_inact = op.inacts
        left_result = _check_repeat_chain(left_inact)
        right_result = _check_repeat_chain(right_inact)

        if left_result is None and right_result is None:
            return None

        return left_result, right_result, op

    @indexed_item_selector_reshape_2.transform
    def indexed_item_selector_reshape_2(self, *args, **kwargs):
        left_result, right_result, matmul = self.matched_pattern
        builder = OpTransformResultV2Builder()

        repeat_left = 1
        repeat_right = 1

        # --- Process left input ---
        if left_result is not None:
            repeat_val, (reshape1, idxsel, reshape2), original_inact, transpose_op = (
                left_result
            )
            repeat_left = repeat_val
            new_left = builder.copy_activationspec(original_inact, add_input_map=True)
            if transpose_op is not None:
                new_left = builder.make_transpose(new_left, transpose_axes=(0, 1, 3, 2))
                builder.remove_connectivity_and_invalidate(
                    reshape1, idxsel, reshape2, transpose_op, matmul
                )
            else:
                builder.remove_connectivity_and_invalidate(
                    reshape1, idxsel, reshape2, matmul
                )
        else:
            new_left = builder.copy_activationspec(matmul.inacts[0], add_input_map=True)

        # --- Process right input ---
        if right_result is not None:
            repeat_val, (reshape1, idxsel, reshape2), original_inact, transpose_op = (
                right_result
            )
            repeat_right = repeat_val
            new_right = builder.copy_activationspec(original_inact, add_input_map=True)
            if transpose_op is not None:
                new_right = builder.make_transpose(
                    new_right, transpose_axes=(0, 1, 3, 2)
                )
                builder.remove_connectivity_and_invalidate(
                    reshape1, idxsel, reshape2, transpose_op, matmul
                )
            else:
                builder.remove_connectivity_and_invalidate(
                    reshape1, idxsel, reshape2, matmul
                )
        else:
            new_right = builder.copy_activationspec(
                matmul.inacts[1], add_input_map=True
            )

        builder.add_invalidate_ops(matmul)

        # Build new matmul with repeat
        repeat = (repeat_left, repeat_right)
        new_outact = builder.make_matmul(new_left, new_right, repeat=repeat)

        old_outact = matmul.outacts[0]
        builder.add_output_map(new_outact, old_outact)

        return builder.build()
