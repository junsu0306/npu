from mblt import Operator, LayerType
from mblt.core import TransformRule, pattern
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    check_input_npu_stride,
)
from mblt.transform.ruleset.dataflow import DataFlowRuleSet
from mblt.transform.transform_result import OpTransformResultV2Builder


@DataFlowRuleSet.register
class InstanceNormGrouping(TransformRule):
    @pattern
    def group_order1(self, op: Operator, **kwargs):
        """
        (1,112,112,64)-[reshape]->(1,12544,32,2)
                      -[transpose0312]->(1,2,12544,32)
                      -[instancenorm  num_features=32]->(1,2,12544,32)
            =>
        (1,112,112,64)-[InstanceNormalization, num_features=c, num_groups=2, group_order=1]->(1,112,112,64)
                      -[reshape]->(1,12544,32,2)
                      -[transpose0312]->(1,2,12544,32)
        """
        pat = find_operator_sequence(
            op, "R[1hw(cd)->1(hw)cd] T0312", LayerType.InstanceNormalization
        )
        if pat is None:
            return None
        reshape, transpose, instancenorm = pat
        reshape_inact = reshape.inacts[0]
        if not check_input_npu_stride(reshape_inact.producer_op):
            return None
        reshape_outact = reshape.outacts[0]
        c, d = reshape_outact.src_shape[-2:]
        if c == d == 1:
            return None
        inorm_scale = instancenorm.get_tensor(instancenorm.options.scale).value
        if inorm_scale.shape[0] == int(c):
            return reshape, transpose, instancenorm
        return None

    @group_order1.transform
    def group_order1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, transpose, instancenorm = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        n, x, num_features, num_groups = reshape_outact.src_shape
        new_outact = builder.with_new_input_and_options(
            instancenorm,
            new_inact,
            num_groups=int(num_groups),
            group_order=1,
        )
        new_outact = builder.make_reshape(new_outact, (n, x, num_features, num_groups))
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = instancenorm.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape, instancenorm)

        return builder.build()
