from mblt import LayerType
from mblt.core import pattern
from mblt.operator import Operator
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    check_output_npu_stride,
    is_transpose,
)
from mblt.transform.graph_transform import TransformRule
from mblt.transform.transform_result import OpTransformResultV2Builder
from ._ruleset import DataFlowRuleSet


@DataFlowRuleSet.register
class TransposeMatmul(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype != LayerType.MatMul:
            return None
        if op.options.repeat[0] != -1:
            return None
        inact0, inact1 = op.inacts
        if is_transpose(inact0.producer_op, (0, 1, 3, 2)) and is_transpose(
            inact1.producer_op, (0, 1, 3, 2)
        ):
            trans0 = inact0.producer_op
            trans1 = inact1.producer_op
            return trans0, trans1, op
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        trans0, trans1, matmul = self.matched_pattern
        inact0 = trans0.inacts[0]
        new_inact0 = builder.copy_activationspec(inact0, add_input_map=True)
        inact1 = trans1.inacts[0]
        new_inact1 = builder.copy_activationspec(inact1, add_input_map=True)
        new_outact = builder.make_matmul(new_inact1, new_inact0)
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
        old_outact = matmul.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(trans0, matmul)
        builder.remove_connectivity_and_invalidate(trans1, matmul)

        return builder.build()


# Matmul의 경우 softmax, headerview등 때문에 자연스럽게 처리하기 어려워 추가 구현 필요함.
@DataFlowRuleSet.register
class TransposeMatmulReshapeTransposeConvolution(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        possibly with activation function after matmul.
                                           (1,6,32,196)-|-[matmul]->(1,6,32,196)-[reshape]->(1,196,14,14)-[transpose0231]->(1,14,14,192)
        [softmax axis=-1]-[transpose0132]-(1,6,196,196)-|
        =>
                   [softmax axis=-1]-(1,6,196,196)-|-[matmul]->(1,6,196,32)-[transpose0213] ->(1,196,6,32)-[reshape]->(1,14,14,192)
        (1,6,32,196)-[transpose0132]->(1,6,196,32)-|

        """
        pat = find_operator_sequence(op, LayerType.MatMul, "R[1nc(hw)->1(nc)hw] T0231")
        matmul = actfn = reshape = transpose0231 = None
        if pat is not None:
            matmul, reshape, transpose0231 = pat
        if matmul is None:
            pat = find_operator_sequence(
                op, LayerType.MatMul, "actfn R[1nc(hw)->1(nc)hw] T0231"
            )
            if pat is not None:
                matmul, actfn, reshape, transpose0231 = pat
        if matmul is None:
            return None

        if matmul.options.repeat[0] != -1:
            return None
        transpose_outact = transpose0231.outacts[0]
        is_npu_stride = any(
            check_output_npu_stride(cop) for cop in transpose_outact.consumer_ops
        )
        if not is_npu_stride:
            return None
        left_inact, right_inact = matmul.inacts
        pat = find_operator_sequence(
            right_inact.producer_op, LayerType.Softmax, "T0132"
        )
        if pat is None:
            return None
        softmax, transpose0132 = pat
        if softmax.options.axis in (3, -1):
            return matmul, actfn, reshape, transpose0231
        return pat

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        matmul, actfn, reshape, transpose0231 = self.matched_pattern
        left_inact, right_inact = matmul.inacts
        new_left_inact = builder.copy_activationspec(right_inact, add_input_map=True)
        new_left_inact = builder.make_transpose(new_left_inact, (0, 1, 3, 2))
        new_right_inact = builder.copy_activationspec(left_inact, add_input_map=True)
        new_right_inact = builder.make_transpose(new_right_inact, (0, 1, 3, 2))
        new_outact = builder.make_matmul(new_left_inact, new_right_inact)
        if actfn is not None:
            new_outact = builder.with_new_input_and_options(actfn, new_outact)
        reshape_outact = reshape.outacts[0]
        n, c_out, h, w = reshape_outact.src_shape
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        new_outact = builder.make_reshape(new_outact, (1, h, w, c_out))
        old_outact = transpose0231.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(matmul, reshape, transpose0231)

        return builder.build()


@DataFlowRuleSet.register
class AttentionScale(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype != LayerType.MatMul:
            return None
        mc0 = op.inacts[0].producer_op
        mc1 = op.inacts[1].producer_op
        if mc0.layertype == LayerType.MultiplyConstant and mc0.get_tensor(
            mc0.options.constant
        ).shape in ((1,), (0,)):
            return op
        if mc1.layertype == LayerType.MultiplyConstant and mc1.get_tensor(
            mc1.options.constant
        ).shape in ((1,), (0,)):
            return op
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        matmul = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = []
        consts = []
        for inact in matmul.inacts:
            pop = inact.producer_op
            if pop.layertype != LayerType.MultiplyConstant:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                consts.append(1)
                new_inacts.append(new_inact)
                continue
            const_value = pop.get_tensor(pop.options.constant).value
            if const_value.shape in ((1,), (0,)):
                pop_inact = pop.inacts[0]
                new_inact = builder.copy_activationspec(pop_inact, add_input_map=True)
                consts.append(const_value)
                builder.remove_connectivity_and_invalidate(pop, matmul)
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                consts.append(1)
            new_inacts.append(new_inact)
        new_consts = consts[0] * consts[1]
        new_outact = builder.with_new_input_and_options(matmul, new_inacts)
        new_outact = builder.make_mul(new_outact, new_consts)
        old_outact = matmul.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(matmul)
        return builder.build()
