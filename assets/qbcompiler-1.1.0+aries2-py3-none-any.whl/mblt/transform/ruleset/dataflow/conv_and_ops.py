import math

import numpy

from mblt import Operator, LayerType
from mblt.core import TransformRule, pattern
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    is_basic_npu_op,
    is_linear_conv,
    is_actfunc_type,
    check_input_npu_stride,
)
from ._ruleset import DataFlowRuleSet
from ...transform_result import OpTransformResultV2Builder


def _conv_linear_fusible(
    conv_in_shape,
    conv_out_shape,
    conv_weight_shape,
    linear_out_shape,
    linear_weight_shape,
):
    _, hi, wi, ci = map(int, conv_in_shape)
    _, ho, wo, co = map(int, conv_out_shape)
    input_read = hi * wi * ci
    output_write = ho * wo * co
    weight_read = math.prod(conv_weight_shape)
    conv_dma = input_read + output_write + weight_read

    _, lho, lwo, lco = map(int, linear_out_shape)
    linaer_input_read = ho * wo * co
    linear_output_write = lho * lwo * lco
    linear_weight_read = math.prod(linear_weight_shape)  # (o,i,1,1)
    linear_dma = linaer_input_read + linear_output_write + linear_weight_read
    dma_before = conv_dma + linear_dma

    after_input_read = hi * wi * ci
    after_weight_size = list(conv_weight_shape)
    after_weight_size[0] = linear_weight_shape[0]
    after_weight_read = math.prod(after_weight_size)
    after_output_write = lho * lwo * lco
    dma_after = after_input_read + after_weight_read + after_output_write
    return dma_after <= dma_before


@DataFlowRuleSet.register
class TransposeLinear(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T0213 L ")
        if pat is None:
            return None
        transpose, linear = pat
        pop = transpose.inacts[0].producer_op
        if check_input_npu_stride(pop):
            return transpose, linear
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, linear = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(linear, new_inact)
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = linear.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, linear)
        return builder.build()


@DataFlowRuleSet.register
class Convolution(TransformRule):
    @pattern
    def conv_addconst(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, "C", LayerType.AddingConstant, strict_search=True
        )
        if pat is None:
            return None
        conv, xconst = pat
        ts = xconst.get_tensor(xconst.options.constant)
        if (
            ts.shape == tuple()
            or ts.shape == (1,)
            or ts.shape == (conv.options.out_channels,)
        ):
            return conv, xconst
        return None

    @conv_addconst.transform
    def conv_addconst(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        conv, xconst = self.matched_pattern
        inact = conv.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        const_val = xconst.get_tensor(xconst.options.constant).value
        if conv.options.bias == -1:
            bias = numpy.zeros((conv.options.out_channels,), dtype=numpy.float32)
        else:
            bias = conv.get_tensor(conv.options.bias).value
        new_bias = bias + const_val
        new_outact = builder.with_new_input_and_options(conv, new_inact, bias=new_bias)
        old_outact = xconst.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(conv, xconst)
        return builder.build()

    @pattern
    def conv_mulconst(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, "C", LayerType.MultiplyConstant, strict_search=True
        )
        if pat is None:
            return None
        conv, xconst = pat
        ts = xconst.get_tensor(xconst.options.constant)
        if (
            ts.shape == tuple()
            or ts.shape == (1,)
            or ts.shape == (conv.options.out_channels,)
        ):
            return conv, xconst
        return None

    @conv_mulconst.transform
    def conv_mulconst(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        conv, xconst = self.matched_pattern
        inact = conv.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        const_val = xconst.get_tensor(xconst.options.constant).value
        if conv.options.bias == -1:

            new_bias = None
        else:
            bias = conv.get_tensor(conv.options.bias).value
            new_bias = bias * const_val
        weight = conv.get_tensor(conv.options.weight).value
        new_weight = weight * const_val.reshape(-1, 1, 1, 1)
        new_outact = builder.with_new_input_and_options(
            conv, new_inact, bias=new_bias, weight=new_weight
        )
        old_outact = xconst.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(conv, xconst)
        return builder.build()

    @pattern
    def linear(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "CL", strict_search=True)
        if pat is None:
            return None
        conv, linear = pat
        if conv.options.group_number == 1 and _conv_linear_fusible(
            conv.inacts[0].src_shape,
            conv.outacts[0].src_shape,
            conv.get_tensor(conv.options.weight).value.shape,
            linear.outacts[0].src_shape,
            linear.get_tensor(linear.options.weight).value.shape,
        ):
            return conv, linear
        return None
        # if conv.options.group_number > 1:
        #     return None
        #
        # conv_inact = conv.inacts[0]
        # weight = conv.get_tensor(conv.options.weight).value
        # conv_outact = conv.outacts[0]
        # _, hi, wi, ci = map(int, conv_inact.src_shape)
        # _, ho, wo, co = map(int, conv_outact.src_shape)
        # input_read = hi * wi * ci
        # output_write = ho * wo * co
        # weight_read = math.prod(weight.shape)
        # conv_dma = input_read + output_write + weight_read
        #
        # linear_weight = linear.get_tensor(linear.options.weight).value
        # linear_outact = linear.outacts[0]
        # _, lho, lwo, lco = map(int, linear_outact.src_shape)
        # linaer_input_read = ho * wo * co
        # linear_output_write = lho * lwo * lco
        # linear_weight_read = math.prod(linear_weight.shape)  # (o,i,1,1)
        # linear_dma = linaer_input_read + linear_output_write + linear_weight_read
        # dma_before = conv_dma + linear_dma
        #
        # after_input_read = hi * wi * ci
        # after_weight_size = list(weight.shape)
        # after_weight_size[0] = linear_weight.shape[0]
        # after_weight_read = math.prod(after_weight_size)
        # after_output_write = lho * lwo * lco
        # dma_after = after_input_read + after_weight_read + after_output_write
        #
        # if dma_after <= dma_before:
        #     return conv, linear
        # return None

    @linear.transform
    def linear(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        conv, linear = self.matched_pattern
        inact = conv.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        conv_weight = conv.get_tensor(conv.options.weight).value

        linear_weight = linear.get_tensor(linear.options.weight).value
        mul = linear_weight[:, :, 0, 0]

        # einsum("oc,cihw->oihw", mul, conv_weight)
        weight_new = (mul @ conv_weight.reshape(conv_weight.shape[0], -1)).reshape(
            mul.shape[0], *conv_weight.shape[1:]
        )

        new_bias = None
        if conv.options.bias != -1:
            conv_bias = conv.get_tensor(conv.options.bias).value
            new_bias = mul @ conv_bias  # einsum("oc,c->o")

        if linear.options.bias != -1:
            linear_bias = linear.get_tensor(linear.options.bias).value
            if new_bias is None:
                new_bias = linear_bias
            else:
                new_bias = new_bias + linear_bias

        new_outact = builder.with_new_input_and_options(
            conv,
            new_inact,
            out_channels=weight_new.shape[0],
            weight=weight_new,
            bias=new_bias,
        )
        old_outact = linear.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(conv, linear)

        return builder.build()

    @pattern
    def linears_add_or_sub(self, op: Operator, **kwargs):
        """from the same inputs
        -|-linear-|-adding/sub
         |-linear-|
        """
        if op.layertype not in (LayerType.Adding, LayerType.Sub):
            return None
        biop = op
        pop0 = biop.inacts[0].producer_op
        pat = find_operator_sequence(pop0, "L")
        if pat is None:
            return None
        linear0 = pat[0]
        pop1 = biop.inacts[1].producer_op
        pat = find_operator_sequence(pop1, "L")
        if pat is None:
            return None
        linear1 = pat[0]
        linear0_outact = linear0.outacts[0]
        linear1_outact = linear1.outacts[0]
        if (
            linear0.inacts[0].name == linear1.inacts[0].name
            and (linear1_outact.src_shape == linear0_outact.src_shape)
            and (
                1
                == len(linear0_outact.consumer_ops)
                == len(linear1_outact.consumer_ops)
            )
        ):
            return linear0, linear1, biop
        return None

    @linears_add_or_sub.transform
    def linears_add_or_sub(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        linear0, linear1, biop = self.matched_pattern
        inact0 = linear0.inacts[0]
        new_inact0 = builder.copy_activationspec(inact0, add_input_map=True)

        linear0_weight = linear0.get_tensor(linear0.options.weight).value
        linear1_weight = linear1.get_tensor(linear1.options.weight).value
        if biop.layertype == LayerType.Adding:
            new_weight = linear0_weight + linear1_weight
        elif biop.layertype == LayerType.Sub:
            new_weight = linear0_weight - linear1_weight
        else:
            raise ValueError(f"Unsupported layer type: {biop.layertype}")

        new_bias = None
        if linear0.options.bias != -1:
            new_bias = linear0.get_tensor(linear0.options.bias).value
        if linear1.options.bias != -1:
            bias1 = linear1.get_tensor(linear1.options.bias).value
            if new_bias is None:
                new_bias = 0
            if biop.layertype == LayerType.Adding:
                new_bias = new_bias + bias1
            elif biop.layertype == LayerType.Sub:
                new_bias = new_bias - bias1
            else:
                raise ValueError(f"Unsupported layer type: {biop.layertype}")

        new_outact = builder.with_new_input_and_options(
            linear0, new_inact0, weight=new_weight, bias=new_bias
        )
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(linear0, biop)
        builder.remove_connectivity_and_invalidate(linear1, biop)
        return builder.build()

    @pattern
    def linear_addconst_add(self, op: Operator, **kwargs):
        """
        linear-|-adding/sub
        addint_const-|
        """
        if op.layertype not in (LayerType.Adding, LayerType.Sub):
            return None

        def check_fn(pop0, pop1):
            if not is_linear_conv(pop0):
                return None
            pop0_outact = pop0.outacts[0]
            pop1_outact = pop1.outacts[0]
            if not (
                len(pop0_outact.consumer_ops) == len(pop1_outact.consumer_ops) == 1
            ):
                return None
            if pop1.layertype == LayerType.AddingConstant:
                ac_value = pop1.get_tensor(pop1.options.constant).value
                c = int(pop0.options.out_channels)
                if ac_value.size == 1 or ac_value.shape == (c,):
                    return pop0, pop1
            return None

        biop = op
        pop0 = biop.inacts[0].producer_op
        pop1 = biop.inacts[1].producer_op
        if check_fn(pop0, pop1) is not None:
            return pop1, biop
        if check_fn(pop1, pop0) is not None:
            return pop0, biop
        return None

    @linear_addconst_add.transform
    def linear_addconst_add(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        addconst, biop = self.matched_pattern
        new_inacts = []
        for inact in biop.inacts:
            if inact.producer_op.layertype == LayerType.AddingConstant:
                addconst_inact = addconst.inacts[0]
                new_inact = builder.copy_activationspec(
                    addconst_inact, add_input_map=True
                )
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                const_val = addconst.get_tensor(addconst.options.constant).value
                new_inact = builder.make_add(new_inact, const_val)
            new_inacts.append(new_inact)

        new_outact = builder.make_add(*new_inacts)
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(addconst, biop)
        builder.remove_connectivity_and_invalidate(biop)
        return builder.build()

    @pattern
    def linears_add_linear(self, op: Operator, **kwargs):
        """
        ()-[linaer]-|-[adding]->()-[linaer]
        ()-[linaer]-|
        """

        def _add_or_sub(op):
            return op.layertype in (LayerType.Adding, LayerType.Sub)

        pat = find_operator_sequence(op, _add_or_sub, "L", strict_search=True)
        if pat is None:
            return None
        add, linear = pat

        pop0 = add.inacts[0].producer_op
        pop1 = add.inacts[1].producer_op
        if is_linear_conv(pop0) and is_linear_conv(pop1):
            if (
                pop0.options.out_channels
                == pop1.options.out_channels
                == linear.options.in_channels
            ) and pop0.inacts[0].name != pop1.inacts[0].name:
                pop0_outact = pop0.outacts[0]
                pop1_outact = pop1.outacts[0]
                if 1 == len(pop0_outact.consumer_ops) == len(pop1_outact.consumer_ops):
                    return pop0, pop1, add, linear
        return None

    @linears_add_linear.transform
    def linears_add_linear(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        linear0, linear1, add, linear_last = self.matched_pattern

        linear_last_weight = linear_last.get_tensor(linear_last.options.weight).value
        linear_last_bias = None
        if linear_last.options.bias != -1:
            linear_last_bias = linear_last.get_tensor(linear_last.options.bias).value

        has_bias_idx = 0
        if linear0.options.bias == -1 and linear1.options.bias != -1:
            has_bias_idx = 1

        new_add_inacts = []
        for i, conv in enumerate((linear0, linear1)):
            inact = conv.inacts[0]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            conv_weight = conv.get_tensor(conv.options.weight).value
            mul = linear_last_weight[:, :, 0, 0]
            weight_new = (mul @ conv_weight.reshape(conv_weight.shape[0], -1)).reshape(
                mul.shape[0], *conv_weight.shape[1:]
            )
            new_bias = None
            if conv.options.bias != -1:
                conv_bias = conv.get_tensor(conv.options.bias).value
                new_bias = mul @ conv_bias
            if linear_last_bias is not None and has_bias_idx == i:
                if new_bias is None:
                    new_bias = linear_last_bias
                else:
                    new_bias = new_bias + linear_last_bias

            new_outact = builder.with_new_input_and_options(
                conv,
                new_inact,
                out_channels=weight_new.shape[0],
                weight=weight_new,
                bias=new_bias,
            )
            new_add_inacts.append(new_outact)
        if add.layertype == LayerType.Adding:
            new_outact = builder.make_add(*new_add_inacts)
        elif add.layertype == LayerType.Sub:
            new_outact = builder.make_sub(*new_add_inacts)
        else:
            raise ValueError(f"Unsupported layer type: {add.layertype}")
        old_outact = linear_last.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(linear0, add, linear_last)
        builder.remove_connectivity_and_invalidate(linear1, add)
        return builder.build()


def mulconst_conv_fused_weight(
    const_val, conv_weight, in_channels, out_channels, groups
):
    if const_val.size == 1:
        const_val = numpy.full((in_channels,), const_val.reshape(-1)[0])
    if groups == 1:
        new_weight = const_val.reshape(1, -1, 1, 1) * conv_weight
    else:
        const_reshaped = const_val.reshape(groups, -1)
        c_out = out_channels
        c_out_per_group = c_out // groups
        ker_h, ker_w = conv_weight.shape[2:]
        weight_reshaped = conv_weight.reshape(groups, c_out_per_group, -1, ker_h, ker_w)
        new_weight = weight_reshaped * const_reshaped[:, None, :, None, None]
        new_weight = new_weight.reshape(c_out, -1, ker_h, ker_w)
    return new_weight


@DataFlowRuleSet.register
class BiopConstConvolution(TransformRule):
    def _const_check(self, xconst, c):
        const_val = xconst.get_tensor(xconst.options.constant).value
        return const_val.shape == (c,) or const_val.size == 1

    def _conv_pad_check(self, conv):
        return (
            conv.options.north_padding
            == conv.options.south_padding
            == conv.options.west_padding
            == conv.options.east_padding
            == 0
        )

    def _get_add_const_new_bias(self, conv_weight, conv_bias, const_val, groups):
        oc, ic_div_groups, ker_h, ker_w = conv_weight.shape
        kernel_sum = conv_weight.sum(axis=(2, 3))
        if groups == 1:
            if kernel_sum.shape[-1] > 1 and const_val.size == 1:
                const_val = numpy.full(kernel_sum.shape[-1], const_val.reshape(-1)[0])
            return kernel_sum @ const_val + conv_bias
        const_val_reshaped = const_val.reshape(groups, -1)
        out_per_group = oc // groups
        kernel_sum_reshaped = kernel_sum.reshape(groups, out_per_group, -1)
        partial_bias = numpy.einsum(
            "goi,gi->go", kernel_sum_reshaped, const_val_reshaped
        )
        new_bias = partial_bias.flatten() + conv_bias
        return new_bias

    @pattern
    def addconst_conv(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.AddingConstant, LayerType.Convolution, strict_search=True
        )
        if pat is None:
            return None
        addconst, conv = pat
        if not self._conv_pad_check(conv):
            return None
        if self._const_check(addconst, conv.options.in_channels):
            return addconst, conv
        return None

    @addconst_conv.transform
    def addconst_conv(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        addconst, conv = self.matched_pattern
        inact = addconst.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        const_val = addconst.get_tensor(addconst.options.constant).value
        if const_val.size == 1:
            const_val = numpy.full(
                (conv.options.in_channels,), const_val.reshape(-1)[0]
            )
        conv_weight = conv.get_tensor(conv.options.weight).value
        if conv.options.bias != -1:
            conv_bias = conv.get_tensor(conv.options.bias).value
        else:
            conv_bias = numpy.zeros((conv.options.out_channels,), dtype=numpy.float32)
        # Conv(X+c) + B -> Conv(X) + Conv(c) + B
        new_bias = self._get_add_const_new_bias(
            conv_weight, conv_bias, const_val, conv.options.group_number
        )
        new_outact = builder.with_new_input_and_options(conv, new_inact, bias=new_bias)
        old_outact = conv.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(addconst, conv)
        return builder.build()

    @pattern
    def mulconst_conv(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.MultiplyConstant, LayerType.Convolution, strict_search=True
        )
        if pat is None:
            return None
        mulconst, conv = pat
        if not self._conv_pad_check(conv):
            return None
        if self._const_check(mulconst, conv.options.in_channels):
            return mulconst, conv
        return None

    @mulconst_conv.transform
    def mulconst_conv(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        mulconst, conv = self.matched_pattern
        inact = mulconst.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        const_val = mulconst.get_tensor(mulconst.options.constant).value
        conv_weight = conv.get_tensor(conv.options.weight).value
        new_weight = mulconst_conv_fused_weight(
            const_val,
            conv_weight,
            conv.options.in_channels,
            conv.options.out_channels,
            conv.options.group_number,
        )
        new_outact = builder.with_new_input_and_options(
            conv, new_inact, weight=new_weight
        )
        old_outact = conv.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(mulconst, conv)
        return builder.build()

    @pattern
    def mulconst_t0231_conv(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.MultiplyConstant, "T0231 C")
        if pat is None:
            return None
        mulconst, t0231, conv = pat
        const_val = mulconst.get_tensor(mulconst.options.constant).value
        c = conv.options.in_channels
        if not (const_val.shape == (1, c, 1, 1) or const_val.size == 1):
            return None
        t0231_outact = t0231.outacts[0]
        fusibles = []
        for cop in t0231_outact.consumer_ops:
            if cop.layertype == LayerType.Convolution and self._conv_pad_check(conv):
                fusibles.append(cop)
        if fusibles and len(t0231_outact.consumer_ops) - len(fusibles) <= 1:
            return mulconst, t0231, fusibles
        return None

    @mulconst_t0231_conv.transform
    def mulconst_t0231_conv(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        mulconst, t0231, convs = self.matched_pattern
        inact = mulconst.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_inact = builder.make_transpose(new_inact, (0, 2, 3, 1))
        const_val = mulconst.get_tensor(mulconst.options.constant).value
        for conv in convs:
            conv_weight = conv.get_tensor(conv.options.weight).value
            const_val = const_val.reshape(-1)
            new_weight = mulconst_conv_fused_weight(
                const_val,
                conv_weight,
                conv.options.in_channels,
                conv.options.out_channels,
                conv.options.group_number,
            )
            new_outact = builder.with_new_input_and_options(
                conv, new_inact, weight=new_weight
            )
            old_outact = conv.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(mulconst, t0231, conv)
        return builder.build()

    @pattern
    def addconst_t0231_conv(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op,
            LayerType.AddingConstant,
            "T0231",
            LayerType.Convolution,
        )
        if pat is None:
            return None
        addconst, t0231, conv = pat
        const_val = addconst.get_tensor(addconst.options.constant).value
        c = conv.options.in_channels
        if not (const_val.shape == (1, c, 1, 1) or const_val.size == 1):
            return None
        t0231_outact = t0231.outacts[0]
        fusibles = []
        for cop in t0231_outact.consumer_ops:
            if cop.layertype == LayerType.Convolution and self._conv_pad_check(conv):
                fusibles.append(cop)
        if fusibles and len(t0231_outact.consumer_ops) - len(fusibles) <= 1:
            return addconst, t0231, fusibles
        return None

    @addconst_t0231_conv.transform
    def addconst_t0231_conv(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        addconst, t0231, convs = self.matched_pattern
        inact = addconst.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_inact = builder.make_transpose(new_inact, (0, 2, 3, 1))
        const_val = addconst.get_tensor(addconst.options.constant).value
        for conv in convs:
            conv_weight = conv.get_tensor(conv.options.weight).value
            const_val = const_val.reshape(-1)
            if conv.options.bias != -1:
                conv_bias = conv.get_tensor(conv.options.bias).value
            else:
                conv_bias = numpy.zeros(
                    (conv.options.out_channels,), dtype=numpy.float32
                )
            new_bias = self._get_add_const_new_bias(
                conv_weight, conv_bias, const_val, conv.options.group_number
            )
            new_outact = builder.with_new_input_and_options(
                conv, new_inact, bias=new_bias
            )
            old_outact = conv.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(addconst, t0231, conv)
        return builder.build()

    @pattern
    def subconst_conv(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.SubConstant, LayerType.Convolution, strict_search=True
        )
        if pat is None:
            return None
        subconst, conv = pat
        if not self._conv_pad_check(conv):
            return None
        if self._const_check(subconst, conv.options.in_channels):
            return subconst, conv
        return None

    @subconst_conv.transform
    def subconst_conv(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        subconst, conv = self.matched_pattern
        inact = subconst.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        const_val = subconst.get_tensor(subconst.options.constant).value
        if const_val.size == 1:
            const_val = numpy.full(
                (conv.options.in_channels,), const_val.reshape(-1)[0]
            )

        conv_weight = conv.get_tensor(conv.options.weight).value
        if conv.options.bias != -1:
            conv_bias = conv.get_tensor(conv.options.bias).value
        else:
            conv_bias = numpy.zeros((conv.options.out_channels,), dtype=numpy.float32)
        if bool(subconst.options.is_const_first):
            # Conv(c-X)+B -> -Conv(X) + Conv(c) + B
            new_bias = self._get_add_const_new_bias(
                conv_weight, conv_bias, const_val, conv.options.group_number
            )
            new_outact = builder.with_new_input_and_options(
                conv, new_inact, weight=-conv_weight, bias=new_bias
            )
        else:
            # Conv(X-c)+B -> Conv(X) + Conv(-c) + B
            new_bias = self._get_add_const_new_bias(
                conv_weight, conv_bias, -const_val, conv.options.group_number
            )
            new_outact = builder.with_new_input_and_options(
                conv, new_inact, bias=new_bias
            )
        old_outact = conv.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(subconst, conv)
        return builder.build()

    @pattern
    def mulconst_addconst_ordered_patchify_conv(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op,
            LayerType.InstanceNormalization,
            LayerType.MultiplyConstant,
            LayerType.AddingConstant,
            LayerType.OrderedPatchify,
            "C",
            strict_search=True,
        )
        if pat is None:
            return None
        inorm, mulconst, addconst, patchify, conv = pat
        inorm_shape = inorm.get_tensor(inorm.options.scale).value.shape
        mulconst_inact = mulconst.inacts[0]
        c = int(mulconst_inact.src_shape[-1])

        # unfusible with instance norm.
        if inorm_shape == (c,):
            return None
        if not self._conv_pad_check(conv):
            return None

        if self._const_check(addconst, conv.options.in_channels) and self._const_check(
            mulconst, conv.options.in_channels
        ):
            return mulconst, addconst, patchify
        return None

    @mulconst_addconst_ordered_patchify_conv.transform
    def mulconst_addconst_ordered_patchify_conv(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        mulconst, addconst, patchify = self.matched_pattern
        inact = mulconst.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(patchify, new_inact)
        new_outact = builder.with_new_input_and_options(mulconst, new_outact)
        new_outact = builder.with_new_input_and_options(addconst, new_outact)
        old_outact = patchify.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(mulconst, addconst, patchify)
        return builder.build()


@DataFlowRuleSet.register
class TransposeReshapeConvolution(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        [conv]-[add]->(1,32,19,128)-[transpose0132]->(1,32,128,19)-[reshape]->(1,1,32,2432)-[linear]->(1,1,32,192)
        =>
        [conv]-[add]->(1,32,19,128)-[conv2d]->(1,32,1,192)
        """
        pat = find_operator_sequence(
            op, "biop T0132 R[1hwc->11h(wc)] L", strict_search=True
        )
        if pat is None:
            return None
        biop, transpose, reshape, conv = pat
        reshape_inact = reshape.inacts[0]
        if any(x.dynamic for x in reshape_inact.src_shape):
            return None
        for inact in biop.inacts:
            pat = find_operator_sequence(inact.producer_op, is_basic_npu_op)
            if pat is not None:
                return transpose, reshape, conv
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape, conv = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        conv_weight = conv.get_tensor(conv.options.weight).value
        conv_bias = (
            conv.get_tensor(conv.options.bias).value
            if conv.options.bias != -1
            else None
        )
        n, h, w, c_in = map(int, new_inact.src_shape)
        c_out, c_in_orig, h_out, w_out = conv_weight.shape
        new_weight = numpy.zeros((c_out, c_in, 1, w), dtype=numpy.float32)
        for c in range(c_in):
            for w_idx in range(w):
                j = c * w + w_idx
                new_weight[:, c, 0, w_idx] = conv_weight[:, j, 0, 0]

        new_outact = builder.make_conv2d(
            new_inact,
            in_channels=c_in,
            out_channels=c_out,
            h_kernel=1,
            w_kernel=w,
            weight=new_weight,
            bias=conv_bias,
        )
        old_outact = conv.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape, conv)
        return builder.build()


@DataFlowRuleSet.register
class MatmulReshapeLinear(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.MatMul, "R[1h1c->111(hc)] L")
        if pat is None:
            return None
        mm, reshape, linear = pat
        n, h, w, c = reshape.inacts[0].src_shape
        if h > 1 and not h.dynamic:
            return reshape, linear
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, linear = self.matched_pattern
        reshape_inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(reshape_inact, add_input_map=True)
        conv_weight = linear.get_tensor(linear.options.weight).value
        n, h, w, c = map(int, reshape_inact.src_shape)
        oc, ic, ker_h, ker_w = conv_weight.shape
        assert ker_h == ker_w == 1 and h * c == ic and w == 1
        weight = conv_weight.reshape(oc, h, c).transpose(0, 2, 1).reshape(oc, c, h, 1)
        new_outact = builder.with_new_input_and_options(
            linear, new_inact, weight=weight, in_channels=c, h_kernel=h
        )
        old_outact = linear.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, linear)

        return builder.build()


@DataFlowRuleSet.register
class ConvolutionConcatenate(TransformRule):
    @pattern
    def case_conv_actfn(self, op: Operator, **kwargs):
        if not (op.layertype == LayerType.Concatenate and op.options.axis in (3, -1)):
            return None
        concat = op
        convs = []
        ref_inact = None
        ref_conv_opt = None
        ref_actfn = None
        for inact in concat.inacts:
            if not is_actfunc_type(inact.producer_op):
                return None
            if len(inact.consumer_ops) != 1:
                return None
            if ref_actfn is None:
                pat = find_operator_sequence(
                    inact.producer_op, "C actfn", strict_search=True
                )
            else:
                pat = find_operator_sequence(
                    inact.producer_op, "C", ref_actfn.layertype, strict_search=True
                )
            if pat is None:
                return None
            conv, actfn = pat
            ref_actfn = actfn
            conv_inact = conv.inacts[0]
            if ref_conv_opt is None:
                ref_conv_opt = conv.options
            if ref_inact is None:
                ref_inact = conv_inact
            if conv_inact.name != ref_inact.name:
                return None
            curr_opt = conv.options
            if (
                ref_conv_opt.h_kernel == curr_opt.h_kernel
                and ref_conv_opt.w_kernel == curr_opt.w_kernel
                and ref_conv_opt.h_dilation == curr_opt.h_dilation
                and ref_conv_opt.w_dilation == curr_opt.w_dilation
                and ref_conv_opt.h_stride == curr_opt.h_stride
                and ref_conv_opt.w_stride == curr_opt.w_stride
                and ref_conv_opt.north_padding == curr_opt.north_padding
                and ref_conv_opt.south_padding == curr_opt.south_padding
                and ref_conv_opt.east_padding == curr_opt.east_padding
                and ref_conv_opt.west_padding == curr_opt.west_padding
                and ref_conv_opt.group_number == curr_opt.group_number == 1
            ):
                pat = find_operator_sequence(conv, "CL", strict_search=True)
                if pat is not None:
                    conv_p, linear_p = pat
                    if conv_p.options.group_number == 1 and _conv_linear_fusible(
                        conv_p.inacts[0].src_shape,
                        conv_p.outacts[0].src_shape,
                        conv_p.get_tensor(conv_p.options.weight).value.shape,
                        linear_p.outacts[0].src_shape,
                        linear_p.get_tensor(linear_p.options.weight).value.shape,
                    ):
                        return None
                convs.append(conv)
            else:
                return None
        return convs, ref_actfn, concat

    @case_conv_actfn.transform
    def case_conv_actfn(self, *args, **kwargs):
        convs, actfn, concat = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = convs[0].inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_weight = []
        has_bias = any(x.options.bias != -1 for x in convs)
        new_bias = []
        for conv in convs:
            conv_weight = conv.get_tensor(conv.options.weight).value
            new_weight.append(conv_weight)
            if conv.options.bias == -1:
                if has_bias:
                    new_bias.append(
                        numpy.zeros(conv.options.out_channels, dtype=numpy.float32)
                    )
            else:
                conv_bias = conv.get_tensor(conv.options.bias).value
                new_bias.append(conv_bias)
            builder.remove_connectivity_and_invalidate(conv, actfn, concat)
        new_weight = numpy.concatenate(new_weight, axis=0)
        if has_bias:
            new_bias = numpy.concatenate(new_bias, axis=0)
        else:
            new_bias = None
        new_outact = builder.with_new_input_and_options(
            convs[0],
            new_inact,
            weight=new_weight,
            bias=new_bias,
            out_channels=new_weight.shape[0],
        )
        new_outact = builder.with_new_input_and_options(actfn, new_outact)
        old_outact = concat.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        return builder.build()

    @pattern
    def case_conv(self, op: Operator, **kwargs):
        if not (op.layertype == LayerType.Concatenate and op.options.axis in (3, -1)):
            return None
        concat = op
        convs = []
        ref_inact = None
        ref_conv_opt = None
        for inact in concat.inacts:
            if 1 != len(inact.consumer_ops):
                return None
            if inact.producer_op.layertype != LayerType.Convolution:
                return None
            conv = inact.producer_op
            conv_inact = conv.inacts[0]
            if ref_conv_opt is None:
                ref_conv_opt = conv.options
            if ref_inact is None:
                ref_inact = conv_inact
            if conv_inact.name != ref_inact.name:
                return None
            curr_opt = conv.options
            if (
                ref_conv_opt.h_kernel == curr_opt.h_kernel
                and ref_conv_opt.w_kernel == curr_opt.w_kernel
                and ref_conv_opt.h_dilation == curr_opt.h_dilation
                and ref_conv_opt.w_dilation == curr_opt.w_dilation
                and ref_conv_opt.h_stride == curr_opt.h_stride
                and ref_conv_opt.w_stride == curr_opt.w_stride
                and ref_conv_opt.north_padding == curr_opt.north_padding
                and ref_conv_opt.south_padding == curr_opt.south_padding
                and ref_conv_opt.east_padding == curr_opt.east_padding
                and ref_conv_opt.west_padding == curr_opt.west_padding
                and ref_conv_opt.group_number == curr_opt.group_number == 1
            ):
                pat = find_operator_sequence(conv, "CL", strict_search=True)
                if pat is not None:
                    conv_p, linear_p = pat
                    if conv_p.options.group_number == 1 and _conv_linear_fusible(
                        conv_p.inacts[0].src_shape,
                        conv_p.outacts[0].src_shape,
                        conv_p.get_tensor(conv_p.options.weight).value.shape,
                        linear_p.outacts[0].src_shape,
                        linear_p.get_tensor(linear_p.options.weight).value.shape,
                    ):
                        return None
                convs.append(conv)
            else:
                return None
        return convs, concat

    @case_conv.transform
    def case_conv(self, *args, **kwargs):
        convs, concat = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = convs[0].inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_weight = []
        has_bias = any(x.options.bias != -1 for x in convs)
        new_bias = []
        for conv in convs:
            conv_weight = conv.get_tensor(conv.options.weight).value
            new_weight.append(conv_weight)
            if conv.options.bias == -1:
                if has_bias:
                    new_bias.append(
                        numpy.zeros(conv.options.out_channels, dtype=numpy.float32)
                    )
            else:
                conv_bias = conv.get_tensor(conv.options.bias).value
                new_bias.append(conv_bias)
            builder.remove_connectivity_and_invalidate(conv, concat)
        new_weight = numpy.concatenate(new_weight, axis=0)
        if has_bias:
            new_bias = numpy.concatenate(new_bias, axis=0)
        else:
            new_bias = None
        new_outact = builder.with_new_input_and_options(
            convs[0],
            new_inact,
            weight=new_weight,
            bias=new_bias,
            out_channels=new_weight.shape[0],
        )
        old_outact = concat.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        return builder.build()

    # @pattern
    # def case_concat_ax2(self, op: Operator, **kwargs):
    #     """
    #     linear with no bias
    #     [linear]-(1,4,400,17)--|-[concat axis=2]->(1,4,8400,1)
    #     [linear]-(1,4,1600,17)-|-
    #     [linear]-(1,4,6400,17)-|-
    #     """
    #     if not (op.layertype == LayerType.Concatenate and op.options.axis == 2):
    #         return None
    #
    #     ref_weight = None
    #     ref_conv = None
    #     convs = []
    #     for inact in op.inacts:
    #         conv = inact.producer_op
    #         if not is_linear_conv(conv):
    #             return None
    #         if conv.options.bias != -1:
    #             return None
    #         if conv.options.out_channels != 1:
    #             return None
    #
    #         if ref_conv is None:
    #             ref_conv = conv
    #             ref_weight = conv.get_tensor(conv.options.weight).value
    #
    #         if ref_conv.options.in_channels != conv.options.in_channels:
    #             return None
    #
    #         inact = conv.inacts[0]
    #         ref_ianct = ref_conv.inacts[0]
    #         if inact.src_shape[:2] != ref_ianct.src_shape[:2]:
    #             return None
    #         if inact.src_shape[3] != ref_ianct.src_shape[3]:
    #             return None
    #         weight = conv.get_tensor(conv.options.weight).value
    #         if ref_weight.shape == weight.shape and numpy.allclose(ref_weight, weight):
    #             convs.append(conv)
    #         else:
    #             return None
    #     if len(convs) == len(op.options.inputs):
    #         return convs, op
    #     return None
    #
    # @case_concat_ax2.transform
    # def case_concat_ax2(self, *args, **kwargs):
    #     convs, concat = self.matched_pattern
    #     builder = OpTransformResultV2Builder()
    #     new_inacts = []
    #     for conv in convs:
    #         inact = conv.inacts[0]
    #         new_inact = builder.copy_activationspec(inact, add_input_map=True)
    #         new_inacts.append(new_inact)
    #
    #     new_outact = builder.make_concatenate(new_inacts, axis=2)
    #
    #     ref_conv = convs[0]
    #     new_outact = builder.with_new_input_and_options(ref_conv, new_outact)
    #     old_outact = concat.outacts[0]
    #     builder.add_output_map(new_outact, old_outact)
    #     for conv in convs:
    #         builder.remove_connectivity_and_invalidate(conv, concat)
    #
    #     return builder.build()
