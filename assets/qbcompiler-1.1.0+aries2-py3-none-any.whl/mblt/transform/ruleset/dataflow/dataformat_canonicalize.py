import operator

from mblt import LayerType, Operator
from mblt.core import TransformRule, pattern
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    is_reducidle_reshapes,
)
from mblt.transform.ruleset.dataflow._ruleset import DataFormatCanonicalizationRuleSet
from mblt.transform.transform_result import OpTransformResultV2Builder


def is_static_one(x):
    return x == 1 and not getattr(x, "dynamic", False)


def decompose_transpose_move_ones(shape, perm):
    """
    shape: input shape
    perm: original transpose perm

    returns:
        perm_move_ones
        perm_layout
    """

    # 1축 / non-1축 분리
    one_axes = tuple(i for i, s in enumerate(shape) if is_static_one(s))
    non_one_axes = tuple(i for i, s in enumerate(shape) if not is_static_one(s))

    # Step1: 1축을 앞으로 모으는 perm
    perm_move_ones = one_axes + non_one_axes

    # Step2: 보정 perm 계산
    # 기존 perm을 step1 기준으로 다시 매핑

    # old axis -> step1 axis 위치
    axis_to_newpos = {ax: i for i, ax in enumerate(perm_move_ones)}

    # 최종 perm을 step1 좌표계로 변환
    perm_layout = tuple([axis_to_newpos[ax] for ax in perm])

    return perm_move_ones, perm_layout


def is_reshape_like_transpose(shape, perm):
    non_one_axes = tuple(i for i, s in enumerate(shape) if not is_static_one(s))
    # shape=(1, 1, a, 1, 1, c), perm=(0, 1, 3, 4, 2, 5)
    # filtered_perm은 [2, 5]가 됨 (a와 c의 원래 위치)
    filtered_perm = [p for p in perm if p in non_one_axes]
    for i in range(len(filtered_perm) - 1):
        if filtered_perm[i] > filtered_perm[i + 1]:
            return False
    return True


def get_effective_shape(src_shape):
    def gen():
        for s in src_shape:
            if s != 1 or getattr(s, "dynamic", False):
                yield int(s)

    return tuple(gen())


@DataFormatCanonicalizationRuleSet.register
class Reshape(TransformRule):

    @pattern
    def reshape_reshape(self, op: Operator, *args, **kwargs):
        pat = find_operator_sequence(op, "RR")
        if pat is None:
            return None
        reshape0, reshape1 = pat
        if is_reducidle_reshapes(reshape0, reshape1):
            return reshape0, reshape1
        return None

    @reshape_reshape.transform
    def reshape_reshape(self, *args, **kwargs):
        reshape0, reshape1 = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reshape0.inacts[0]
        old_outact = reshape1.outacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, reshape1)
        return builder.build()

    @pattern
    def case0(self, op: Operator, **kwargs):
        """reshape-matmul=>transpose-matmul"""
        pat = find_operator_sequence(op, "R[111c->11c1]")
        if pat is not None:
            reshape = pat[0]
            reshape_outact = reshape.outacts[0]
            for cop in reshape_outact.consumer_ops:
                if cop.layertype == LayerType.MatMul:
                    return reshape
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape = self.matched_pattern
        inact = reshape.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape)
        return builder.build()


@DataFormatCanonicalizationRuleSet.register
class Transpose(TransformRule):

    @pattern
    def transpose_transpose(self, op: Operator, *args, **kwargs):
        """
        to identity or single transpose
        """
        # transpose-transpose
        pat = find_operator_sequence(op, "TT")
        if pat is None:
            return None
        return pat

    @transpose_transpose.transform
    def transpose_transpose(self, *args, **kwargs):
        trans0, trans1 = self.matched_pattern
        old_inact = trans0.inacts[0]
        old_outact = trans1.outacts[0]
        indexer = tuple(range(old_inact.src_dim))
        indexer = operator.itemgetter(*trans0.options.transpose_axes)(indexer)
        indexer = operator.itemgetter(*trans1.options.transpose_axes)(indexer)
        indexer = tuple(indexer)

        builder = OpTransformResultV2Builder()
        new_outact = builder.copy_activationspec(old_inact, add_input_map=True)
        if indexer == tuple(range(len(indexer))):
            new_outact = builder.make_identity(new_outact)
        else:
            new_outact = builder.make_transpose(new_outact, indexer)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(trans0, trans1)
        return builder.build()

    @pattern
    def decompose_transpose(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Transpose:
            return None
        if op.options.transpose_axes in ((0, 2, 3, 1), (0, 3, 1, 2)):
            return None
        inact = op.inacts[0]
        outact = op.outacts[0]
        if not (
            inact.src_dim >= 4
            and is_static_one(inact.src_shape[0])
            and is_static_one(outact.src_shape[0])
        ):
            return None
        if op.options.transpose_axes == (0, 1, 3, 2):
            n, h, w, c = inact.src_shape
            if n == h == c == 1 or n == h == w == 1:
                return None
        move_ones, layout = decompose_transpose_move_ones(
            inact.src_shape, op.options.transpose_axes
        )
        ref = tuple(range(len(move_ones)))
        # without below condition, it can cause infinite loop
        if move_ones == ref:
            return None
        new_shape = tuple(inact.src_shape[i] for i in move_ones)
        leading_ones_after = 0
        for i, s in enumerate(new_shape):
            if is_static_one(s) and layout[i] == i:
                leading_ones_after += 1
            else:
                break
        if leading_ones_after > 1:
            return None
        return op

    @decompose_transpose.transform
    def decompose_transpose(self, *args, **kwargs):
        transpose = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        move_ones, layout = decompose_transpose_move_ones(
            inact.src_shape, transpose.options.transpose_axes
        )
        new_shape = operator.itemgetter(*move_ones)(inact.src_shape)
        new_outact = builder.make_reshape(new_inact, new_shape)
        if layout != tuple(range(len(move_ones))):
            new_outact = builder.make_transpose(new_outact, layout)
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose)
        return builder.build()

    @pattern
    def move_ones_to_front(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Transpose:
            return None
        inact = op.inacts[0]
        ndim = inact.src_dim
        if ndim < 4:
            return None
        outact = op.outacts[0]
        outact_src_shape = outact.src_shape
        perm = op.options.transpose_axes
        # (1,1,56,1,64)->(1,1,1,56,64), axes=[3,1,0,2,4]
        non_one_axes = [
            i for i, x in enumerate(inact.src_shape) if not is_static_one(x)
        ]
        perm_non_one = [
            int(ax) for ax in perm if not is_static_one(outact_src_shape[ax])
        ]
        if non_one_axes == perm_non_one:
            return op
        return None

    @move_ones_to_front.transform
    def move_ones_to_front(self, *args, **kwargs):
        transpose = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        outact = transpose.outacts[0]
        new_outact = builder.make_reshape(new_inact, outact.src_shape)
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose)
        return builder.build()

    @pattern
    def fix_transpose_axes_for_static_one(self, op: Operator, **kwargs):
        """
        AXES=024135 , (1,1,1,196,16,32)->(1,1,16,1,196,32)
        => AXES014235
        """
        if op.layertype != LayerType.Transpose:
            return None
        inact = op.inacts[0]
        if inact.src_dim < 4:
            return None

        in_shape = inact.src_shape
        static_one_indices = [i for i, s in enumerate(in_shape) if is_static_one(s)]
        # static_one_indices = (0,1,2)
        # axes_check=(0,2,1)
        axes_check = tuple(
            int(ax) for ax in op.options.transpose_axes if ax in static_one_indices
        )
        if axes_check != tuple(sorted(axes_check)):
            return op
        return None

    @fix_transpose_axes_for_static_one.transform
    def fix_transpose_axes_for_static_one(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        in_shape = inact.src_shape
        static_one_indices = [i for i, s in enumerate(in_shape) if is_static_one(s)]
        axes = transpose.options.transpose_axes
        sorted_one_indices = sorted(static_one_indices)
        new_axes = []
        cnt = 0
        for ax in transpose.options.transpose_axes:
            if int(ax) in static_one_indices:
                new_axes.append(sorted_one_indices[cnt])
                cnt += 1
            else:
                new_axes.append(ax)
        if new_axes == tuple(range(len(axes))):
            new_outact = builder.make_identity(new_inact)
        else:
            new_outact = builder.make_transpose(new_inact, new_axes)
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose)
        return builder.build()

    @pattern
    def remove_leading_ones(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Transpose:
            return None
        transpose = op
        transpose_inact = transpose.inacts[0]
        rank = transpose_inact.src_dim
        axes = transpose.options.transpose_axes
        if rank <= 4 or axes == tuple(range(int(rank))):
            return None

        leading_cnt = 0
        shape = transpose_inact.src_shape
        for ax, s in zip(axes, shape):
            if ax == leading_cnt and is_static_one(s):
                leading_cnt += 1
            else:
                break
        if leading_cnt > 1:
            return transpose, leading_cnt
        return None

    @remove_leading_ones.transform
    def remove_leading_ones(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, leading_cnt = self.matched_pattern
        transpose_inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(transpose_inact, add_input_map=True)
        # (0,1,3,2,4,5), (1,1,a,b,c,d)->(1,1,b,a,c,d) => (0,2,1,3,4), (1,a,b,c,d)->(1,b,a,c,d)
        # (0,1,2,3,5,4), (1,1,1,a,b,c)->(1,1,1,a,c,b) => (0,1,3,2), (1,a,b,c) -> (1,a,c,b)
        orig_rank = transpose_inact.src_dim
        final_rank = max(orig_rank - leading_cnt, 4)  # max(6-3,4) = 4
        n_leading_ones = max(0, final_rank - (orig_rank - leading_cnt))
        new_shape = (1,) * n_leading_ones + new_inact.src_shape[leading_cnt:]
        new_outact = builder.make_reshape(new_inact, new_shape)
        axes_shift = orig_rank - final_rank
        new_axes = tuple(range(n_leading_ones)) + tuple(
            ax - axes_shift for ax in transpose.options.transpose_axes[leading_cnt:]
        )
        new_outact = builder.make_transpose(new_outact, new_axes)
        old_outact = transpose.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose)
        return builder.build()

    @pattern
    def transpose_to_reshape(self, op: Operator, **kwargs):
        """
        transpose0132-[matmul]은 제외함.
        """
        pat = find_operator_sequence(op, "TR")
        transpose = None
        if pat is not None:
            transpose, _ = pat
        else:
            pat = find_operator_sequence(op, "RT")
            if pat is not None:
                _, transpose = pat
        if transpose is None:
            return None
        shape_in = transpose.inacts[0].src_shape
        if not is_reshape_like_transpose(shape_in, transpose.options.transpose_axes):
            return None

        if transpose.options.transpose_axes == (0, 1, 3, 2):
            transpose_outact = transpose.outacts[0]
            for cop in transpose_outact.consumer_ops:
                if cop.layertype == LayerType.MatMul:
                    return None
        if transpose.options.transpose_axes == (0, 1, 3, 2):
            # replace_op에 있는 Reshape과 무한루프 생성함.
            n, h, w, c = transpose.inacts[0].src_shape
            if n == h == c == 1 or n == h == w == 1:
                return None
        return transpose

    @transpose_to_reshape.transform
    def transpose_to_reshape(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        old_outact = transpose.outacts[0]
        new_outact = builder.make_reshape(new_inact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose)
        return builder.build()

    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        (1,h,w,c)->(1,1,h,w,c)->(1,c,h,1,w)->(1,c,h,w)
        """
        pat = find_operator_sequence(op, "R[1hwc->11hwc] T04213 R[1ch1w->1chw]")
        if pat is None:
            return None
        reshape0, transpose, reshape1 = pat
        return reshape0, transpose, reshape1

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        reshape0_inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(reshape0_inact, add_input_map=True)
        new_outact = builder.make_transpose(new_inact, (0, 3, 1, 2))
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        """
        (1,h,w,c)->(1,1,h,w,c)->(1,h,1,c,w)->(1,h,c,w)
        =============================================
        (1,h,w,c)->(1,1,h,w,c)->(1,h,1,w,c)->(1,h,w,c)
        """
        trans = [
            "T02134",
            "T02143",
        ]
        for tr in trans:
            pat = find_operator_sequence(op, "R[1hwc->11hwc]" + tr + "R")
            if pat is not None:
                return pat
            pat = find_operator_sequence(op, "R[h1wc->11hwc]" + tr + "R")
            if pat is not None:
                return pat
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        reshape0_inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(reshape0_inact, add_input_map=True)
        if new_inact.src_shape[0] != 1:
            h, b, w, c = new_inact.src_shape
            assert b == 1, f"Expected h to be 1, got {b}"
            new_inact = builder.make_reshape(new_inact, (1, h, w, c))
        if transpose.options.transpose_axes == (0, 2, 1, 3, 4):
            new_outact = builder.make_identity(new_inact)
        elif transpose.options.transpose_axes == (0, 2, 1, 4, 3):
            new_outact = builder.make_transpose(new_inact, (0, 1, 3, 2))
        else:
            raise NotImplementedError("code should not reach here")
        old_outact = reshape1.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        """
        (1,1,196,512)-[reshape]->(1,196,16,32)-[transpose2013]->(16,1,196,32)-[reshape]->(1,16,196,32)
        """
        pat = find_operator_sequence(op, "R[11w(cd)->1wcd] T2013 R[w1cd->1wcd]")
        return pat

    @case2.transform
    def case2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        _, transpose, reshape1 = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_inact, (0, 2, 1, 3))
        old_outact = reshape1.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape1)
        return builder.build()


@DataFormatCanonicalizationRuleSet.register
class ReshapeTranspose(TransformRule):
    @pattern
    def rtr_channel_split(self, op: Operator, *args, **kwargs):
        """
        todo: generalize this rule

        channel_split _transpose to channel first, then reshape back to merge channels

        (1,56,56,64)-[reshape]->(1,56,56,2,32)->[transpose03412]->(1,2,32,56,56)-[reshape]->(1,64,56,56)
        =>
        (1,56,56,64)-[transpose0312]->(1,64,56,56)
        """
        #
        pat = find_operator_sequence(op, "R[1hw(bc)->1hwbc] T03412 R[1bchw->1(bc)hw]")
        if pat is not None:
            reshape0, transpose, reshape1 = pat
            n, h, w, c = reshape0.inacts[0].src_shape
            reshape1_outact = reshape1.outacts[0]
            if reshape1_outact.src_shape == (n, c, h, w):
                return reshape0, transpose, reshape1
        return None

    @rtr_channel_split.transform
    def rtr_channel_split(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_inact, (0, 3, 1, 2))
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()


@DataFormatCanonicalizationRuleSet.register
class TransposeReshape(TransformRule):
    @pattern
    def t0231_reshape(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T0231 R[1wdc->11(wd)c]")
        if pat is None:
            return None
        transpose, reshape = pat
        return transpose, reshape

    @t0231_reshape.transform
    def t0231_reshape(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        n, w, d, c = reshape.inacts[0].src_shape
        new_outact = builder.make_reshape(new_inact, (1, 1, c, w * d))
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def t0321_reshape(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T0321 R[1cw1->11cw]")
        if pat is None:
            return None
        transpose, reshape = pat
        return transpose, reshape

    @t0321_reshape.transform
    def t0321_reshape(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_inact, (0, 1, 3, 2))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def t0312_reshape(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T0312 R[1c1w->1cw1]")
        if pat is None:
            return None
        transpose, reshape = pat
        return transpose, reshape

    @t0312_reshape.transform
    def t0312_reshape(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_inact, (0, 3, 2, 1))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()
