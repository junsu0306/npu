import collections
import operator
from types import SimpleNamespace
from typing import List

import numpy

from mblt import Operator, LayerType
from mblt.core import TransformRule, pattern
from mblt.operator import reshape_output_shape, REDUCE_OPS
from mblt.operator.utils import interpret_slice
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    is_transpose,
    is_reduce,
    is_biop_const,
    is_biop_wrapper,
    check_input_npu_stride,
    is_reshape_with_expr,
)
from mblt.subgraph.util.reshape_check import reshape_check
from mblt.transform.ruleset.util import simple_swap
from mblt.transform.transform_result import (
    RemoveIdentityResult,
    OpTransformResultV2Builder,
    RemoveIdentitySequenceResult,
)
from ._ruleset import DataFlowDirectRuleSet


def handle_pre_transpose_and_op(op: Operator, pre_transpose_axes):
    reverse_axes = [0] * len(pre_transpose_axes)
    for i, axis in enumerate(pre_transpose_axes):
        reverse_axes[axis] = i

    builder = OpTransformResultV2Builder()
    new_inacts = []
    for inact in op.inacts:
        if is_transpose(inact.producer_op, pre_transpose_axes):
            transpose = inact.producer_op
            transpose_inact = transpose.inacts[0]
            new_inact = builder.copy_activationspec(transpose_inact, add_input_map=True)
            builder.remove_connectivity_and_invalidate(transpose, op)
        else:
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inact = builder.make_transpose(new_inact, reverse_axes)
        new_inacts.append(new_inact)

    kwargs = {}
    if op.layertype in (LayerType.Concatenate, LayerType.IndexedItemSelector):
        kwargs["axis"] = pre_transpose_axes[op.options.axis]
    elif op.layertype == LayerType.Resize:
        scales = op.options.scales
        sizes = op.options.sizes
        if scales is not None and len(scales) == 4:
            kwargs["scales"] = operator.itemgetter(*reverse_axes)(scales)
        if sizes is not None and len(sizes) == 4:
            kwargs["sizes"] = operator.itemgetter(*reverse_axes)(sizes)
        if not kwargs:
            raise NotImplementedError("unknown resize case")
    elif op.layertype in REDUCE_OPS:
        kwargs["reduce_axes"] = tuple(
            pre_transpose_axes[ax] for ax in op.options.reduce_axes
        )
    elif op.layertype in (
        LayerType.SumNormalization,
        LayerType.L2Normalization,
        LayerType.L1Normalization,
    ):
        kwargs["norm_axis"] = tuple(
            pre_transpose_axes[ax] for ax in op.options.norm_axis
        )
    elif is_biop_const(op):
        const_val = op.get_tensor(op.options.constant).value
        if const_val.ndim < op.inacts[0].src_dim:
            const_val = numpy.broadcast_to(
                const_val, tuple(map(int, op.inacts[0].src_shape))
            )
        constant = numpy.transpose(const_val, reverse_axes)
        kwargs["constant"] = constant
    elif op.layertype == LayerType.Slice:
        kwargs["axis"] = tuple(pre_transpose_axes[ax] for ax in op.options.axis)

    new_outact = builder.with_new_input_and_options(op, *new_inacts, **kwargs)
    new_outact = builder.make_transpose(new_outact, pre_transpose_axes)
    old_outact = op.outacts[0]
    builder.add_output_map(new_outact, old_outact)
    builder.remove_connectivity_and_invalidate(op)
    return builder.build()


def is_headerview(transpose):
    if transpose.options.transpose_axes == (0, 2, 1, 3):
        reshape = transpose.inacts[0].producer_op
        if reshape is not None and reshape.layertype == LayerType.Reshape:
            return reshape_check(
                "11(hw)c->1hwc",
                reshape.inacts[0].src_shape,
                reshape.outacts[0].src_shape,
            ) or reshape_check(
                "1hw(nc)->1(hw)nc",
                reshape.inacts[0].src_shape,
                reshape.outacts[0].src_shape,
            )
    # if transpose.options.transpose_axes == (0, 3, 2, 1):
    #     """
    #     The following is equivalent to:
    #     (1, 38, 38, 3) -> (1, 1, 1444, 3) -> (1, 3, 1444, 1)
    #     is logically equivalent to:
    #     (1, 38, 38, 3) -> (1, 1444, 3, 1) -> (1, 3, 1444, 1)
    #     However, due to shape normalization, the intermediate representation is different.
    #     """
    #     reshape = transpose.inacts[0].producer_op
    #     if reshape is not None and reshape.layertype == LayerType.Reshape:
    #         return reshape_check(
    #             "1hwc->11(hw)c",
    #             reshape.inacts[0].src_shape,
    #             reshape.outacts[0].src_shape,
    #         )

    if transpose.options.transpose_axes == (0, 3, 1, 2, 4):
        reshape = transpose.inacts[0].producer_op
        if reshape is not None and reshape.layertype == LayerType.Reshape:
            return reshape_check(
                "1hw(nc)->1hwnc",
                reshape.inacts[0].src_shape,
                reshape.outacts[0].src_shape,
            )
    return False


def is_static_one(x):
    return x.value == 1 and not getattr(x, "dynamic", False)


def _is_identity(op):
    if op.layertype == LayerType.Identity:
        return True

    if op.layertype == LayerType.Transpose:
        return op.options.transpose_axes == tuple(range(len(op.inacts[0].src_shape)))

    if op.layertype == LayerType.Reshape:
        inact = op.inacts[0]
        return op.options.new_shape and inact.src_shape == reshape_output_shape(
            inact.src_shape, op.options.new_shape
        )

    if op.layertype == LayerType.MultiplyConstant:
        # need to consider broadcast case
        inact = op.inacts[0]
        outact = op.outacts[0]
        const_value = op.get_tensor(op.options.constant).value
        return inact.src_shape == outact.src_shape and numpy.allclose(const_value, 1.0)

    if op.layertype in (LayerType.AddingConstant, LayerType.SubConstant):
        # need to consider broadcast case
        inact = op.inacts[0]
        outact = op.outacts[0]
        const_value = op.get_tensor(op.options.constant).value
        return inact.src_shape == outact.src_shape and numpy.allclose(const_value, 0.0)

    if op.layertype == LayerType.Slice:
        inact = op.inacts[0]
        outact = op.outacts[0]
        for i, ax in enumerate(op.options.axis):
            if inact.src_shape[ax].dynamic:
                return False
            if inact.src_shape[ax] != outact.src_shape[ax]:
                return False
        return True

    if op.layertype == LayerType.Expand:
        inact = op.inacts[0]
        outact = op.outacts[0]
        return inact.src_shape == outact.src_shape

    if op.layertype == LayerType.PadGeneric:
        return op.options.pad_mode == "constant" and all(
            x == 0 for x in op.options.padding_list
        )

    return False


@DataFlowDirectRuleSet.register
class RemoveIdentity(TransformRule):
    @pattern
    def identity_sequence(self, op: Operator, **kwargs):
        seq = []
        curr_op = op
        while curr_op is not None and _is_identity(curr_op):
            seq.append(curr_op)
            curr_op = curr_op.inacts[0].producer_op
            if curr_op is None or not curr_op.valid:
                return None
            if 1 != len(curr_op.outacts[0].consumer_ops):
                return None
        if seq:
            return tuple(reversed(seq))
        return None

    @identity_sequence.transform
    def identity_sequence(self, *args, **kwargs):
        seq = self.matched_pattern
        if len(seq) == 1:
            return RemoveIdentityResult(seq[0])
        # 여기서 make_identity하면, identitiy-identitiy-identity같은 경우는 builder에 의해 계속 같은 형상이 생성됨.
        return RemoveIdentitySequenceResult(seq)

    @pattern
    def identity_simple(self, op: Operator, **kwargs):
        if _is_identity(op):
            return op
        return None

    @identity_simple.transform
    def identity_simple(self, op: Operator, **kwargs):
        return RemoveIdentityResult(op)

    @pattern
    def transpose_transpose(self, op: Operator, *args, **kwargs):
        """
        to identity or single transpose
        """
        # transpose-transpose
        pat = find_operator_sequence(op, "TT")
        if pat is None:
            return None
        return pat

    @transpose_transpose.transform
    def transpose_transpose(self, *args, **kwargs):
        trans0, trans1 = self.matched_pattern
        old_inact = trans0.inacts[0]
        old_outact = trans1.outacts[0]
        indexer = tuple(range(old_inact.src_dim))
        indexer = operator.itemgetter(*trans0.options.transpose_axes)(indexer)
        indexer = operator.itemgetter(*trans1.options.transpose_axes)(indexer)
        indexer = tuple(indexer)

        builder = OpTransformResultV2Builder()
        new_outact = builder.copy_activationspec(old_inact, add_input_map=True)
        if indexer == tuple(range(len(indexer))):
            new_outact = builder.make_identity(new_outact)
        else:
            new_outact = builder.make_transpose(new_outact, indexer)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(trans0, trans1)
        return builder.build()

    @pattern
    def avgpool(self, op: Operator, **kwargs):
        if not (
            op.layertype == LayerType.Pooling
            and op.options.pool_type.lower() == "avgpool"
        ):
            return None
        opt = op.options
        if not (
            1 == opt.h_kernel == opt.w_kernel
            and 1 == opt.h_dilation == opt.w_dilation
            and 1 == opt.h_stride == opt.w_stride
            and 0
            == opt.north_padding
            == opt.south_padding
            == opt.west_padding
            == opt.east_padding
        ):
            return None
        return op

    @avgpool.transform
    def avgpool(self, op, **kwargs):
        return RemoveIdentityResult(op)


@DataFlowDirectRuleSet.register
class TransposeAndOp(TransformRule):

    @pattern
    def transpose_concat(self, concat: Operator, *args, **kwargs):
        if concat.layertype != LayerType.Concatenate:
            return None
        axes = collections.defaultdict(int)
        for inact in concat.inacts:
            if inact.src_dim != 4:
                return None
            transpose = inact.producer_op
            if transpose.layertype == LayerType.Transpose:
                if is_headerview(transpose):
                    return None
                key = tuple(map(int, transpose.options.transpose_axes))
                axes[key] += 1
        if not axes:
            return None
        target_axes = max(axes, key=axes.get)
        incnt = axes[target_axes]
        ref = len(concat.options.inputs) // 2
        if incnt > ref:
            return concat, target_axes
        reverse_axes = [0] * len(target_axes)
        for i, axis in enumerate(target_axes):
            reverse_axes[axis] = i
        outact = concat.outacts[0]
        outcnt = sum(is_transpose(cop, reverse_axes) for cop in outact.consumer_ops)
        if incnt == ref and outcnt > 1:
            return concat, target_axes
        return None

    @transpose_concat.transform
    def transpose_concat(self, *args, **kwargs):
        concat, target_axes = self.matched_pattern
        return handle_pre_transpose_and_op(concat, target_axes)

    @pattern
    def case_actfn(self, op: Operator, *args, **kwargs):
        pat = find_operator_sequence(op, "T actfn")
        return pat

    @case_actfn.transform
    def case_actfn(self, *args, **kwargs):
        trans, actfn = self.matched_pattern
        return simple_swap(trans, actfn)

    @pattern
    def case_resize(self, op: Operator, *args, **kwargs):
        """
        transpose0312 + resize
        """
        pat = find_operator_sequence(op, "T0312", LayerType.Resize)
        if pat is not None:
            trans0312, resize = pat
            if resize.options.scales is not None and len(resize.options.scales) == 4:
                return trans0312, resize
            if resize.options.sizes is not None and len(resize.options.sizes) == 4:
                return trans0312, resize
        return None

    @case_resize.transform
    def case_resize(self, *args, **kwargs):
        trans0312, resize = self.matched_pattern
        return handle_pre_transpose_and_op(resize, trans0312.options.transpose_axes)

    @pattern
    def case_reduce(self, op: Operator, *args, **kwargs):
        pat = find_operator_sequence(op, "T", is_reduce)
        if pat is None:
            return None
        transpose, reduce = pat
        if reduce.inacts[0].src_dim == 4:
            return None
        if is_headerview(transpose):
            return None
        if 0 not in reduce.options.reduce_axes and bool(reduce.options.keep_dims):
            return transpose, reduce
        return None

    @case_reduce.transform
    def case_reduce(self, op: Operator, *args, **kwargs):
        trans, reduce = self.matched_pattern
        return handle_pre_transpose_and_op(reduce, trans.options.transpose_axes)

    @pattern
    def case_norm_with_axis(self, op: Operator, *args, **kwargs):
        def is_norm_with_axis(op):
            return op.layertype in (
                LayerType.SumNormalization,
                LayerType.L2Normalization,
                LayerType.L1Normalization,
            )

        pat = find_operator_sequence(op, "T0312", is_norm_with_axis)
        if pat is None:
            return None
        transpose, norm = pat
        if norm.inacts[0].src_dim != 4:
            return None
        if is_headerview(transpose):
            return None
        if 0 not in norm.options.norm_axis:
            return transpose, norm
        return None

    @case_norm_with_axis.transform
    def case_norm_with_axis(self, *args, **kwargs):
        trans, norm = self.matched_pattern
        return handle_pre_transpose_and_op(norm, trans.options.transpose_axes)

    @pattern
    def case_biop_const(self, op: Operator, *args, **kwargs):
        pat = find_operator_sequence(op, "T", is_biop_const)
        if pat is None:
            return None
        transpose, xconst = pat
        if xconst.inacts[0].src_dim != 4:
            return None
        if is_headerview(transpose):
            return None
        outact = xconst.outacts[0]
        if len(outact.consumer_ops) == 1:
            cop = outact.consumer_ops[0]
            if cop.layertype in (LayerType.Convolution, LayerType.Identity):
                return None
        return transpose, xconst

    @case_biop_const.transform
    def case_biop_const(self, op: Operator, *args, **kwargs):
        transpose, xconst = self.matched_pattern
        return handle_pre_transpose_and_op(xconst, transpose.options.transpose_axes)

    @pattern
    def case_slice(self, op: Operator, *args, **kwargs):
        pat = find_operator_sequence(op, "T S[1]")
        if pat is None:
            return None
        transpose, slice_ = pat
        if is_headerview(transpose):
            return None
        # if check_input_npu_stride(transpose.inacts[0].producer_op):
        #     return transpose, slice_
        return None

    @case_slice.transform
    def case_slice(self, *args, **kwargs):
        transpose, slice_ = self.matched_pattern
        return handle_pre_transpose_and_op(slice_, transpose.options.transpose_axes)

    @pattern
    def case_slice_transpose(self, op: Operator, *args, **kwargs):
        pat = find_operator_sequence(op, "TST")
        if pat is None:
            return None
        trans0, slice_, trans1 = pat

        old_inact = trans0.inacts[0]
        old_outact = trans1.outacts[0]
        indexer = tuple(range(old_inact.src_dim))
        indexer = operator.itemgetter(*trans0.options.transpose_axes)(indexer)
        indexer = operator.itemgetter(*trans1.options.transpose_axes)(indexer)
        indexer = tuple(indexer)
        if indexer == tuple(range(len(indexer))):
            return trans0, slice_, trans1
        return None

    @case_slice_transpose.transform
    def case_slice_transpose(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        trans0, slice_, trans1 = self.matched_pattern
        pre_axes = trans0.options.transpose_axes
        new_axis = tuple(pre_axes[ax] for ax in slice_.options.axis)
        inact = trans0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(
            slice_, new_inact, axis=new_axis
        )
        old_outact = trans1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(trans0, slice_, trans1)
        return builder.build()

    @pattern
    def case_selector(self, op: Operator, *args, **kwargs):
        pat = find_operator_sequence(op, "T0213", LayerType.IndexedItemSelector)
        if pat is not None:
            transpose, selector = pat
            if selector.options.axis in (3, -1):
                return transpose, selector
        pat = find_operator_sequence(op, "T0312", LayerType.IndexedItemSelector)
        if pat is not None:
            transpose, selector = pat
            return transpose, selector
        return None

    @case_selector.transform
    def case_selector(self, *args, **kwargs):
        transpose, selector = self.matched_pattern
        return handle_pre_transpose_and_op(selector, transpose.options.transpose_axes)


@DataFlowDirectRuleSet.register
class TransposeBiOp(TransformRule):
    @pattern
    def case0(self, biop: Operator, *args, **kwargs):
        """
        transpose0312 + add/mul/div/sub + (act + trans0231)
        """
        if not is_biop_wrapper(biop):
            return None

        def _is_trans0312(op):
            if op.layertype == LayerType.Reshape:
                reshape_inact = op.inacts[0]
                reshape_outact = op.outacts[0]
                if reshape_inact.src_dim == 4 and reshape_outact.src_dim == 4:
                    num_ones = sum(x == 1 for x in reshape_inact.src_shape)
                    if num_ones == 3:
                        return reshape_outact.src_shape == operator.itemgetter(
                            0, 3, 1, 2
                        )(reshape_inact.src_shape)
            return is_transpose(op, (0, 3, 1, 2))

        incnt = sum(_is_trans0312(inact.producer_op) for inact in biop.inacts)
        if incnt == 2:
            return biop
        elif incnt == 1:
            outact = biop.outacts[0]
            outcnt = sum(is_transpose(cop, (0, 2, 3, 1)) for cop in outact.consumer_ops)
            if outcnt > 0:
                return biop
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        biop = self.matched_pattern
        return handle_pre_transpose_and_op(biop, (0, 3, 1, 2))

    @pattern
    def case1(self, biop: Operator, *args, **kwargs):
        if not is_biop_wrapper(biop):
            return None
        axes = []
        for inact in biop.inacts:
            if is_transpose(inact.producer_op):
                transpose = inact.producer_op
                # 이 조건이 없으면 batch가 1보다 크도록 나쁘게 바뀜.
                if (
                    inact.src_dim == 4
                    and inact.src_shape[0] == 1
                    and transpose.inacts[0].src_shape[0] > 1
                ):
                    return None
                axes.append(inact.producer_op.options.transpose_axes)
            else:
                return None
        if axes[0] == axes[1]:
            outact = biop.outacts[0]
            for cop in outact.consumer_ops:
                if (
                    cop.layertype == LayerType.Transpose
                    and axes[0] == cop.options.transpose_axes
                ):
                    return biop
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop = self.matched_pattern
        axes = None
        new_inacts = []
        for inact in biop.inacts:
            transpose = inact.producer_op
            trans_inact = transpose.inacts[0]
            new_inact = builder.copy_activationspec(trans_inact, add_input_map=True)
            axes = transpose.options.transpose_axes
            new_inacts.append(new_inact)
            builder.remove_connectivity_and_invalidate(transpose, biop)
        new_outact = builder.with_new_input_and_options(biop, new_inacts)
        new_outact = builder.make_transpose(new_outact, axes)
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(biop)
        return builder.build()


@DataFlowDirectRuleSet.register
class DivConstToMulConst(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype == LayerType.DivConstant and not op.options.is_const_first:
            return op
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        divconst = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = divconst.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        constant = divconst.get_tensor(divconst.options.constant).value
        new_constant = 1.0 / constant
        new_outact = builder.make_mul(new_inact, new_constant)
        old_outact = divconst.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(divconst)
        return builder.build()


@DataFlowDirectRuleSet.register
class PadGenericTranspose(TransformRule):

    @pattern
    def case0(self, op: Operator, **kwargs):
        """pad_generic-transpose1
        transpose1-padgeneric
        """
        pat = find_operator_sequence(op, LayerType.PadGeneric, "T")
        if pat is None:
            return None
        return pat

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        pad, transpose = self.matched_pattern
        old_inact = pad.inacts[0]
        rank = old_inact.src_dim
        assert (
            len(pad.options.padding_list) == rank * 2
        ), f"padding_list={pad.options.padding_list} is not valid for rank={rank}"
        pad_begin = pad.options.padding_list[:rank]
        pad_end = pad.options.padding_list[rank:]
        pad_begin = operator.itemgetter(*transpose.options.transpose_axes)(pad_begin)
        pad_end = operator.itemgetter(*transpose.options.transpose_axes)(pad_end)
        padding_list = pad_begin + pad_end
        new_outact = builder.copy_activationspec(old_inact, add_input_map=True)
        new_outact = builder.make_transpose(
            new_outact, transpose.options.transpose_axes
        )
        new_outact = builder.with_new_input_and_options(
            pad, new_outact, padding_list=padding_list
        )
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(pad, transpose)
        return builder.build()


@DataFlowDirectRuleSet.register
class SliceConcatenate(TransformRule):

    @pattern
    def case0(self, op: Operator, **kwargs):
        """identity case"""
        if op.layertype != LayerType.Concatenate:
            return None
        concat = op
        ax = concat.options.axis
        outact = concat.outacts[0]
        rank = outact.src_dim
        if ax < 0:
            ax += rank
        ref_slice_inact = None
        acc = 0
        slices = []
        for inact in concat.inacts:
            slice_ = inact.producer_op
            if slice_ is None:
                return None
            if slice_.layertype != LayerType.Slice:
                return None
            if len(slice_.options.axis) != 1:
                return None

            slice_inact = slice_.inacts[0]
            if ref_slice_inact is None:
                ref_slice_inact = slice_inact
            else:
                if ref_slice_inact.name != slice_inact.name:
                    return None
            rank = slice_inact.src_dim
            slice_ax = slice_.options.axis[0]
            if slice_ax < 0:
                slice_ax += rank
            if slice_ax != ax:
                return None
            if not (slice_.options.step is None or slice_.options.step == (1,)):
                return None
            s_ = slice_.options.start[0]
            if s_ < 0:
                s_ += slice_inact.src_shape[slice_ax]
            e_ = slice_.options.end[0]
            if e_ < 0:
                e_ += slice_inact.src_shape[slice_ax]
            if s_ != acc:
                return None
            acc = e_
            slices.append(slice_)
        return slices, concat

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        slices, concat = self.matched_pattern
        inact = slices[0].inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_identity(new_inact)
        old_outact = concat.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        for slice_ in slices:
            builder.remove_connectivity_and_invalidate(slice_, concat)
        return builder.build()


@DataFlowDirectRuleSet.register
class ReshapeTranspose(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[1h1c->h11c] T2103")
        return pat

    @case0.transform
    def case0(self, *args, **kwargs):
        reshape0, transpose = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reshape0.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        """
        w1c->1w1c-[transpose0213]->(11wc)
        """
        pat = find_operator_sequence(op, "R[w1c->1w1c] T0213")
        if pat is None:
            return None
        reshape, transpose = pat
        reshape_inact = reshape.inacts[0]
        if not reshape_inact.src_shape[1].dynamic:
            return pat
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        reshape0, transpose = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reshape0.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        transpose_outact = transpose.outacts[0]
        new_outact = builder.make_reshape(new_outact, transpose_outact.src_shape)
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose)
        return builder.build()


@DataFlowDirectRuleSet.register
class TransposeReshape(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T2103 R[w11c->1w1c]")
        return pat

    @case0.transform
    def case0(self, *args, **kwargs):
        transpose, reshape = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = transpose.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T0213 R[1w1c->w1c]")
        return pat

    @case1.transform
    def case1(self, *args, **kwargs):
        transpose, reshape = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = transpose.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        new_shape = reshape.outacts[0].src_shape
        new_outact = builder.make_reshape(new_outact, new_shape)
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T0312 R[nchw->n1c(hw)] T0132")
        if pat is None:
            return None
        transpose0, reshape, transpose1 = pat
        transpose0_inact = transpose0.inacts[0]
        n, h, w, c = transpose0_inact.src_shape
        if h > 1 and w > 1:
            return transpose0, reshape, transpose1
        return None

    @case2.transform
    def case2(self, *args, **kwargs):
        transpose0, reshape, transpose1 = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = transpose0.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        n, _, c, hw = reshape.outacts[0].src_shape
        new_outact = builder.make_reshape(new_outact, (n, 1, -1, c))
        old_outact = transpose1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose0, reshape, transpose1)
        return builder.build()

    @pattern
    def case3(self, op: Operator, **kwargs):
        """
        # todo: 여기 그냥 channel을 앞으로 가져온 후 reshape으로 factor하는 경우는 일반화하기.
        (1,14,14,1152)-[transpose0312]-(1,1152,14,14)-[reshape]-(1,3,6,64,196)
        =>
        (1,14,14,1152)-[reshape]-(1,196,3,6,64)-[transpose02341]->(1,3,6,64,196)
        """
        pat = find_operator_sequence(op, "T0312 R[1(cde)hw->1cde(hw)]")
        if pat is None:
            return None
        transpose0, reshape = pat
        pop = transpose0.inacts[0].producer_op
        if check_input_npu_stride(pop):
            return transpose0, reshape
        return None

    @case3.transform
    def case3(self, *args, **kwargs):
        transpose0, reshape = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = transpose0.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        n, c, d, e, hw = reshape_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, hw, c, d, e))
        new_outact = builder.make_transpose(new_outact, (0, 2, 3, 4, 1))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose0, reshape)
        return builder.build()

    @staticmethod
    def _get_single_non_one_dim(shape):
        non_one_dims = [dim for dim in shape if not is_static_one(dim)]
        if len(non_one_dims) != 1:
            return None
        if sum(1 for dim in shape if is_static_one(dim)) != len(shape) - 1:
            return None
        return non_one_dims[0]

    @pattern
    def case4(self, op: Operator, **kwargs):
        """
        If the transpose input has exactly one non-static-1 axis and the reshape output
        also keeps exactly one non-static-1 axis with the same value, transpose does not
        change the effective tensor layout and the sequence can be replaced by reshape only.
        """
        pat = find_operator_sequence(op, "TR")
        if pat is None:
            return None
        transpose, reshape = pat
        acts = [
            transpose.inacts[0],
            transpose.outacts[0],
            reshape.inacts[0],
            reshape.outacts[0],
        ]
        for act in acts:
            if act.src_dim != 4:
                return None

        in_non_one = self._get_single_non_one_dim(transpose.inacts[0].src_shape)
        out_non_one = self._get_single_non_one_dim(reshape.outacts[0].src_shape)
        if in_non_one is None or out_non_one is None:
            return None
        if in_non_one != out_non_one:
            return None
        return transpose, reshape

    @case4.transform
    def case4(self, *args, **kwargs):
        transpose0, reshape = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = transpose0.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_reshape(new_outact, reshape.outacts[0].src_shape)
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose0, reshape)
        return builder.build()


@DataFlowDirectRuleSet.register
class ReshapeTransposeReshape(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[1h1(wc)->h1wc] T2130 R[w1ch->1wch]")
        return pat

    @case0.transform
    def case0(self, *args, **kwargs):
        reshape0, transpose, reshape1 = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reshape0.inacts[0]
        reshape0_outact = reshape0.outacts[0]
        h, b, w, c = reshape0_outact.src_shape
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_reshape(new_outact, (b, h, w, c))
        new_outact = builder.make_transpose(new_outact, (0, 2, 3, 1))
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        """R[bh1(wc)->hbwc] T2103 R[wbhc->bwhc]"""
        pat = find_operator_sequence(op, "R[1h1(wc)->h1wc] T2103 R[w1hc->1whc]")
        return pat

    @case1.transform
    def case1(self, *args, **kwargs):
        reshape0, transpose, reshape1 = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reshape0.inacts[0]
        reshape0_outact = reshape0.outacts[0]
        h, b, w, c = reshape0_outact.src_shape
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_reshape(new_outact, (b, h, w, c))
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        """R[bhwc->hbwc] T2103 R[wbhc->wbhc]"""
        pat = find_operator_sequence(op, "R[1hwc->h1wc] T2103 R[w1hc->1w1(hc)]")
        return pat

    @case2.transform
    def case2(self, *args, **kwargs):
        reshape0, transpose, reshape1 = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reshape0.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        b, h, w, c = new_outact.src_shape
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        new_outact = builder.make_reshape(new_outact, (b, w, 1, h * c))
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def case3(self, op: Operator, **kwargs):
        """
        (1,1,2048,96)-[reshape]->(1,64,32,96)-[transpose0312]->(1,96,64,32)-[reshape]->(1,96,32,2,16,2)
        =>
        (1,1,2048,96)-[reshape]->(1,32,2,16,2,96)-[transpose051234]->(1,96,32,2,16,2)
        """
        pat = find_operator_sequence(op, "R[b1(hw)c->bhwc] T0312 R[bc(xy)(st)->bcxyst]")
        if pat is None:
            return None
        reshape0, transpose, reshape1 = pat
        reshape0_inact = reshape0.inacts[0]
        if check_input_npu_stride(reshape0_inact.producer_op):
            return pat
        return None

    @case3.transform
    def case3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        reshape1_outact = reshape1.outacts[0]
        n, c, h1, h2, w1, w2 = reshape1_outact.src_shape  # (1,96,32,2,16,2)
        new_outact = builder.make_reshape(new_inact, (n, h1, h2, w1, w2, c))
        new_outact = builder.make_transpose(new_outact, (0, 5, 1, 2, 3, 4))
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def case4(self, op: Operator, **kwargs):
        """
        (1,1,512,192)-[reshape]->(1,16,2,8,2,192)-[transpose052413]->(1,192,2,2,16,8)-[reshape]->(1,1,768,128)
        =>
        (1,1,512,192)-[reshape]->(1,16,2,8,2,192)-[transpose013524]->(1,16,8,192,2,2)-[reshape]->(1,1,128,768)->[transpose0132]->(1,1,768,128)
        """
        pat = find_operator_sequence(
            op, "R[b1(hxwy)c->bhxwyc] T052413 R[bcxyhw->b1(cxy)(hw)]"
        )
        if pat is None:
            return None
        reshape0, transpose, reshape1 = pat
        reshape0_inact = reshape0.inacts[0]
        reshape0_outact = reshape0.outacts[0]
        if all(
            x > 1 for x in reshape0_outact.src_shape[1:-1]
        ) and check_input_npu_stride(reshape0_inact.producer_op):
            return pat
        return None

    @case4.transform
    def case4(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_inact, (0, 1, 3, 5, 2, 4))
        reshape1_outact = reshape1.outacts[0]
        n, h, w, c = reshape1_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, 1, c, w))
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape1)
        return builder.build()

    @pattern
    def case5(self, op: Operator, **kwargs):
        """
        (1,2,49,768)-[reshape]->(1,2,1,7,7,768)-[transpose013245]->(1,2,7,1,7,768)-[reshape]->
        =>
        (1,2,49,768)-[reshape]->
        """
        pat = find_operator_sequence(op, "R T013245 R")
        if pat is None:
            return None
        reshape0, transpose, reshape1 = pat
        transpose_inact = transpose.inacts[0]
        if 0 < sum(
            1 == int(s) and not s.dynamic for s in transpose_inact.src_shape[2:4]
        ):
            return reshape0, transpose, reshape1
        return None

    @case5.transform
    def case5(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        old_outact = reshape1.outacts[0]
        new_outact = builder.make_reshape(new_inact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def case6(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[1hwc->1(hw)1c] T0312 R[1c(hw)1->1chw]")
        if pat is None:
            return None
        reshape0, transpose, reshape1 = pat
        pop = reshape0.inacts[0].producer_op
        if check_input_npu_stride(pop):
            return reshape0, transpose, reshape1
        return None

    @case6.transform
    def case6(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        reshape1_outact = reshape1.outacts[0]
        n, c, h, w = reshape1_outact.src_shape
        if reshape0.inacts[0].src_shape != (n, h, w, c):
            new_inact = builder.make_reshape(new_inact, (n, h, w, c))
        new_outact = builder.make_transpose(new_inact, (0, 3, 1, 2))
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def case7(self, op: Operator, **kwargs):
        """
        (1,4,x,32) -[reshape]->(1,1,4*x,32)-[transpose0,1,3,2]->(1,1,32,4*x)-[reshape]->(1,32*4,h,w)
        =>
        (1,4,x,32) -[transpose0312]->(1,32,4,x)-[reshape]->(1,32*4,h,w)
        """
        pat = find_operator_sequence(op, "R[1bxc->11(bx)c] T0132 R")
        if pat is None:
            return None
        reshape0, transpose, reshape1 = pat

        inact = reshape0.inacts[0]
        n, h, w, c = inact.src_shape
        if h == 1 or w == 1 or c == 1:
            return None
        reshape1_outact = reshape1.outacts[0]
        if reshape1_outact.src_dim == 4 and reshape1_outact.src_shape[:2] == (1, c * h):
            return reshape0, transpose, reshape1
        return None

    @case7.transform
    def case7(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_inact, (0, 3, 1, 2))
        old_outact = reshape1.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def case8(self, op: Operator, **kwargs):
        """
        (1,80,80,128)-[reshape]->(1,6400,32,4)-[transpose0231]->(1,32,4,6400)-[reshape]->(1,128,80,80)
        =>
        (1,80,80,128)-[transpose0312]->(1,128,80,80)
        """
        pat = find_operator_sequence(
            op, "R[1hw(cd)->1(hw)cd] T0231 R[ncd(hw)->n(cd)hw]"
        )
        if pat is None:
            return None
        reshape0, transpose, reshape1 = pat

        inact = reshape0.inacts[0]
        n, h, w, c = inact.src_shape
        if reshape1.outacts[0].src_shape == (n, c, h, w):
            return reshape0, transpose, reshape1
        return None

    @case8.transform
    def case8(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_inact, (0, 3, 1, 2))
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def case9(self, op: Operator, **kwargs):
        """
        (1,40,40,256)-[reshape]->(1,4,400,256)-[transpose0132]->(1,4,256,400)-[reshape]->(4,8,32,400)
        =>
        (1,40,40,256)-[reshape]->(4,400,8,32)-[transpose0231]->(4,8,32,400)
        """

        def reshape0_check(reshape):
            if reshape.layertype != LayerType.Reshape:
                return False
            reshape_inact = reshape.inacts[0]
            reshape_outact = reshape.outacts[0]
            if not (4 == reshape_inact.src_dim == reshape_outact.src_dim):
                return False
            n, h, w, c = reshape_inact.src_shape
            if h == 1 or w == 1:
                return False
            n1, h1, w1, c1 = reshape_outact.src_shape
            if h1 == 1 or w1 == 1:
                return False
            if n == n1 == 1 and c == c1:
                return True
            return False

        pat = find_operator_sequence(op, reshape0_check, "T0132 R[1h(wd)c->hwdc]")
        if pat is None:
            return None
        reshape0, transpose, reshape1 = pat
        pop = reshape0.inacts[0].producer_op
        if check_input_npu_stride(pop):
            return reshape0, transpose, reshape1
        return None

    @case9.transform
    def case9(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        inact = reshape0.inacts[0]
        old_outact = reshape1.outacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        n, c, d, w = old_outact.src_shape  # (4,8,32,400)
        new_outact = builder.make_reshape(new_inact, (n, w, c, d))
        new_outact = builder.make_transpose(new_outact, (0, 2, 3, 1))
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def case10(self, op: Operator, **kwargs):
        """
        (1,40,40,256)-[reshape]->(1,4,400,256)-[transpose0132]->(1,4,256,400)-[reshape]->(1,32,32,400)
        =>
        (1,40,40,256)-[reshape]->(1,4,400,8,32)-[transpose01342]->(1,4,8,32,400)-[reshape]->(1,32,32,400)
        """

        def reshape0_check(reshape):
            if reshape.layertype != LayerType.Reshape:
                return False
            reshape_inact = reshape.inacts[0]
            reshape_outact = reshape.outacts[0]
            if not (4 == reshape_inact.src_dim == reshape_outact.src_dim):
                return False
            n, h, w, c = reshape_inact.src_shape
            if h == 1 or w == 1:
                return False
            n1, h1, w1, c1 = reshape_outact.src_shape
            if h1 == 1 or w1 == 1:
                return False
            if n == n1 == 1 and c == c1:
                return True
            return False

        def reshape1_check(reshape):
            return is_reshape_with_expr("1h(wd)c->hwdc")(reshape) or reshape0_check(
                reshape
            )

        pat = find_operator_sequence(op, reshape0_check, "T0132", reshape1_check)
        if pat is None:
            return None
        reshape0, transpose, reshape1 = pat
        pop = reshape0.inacts[0].producer_op
        if check_input_npu_stride(pop):
            return reshape0, transpose, reshape1
        return None

    @case10.transform
    def case10(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        inact = reshape0.inacts[0]
        reshape0_outact = reshape0.outacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        reshape1_inact = reshape1.inacts[0]
        reshape1_outact = reshape1.outacts[0]
        n, h, w, c = map(int, reshape1_inact.src_shape)  # (1,4,256,400)
        n1, h1, w1, c1 = map(int, reshape1_outact.src_shape)  # (1,32,32,400)
        c = w // w1  # 256//32 = 8
        d = w1  # 32
        n, h, w, c0 = map(int, inact.src_shape)  # (1,40,40,256)
        n2, h2, w2, c2 = map(int, reshape0_outact.src_shape)  # (1,4,400,256)
        new_outact = builder.make_reshape(new_inact, (n2, h2, w2, c, d))
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 4, 2))
        old_outact = reshape1.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()

    @pattern
    def case11(self, op: Operator, **kwargs):
        """
        (1,197,1,2034)->(1,197,1,3,768)->(3,197,1,1,768)->(3,197,1,769)
        =>
        (1,197,1,2034)->(1,197,3,768)[transpose 2103]->(3,197,1,768)

        """

        pat = find_operator_sequence(op, "R[1h1(cd)->1h1cd] T31024 R[ch11d->ch1d]")
        if pat is None:
            return None
        reshape0, transpose, reshape1 = pat
        n, h, w, cd = reshape0.inacts[0].src_shape
        if h == 1 or cd == 1:
            return None
        pop = reshape0.inacts[0].producer_op
        if check_input_npu_stride(pop):
            return reshape0, transpose, reshape1
        return None

    @case11.transform
    def case11(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, transpose, reshape1 = self.matched_pattern
        inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        reshape0_outact = reshape0.outacts[0]
        n, h, w, c, d = reshape0_outact.src_shape
        new_outact = builder.make_reshape(new_inact, (n, h, c, d))
        new_outact = builder.make_transpose(new_outact, (2, 1, 0, 3))
        old_outact = reshape1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, transpose, reshape1)
        return builder.build()


@DataFlowDirectRuleSet.register
class BiopConstantSequence(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        def _is_add_or_sub(op):
            return op.layertype in (LayerType.AddingConstant, LayerType.SubConstant)

        pat = find_operator_sequence(
            op, _is_add_or_sub, _is_add_or_sub, strict_search=True
        )
        return pat

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        add0, add1 = self.matched_pattern
        const0 = add0.get_tensor(add0.options.constant).value
        const1 = add1.get_tensor(add1.options.constant).value
        if add0.layertype == LayerType.SubConstant:
            const0 = -const0
        if add1.layertype == LayerType.SubConstant:
            const1 = -const1
        new_const = const0 + const1
        inact = add0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_add(new_inact, new_const)
        old_outact = add1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(add0, add1)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.MultiplyConstant, LayerType.MultiplyConstant
        )
        return pat

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        mul0, mul1 = self.matched_pattern
        const0 = mul0.get_tensor(mul0.options.constant).value
        const1 = mul1.get_tensor(mul1.options.constant).value
        new_const = const0 * const1
        inact = mul0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_mul(new_inact, new_const)
        old_outact = mul1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(mul0, mul1)
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        def is_add_or_sub(op):
            return op.layertype in (LayerType.AddingConstant, LayerType.SubConstant)

        pat = find_operator_sequence(
            op,
            LayerType.MultiplyConstant,
            is_add_or_sub,
            LayerType.MultiplyConstant,
            strict_search=True,
        )
        return pat

    @case2.transform
    def case2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        mul0, add0, mul1 = self.matched_pattern
        const0 = mul0.get_tensor(mul0.options.constant).value
        const1 = add0.get_tensor(add0.options.constant).value
        const2 = mul1.get_tensor(mul1.options.constant).value
        if add0.layertype == LayerType.SubConstant:
            const1 = -const1
        # (aX + b) * c => (ac*X + bc)
        inact = mul0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        shape = tuple(map(int, inact.src_shape))
        new_const0 = numpy.broadcast_to(const0, shape) * const2
        new_outact = builder.make_mul(new_inact, new_const0)
        add0_inact = add0.inacts[0]
        shape2 = tuple(map(int, add0_inact.src_shape))
        new_const1 = numpy.broadcast_to(const1, shape2) * const2
        new_outact = builder.make_add(new_outact, new_const1)
        old_outact = mul1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(mul0, add0, mul1)
        return builder.build()

    @pattern
    def case3(self, op: Operator, **kwargs):
        """
        c * ((ax)**exponent) => c * (a**exponent )* (x **exponent)
        """
        pat = find_operator_sequence(
            op,
            LayerType.MultiplyConstant,
            LayerType.Pow,
            LayerType.MultiplyConstant,
            strict_search=True,
        )
        return pat

    @case3.transform
    def case3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        mc0, pow, mc1 = self.matched_pattern
        const0 = mc0.get_tensor(mc0.options.constant).value
        const1 = mc1.get_tensor(mc1.options.constant).value
        inact = mc0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        exponent = pow.options.exponent
        new_outact = builder.make_pow(new_inact, exponent)
        new_const = numpy.power(const0, exponent) * const1
        new_outact = builder.make_mul(new_outact, new_const)
        old_outact = mc1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(mc0, pow, mc1)
        return builder.build()

    @pattern
    def case4(self, op: Operator, **kwargs):
        """
        adding_const(channelwise) - [convs and adding_const]
        """

        pat = find_operator_sequence(
            op, LayerType.AddingConstant, LayerType.AddingConstant
        )
        if pat is None:
            return None
        ac0, ac1 = pat
        ac0_value = ac0.get_tensor(ac0.options.constant).value
        ac0_inact = ac0.inacts[0]
        ac0_outact = ac0.outacts[0]
        if not (ac0_inact.src_dim == 4 and ac0_inact.src_shape == ac0_outact.src_shape):
            return None
        n, h, w, c = ac0_inact.src_shape
        if not (ac0_value.shape == (int(c),) or ac0_value.size == 1):
            return None
        adding_consts = []
        for cop in ac0_outact.consumer_ops:
            if cop.layertype == LayerType.AddingConstant:
                const_value = cop.get_tensor(cop.options.constant).value
                if const_value.size >= int(c) or const_value.size == 1:
                    adding_consts.append(cop)
        if adding_consts:
            return ac0, adding_consts
        return None

    @case4.transform
    def case4(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        ac0, adding_consts = self.matched_pattern
        ac0_inact = ac0.inacts[0]
        new_inact = builder.copy_activationspec(ac0_inact, add_input_map=True)
        ac0_value = ac0.get_tensor(ac0.options.constant).value
        for ac in adding_consts:
            ac_value = ac.get_tensor(ac.options.constant).value
            new_const = ac0_value + ac_value
            new_outact = builder.make_add(new_inact, new_const)
            old_outact = ac.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(ac0, ac)
        return builder.build()


@DataFlowDirectRuleSet.register
class PReluToLeakyRelu(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype != LayerType.PRelu:
            return None
        alpha = op.get_tensor(op.options.leaky_alpha).value
        unique_vals = numpy.unique(alpha)
        if unique_vals.size != 1:
            return None
        return op, float(unique_vals[0])

    @case0.transform
    def case0(self, *args, **kwargs):
        prelu, alpha_val = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = prelu.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_leaky_relu(new_inact, leaky_alpha=alpha_val)
        old_outact = prelu.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(prelu)
        return builder.build()


def _interpret_slice_wrapper(op):
    if op.layertype == LayerType.Slice:
        return interpret_slice(op.inacts[0].src_shape, op.options)
    if op.layertype == LayerType.IndexedItemSelector:
        options = SimpleNamespace()
        options.axis = (op.options.axis,)
        options.start = (op.options.start,)
        options.end = (op.options.end,)
        options.step = None if op.options.step is None else (op.options.step,)
        return interpret_slice(op.inacts[0].src_shape, options)
    raise ValueError(f"Unsupported op type: {op.layertype}")


def split_pattern(op, axis=3) -> None | List[Operator]:
    def _slice_check(slice_):
        if slice_.layertype == LayerType.Slice:
            return slice_.options.axis in ((axis,), (axis - 4,))
        return False

    def _selector_check(selector_):
        if selector_.layertype == LayerType.IndexedItemSelector:
            return (
                selector_.options.axis in (axis, axis - 4)
                and selector_.options.index == -1
            )
        return False

    inact = op.inacts[0]
    if inact.src_dim != 4:
        return None
    slices = []
    intervals = []
    for cop in inact.consumer_ops:
        if not cop.valid:
            return None
        if _slice_check(cop) or _selector_check(cop):
            s, e, step = _interpret_slice_wrapper(cop)
            if step > 1:
                return None
            intervals.append((s, e))
            slices.append(cop)
        else:
            return None
    intervals = sorted(intervals, key=lambda se: se[0])
    acc = 0
    for s, e in intervals:
        if s == acc:
            acc = e
        else:
            return None
    return slices


@DataFlowDirectRuleSet.register
class HeaderViewDataflow(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T0213 R[1wdc->11w(dc)]", LayerType.HeaderView)
        if pat is None:
            return None
        transpose, reshape, hview = pat
        reshape_inact = reshape.inacts[0]
        n, w, d, c = reshape_inact.src_shape
        if hview.options.batch_order == 0 and hview.options.num_heads == int(d):
            transpose_inact = transpose.inacts[0]
            hview_outact = hview.outacts[0]
            if transpose_inact.src_shape == hview_outact.src_shape:
                return transpose, reshape, hview
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape, hview = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_identity(new_inact)
        old_outact = hview.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape, hview)
        return builder.build()


@DataFlowDirectRuleSet.register
class MulConstAddConstMulConst(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op,
            LayerType.MultiplyConstant,
            LayerType.AddingConstant,
            LayerType.MultiplyConstant,
            strict_search=True,
        )
        if pat is None:
            return None

        mc0, ac, mc1 = pat
        if mc1.get_tensor(mc1.options.constant).size == 1:
            return mc0, ac, mc1
        return None

    @case0.transform
    def case0(self, op: Operator, **kwargs):
        builder = OpTransformResultV2Builder()
        mc0, ac, mc1 = self.matched_pattern
        inact = mc0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        const0 = mc0.get_tensor(mc0.options.constant).value
        const1 = ac.get_tensor(ac.options.constant).value
        const2 = mc1.get_tensor(mc1.options.constant).value
        new_const0 = const0 * const2
        new_const1 = const1 * const2
        new_outact = builder.make_mul(new_inact, new_const0)
        new_outact = builder.make_add(new_outact, new_const1)
        old_outact = mc1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(mc0, ac, mc1)
        return builder.build()
