import numpy

from mblt.core import pattern, LayerType
from mblt.operator import Operator
from mblt.transform.graph_transform import TransformRule
from mblt.transform.transform_result import OpTransformResultV2Builder
from ._ruleset import GatherScatterRuleSet


@GatherScatterRuleSet.register
class Gather(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        single element selection.
        indices shape = ()
        """
        if op.layertype != LayerType.Gather:
            return None
        data, indices = op.inacts
        if indices.producer_op.layertype != LayerType.InputConstant:
            return None
        iconst = indices.producer_op
        indices = iconst.get_tensor(iconst.options.constant).value
        if data.src_dim >= 2 and indices.ndim == 0:
            return op
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        gather = self.matched_pattern
        data, indices = gather.inacts
        iconst = indices.producer_op
        indices = iconst.get_tensor(iconst.options.constant).value
        new_inact = builder.copy_activationspec(data, add_input_map=True)
        sel = int(indices.reshape(-1)[0])
        if sel == -1:
            end = 2_147_483_647
        else:
            end = sel + 1
        new_outact = builder.make_slice(
            new_inact, axis=(gather.options.axis,), start=(sel,), end=(end,)
        )
        old_outact = gather.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(gather)

        return builder.build()


def _build_scatter_concat_permutation(channel_size, scatter_channels):
    """
    channel_size: data channel size
    scatter_channels: shape (K,)

    return:
        keep_channels
        permutation
    """
    mask = numpy.ones(channel_size, dtype=numpy.bool_)
    mask[scatter_channels] = False
    keep_channels = numpy.where(mask)[0]
    new_order = numpy.concatenate([keep_channels, scatter_channels])
    permutation = numpy.argsort(new_order)
    return keep_channels, permutation


@GatherScatterRuleSet.register
class ScatterND(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        # todo: generalize or support more indices shape.
        """
        rexnet

        input: (1,92,14,14) # first posision
        indices: (1,76,2)
        updates: (1,76,14,14)
        """
        if op.layertype != LayerType.ScatterND:
            return None
        data, indices, updates = op.inacts
        if indices.producer_op.layertype != LayerType.InputConstant:
            return None
        indices = indices.producer_op.get_tensor(
            indices.producer_op.options.constant
        ).value
        if not (indices.ndim == 3 and indices.shape[0] == 1 and indices.shape[2] == 2):
            return None
        n_ind, num_updates, num_index_sel = indices.shape
        n, c, h, w = data.src_shape
        if not (
            n == 1 and updates.src_shape == (1, num_updates, h, w) and c >= num_updates
        ):
            return None

        # check uniqueness
        indices_ = indices[0, :, 1].astype(numpy.int_)
        seen = [False] * c
        for c in indices_:
            if seen[c]:
                return None
            seen[c] = True
        return op

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        scatter_nd = self.matched_pattern
        data, indices, updates = scatter_nd.inacts
        indices_op = indices.producer_op
        indices_val = indices_op.get_tensor(indices_op.options.constant).value

        scatter_channels = indices_val[0, :, 1].astype(numpy.int_)
        new_outact = self._transform_to_concat_flow(
            builder, data, updates, scatter_channels, axis=1
        )

        builder.add_output_map(new_outact, scatter_nd.outacts[0])
        builder.remove_connectivity_and_invalidate(indices_op, scatter_nd)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        """
        yolov7_seg_640_640

        input: (1,3,20,20,117)
        indices: (1,3,20,20,85,5)
        updates: (1,3,20,20,85)
        """
        if op.layertype != LayerType.ScatterND:
            return None
        data, indices, updates = op.inacts
        if indices.producer_op.layertype != LayerType.InputConstant:
            return None
        indices = indices.producer_op.get_tensor(
            indices.producer_op.options.constant
        ).value
        if indices.ndim != 6 or indices.shape[0] != 1:
            return None
        n, d, h, w, k, dim = map(int, indices.shape)
        if dim != 5:
            return None
        if data.src_shape[:4] != (n, d, h, w):
            return None
        if updates.src_shape != (n, d, h, w, k):
            return None

        # 모든 loop index확인
        grid = numpy.stack(
            numpy.meshgrid(
                numpy.arange(n),
                numpy.arange(d),
                numpy.arange(h),
                numpy.arange(w),
                indexing="ij",
            ),
            axis=-1,
        )
        # (n,d,h,w,4)
        if not numpy.all(indices[..., :4] == grid[..., None, :]):
            return None

        # 모든 indices 확인
        ch = indices[..., 4]
        ch_flat = ch.reshape(-1, k)

        base = ch_flat[0]
        if not numpy.all(ch_flat == base):
            return None
        if len(numpy.unique(base)) != k:
            return None
        return op

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        scatter_nd = self.matched_pattern
        data, indices, updates = scatter_nd.inacts
        indices_op = indices.producer_op
        indices_val = indices_op.get_tensor(indices_op.options.constant).value

        scatter_channels = indices_val[0, 0, 0, 0, :, 4].astype(numpy.int_)

        new_outact = self._transform_to_concat_flow(
            builder, data, updates, scatter_channels, axis=4
        )

        builder.add_output_map(new_outact, scatter_nd.outacts[0])
        builder.remove_connectivity_and_invalidate(indices_op, scatter_nd)
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        """
        mvitv2_base_cls

        input: (1,4,197,197)
        indices: (1,4,196,196,4)
        updates: (1,4,196,196)
        """

        if op.layertype != LayerType.ScatterND:
            return None
        if op.layertype != LayerType.ScatterND:
            return None
        data, indices, updates = op.inacts
        if indices.producer_op.layertype != LayerType.InputConstant:
            return None

        indices_val = indices.producer_op.get_tensor(
            indices.producer_op.options.constant
        ).value

        # Shape 체크
        if indices_val.ndim != 5 or indices_val.shape[-1] != 4:
            return None
        n, d, h_up, w_up, k = indices_val.shape

        # data shape: (1, 4, 197, 197), updates shape: (1, 4, 196, 196)
        if updates.src_shape != (n, d, h_up, w_up):
            return None

        # 좌표 분석: N, D 축은 고정되어 있고 H, W 축만 가변적인지 확인
        # indices[..., 0] -> N, indices[..., 1] -> D
        # indices[..., 2] -> H, indices[..., 3] -> W

        # N, D 그리드 체크 (변하지 않는 축)
        grid_nd = numpy.stack(
            numpy.meshgrid(numpy.arange(n), numpy.arange(d), indexing="ij"), axis=-1
        )
        if not numpy.all(indices_val[:, :, 0, 0, :2] == grid_nd):
            return None

        # H, W 좌표 추출
        h_idx = indices_val[0, 0, :, 0, 2]  # (196,)
        w_idx = indices_val[0, 0, 0, :, 3]  # (196,)

        # 모든 N, D 위치에서 H, W 인덱스가 동일한지 확인
        if not numpy.all(indices_val[..., 2] == h_idx[None, None, :, None]):
            return None
        if not numpy.all(indices_val[..., 3] == w_idx[None, None, None, :]):
            return None

        return op

    @case2.transform
    def case2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        scatter_nd = self.matched_pattern
        data, indices, updates = scatter_nd.inacts

        indices_op = indices.producer_op
        indices_val = indices_op.get_tensor(indices_op.options.constant).value

        n, d, h_up, w_up, _ = indices_val.shape
        h_size, w_size = int(data.src_shape[2]), int(data.src_shape[3])

        h_idx = indices_val[0, 0, :, 0, 2].astype(numpy.int_)  # (h_up,)
        w_idx = indices_val[0, 0, 0, :, 3].astype(numpy.int_)  # (w_up,)

        new_data = builder.copy_activationspec(data, add_input_map=True)
        new_update = builder.copy_activationspec(updates, add_input_map=True)

        # 1. 연속성 판단 헬퍼
        def get_contig_info(indices_1d):
            s, e = int(indices_1d[0]), int(indices_1d[-1])
            is_contig = (len(indices_1d) == (e - s + 1)) and numpy.all(
                indices_1d == numpy.arange(s, e + 1)
            )
            return s, e, is_contig

        h_s, h_e, h_contig = get_contig_info(h_idx)
        w_s, w_e, w_contig = get_contig_info(w_idx)

        if h_contig and w_contig:
            # --- 연속적인 경우: 2D Slice + Concat 최적화 ---
            h_parts = []
            if h_s > 0:
                h_parts.append(
                    builder.make_slice(new_data, axis=(2,), start=(0,), end=(h_s,))
                )
            mid_h_region = builder.make_slice(
                new_data, axis=(2,), start=(h_s,), end=(h_e + 1,)
            )

            w_parts = []
            if w_s > 0:
                w_parts.append(
                    builder.make_slice(mid_h_region, axis=(3,), start=(0,), end=(w_s,))
                )
            w_parts.append(new_update)
            if w_e + 1 < w_size:
                w_parts.append(
                    builder.make_slice(
                        mid_h_region, axis=(3,), start=(w_e + 1,), end=(w_size,)
                    )
                )

            # W축 조립 후 H축에 끼워넣기
            updated_mid_h = builder.make_concatenate(w_parts, axis=3)
            h_parts.append(updated_mid_h)

            if h_e + 1 < h_size:
                h_parts.append(
                    builder.make_slice(
                        new_data, axis=(2,), start=(h_e + 1,), end=(h_size,)
                    )
                )

            new_outact = builder.make_concatenate(h_parts, axis=2)

        else:
            # (N, D, H, W) -> (N, D, H*W) 형태로 reshape하여 1D Scatter처럼 처리
            flat_data = builder.make_reshape(
                new_data, new_shape=(n, d, h_size * w_size)
            )
            flat_update = builder.make_reshape(
                new_update, new_shape=(n, d, h_up * w_up)
            )

            # 2. 2D 좌표를 1D 인덱스로 변환: index = h * W_WIDTH + w
            # h_idx, w_idx를 meshgrid로 확장하여 flat 인덱스 생성
            H_grid, W_grid = numpy.meshgrid(h_idx, w_idx, indexing="ij")
            flat_scatter_indices = (
                (H_grid * w_size + W_grid).flatten().astype(numpy.int_)
            )

            # 3. 1D 헬퍼 함수 활용 (기존 정의된 함수 호출)
            keep_indices, permutation = _build_scatter_concat_permutation(
                h_size * w_size, flat_scatter_indices
            )

            # 4. Concat Flow 구성
            keep_inact = builder.make_indexed_item_selector(
                flat_data, axis=2, index=keep_indices
            )
            new_outact = builder.make_concatenate([keep_inact, flat_update], axis=2)

            if not numpy.all(permutation == numpy.arange(h_size * w_size)):
                new_outact = builder.make_indexed_item_selector(
                    new_outact, axis=2, index=permutation
                )

            # 5. 원래 2D Shape으로 복원
            new_outact = builder.make_reshape(
                new_outact, new_shape=(n, d, h_size, w_size)
            )

        # 5. 그래프 연결 및 정리
        builder.add_output_map(new_outact, scatter_nd.outacts[0])
        builder.remove_connectivity_and_invalidate(indices_op, scatter_nd)

        return builder.build()

    def _transform_to_concat_flow(self, builder, data, updates, scatter_channels, axis):
        c_size = int(data.src_shape[axis])
        new_data = builder.copy_activationspec(data, add_input_map=True)
        new_update = builder.copy_activationspec(updates, add_input_map=True)

        # 연속성 체크
        s, e = int(scatter_channels[0]), int(scatter_channels[-1])
        is_contiguous = (len(scatter_channels) == (e - s + 1)) and numpy.all(
            scatter_channels == numpy.arange(s, e + 1)
        )

        if is_contiguous:
            concat_inputs = []
            if s > 0:
                # 앞 부분
                concat_inputs.append(
                    builder.make_slice(new_data, axis=(axis,), start=(0,), end=(s,))
                )
            concat_inputs.append(new_update)
            if e + 1 < c_size:
                # 뒷 부분
                concat_inputs.append(
                    builder.make_slice(
                        new_data, axis=(axis,), start=(e + 1,), end=(c_size,)
                    )
                )
            return builder.make_concatenate(concat_inputs, axis=axis)

        keep_indices, permutation = _build_scatter_concat_permutation(
            c_size, scatter_channels
        )
        keep_inact = builder.make_indexed_item_selector(
            new_data, axis=axis, index=keep_indices
        )
        out = builder.make_concatenate([keep_inact, new_update], axis=axis)

        if not numpy.all(permutation == numpy.arange(c_size)):
            out = builder.make_indexed_item_selector(out, axis=axis, index=permutation)
        return out
