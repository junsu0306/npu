from mblt.core import RuleSet

GatherScatterRuleSet = RuleSet("GatherScatterRuleSet")
DataFlowRuleSet = RuleSet("DataFlowRuleSet")
DataFlowDirectRuleSet = RuleSet("DataFlowDirectRuleSet")
SelectorRuleSet = RuleSet("SelectorRuleSet")
BatchnormRuleSet = RuleSet("BatchnormRuleSet")
DataFormatCanonicalizationRuleSet = RuleSet("DataFormatCanonicalizationRuleSet")
