from mblt import Operator, LayerType
from mblt.core import TransformRule, pattern
from mblt.subgraph.util.pattern_util import find_operator_sequence
from ._ruleset import DataFlowRuleSet
from ...transform_result import OpTransformResultV2Builder


@DataFlowRuleSet.register
class SubConstantMultiply(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """(1-x)*w => w - x*w"""
        if op.layertype != LayerType.Multiply:
            return None
        mul = op
        pop0 = mul.inacts[0].producer_op
        pop1 = mul.inacts[1].producer_op

        def check_mul_sub(pop):
            if pop.layertype == LayerType.SubConstant and pop.options.is_const_first:
                const_value = pop.get_tensor(pop.options.constant).value
                if const_value.size == 1 and const_value.reshape(-1)[0] == 1:
                    return pop
            return None

        sc = check_mul_sub(pop0)
        if sc is not None and sc.inacts[0].name != mul.inacts[1].name:
            return sc, mul

        sc = check_mul_sub(pop1)
        if sc is not None and sc.inacts[0].name != mul.inacts[0].name:
            return sc, mul
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        sc, mul = self.matched_pattern
        x_inact = builder.copy_activationspec(sc.inacts[0], add_input_map=True)
        for inact in mul.inacts:
            if inact.name != sc.outacts[0].name:
                w_inact = builder.copy_activationspec(inact, add_input_map=True)
                break
        xw_outact = builder.make_mul(x_inact, w_inact)
        new_outact = builder.make_sub(w_inact, xw_outact)
        old_outact = mul.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(sc, mul)
        return builder.build()


@DataFlowRuleSet.register
class MulitiplyAdding(TransformRule):
    """
    (w0 - w0 * x) + w1 * x => w0 + (w1-w0) * x
    """

    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Adding:
            return None
        adding = op
        pop0 = adding.inacts[0].producer_op
        pop1 = adding.inacts[1].producer_op
        if pop0.layertype == LayerType.Multiply and pop1.layertype == LayerType.Sub:
            mul1, sub = pop0, pop1
        elif pop0.layertype == LayerType.Sub and pop1.layertype == LayerType.Multiply:
            mul1, sub = pop1, pop0
        else:
            return None
        if mul1.inacts[0].name == mul1.inacts[1].name:
            return None
        sub_inact0 = sub.inacts[0]
        sub_inact1 = sub.inacts[1]
        if sub_inact1.producer_op.layertype != LayerType.Multiply:
            return None
        mul0 = sub_inact1.producer_op
        if mul0.inacts[0].name == mul0.inacts[1].name:
            return None

        if mul0.inacts[0].name == sub_inact0.name:
            x_inact = mul0.inacts[1]
        elif mul0.inacts[1].name == sub_inact0.name:
            x_inact = mul0.inacts[0]
        else:
            return None

        if mul1.inacts[0].name == x_inact.name:
            return mul0, sub, mul1, adding
        elif mul1.inacts[1].name == x_inact.name:
            return mul0, sub, mul1, adding
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        mul0, sub, mul1, adding = self.matched_pattern
        for inact in sub.inacts:
            if inact.name != mul0.outacts[0].name:
                w0_inact = builder.copy_activationspec(inact, add_input_map=True)
                break
        for inact in mul0.inacts:
            if inact.name != w0_inact.name:
                x_inact = builder.copy_activationspec(inact, add_input_map=True)
                break
        for inact in mul1.inacts:
            if inact.name != x_inact.name:
                w1_inact = builder.copy_activationspec(inact, add_input_map=True)
                break
        new_outact = builder.make_sub(w1_inact, w0_inact)
        new_outact = builder.make_mul(new_outact, x_inact)
        new_outact = builder.make_add(new_outact, w0_inact)
        old_outact = adding.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(mul0, sub, adding)
        builder.remove_connectivity_and_invalidate(mul1, adding)

        return builder.build()


@DataFlowRuleSet.register
class SliceTransposeCast(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op,
            LayerType.Slice,
            LayerType.Transpose,
            LayerType.Cast,
            strict_search=True,
        )
        if pat is None:
            return None
        slice_, transpose, cast = pat
        slice_inact = slice_.inacts[0]
        for cop in slice_inact.consumer_ops:
            if (
                cop.valid
                and cop.layertype == LayerType.Cast
                and cop.options.dtype == cast.options.dtype
            ):
                return slice_, transpose, cast
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        slice_, transpose, cast = self.matched_pattern
        inact = slice_.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(cast, new_inact)
        new_outact = builder.with_new_input_and_options(slice_, new_outact)
        new_outact = builder.with_new_input_and_options(transpose, new_outact)
        old_outact = cast.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(slice_, transpose, cast)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op,
            LayerType.Slice,
            LayerType.Cast,
            strict_search=True,
        )
        if pat is None:
            return None
        slice_, cast = pat
        slice_inact = slice_.inacts[0]
        for cop in slice_inact.consumer_ops:
            if (
                cop.valid
                and cop.layertype == LayerType.Cast
                and cop.options.dtype == cast.options.dtype
            ):
                return slice_, cast
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        slice_, cast = self.matched_pattern
        inact = slice_.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(cast, new_inact)
        new_outact = builder.with_new_input_and_options(slice_, new_outact)
        old_outact = cast.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(slice_, cast)
        return builder.build()


@DataFlowRuleSet.register
class IndexedItemSelectorCast(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.IndexedItemSelector, LayerType.Cast, strict_search=True
        )
        if pat is None:
            return None
        selector, cast = pat
        if selector.options.repeat is not None or selector.options.start is not None:
            return selector, cast
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        selector, cast = self.matched_pattern
        inact = selector.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(cast, new_inact)
        new_outact = builder.with_new_input_and_options(selector, new_outact)
        old_outact = cast.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(selector, cast)
        return builder.build()
