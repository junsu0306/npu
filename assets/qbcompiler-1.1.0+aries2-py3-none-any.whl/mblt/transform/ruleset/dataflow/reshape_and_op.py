from mblt.core import pattern, LayerType
from mblt.operator import Operator
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    is_prev_op_basic_npu_op_pattern,
    is_shape_irrelevant_single_op,
    is_reshape_with_expr,
    is_biop_wrapper,
    check_input_npu_stride,
    get_shape_irrelevant_single_op_sequence_until,
    is_actfunc_type,
)
from mblt.transform.graph_transform import TransformRule
from mblt.transform.ruleset.util import simple_swap
from mblt.transform.transform_result import OpTransformResultV2Builder
from ._ruleset import DataFlowRuleSet


@DataFlowRuleSet.register
class ReshapeAndOp(TransformRule):
    @pattern
    def case_actfn(self, op: Operator, *args, **kwargs):
        pat = find_operator_sequence(op, "Ractfn")
        if pat is None:
            return None
        reshape, single_op = pat
        if single_op.layertype == LayerType.Softmax:
            return None
        if reshape.outacts[0].src_dim == 4 and reshape.inacts[0].src_dim != 4:
            return None
        return reshape, single_op

    @case_actfn.transform
    def case_actfn(self, *args, **kwargs):
        reshape, actfn = self.matched_pattern
        return simple_swap(reshape, actfn)

    @pattern
    def case_layernorm(self, op: Operator, **kwargs):

        def check_op(op):
            return op.layertype in (
                LayerType.LayerNormalization,
                LayerType.RmsNormalization,
            )

        pat = find_operator_sequence(op, "R[1hwc->11(hw)c]", check_op)
        if pat is None:
            return None
        reshape, norm = pat
        reshape_inact = reshape.inacts[0]
        if not is_prev_op_basic_npu_op_pattern(reshape_inact.producer_op):
            return None
        inact = norm.inacts[0]
        c = int(inact.src_shape[-1])
        if norm.options.normalized_shape == (c,):
            return reshape, norm
        return None

    @case_layernorm.transform
    def case_layernorm(self, *args, **kwargs):
        reshape, norm = self.matched_pattern
        return simple_swap(reshape, norm)

    @pattern
    def case_linear(self, op: Operator, *args, **kwargs):
        pat = find_operator_sequence(op, "R[1hwc->11(hw)c]L")
        if pat is None:
            return None
        reshape, linear = pat
        linear_outact = linear.outacts[0]
        if 1 == len(linear_outact.consumer_ops):
            cop = linear_outact.consumer_ops[0]
            if is_actfunc_type(cop):
                return None
        return reshape, linear

    @case_linear.transform
    def case_linear(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, linear = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(linear, new_inact)
        old_outact = linear.outacts[0]
        new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, linear)
        return builder.build()

    @pattern
    def case_biop(self, op: Operator, *args, **kwargs):
        if not is_biop_wrapper(op):
            return None

        def get_seq(last_op):
            if last_op.layertype == LayerType.Reshape:
                return [last_op]
            pat = get_shape_irrelevant_single_op_sequence_until(last_op)
            if pat:
                first_op = pat[0]
                first_op_pop = first_op.inacts[0].producer_op
                if first_op_pop.layertype == LayerType.Reshape:
                    return [first_op_pop] + list(pat)
            return None

        pop0 = op.inacts[0].producer_op
        pop1 = op.inacts[1].producer_op
        pat0 = get_seq(pop0)
        if pat0 is None:
            return None
        pat1 = get_seq(pop1)
        if pat1 is None:
            return None
        reshape0 = pat0[0]
        reshape1 = pat1[0]
        reshape0_in_shape = reshape0.inacts[0].src_shape
        reshape0_out_shape = reshape0.outacts[0].src_shape
        reshape1_in_shape = reshape1.inacts[0].src_shape
        reshape1_out_shape = reshape1.outacts[0].src_shape
        if not (
            reshape0_in_shape == reshape1_in_shape
            and reshape0_out_shape == reshape1_out_shape
        ):
            return None
        if check_input_npu_stride(reshape0) or check_input_npu_stride(reshape1):
            return pat0, pat1, op
        return False

    @case_biop.transform
    def case_biop(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        pat0, pat1, biop = self.matched_pattern
        inact0 = pat0[0].inacts[0]
        inact1 = pat1[0].inacts[0]
        new_inact0 = builder.copy_activationspec(inact0, add_input_map=True)
        new_inact1 = builder.copy_activationspec(inact1, add_input_map=True)
        for curr_op in pat0[1:]:
            new_inact0 = builder.with_new_input_and_options(curr_op, new_inact0)
        for curr_op in pat1[1:]:
            new_inact1 = builder.with_new_input_and_options(curr_op, new_inact1)
        new_outact = builder.with_new_input_and_options(biop, new_inact0, new_inact1)
        old_outact = biop.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(*pat0, biop)
        builder.remove_connectivity_and_invalidate(*pat1, biop)
        return builder.build()

    @pattern
    def case_biop1(self, op: Operator, **kwargs):
        if not is_biop_wrapper(op):
            return None
        biop = op
        inact0, inact1 = biop.inacts
        if inact0.src_shape == inact1.src_shape:
            if (
                find_operator_sequence(inact0.producer_op, "R") is not None
                and find_operator_sequence(inact1.producer_op, "R") is not None
            ):
                r_inact0 = inact0.producer_op.inacts[0]
                r_inact1 = inact1.producer_op.inacts[0]
                if r_inact0.src_shape == r_inact1.src_shape:
                    return biop
        # headerview에 방해 됨.
        # if inact0.src_shape[:3] == inact1.src_shape[:3]:
        #     # (1,1,2028,80) * (1,1,2028,1)
        #     if (
        #         find_operator_sequence(inact0.producer_op, "R[1chw->11(ch)w]")
        #         is not None
        #         and find_operator_sequence(inact1.producer_op, "R[1chw->11(ch)w]")
        #         is not None
        #     ):
        #         return biop
        return None

    @case_biop1.transform
    def case_biop1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop = self.matched_pattern
        new_inacts = []
        for inact in biop.inacts:
            reshape = inact.producer_op
            reshape_inact = reshape.inacts[0]
            new_inact = builder.copy_activationspec(reshape_inact, add_input_map=True)
            new_inacts.append(new_inact)
            builder.remove_connectivity_and_invalidate(reshape, biop)
        new_outact = builder.with_new_input_and_options(biop, *new_inacts)
        old_outact = biop.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)

        return builder.build()

    @pattern
    def case_l2norm(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[n1w(cd)->nwcd]", LayerType.L2Normalization)
        if pat is None:
            return None
        reshape, l2norm = pat
        if l2norm.options.norm_axis == (1,):
            return reshape, l2norm
        return None

    @case_l2norm.transform
    def case_l2norm(self, *args, **kwargs):
        reshape, l2norm = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(
            l2norm, new_inact, norm_axis=(2,)
        )
        new_outact = builder.make_reshape(new_outact, reshape.outacts[0].src_shape)
        old_outact = l2norm.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, l2norm)
        return builder.build()

    @pattern
    def case_instance_norm(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, "R[1hwc->11(hw)c]", LayerType.InstanceNormalization
        )
        if pat is None:
            return None
        reshape, instance_norm = pat
        reshape_inact = reshape.inacts[0]
        if reshape_inact.src_shape[1] == 1:
            return None
        c = int(reshape_inact.src_shape[-1])
        if (c,) == instance_norm.get_tensor(instance_norm.options.scale).shape:
            return reshape, instance_norm
        return None

    @case_instance_norm.transform
    def case_instance_norm(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, instance_norm = self.matched_pattern

        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(instance_norm, new_inact)
        new_outact = builder.make_reshape(new_outact, reshape.outacts[0].src_shape)
        old_outact = instance_norm.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, instance_norm)
        return builder.build()


@DataFlowRuleSet.register
class ReshapeTranspose(TransformRule):
    # todo: implement more general rule involving 1's in shape

    @pattern
    def case0(self, op: Operator, *args, **kwargs):
        """
        headerview basic pattern
        """
        pat = find_operator_sequence(
            op, is_prev_op_basic_npu_op_pattern, "R[1hw(nc)->1hwnc]T03124"
        )
        if pat is None:
            return None
        npu_op, reshape, transpose = pat
        reshape_outact = reshape.outacts[0]
        b, h, w, n_heads, c = reshape_outact.src_shape
        if h.dynamic or w.dynamic:
            return None
        if n_heads > 1 and c > 1:
            return reshape, transpose
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        reshape, transpose = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reshape.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        n, h, w, c = new_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, 1, -1, c))  # (n,1,hw,c)
        reshape_outact = reshape.outacts[0]
        b, h, w, n_heads, c = reshape_outact.src_shape
        new_outact = builder.make_reshape(
            new_outact, (n, -1, n_heads, c)
        )  # (n,hw,nheads,c)
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = transpose.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, transpose)
        return builder.build()

    @pattern
    def case2(self, op: Operator, *args, **kwargs):
        """(1,h,w,1)-[reshape]->(1,1,hw,1)-[transpose0132/0312]->(1,1,1,hw)
        =>
         (1,h,w,1)-[reshape]->(1,1,1,hw)
        """

        def transpose_check(op):
            return (
                op is not None
                and op.layertype == LayerType.Transpose
                and op.options.transpose_axes in ((0, 3, 1, 2), (0, 1, 3, 2))
            )

        pat = find_operator_sequence(op, "R[bhw1->b1(hw)1]", transpose_check)
        if pat is None:
            return None
        reshape, transpose = pat
        b, h, w, c = reshape.inacts[0].src_shape
        if h > 1 and w > 1:
            return reshape, transpose
        return None

    @case2.transform
    def case2(self, *args, **kwargs):
        reshape, transpose = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reshape.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_reshape(new_outact, (1, 1, 1, -1))
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, transpose)
        return builder.build()

    @pattern
    def case3(self, op: Operator, *args, **kwargs):
        """
        (1,h,w,nc)-[reshape]->(h,w,1,n,c)-[transpose20314]->(1,h,n,w,c)
        =>
        (1,h,w,nc)-[reshape]->(1,h,w,n,c)-[transpose01324]->(1,h,n,w,c)
        """

        pat = find_operator_sequence(op, "R[1hw(nc)->hw1nc] T20314")
        if pat is None:
            return None
        reshape, transpose = pat
        return reshape, transpose

    @case3.transform
    def case3(self, *args, **kwargs):
        reshape, transpose = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reshape.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        transpose_outact = transpose.outacts[0]
        b, h, n, w, c = transpose_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (1, h, w, n, c))
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2, 4))
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, transpose)
        return builder.build()

    @pattern
    def case4(self, op: Operator, *args, **kwargs):
        """
        (1,1,w,c)-[reshape]->(w,c,1,1)-[transpose2031]->(1,w,1,c)
        =>
        (1,1,w,c)-[reshape]->(1,w,1,c)
        """
        pat = find_operator_sequence(op, "R[11wc->wc11] T2031")
        if pat is None:
            return None
        reshape, transpose = pat
        return reshape, transpose

    @case4.transform
    def case4(self, *args, **kwargs):
        reshape, transpose = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reshape.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        old_outact = transpose.outacts[0]
        new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, transpose)
        return builder.build()

    @pattern
    def case5(self, op: Operator, **kwargs):
        # todo: generalize
        """
        (1,56,56,1,64)-[reshape]>(1,1,56,56,64)-[transpose01423]->(1,1,64,56,56)
        =>
        (1,56,56,1,64)-[reshape]>(1,56,56,64)-[transpose0312]->(1,64,56,56)
        """
        pat = find_operator_sequence(op, "R[1hw1c->11hwc] T01423")
        if pat is None:
            return None
        reshape, transpose = pat
        return reshape, transpose

    @case5.transform
    def case5(self, *args, **kwargs):
        reshape, transpose = self.matched_pattern
        builder = OpTransformResultV2Builder()
        reshape_inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(reshape_inact, add_input_map=True)
        n, b, h, w, c = reshape.outacts[0].src_shape
        assert b == 1
        new_outact = builder.make_reshape(new_inact, (n, h, w, c))
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = transpose.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, transpose)
        return builder.build()

    @pattern
    def case6(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[111(dc)->111dc] T03421", LayerType.Softmax)
        if pat is None:
            return None
        reshape, transpose, softmax = pat
        reshape_outact = reshape.outacts[0]
        n, h, w, d, c = reshape_outact.src_shape
        if h.dynamic or w.dynamic:
            return None
        if softmax.options.axis == 1:
            if check_input_npu_stride(reshape.inacts[0].producer_op):
                return reshape, transpose, softmax
        return None

    @case6.transform
    def case6(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, transpose, softmax = self.matched_pattern
        inact = reshape.inacts[0]
        n, h, w, d, c = reshape.outacts[0].src_shape
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_reshape(new_inact, (1, 1, d, c))
        new_outact = builder.with_new_input_and_options(softmax, new_outact, axis=2)
        new_outact = builder.make_transpose(new_outact, (0, 2, 3, 1))
        old_outact = softmax.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, transpose, softmax)
        return builder.build()

    @pattern
    def case7(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T0132 R[1(dh)cw->dhcw]")
        if pat is None:
            return None
        transpose, reshape = pat
        pop = transpose.inacts[0].producer_op
        if check_input_npu_stride(pop):
            return transpose, reshape
        return None

    @case7.transform
    def case7(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        old_outact = reshape.outacts[0]
        d, h, c, w = old_outact.src_shape
        new_outact = builder.make_reshape(new_inact, (d, h, w, c))
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()


@DataFlowRuleSet.register
class ReshapeOpsReshape(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        reshape->()-[ops]->()-reshape->()
        """
        expr0 = "1hwc->11(hw)c"
        expr1 = "11(hw)c->1hwc"
        if is_reshape_with_expr(expr1)(op):
            reshape_last = op
            pre_expr = expr0
        elif is_reshape_with_expr(expr0)(op):
            reshape_last = op
            pre_expr = expr1
        else:
            return None
        curr_op = reshape_last.inacts[0].producer_op
        ops = [reshape_last]
        max_depth = 10
        curr_depth = 0
        while curr_depth < max_depth:
            if curr_op is None:
                return None
            if is_reshape_with_expr(pre_expr)(curr_op):
                ops.append(curr_op)
                patterns = tuple(reversed(ops))
                reshape_pre = patterns[0]
                reshape_post = patterns[-1]
                return patterns
            if is_shape_irrelevant_single_op(curr_op):
                ops.append(curr_op)
                curr_depth += 1
                curr_op = curr_op.inacts[0].producer_op
            else:
                return None
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()

        patterns = self.matched_pattern
        reshape_pre = patterns[0]
        reshape_post = patterns[-1]
        inact = reshape_pre.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        for old_op in patterns[1:-1]:
            new_outact = builder.with_new_input_and_options(old_op, new_outact)
        old_outact = reshape_post.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(*patterns)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        """
        (1,56,56,96)-[reshape]-|->(1,1,3136,96)-[ops]->(1,1,3136,96)-|-[add]->(1,1,3136,96)
                               |->(1,1,3136,96)----------------------|
        """
        exprs = ["1hwc->11(hw)c", "11(hw)c->1hwc"]
        if not is_biop_wrapper(op):
            return None
        biop = op
        inact0, inact1 = biop.inacts
        if inact0.src_shape != inact1.src_shape:
            return None
        reshape_pre = curr_op = None
        for expr in exprs:
            if is_reshape_with_expr(expr)(inact0.producer_op):
                reshape_pre = inact0.producer_op
                curr_op = inact1.producer_op
                break
            elif is_reshape_with_expr(expr)(inact1.producer_op):
                reshape_pre = inact1.producer_op
                curr_op = inact0.producer_op
                break
        if reshape_pre is None:
            return None
        ops = []
        max_depth = 10
        curr_depth = 0
        while curr_depth < max_depth:
            if curr_op is None:
                return None
            if (
                curr_op.layertype == LayerType.Reshape
                and curr_op.name == reshape_pre.name
                and ops  # we will only deal with non-empty ops case here for clarity.
            ):
                return reshape_pre, tuple(reversed(ops)), biop
            if is_shape_irrelevant_single_op(curr_op):
                ops.append(curr_op)
                curr_depth += 1
                curr_op = curr_op.inacts[0].producer_op
            else:
                return None
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape_pre, op_seq, biop = self.matched_pattern
        inact = reshape_pre.inacts[0]
        new_inact0 = builder.copy_activationspec(inact, add_input_map=True)
        new_inact1 = new_inact0
        for cop in op_seq:
            new_inact1 = builder.with_new_input_and_options(cop, new_inact1)
        if biop.inacts[0].name == reshape_pre:
            pass
        elif biop.inacts[1].name == reshape_pre:
            new_inact0, new_inact1 = new_inact1, new_inact0
        new_outact = builder.with_new_input_and_options(biop, new_inact0, new_inact1)
        old_outact = biop.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape_pre, biop)
        builder.remove_connectivity_and_invalidate(reshape_pre, *op_seq, biop)
        return builder.build()


@DataFlowRuleSet.register
class ReshapeSliceTranspose(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "R[11w(nc)->1wnc] S[1] T0231")
        if pat is None:
            return None
        reshape, slice_, transpose = pat
        inact = reshape.inacts[0]
        if is_prev_op_basic_npu_op_pattern(inact.producer_op):
            return reshape, slice_, transpose
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, slice_, transpose = self.matched_pattern
        inact = reshape.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_outact, axis=(2,))
        b, w, n, c = reshape.outacts[0].src_shape
        new_outact = builder.make_reshape(new_outact, (b, -1, n, c))
        new_outact = builder.make_transpose(new_outact, (0, 2, 3, 1))
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, slice_, transpose)
        return builder.build()
