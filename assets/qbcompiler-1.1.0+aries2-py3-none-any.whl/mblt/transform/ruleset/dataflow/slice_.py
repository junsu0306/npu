import functools
from types import SimpleNamespace
from typing import List

import numpy

from mblt import LayerType
from mblt.core import pattern
from mblt.operator import Operator
from mblt.operator.utils import interpret_slice
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    is_biop_const,
    check_input_npu_stride,
    is_slice_with_axis,
    is_basic_npu_op,
    is_transpose,
)
from mblt.transform.graph_transform import TransformRule
from mblt.transform.transform_result import OpTransformResultV2Builder
from ._ruleset import DataFlowRuleSet


@DataFlowRuleSet.register
class SliceSlice(TransformRule):
    @pattern
    def slice_transpose_slice(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "STS")
        if pat is None:
            return None
        slice0, transpose, slice1 = pat
        return transpose, slice1

    @slice_transpose_slice.transform
    def slice_transpose_slice(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, slice2 = self.matched_pattern
        inact = transpose.inacts[0]
        prev_axis = tuple(
            transpose.options.transpose_axes[ax] for ax in slice2.options.axis
        )
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(
            slice2, new_inact, axis=prev_axis
        )
        new_outact = builder.make_transpose(
            new_outact, transpose.options.transpose_axes
        )
        old_outact = slice2.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, slice2)
        return builder.build()

    @pattern
    def slice_same_axis(self, op: Operator, **kwargs):
        for i in range(1, 4):
            pat = find_operator_sequence(op, f"S[{i}] S[{i}]")
            if pat is None:
                continue
            slice1, slice2 = pat
            dim_size1 = slice1.inacts[0].src_shape[i]
            if dim_size1.dynamic:
                continue
            start1, end1, step1 = interpret_slice(
                slice1.inacts[0].src_shape, slice1.options
            )
            start2, end2, step2 = interpret_slice(
                slice2.inacts[0].src_shape, slice2.options
            )
            if step1 > 0 and step2 > 0:
                return slice1, slice2
        return None

    @slice_same_axis.transform
    def slice_same_axis(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        slice1, slice2 = self.matched_pattern
        start1, end1, step1 = interpret_slice(
            slice1.inacts[0].src_shape, slice1.options
        )
        start2, end2, step2 = interpret_slice(
            slice2.inacts[0].src_shape, slice2.options
        )
        new_start = start1 + start2 * step1
        new_step = step2 * step1
        new_end = start1 + end2 * step1
        new_inact = builder.copy_activationspec(slice1.inacts[0], add_input_map=True)
        new_outact = builder.make_slice(
            new_inact,
            axis=slice1.options.axis,
            start=(new_start,),
            end=(new_end,),
            step=(new_step,),
        )
        old_outact = slice2.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(slice1, slice2)
        return builder.build()


def _is_channel_slice(op):
    if (
        op.layertype == LayerType.Slice
        and 1 == len(op.options.axis)
        and op.options.axis[0] in (3, -1)
    ):
        return True
    if (
        op.layertype == LayerType.IndexedItemSelector
        and op.options.index == -1
        and op.options.axis in (3, -1)
        and op.options.start is not None
    ):
        return True
    return False


def split_pattern(op, axis=3) -> None | List[Operator]:
    def _slice_check(slice_):
        if slice_.layertype == LayerType.Slice:
            return slice_.options.axis in ((axis,), (axis - 4,))
        return False

    def _selector_check(selector_):
        if selector_.layertype == LayerType.IndexedItemSelector:
            return (
                selector_.options.axis in (axis, axis - 4)
                and selector_.options.index == -1
            )
        return False

    inact = op.inacts[0]
    if inact.src_dim != 4:
        return None
    slices = []
    intervals = []
    for cop in inact.consumer_ops:
        if not cop.valid:
            return None
        if _slice_check(cop) or _selector_check(cop):
            s, e, step = _interpret_slice_wrapper(cop)
            if step > 1:
                return None
            intervals.append((s, e))
            slices.append(cop)
        else:
            return None
    intervals = sorted(intervals, key=lambda se: se[0])
    acc = 0
    for s, e in intervals:
        if s == acc:
            acc = e
        else:
            return None
    return slices


def _make_channel_slice_index(input_shape, factor, axis, start, end, step=None):
    input_shape = tuple(map(int, input_shape))
    rank = len(input_shape)
    channel_shape = input_shape[-factor:]
    if axis < 0:
        axis += rank
    axis = axis - (rank - factor)
    index = numpy.arange(numpy.prod(channel_shape)).reshape(channel_shape)
    slice_index = [slice(None)] * factor
    slice_index[axis] = slice(start, end, step)
    index = index[tuple(slice_index)].reshape(-1)
    return index


def _channel_factor_check(op, factor: int):
    if op.layertype != LayerType.Reshape:
        return False
    inact = op.inacts[0]
    if inact.src_dim != 4:
        return None
    pop = inact.producer_op
    if not check_input_npu_stride(pop):
        return None
    n, h, w, c = inact.src_shape
    # if n != 1 or n.dynamic:
    #     return None
    outact = op.outacts[0]
    if outact.src_dim < factor + 1:
        return None
    if factor == 2:
        c0, c1 = outact.src_shape[-2:]
        return c0 > 1 and c1 > 1 and c0 * c1 == c
    if factor == 3:
        c0, c1, c2 = outact.src_shape[-3:]
        return c0 * c1 * c2 == c and sum(x > 1 for x in (c0, c1, c2)) >= 2
    return False


def _concat_axis3(op_):
    return op_.layertype == LayerType.Concatenate and op_.options.axis in (3, -1)


def _concat_axis2(op_):
    return op_.layertype == LayerType.Concatenate and op_.options.axis in (2, -2)


def _interpret_slice_wrapper(op):
    if op.layertype == LayerType.Slice:
        return interpret_slice(op.inacts[0].src_shape, op.options)
    if op.layertype == LayerType.IndexedItemSelector:
        options = SimpleNamespace()
        options.axis = (op.options.axis,)
        options.start = (op.options.start,)
        options.end = (op.options.end,)
        options.step = None if op.options.step is None else (op.options.step,)
        return interpret_slice(op.inacts[0].src_shape, options)
    raise ValueError(f"Unsupported op type: {op.layertype}")


@DataFlowRuleSet.register
class MakeChannelFactorSlice(TransformRule):
    @pattern
    def factor2or3_transpose_slice(self, op: Operator, **kwargs):
        """

        (1,14,14,384)-[reshape]->(1,196,8,48)-[transpose0213]->(1,8,196,48)-[slice axis=3]->(1,8,196,16)
        =>
        (1,14,14,384)-[channel_factor_slice factor_shape=(8,48), axis=-1]->(1,14,14,128)
                     -[reshape]->(1,196,8,16)
                     -[transpose0213]->(1,8,196,16)
        =================================================================================================

        (1,1,196,768)-[reshape]->(1,196,3,8,32)-[transpose20314]->(3,1,8,196,32)-[slice axis=0]->(1,1,8,196,32)
        =>
        (1,1,196,768)-[channel_factor_slice factor_shape=(3,8,32), axis=-2]->(1,1,196,256)
                     -[reshape]->(1,196,1,8,32)
                     -[transpose20314]->(1,1,8,196,32)
        """
        for factor in (2, 3):
            reshape_cond = functools.partial(_channel_factor_check, factor=factor)
            pattern = find_operator_sequence(op, reshape_cond, "TS")
            if pattern is None:
                continue
            reshape, transpose, slice_ = pattern
            rank = slice_.inacts[0].src_dim
            channel_axes = tuple(range(-factor + rank, rank))
            slices = []
            transpose_ouact = transpose.outacts[0]
            for cop in transpose_ouact.consumer_ops:
                if cop.layertype == LayerType.Slice and 1 == len(slice_.options.axis):
                    slice_ax = slice_.options.axis[0]
                    prev_axis = transpose.options.transpose_axes[slice_ax]
                    if prev_axis in channel_axes:
                        reshape_pop = reshape.inacts[0].producer_op
                        if check_input_npu_stride(reshape_pop):
                            slices.append(cop)
            if slices:
                return reshape, transpose, slices, factor
        return None

    @factor2or3_transpose_slice.transform
    def factor2or3_transpose_slice(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, transpose, slices, factor = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        factor_shape = tuple(map(int, reshape_outact.src_shape[-factor:]))
        for slice_ in slices:
            slice_ax = slice_.options.axis[0]
            factor_axis = transpose.options.transpose_axes[slice_ax]
            prev_rank = reshape_outact.src_dim
            if slice_ax < 0:
                factor_axis = slice_ax
            else:
                factor_axis = factor_axis - prev_rank
            slice_inact = slice_.inacts[0]
            start, end, step = interpret_slice(slice_inact.src_shape, slice_.options)
            new_outact = builder.make_channel_factor_slice(
                new_inact,
                factor_shape,
                axis=factor_axis,
                start=start,
                end=end,
                step=step,
            )
            new_shape = list(factor_shape)
            new_shape[factor_axis] = -1
            new_shape = reshape_outact.src_shape[:-factor] + tuple(new_shape)
            new_outact = builder.make_reshape(new_outact, new_shape)
            new_outact = builder.make_transpose(
                new_outact, transpose.options.transpose_axes
            )
            old_outact = slice_.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(reshape, transpose, slice_)
        return builder.build()

    @pattern
    def factor2or3_slice(self, op: Operator, **kwargs):
        """
        (1,1,196,768)-[reshape]->(1,196,3,8,32)-[slice axis=2]->(1,196,1,8,32)
        =>
        (1,1,196,768)-[channel_factor_slice factor_shape=(3,8,32), axis=-2]->(1,1,196,256)
                     -[reshape]->(1,196,1,8,32)
        """

        for factor in (2, 3):
            reshape_cond = functools.partial(_channel_factor_check, factor=factor)
            pat = find_operator_sequence(op, reshape_cond, "S")
            if pat is None:
                continue
            reshape, slice_ = pat
            reshape_inact = reshape.inacts[0]
            pop = reshape_inact.producer_op
            if not check_input_npu_stride(pop):
                continue
            reshape_outact = reshape.outacts[0]
            rank = slice_.inacts[0].src_dim
            channel_axes = tuple(range(-factor + rank, rank))
            for ax in channel_axes:
                slices = []
                for cop in reshape_outact.consumer_ops:
                    if is_slice_with_axis(ax)(cop):
                        slices.append(cop)
                if slices:
                    return reshape, slices, factor
        return None

    @factor2or3_slice.transform
    def factor2or3_slice(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, slices, factor = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        factor_shape = tuple(map(int, reshape_outact.src_shape[-factor:]))
        for slice_ in slices:
            slice_ax = slice_.options.axis[0]
            prev_rank = reshape_outact.src_dim
            if slice_ax < 0:
                factor_axis = slice_ax
            else:
                factor_axis = slice_ax - prev_rank
            slice_inact = slice_.inacts[0]
            start, end, step = interpret_slice(slice_inact.src_shape, slice_.options)
            new_outact = builder.make_channel_factor_slice(
                new_inact,
                reshape_outact.src_shape[-factor:],
                axis=factor_axis,
                start=start,
                end=end,
                step=step,
            )
            new_shape = list(factor_shape)
            new_shape[factor_axis] = -1
            new_shape = reshape_outact.src_shape[:-factor] + tuple(new_shape)
            new_outact = builder.make_reshape(new_outact, new_shape)
            old_outact = slice_.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(reshape, slice_)
        return builder.build()


@DataFlowRuleSet.register
class ChannelSplit(TransformRule):
    @pattern
    def conv_split(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "C", _is_channel_slice)
        if pat is None:
            return None
        conv, slice_ = pat
        slices = split_pattern(slice_)
        if slices and any(x.layertype == LayerType.Slice for x in slices):
            return conv, slices
        return None

    @conv_split.transform
    def conv_split(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        conv, slices = self.matched_pattern
        conv_outact = conv.outacts[0]
        new_inact = builder.copy_activationspec(conv_outact, add_input_map=True)
        for slice_ in slices:
            # we do nothing for indexed_itemselector
            if slice_.layertype == LayerType.Slice:
                new_outact = builder.make_indexed_item_selector(
                    new_inact,
                    axis=slice_.options.axis[0],
                    start=slice_.options.start[0],
                    end=slice_.options.end[0],
                    step=1,
                )
                old_outact = slice_.outacts[0]
                builder.add_output_map(new_outact, old_outact)
                builder.remove_connectivity_and_invalidate(slice_)
        return builder.build()

    @pattern
    def conv_actfn_split(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "C actfn S[3]")
        if pat is None:
            return None
        conv, actfn, slice_ = pat
        slices = split_pattern(slice_)
        if slices is None:
            return None
        return conv, actfn, slices

    @conv_actfn_split.transform
    def conv_actfn_split(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        conv, actfn, slices = self.matched_pattern
        conv_outact = conv.outacts[0]
        new_inact = builder.copy_activationspec(conv_outact, add_input_map=True)
        for slice_ in slices:
            new_outact = builder.with_new_input_and_options(slice_, new_inact)
            new_outact = builder.with_new_input_and_options(actfn, new_outact)
            builder.add_output_map(new_outact, slice_.outacts[0])
            builder.remove_connectivity_and_invalidate(actfn, slice_)
        return builder.build()

    @pattern
    def biop_constant_split(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, is_biop_const, "S[3]")
        if pat is None:
            return None
        biopconst, slice_ = pat
        slices = split_pattern(slice_)
        if slices is None:
            return None
        biopconst_inact = biopconst.inacts[0]
        biopconst_outact = biopconst.outacts[0]
        if biopconst_inact.src_shape[-1] == biopconst_outact.src_shape[-1]:
            return biopconst, slices
        return None

    @biop_constant_split.transform
    def biop_constant_split(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biopconst, slices = self.matched_pattern
        const_value = biopconst.get_tensor(biopconst.options.constant).value
        biopconst_outact = biopconst.outacts[0]
        shape = tuple(map(int, biopconst_outact.src_shape))
        const_value = numpy.broadcast_to(const_value, shape)
        inact = biopconst.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        for slice_ in slices:
            s, e, step = interpret_slice(slice_.inacts[0].src_shape, slice_.options)
            new_const_val = const_value[..., s:e]
            new_outact = builder.with_new_input_and_options(slice_, new_inact)
            new_outact = builder.with_new_input_and_options(
                biopconst, new_outact, constant=new_const_val
            )
            builder.add_output_map(new_outact, slice_.outacts[0])
            builder.remove_connectivity_and_invalidate(biopconst, slice_)
        return builder.build()

    @pattern
    def concat_ax2_split(self, op: Operator, **kwargs):

        pat = find_operator_sequence(op, LayerType.Concatenate, "S[3]")
        if pat is None:
            return None
        concat, slice_ = pat
        if concat.options.axis != 2:
            return None
        slices = split_pattern(slice_, axis=3)
        if slices is None:
            return None

        # fixme: yolo6n, yolo26s post 때문에 일단 막음.
        if (
            len(slices) == 2
            and 3 == len(concat.options.inputs)
            and all(4 == int(x.src_shape[-1]) for x in concat.inacts)
        ):
            """
            (1,1,8400,4)->(1,1,8400,2)
            """
            slice0, slice1 = slices

            def check_(slice_):
                s, e, step = interpret_slice(slice_.inacts[0].src_shape, slice_.options)
                return e - s == 2 and step == 1

            if check_(slice0) or check_(slice1):
                return None

        return concat, slices

    @concat_ax2_split.transform
    def concat_ax2_split(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        concat, slices = self.matched_pattern
        for slice_ in slices:
            new_cc_inacts = []
            for inact in concat.inacts:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.with_new_input_and_options(slice_, new_inact)
                new_cc_inacts.append(new_inact)
            new_cc_outact = builder.make_concatenate(new_cc_inacts, axis=2)
            old_outact = slice_.outacts[0]
            builder.add_output_map(new_cc_outact, old_outact)
            builder.remove_connectivity_and_invalidate(concat, slice_)
        return builder.build()

@DataFlowRuleSet.register
class ConcatenateTransposeSplit(TransformRule):
    @pattern
    def T0132_split(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.Concatenate, "T0132 S[2]")
        if pat is None:
            return None
        concat, transpose, slice_ = pat
        slices = split_pattern(slice_, axis=2)
        if slices is None:
            return None
        return concat, transpose, slices

    @T0132_split.transform
    def T0132_split(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        concat, transpose, slices = self.matched_pattern
        concat_outact = concat.outacts[0]
        new_inact = builder.copy_activationspec(concat_outact, add_input_map=True)
        for slice_ in slices:
            new_outact = builder.with_new_input_and_options(
                slice_, new_inact, axis=(3,)
            )
            new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
            old_outact = slice_.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(transpose, slice_)
        return builder.build()


@DataFlowRuleSet.register
class ConcatenateReshapeSplit(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.Concatenate, "R[1hw(cd)->1hwcd] S[3]"
        )
        if pat is None:
            return None
        concat, reshape, slice_ = pat
        if concat.options.axis not in (3, -1):
            return None
        slices = split_pattern(slice_, axis=3)
        if slices is None:
            return None
        return concat, reshape, slices

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        concat, reshape, slices = self.matched_pattern
        concat_outact = concat.outacts[0]
        new_inact = builder.copy_activationspec(concat_outact, add_input_map=True)
        for slice_ in slices:
            new_outact = builder.with_new_input_and_options(
                slice_, new_inact, axis=(3,)
            )
            new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
            old_outact = slice_.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(reshape, slice_)
        return builder.build()


@DataFlowRuleSet.register
class ConvTransposeSlice(TransformRule):
    @pattern
    def T0213_slice3(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "C T0213 S[3]")
        if pat is None:
            return None
        return pat

    @T0213_slice3.transform
    def T0213_slice3(self, *args, **kwargs):
        conv, transpose, slice_ = self.matched_pattern
        builder = OpTransformResultV2Builder()
        conv_outact = conv.outacts[0]
        new_inact = builder.copy_activationspec(conv_outact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_inact)
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        builder.add_output_map(new_outact, slice_.outacts[0])
        builder.remove_connectivity_and_invalidate(conv, transpose, slice_)
        return builder.build()

    @pattern
    def T0312_slice(self, op: Operator, **kwargs):
        """
        for this case, we allow npu_ops
        """

        def _check_prev_op(op: Operator) -> bool:
            return is_basic_npu_op(op) or op.layertype == LayerType.IndexedItemSelector

        pat = find_operator_sequence(op, _check_prev_op, "T0312 S")
        if pat is not None:
            return pat
        pat = find_operator_sequence(op, _check_prev_op, "actfn T0312 S")
        return pat

    @T0312_slice.transform
    def T0312_slice(self, *args, **kwargs):
        transpose, slice_ = self.matched_pattern[-2:]
        builder = OpTransformResultV2Builder()
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        ax = slice_.options.axis[0]
        new_outact = builder.with_new_input_and_options(
            slice_,
            new_inact,
            axis=(transpose.options.transpose_axes[ax],),
        )
        old_outact = slice_.outacts[0]
        if 1 == (old_outact.consumer_ops):
            next_transpose = old_outact.consumer_ops[0]
            if is_transpose(next_transpose, (0, 2, 3, 1)):
                builder.add_output_map(new_outact, next_transpose.outacts[0])
                builder.remove_connectivity_and_invalidate(
                    transpose, slice_, next_transpose
                )
                return builder.build()
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, slice_)
        return builder.build()

    @pattern
    def yolo_dfl_case0(self, op: Operator, **kwargs):
        """
        NHWC(1,4,8400,16)-[Softmax]->(1,4,8400,16)-[Linear]->(1,4,8400,1)-[Slice0]->(1,2,8400,1)
                                                                              -[Slice1]->(1,2,8400,1)
        We replace convolution to (without softmax)
        (1,4,8400,16)-[conv]->(1,1,8400,4)-[Slice0]-(1,1,8400,2)->[Transpose]->(1,2,8400,1)
                                                 -[Slice1]-(1,1,8400,2)->[Transpose]->(1,2,8400,1)
        """
        pat = find_operator_sequence(op, LayerType.Softmax, "L S[1]")
        if pat is None:
            return None
        softmax, conv, slice_ = pat
        if softmax.options.axis not in (3, -1):
            return None
        if conv.options.bias != -1:
            return None
        if not (conv.options.out_channels == 1 and conv.options.in_channels < 32):
            return None
        slices = split_pattern(slice_, axis=1)
        if slices is None:
            return None
        if any(x.dynamic for x in conv.inacts[0].src_shape):
            return None
        return softmax, conv, slices

    @yolo_dfl_case0.transform
    def yolo_dfl_case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        softmax, conv, slices = self.matched_pattern
        inact = conv.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        conv_weight = conv.get_tensor(conv.options.weight).value
        new_out_channels = int(new_inact.src_shape[1])
        new_conv_weight_shape = list(conv_weight.shape)
        new_conv_weight_shape[0] = int(new_out_channels)
        new_conv_weight_shape[2] = int(new_out_channels)
        new_conv_weight = numpy.zeros(new_conv_weight_shape, dtype="float32")
        for i in range(new_out_channels):
            new_conv_weight[i, :, i, :] = conv_weight[0, :, 0, :]
        new_outact = builder.make_conv2d(
            new_inact,
            in_channels=new_conv_weight.shape[1],
            out_channels=new_conv_weight.shape[0],
            h_kernel=new_out_channels,
            weight=new_conv_weight,
        )
        for slice_ in slices:
            new_slice_outact = builder.with_new_input_and_options(
                slice_, new_outact, axis=(3,)
            )
            new_slice_outact = builder.make_transpose(new_slice_outact, (0, 3, 2, 1))
            slice_outact = slice_.outacts[0]
            builder.add_output_map(new_slice_outact, slice_outact)
            builder.remove_connectivity_and_invalidate(conv, slice_)
        return builder.build()


@DataFlowRuleSet.register
class ConvReshapeSlice(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "C actfn R[1hwc->11(hw)c] S[3]")
        if pat is not None:
            conv, actfn, reshape, slice_ = pat
        else:
            pat = find_operator_sequence(op, "C R[1hwc->11(hw)c] S[3]")
            if pat is None:
                return None
            conv, reshape, slice_ = pat
        reshape_inact = reshape.inacts[0]
        n, h, w, c = reshape_inact.src_shape
        # slice_outact = slice_.outacts[0]
        # for cop in slice_outact.consumer_ops:
        #     if cop.layertype == LayerType.Concatenate:
        #         return None
        if h > 1 and w > 1:
            return reshape, slice_
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, slice_ = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_inact)
        old_outact = slice_.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, slice_)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "C actfn R[1hw1->11hw] S[2]")
        if pat is not None:
            conv, actfn, reshape, slice_ = pat
        else:
            pat = find_operator_sequence(op, "C R[1hw1->11hw] S[2]")
            if pat is None:
                return None
            conv, reshape, slice_ = pat
        reshape_inact = reshape.inacts[0]
        n, h, w, c = reshape_inact.src_shape
        if w > 1:
            return reshape, slice_
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, slice_ = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_inact, axis=(1,))
        old_outact = slice_.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, slice_)
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "C actfn R S[3]")
        if pat is not None:
            conv, actfn, reshape, slice_ = pat
        else:
            pat = find_operator_sequence(op, "C R S[3]")
            if pat is None:
                return None
            conv, reshape, slice_ = pat
        reshape_inact = reshape.inacts[0]
        reshape_outact = reshape.outacts[0]
        if not (4 == reshape_inact.src_dim == reshape_outact.src_dim):
            return None
        n, h, w, c = reshape_inact.src_shape
        if h == 1 or w == 1:
            return None
        n1, h1, w1, c1 = reshape_outact.src_shape
        if h1 == 1 or w1 == 1:
            return None
        if n == n1 == 1 and c == c1:
            return reshape, slice_
        return None

    @case2.transform
    def case2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, slice_ = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(slice_, new_inact)
        old_outact = slice_.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, slice_)
        return builder.build()


@DataFlowRuleSet.register
class ConcatenateReshapeSlice(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, _concat_axis3, "R[1hwc->11(hw)c]", _is_channel_slice
        )
        if pat is None:
            return None
        concat, reshape, slice_ = pat
        input_channels = []
        acc = 0
        for inact in concat.inacts:
            c = int(inact.src_shape[-1])
            input_channels.append((acc, c + acc))
            acc += c
        reshape_outact = reshape.outacts[0]
        for cop in reshape_outact.consumer_ops:
            if _is_channel_slice(cop):
                s, e, step = _interpret_slice_wrapper(cop)
                for i_start, e_end in input_channels:
                    if i_start <= s < e <= e_end:
                        return concat, reshape, slice_
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        concat, reshape, slice_ = self.matched_pattern
        input_channels = []
        acc = 0
        for inact in concat.inacts:
            c = int(inact.src_shape[-1])
            input_channels.append((acc, c + acc, inact))
            acc += c
        reshape_outact = reshape.outacts[0]
        cop_copy = [x for x in reshape_outact.consumer_ops]
        for cop in cop_copy:
            if _is_channel_slice(cop):
                s, e, step = _interpret_slice_wrapper(cop)
                for i_start, e_end, inact in input_channels:
                    if i_start <= s < e <= e_end:
                        new_outact = builder.copy_activationspec(
                            inact, add_input_map=True
                        )
                        if step is not None:
                            step = (step,)
                        slice_start = s - i_start
                        new_outact = builder.make_slice(
                            new_outact,
                            axis=(3,),
                            start=(slice_start,),
                            end=(slice_start + (e - s),),
                            step=step,
                        )
                        old_outact = cop.outacts[0]
                        if old_outact.src_shape != new_outact.src_shape:
                            new_outact = builder.make_reshape(
                                new_outact, old_outact.src_shape
                            )
                        builder.add_output_map(new_outact, old_outact)
                        builder.remove_connectivity_and_invalidate(concat, reshape, cop)
        return builder.build()


@DataFlowRuleSet.register
class BiopSlice(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        def check_mul_add(op):
            return op.layertype in (LayerType.Multiply, LayerType.Adding, LayerType.Sub)

        pat = find_operator_sequence(op, check_mul_add, "S[3]")
        if pat is None:
            return None
        biop, slice_ = pat
        inact0, inact1 = biop.inacts
        if inact0.src_shape[-1] != inact1.src_shape[-1]:
            return None
        if check_input_npu_stride(inact0.producer_op) or check_input_npu_stride(
            inact1.producer_op
        ):
            outact = biop.outacts[0]
            slices = []
            has_biop = False
            for cop in outact.consumer_ops:
                if is_slice_with_axis(3)(cop):
                    slices.append(cop)
                if check_mul_add(cop):
                    has_biop = True
            if not has_biop and slices:
                return biop, slices
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop, slices = self.matched_pattern

        inact0 = biop.inacts[0]
        inact1 = biop.inacts[1]
        new_inact0 = builder.copy_activationspec(inact0, add_input_map=True)
        new_inact1 = builder.copy_activationspec(inact1, add_input_map=True)
        for slice_ in slices:
            new_left = builder.with_new_input_and_options(slice_, new_inact0)
            new_right = builder.with_new_input_and_options(slice_, new_inact1)
            new_outact = builder.with_new_input_and_options(biop, (new_left, new_right))
            old_outact = slice_.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(biop, slice_)
        return builder.build()


@DataFlowRuleSet.register
class ConcatenateSlice(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, _concat_axis3, "S[3]")
        if pat is None:
            return None
        concat, slice_ = pat
        slice_inact = slice_.inacts[0]
        if slice_inact.src_dim != 4:
            return None
        if 1 != len(slice_.options.axis):
            return None
        # fixme: dynamic and -1:max slice
        if slice_inact.src_shape[-1].dynamic:
            return None

        intervals = []
        acc = 0
        for inact in concat.inacts:
            c = int(inact.src_shape[-1])
            intervals.append((acc, acc + c))
            acc += c

        slices = []
        concat_outact = concat.outacts[0]
        for cop in concat_outact.consumer_ops:
            if cop.layertype == LayerType.Slice and cop.options.axis in ((-1,), (3,)):
                s, e, st = interpret_slice(slice_inact.src_shape, slice_.options)
                for int_s, int_e in intervals:
                    if int_s <= s < e <= int_e:
                        slices.append(cop)
        if slices:
            return concat, slices
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        concat, slices = self.matched_pattern
        intervals = []
        acc = 0
        for inact in concat.inacts:
            c = int(inact.src_shape[-1])
            intervals.append((acc, acc + c, inact))
            acc += c

        for slice_ in slices:
            s, e, st = interpret_slice(slice_.inacts[0].src_shape, slice_.options)
            for int_s, int_e, inact in intervals:
                if int_s <= s < e <= int_e:
                    new_inact = builder.copy_activationspec(inact, add_input_map=True)
                    new_s = s - int_s
                    new_e = new_s + (e - s)
                    new_outact = builder.make_slice(
                        new_inact, axis=(3,), start=(new_s,), end=(new_e,), step=(st,)
                    )
                    old_outact = slice_.outacts[0]
                    builder.add_output_map(new_outact, old_outact)
                    builder.remove_connectivity_and_invalidate(concat, slice_)
        return builder.build()
