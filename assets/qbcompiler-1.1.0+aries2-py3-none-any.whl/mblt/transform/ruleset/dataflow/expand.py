import numpy

from mblt.core import TransformRule, pattern, Operator, LayerType
from mblt.operator import broadcast_shape
from mblt.subgraph.util.pattern_util import (
    is_biop_wrapper,
    check_input_npu_stride,
    find_operator_sequence,
    check_output_npu_stride,
)
from mblt.transform.transform_result import (
    OpTransformResultV2Builder,
)
from ._ruleset import DataFlowRuleSet


def _is_expand(op):
    if op.layertype == LayerType.Expand:
        return True
    if op.layertype == LayerType.IndexedItemSelector and op.options.repeat is not None:
        return True
    return False


@DataFlowRuleSet.register
class RemoveExpand(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if not is_biop_wrapper(op):
            return None
        inact0, inact1 = op.inacts
        outact = op.outacts[0]
        target_shape = tuple(map(int, outact.src_shape))
        if _is_expand(inact0.producer_op):
            expand = inact0.producer_op
            expand_inact = inact0.producer_op.inacts[0]
            if target_shape == broadcast_shape(
                expand_inact.src_shape, inact1.src_shape
            ):
                return expand, op, 0
        if _is_expand(inact1.producer_op):
            expand = inact1.producer_op
            expand_inact = inact1.producer_op.inacts[0]
            if target_shape == broadcast_shape(
                expand_inact.src_shape, inact0.src_shape
            ):
                return expand, op, 1
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        (expand, op, target_idx) = self.matched_pattern
        new_inacts = []
        for idx, inact in enumerate(op.inacts):
            if target_idx == idx:
                inact = expand.inacts[0]
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(op, *new_inacts)
        old_outact = op.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(expand, op)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        """
        (1,40000,1,32)-[resize]->(1,40000,20,32)-|-[concat axis=3]-(1,40000,20,64)-[linear]->(1,40000,20,64)
        (1,40000,20,32)--------------------------|
        """
        pat = find_operator_sequence(op, LayerType.Concatenate, "L", strict_search=True)
        if pat is None:
            return None
        concat, linear = pat
        if concat.options.axis not in (3, -1):
            return None
        if 2 != len(concat.options.inputs):
            return None

        def _f(pop0, pop1):
            if _is_expand(pop0) and not _is_expand(pop1):
                inact = pop0.inacts[0]
                n, h, w, c = inact.src_shape
                outact = pop0.outacts[0]
                x, y, z, t = outact.src_shape
                if any(x.dynamic for x in (n, h, w, c)):
                    return False
                return w == 1 and z > 1 and (n, h, c) == (x, y, t)
            return False

        if any(x.src_shape[3] < 32 for x in concat.inacts):
            return None
        pop0 = concat.inacts[0].producer_op
        pop1 = concat.inacts[1].producer_op
        if _f(pop0, pop1):
            return pop0, concat, linear
        if _f(pop1, pop0):
            return pop1, concat, linear
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        resize, concat, linear = self.matched_pattern
        new_inacts = []
        conv_weight = linear.get_tensor(linear.options.weight).value
        acc = 0
        for i, inact in enumerate(concat.inacts):
            if inact.name == resize.outacts[0].name:
                inact = resize.inacts[0]
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
            c = int(inact.src_shape[3])
            w = conv_weight[:, acc : acc + c]
            new_outact = builder.with_new_input_and_options(
                linear, new_inact, weight=w, in_channels=c
            )
            acc += c
            new_inacts.append(new_outact)
        new_outacts = builder.make_add(new_inacts[0], new_inacts[1])
        old_outact = linear.outacts[0]
        builder.add_output_map(new_outacts, old_outact)
        builder.remove_connectivity_and_invalidate(resize, concat, linear)
        return builder.build()


@DataFlowRuleSet.register
class Expand(TransformRule):

    @pattern
    def case_repeat_batch(self, op: Operator, **kwargs):
        if not (
            op.layertype == LayerType.Expand
            and op.options.constant != -1
            and not op.options.is_const_first
        ):
            return None
        expand = op
        inact = expand.inacts[0]
        if not (inact.src_dim == 4 and inact.src_shape[0] == 1):
            return None
        pop = inact.producer_op
        if not check_input_npu_stride(pop):
            return None

        const_val = expand.get_tensor(expand.options.constant).value
        const_len = const_val.size
        const_val = tuple(map(int, const_val))
        if const_len < inact.src_dim:
            const_val = (1,) * (inact.src_dim - const_val.ndim) + const_val
        expand_axes = []
        for i in range(4):
            s = inact.src_shape[i]
            c = const_val[i]
            if s != c:
                if s == 1 and c > 1:
                    expand_axes.append(i)
        if tuple(expand_axes) == (0,):
            return expand
        return None

    @case_repeat_batch.transform
    def case_repeat_batch(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        expand = self.matched_pattern
        inact = expand.inacts[0]
        const_val = expand.get_tensor(expand.options.constant).value
        const_len = const_val.size
        const_val = tuple(map(int, const_val))
        if const_len < inact.src_dim:
            const_val = (1,) * (inact.src_dim - const_val.ndim) + const_val
        n_repeat = const_val[0]
        n, h, w, c = inact.src_shape
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_reshape(new_inact, (n, 1, -1, c))
        new_outact = builder.make_indexed_item_selector(
            new_outact, axis=1, repeat=int(n_repeat)
        )
        old_outact = expand.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(expand)
        return builder.build()

    @pattern
    def case_repeat_h_w(self, op: Operator, **kwargs):
        if not (
            op.layertype == LayerType.Expand
            and op.options.constant != -1
            and not op.options.is_const_first
        ):
            return None
        expand = op
        inact = expand.inacts[0]
        pop = inact.producer_op
        if not check_input_npu_stride(pop):
            return None
        const_val = expand.get_tensor(expand.options.constant).value
        const_len = const_val.size
        const_val = tuple(map(int, const_val))
        if const_len < inact.src_dim:
            const_val = (1,) * (inact.src_dim - const_val.ndim) + const_val
        expand_axes = []
        for i in range(4):
            s = inact.src_shape[i]
            c = const_val[i]
            if s != c:
                if s == 1 and c > 1:
                    expand_axes.append(i)
        if tuple(expand_axes) in ((1,), (2,)):
            return expand, expand_axes[0]
        return None

    @case_repeat_h_w.transform
    def case_repeat_h_w(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        expand, ax = self.matched_pattern
        inact = expand.inacts[0]
        const_val = expand.get_tensor(expand.options.constant).value
        const_len = const_val.size
        const_val = tuple(map(int, const_val))
        if const_len < inact.src_dim:
            const_val = (1,) * (inact.src_dim - const_val.ndim) + const_val
        n_repeat = const_val[ax]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_indexed_item_selector(
            new_inact, axis=ax, repeat=int(n_repeat)
        )
        old_outact = expand.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(expand)
        return builder.build()

    @pattern
    def case0(self, op: Operator, **kwargs):
        """Expand a constant input to a resize operation."""

        pat = find_operator_sequence(op, "T0312 R[nchw->nch1w1]", LayerType.Expand)
        if pat is None:
            return None
        transpose, reshape, expand = pat
        if expand.options.is_const_first:
            return None
        expand_inact = expand.inacts[0]
        expand_constant = expand.get_tensor(expand.options.constant).value
        expand_constant = tuple(map(int, expand_constant))
        expand_input_shape = tuple(map(int, expand_inact.src_shape))
        same_index = (0, 1, 2, 4)
        for i, (x, y) in enumerate(zip(expand_input_shape, expand_constant)):
            if i in same_index:
                if x != y:
                    return None
            else:
                if x != 1:
                    return None
        transpose_inact = transpose.inacts[0]
        if check_input_npu_stride(transpose_inact.producer_op):
            return transpose, reshape, expand
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape, expand = self.matched_pattern
        transpose_inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(transpose_inact, add_input_map=True)

        expand_constant = expand.get_tensor(expand.options.constant).value
        a, b, c, d, e, f = map(int, expand_constant)
        sizes = (a, c * d, e * f, b)

        new_outact = builder.make_resize(
            new_inact,
            sizes=sizes,
            resize_type="nearest",
            transform_mode="asymmetric",
            nearest_mode="floor",
        )
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = expand.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape, expand)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        """
        (1,256,19,1,19,1)-[expand]->(1,256,19,2,19,2)-[reshape]->(1,256,38,38)-[transpose]->(1,38,38,256)
        =>
        (1,256,19,1,19,1)-[resize nearest asymmetric]->(1,38,38,256)

        (1,256,19,1,19,1)-[reshape]->(1,256,19,19)
                         -[transpose]->(1,19,19,256)
                         -[tconv2d]->(1,38,38,256)
        """

        pat = find_operator_sequence(
            op, LayerType.Expand, "R[1chdwe->1c(hd)(we)] T0231"
        )
        if pat is None:
            return None
        expand, reshape, transpose = pat
        expand_inact = expand.inacts[0]
        expand_outact = expand.outacts[0]
        a, b, c, d, e, f = map(int, expand_outact.src_shape)
        if (
            expand_inact.src_shape == (a, b, c, 1, e, 1)
            and c > 1
            and e > 1
            and d > 1
            and f > 1
        ):
            for cop in transpose.outacts[0].consumer_ops:
                if check_output_npu_stride(cop):
                    return expand, reshape, transpose
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        USE_RESIZE = True

        builder = OpTransformResultV2Builder()
        expand, reshape, transpose = self.matched_pattern
        expand_inact = expand.inacts[0]
        expand_outact = expand.outacts[0]
        new_inact = builder.copy_activationspec(expand_inact, add_input_map=True)
        a, b, c, d, e, f = map(int, expand_outact.src_shape)
        new_inact = builder.make_reshape(new_inact, (a, b, c, e))
        new_inact = builder.make_transpose(new_inact, (0, 2, 3, 1))

        out_channels = in_channels = int(new_inact.src_shape[-1])

        if USE_RESIZE:
            sizes = (a, c * d, e * f, b)
            new_outact = builder.make_resize(
                new_inact,
                sizes=sizes,
                resize_type="nearest",
                transform_mode="asymmetric",
                nearest_mode="floor",
            )
        else:
            groups = in_channels
            groups = 1

            kernel_h = d
            kernel_w = f

            weight = numpy.zeros(
                (out_channels, in_channels // groups, kernel_h, kernel_w),
                dtype="float32",
            )
            if groups > 1:
                weight[:, 0, :, :] = 1.0
            else:
                for i in range(out_channels):
                    weight[i, i, ...] = 1.0

            west_padding = east_padding = kernel_w - 1
            north_padding = south_padding = kernel_h - 1

            new_outact = builder.make_transposeconv2d(
                new_inact,
                in_channels=in_channels,
                out_channels=out_channels,
                h_kernel=kernel_h,
                w_kernel=kernel_w,
                h_stride=kernel_h,
                w_stride=kernel_w,
                north_padding=south_padding,  # npu's north/south padding is inverted.
                south_padding=north_padding,
                west_padding=west_padding,
                east_padding=east_padding,
                group_number=groups,
                weight=weight,
            )
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(expand, reshape, transpose)
        return builder.build()
