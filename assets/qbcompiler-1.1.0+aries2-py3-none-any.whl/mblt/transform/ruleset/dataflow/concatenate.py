import collections

import numpy

from mblt import Operator, LayerType
from mblt.core import TransformRule, pattern
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    is_conv_type,
    is_actfunc_type,
    is_reshape_with_expr,
    check_input_npu_stride,
    is_transpose,
)
from mblt.transform.ruleset.dataflow import DataFlowRuleSet
from mblt.transform.transform_result import OpTransformResultV2Builder


@DataFlowRuleSet.register
class SliceBiopConstSeqConcatenate(TransformRule):

    def _xconst_ref_shape(self, xconst, ax, ref_shape):
        def _target_shape(shape, ax):
            return tuple(x if i != ax else x for i, x in enumerate(shape))

        ac_inact = xconst.inacts[0]
        ac_outact = xconst.outacts[0]
        # not broadcasting
        if ac_inact.src_shape != ac_outact.src_shape:
            return None
        const = xconst.get_tensor(xconst.options.constant).value
        rank = ac_inact.src_dim
        if const.ndim < rank:
            const = const.reshape((1,) * (rank - const.ndim) + const.shape)
        curr_shape = _target_shape(const.shape, ax)
        if ref_shape is None:
            return curr_shape
        if ref_shape == curr_shape:
            return curr_shape
        return None

    def _slice_check(self, slice_, ax):
        if len(slice_.options.axis) != 1:
            return False
        slice_ax = slice_.options.axis[0]
        slice_inact = slice_.inacts[0]
        rank = slice_inact.src_dim
        if slice_ax < 0:
            slice_ax += rank
        if slice_ax != ax:
            return False
        return True

    @pattern
    def slice_xconst(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Concatenate:
            return None

        def _lt_check(lt, concat):
            ax = concat.options.axis
            outact = concat.outacts[0]
            rank = outact.src_dim
            if ax < 0:
                ax += rank
            ac_ref_shape = None
            acs = []
            ref_slice_inact = None
            for inact in concat.inacts:
                pat_ = find_operator_sequence(inact.producer_op, LayerType.Slice, lt)
                if pat_ is None:
                    return None
                slice_, addconst = pat_
                if not self._slice_check(slice_, ax):
                    return None
                if ref_slice_inact is None:
                    ref_slice_inact = slice_.inacts[0]
                if ref_slice_inact.name != slice_.inacts[0].name:
                    return None
                ac_ref_shape = self._xconst_ref_shape(addconst, ax, ac_ref_shape)
                if ac_ref_shape is None:
                    return None
                acs.append(addconst)
            return acs

        # slice size에 대해서는 체크하지 않았기 때문에 slice는 여기서 처리하지 않음.
        mc_res = _lt_check(LayerType.MultiplyConstant, op)
        if mc_res is not None:
            return mc_res, op
        ac_res = _lt_check(LayerType.AddingConstant, op)
        if ac_res is not None:
            return ac_res, op
        return None

    @slice_xconst.transform
    def slice_xconst(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        xconsts, concat = self.matched_pattern
        new_inacts = []
        new_const = []
        rank = concat.inacts[0].src_dim
        for xconst in xconsts:
            inact = xconst.inacts[0]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inacts.append(new_inact)
            ac_val = xconst.get_tensor(xconst.options.constant).value
            if ac_val.ndim < rank:
                ac_val = ac_val.reshape((1,) * (rank - ac_val.ndim) + ac_val.shape)
            new_const.append(ac_val)
            builder.remove_connectivity_and_invalidate(xconst, concat)
        ax = concat.options.axis
        new_const = numpy.concatenate(new_const, axis=ax)
        new_outact = builder.with_new_input_and_options(concat, new_inacts)
        if xconsts[0].layertype == LayerType.MultiplyConstant:
            new_outact = builder.make_mul(new_outact, new_const)
        else:
            new_outact = builder.make_add(new_outact, new_const)
        old_outact = concat.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        return builder.build()

    @pattern
    def slice_mulconst_addconst(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Concatenate:
            return None
        outact = op.outacts[0]
        ax = op.options.axis

        rank = outact.src_dim
        if ax < 0:
            ax += rank

        mc_ref_shape = None
        ac_ref_shape = None
        mcs = []
        acs = []
        ref_slice_inact = None
        for inact in op.inacts:
            pat_ = find_operator_sequence(
                inact.producer_op,
                LayerType.Slice,
                LayerType.MultiplyConstant,
                LayerType.AddingConstant,
            )
            if pat_ is None:
                return None
            slice_, mulconst, addconst = pat_
            if not self._slice_check(slice_, ax):
                return None
            if ref_slice_inact is None:
                ref_slice_inact = slice_.inacts[0]
            if ref_slice_inact.name != slice_.inacts[0].name:
                return None
            mc_ref_shape = self._xconst_ref_shape(mulconst, ax, mc_ref_shape)
            if mc_ref_shape is None:
                return None
            ac_ref_shape = self._xconst_ref_shape(addconst, ax, ac_ref_shape)
            if ac_ref_shape is None:
                return None
            mcs.append(mulconst)
            acs.append(addconst)
        return mcs, acs, op

    @slice_mulconst_addconst.transform
    def slice_mulconst_addconst(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        mcs, acs, concat = self.matched_pattern
        new_inacts = []
        mc_consts = []
        ac_consts = []
        rank = concat.inacts[0].src_dim
        for mulconst, addconst in zip(mcs, acs):
            inact = mulconst.inacts[0]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inacts.append(new_inact)
            mc_val = mulconst.get_tensor(mulconst.options.constant).value
            if mc_val.ndim < rank:
                mc_val = mc_val.reshape((1,) * (rank - mc_val.ndim) + mc_val.shape)
            mc_consts.append(mc_val)
            ac_val = addconst.get_tensor(addconst.options.constant).value
            if ac_val.ndim < rank:
                ac_val = ac_val.reshape((1,) * (rank - ac_val.ndim) + ac_val.shape)
            ac_consts.append(ac_val)
            builder.remove_connectivity_and_invalidate(mulconst, addconst, concat)
        ax = concat.options.axis
        new_mc_val = numpy.concatenate(mc_consts, axis=ax)
        new_ac_val = numpy.concatenate(ac_consts, axis=ax)
        new_outact = builder.with_new_input_and_options(concat, new_inacts)
        new_outact = builder.make_mul(new_outact, new_mc_val)
        new_outact = builder.make_add(new_outact, new_ac_val)
        old_outact = concat.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        return builder.build()


@DataFlowRuleSet.register
class ConcatenateAndOp(TransformRule):
    @pattern
    def case_actfn(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.Concatenate, is_actfunc_type, strict_search=True
        )
        if pat is None:
            return None
        concat, actfunc = pat
        for inact in concat.inacts:
            if inact.producer_op.valid:
                if is_conv_type(inact.producer_op):
                    return concat, actfunc
                pat = find_operator_sequence(
                    inact.producer_op, is_conv_type, LayerType.Reshape
                )
                if pat is not None:
                    return concat, actfunc
                pat = find_operator_sequence(
                    inact.producer_op, is_conv_type, LayerType.Transpose
                )
                if pat is not None:
                    return concat, actfunc
        return None

    @case_actfn.transform
    def case_actfn(self, *args, **kwargs):
        concat, actfn = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = []
        for inact in concat.inacts:
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inact = builder.with_new_input_and_options(actfn, new_inact)
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(concat, new_inacts)
        old_outact = actfn.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(concat, actfn)
        return builder.build()

    @pattern
    def case_biopconst(self, op: Operator, **kwargs):
        def check(op0):
            return op.layertype in (
                LayerType.AddingConstant,
                LayerType.MultiplyConstant,
                LayerType.SubConstant,
            )

        pat = find_operator_sequence(
            op, LayerType.Concatenate, check, strict_search=True
        )
        if pat is None:
            return None
        concat, biop_const = pat
        if concat.options.axis not in (3, -1):
            return None
        c = int(biop_const.inacts[0].src_shape[-1])
        const_value = biop_const.get_tensor(biop_const.options.constant).value
        if const_value.shape == (c,) or const_value.size == 1:
            # fixme: ruduced ops count 기준으로 수정.
            cnt = sum(
                1 == len(inact.consumer_ops) and is_conv_type(inact.producer_op)
                for inact in concat.inacts
            )
            if cnt >= len(concat.options.inputs) - 1:
                return concat, biop_const
        return None

    @case_biopconst.transform
    def case_biopconst(self, *args, **kwargs):
        concat, biop_const = self.matched_pattern
        builder = OpTransformResultV2Builder()
        const_value = biop_const.get_tensor(biop_const.options.constant).value
        if const_value.size == 1:
            new_inacts = []
            for inact in concat.inacts:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.with_new_input_and_options(biop_const, new_inact)
                new_inacts.append(new_inact)
        else:  # channelwise
            acc = 0
            new_inacts = []
            for inact in concat.inacts:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                csize = int(new_inact.src_shape[-1])
                new_inact = builder.with_new_input_and_options(
                    biop_const, new_inact, constant=const_value[acc : acc + csize]
                )
                new_inacts.append(new_inact)
                acc += csize
        new_outact = builder.with_new_input_and_options(concat, new_inacts)
        old_outact = biop_const.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(concat, biop_const)
        return builder.build()

    @pattern
    def case_biop_reshape_reducesum(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "biop R[1hw(bc)->1hwbc]", LayerType.ReduceSum)
        if pat is None:
            return None
        biop, reshape, reduce = pat
        reshape_outact = reshape.outacts[0]
        n, h, w, b, c = reshape_outact.src_shape
        if b == 1 or b.dynamic:
            return None
        if not (reduce.options.reduce_axes == (3,) and reduce.options.keep_dims):
            return None
        target_num = int(b)
        c = int(c)
        concats = []
        for inact in biop.inacts:
            concat = inact.producer_op
            if not (
                concat.layertype == LayerType.Concatenate
                and concat.options.axis in (3, -1)
                and target_num == len(concat.options.inputs)
            ):
                return None
            if all(inact.src_shape[-1] == c for inact in concat.inacts):
                concats.append(concat)
            else:
                return None
        if len(concats) == 2:
            return concats, biop
        return None

    @case_biop_reshape_reducesum.transform
    def case_biop_reshape_reducesum(self, *args, **kwargs):
        concats, biop = self.matched_pattern
        builder = OpTransformResultV2Builder()
        dct = collections.defaultdict(list)
        for concat in concats:
            for i, inact in enumerate(concat.inacts):
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                dct[i].append(new_inact)
            builder.remove_connectivity_and_invalidate(concat, biop)
        new_outacts = []
        for i in range(len(dct)):
            new_inacts = dct[i]
            new_outact = builder.with_new_input_and_options(biop, new_inacts)
            new_outacts.append(new_outact)
        new_outact = builder.make_concatenate(new_outacts, axis=-1)
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        return builder.build()

    @pattern
    def case_linear(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.Concatenate, "L", strict_search=True)
        if pat is None:
            return None
        concat, linear = pat
        if concat.options.axis not in (3, -1):
            return None
        for inact in concat.inacts:
            pop = inact.producer_op
            if pop.layertype == LayerType.Convolution and pop.options.group_number == 1:
                return concat, linear
        return None

    @case_linear.transform
    def case_linear(self, *args, **kwargs):
        concat, linear = self.matched_pattern
        builder = OpTransformResultV2Builder()
        weight = linear.get_tensor(linear.options.weight).value
        if linear.options.bias != -1:
            bias = linear.get_tensor(linear.options.bias).value
        else:
            bias = None
        oc = linear.options.out_channels
        acc = 0
        new_adding_inacts = []
        for inact in concat.inacts:
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            in_channels = int(new_inact.src_shape[-1])
            new_weight = weight[:, acc : acc + in_channels, ...]
            # bias는 한 번만 더해야 함.
            if bias is not None and acc == 0:
                new_bias = bias
            else:
                new_bias = None
            new_conv_outact = builder.make_conv2d(
                new_inact,
                in_channels=in_channels,
                out_channels=oc,
                weight=new_weight,
                bias=new_bias,
            )
            new_adding_inacts.append(new_conv_outact)
            acc += in_channels
        new_outact = new_adding_inacts[0]
        for new_inact in new_adding_inacts[1:]:
            new_outact = builder.make_add(new_outact, new_inact)
        old_outact = linear.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(concat, linear)
        return builder.build()


@DataFlowRuleSet.register
class ReshapeAndConcatenate(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype == LayerType.Concatenate and op.options.axis == 2:
            reshapes = []
            for inact in op.inacts:
                reshape = inact.producer_op
                if is_reshape_with_expr("1hw1->111(hw)")(reshape):
                    if check_input_npu_stride(reshape.inacts[0].producer_op):
                        reshapes.append(reshape)
                        continue
                return None
            return reshapes, op
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshapes, concat = self.matched_pattern
        new_cc_inacts = []
        for reshape in reshapes:
            inact = reshape.inacts[0]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            n, h, w, c = new_inact.src_shape
            assert c == 1
            new_inact = builder.make_reshape(new_inact, (n, 1, -1, 1))
            new_cc_inacts.append(new_inact)
            builder.remove_connectivity_and_invalidate(reshape, concat)
        new_outact = builder.with_new_input_and_options(concat, new_cc_inacts, axis=-1)
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
        old_outact = concat.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        return builder.build()

    @pattern
    def rank5_batch_concat(self, op: Operator, **kwargs):
        if op.layertype == LayerType.Concatenate and op.options.axis == 0:
            pre_patterns = []
            for inact in op.inacts:
                if inact.src_shape[:2] != (1, 1):
                    return None
                pop = inact.producer_op
                # (1,160,160,64)->(1,64,160,160)->(1,1,64,160,160)
                pat = find_operator_sequence(pop, "T0312 R[1hwc->11hwc]")
                if pat is not None:
                    pre_patterns.append(pat)
                else:
                    # (1,160,160,64)->(1,160,160,1,64)->(1,1,64,160,160)
                    pat = find_operator_sequence(pop, "R[1hwc->1hw1c] T03412")
                    if pat is None:
                        return None
                    pre_patterns.append(pat)
            if len(pre_patterns) == len(op.options.inputs):
                return pre_patterns, op
        return None

    @rank5_batch_concat.transform
    def rank5_batch_concat(self, *args, **kwargs):
        pre_patterns, concat = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = []
        for op0, op1 in pre_patterns:
            inact = op0.inacts[0]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            n, h, w, c = new_inact.src_shape
            new_inact = builder.make_reshape(new_inact, (n, 1, h, w, c))
            new_inacts.append(new_inact)
        new_outact = builder.make_concatenate(new_inacts, axis=1)
        new_outact = builder.make_transpose(new_outact, (0, 1, 4, 2, 3))
        old_outact = concat.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)

        for op0, op1 in pre_patterns:
            builder.remove_connectivity_and_invalidate(op0, op1, concat)
        return builder.build()


@DataFlowRuleSet.register
class ConcatenateReshapeTranspose(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        (1,56,56,64)-[concat]->(1,56,d*56,64)-[reshape]->(1,56,d,56,64)-[transpose]->(1,d,64,56,56)
        """
        pat = find_operator_sequence(op, LayerType.Concatenate, "R T")
        if pat is None:
            return None
        concat, reshape, transpose = pat
        input_stride = False
        ax = concat.options.axis
        if ax == 3 or ax == -1:
            return None
        ref_shape = concat.inacts[0].src_shape
        reshape_outact = reshape.outacts[0]
        expected_shape = ref_shape[:ax] + (len(concat.options.inputs),) + ref_shape[ax:]
        if reshape_outact.src_shape != expected_shape:
            return None
        for inact in concat.inacts:
            if not input_stride:
                input_stride = check_input_npu_stride(inact.producer_op)
            if ref_shape != inact.src_shape:
                return None
        if input_stride:
            return concat, reshape, transpose
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        concat, reshape, _ = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = []
        for inact in concat.inacts:
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(concat, new_inacts, axis=-1)
        reshape_outact = reshape.outacts[0]
        n, h, d, w, c = reshape_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, h, w, d, c))
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2, 4))
        old_outact = reshape_outact
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(concat, reshape)
        return builder.build()


@DataFlowRuleSet.register
class ConcatenateTranspose(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.Concatenate, "T0231")
        if pat is None:
            return None
        concat, transpose = pat
        for inact in concat.inacts:
            pop = inact.producer_op
            if is_transpose(pop, (0, 3, 1, 2)):
                return concat, transpose
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        concat, transpose = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = []
        remove_trans = []
        for inact in concat.inacts:
            if is_transpose(inact.producer_op, (0, 3, 1, 2)):
                pre_transpose = inact.producer_op
                transpose_inact = pre_transpose.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                new_inacts.append(new_inact)
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_transpose(new_inact, (0, 2, 3, 1))
                new_inacts.append(new_inact)

        axis = concat.options.axis
        if axis < 0:
            axis += 4
        new_concat_axis = [0, 3, 1, 2][axis]
        new_outact = builder.make_concatenate(new_inacts, axis=new_concat_axis)
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(concat, transpose)
        for trans in remove_trans:
            builder.remove_connectivity_and_invalidate(trans, concat)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.Concatenate, "T0132 C")
        if pat is None:
            return None
        concat, trans_post, conv = pat
        pre_cnt = 0
        all_in_cnt = 0
        for inact in concat.inacts:
            all_in_cnt += 1
            if is_transpose(inact.producer_op, (0, 1, 3, 2)):
                pre_cnt += 1
            pat = find_operator_sequence(
                inact.producer_op, LayerType.Input, "R", strict_search=True
            )
            if pat is not None:
                pre_cnt += 1

        if pre_cnt < all_in_cnt // 2:
            return None
        post_cnt = 0
        all_out_cnt = 0
        cc_outact = trans_post.outacts[0]
        for cop in cc_outact.consumer_ops:
            if not cop.valid:
                continue
            all_out_cnt += 1
            if is_transpose(cop, (0, 1, 3, 2)):
                post_cnt += 1
            elif cop.layertype == LayerType.Slice:
                slice_outact = cop.outacts[0]
                for slice_cop in slice_outact.consumer_ops:
                    if is_transpose(slice_cop, (0, 1, 3, 2)):
                        post_cnt += 1
                        break
        if pre_cnt + post_cnt >= (all_in_cnt + all_out_cnt) // 2:
            return concat, trans_post, conv
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        concat, trans_post, conv = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = []
        for inact in concat.inacts:
            if is_transpose(inact.producer_op, (0, 1, 3, 2)):
                pre_trans = inact.producer_op
                trans_inact = pre_trans.inacts[0]
                new_inact = builder.copy_activationspec(trans_inact, add_input_map=True)
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_transpose(new_inact, (0, 1, 3, 2))
            new_inacts.append(new_inact)
        new_axis = (0, 1, 3, 2)[concat.options.axis]
        new_output = builder.make_concatenate(new_inacts, axis=new_axis)
        new_output = builder.make_transpose(new_output, (0, 1, 3, 2))
        old_outact = concat.outacts[0]
        builder.add_output_map(new_output, old_outact)
        builder.remove_connectivity_and_invalidate(concat)
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        """
        (1,1,156,256)-[concat]->(1,d,156,256)-[transpose2013]->(156,1,d,256)
        """
        pat = find_operator_sequence(op, LayerType.Concatenate, "T2013")
        if pat is None:
            return None
        concat, transpose = pat
        if concat.options.axis != 1:
            return None
        stride_check = False
        for inact in concat.inacts:
            if any(x.dynamic or x != 1 for x in inact.src_shape[:2]):
                return None
            if not stride_check:
                stride_check = check_input_npu_stride(inact.producer_op)
        if not stride_check:
            return None
        return concat, transpose

    @case2.transform
    def case2(self, *args, **kwargs):
        concat, transpose = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = []
        for inact in concat.inacts:
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(concat, new_inacts, axis=-1)
        d = len(concat.options.inputs)
        n, h, w, c = new_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (1, h, w, d, c // d))
        old_outact = transpose.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(concat, transpose)
        return builder.build()

    @pattern
    def case3(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.Concatenate, "T0132")
        if pat is None:
            return None
        concat, trans_post = pat
        if concat.options.axis not in (3, -1):
            return None
        pre_reshapes = []
        for inact in concat.inacts:
            pat = find_operator_sequence(
                inact.producer_op, "C R[1hw1->11hw]", strict_search=True
            )
            if pat is None:
                return None
            conv, reshape = pat
            reshape_inact = reshape.inacts[0]
            n, h, w, c = reshape_inact.src_shape
            if not (h > 1 and w > 1 and c == 1):
                return None
            pre_reshapes.append(reshape)
        return pre_reshapes, concat

    @case3.transform
    def case3(self, *args, **kwargs):
        pre_reshapes, concat = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = []
        for reshape in pre_reshapes:
            inact = reshape.inacts[0]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inacts.append(new_inact)
        new_outact = builder.make_concatenate(new_inacts, axis=2)
        n, h, w, c = new_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, 1, h, w))
        old_outact = concat.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        for reshape in pre_reshapes:
            builder.remove_connectivity_and_invalidate(reshape, concat)
        return builder.build()
    
    @pattern
    def case4(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.Concatenate, "T0132")
        if pat is None:
            return None
        concat, trans_post = pat
        if concat.options.axis not in (3, -1):
            return None
        pre_reshapes = []
        for inact in concat.inacts:
            if len(inact.consumer_ops)!=1:
                return None 
            pat = find_operator_sequence(
                inact.producer_op, "R[1hw1->111(hw)]"
            )
            if pat is None:
                return None
            reshape = pat[0]
            reshape_inact = reshape.inacts[0]
            n, h, w, c = reshape_inact.src_shape
            if not (h > 1 and w > 1 and c == 1):
                return None
            pre_reshapes.append(reshape)
        return pre_reshapes, concat, trans_post

    @case4.transform
    def case4(self, *args, **kwargs):
        pre_reshapes, concat, trans_post = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = []
        for reshape in pre_reshapes:
            inact = reshape.inacts[0]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inact = builder.make_reshape(new_inact, (1, 1, -1, 1))
            new_inacts.append(new_inact)
        new_outact = builder.make_concatenate(new_inacts, axis=2)
        old_outact = trans_post.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        for reshape in pre_reshapes:
            builder.remove_connectivity_and_invalidate(reshape, concat)
        builder.remove_connectivity_and_invalidate(concat, trans_post)
        return builder.build()

#
# @DataFlowRuleSet.register
# class ConcatenateRank5(TransformRule):
#     @pattern
#     def rank5_with_inputconst(self, op: Operator, **kwargs):
#         if not (
#             op.layertype == LayerType.Concatenate
#             and op.options.axis in (-1, 4)
#             and 2 == len(op.options.inputs)
#         ):
#             return None
#         concat = op
#         inact0 = concat.inacts[0]
#         inact1 = concat.inacts[1]
#         if not (
#             inact1.src_dim == 5
#             and inact1.producer_op.layertype == LayerType.InputConstant
#         ):
#             return None
#         pat = find_operator_sequence(
#             inact0.producer_op,
#             "R[1hwc->11(hw)c] T0321 R[1c(hw)1->1chw1]",
#             strict_search=True,
#         )
#         if pat is not None:
#             return concat
#         return None
#
#     @rank5_with_inputconst.transform
#     def rank5_with_inputconst(self, *args, **kwargs):
#         concat = self.matched_pattern
#         builder = OpTransformResultV2Builder()
#         inact0 = concat.inacts[0]
#         inact1 = concat.inacts[1]
#         new_inact0 = builder.copy_activationspec(inact0, add_input_map=True)
#         n, c, h, w, d = new_inact0.src_shape
#         new_inact0 = builder.make_reshape(new_inact0, (n, c, -1, d))
#
#         iconst = inact1.producer_op
#         const_val = iconst.get_tensor(iconst.options.constant).value
#
#         n, c, h, w, d = map(int, inact1.src_shape)
#         new_const_val = const_val.reshape( (n, c, h * w, d))
#         new_inact1 = builder.make_inputconst(new_const_val)
#
#         new_outact = builder.with_new_input_and_options(
#             concat, [new_inact0, new_inact1], axis=-1
#         )
#         old_outact = concat.outacts[0]
#         if old_outact.src_shape != new_outact.src_shape:
#             new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
#         builder.add_output_map(new_outact, old_outact)
#         builder.remove_connectivity_and_invalidate(concat)
#         return builder.build()
