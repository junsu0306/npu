import numpy

from mblt.core import TransformRule, pattern, Operator, LayerType
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    is_reduce,
    check_input_npu_stride,
)
from mblt.subgraph.util.reshape_check import reshape_check
from mblt.transform.transform_result import (
    OpTransformResultV2Builder,
)
from ._ruleset import DataFlowRuleSet


def is_headerview(transpose):
    if transpose.options.transpose_axes == (0, 2, 1, 3):
        reshape = transpose.inacts[0].producer_op
        if reshape is not None and reshape.layertype == LayerType.Reshape:
            return reshape_check(
                "11(hw)c->1hwc",
                reshape.inacts[0].src_shape,
                reshape.outacts[0].src_shape,
            ) or reshape_check(
                "1hw(nc)->1(hw)nc",
                reshape.inacts[0].src_shape,
                reshape.outacts[0].src_shape,
            )

    if transpose.options.transpose_axes == (0, 3, 1, 2, 4):
        reshape = transpose.inacts[0].producer_op
        if reshape is not None and reshape.layertype == LayerType.Reshape:
            return reshape_check(
                "1hw(nc)->1hwnc",
                reshape.inacts[0].src_shape,
                reshape.outacts[0].src_shape,
            )
    return False


@DataFlowRuleSet.register
class TransposeReduce(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T", is_reduce)
        if pat is None:
            return None
        transpose, reduce = pat
        if is_headerview(transpose):
            return None
        return transpose, reduce

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reduce = self.matched_pattern
        new_axes = [
            transpose.options.transpose_axes[ax] for ax in reduce.options.reduce_axes
        ]
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(
            reduce, new_inact, reduce_axes=new_axes, keep_dims=True
        )
        new_outact = builder.make_transpose(
            new_outact, transpose.options.transpose_axes
        )
        old_outact = reduce.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reduce)
        return builder.build()


@DataFlowRuleSet.register
class ReduceSum(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.Concatenate, "R[1hw(bc)->1(hw)bc]", LayerType.ReduceSum
        )
        if pat is None:
            return None

        concat, reshape, reduce = pat
        if concat.options.axis not in (3, -1):
            return None
        reshape_outact = reshape.outacts[0]
        n, hw, b, c = reshape_outact.src_shape
        if b == 1:
            return None
        if not (
            op.layertype == LayerType.ReduceSum
            and op.options.reduce_axes == (2,)
            and op.options.keep_dims
        ):
            return None
        if len(concat.options.inputs) == int(b) and (
            all(c == inact.src_shape[-1] for inact in concat.inacts)
        ):
            return reshape, reduce
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, reduce = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)

        reshape_outact = reshape.outacts[0]
        n, hw, b, c = map(int, reshape_outact.src_shape)

        new_inacts = []
        acc = 0
        for i in range(b):
            slice_outact = builder.make_slice(
                new_inact, axis=(-1,), start=(acc,), end=(acc + c,)
            )
            new_inacts.append(slice_outact)
            acc += c
        new_outact = new_inacts[0]
        for iact in new_inacts[1:]:
            new_outact = builder.make_add(new_outact, iact)
        old_outact = reduce.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, reduce)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.ReduceSum, "T0213")
        if pat is None:
            return None
        reduce, transpose = pat
        if not (reduce.options.reduce_axes == (2,) and reduce.options.keep_dims):
            return None
        reduce_inact = reduce.inacts[0]
        n, h, w, c = reduce_inact.src_shape
        if h == 1 or any(x.dynamic for x in (n, h, w, c)):
            return None
        if w <= 32:
            return reduce, transpose
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reduce, transpose = self.matched_pattern
        reduce_inact = reduce.inacts[0]
        new_inact = builder.copy_activationspec(reduce_inact, add_input_map=True)
        n, h, w, c = new_inact.src_shape
        new_inact = builder.make_reshape(new_inact, (n, 1, -1, c))
        oc = ic = int(c)
        group_number = ic
        h_kernel = h_stride = 1
        w_kernel = w_stride = int(w)

        weight = numpy.zeros(
            (oc, ic // group_number, h_kernel, w_kernel), dtype="float32"
        )
        weight[:, 0, 0, :] = 1.0

        new_outact = builder.make_conv2d(
            new_inact,
            out_channels=oc,
            in_channels=ic,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            h_stride=h_stride,
            w_stride=w_stride,
            group_number=group_number,
            weight=weight,
        )
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reduce, transpose)
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.Concatenate, "R[1hw(bc)->1hwbc]", LayerType.ReduceSum
        )
        if pat is None:
            return None
        concat, reshape, reduce = pat
        if concat.options.axis not in (3, -1):
            return None
        reshape_outact = reshape.outacts[0]
        n, h, w, b, c = reshape_outact.src_shape
        if b == 1:
            return None
        if not (
            op.layertype == LayerType.ReduceSum
            and op.options.reduce_axes == (3,)
            and op.options.keep_dims
        ):
            return None
        if len(concat.options.inputs) == int(b) and (
            all(c == inact.src_shape[-1] for inact in concat.inacts)
        ):
            return reshape, reduce
        return None

    @case2.transform
    def case2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, reduce = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        n, h, w, b, c = map(int, reshape_outact.src_shape)
        new_inacts = []
        acc = 0
        for i in range(b):
            slice_outact = builder.make_slice(
                new_inact, axis=(-1,), start=(acc,), end=(acc + c,)
            )
            new_inacts.append(slice_outact)
            acc += c
        new_outact = new_inacts[0]
        for iact in new_inacts[1:]:
            new_outact = builder.make_add(new_outact, iact)
        old_outact = reduce.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, reduce)
        return builder.build()

    @pattern
    def case3(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.Concatenate, "R", LayerType.ReduceSum
        )
        if pat is None:
            return None
        concat, reshape, reduce = pat
        if 1 != len(reduce.options.reduce_axes):
            return None
        if not check_input_npu_stride(concat):
            return None
        reshape_inact = reshape.inacts[0]
        reshape_outact = reshape.outacts[0]
        if reshape_inact.src_dim + 1 != reshape_outact.src_dim:
            return None
        ax = int(reduce.options.reduce_axes[0])
        if ax < 0:
            ax += 4
        cc_axis = concat.options.axis
        if cc_axis < 0:
            cc_axis += 4
        if ax not in (1, 2, 3) or ax != cc_axis:  # ax=3, dim=4
            return None
        d, e = reshape_outact.src_shape[ax : ax + 2]
        if (
            reshape_inact.src_shape[:ax] == reshape_outact.src_shape[:ax]
            and reshape_inact.src_shape[ax] == d * e
            and reshape_inact.src_shape[ax + 1 :] == reshape_outact.src_shape[ax + 2 :]
        ):
            return concat, reshape, reduce
        return None

    @case3.transform
    def case3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        concat, reshape, reduce = self.matched_pattern
        new_inacts = []
        for inact in concat.inacts:
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inacts.append(new_inact)
        new_outact = new_inacts[0]
        for iact in new_inacts[1:]:
            new_outact = builder.make_add(new_outact, iact)
        old_outact = reduce.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(concat, reshape, reduce)
        return builder.build()

    @pattern
    def case4(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op,
            LayerType.Multiply,
            "R[1hw(bc)->1(hw)bc]",
            LayerType.ReduceSum,
            strict_search=True,
        )
        if pat is None:
            return None

        mul, reshape, reduce = pat
        reshape_outact = reshape.outacts[0]
        n, hw, b, c = reshape_outact.src_shape
        if b == 1:
            return None
        if b > 8:
            return None
        if not (
            op.layertype == LayerType.ReduceSum
            and op.options.reduce_axes == (2,)
            and op.options.keep_dims
        ):
            return None
        if all(b * c == inact.src_shape[-1] for inact in mul.inacts):
            return reshape, reduce
        return None

    @case4.transform
    def case4(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, reduce = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)

        reshape_outact = reshape.outacts[0]
        n, hw, b, c = map(int, reshape_outact.src_shape)

        new_inacts = []
        acc = 0
        for i in range(b):
            slice_outact = builder.make_slice(
                new_inact, axis=(-1,), start=(acc,), end=(acc + c,)
            )
            new_inacts.append(slice_outact)
            acc += c
        new_outact = new_inacts[0]
        for iact in new_inacts[1:]:
            new_outact = builder.make_add(new_outact, iact)
        old_outact = reduce.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, reduce)
        return builder.build()
