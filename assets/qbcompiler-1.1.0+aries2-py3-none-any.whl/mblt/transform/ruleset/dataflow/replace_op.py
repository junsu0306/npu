import numpy

from mblt import LayerType
from mblt.core import pattern
from mblt.operator import Operator
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    is_reshape_with_expr,
)
from mblt.transform.graph_transform import TransformRule
from mblt.transform.transform_result import OpTransformResultV2Builder
from ._ruleset import DataFlowRuleSet


@DataFlowRuleSet.register
class Reshape(TransformRule):
    @pattern
    def transpose0132(self, op: Operator, **kwargs):
        if is_reshape_with_expr("11w1->111w")(op) or is_reshape_with_expr("111w->11w1")(
            op
        ):
            inact = op.inacts[0]
            n, h, w, c = inact.src_shape
            if not w.dynamic and not c.dynamic and (w > 1 or c > 1):
                return op
        return None

    @transpose0132.transform
    def transpose0132(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_inact, (0, 1, 3, 2))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape)
        return builder.build()


@DataFlowRuleSet.register
class AvgPool(TransformRule):
    @pattern
    def kernel11(self, op: Operator, **kwargs):
        if (
            op.layertype == LayerType.Pooling
            and op.options.pool_type.lower() == "avgpool"
            and op.options.h_kernel == op.options.w_kernel == 1
        ):
            return op
        return None

    @kernel11.transform
    def kernel11(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        avgpool = self.matched_pattern
        inact = avgpool.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)

        if avgpool.options.h_stride == 1 and avgpool.options.w_stride == 1:
            new_outact = builder.make_identity(new_inact)
        else:
            in_channels = int(inact.src_shape[-1])
            weight = numpy.ones((in_channels, 1, 1, 1), dtype="float32")
            new_outact = builder.make_depthwise_conv2d(
                new_inact,
                in_channels=in_channels,
                out_channels=in_channels,
                h_kernel=1,
                w_kernel=1,
                h_stride=avgpool.options.h_stride,
                w_stride=avgpool.options.w_stride,
                h_dilation=avgpool.options.h_dilation,
                w_dilation=avgpool.options.w_dilation,
                west_padding=avgpool.options.west_padding,
                east_padding=avgpool.options.east_padding,
                north_padding=avgpool.options.north_padding,
                south_padding=avgpool.options.south_padding,
                weight=weight,
            )
        outact = avgpool.outacts[0]
        builder.add_output_map(new_outact, outact)
        builder.remove_connectivity_and_invalidate(avgpool)
        return builder.build()


@DataFlowRuleSet.register
class GlobalAveragePoolingToAvgPool(TransformRule):
    @staticmethod
    def _get_4d_input_shape(inact):
        if any(dim.dynamic for dim in inact.src_shape):
            return None
        if inact.src_shape[0] != 1:
            return None

        if inact.src_dim == 2:
            n, c = inact.src_shape
            return (n, 1, 1, c)
        if inact.src_dim == 3:
            n, w, c = inact.src_shape
            return (n, 1, w, c)
        if inact.src_dim == 4:
            return inact.src_shape
        if inact.src_dim == 5:
            for axis in range(1, 4):
                if inact.src_shape[axis] == 1:
                    return tuple(
                        dim for idx, dim in enumerate(inact.src_shape) if idx != axis
                    )
            return None
        return None

    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype != LayerType.GlobalAveragePooling:
            return None
        if not op.options.channel_last:
            return None
        if self._get_4d_input_shape(op.inacts[0]) is None:
            return None
        return op

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        gap = self.matched_pattern
        inact = gap.inacts[0]
        outact = gap.outacts[0]

        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        target_shape = self._get_4d_input_shape(new_inact)
        if target_shape is None:
            raise NotImplementedError("global average pooling input is not lowerable")
        if new_inact.src_shape != target_shape:
            new_inact = builder.make_reshape(new_inact, target_shape)

        _, h, w, _ = new_inact.src_shape
        new_outact = builder.make_avgpool(
            new_inact,
            h_kernel=int(h),
            w_kernel=int(w),
            h_stride=1,
            w_stride=1,
            west_padding=0,
            east_padding=0,
            north_padding=0,
            south_padding=0,
            pad_mode="constant",
            h_dilation=1,
            w_dilation=1,
            padding_list=tuple(),
            is_ceil_mode=False,
            is_include_pad=False,
        )
        if new_outact.src_shape != outact.src_shape:
            new_outact = builder.make_reshape(new_outact, outact.src_shape)

        builder.add_output_map(new_outact, outact)
        builder.remove_connectivity_and_invalidate(gap)
        return builder.build()


@DataFlowRuleSet.register
class Where(TransformRule):
    @pattern
    def case_masked_fill(self, op: Operator, **kwargs):
        """
        if x is inputconst with size=1
        """
        pat = find_operator_sequence(op, LayerType.Where)
        if pat is None:
            return None
        where = pat[0]
        if 3 != len(where.options.inputs):
            return None
        cond, x, y = where.inacts
        if any(4 != a.src_dim or 1 != a.src_shape[0] for a in where.inacts):
            return None
        xconst = x.producer_op
        if xconst.layertype == LayerType.InputConstant:
            value = xconst.get_tensor(xconst.options.constant).value
            if (
                value.size == 1
                or value.size == 0
                or bool(numpy.all(value.reshape(-1)[0] == value))
            ):
                return where
        return None

    @case_masked_fill.transform
    def case0(self, op: Operator, **kwargs):
        builder = OpTransformResultV2Builder()
        where = self.matched_pattern
        cond, x, y = where.inacts
        new_inact = builder.copy_activationspec(y, add_input_map=True)
        mask_inact = builder.copy_activationspec(cond, add_input_map=True)
        mask_inact = builder.make_cast(mask_inact, dtype="int32")
        xconst = x.producer_op
        value = xconst.get_tensor(xconst.options.constant).value
        value = value.reshape(-1)[0]
        new_outact = builder.make_masked_fill(new_inact, mask_inact, value)
        old_outact = where.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(where)
        return builder.build()


@DataFlowRuleSet.register
class MultiplyToPow(TransformRule):
    """Expand a constant input to a pad operation."""

    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype == LayerType.Multiply:
            if op.options.inputs[0] == op.options.inputs[1]:
                return op
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        multiply = self.matched_pattern
        inact = multiply.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_pow(new_inact, 2)
        old_outact = multiply.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(multiply)
        return builder.build()


@DataFlowRuleSet.register
class Softmax(TransformRule):

    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        [conv]-(n,h,w,2c)-[reshape]->(n,hw,2,c)-[softmax axis=2]->(n,hw,2,c)
        ==========================================================
        [conv]-(n,h,w,c*2)-[reshape]->(...,2)-[softmax axis=-1]->(...,2)
        """
        pat = find_operator_sequence(op, "C R", LayerType.Softmax)
        if pat is None:
            return None
        conv, reshape, softmax = pat
        if conv.options.group_number != 1:
            return None
        ax = softmax.options.axis
        if ax >= 0:
            ax -= softmax.inacts[0].src_dim

        if ax not in (-2, -1):
            return None
        reshape_inact = reshape.inacts[0]
        reshape_outact = reshape.outacts[0]
        if reshape_outact.src_dim < 2:
            return None
        if reshape_outact.src_shape[ax] != 2 or reshape_outact.src_shape[ax].dynamic:
            return None
        if ax == -2:
            c, d = reshape_outact.src_shape[-2:]
            if reshape_inact.src_shape[-1] == c * d:
                return reshape, softmax
        if ax == -1:
            return reshape, softmax
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, softmax = self.matched_pattern
        softmax_inact = softmax.inacts[0]
        new_inact = builder.copy_activationspec(softmax_inact, add_input_map=True)
        ax = softmax.options.axis
        if ax >= 0:
            ax -= softmax_inact.src_dim
        reshape_inact = reshape.inacts[0]
        n, h, w, c = reshape_inact.src_shape
        if ax == -1:
            new_shape = (n, h * w, c // 2, 2)
        elif ax == -2:
            new_shape = (n, h * w, 2, c // 2)
        else:
            raise NotImplementedError("code should not reach here")
        if new_inact.src_shape != new_shape:
            new_inact = builder.make_reshape(new_inact, new_shape)
        a = builder.make_slice(new_inact, (ax,), start=(0,), end=(1,))
        b = builder.make_slice(new_inact, (ax,), start=(1,), end=(2,))
        sub_outact = builder.make_sub(a, b)
        sigmoid_outact = builder.make_sigmoid(sub_outact)
        one_sub_sigmoid_outact = builder.make_sub(1.0, sigmoid_outact)
        new_outact = builder.make_concatenate(
            [sigmoid_outact, one_sub_sigmoid_outact], axis=-1
        )
        old_outact = softmax.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(softmax)
        return builder.build()


@DataFlowRuleSet.register
class SubConstant(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        # x - const
        if op.layertype == LayerType.SubConstant and not op.options.is_const_first:
            return op
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        subconst = self.matched_pattern
        inact = subconst.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        value = subconst.get_tensor(subconst.options.constant).value
        new_outact = builder.make_add(new_inact, -value)
        old_outact = subconst.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(subconst)
        return builder.build()


@DataFlowRuleSet.register
class Convolution3D(TransformRule):
    # fmt: off
    axis_specs = (
        (1, "d", "d_kernel", "d_stride", "d_dilation", "front_padding", "back_padding"),
        (2, "h", "h_kernel", "h_stride", "h_dilation", "north_padding", "south_padding"),
        (3, "w", "w_kernel", "w_stride", "w_dilation", "west_padding", "east_padding"),
    )
    # fmt: on

    @staticmethod
    def _get_conv2d_kwargs(opt, axis: int):
        if axis == 1:
            # onnx의 3d conv에서는 미리 north/south padding을 뒤집지 않았음.
            return dict(
                h_kernel=opt.h_kernel,
                w_kernel=opt.w_kernel,
                h_stride=opt.h_stride,
                w_stride=opt.w_stride,
                h_dilation=opt.h_dilation,
                w_dilation=opt.w_dilation,
                north_padding=opt.south_padding,
                south_padding=opt.north_padding,
                west_padding=opt.west_padding,
                east_padding=opt.east_padding,
            )
        if axis == 2:
            return dict(
                h_kernel=opt.d_kernel,
                w_kernel=opt.w_kernel,
                h_stride=opt.d_stride,
                w_stride=opt.w_stride,
                h_dilation=opt.d_dilation,
                w_dilation=opt.w_dilation,
                north_padding=opt.back_padding,
                south_padding=opt.front_padding,
                west_padding=opt.west_padding,
                east_padding=opt.east_padding,
            )
        if axis == 3:
            return dict(
                h_kernel=opt.d_kernel,
                w_kernel=opt.h_kernel,
                h_stride=opt.d_stride,
                w_stride=opt.h_stride,
                h_dilation=opt.d_dilation,
                w_dilation=opt.h_dilation,
                north_padding=opt.back_padding,
                south_padding=opt.front_padding,
                west_padding=opt.north_padding,
                east_padding=opt.south_padding,
            )
        raise NotImplementedError(f"unsupported fold axis: {axis}")

    @pattern
    def to_conv2d(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Convolution3d:
            return None
        inact = op.inacts[0]
        opt = op.options
        if not (opt.channel_last and inact.src_shape[0] == 1):
            return None

        for axis, _, kernel, stride, dilation, pad_begin, pad_end in self.axis_specs:
            dim = inact.src_shape[axis]
            if (
                not dim.dynamic
                # and dim == 1
                and (
                    getattr(opt, kernel)
                    == getattr(opt, stride)
                    == getattr(opt, dilation)
                    == 1
                )
                and (getattr(opt, pad_begin) == getattr(opt, pad_end) == 0)
            ):
                return op, axis
        return None

    @to_conv2d.transform
    def to_conv2d(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        conv3d, axis = self.matched_pattern

        inact = conv3d.inacts[0]

        outact = conv3d.outacts[0]
        opt = conv3d.options

        dim = inact.src_shape[axis]
        weight = conv3d.get_tensor(conv3d.options.weight).value
        assert weight.shape[axis + 1] == 1
        weight = numpy.take(weight, 0, axis=axis + 1)  # (oc,ic,d,h,w)=>(oc,ic,h,w)
        if opt.bias != -1:
            bias = conv3d.get_tensor(conv3d.options.bias).value
        else:
            bias = None

        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        if dim == 1:
            new_shape = tuple(
                dim for i, dim in enumerate(new_inact.src_shape) if i != axis
            )
            new_outact = builder.make_reshape(new_inact, new_shape)
            new_outact = builder.make_conv2d(
                new_outact,
                in_channels=opt.in_channels,
                out_channels=opt.out_channels,
                padding_list=tuple(),
                group_number=opt.group_number,
                weight=weight,
                bias=bias,
                **self._get_conv2d_kwargs(opt, axis),
            )
        else:
            # n,d,h,w,c
            # n,w,d,h,c
            # axis=1, (0,1,2,3,4), (0,1,2,3,4)
            # axis=2, (0,2,1,3,4), (0,2,1,3,4)
            # axis=3, (0,3,1,2,4), (0,2,3,1,4)
            if axis == 2:
                t_axes = (0, 2, 1, 3, 4)
            elif axis == 3:
                t_axes = (0, 3, 1, 2, 4)
            else:
                t_axes = None

            if t_axes is not None:
                new_inact = builder.make_transpose(new_inact, t_axes)

            n, x, h, w, c = new_inact.src_shape
            new_outact = builder.make_reshape(new_inact, (n * x, h, w, c))

            new_outact = builder.make_conv2d(
                new_outact,
                in_channels=opt.in_channels,
                out_channels=opt.out_channels,
                padding_list=tuple(),
                group_number=opt.group_number,
                weight=weight,
                bias=bias,
                **self._get_conv2d_kwargs(opt, axis),
            )

            b, h, w, c = new_outact.src_shape
            new_outact = builder.make_reshape(new_outact, (n, x, h, w, c))
            if t_axes is not None:
                rev_axes = tuple(sorted(range(len(t_axes)), key=lambda i: t_axes[i]))
                new_outact = builder.make_transpose(new_outact, rev_axes)

        if new_outact.src_shape != outact.src_shape:
            new_outact = builder.make_reshape(new_outact, outact.src_shape)
        builder.add_output_map(new_outact, outact)
        builder.remove_connectivity_and_invalidate(conv3d)
        return builder.build()
