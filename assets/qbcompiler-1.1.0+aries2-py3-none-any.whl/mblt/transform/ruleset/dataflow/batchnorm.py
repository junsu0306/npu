import numpy

from mblt.core import TransformRule, pattern, Operator, LayerType
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    is_conv_type,
)
from mblt.transform.transform_result import (
    OpTransformResultV2Builder,
)
from ._ruleset import BatchnormRuleSet


@BatchnormRuleSet.register
class ConvolutionBatchnorm(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, is_conv_type, LayerType.Batchnorm, strict_search=True
        )
        if pat is None:
            return None
        conv, batchnorm = pat
        return conv, batchnorm

    @case0.transform
    def batchnorm(self, *args, **kwargs):
        conv, batchnorm = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = conv.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        weight = conv.get_tensor(conv.options.weight).value

        gamma = batchnorm.get_tensor(batchnorm.options.gamma).value
        beta = batchnorm.get_tensor(batchnorm.options.beta).value
        moving_mean = batchnorm.get_tensor(batchnorm.options.moving_mean).value
        moving_var = batchnorm.get_tensor(batchnorm.options.moving_var).value
        epsilon = batchnorm.get_tensor(batchnorm.options.epsilon).value

        alpha = gamma / numpy.sqrt(moving_var + epsilon)  # (Cout,)
        new_weight = weight * alpha[:, None, None, None]
        if conv.options.bias != -1:
            bias = conv.get_tensor(conv.options.bias).value
        else:
            bias = 0
        new_conv_bias = beta + (bias - moving_mean) * alpha

        new_outact = builder.with_new_input_and_options(
            conv, new_inact, weight=new_weight, bias=new_conv_bias
        )
        old_outact = batchnorm.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(conv, batchnorm)

        return builder.build()


@BatchnormRuleSet.register
class BatchnormToAffine(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.valid and op.layertype == LayerType.Batchnorm:
            return op
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        batchnorm = self.matched_pattern
        builder = OpTransformResultV2Builder()
        bn_inact = batchnorm.inacts[0]
        new_inact = builder.copy_activationspec(bn_inact, add_input_map=True)
        gamma = batchnorm.get_tensor(batchnorm.options.gamma).value
        beta = batchnorm.get_tensor(batchnorm.options.beta).value
        moving_mean = batchnorm.get_tensor(batchnorm.options.moving_mean).value
        moving_var = batchnorm.get_tensor(batchnorm.options.moving_var).value
        epsilon = batchnorm.get_tensor(batchnorm.options.epsilon).value

        mul_const = gamma / numpy.sqrt(moving_var + epsilon)
        add_const = beta - moving_mean * mul_const
        new_outact = builder.make_mul(new_inact, mul_const)
        new_outact = builder.make_add(new_outact, add_const)
        old_outact = batchnorm.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(batchnorm)

        return builder.build()


@BatchnormRuleSet.register
class ConcatenateBatchnorm(TransformRule):

    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.Concatenate, LayerType.Batchnorm, strict_search=True
        )
        if pat is None:
            return None
        concat, batchnorm = pat
        if concat.options.axis not in (3, -1):
            return None
        # fixme: ruduced ops count 기준으로 수정.
        if all(
            (
                inact.producer_op.valid
                and is_conv_type(inact.producer_op)
                and 1 == len(inact.consumer_ops)
            )
            for inact in concat.inacts
        ):
            return concat, batchnorm
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        concat, batchnorm = self.matched_pattern
        if batchnorm.options.gamma != -1:
            gamma = batchnorm.get_tensor(batchnorm.options.gamma).value
        else:
            raise ValueError("Batchnorm gamma tensor not found")
        if batchnorm.options.beta != -1:
            beta = batchnorm.get_tensor(batchnorm.options.beta).value
        else:
            raise ValueError("Batchnorm beta tensor not found")
        if batchnorm.options.epsilon != -1:
            epsilon = batchnorm.get_tensor(batchnorm.options.epsilon).value
        else:
            raise ValueError("Batchnorm epsilon tensor not found")
        if batchnorm.options.moving_mean != -1:
            moving_mean = batchnorm.get_tensor(batchnorm.options.moving_mean).value
        else:
            raise ValueError("Batchnorm moving_mean tensor not found")
        if batchnorm.options.moving_var != -1:
            moving_var = batchnorm.get_tensor(batchnorm.options.moving_var).value
        else:
            raise ValueError("Batchnorm moving_var tensor not found")

        builder = OpTransformResultV2Builder()
        acc = 0
        new_inacts = []
        for inact in concat.inacts:
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            csize = int(new_inact.src_shape[-1])
            new_outact = builder.make_batchnorm(
                new_inact,
                gamma=gamma[acc : acc + csize],
                beta=beta[acc : acc + csize],
                moving_mean=moving_mean[acc : acc + csize],
                moving_var=moving_var[acc : acc + csize],
                epsilon=epsilon,
            )
            new_inacts.append(new_outact)
            acc += csize
        new_outact = builder.with_new_input_and_options(concat, new_inacts)
        old_outact = batchnorm.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(concat, batchnorm)
        return builder.build()
