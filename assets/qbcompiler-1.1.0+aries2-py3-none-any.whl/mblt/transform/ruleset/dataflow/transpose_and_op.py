import functools
import math
import operator

import numpy

from mblt import LayerType
from mblt.core import pattern
from mblt.operator import Operator, ACTIVATION_FUNCTIONS
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    is_actfunc_type,
    check_input_npu_stride,
    is_basic_npu_op,
    check_output_npu_stride,
    is_transpose,
    is_biop_wrapper,
    is_biop_const,
)
from mblt.subgraph.util.reshape_check import reshape_check
from mblt.transform.graph_transform import TransformRule
from mblt.transform.transform_result import OpTransformResultV2Builder
from ._ruleset import DataFlowRuleSet


@DataFlowRuleSet.register
class TransposeReshape(TransformRule):

    @pattern
    def case0(self, op: Operator, **kwargs):
        """channel split.
        [conv2d]-[transpose0312]->(1,255,19,19)-[reshape]->(...,19,19)
        we reorder [conv2d]-reshape-transpose
        """
        pat = find_operator_sequence(op, "T0312R")
        if pat is None:
            return None
        transpose, reshape = pat
        reshape_inact = reshape.inacts[0]
        reshape_outact = reshape.outacts[0]
        if not (
            reshape_outact.src_dim > 3
            and reshape_inact.src_shape[-2:] == reshape_outact.src_shape[-2:]
            and reshape_inact.src_shape[0] == reshape_outact.src_shape[0]
            and reshape_inact.src_shape[1]
            == math.prod(map(int, reshape_outact.src_shape[1:-2]))
        ):
            return None
        curr_op = transpose.inacts[0].producer_op
        if check_input_npu_stride(curr_op):
            return transpose, reshape
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        reshape_outact = reshape.outacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        new_shape = reshape_outact.src_shape
        new_shape = (new_shape[0],) + new_shape[-2:] + new_shape[1:-2]
        new_outact = builder.make_reshape(new_outact, new_shape)
        transpose_axes = (0,) + tuple(range(3, reshape_outact.src_dim)) + (1, 2)
        new_outact = builder.make_transpose(new_outact, transpose_axes)
        builder.add_output_map(new_outact, reshape_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T0312 R[nhwc->nh(wc)]")
        if pat is None:
            return None
        return pat

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)

        reshape_outact = reshape.outacts[0]
        n, c, hw = reshape_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, 1, hw, c))
        new_outact = builder.make_reshape(new_outact, (n, hw, c))
        new_outact = builder.make_transpose(new_outact, (0, 2, 1))
        builder.add_output_map(new_outact, reshape_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        """channel split. # we may generalize this case for reshape.
        (1,1,3136,128)->[transpose0132]->(1,1,128,3136)-[reshape]->(1,128,56,56)
        =>
        (1,1,3136,128)->[reshape]->(1,56,56,128)-[transpose0312]->(1,128,56,56)
        """
        pat = find_operator_sequence(op, "T0132 R[n1c(hw)->nchw]")
        if pat is None:
            return None
        transpose, reshape = pat
        return transpose, reshape

    @case2.transform
    def case2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        n, c, h, w = reshape_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, h, w, c))
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case3(self, op: Operator, **kwargs):
        """
        (1,56,56,128)->[transpose0312]->(1,128,56,56)-[reshape]->(1,1,128,3136)
        =>
        (1,56,56,128)->[reshape]->(1,1,3136,128)-[transpose0132]->(1,1,128,3136)
        """
        pat = find_operator_sequence(op, "T0312 R[nchw->n1c(hw)]")
        if pat is None:
            return None
        transpose, reshape = pat
        return transpose, reshape

    @case3.transform
    def case3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_inact = reshape.inacts[0]
        n, c, h, w = reshape_inact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, 1, h * w, c))
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case4(self, op: Operator, **kwargs):
        """channel split. # we may generalize this case for reshape.
        (1,28,28,256)-[transpose0312]->(1,256,28,28)-[reshape]->(1,8,32,784)
        =>
        (1,28,28,256)-[reshape]->(1,1,784,256)-[reshape]->(1,784,8,32)-[transpose0231]->(1,8,32,784)
        """
        pat = find_operator_sequence(op, "T0312 R[n(cd)hw->ncd(hw)]")
        if pat is None:
            return None
        transpose, reshape = pat
        stride_check = check_input_npu_stride(transpose.inacts[0].producer_op)
        if stride_check:
            return transpose, reshape
        return None

    @case4.transform
    def case4(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        n, cd, h, w = reshape.inacts[0].src_shape
        n, c, d, hw = reshape.outacts[0].src_shape
        new_outact = builder.make_reshape(new_outact, (n, 1, hw, cd))
        new_outact = builder.make_reshape(new_outact, (n, hw, c, d))
        new_outact = builder.make_transpose(new_outact, (0, 2, 3, 1))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case5(self, op: Operator, **kwargs):
        """channel split. # we may generalize this case for reshape.
        (1,1,h,wc)-[transpose0213]->(1,h,1,wc)-[reshape]->(1,h,w,c)
        =>
        (1,1,h,wc)-[reshape]->(1,h,w,c)
        """
        pat = find_operator_sequence(op, "T0213 R[bh1(nc)->bhnc]")
        if pat is None:
            return None
        transpose, reshape = pat
        return transpose, reshape

    @case5.transform
    def case5(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        n, h, e, nc = reshape.inacts[0].src_shape
        assert e == 1
        n, h, w, c = reshape.outacts[0].src_shape
        new_outact = builder.make_reshape(new_outact, (n, h, w, c))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case6(self, op: Operator, **kwargs):
        target_patterns = [
            "T0312 R[1h11->1h]",
            "T0321 R[1h11->1h]",
        ]
        for target_pattern in target_patterns:
            pat = find_operator_sequence(op, target_pattern)
            if pat is not None:
                return pat
        return None

    @case6.transform
    def case6(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        old_outact = reshape.outacts[0]
        new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case7(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T0132 R[11(hc)w->1hcw]")
        if pat is None:
            return None
        transpose, reshape = pat
        reshape_outact = reshape.outacts[0]
        n, h, c, w = reshape_outact.src_shape
        if h > 1 and c > 1:
            return transpose, reshape
        return None

    @case7.transform
    def case7(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        n, h, c, w = reshape_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, w, h, c))
        new_outact = builder.make_transpose(new_outact, (0, 2, 3, 1))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case8(self, op: Operator, **kwargs):
        """
        (1,112,112,64)->[transpose0312]->(1,64,112,112)-[reshape]->(1,1,32,25088)-[transpose0132]->(1,1,25088,32)
        =>
        (1,112,112,64)->[reshape]->(1,112*112,32,2)-[transpose0312]->(1,2,12544,32)-[reshape]->(1,1,25088,32)
        """
        pat = find_operator_sequence(op, "T0312 R[1(cd)hw->11c(dhw)] T0132")
        if pat is None:
            return None
        t0312, reshape, t0132 = pat
        reshape_inact = reshape.inacts[0]
        reshape_outact = reshape.outacts[0]
        if not (reshape_inact.src_shape[1] > reshape_outact.src_shape[2]):
            return None
        return t0312, reshape, t0132

    @case8.transform
    def case8(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        t0312, reshape, t0132 = self.matched_pattern
        inact = t0312.inacts[0]
        n, h, w, c = inact.src_shape
        old_outact = t0132.outacts[0]
        n, b, dhw, c_out = old_outact.src_shape
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_reshape(inact, (n, -1, c_out, c // c_out))
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        new_outact = builder.make_reshape(new_outact, (n, b, dhw, c_out))
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(t0312, reshape, t0132)
        return builder.build()

    @pattern
    def case9(self, op: Operator, **kwargs):
        """
        (1,1,25088,32)->[transpose0132]->(1,1,32,25088)-[reshape]->(1,64,112,122)-[transpose0231]->(1,112,112,64)
        =>
        (1,1,25088,32)->[reshape]->(1,2,12544,32)-[transpose0231]->(1,12544,32,2)-[reshape]->(1,112,112,64)
        """
        pat = find_operator_sequence(op, "T0132 R[11c(bhw)->1(cb)hw] T0231")
        if pat is None:
            return None
        t0132, reshape, t0231 = pat
        reshape_inact = reshape.inacts[0]
        reshape_outact = reshape.outacts[0]
        if not (reshape_inact.src_shape[2] < reshape_outact.src_shape[1]):
            return None
        return t0132, reshape, t0231

    @case9.transform
    def case9(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        t0132, reshape, t0231 = self.matched_pattern
        inact = t0132.inacts[0]
        old_outact = t0231.outacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        c_in = inact.src_shape[-1]
        c_out = old_outact.src_shape[-1]
        n_div = int(c_out // c_in)
        new_outact = builder.make_reshape(new_inact, (1, n_div, -1, c_in))
        new_outact = builder.make_transpose(new_outact, (0, 2, 3, 1))
        new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(t0132, reshape, t0231)
        return builder.build()

    @pattern
    def case10(self, op: Operator, **kwargs):
        """
        [matmul]->(1,8,49,128)-[transpose0132]->(1,8,128,49)-[reshape]->(1,1024,7,7)
        =>
        [matmul]->(1,8,49,128)-[transpose0213]->(1,49,8,128)-[reshape]->(1,7,7,1024)-[transpose0312]->(1,1024,7,7)
        """
        pat = find_operator_sequence(op, LayerType.MatMul, "T0132 R[1bc(hw)->1(bc)hw]")
        if pat is None:
            return None
        matmul, t0132, reshape = pat
        return t0132, reshape

    @case10.transform
    def case10(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        t0132, reshape = self.matched_pattern
        inact = t0132.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        n, c, h, w = reshape_outact.src_shape
        new_outact = builder.make_transpose(new_inact, (0, 2, 1, 3))
        new_outact = builder.make_reshape(new_outact, (n, h, w, c))
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(t0132, reshape)
        return builder.build()

    @pattern
    def case11(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T0312 R[1c(xy)(zt)->1cxyzt]")
        if pat is None:
            return None
        transpose, reshape = pat
        return transpose, reshape

    @case11.transform
    def case11(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        b, c, x, y, z, t = reshape_outact.src_shape
        new_outact = builder.make_reshape(new_inact, (b, x, y, z, t, c))
        new_outact = builder.make_transpose(new_outact, (0, 5, 1, 2, 3, 4))
        builder.add_output_map(new_outact, reshape.outacts[0])
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case12(self, op: Operator, **kwargs):
        """
        (1,76,76,3)-[transpose0312]->(1,3,76,76)-[reshape]->(1,1,17328,1)
        =>
        (1,76,76,3)-[reshape]->(1,5776,3,1)-[transpose0213]->(1,3,5776,1)-[reshape]->(1,1,17328,1)
        """
        pat = find_operator_sequence(op, "T0312 R[1chw->11(chw)1]")
        if pat is None:
            return None
        transpose, reshape = pat
        transpose_inact = transpose.inacts[0]
        if check_input_npu_stride(transpose_inact.producer_op):
            return transpose, reshape
        return None

    @case12.transform
    def case12(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        n, h, w, c = inact.src_shape
        new_outact = builder.make_reshape(new_inact, (1, -1, c, 1))
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = reshape.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case13(self, op: Operator, **kwargs):
        """
        (1,1,49,256)-[transpose2301]->(49,256,1,1)-[reshape]
        =>
        (1,1,49,256)-[reshape]
        """
        pat = find_operator_sequence(op, "T2301 R")
        if pat is None:
            return None
        transpose, reshape = pat
        transpose_inact = transpose.inacts[0]
        if transpose_inact.src_shape[:2] == (1, 1):
            return transpose, reshape
        return None

    @case13.transform
    def case13(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        old_outact = reshape.outacts[0]
        new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case14(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T0231 R[1hw1->1hw11]")
        if pat is None:
            return None
        transpose, reshape = pat
        pop = transpose.inacts[0].producer_op
        return transpose, reshape

    @case14.transform
    def case14(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        n, h, w, c = inact.src_shape
        new_outact = builder.make_reshape(new_outact, (1, 1, 1, w, c))
        new_outact = builder.make_transpose(new_outact, (0, 3, 4, 1, 2))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case15(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T0312 R[1ch(dw)->1chdw]")
        if pat is None:
            return None
        transpose, reshape = pat
        pop = transpose.inacts[0].producer_op
        if check_input_npu_stride(pop):
            return transpose, reshape
        return None

    @case15.transform
    def case15(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        n, c, h, d, w = reshape_outact.src_shape
        new_outact = builder.make_reshape(new_inact, (n, h, d, w, c))
        new_outact = builder.make_transpose(new_outact, (0, 4, 1, 2, 3))
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()

    @pattern
    def case16(self, op: Operator, **kwargs):
        """
        (1,12,197,64)-[transpose axes 2013]-(197,1,12,64)->(1,1,197,768)
        =>
        (1,12,197,64)-[transpose axes 0213]-(1,197,12,64)->(1,1,197,768)
        """
        pat = find_operator_sequence(op, "T2013 R[w1cd->11w(cd)]")
        if pat is None:
            return None
        transpose, reshape = pat
        for cop in reshape.outacts[0].consumer_ops:
            # headerviewrevert를 유도하므로 output확인
            if check_output_npu_stride(cop):
                return transpose, reshape
        return None

    @case16.transform
    def case16(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        new_outact = builder.make_transpose(new_inact, (0, 2, 1, 3))
        old_outact = reshape.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()


@DataFlowRuleSet.register
class TransposeReshapeTranspose(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        (1,8,196,16)-[transpose0132]->(1,8,16,196)-[reshape]->(1,128,14,14)-[transpose0231]->(1,14,14,128)-[conv]
        =>
        (1,8,196,16)-[transpose0213]->(1,196,8,16)-[reshape]->(1,14,14,128)-[conv]
        """
        pat = find_operator_sequence(
            op, "T0132 R[1bc(hw)->1(bc)hw] T0231", is_basic_npu_op
        )
        if pat is None:
            return None
        transpose0132, reshape, transpose0231, npu_op = pat
        return transpose0132, reshape, transpose0231

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose0132, reshape, transpose0231 = self.matched_pattern
        inact = transpose0132.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_inact, (0, 2, 1, 3))
        old_outact = transpose0231.outacts[0]
        new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(
            transpose0132, reshape, transpose0231
        )
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        """
        (1,20,20,351)-[transpose0312]->(1,351,20,20)-[reshape]->(3,117,20,20)-[transpose0231]->(3,20,20,117)
        =>
        (1,20,20,351)-[reshape]->(1,400,3,117)-[transpose0213]-[reshape]->(3,20,20,117)
        """
        pat = find_operator_sequence(op, "T0312 R[1(cd)xy->cdxy] T0231")
        if pat is None:
            return None
        transpose0312, reshape, transpose0231 = pat
        reshape_inact = reshape.inacts[0]
        reshape_outact = reshape.outacts[0]
        if reshape_inact.src_shape[0] == 1 and reshape_outact.src_shape[0] > 1:
            return transpose0312, reshape, transpose0231
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose0312, reshape, transpose0231 = self.matched_pattern
        inact = transpose0312.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        reshape_outact = reshape.outacts[0]
        c, d, x, y = reshape_outact.src_shape
        new_outact = builder.make_reshape(new_inact, (1, -1, c, d))
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = transpose0231.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(
            transpose0312, reshape, transpose0231
        )
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        """
        (1,1,64,4)-[transpose0132]->(1,1,4,64)-[reshape]->(1,1,1,4,64)-[transpose04123]->(1,64,1,1,4)
        =>
        (1,1,64,4)-[reshape]->(1,64,1,1,4)
        """
        pat = find_operator_sequence(op, "T0132 R[11bc->111bc] T04123")
        if pat is None:
            return None
        return pat

    @case2.transform
    def case2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose0132, reshape, transpose04123 = self.matched_pattern
        inact = transpose0132.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        old_outact = transpose04123.outacts[0]
        new_outact = builder.make_reshape(new_inact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(
            transpose0132, reshape, transpose04123
        )
        return builder.build()


@DataFlowRuleSet.register
class TransposeReshapeNPUOps(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """something like maxpool-transpose0312-r-linear. In this case, transpose0312 cannot be removed by matching transpose0231"""
        pat = find_operator_sequence(
            op, is_basic_npu_op, "T0312 R[bchw->b11(chw)]", is_basic_npu_op
        )
        if pat is not None:
            _, transpose, reshape, _ = pat
            transpose_inact = transpose.inacts[0]
            n, h, w, c = transpose_inact.src_shape
            if all(x > 1 and not x.dynamic for x in (h, w, c)):
                return transpose, reshape
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, reshape = self.matched_pattern
        inact = transpose.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)

        n, kernel_h, kernel_w, in_ch = map(int, inact.src_shape)
        out_ch = int(kernel_h * kernel_w * in_ch)
        w_conv = numpy.zeros((out_ch, in_ch, kernel_h, kernel_w), dtype=numpy.float32)
        c, h, w = numpy.indices((in_ch, kernel_h, kernel_w))  # 모두 (C,H,W)
        k = c * (kernel_h * kernel_w) + h * kernel_w + w  # (C,H,W)
        w_conv[k.ravel(), c.ravel(), h.ravel(), w.ravel()] = 1.0

        new_outact = builder.make_conv2d(
            new_outact,
            in_channels=in_ch,
            out_channels=out_ch,
            h_kernel=kernel_h,
            w_kernel=kernel_w,
            weight=w_conv,
        )
        old_outact = reshape.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, reshape)
        return builder.build()


def is_headerview(transpose):
    if transpose.options.transpose_axes == (0, 2, 1, 3):
        reshape = transpose.inacts[0].producer_op
        if reshape is not None and reshape.layertype == LayerType.Reshape:
            return reshape_check(
                "11(hw)c->1hwc",
                reshape.inacts[0].src_shape,
                reshape.outacts[0].src_shape,
            )
    if transpose.options.transpose_axes == (0, 3, 1, 2, 4):
        reshape = transpose.inacts[0].producer_op
        if reshape is not None and reshape.layertype == LayerType.Reshape:
            return reshape_check(
                "1hw(nc)->1hwnc",
                reshape.inacts[0].src_shape,
                reshape.outacts[0].src_shape,
            )
    return False


@DataFlowRuleSet.register
class TransposeOpsTranspose(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """transpose0-[ops...]-transpose1
        we pull ops in front of the first transpose
        =>
        [ops...]-transpose0-transpose1
        """

        def check_fn(op):
            return (
                op.layertype
                in (
                    LayerType.L2Normalization,
                    LayerType.L1Normalization,
                    LayerType.SumNormalization,
                )
                or is_actfunc_type(op)
                or op.layertype == LayerType.Pow
                or is_biop_const(op)
            )

        pat = find_operator_sequence(op, check_fn, "T", strict_search=True)
        if pat is None:
            return None
        curr_op, trans_post = pat
        op_seq = [trans_post, curr_op]
        max_depth = 10
        depth = 0
        curr_op = curr_op.inacts[0].producer_op
        while depth < max_depth:
            # terminal cond
            if curr_op is None:
                return None
            if curr_op.layertype == LayerType.Transpose:
                if is_headerview(curr_op):
                    return None
                op_seq.append(curr_op)
                return tuple(reversed(op_seq))
            # proceed
            if check_fn(curr_op):
                op_seq.append(curr_op)
                inact = curr_op.inacts[0]
                if 1 == len(inact.consumer_ops):
                    curr_op = curr_op.inacts[0].producer_op
                else:
                    return None
            else:
                return None
            depth += 1

        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        def new_axes_from_old(old_axes, pre_transpose_axes, rank):
            new_axes = []
            for ax in old_axes:
                if ax < 0:
                    ax += rank
                new_ax = pre_transpose_axes[ax]
                new_axes.append(new_ax)
            return tuple(new_axes)

        builder = OpTransformResultV2Builder()
        op_seq = self.matched_pattern
        pre_trans, op_seq, post_trans = op_seq[0], op_seq[1:-1], op_seq[-1]
        pre_trans_inact = pre_trans.inacts[0]
        new_outact = builder.copy_activationspec(pre_trans_inact, add_input_map=True)
        for old_op in op_seq:
            kw = {}
            if old_op.layertype == LayerType.Slice:
                kw["axis"] = new_axes_from_old(
                    old_op.options.axis,
                    pre_trans.options.transpose_axes,
                    new_outact.src_dim,
                )
            elif old_op.layertype == LayerType.L2Normalization:
                kw["norm_axis"] = new_axes_from_old(
                    old_op.options.norm_axis,
                    pre_trans.options.transpose_axes,
                    new_outact.src_dim,
                )
            elif is_biop_const(old_op):
                const_val = old_op.get_tensor(old_op.options.constant).value
                if const_val.size == 1:
                    new_const_val = const_val
                else:
                    old_inact = old_op.inacts[0]
                    shape = tuple(map(int, old_inact.src_shape))
                    new_const_val = numpy.broadcast_to(const_val, shape)
                    pre_axes = pre_trans.options.transpose_axes
                    reverse_axes = tuple(
                        sorted(range(len(pre_axes)), key=lambda i: pre_axes[i])
                    )
                    new_const_val = numpy.transpose(new_const_val, reverse_axes)
                kw = {"constant": new_const_val}
            new_outact = builder.with_new_input_and_options(old_op, new_outact, **kw)
        new_outact = builder.make_transpose(
            new_outact, pre_trans.options.transpose_axes
        )
        old_outact = post_trans.inacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(pre_trans, *op_seq)
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        """is op does not have effiect in stride
        (1,n,h,w,c)-[transpose03214]->(1,w,h,n,c)-[op]->(1,w,h,n,c)-[transpose01432]->(1,w,c,n,h)
        =>
        (1,n,h,w,c)-[transpose03124]->(1,w,n,h,c)-[op]->(1,w,n,h,c)-[transpose01423]->(1,w,c,n,h)
        """

        def check_fn(op):
            if op.layertype in ACTIVATION_FUNCTIONS:
                return True
            if op.layertype == LayerType.Softmax and op.options.axis in (4, -1):
                return True
            return False

        pat = find_operator_sequence(op, "T03214", check_fn, "T01432")
        if pat is None:
            return None
        return pat

    @case2.transform
    def case2(self, *args, **kwargs):
        transpose0, op, transpose1 = self.matched_pattern
        builder = OpTransformResultV2Builder()
        transpose0_inact = transpose0.inacts[0]
        new_inact = builder.copy_activationspec(transpose0_inact, add_input_map=True)
        new_inact = builder.make_transpose(new_inact, (0, 3, 1, 2, 4))
        new_outact = builder.with_new_input_and_options(op, new_inact)
        new_outact = builder.make_transpose(new_outact, (0, 1, 4, 2, 3))
        old_outact = transpose1.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose0, op, transpose1)
        return builder.build()

    @pattern
    def case3(self, op: Operator, **kwargs):
        """
        (1,8,3136,19)-[transpose0132]->(1,8,19,3136)-[reshape]->(1,152,56,56)-[slice axis=1]->(1,38,56,56)-[transpose0231]->(1,56,56,38)
        =>
        (1,8,3136,19)-[transpose0213]->(1,3136,8,19)-[reshape]->(1,56,56,152)-[slice axis=-1]->(1,56,56,38)
        """
        pat = find_operator_sequence(op, "T0132 R[1nc(hw)->1(nc)hw] S[1] T0231")
        if pat is None:
            return None
        t0132, reshape, slice_, t0231 = pat
        inact = t0132.inacts[0]
        if check_input_npu_stride(inact.producer_op):
            return t0132, reshape, slice_, t0231
        return None

    @case3.transform
    def case3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        t0132, reshape, slice_, t0231 = self.matched_pattern
        inact = t0132.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        n, c, h, w = reshape.outacts[0].src_shape
        new_outact = builder.make_reshape(new_outact, (n, h, w, c))
        new_outact = builder.with_new_input_and_options(slice_, new_outact, axis=(-1,))
        old_outact = t0231.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(t0132, reshape, slice_, t0231)
        return builder.build()

    @pattern
    def case4(self, op, *args, **kwargs):
        """
        (1,4,16,8400)-[transpose0213]->(1,16,4,8400)-[softmax axis=1]-[transpose0231]->(1,4,8400,16)
        =>
        (1,4,16,8400)-[transpose0132]->(1,4,8400,16)-[softmax axis=3]
        """
        pat = find_operator_sequence(op, "T0213", LayerType.Softmax, "T0231")
        if pat is None:
            return None
        t0213, softmax, t0231 = pat
        if softmax.options.axis == 1:
            return t0213, softmax, t0231
        return None

    @case4.transform
    def case4(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        t0213, softmax, t0231 = self.matched_pattern
        inact = t0213.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
        new_outact = builder.with_new_input_and_options(softmax, new_outact, axis=3)
        old_outact = t0231.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(t0213, softmax, t0231)
        return builder.build()


@DataFlowRuleSet.register
class ExpandTranspose(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.Expand, "T0231")
        if pat is None:
            return None
        expand, t0231 = pat
        if expand.options.is_const_first:
            return None
        return expand, t0231

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        expand, t0231 = self.matched_pattern
        expand_inact = expand.inacts[0]
        new_outact = builder.copy_activationspec(expand_inact, add_input_map=True)
        new_outact = builder.make_transpose(new_outact, (0, 2, 3, 1))

        const = expand.get_tensor(expand.options.constant).value
        expand_shape = numpy.array(operator.itemgetter(0, 2, 3, 1)(const))
        new_outact = builder.make_expand(new_outact, constant=expand_shape)
        old_outact = t0231.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(expand, t0231)
        return builder.build()


@DataFlowRuleSet.register
class ResizeTranspose(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.Resize, "T0231")
        if pat is None:
            return None
        resize, transpose = pat
        for cop in transpose.outacts[0].consumer_ops:
            if check_output_npu_stride(cop):
                return resize, transpose
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        resize, transpose = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = resize.inacts[0]
        new_outact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_transpose(new_outact, (0, 2, 3, 1))
        if resize.options.scales is not None and resize.options.scales:
            scales = operator.itemgetter(0, 2, 3, 1)(resize.options.scales)
        else:
            scales = None
        if resize.options.sizes is not None and resize.options.sizes:
            sizes = operator.itemgetter(0, 2, 3, 1)(resize.options.sizes)
        else:
            sizes = None
        if resize.options.roi:
            roi = resize.options.roi
            start, end = roi[: len(roi) // 2], roi[len(roi) // 2 :]
            start = tuple(operator.itemgetter(0, 2, 3, 1)(start))
            end = tuple(operator.itemgetter(0, 2, 3, 1)(end))
            roi = start + end
        else:
            roi = None
        new_outact = builder.with_new_input_and_options(
            resize, new_outact, scales=scales, sizes=sizes, roi=roi
        )
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(resize, transpose)
        return builder.build()


@DataFlowRuleSet.register
class MaskedFill(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.MaskedFill)
        if pat is None:
            return None
        masked_fill = pat[0]
        inact, mask = masked_fill.inacts
        if is_transpose(inact.producer_op, (0, 1, 3, 2)):
            transpose = inact.producer_op
            transpose_inact = transpose.inacts[0]
            if check_input_npu_stride(transpose_inact.producer_op):
                return transpose, masked_fill
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        transpose, masked_fill = self.matched_pattern
        builder = OpTransformResultV2Builder()
        transpose_inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(transpose_inact, add_input_map=True)
        mask_inact = masked_fill.inacts[1]
        new_mask_inact = builder.copy_activationspec(mask_inact, add_input_map=True)
        new_mask_inact = builder.make_transpose(new_mask_inact, (0, 1, 3, 2))
        new_outact = builder.with_new_input_and_options(
            masked_fill, (new_inact, new_mask_inact)
        )
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2))
        old_outact = masked_fill.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, masked_fill)
        return builder.build()


@DataFlowRuleSet.register
class TransposeBiop(TransformRule):
    @pattern
    def case1(self, biop: Operator, *args, **kwargs):
        """
        transpose0312/0213/0132/0321-| add/mul/div/sub
        transpose0312/0213/0132/0321-|
        """
        if not is_biop_wrapper(biop):
            return None

        inact0, inact1 = biop.inacts
        # targets = [(0, 3, 1, 2), (0, 3, 2, 1), (0, 2, 1, 3), (0, 1, 3, 2), (0, 3, 2, 1)]
        pop0, pop1 = inact0.producer_op, inact1.producer_op
        if is_transpose(pop0):
            axes = pop0.options.transpose_axes
            if len(axes) == 4:
                if axes[0] != 0:
                    return None
            if is_transpose(pop1, axes):
                if axes == (0, 2, 3, 1):
                    return None
                return biop, axes
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop, pat_ax = self.matched_pattern
        new_inacts = []
        for inact in biop.inacts:
            transpose = inact.producer_op
            inact = transpose.inacts[0]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inacts.append(new_inact)
            builder.remove_connectivity_and_invalidate(transpose, biop)
        new_outact = builder.with_new_input_and_options(biop, new_inacts)
        new_outact = builder.make_transpose(new_outact, pat_ax)
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        return builder.build()

    @pattern
    def case2(self, biop: Operator, *args, **kwargs):
        """
        transpose0312/0213      -| add/mul/div/sub
        transpose0312/0213-slice-|
        """
        if not is_biop_wrapper(biop):
            return None

        inact0, inact1 = biop.inacts
        targets = [("T0312 S", (0, 3, 1, 2)), ("T0213 S", (0, 2, 1, 3))]
        pop0, pop1 = inact0.producer_op, inact1.producer_op
        for s_pat, ax_pat in targets:
            if (
                pat := find_operator_sequence(pop0, s_pat, strict_search=True)
            ) is not None and is_transpose(pop1, ax_pat):
                return biop, ax_pat
        return None

    @case2.transform
    def case2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop, pat_ax = self.matched_pattern
        new_inacts = []
        for inact in biop.inacts:
            if inact.producer_op.layertype == LayerType.Slice:
                slice_ = inact.producer_op
                transpose = slice_.inacts[0].producer_op
                inact = transpose.inacts[0]
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_axis = tuple(pat_ax[ax] for ax in slice_.options.axes)
                new_inact = builder.with_new_input_and_options(
                    slice_, new_inact, axis=new_axis
                )
                new_inacts.append(new_inact)
                builder.remove_connectivity_and_invalidate(transpose, slice_, biop)
            elif inact.producer_op.layertype == LayerType.Transpose:
                transpose = inact.producer_op
                inact = transpose.inacts[0]
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inacts.append(new_inact)
                builder.remove_connectivity_and_invalidate(transpose, biop)
        new_outact = builder.with_new_input_and_options(biop, new_inacts)
        new_outact = builder.make_transpose(new_outact, pat_ax)
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        return builder.build()

    @pattern
    def case3(self, op: Operator, *args, **kwargs):
        pat = find_operator_sequence(op, "biop T0213")
        if pat is None:
            return None
        biop, transpost_post = pat

        for inact in biop.inacts:
            pat = find_operator_sequence(inact.producer_op, is_basic_npu_op, "T0213")
            if pat is not None:
                conv, transpose_pre = pat
                return transpose_pre, biop, transpost_post
        return None

    @case3.transform
    def case3(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        _, biop, _ = self.matched_pattern
        new_inacts = []
        for inact in biop.inacts:
            if is_transpose(inact.producer_op, (0, 2, 1, 3)):
                transpose = inact.producer_op
                transpose_inact = transpose.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                builder.remove_connectivity_and_invalidate(transpose, biop)
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_transpose(new_inact, (0, 2, 1, 3))
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(biop, new_inacts)
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(biop)
        return builder.build()

    @pattern
    def case4(self, biop: Operator, *args, **kwargs):
        if not is_biop_wrapper(biop):
            return None
        inact0, inact1 = biop.inacts
        pop0, pop1 = inact0.producer_op, inact1.producer_op

        def f(pop0, pop1):
            pat0 = find_operator_sequence(pop0, "T0213")
            if pat0 is None:
                return None
            transpose_pre = pat0[0]
            transpose_inact = transpose_pre.inacts[0]
            if not check_input_npu_stride(transpose_inact.producer_op):
                return None
            pat1 = find_operator_sequence(pop1, LayerType.ReduceSum)
            if pat1 is None:
                return None
            reduce = pat1[0]
            if reduce.options.reduce_axes == (2,) and reduce.options.keep_dims:
                return transpose_pre, reduce
            return None

        if f(pop0, pop1) is not None or f(pop1, pop0) is not None:
            return biop
        return None

    @case4.transform
    def case4(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop = self.matched_pattern
        new_inacts = []
        for inact in biop.inacts:
            transpose = inact.producer_op
            if is_transpose(transpose, (0, 2, 1, 3)):
                transpose_inact = transpose.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                builder.remove_connectivity_and_invalidate(transpose, biop)
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_transpose(new_inact, (0, 2, 1, 3))
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(biop, new_inacts)
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(biop)
        return builder.build()

    @pattern
    def case5(self, biop: Operator, *args, **kwargs):
        if not is_biop_wrapper(biop):
            return None
        inact0, inact1 = biop.inacts
        pop0, pop1 = inact0.producer_op, inact1.producer_op
        outact = biop.outacts[0]
        if not (
            1 == len(outact.consumer_ops)
            and outact.consumer_ops[0].layertype == LayerType.Concatenate
            and outact.consumer_ops[0].options.axis in (3, -1)
        ):
            return None
        concat = outact.consumer_ops[0]

        def f(pop0, pop1):
            pat0 = find_operator_sequence(pop0, "T0213")
            if pat0 is None:
                return None
            pat1 = find_operator_sequence(pop1, "T0213")
            if pat1 is None:
                return None
            return pop0, pop1

        pat0 = f(pop0, pop1)
        if pat0 is not None:
            return biop, concat
        pat1 = f(pop1, pop0)
        if pat1 is not None:
            return biop, concat
        return None

    @case5.transform
    def case5(self, *args, **kwargs):
        biop, concat = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = []
        for inact in biop.inacts:
            transpose = inact.producer_op
            transpose_inact = transpose.inacts[0]
            new_inact = builder.copy_activationspec(transpose_inact, add_input_map=True)
            new_inacts.append(new_inact)
            builder.remove_connectivity_and_invalidate(transpose, biop)
        new_outact = builder.with_new_input_and_options(biop, new_inacts)
        new_cc_inacts = []
        for inact in concat.inacts:
            if inact.producer_op.name == biop.name:
                new_cc_inacts.append(new_outact)
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_transpose(new_inact, (0, 2, 1, 3))
                new_cc_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(concat, new_cc_inacts)
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_otuact = concat.outacts[0]
        builder.add_output_map(new_outact, old_otuact)
        builder.remove_connectivity_and_invalidate(biop, concat)
        return builder.build()

    @pattern
    def case6(self, op: Operator, *args, **kwargs):
        if not is_biop_wrapper(op):
            return None
        biop = op

        def f(pop0, pop1):
            pat = find_operator_sequence(pop0, is_basic_npu_op, "T0312")
            if pat is None:
                return None
            basic_op, t0312_left = pat
            pat = find_operator_sequence(pop1, "T0312 S")
            if pat is None:
                return None
            t0312_right, slice_ = pat
            return basic_op, t0312_left, t0312_right, slice_

        inact0, inact1 = biop.inacts
        pop0 = inact0.producer_op
        pop1 = inact1.producer_op
        pat = f(pop0, pop1)
        if pat is not None:
            basic_op, t0312_left, t0312_right, slice_ = pat
            return basic_op, t0312_left, t0312_right, slice_, biop
        pat = f(pop1, pop0)
        if pat is not None:
            basic_op, t0312_left, t0312_right, slice_ = pat
            return basic_op, t0312_left, t0312_right, slice_, biop
        return None

    @case6.transform
    def case6(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        basic_op, t0312_left, t0312_right, slice_, biop = self.matched_pattern
        new_inacts = []
        for inact in biop.inacts:
            pop = inact.producer_op
            if pop.layertype == LayerType.Transpose:
                transpose_inact = pop.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                builder.remove_connectivity_and_invalidate(pop, biop)
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_transpose(new_inact, (0, 2, 3, 1))
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(biop, new_inacts)
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(biop)
        return builder.build()

    @pattern
    def case7(self, op: Operator, *args, **kwargs):
        """next biop also has transpose0213 input
        (1,32,19,192)-[conv]->(1,32,1,192)-[rmnsnorm]-[transpose0213]-[...]
                                                    |-[adding]->[transpose0213 and biops....]
        (1,1,32,192)-[transpose0213]->(1,32,1,192)--|

        =>
        (1,32,19,192)-[conv]->(1,32,1,192)-[rmnsnorm]-[transpose0213]-|-[...]
                                                                      |-[adding]
        (1,1,32,192)--------------------------------------------------|

        """
        if not is_biop_wrapper(op):
            return None
        biop = op
        adding_outact = biop.outacts[0]
        post_transpose_check = False
        post_biop_check = False
        for cop in adding_outact.consumer_ops:
            if is_transpose(cop, (0, 2, 1, 3)):
                post_transpose_check = True
            elif is_biop_wrapper(cop):
                for cop_inact in cop.inacts:
                    if is_transpose(cop_inact.producer_op, (0, 2, 1, 3)):
                        post_biop_check = True
        if not (post_biop_check and post_transpose_check):
            return None
        inact0, inact1 = biop.inacts
        if not is_transpose(inact1.producer_op, (0, 2, 1, 3)):
            return None
        pat0 = find_operator_sequence(
            inact0.producer_op, LayerType.Convolution, LayerType.RmsNormalization
        )
        if pat0 is None:
            return None
        conv, rmsnorm = pat0
        rmsnorm_outact = rmsnorm.outacts[0]
        if not any(
            is_transpose(cop, (0, 2, 1, 3)) for cop in rmsnorm_outact.consumer_ops
        ):
            return None
        return biop

    @case7.transform
    def case7(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop = self.matched_pattern
        new_inacts = []
        for inact in biop.inacts:
            pop = inact.producer_op
            if is_transpose(pop, (0, 2, 1, 3)):
                transpose_inact = pop.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                builder.remove_connectivity_and_invalidate(pop, biop)
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_transpose(new_inact, (0, 2, 1, 3))
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(biop, new_inacts)
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(biop)
        return builder.build()

    @pattern
    def case8(self, op: Operator, *args, **kwargs):
        """
        t0312->(1,256,80,80)-----------------------------|-[adding]->(1,256,80,80)-[actfn]
        t0312->(1,256,80,80)-|-[multiply]->(1,256,80,80)-|
        t0231->(1,256,1,1)--
        """
        pat = find_operator_sequence(op, "biop")
        if pat is None:
            return None
        biop1 = pat[0]
        inact0, inact1 = biop1.inacts

        def check_biop0_cond(biop0):
            if not is_biop_wrapper(biop0):
                return False
            inact00, inact01 = biop0.inacts
            return is_transpose(inact00.producer_op, (0, 3, 1, 2)) and is_transpose(
                inact01.producer_op, (0, 2, 3, 1)
            )

        if is_transpose(inact0.producer_op, (0, 3, 1, 2)) and check_input_npu_stride(
            inact0.producer_op, 3
        ):
            biop0 = inact1.producer_op
            if check_biop0_cond(biop0):
                return biop0, biop1
        if is_transpose(inact1.producer_op, (0, 3, 1, 2)):
            biop0 = inact0.producer_op
            if check_biop0_cond(biop0):
                return biop0, biop1
        return None

    @case8.transform
    def case8(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop0, biop1 = self.matched_pattern
        new_inacts0 = []
        for inact in biop0.inacts:
            if is_transpose(inact.producer_op, (0, 3, 1, 2)):
                transpose_inact = inact.producer_op.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                builder.remove_connectivity_and_invalidate(inact.producer_op, biop0)
            elif is_transpose(inact.producer_op, (0, 2, 3, 1)):
                transpose_inact = inact.producer_op.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                new_inact = builder.make_transpose(new_inact, (0, 3, 1, 2))
                builder.remove_connectivity_and_invalidate(inact.producer_op, biop0)
            else:
                raise NotImplementedError("code should not reach here")
            new_inacts0.append(new_inact)
        new_outact0 = builder.with_new_input_and_options(biop0, new_inacts0)

        new_inacts1 = []
        for inact in biop1.inacts:
            if is_transpose(inact.producer_op, (0, 3, 1, 2)):
                transpose_inact = inact.producer_op.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                builder.remove_connectivity_and_invalidate(inact.producer_op, biop1)
                new_inacts1.append(new_inact)
            else:
                new_inacts1.append(new_outact0)
                builder.remove_connectivity_and_invalidate(biop0, biop1)
        new_outact1 = builder.with_new_input_and_options(biop1, new_inacts1)
        new_outact1 = builder.make_transpose(new_outact1, (0, 3, 1, 2))
        builder.add_output_map(new_outact1, biop1.outacts[0])
        builder.remove_connectivity_and_invalidate(biop1)
        return builder.build()

    @pattern
    def case9(self, op: Operator, *args, **kwargs):
        """eca_nfnet
        conv->(1,56,56,256)-[transpose0312]->(1,256,56,56)-|-[multiply]->(1,256,56,56)
        conv->(1,1,256,1)-[transpose0231]->(1,256,1,1)-----|
        """
        if not is_biop_wrapper(op):
            return None
        biop = op
        inact0, inact1 = biop.inacts
        pop0, pop1 = inact0.producer_op, inact1.producer_op

        def check0312(pop):
            pat = find_operator_sequence(pop, is_basic_npu_op, "T0312")
            if pat is not None:
                return True
            return (
                find_operator_sequence(pop, is_basic_npu_op, "actfn T0312") is not None
            )

        def check0231(pop):
            oact = pop.outacts[0]
            if not (oact.src_dim == 4 and oact.src_shape[-2:] == (1, 1)):
                return False
            pat = find_operator_sequence(pop, is_basic_npu_op, "T0231")
            if pat is not None:
                return True
            return (
                find_operator_sequence(pop, is_basic_npu_op, "actfn T0231") is not None
            )

        if check0312(pop0) and check0231(pop1):
            return biop
        if check0312(pop1) and check0231(pop0):
            return biop
        return None

    @case9.transform
    def case9(self, op: Operator, **kwargs):
        builder = OpTransformResultV2Builder()
        biop = self.matched_pattern
        new_inacts = []
        for inact in biop.inacts:
            if is_transpose(inact.producer_op, (0, 3, 1, 2)):
                transpose_inact = inact.producer_op.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                builder.remove_connectivity_and_invalidate(inact.producer_op, biop)
                new_inacts.append(new_inact)
            elif is_transpose(inact.producer_op, (0, 2, 3, 1)):
                transpose_inact = inact.producer_op.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                new_inact = builder.make_transpose(new_inact, (0, 1, 3, 2))
                builder.remove_connectivity_and_invalidate(inact.producer_op, biop)
                new_inacts.append(new_inact)
            else:
                raise NotImplementedError("code should not reach here")
        new_outact = builder.with_new_input_and_options(biop, new_inacts)
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        return builder.build()

    @pattern
    def case10(self, op: Operator, *args, **kwargs):
        if not is_biop_wrapper(op):
            return None
        inact0, inact1 = op.inacts
        left_pop = inact0.producer_op
        right_pop = inact1.producer_op
        if left_pop.layertype == LayerType.Transpose:
            axes = left_pop.options.transpose_axes
            t_with_axes = functools.partial(is_transpose, axes=axes)
            if (
                find_operator_sequence(right_pop, t_with_axes, LayerType.Softmax)
                is not None
            ):
                return left_pop, right_pop, op
        if right_pop.layertype == LayerType.Transpose:
            axes = right_pop.options.transpose_axes
            t_with_axes = functools.partial(is_transpose, axes=axes)
            if (
                find_operator_sequence(left_pop, t_with_axes, LayerType.Softmax)
                is not None
            ):
                return left_pop, right_pop, op
        return None

    @case10.transform
    def case10(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        left_pop, right_pop, biop = self.matched_pattern
        new_inacts = []
        transpose_axes = None
        for inact in biop.inacts:
            if inact.producer_op.layertype == LayerType.Transpose:
                transpose = inact.producer_op
                transpose_axes = transpose.options.transpose_axes
                transpose_inact = inact.producer_op.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                builder.remove_connectivity_and_invalidate(transpose, biop)
            else:
                softmax = inact.producer_op
                transpose = softmax.inacts[0].producer_op
                transpose_inact = transpose.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                axis = transpose.options.transpose_axes[softmax.options.axis]
                new_inact = builder.make_softmax(new_inact, axis=axis)
                builder.remove_connectivity_and_invalidate(transpose, softmax, biop)
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(biop, *new_inacts)
        new_outact = builder.make_transpose(new_outact, transpose_axes)
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        return builder.build()


@DataFlowRuleSet.register
class TransposeConcatenate(TransformRule):

    @pattern
    def base(self, op: Operator, **kwargs):
        if not (op.layertype == LayerType.Concatenate):
            return None
        ref_axes = None
        trans = []
        for inact in op.inacts:
            if inact.producer_op.layertype == LayerType.Transpose:
                transpose = inact.producer_op
                if ref_axes is None:
                    ref_axes = transpose.options.transpose_axes
                if ref_axes != transpose.options.transpose_axes:
                    return None
                trans.append(transpose)
            else:
                return None
        return trans, op

    @base.transform
    def base(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transposes, concatenate = self.matched_pattern
        new_inacts = []
        for trans in transposes:
            trans_inact = trans.inacts[0]
            new_inact = builder.copy_activationspec(trans_inact, add_input_map=True)
            new_inacts.append(new_inact)
            builder.remove_connectivity_and_invalidate(trans, concatenate)
        trans_axes = transposes[0].options.transpose_axes
        new_axis = trans_axes[concatenate.options.axis]
        new_outact = builder.make_concatenate(new_inacts, new_axis)
        new_outact = builder.make_transpose(new_outact, trans_axes)
        old_outact = concatenate.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        return builder.build()

    @pattern
    def case0(self, op: Operator, **kwargs):
        if not (op.layertype == LayerType.Concatenate and op.options.axis == 1):
            return None
        concat = op
        for inact in concat.inacts:
            pat0 = find_operator_sequence(
                inact.producer_op, LayerType.Input, "R[h1c->1h1c]"
            )
            if pat0 is not None:
                continue
            pat1 = find_operator_sequence(inact.producer_op, "T0213")
            if pat1 is None:
                return None
        return concat

    @case0.transform
    def case0(self, *args, **kwargs):
        concat = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = []
        for inact in concat.inacts:
            transpose = inact.producer_op
            if transpose.layertype == LayerType.Transpose:
                transpose_inact = transpose.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_transpose(new_inact, (0, 2, 1, 3))
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(concat, new_inacts, axis=2)
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = concat.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(concat)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        if not (op.layertype == LayerType.Concatenate and op.options.axis in (3, -1)):
            return None
        concat = op
        input_transpose_cnt = 0

        input_cnt = len(concat.inacts)
        for inact in concat.inacts:
            pop = inact.producer_op
            if is_transpose(pop, (0, 2, 1, 3)):
                pop_inact = pop.inacts[0]
                if check_input_npu_stride(pop_inact.producer_op):
                    input_transpose_cnt += 1
            elif pop.layertype == LayerType.InputConstant:
                input_transpose_cnt += 1
        if input_transpose_cnt > input_cnt - input_transpose_cnt:
            return concat

        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        concat = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inacts = []
        for inact in concat.inacts:
            transpose = inact.producer_op
            if is_transpose(transpose, (0, 2, 1, 3)):
                transpose_inact = transpose.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                builder.remove_connectivity_and_invalidate(transpose, concat)
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_transpose(new_inact, (0, 2, 1, 3))
            new_inacts.append(new_inact)
        new_outact = builder.make_concatenate(new_inacts, axis=-1)
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = concat.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(concat)
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Concatenate:
            return None
        if op.options.axis != 1:
            return None

        # 이게 instancenorm이랑 잘못 엮이면 무한루프 돌 수 있어서 특수 경우만 처리함.
        checks = []
        for inact in op.inacts:
            pop = inact.producer_op
            if is_transpose(pop, (0, 3, 1, 2)):
                transpose = inact.producer_op
                pop = transpose.inacts[0].producer_op
                if (
                    pop.layertype != LayerType.InputConstant
                    and is_basic_npu_op(pop)
                    or find_operator_sequence(pop, is_basic_npu_op, LayerType.Resize)
                ):
                    checks.append(True)
            elif pop.layertype == LayerType.InputConstant:
                checks.append(True)
            else:
                return None
        if sum(checks) == len(op.options.inputs):
            return op
        return None

    @case2.transform
    def case2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        concat = self.matched_pattern
        new_inacts = []
        for inact in concat.inacts:
            if is_transpose(inact.producer_op, (0, 3, 1, 2)):
                transpose = inact.producer_op
                inact = transpose.inacts[0]
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                builder.remove_connectivity_and_invalidate(transpose, concat)
            elif inact.producer_op.layertype == LayerType.InputConstant:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_transpose(new_inact, (0, 2, 3, 1))
            else:
                raise NotImplementedError("code should not reach here")
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(concat, new_inacts, axis=-1)
        new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = concat.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        return builder.build()

    # @pattern
    # def with_inputconst(self, op: Operator, **kwargs):
    #     """with inputconst"""
    #     if op.layertype != LayerType.Concatenate:
    #         return None
    #     transposes = []
    #     inputconsts = []
    #     for inact in op.inacts:
    #         pop = inact.producer_op
    #         if pop is None:
    #             return None
    #         if pop.layertype == LayerType.InputConstant:
    #             inputconsts.append(pop)
    #         elif pop.layertype == LayerType.Transpose:
    #             transposes.append(pop)
    #         else:
    #             return None
    #     if len(transposes) + len(inputconsts) != len(op.options.inputs):
    #         return None
    #     axes = transposes[0].options.transpose_axes
    #     if all(axes == x.options.transpose_axes for x in transposes[1:]):
    #         return op, axes
    #
    #     return None
    #
    # @with_inputconst.transform
    # def with_inputconst(self, *args, **kwargs):
    #     builder = OpTransformResultV2Builder()
    #     concat, axes = self.matched_pattern
    #     new_inacts = []
    #     for inact in concat.inacts:
    #         pop = inact.producer_op
    #         new_inact = builder.copy_activationspec(inact, add_input_map=True)
    #         if pop.layertype == LayerType.Transpose:
    #             new_outact = builder.make_transpose(
    #                 new_inact, pop.options.transpose_axes
    #             )
    #             new_inacts.append(new_outact)
    #         else:
    #             const_val = pop.get_tensor(pop.options.constant).value
    #             new_const_val = numpy.transpose(const_val, axes)
    #             new_outact = builder.make_inputconst(new_const_val)
    #             new_inacts.append(new_outact)
    #         builder.remove_connectivity_and_invalidate(pop, concat)
    #     new_axes = axes[concat.options.axis]
    #     new_outact = builder.make_concatenate(new_inacts, axis=new_axes)
    #     new_outact = builder.make_transpose(new_outact, axes)
    #     old_outact = concat.outacts[0]
    #     builder.add_output_map(new_outact, old_outact)
    #     builder.remove_connectivity_and_invalidate(concat)
    #     return builder.build()


@DataFlowRuleSet.register
class TransposeWhere(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.Where)
        if pat is None:
            return None
        where = pat[0]
        if 3 != len(where.options.inputs):
            return None
        cond, x, y = where.inacts
        if any(4 != a.src_dim or 1 != a.src_shape[0] for a in where.inacts):
            return None
        xconst = x.producer_op
        if not (
            xconst.layertype == LayerType.InputConstant
            and (xconst.get_tensor(xconst.options.constant).value.size == 1)
        ):
            return None
        y_pop = y.producer_op
        if not is_transpose(y_pop, (0, 1, 3, 2)):
            return None
        y_pop_inact = y_pop.inacts[0]
        if check_input_npu_stride(y_pop_inact.producer_op, 4):
            return op
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        where_ = self.matched_pattern
        new_inacts = []
        for inact in where_.inacts:
            if is_transpose(inact.producer_op, (0, 1, 3, 2)):
                transpose = inact.producer_op
                transpose_inact = transpose.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                builder.remove_connectivity_and_invalidate(transpose, where_)
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_transpose(new_inact, (0, 1, 3, 2))
            new_inacts.append(new_inact)
        new_output = builder.with_new_input_and_options(where_, new_inacts)
        new_output = builder.make_transpose(new_output, (0, 1, 3, 2))
        old_output = where_.outacts[0]
        builder.add_output_map(new_output, old_output)
        builder.remove_connectivity_and_invalidate(where_)
        return builder.build()


@DataFlowRuleSet.register
class TransposeNormalization(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        def check_norm(op):
            return op.layertype in (
                LayerType.RmsNormalization,
                LayerType.LayerNormalization,
            )

        pat = find_operator_sequence(op, "T0213", check_norm)
        if pat is None:
            return None
        transpose, norm = pat
        norm_inact = norm.inacts[0]
        c = int(norm_inact.src_shape[-1])
        if norm.options.normalized_shape == (c,):
            return transpose, norm
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        transpose, norm = self.matched_pattern
        builder = OpTransformResultV2Builder()
        new_inact = builder.copy_activationspec(transpose.inacts[0], add_input_map=True)
        new_outact = builder.with_new_input_and_options(norm, new_inact)
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = norm.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, norm)
        return builder.build()


@DataFlowRuleSet.register
class TransposeSliceOutput(TransformRule):
    @pattern
    def transpose_slice(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T S", strict_search=True)
        if pat is None:
            return None
        transpose, slice_ = pat
        transpose_inact = transpose.inacts[0]

        # not reshape.
        def check_RT(op):
            return op.layertype in (LayerType.Transpose, LayerType.Reshape)

        if find_operator_sequence(transpose_inact.producer_op, check_RT) is None:
            return transpose, slice_
        return None

    @transpose_slice.transform
    def transpose_slice(self, *args, **kwargs):
        transpose, slice_ = self.matched_pattern
        builder = OpTransformResultV2Builder()
        transpose_inact = transpose.inacts[0]
        new_outact = builder.copy_activationspec(transpose_inact, add_input_map=True)
        axes = tuple(transpose.options.transpose_axes[ax] for ax in slice_.options.axis)
        new_outact = builder.with_new_input_and_options(slice_, new_outact, axis=axes)
        new_outact = builder.with_new_input_and_options(transpose, new_outact)
        old_outact = slice_.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, slice_)
        return builder.build()


@DataFlowRuleSet.register
class BiopTranspose(TransposeBiop):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "biop T0231", is_basic_npu_op)
        if pat is None:
            return None
        biop, transpose, npu_op = pat
        return biop, transpose

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        biop, transpose = self.matched_pattern
        new_inacts = []
        for inact in biop.inacts:
            pop = inact.producer_op
            if is_transpose(pop, (0, 3, 1, 2)):
                transpose_inact = pop.inacts[0]
                new_inact = builder.copy_activationspec(
                    transpose_inact, add_input_map=True
                )
                # 여기서 biop가 invalidate되면 버그 발생함. biop의 consumers가 1이 아닐 수 있음.
                # builder.remove_connectivity_and_invalidate(pop, biop)
                inact.consumer_ops = [
                    x for x in inact.consumer_ops if x.name != biop.name
                ]
                if inact.consumer_ops:
                    builder.remove_connectivity_and_invalidate(inact.producer_op)
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_transpose(new_inact, (0, 2, 3, 1))
            new_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(biop, *new_inacts)
        old_outact = transpose.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(biop, transpose)
        return builder.build()
