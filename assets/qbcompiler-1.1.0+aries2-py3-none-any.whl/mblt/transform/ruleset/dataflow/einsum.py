import numpy

from mblt.core import TransformRule, pattern, Operator, LayerType
from mblt.transform.transform_result import (
    OpTransformResultV2Builder,
)
from ._ruleset import DataFlowRuleSet


@DataFlowRuleSet.register
class Einsum(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """

        (a,b,56,56,96)---|-[einsum byhwc,wkc->byhwk]->(a,b,56,56,14)
        const (56,14,96)-|
        =>
        (a,b,56,56,96)-[reshape]->(1,a*b,56,56*96)-[groupconv, groups=56]->(1,a*b,56,56*14)-[reshape]->(a,b,56,56,14)
        """
        if not (op.layertype == LayerType.Einsum and 2 == len(op.options.inputs)):
            return None
        inact0, inact1 = op.inacts
        if inact1.producer_op.layertype != LayerType.InputConstant:
            return None
        inact_src_shape = inact0.src_shape
        outact = op.outacts[0]
        outact_src_shape = outact.src_shape
        if not (
            len(inact_src_shape) == len(outact_src_shape) == 5
            and inact_src_shape[:2] == outact_src_shape[:2]
            and inact_src_shape[3] == outact_src_shape[3]
        ):
            return None
        if "," not in op.options.equation:
            return None
        eq_left, eq_right = op.options.equation.split("->")
        eq_left0, eq_left1 = eq_left.split(",")
        if (
            len(eq_left0) == len(eq_right) == 5
            and len(eq_left1) == 3
            and eq_left0[:4] == eq_right[:4]
            and eq_left0[4] == eq_left1[2]
            and eq_left1[1] == eq_right[4]
            and (eq_left1[0] == eq_right[3])
        ):
            return op
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        einsum = self.matched_pattern
        inact = einsum.inacts[0]
        iconst = einsum.inacts[1].producer_op

        a, b, h, num_groups, in_ch = map(int, inact.src_shape)
        batch_shape = (a, b)
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_inact = builder.make_reshape(new_inact, (1, a * b, h, -1))

        outact = einsum.outacts[0]
        a, b, h, out_groups, out_ch = map(int, outact.src_shape)
        if out_groups != num_groups:
            raise Exception("out_groups!= in_groups")
        const = iconst.get_tensor(iconst.options.constant).value
        gconv_weight_shape = tuple(map(int, (num_groups * out_ch, in_ch, 1, 1)))
        gconv_weight = numpy.concatenate(
            [const[i, ...] for i in range(const.shape[0])]
        ).reshape(gconv_weight_shape)
        new_outact = builder.make_conv2d(
            new_inact,
            in_channels=in_ch * num_groups,
            out_channels=out_ch * num_groups,
            weight=gconv_weight,
            group_number=num_groups,
        )
        old_outact = einsum.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(einsum)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        """
        (a,b,56,56,96)---|-[einsum byhwc,hkc->byhwk]->(a,b,56,56,14)
        const (56,14,96)-|
        =>

        """
        if not (op.layertype == LayerType.Einsum and 2 == len(op.options.inputs)):
            return None
        inact0, inact1 = op.inacts
        if inact1.producer_op.layertype != LayerType.InputConstant:
            return None
        inact_src_shape = inact0.src_shape
        outact = op.outacts[0]
        outact_src_shape = outact.src_shape
        if not (
            len(inact_src_shape) == len(outact_src_shape) == 5
            and inact_src_shape[:2] == outact_src_shape[:2]
            and inact_src_shape[2] == outact_src_shape[2]
            and inact_src_shape[3] == outact_src_shape[3]
        ):
            return None
        if "," not in op.options.equation:
            return None
        eq_left, eq_right = op.options.equation.split("->")
        eq_left0, eq_left1 = eq_left.split(",")
        if (
            len(eq_left0) == len(eq_right) == 5
            and len(eq_left1) == 3
            and eq_left0[:4] == eq_right[:4]
            and eq_left0[4] == eq_left1[2]
            and eq_left1[1] == eq_right[4]
            and (eq_left1[0] == eq_right[2])
        ):
            return op
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        einsum = self.matched_pattern
        inact = einsum.inacts[0]
        iconst = einsum.inacts[1].producer_op

        a, b, num_groups, w, in_ch = map(int, inact.src_shape)
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_inact = builder.make_transpose(new_inact, (0, 1, 3, 2, 4))
        new_inact = builder.make_reshape(new_inact, (1, a * b, w, -1))

        outact = einsum.outacts[0]
        a, b, out_groups, w, out_ch = map(int, outact.src_shape)
        const = iconst.get_tensor(iconst.options.constant).value
        gconv_weight_shape = tuple(map(int, (num_groups * out_ch, in_ch, 1, 1)))
        gconv_weight = numpy.concatenate(
            [const[i, ...] for i in range(const.shape[0])]
        ).reshape(gconv_weight_shape)
        new_outact = builder.make_conv2d(
            new_inact,
            in_channels=in_ch * num_groups,
            out_channels=out_ch * num_groups,
            weight=gconv_weight,
            group_number=num_groups,
        )
        new_outact = builder.make_reshape(new_outact, (a, b, w, num_groups, out_ch))
        new_outact = builder.make_transpose(new_outact, (0, 1, 3, 2, 4))
        old_outact = einsum.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(einsum)
        return builder.build()
