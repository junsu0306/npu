from types import SimpleNamespace

import numpy

from mblt import LayerType
from mblt.core import pattern
from mblt.operator import Operator
from mblt.operator.utils import interpret_slice
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    check_input_npu_stride,
    is_biop_wrapper,
)
from mblt.transform.graph_transform import TransformRule
from mblt.transform.transform_result import OpTransformResultV2Builder
from ._ruleset import SelectorRuleSet


def _get_selector_index(selector):
    if selector.options.index != -1:
        return list(map(int, selector.get_tensor(selector.options.index).value))
    if selector.options.start is not None:
        dim_size = int(selector.inacts[0].src_shape[selector.options.axis])
        s = selector.options.start
        if s < 0:
            s += dim_size
        e = selector.options.end
        if e < 0:
            e += dim_size
        e = min(dim_size, e)
        return list(range(s, e, selector.options.step))
    return None


@SelectorRuleSet.register
class SelectorSlice(TransformRule):
    @pattern
    def case0(self, op: Operator, *args, **kwargs):
        pat = find_operator_sequence(op, LayerType.IndexedItemSelector, "S")
        if pat is None:
            return None
        selector, slice_ = pat
        if selector.options.index == -1:
            return None
        axis = selector.options.axis
        if axis < 0:
            axis += 1
        rank = selector.inacts[0].src_dim
        if rank != 4:
            return None
        if slice_.options.axis in ((rank - 1,), (-1,)):
            return selector, slice_
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        selector, slice_ = self.matched_pattern
        inact = selector.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        slice_inact = slice_.inacts[0]
        start, end, step = interpret_slice(slice_inact.src_shape, slice_.options)
        index = selector.get_tensor(selector.options.index).value
        new_index = index[numpy.arange(start, end, step)]
        new_outact = builder.make_indexed_item_selector(
            new_inact, axis=selector.options.axis, index=new_index
        )
        old_outact = slice_.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(selector, slice_)
        return builder.build()


@SelectorRuleSet.register
class SelectorSelector(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.IndexedItemSelector, LayerType.IndexedItemSelector
        )
        if pat is None:
            return None
        selector0, selector1 = pat
        inact = selector0.inacts[0]
        if inact.src_dim != 4:
            return None
        if not (
            selector0.options.axis == selector1.options.axis
            and selector0.options.axis in (3, -1)
            and selector0.options.index != -1
        ):
            return None
        pop = inact.producer_op
        if pop.layertype == LayerType.Identity:
            return None
        outact0 = selector0.outacts[0]
        is_all_reduce = True
        for cop in outact0.consumer_ops:
            if cop.layertype == LayerType.IndexedItemSelector and cop.options.axis in (
                3,
                -1,
            ):
                if cop.options.repeat is not None:
                    is_all_reduce = False
                outact = cop.outacts[0]
                if outact.src_shape[-1] <= inact.src_shape[-1]:
                    continue
            elif cop.layertype == LayerType.Slice and cop.options.axis in (
                (3,),
                (-1,),
            ):
                continue
            else:
                return None
        if is_all_reduce:
            return selector0, selector1
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        selector0, selector1 = self.matched_pattern

        outact0 = selector0.outacts[0]
        cops = [x for x in outact0.consumer_ops]
        old_index = selector0.get_tensor(selector0.options.index).value
        inact = selector0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        for cop in cops:
            if cop.layertype == LayerType.IndexedItemSelector:
                if cop.options.start is not None:
                    s, e, st = _interpret_slice_wrapper(selector1)
                    new_index = old_index[slice(s, e, st)]
                    new_outact = builder.make_indexed_item_selector(
                        new_inact, axis=-1, index=new_index
                    )
                elif cop.options.index != -1:
                    old_index2 = cop.get_tensor(cop.options.index).value
                    new_index = old_index[old_index2]
                    new_outact = builder.make_indexed_item_selector(
                        new_inact, axis=-1, index=new_index
                    )
                else:
                    raise NotImplementedError("code should not reach here")
            elif cop.layertype == LayerType.Slice and cop.options.axis in (
                (3,),
                (-1,),
            ):
                s, e, st = _interpret_slice_wrapper(cop)
                new_index = old_index[slice(s, e, st)]
                new_outact = builder.make_indexed_item_selector(
                    new_inact, axis=-1, index=new_index
                )
            else:
                raise NotImplementedError("code should not reach here")
            old_outact = cop.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(selector0, cop)

        return builder.build()


@SelectorRuleSet.register
class ConvolutionSelector(TransformRule):
    @pattern
    def conv_split_fuse(self, op: Operator, **kwargs):
        """
        We remove selector here because this case always reduces operations.
        """
        pat = find_operator_sequence(op, "C actfn", LayerType.IndexedItemSelector)
        if pat is not None:
            conv, actfn, selector = pat
        else:
            pat = find_operator_sequence(op, "C", LayerType.IndexedItemSelector)
            if pat is None:
                return None
            conv, selector = pat
            actfn = None
        if conv.options.group_number != 1:
            return None

        selector_inact = selector.inacts[0]
        for cop in selector_inact.consumer_ops:
            if not (
                cop.layertype == LayerType.IndexedItemSelector
                and cop.options.axis in (3, -1)
                and cop.options.repeat is None
            ):
                return None

        if len(selector_inact.consumer_ops) == 1:
            return conv, actfn, [selector]

        sel_indices = [_get_selector_index(cop) for cop in selector_inact.consumer_ops]
        all_indices = numpy.concatenate(sel_indices)
        unique_vals, counts = numpy.unique(all_indices, return_counts=True)
        count_lookup = numpy.zeros(unique_vals.max() + 1, dtype=numpy.int32)
        count_lookup[unique_vals] = counts

        removable_selectors = []
        for i, curr_idx_list in enumerate(sel_indices):
            if numpy.all(count_lookup[curr_idx_list] == 1):
                removable_selectors.append(selector_inact.consumer_ops[i])
                # return conv, actfn, selector_inact.consumer_ops[i]
        if removable_selectors:
            return conv, actfn, removable_selectors
        return None

    @conv_split_fuse.transform
    def conv_split_fuse(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        conv, actfn, selectors = self.matched_pattern

        inact = conv.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        for selector in selectors:
            index = _get_selector_index(selector)
            if conv.options.bias != -1:
                new_bias = conv.get_tensor(conv.options.bias).value
                new_bias = new_bias[index]
            else:
                new_bias = None
            new_weight = conv.get_tensor(conv.options.weight).value
            new_weight = new_weight[index, :, :, :]
            new_outact = builder.with_new_input_and_options(
                conv,
                new_inact,
                bias=new_bias,
                weight=new_weight,
                out_channels=new_weight.shape[0],
            )
            if actfn is not None:
                new_outact = builder.with_new_input_and_options(actfn, new_outact)
                builder.remove_connectivity_and_invalidate(conv, actfn, selector)
            else:
                builder.remove_connectivity_and_invalidate(conv, selector)
            old_outact = selector.outacts[0]
            builder.add_output_map(new_outact, old_outact)
        return builder.build()


@SelectorRuleSet.register
class ReshapeSelector(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        (1,14,14,256)-[reshape]->(1,1,196,256)-[indexed_item_selector, axis=3]->(1,1,196,64)
            =>
        (1,14,14,256)-[indexed_item_selector, axis=3]->(1,14,14,64)-[reshape]->(1,1,196,64)
        """
        pat = find_operator_sequence(op, "R", LayerType.IndexedItemSelector)
        if pat is None:
            return None
        reshape, selector = pat
        if selector.options.axis not in (3, -1):
            return None
        reshape_inact = reshape.inacts[0]
        reshape_outact = reshape.outacts[0]
        if not (4 == reshape_inact.src_dim == reshape_outact.src_dim):
            return None
        if not (reshape_inact.src_shape[3] == reshape_outact.src_shape[3]):
            return None
        n0, h0, w0, c0 = reshape_inact.src_shape
        n1, h1, w1, c1 = reshape_outact.src_shape
        if 1 == n0 == n1 and c0 == c1:
            return reshape, selector
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, selector = self.matched_pattern
        inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(selector, new_inact)
        n, h, w, _ = reshape.outacts[0].src_shape
        selector_outact = selector.outacts[0]
        _, _, _, c = selector_outact.src_shape
        new_outact = builder.make_reshape(new_outact, (n, h, w, c))
        old_outact = selector.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, selector)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        """
        (1,1,64,4)-[reshape]->(1,64,4,1)-[indexed_item_selector, axis=3]->(1,64,4,8)-[reshape]->(1,1,64,32)
        """
        pat = find_operator_sequence(op, "R[11nc->1nc1]", LayerType.IndexedItemSelector)
        if pat is None:
            return None
        reshape0, selector = pat
        if selector.options.repeat is None:
            return None
        if selector.options.axis not in (3, -1):
            return None
        n, h, w, c = reshape0.inacts[0].src_shape
        if c > 1:
            pop = reshape0.inacts[0].producer_op
            if check_input_npu_stride(pop):
                return reshape0, selector
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape0, selector = self.matched_pattern
        inact = reshape0.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)

        in_ch = int(new_inact.src_shape[3])
        out_ch = int(selector.options.repeat * in_ch)
        repeat = selector.options.repeat
        eye = numpy.eye(in_ch, dtype="float32")
        weight = numpy.repeat(eye, repeat, axis=0)
        weight = weight.reshape(out_ch, in_ch, 1, 1)
        new_outact = builder.make_conv2d(
            new_inact, in_channels=in_ch, out_channels=out_ch, weight=weight
        )
        old_outact = selector.outacts[0]
        if new_outact.src_shape != old_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape0, selector)
        return builder.build()


@SelectorRuleSet.register
class TransposeSelector(TransformRule):
    # @pattern
    # def case_0231_selector_2(self, op: Operator, **kwargs):
    #     pat = find_operator_sequence(op, "T0231", LayerType.IndexedItemSelector)
    #     if pat is None:
    #         return None
    #     transpose, selector = pat
    #     if selector.options.axis != 2:
    #         return None
    #     transpose_inact = transpose.inacts[0]
    #     if not check_input_npu_stride(transpose_inact.producer_op):
    #         return None
    #     return transpose, selector
    #
    # @case_0231_selector_2.transform
    # def case_0231_selector_2(self, *args, **kwargs):
    #     builder = OpTransformResultV2Builder()
    #     transpose, selector = self.matched_pattern
    #     inact = transpose.inacts[0]
    #     new_inact = builder.copy_activationspec(inact, add_input_map=True)
    #     new_output = builder.with_new_input_and_options(selector, new_inact, axis=3)
    #     new_outact = builder.make_transpose(new_output, (0, 2, 3, 1))
    #     old_outact = selector.outacts[0]
    #     builder.add_output_map(new_outact, old_outact)
    #     builder.remove_connectivity_and_invalidate(transpose, selector)
    #     return builder.build()

    @pattern
    def case_0213_selector_2(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, "T0213", LayerType.IndexedItemSelector)
        if pat is None:
            return None
        transpose, selector = pat
        transpose_inact = transpose.inacts[0]
        if not check_input_npu_stride(transpose_inact.producer_op):
            return None
        if not (
            selector.options.axis == 2
            and selector.options.repeat is not None
            and 32 >= selector.options.repeat > 1
        ):
            return None
        selector_inact = selector.inacts[0]
        if selector_inact.src_shape[2] != 1:
            return None
        return pat

    @case_0213_selector_2.transform
    def case_0213_selector_2(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        transpose, selector = self.matched_pattern
        inact = transpose.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        out_channels = in_channels = int(new_inact.src_shape[-1])
        groups = in_channels
        kernel_h = stride_h = 1
        kernel_w = stride_w = int(selector.options.repeat)
        weight = numpy.zeros(
            (out_channels, in_channels // groups, kernel_h, kernel_w), dtype="float32"
        )
        weight[:, 0, 0, :] = 1.0
        west_padding = east_padding = kernel_w - 1

        new_outact = builder.make_transposeconv2d(
            new_inact,
            in_channels=in_channels,
            out_channels=out_channels,
            h_kernel=kernel_h,
            w_kernel=kernel_w,
            h_stride=stride_h,
            w_stride=stride_w,
            west_padding=west_padding,
            east_padding=east_padding,
            group_number=groups,
            weight=weight,
        )
        new_outact = builder.make_transpose(new_outact, (0, 2, 1, 3))
        old_outact = selector.outacts[0]
        if new_outact.src_shape != selector.outacts[0].src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(transpose, selector)
        return builder.build()


@SelectorRuleSet.register
class SelectorWhere(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.MaskedFill)
        if pat is None:
            return None
        masked_fill = pat[0]
        inact, mask = masked_fill.inacts
        if any(4 != a.src_dim or 1 != a.src_shape[0] for a in masked_fill.inacts):
            return None
        pat = find_operator_sequence(
            mask.producer_op, LayerType.IndexedItemSelector, "T0132", strict_search=True
        )
        if pat is None:
            return None
        selector, t0132 = pat
        if len(mask.consumer_ops) != 1:
            return None
        if not (
            selector.options.axis == 2
            and selector.options.repeat is not None
            and selector.options.repeat > 1
        ):
            return None
        if inact.src_shape[-1] > 1 and selector.inacts[0].src_shape[2] == 1:
            return selector, t0132, masked_fill
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        selector, t0132, masked_fill = self.matched_pattern
        selector_inact = selector.inacts[0]
        new_mask = builder.copy_activationspec(selector_inact, add_input_map=True)
        new_mask = builder.make_transpose(new_mask, (0, 1, 3, 2))
        old_inact = masked_fill.inacts[0]
        new_inact = builder.copy_activationspec(old_inact, add_input_map=True)
        new_outact = builder.make_masked_fill(
            x=new_inact, mask=new_mask, value=masked_fill.options.value
        )
        old_outact = masked_fill.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(selector, t0132, masked_fill)
        return builder.build()


@SelectorRuleSet.register
class SelectorBiop(TransformRule):
    @pattern
    def remove_broadcasting_selector(self, op: Operator, **kwargs):
        """
        remove selector when broadcasting case but not necesary.
        """
        if not is_biop_wrapper(op):
            return None
        biop = op
        for idx, inact in enumerate(biop.inacts):
            selector = inact.producer_op
            if (
                selector.layertype == LayerType.IndexedItemSelector
                and selector.options.repeat is not None
            ):
                axis = selector.options.axis
                if idx == 0:
                    other_inact = biop.inacts[1]
                else:
                    other_inact = biop.inacts[0]
                selector_inact = selector.inacts[0]
                if (
                    other_inact.src_shape[axis] > 1
                    and selector_inact.src_shape[axis] == 1
                ):
                    return selector, biop
        return None

    @remove_broadcasting_selector.transform
    def remove_broadcasting_selector(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        selector, biop = self.matched_pattern
        new_biop_inacts = []
        for inact in biop.inacts:
            if inact.producer_op.name == selector.name:
                new_inact = builder.copy_activationspec(
                    selector.inacts[0], add_input_map=True
                )
            else:
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_biop_inacts.append(new_inact)
        new_outact = builder.with_new_input_and_options(biop, *new_biop_inacts)
        old_outact = biop.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(selector, biop)
        return builder.build()


def _concat_axis3(op_):
    return op_.layertype == LayerType.Concatenate and op_.options.axis in (3, -1)


def _interpret_slice_wrapper(op):
    if op.layertype == LayerType.Slice:
        return interpret_slice(op.inacts[0].src_shape, op.options)
    if op.layertype == LayerType.IndexedItemSelector:
        options = SimpleNamespace()
        options.axis = (op.options.axis,)
        options.start = (op.options.start,)
        options.end = (op.options.end,)
        options.step = None if op.options.step is None else (op.options.step,)
        return interpret_slice(op.inacts[0].src_shape, options)
    raise ValueError(f"Unsupported op type: {op.layertype}")


@SelectorRuleSet.register
class ConcatenateSelector(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, _concat_axis3, LayerType.IndexedItemSelector)
        if pat is None:
            return None
        concat, selector = pat
        slice_inact = selector.inacts[0]
        if slice_inact.src_dim != 4:
            return None
        if selector.options.start is None:
            return None
        # fixme: dynamic and -1:max slice
        if slice_inact.src_shape[-1].dynamic:
            return None

        intervals = []
        acc = 0
        for inact in concat.inacts:
            c = int(inact.src_shape[-1])
            intervals.append((acc, acc + c))
            acc += c

        slices = []
        concat_outact = concat.outacts[0]
        for cop in concat_outact.consumer_ops:
            if (
                cop.layertype == LayerType.IndexedItemSelector
                and cop.options.start is not None
                and cop.options.axis
                in (
                    3,
                    -1,
                )
            ):
                s, e, st = _interpret_slice_wrapper(cop)
                for int_s, int_e in intervals:
                    if int_s <= s < e <= int_e:
                        slices.append(cop)
        if slices:
            return concat, slices
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        concat, slices = self.matched_pattern
        intervals = []
        acc = 0
        for inact in concat.inacts:
            c = int(inact.src_shape[-1])
            intervals.append((acc, acc + c, inact))
            acc += c

        for selector in slices:
            s, e, st = _interpret_slice_wrapper(selector)
            for int_s, int_e, inact in intervals:
                if int_s <= s < e <= int_e:
                    new_inact = builder.copy_activationspec(inact, add_input_map=True)
                    new_s = s - int_s
                    new_e = new_s + (e - s)
                    new_outact = builder.make_slice(
                        new_inact, axis=(3,), start=(new_s,), end=(new_e,), step=(st,)
                    )
                    old_outact = selector.outacts[0]
                    builder.add_output_map(new_outact, old_outact)
                    builder.remove_connectivity_and_invalidate(concat, selector)
        return builder.build()
