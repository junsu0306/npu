import math

import numpy

from mblt import Operator, LayerType
from mblt.core import TransformRule, pattern
from mblt.subgraph.util.pattern_util import find_operator_sequence
from ._ruleset import OperatorFusingRuleSet
from ...transform_result import OpTransformResultV2Builder


def _check_mulconst_tanh_plus1(op):
    pat = find_operator_sequence(
        op,
        LayerType.MultiplyConstant,
        LayerType.Tanh,
        LayerType.AddingConstant,
        strict_search=True,
    )
    if pat is not None:
        mc, tanh, ac = pat
        ac_value = ac.get_tensor(ac.options.constant).value
        if not (ac_value.size == 1 and ac_value.reshape(-1)[0] == 1):
            return None
        mc_value = mc.get_tensor(mc.options.constant).value
        if not (
            mc_value.size == 1
            and numpy.allclose(mc_value.reshape(-1)[0], 0.79788, atol=1e-07)
        ):
            return None
        return mc, tanh, ac
    return None


def _check_pow3(op):
    if op.layertype != LayerType.Multiply:
        return None
    inact0, inact1 = op.inacts
    if inact0.producer_op.layertype == LayerType.Multiply:
        pow2 = inact0.producer_op
        inact00, inact01 = pow2.inacts
        if inact00.name == inact01.name == inact1.name:
            return pow2, op
    if inact1.producer_op.layertype == LayerType.Multiply:
        pow2 = inact1.producer_op
        inact10, inact11 = pow2.inacts
        if inact10.name == inact11.name == inact0.name:
            return pow2, op
    if (
        inact0.producer_op.layertype == LayerType.Pow
        and inact0.producer_op.options.constant == 2
    ):
        pow2 = inact0.producer_op
        inact00 = pow2.inacts[0]
        if inact00.name == inact1.name:
            return pow2, op
    if (
        inact1.producer_op.layertype == LayerType.Pow
        and inact1.producer_op.options.constant == 2
    ):
        pow2 = inact1.producer_op
        inact10 = pow2.inacts[0]
        if inact10.name == inact0.name:
            return pow2, op
    return None


def _check_pow3_mul0044715(op):
    pat = find_operator_sequence(op, LayerType.Multiply, LayerType.MultiplyConstant)
    if pat is None:
        return None
    pow3, mc0044715 = pat
    const_val = mc0044715.get_tensor(mc0044715.options.constant).value
    if not (
        const_val.size == 1
        and numpy.allclose(const_val.reshape(-1)[0], 0.044715, atol=1e-07)
    ):
        return None
    pat = _check_pow3(pow3)
    if pat is None:
        return None
    pow2, pow3 = pat
    return pow2, pow3, mc0044715


def _check_pow3_mulconst_add(op):
    if op.layertype != LayerType.Adding:
        return None
    adding = op
    inact0, inact1 = adding.inacts
    pat = _check_pow3_mul0044715(inact0.producer_op)
    if pat is not None:
        pow2, pow3, mc0044715 = pat
        pow2_inact = pow2.inacts[0]
        if inact1.name == pow2_inact.name:
            return pow2, pow3, mc0044715, adding
    pat = _check_pow3_mul0044715(inact1.producer_op)
    if pat is not None:
        pow2, pow3, mc0044715 = pat
        pow2_inact = pow2.inacts[0]
        if inact0.name == pow2_inact.name:
            return pow2, pow3, mc0044715, adding
    return None


def _check_divconst_erf_addconst(op):
    pat = find_operator_sequence(
        op,
        LayerType.DivConstant,
        LayerType.Erf,
        LayerType.AddingConstant,
        strict_search=True,
    )
    if pat is not None:
        dc, erf, ac = pat
        dc_value = dc.get_tensor(dc.options.constant).value

        if not (
            dc_value.size == 1
            and numpy.abs(dc_value.reshape(-1)[0] - math.sqrt(2)) < 1e-5
        ):
            return None
    else:
        pat = find_operator_sequence(
            op,
            LayerType.MultiplyConstant,
            LayerType.Erf,
            LayerType.AddingConstant,
            strict_search=True,
        )
        if pat is not None:
            dc, erf, ac = pat
            mc_value = dc.get_tensor(dc.options.constant).value
            if not (
                mc_value.size == 1
                and numpy.abs(mc_value.reshape(-1)[0] - 1.0 / math.sqrt(2)) < 1e-5
            ):
                return None
        else:
            return None

    ac_value = ac.get_tensor(ac.options.constant).value
    if not (ac_value.size == 1 and ac_value.reshape(-1)[0] == 1):
        return None

    return dc, erf, ac


@OperatorFusingRuleSet.register
class Gelu(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Multiply:
            return None
        inact0 = op.inacts[0]
        inact1 = op.inacts[1]
        if inact0.src_dim < 2:
            return None

        if (pat := _check_divconst_erf_addconst(inact0.producer_op)) is not None:
            dc, erf, ac = pat
            if inact1.name != dc.inacts[0].name:
                return None
        elif (pat := _check_divconst_erf_addconst(inact1.producer_op)) is not None:
            dc, erf, ac = pat
            if inact0.name != dc.inacts[0].name:
                return None
        else:
            return None
        mul = op
        if (
            1 == len(mul.outacts[0].consumer_ops)
            and mul.outacts[0].consumer_ops[0].layertype == LayerType.MultiplyConstant
        ):
            half = mul.outacts[0].consumer_ops[0]
            half_value = half.get_tensor(half.options.constant).value
            if (
                half_value.size == 1
                and numpy.abs(half_value.reshape(-1)[0] - 0.5) < 1e-5
            ):
                return dc, erf, ac, mul, half
        return dc, erf, ac, mul, None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        dc, erf, ac, mul, half = self.matched_pattern
        inact = dc.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_gelu(new_inact, approximate=False)
        if half is None:
            outact = mul.outacts[0]
            new_outact = builder.make_mul(new_outact, 2)
            builder.add_output_map(new_outact, outact)
            builder.remove_connectivity_and_invalidate(dc, erf, ac, mul)
        else:
            outact = half.outacts[0]
            builder.add_output_map(new_outact, outact)
            builder.remove_connectivity_and_invalidate(dc, erf, ac, mul, half)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Multiply:
            return None

        def check(inact0, inact1):
            if inact0.src_dim < 2:
                return None
            if (pat := _check_mulconst_tanh_plus1(inact0.producer_op)) is not None:
                mc, tanh, plus1 = pat
                mc_inact = mc.inacts[0]
                pat = _check_pow3_mulconst_add(mc_inact.producer_op)
                if pat is None:
                    return None
                pow2, pow3, mc0044715, adding = pat
                pow2_inact = pow2.inacts[0]
                if inact1.name != pow2_inact.name:
                    return None
                pow2_inact = pow2.inacts[0]
                if pow2_inact.name == inact1.name:
                    return pow2, pow3, mc0044715, adding, mc, tanh, plus1, mul
            return None

        mul = op
        iact0, iact1 = mul.inacts
        pat = check(iact0, iact1)
        if pat is not None:
            return pat
        pat = check(iact1, iact0)
        if pat is not None:
            return pat
        return None

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        pow2, pow3, mc0044715, adding, mc, tanh, plus1, mul = self.matched_pattern
        inact = pow2.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_gelu(new_inact, approximate=True)
        new_outact = builder.make_mul(new_outact, 2)
        outact = mul.outacts[0]
        builder.add_output_map(new_outact, outact)
        builder.remove_connectivity_and_invalidate(adding, mc, tanh, plus1, mul)
        builder.remove_connectivity_and_invalidate(pow2, pow3, mc0044715, adding)
        return builder.build()


def _is_max(op, v=0):
    return (
        op.layertype == LayerType.Clip
        and op.options.clip_min_value == v
        and op.options.clip_max_value is None
    )


@OperatorFusingRuleSet.register
class Softplus(TransformRule):
    @pattern
    def base_case(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op,
            LayerType.Exp,
            LayerType.AddingConstant,
            LayerType.Log,
            strict_search=True,
        )
        if pat is None:
            return None
        exp_, addconst, log_ = pat
        ac_value = addconst.get_tensor(addconst.options.constant).value
        if ac_value.size == 1 and ac_value.reshape(-1)[0] == 1:
            return exp_, addconst, log_
        return pat

    @base_case.transform
    def base_case(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        exp_, addconst, log_ = self.matched_pattern
        inact = exp_.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_softplus(new_inact)
        old_outact = log_.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(exp_, addconst, log_)
        return builder.build()

    @pattern
    def numerical_stability(self, op: Operator, **kwargs):
        """
        softplus(-abs(0-x)) + max(0,x)
        softplus(-abs(x))) + max(0,x)
        """

        if op.layertype != LayerType.Adding:
            return None
        adding = op
        inact0, inact1 = adding.inacts

        def _seq(op):
            pat = find_operator_sequence(
                op,
                LayerType.SubConstant,
                LayerType.Abs,
                LayerType.Neg,
                LayerType.Softplus,
                strict_search=True,
            )
            if pat is not None:
                subconst, abs_, neg_, softplus = pat
                sc_value = subconst.get_tensor(subconst.options.constant).value
                if sc_value.size == 1 and sc_value.reshape(-1)[0] == 0:
                    return pat
            else:
                pat = find_operator_sequence(
                    op,
                    LayerType.Abs,
                    LayerType.Neg,
                    LayerType.Softplus,
                    strict_search=True,
                )
                return pat
            return None

        clip_ = None
        pat = None
        if (
            _is_max(inact0.producer_op, 0)
            and (pat := _seq(inact1.producer_op)) is not None
        ):
            clip_ = inact0.producer_op
        if (
            _is_max(inact1.producer_op, 0)
            and (pat := _seq(inact0.producer_op)) is not None
        ):
            clip_ = inact1.producer_op
        if clip_ is None:
            return None
        clip_inact = clip_.inacts[0]
        pat_inact = pat[0].inacts[0]
        if clip_inact.name != pat_inact.name:
            return None
        return clip_, pat, adding

    @numerical_stability.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        clip_, pat, adding = self.matched_pattern
        clip_inact = clip_.inacts[0]
        new_inact = builder.copy_activationspec(clip_inact, add_input_map=True)
        new_outact = builder.make_softplus(new_inact)
        old_outact = adding.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(clip_, adding)
        builder.remove_connectivity_and_invalidate(*pat, adding)
        return builder.build()

    @pattern
    def threshold(self, op: Operator, **kwargs):
        """
        if softplus(x) is inf:
            x
        else:
            softplus(x)
        """

        if op.layertype != LayerType.Where:
            return None
        where_ = op
        cond, x, y = where_.inacts
        if y.producer_op.layertype != LayerType.Softplus:
            return None
        softplus = y.producer_op
        softplus_inact = softplus.inacts[0]
        if x.name != softplus_inact.name:
            return None
        if cond.producer_op.layertype != LayerType.TensorCmp:
            return None
        cmp = cond.producer_op
        if cmp.options.kind != "eq":
            return None
        if (
            cmp.inacts[0].producer_op.name == softplus.name
            and cmp.inacts[1].producer_op.layertype == LayerType.InputConstant
        ):
            thres_op = cmp.inacts[1].producer_op
        elif (
            cmp.inacts[1].producer_op.name == softplus.name
            and cmp.inacts[0].producer_op.layertype == LayerType.InputConstant
        ):
            thres_op = cmp.inacts[0].producer_op
        else:
            return None
        thres_val = thres_op.get_tensor(thres_op.options.constant).value
        if thres_val.size != 1:
            return None
        return thres_op, cmp, softplus, where_

    @threshold.transform
    def threshold(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        thres_op, cmp, softplus, where_ = self.matched_pattern
        softplus_inact = softplus.inacts[0]
        new_inact = builder.copy_activationspec(softplus_inact, add_input_map=True)
        thres_val = thres_op.get_tensor(thres_op.options.constant).value
        thres_val = thres_val.reshape(-1)[0]
        if numpy.isinf(thres_val):
            new_outact = builder.make_softplus(new_inact)
        else:
            new_outact = builder.make_softplus(
                new_inact, threshold=thres_val.reshape(-1)[0]
            )
        old_outact = where_.outacts[0]
        builder.add_output_map(new_outact, old_outact)

        builder.remove_connectivity_and_invalidate(softplus, cmp)
        builder.remove_connectivity_and_invalidate(thres_op, cmp, where_)
        builder.remove_connectivity_and_invalidate(softplus, where_)
        return builder.build()


@OperatorFusingRuleSet.register
class Swish(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Multiply:
            return None
        inact0 = op.inacts[0]
        inact1 = op.inacts[1]
        if (
            1 == len(inact0.consumer_ops)
            and inact0.producer_op.layertype == LayerType.Sigmoid
        ):
            sigmoid = inact0.producer_op
            if sigmoid.inacts[0].name == inact1.name:
                return sigmoid, op
        if (
            1 == len(inact1.consumer_ops)
            and inact1.producer_op.layertype == LayerType.Sigmoid
        ):
            sigmoid = inact1.producer_op
            if sigmoid.inacts[0].name == inact0.name:
                return sigmoid, op
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        sigmoid, mul = self.matched_pattern
        inact = sigmoid.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_swish(new_inact)
        old_outact = mul.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(sigmoid, mul)
        return builder.build()


@OperatorFusingRuleSet.register
class Softmax(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Div:
            return None
        div = op
        inact0, inact1 = div.inacts
        if inact0.src_dim != 4:
            return None
        exp = inact0.producer_op
        if exp.layertype != LayerType.Exp:
            return None
        reduce_sum = inact1.producer_op
        if not (
            reduce_sum.layertype == LayerType.ReduceSum
            and reduce_sum.options.keep_dims
            and 1 == len(reduce_sum.options.reduce_axes)
        ):
            return None
        ax = reduce_sum.options.reduce_axes[0]
        exp_outact = exp.outacts[0]
        if exp_outact.name != reduce_sum.inacts[0].name:
            return None
        if 2 != len(exp_outact.consumer_ops):
            return None
        pat = find_operator_sequence(
            exp, LayerType.Sub, LayerType.Exp, strict_search=True
        )
        if pat is None:
            return None
        sub, _ = pat
        inact0, inact1 = sub.inacts
        reduce_max = inact1.producer_op
        if not (
            reduce_max.layertype == LayerType.ReduceMax
            and reduce_max.options.keep_dims
            and reduce_max.options.reduce_axes == (ax,)
        ):
            return None
        reduce_max_inact = reduce_max.inacts[0]
        if reduce_max_inact.name != inact0.name:
            return None
        return reduce_max, sub, exp, reduce_sum, div

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reduce_max, sub, exp, reduce_sum, div = self.matched_pattern
        inact = reduce_max.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        axis = reduce_max.options.reduce_axes[0]
        new_outact = builder.make_softmax(new_inact, axis=axis)
        old_outact = div.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reduce_sum, div)
        builder.remove_connectivity_and_invalidate(exp, div)
        builder.remove_connectivity_and_invalidate(sub, div)
        builder.remove_connectivity_and_invalidate(reduce_max, sub)
        return builder.build()


@OperatorFusingRuleSet.register
class Mish(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Multiply:
            return None
        mul = op
        inact0 = mul.inacts[0]
        inact1 = mul.inacts[1]
        pat0 = find_operator_sequence(
            inact0.producer_op, LayerType.Softplus, LayerType.Tanh
        )
        if pat0 is not None:
            softplus, tanh = pat0
            softplus_inact = softplus.inacts[0]
            if inact1.name == softplus_inact.name:
                return softplus, tanh, mul
        pat1 = find_operator_sequence(
            inact1.producer_op, LayerType.Softplus, LayerType.Tanh
        )
        if pat1 is not None:
            softplus, tanh = pat1
            softplus_inact = softplus.inacts[0]
            if inact0.name == softplus_inact.name:
                return softplus, tanh, mul
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        softplus, tanh, mul = self.matched_pattern
        inact = softplus.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_mish(new_inact)
        old_outact = mul.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(softplus, tanh, mul)
        return builder.build()

@OperatorFusingRuleSet.register
class Simoid(TransformRule):
    @staticmethod
    def _check_single_value(xconst):
        const_value = xconst.get_tensor(xconst.options.constant).value
        flat = const_value.reshape(-1)
        if flat.size == 0:
            return None
        if numpy.allclose(flat, flat[0]):
            return flat[0]
        return None
    
    @staticmethod
    def _check_mutiply_form(op):
        if op.layertype not in {LayerType.MultiplyConstant, LayerType.DivConstant}:
            return None

        value = Simoid._check_single_value(op)
        if value is None:
            return None
        if op.layertype == LayerType.MultiplyConstant:
            return True
        elif op.layertype == LayerType.DivConstant:
            if not op.options.is_const_first and not numpy.allclose(value, 0.0):
                return True

        return None

    @staticmethod
    def _check_add_form(op):
        if op.layertype not in {LayerType.AddingConstant, LayerType.SubConstant}:
            return None
        value = Simoid._check_single_value(op)
        if value is None:
            return None
        if op.layertype == LayerType.AddingConstant:
            if numpy.allclose(value, 1.0):
                return True
        elif op.layertype == LayerType.SubConstant:
            if numpy.allclose(value, -1.0) and not op.options.is_const_first:
                return True
        return None                
    
    @staticmethod
    def _check_last_divconst(op):
        if op.layertype != LayerType.DivConstant:
            return None

        value = Simoid._check_single_value(op)
        if value is None:
            return None
        if numpy.allclose(value, 1.0) and op.options.is_const_first:
            return True
        
        return None
    
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, self._check_mutiply_form, LayerType.Exp, self._check_add_form, self._check_last_divconst)
        if pat is not None:
            return pat
        return None

    @pattern
    def case1(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, self._check_mutiply_form, LayerType.Exp, self._check_add_form, self._check_last_divconst)
        if pat is not None:
            return None
        pat = find_operator_sequence(
            op, LayerType.Exp, self._check_add_form, self._check_last_divconst
        )
        if pat is not None:
            return pat
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        mulconst_like, exp, add_like, last_divconst = self.matched_pattern

        new_inact = builder.copy_activationspec(mulconst_like.inacts[0], add_input_map=True)
        mulconst_like_value = self._check_single_value(mulconst_like)
        if mulconst_like.layertype == LayerType.MultiplyConstant:
            alpha = -1 * mulconst_like_value
        elif mulconst_like.layertype == LayerType.DivConstant:
            alpha = -1 / mulconst_like_value
        else:
            raise ValueError(f"Unsupported layer type: {mulconst_like.layertype}")
        new_outact = builder.make_sigmoid(new_inact,alpha=alpha)
        old_outact = last_divconst.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(mulconst_like, exp, add_like, last_divconst)

        return builder.build()

    @case1.transform
    def case1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        exp, add_like, last_divconst = self.matched_pattern

        new_inact = builder.copy_activationspec(exp.inacts[0], add_input_map=True)
        new_outact = builder.make_sigmoid(new_inact)
        old_outact = last_divconst.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(exp, add_like, last_divconst)
        return builder.build()
