import functools

from mblt import Operator, LayerType
from mblt.core import TransformRule, pattern
from mblt.operator.utils import interpret_slice
from mblt.subgraph.util.pattern_util import find_operator_sequence
from ._ruleset import OperatorFusingRuleSet
from ...transform_result import OpTransformResultV2Builder


@OperatorFusingRuleSet.register
class PadGeneric(TransformRule):
    @pattern
    def input_pad_conv2d(self, op: Operator, **kwargs):
        def _is_conv_type(op):
            return op is not None and op.layertype in (
                LayerType.Convolution,
                LayerType.DepthwiseConvolution,
                LayerType.GroupConvolution,
            )

        pat = find_operator_sequence(op, LayerType.PadGeneric, _is_conv_type)
        if pat is None:
            return None
        pad, conv = pat
        if not (pad.options.pad_mode == "constant" and pad.options.constant == 0.0):
            return None
        if len(pad.options.padding_list) != 8:
            return None
        pad_begin, pad_end = pad.options.padding_list[:4], pad.options.padding_list[4:]
        if not (pad_begin[0] == pad_begin[-1] == pad_end[0] == pad_end[-1] == 0):
            return None
        return pad, conv

    @input_pad_conv2d.transform
    def input_pad_conv2d(self, *args, **kwargs):
        pad, conv = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = pad.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)

        pad_begin, pad_end = pad.options.padding_list[:4], pad.options.padding_list[4:]
        pad_h_front, pad_w_front = pad_begin[1:3]
        pad_h_back, pad_w_back = pad_end[1:3]

        # NPU's padding is south/north swapped.
        new_south_padding = pad_h_front + conv.options.south_padding
        new_north_padding = pad_h_back + conv.options.north_padding
        new_west_padding = pad_w_front + conv.options.west_padding
        new_east_padding = pad_w_back + conv.options.east_padding

        new_outact = builder.with_new_input_and_options(
            conv,
            new_inact,
            south_padding=new_south_padding,
            north_padding=new_north_padding,
            west_padding=new_west_padding,
            east_padding=new_east_padding,
        )
        old_outact = conv.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(pad, conv)
        return builder.build()

    @pattern
    def input_pad_maxpool2d(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.PadGeneric, LayerType.Pooling)
        if pat is None:
            return None
        pad, pooling = pat
        if pad.options.pad_mode != "-inf":
            return None
        if len(pad.options.padding_list) != 8:
            return None
        pad_begin, pad_end = pad.options.padding_list[:4], pad.options.padding_list[4:]
        if not (pad_begin[0] == pad_begin[-1] == pad_end[0] == pad_end[-1] == 0):
            return None
        if (
            pooling.options.pool_type.lower() == "maxpool"
            and pooling.options.pad_mode == "-inf"
        ):
            return pad, pooling
        return None

    @input_pad_maxpool2d.transform
    def input_pad_maxpool2d(self, *args, **kwargs):
        pad, pooling = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = pad.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)

        pad_begin, pad_end = pad.options.padding_list[:4], pad.options.padding_list[4:]
        pad_h_front, pad_w_front = pad_begin[1:3]
        pad_h_back, pad_w_back = pad_end[1:3]

        # NPU's padding is south/north swapped.
        new_south_padding = pad_h_front + pooling.options.south_padding
        new_north_padding = pad_h_back + pooling.options.north_padding
        new_west_padding = pad_w_front + pooling.options.west_padding
        new_east_padding = pad_w_back + pooling.options.east_padding

        new_outact = builder.with_new_input_and_options(
            pooling,
            new_inact,
            south_padding=new_south_padding,
            north_padding=new_north_padding,
            west_padding=new_west_padding,
            east_padding=new_east_padding,
        )
        old_outact = pooling.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(pad, pooling)

        return builder.build()

    @pattern
    def input_pad_avgpool2d(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.PadGeneric, LayerType.Pooling)
        if pat is None:
            return None
        pad, pooling = pat
        if pad.options.pad_mode != "constant":
            return None
        if len(pad.options.padding_list) != 8:
            return None
        pad_begin, pad_end = pad.options.padding_list[:4], pad.options.padding_list[4:]
        if not (pad_begin[0] == pad_begin[-1] == pad_end[0] == pad_end[-1] == 0):
            return None
        if not (
            pooling.options.pool_type.lower() == "avgpool"
            and pooling.options.pad_mode == "constant"
        ):
            return None

        if (
            0
            == pooling.options.west_padding
            == pooling.options.east_padding
            == pooling.options.north_padding
            == pooling.options.south_padding
        ):
            return pad, pooling
        else:
            if pooling.options.is_include_pad:
                return pad, pooling
        return None

    @input_pad_avgpool2d.transform
    def input_pad_avgpool2d(self, *args, **kwargs):
        pad, pooling = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = pad.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)

        pad_begin, pad_end = pad.options.padding_list[:4], pad.options.padding_list[4:]
        pad_h_front, pad_w_front = pad_begin[1:3]
        pad_h_back, pad_w_back = pad_end[1:3]

        # NPU's padding is south/north swapped.
        new_south_padding = pad_h_front + pooling.options.south_padding
        new_north_padding = pad_h_back + pooling.options.north_padding
        new_west_padding = pad_w_front + pooling.options.west_padding
        new_east_padding = pad_w_back + pooling.options.east_padding

        new_outact = builder.with_new_input_and_options(
            pooling,
            new_inact,
            south_padding=new_south_padding,
            north_padding=new_north_padding,
            west_padding=new_west_padding,
            east_padding=new_east_padding,
            is_include_pad=True,
        )
        old_outact = pooling.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(pad, pooling)

        return builder.build()


def _pad_check(op, pad_value, padding_list):
    return (
        op.layertype == LayerType.PadGeneric
        and op.options.pad_mode == "constant"
        and op.options.constant == pad_value
        and op.options.padding_list == padding_list
    )


@OperatorFusingRuleSet.register
class StaggeredPadding(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        case0) w < c,  c + w - 1 > (c - w) * 2
        (1,64,16,31)-[pad, (0,1) ]->(1,64,16,32)
                    -[reshape]->(1,1,64,512) / (x,y,...) + (512,)
                    -[pad, (0,c-w)]->(1,1,64,527) / (x,y,...) + (527,)
                    -[reshape]->(1,64,17,31) / (x,y,...) + (17,31)
                    -[slice]->(1,64,16,16) / (x,y,...) + (16,16))
        =>StaggeredPadding with window_size=c-w
        """

        pad_check0 = functools.partial(
            _pad_check, pad_value=0, padding_list=(0, 0, 0, 0, 0, 0, 0, 1)
        )

        pat = find_operator_sequence(
            op,
            pad_check0,
            "R[1hwc->11h(wc)]",
            LayerType.PadGeneric,
            "R[11h(wc)->1hwc]",
            strict_search=True,
        )
        if pat is None:
            return None
        pad0, reshape0, pad1, reshape1 = pat
        pad0_inact = pad0.inacts[0]
        if any(x.dynamic for x in pad0_inact.src_shape):
            return None
        n, h, w, c = map(int, pad0_inact.src_shape)
        if not (w < c and c + w - 1 > (c - w) * 2):
            return None
        if not _pad_check(pad1, 0, (0, 0, 0, 0, 0, 0, 0, c - w)):
            return None
        reshape1_outact = reshape1.outacts[0]
        if reshape1_outact.src_shape[1:] != (h, w + 1, c):
            return None

        pat = find_operator_sequence(
            reshape1, "R S[2] S[3]", strict_search=True, direction="fwd"
        )
        if pat is not None:
            reshape, slice2, slice3 = pat
            slice_order = "23"
        else:
            pat = find_operator_sequence(
                reshape1, "R S[3] S[2]", strict_search=True, direction="fwd"
            )
            if pat is None:
                return None
            reshape, slice3, slice2 = pat
            slice_order = "32"
        start, end, step = interpret_slice(slice2.inacts[0].src_shape, slice2.options)
        if (start, end, step) != (0, w, 1):
            return None
        start, end, step = interpret_slice(slice3.inacts[0].src_shape, slice3.options)
        if (start, end, step) != (c - w, int(slice3.inacts[0].src_shape[-1]), 1):
            return None
        return pad0, reshape0, pad1, reshape1, slice2, slice3, slice_order

    @case0.transform
    def case0(self, *args, **kwargs):
        pad0, reshape0, pad1, reshape1, slice2, slice3, slice_order = (
            self.matched_pattern
        )
        builder = OpTransformResultV2Builder()
        pad0_inact = pad0.inacts[0]
        n, h, w, c = map(int, pad0_inact.src_shape)
        new_inact = builder.copy_activationspec(pad0_inact, add_input_map=True)
        new_outact = builder.make_staggered_padding(
            new_inact, axis=3, reverse=False, window_size=(c - w)
        )
        if slice_order == "23":
            old_outact = slice3.outacts[0]
            builder.remove_connectivity_and_invalidate(
                pad0, reshape0, pad1, reshape1, slice2, slice3
            )
        elif slice_order == "32":
            old_outact = slice2.outacts[0]
            builder.remove_connectivity_and_invalidate(
                pad0, reshape0, pad1, reshape1, slice3, slice2
            )
        else:
            raise NotImplementedError("slice_order must be 23 or 32")
        builder.add_output_map(new_outact, old_outact)

        return builder.build()
