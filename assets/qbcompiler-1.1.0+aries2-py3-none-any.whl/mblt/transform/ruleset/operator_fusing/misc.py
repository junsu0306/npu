import numpy

from mblt import Operator, LayerType
from mblt.core import TransformRule, pattern
from mblt.operator.utils import interpret_slice
from mblt.subgraph.util.pattern_util import (
    find_operator_sequence,
    is_basic_npu_op,
)
from ._ruleset import OperatorFusingRuleSet
from ...transform_result import OpTransformResultV2Builder


@OperatorFusingRuleSet.register
class Space2Depth(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        (1,224,224,3)-[OrderedPatchify order=0]->(1,3136,16,3)-[Reshape]->(1,56,56,48)
        """
        pat = find_operator_sequence(op, LayerType.OrderedPatchify, LayerType.Reshape)
        if pat is None:
            return None
        patchify, reshape = pat
        if patchify.options.order != 0:
            return None
        reshape_inact = reshape.inacts[0]
        reshape_outact = reshape.outacts[0]
        if reshape_outact.src_dim != 4:
            return None
        c0, c1 = map(int, reshape_inact.src_shape[-2:])
        n, h, w, c = map(int, reshape_outact.src_shape)
        if (
            n == 1
            and int(c0) == patchify.options.h_kernel * patchify.options.w_kernel
            and c == c0 * c1
        ):
            return patchify, reshape
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        patchify, reshape = self.matched_pattern
        inact = patchify.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        h_kernel = patchify.options.h_kernel
        w_kernel = patchify.options.w_kernel
        in_channels = int(new_inact.src_shape[-1])
        out_channels = int(new_inact.src_shape[-1]) * h_kernel * w_kernel
        weight = (
            numpy.eye(out_channels, dtype="float32")
            .reshape(out_channels, h_kernel, w_kernel, in_channels)
            .transpose(0, 3, 1, 2)
        )
        new_outact = builder.make_conv2d(
            new_inact,
            in_channels=in_channels,
            out_channels=out_channels,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            h_stride=h_kernel,
            w_stride=w_kernel,
            weight=weight,
        )
        old_outact = reshape.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(patchify, reshape)
        return builder.build()


@OperatorFusingRuleSet.register
class Focus(TransformRule):
    @pattern
    def case_channel_first(self, op: Operator, *args, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.Concatenate, "T0231", is_basic_npu_op
        )
        if pat is None:
            return None
        concat, t0231, npu_op = pat
        if not (
            concat.layertype == LayerType.Concatenate
            and concat.options.axis == 1
            and len(concat.options.inputs) == 4
        ):
            return None

        # todo: generalize
        stride2 = 2
        stride3 = 2

        slices = []
        ref_inact = None
        for i, inact in enumerate(concat.inacts):
            pat_i = find_operator_sequence(inact.producer_op, "S[2] S[3]")
            if pat_i is None:
                return None
            slice2, slice3 = pat_i
            slice2_inact = slice2.inacts[0]
            if ref_inact is None:
                ref_inact = slice2_inact
            else:
                if ref_inact.name != slice2_inact.name:
                    return None

            slice2_inact_src_shape = slice2_inact.src_shape
            start, end, step = interpret_slice(slice2_inact_src_shape, slice2.options)
            _, start_ref = divmod(i, 2)  # (0,1,0,1)
            if stride2 is None:
                stride2 = step
            else:
                if stride2 != step:
                    return None
            if not (
                start == start_ref
                and slice2.options.end[0] >= int(slice2_inact_src_shape[2])  # free end
            ):
                return None
            if stride3 is None:
                stride3 = step
            else:
                if stride3 != step:
                    return None
            slice3_inact = slice3.inacts[0]  # (0,0,1,1)
            slice3_inact_src_shape = slice3_inact.src_shape
            start, end, step = interpret_slice(slice3_inact_src_shape, slice3.options)
            start_ref = 0 if i < 2 else 1
            if not (
                start == start_ref
                and slice3.options.end[0] >= int(slice3_inact_src_shape[3])
            ):
                return None
            slices.append(pat_i)
        if stride2 > 1 and stride3 > 1:
            return slices, concat, t0231, npu_op
        return None

    def get_focus_fused_conv_weight(
        self, conv_weight: numpy.ndarray, slice_output_ch_idx: numpy.ndarray
    ) -> numpy.ndarray:
        """Get new conv weight after fusing focus module into the following conv when focus module consists of slice and concat

        Args:
            weight (numpy.ndarray):
            slice_output_ch_idx (numpy.ndarray): Concat order of the input patches where each patch is the output of slice

        Returns:
            new_weight (numpy.ndarray): new conv weight
        """
        if slice_output_ch_idx.ndim != 2:
            raise NotImplementedError(
                "slice_output_ch_idx.ndim != 2 is unsupported, but got slice_output_ch_idx.ndim = ",
                slice_output_ch_idx.ndim,
            )

        out_ch, in_ch_after, k_h, k_w = conv_weight.shape
        m, n = slice_output_ch_idx.shape

        if in_ch_after % (m * n) != 0:
            raise ValueError(
                "conv_weight.shape[0] must be a mulitple of the number of patches from the input slices."
            )

        in_ch = in_ch_after // (m * n)
        new_conv_weight = numpy.zeros(
            (out_ch, in_ch, k_h * m, k_w * n), dtype=numpy.float32
        )

        for i in range(m):
            for j in range(n):
                idx = slice_output_ch_idx[i, j]
                start_ch = idx * in_ch
                end_ch = start_ch + in_ch
                new_conv_weight[:, :, i::m, j::n] = conv_weight[
                    :, start_ch:end_ch, :, :
                ]

        return new_conv_weight

    def _make_single(self, slices, concat, transpose, conv):
        builder = OpTransformResultV2Builder()
        inact = slices[0][0].inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_inact = builder.make_transpose(new_inact, (0, 2, 3, 1))

        # copied from old implementation
        # Initialize slice_output_pos, slice_output_ch_idx
        slice0, slice1 = slices[0]  # we are in  ax=2, ax=3 order
        m = slice0.options.step[0]
        n = slice1.options.step[0]

        slice_output_ch_idx = numpy.zeros((m, n)).astype(int)

        for i, (slice2, slice3) in enumerate(slices):
            h_coord = slice2.options.start[0]
            w_coord = slice3.options.start[0]
            slice_output_ch_idx[h_coord, w_coord] = i

        old_conv_weight = conv.get_tensor(conv.options.weight).value
        new_conv_weight = self.get_focus_fused_conv_weight(
            old_conv_weight, slice_output_ch_idx
        )

        if conv.options.bias != -1:
            new_bias = conv.get_tensor(conv.options.bias).value
        else:
            new_bias = None

        new_outact = builder.make_conv2d(
            new_inact,
            in_channels=int(new_inact.src_shape[-1]),
            out_channels=conv.options.out_channels,
            h_kernel=conv.options.h_kernel * m,
            w_kernel=conv.options.w_kernel * n,
            h_stride=conv.options.h_stride * m,
            w_stride=conv.options.w_stride * n,
            h_dilation=1,
            w_dilation=1,
            west_padding=conv.options.west_padding * n,
            east_padding=conv.options.east_padding * n,
            north_padding=conv.options.north_padding * m,
            south_padding=conv.options.south_padding * m,
            group_number=1,
            weight=new_conv_weight,
            bias=new_bias,
        )
        old_outact = conv.outacts[0]
        builder.add_output_map(new_outact, old_outact)

        for slice2, slice3 in slices:
            builder.remove_connectivity_and_invalidate(slice2, slice3, concat)

        builder.remove_connectivity_and_invalidate(concat, transpose, conv)

        return builder.build()

    @case_channel_first.transform
    def case_channel_first(self, *args, **kwargs):
        USE_CONV = True

        slices, concat, t0231, npu_op = self.matched_pattern

        def npu_op_check(conv):
            if conv.layertype != LayerType.Convolution:
                return False
            opt = conv.options
            return (
                1 == opt.group_number
                and 1
                == opt.h_dilation
                == opt.w_dilation
                == opt.h_stride
                == opt.w_stride
            )

        USE_SINGLE = npu_op_check(npu_op)

        if USE_CONV:
            if USE_SINGLE:
                return self._make_single(slices, concat, t0231, npu_op)
            else:
                builder = OpTransformResultV2Builder()
                inact = slices[0][0].inacts[0]
                new_inact = builder.copy_activationspec(inact, add_input_map=True)
                new_inact = builder.make_transpose(new_inact, (0, 2, 3, 1))

                in_channels = int(new_inact.src_shape[-1])
                stride2 = slices[0][0].options.step[0]  # = 2
                stride3 = slices[0][1].options.step[0]  # = 2

                out_channels = int(in_channels * stride2 * stride3)  # = 4C

                weight = numpy.zeros(
                    (out_channels, in_channels, stride2, stride3), dtype="float32"
                )
                oc = 0
                for idx, (slice2, slice3) in enumerate(slices):
                    for ic in range(in_channels):
                        i = slice2.options.start[0]
                        j = slice3.options.start[0]
                        weight[oc, ic, i, j] = 1.0
                        oc += 1

                new_outact = builder.make_conv2d(
                    new_inact,
                    in_channels=in_channels,
                    out_channels=out_channels,
                    group_number=1,
                    h_kernel=stride2,
                    w_kernel=stride3,
                    h_stride=stride2,
                    w_stride=stride3,
                    h_dilation=1,
                    w_dilation=1,
                    weight=weight,
                )

                # NHWC → NCHW
                new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))

                old_outact = concat.outacts[0]
                builder.add_output_map(new_outact, old_outact)

                for slice2, slice3 in slices:
                    builder.remove_connectivity_and_invalidate(slice2, slice3, concat)

                return builder.build()

        else:
            builder = OpTransformResultV2Builder()
            inact = slices[0][0].inacts[0]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            new_inact = builder.make_transpose(new_inact, (0, 2, 3, 1))
            new_concat_inacts = []
            for slice2, slice3 in slices:
                start2 = slice2.options.start[0]
                stride2 = slice2.options.step[0]
                start3 = slice3.options.start[0]
                stride3 = slice3.options.step[0]
                in_channels = int(new_inact.src_shape[-1])
                slice3_outact = slice3.outacts[0]
                out_channels = int(slice3_outact.src_shape[1])
                weight = numpy.zeros(
                    (out_channels, 1, stride2, stride3), dtype="float32"
                )
                weight[:, 0, start2, start3] = 1.0
                new_outact = builder.make_depthwise_conv2d(
                    new_inact,
                    in_channels=in_channels,
                    out_channels=out_channels,
                    h_kernel=stride2,
                    w_kernel=stride3,
                    h_stride=stride2,
                    w_stride=stride3,
                    h_dilation=1,
                    w_dilation=1,
                    weight=weight,
                )
                new_concat_inacts.append(new_outact)
                builder.remove_connectivity_and_invalidate(slice2, slice3, concat)
            new_outact = builder.make_concatenate(new_concat_inacts, axis=3)
            new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
            old_outact = concat.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            return builder.build()


@OperatorFusingRuleSet.register
class RotateHalf(TransformRule):
    @pattern
    def type0(self, op: Operator, **kwargs):
        if not (op.layertype == LayerType.Concatenate and op.options.axis in (-1, 3)):
            return None
        concat = op
        concat_outact = concat.outacts[0]
        if concat_outact.src_dim != 4:
            return None
        concat_inact0 = concat.inacts[0]
        concat_inact1 = concat.inacts[1]
        pat0 = find_operator_sequence(
            concat_inact0.producer_op, "S[3]", LayerType.Neg, strict_search=True
        )
        if pat0 is None:
            return None
        slice2, neg = pat0
        slice2_inact = slice2.inacts[0]
        mid = int(slice2_inact.src_shape[-1]) // 2
        if not (
            slice2.options.start == (mid,)
            and (slice2.options.step is None or slice2.options.step == (1,))
            and slice2.options.end[0] >= slice2_inact.src_shape[3]
        ):
            return None
        slice1 = concat_inact1.producer_op
        slice1_inact = slice1.inacts[0]
        if not (
            slice1.options.axis in ((-1,), (3,))
            and slice1.options.start == (0,)
            and (slice1.options.step is None or slice1.options.step == (1,))
            and slice1.options.end[0] >= slice1_inact.src_shape[3]
        ):
            return None
        if slice1.inacts[0].name != slice2.inacts[0].name:
            return None

        return pat0, slice1, concat

    @type0.transform
    def type0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        pat0, slice1, concat = self.matched_pattern
        inact = pat0[0].inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_rotate_half(new_inact, type=0)
        old_outact = concat.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(*pat0, concat)
        builder.remove_connectivity_and_invalidate(slice1, concat)
        builder.remove_connectivity_and_invalidate(concat)
        return builder.build()

    @pattern
    def type1(self, op: Operator, **kwargs):
        if not (op.layertype == LayerType.Concatenate and op.options.axis in (-1, 4)):
            return None
        concat = op
        concat_outact = concat.outacts[0]
        if concat_outact.src_dim != 5:
            return None
        if concat_outact.src_shape[-1] != 2:
            return None
        concat_inact0 = concat.inacts[0]
        concat_inact1 = concat.inacts[1]
        pat0 = find_operator_sequence(
            concat_inact0.producer_op, "S[3]", LayerType.Neg, "R[1hwc->1hwc1]"
        )
        if pat0 is None:
            return None
        slice2, neg, reshape2 = pat0
        slice2_inact = slice2.inacts[0]
        if not (
            slice2.options.start == (1,)
            and slice2.options.step == (2,)
            and slice2.options.end[0] >= slice2_inact.src_shape[3]
        ):
            return None

        pat1 = find_operator_sequence(
            concat_inact1.producer_op, "S[3]", "R[1hwc->1hwc1]"
        )
        if pat1 is None:
            return None
        slice1, reshape1 = pat1
        slice1_inact = slice1.inacts[0]
        if not (
            slice1.options.start == (0,)
            and slice1.options.step == (2,)
            and slice1.options.end[0] >= slice1_inact.src_shape[3]
        ):
            return None
        if slice1.inacts[0].name != slice2.inacts[0].name:
            return None

        return pat0, pat1, concat

    @type1.transform
    def type1(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        pat0, pat1, concat = self.matched_pattern
        inact = pat0[0].inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_rotate_half(new_inact, type=1)
        old_outact = concat.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(*pat0, concat)
        builder.remove_connectivity_and_invalidate(*pat1, concat)
        builder.remove_connectivity_and_invalidate(concat)
        return builder.build()
