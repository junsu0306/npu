from mblt.core import RuleSet

OperatorFusingRuleSet = RuleSet("OperatorFusingRuleSet")
