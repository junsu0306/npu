import numpy

from mblt import Operator, LayerType
from mblt.core import TransformRule, pattern
from mblt.subgraph.util.pattern_util import find_operator_sequence
from ._ruleset import OperatorFusingRuleSet
from ...transform_result import OpTransformResultV2Builder


def _broadcast_const_to_vec(const, c):
    if const.size == 1:
        return numpy.full((c,), fill_value=const.reshape(-1)[0])
    return const


@OperatorFusingRuleSet.register
class Centering(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        x - mean(x, axes)
        """
        if op.layertype != LayerType.Sub:
            return None
        sub = op
        inact0, inact1 = sub.inacts
        if inact1.producer_op.layertype != LayerType.ReduceMean:
            return None
        reducemean = inact1.producer_op
        if reducemean.options.keep_dims:
            reducemean_inact = reducemean.inacts[0]
            if reducemean_inact.name == inact0.name:
                return reducemean, sub
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        reducemean, sub = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reducemean.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_mean_centering(
            new_inact,
            axes=reducemean.options.reduce_axes,
        )
        old_outact = sub.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reducemean, sub)

        return builder.build()


def _check_pow2(op):
    return op.layertype == LayerType.Pow and op.options.exponent == 2


def _check_rsqrt(op):
    return op.layertype == LayerType.Rsqrt or (
        op.layertype == LayerType.Pow and op.options.exponent == -0.5
    )


def _check_sqrt(op):
    return op.layertype == LayerType.Sqrt or (
        op.layertype == LayerType.Pow and op.options.exponent == 0.5
    )


def _check_epsilon_add(op, atol=1e-3):
    if op.layertype == LayerType.AddingConstant:
        eps = op.get_tensor(op.options.constant).value
        if eps.size != 1:
            return False
        if not numpy.all(numpy.isfinite(eps)):
            return False
        if numpy.min(eps) < 0:
            return False
        if numpy.max(numpy.abs(eps)) > atol:
            return False
        return True


@OperatorFusingRuleSet.register
class ReduceRMS(TransformRule):
    @pattern
    def rsqrt(self, op: Operator, **kwargs):
        """
        pow(2)-reducemean-rsqrt
        pow(2)-reducemean-addconst(near 0)-rsqrt
        =>RMS-div
        """
        pat = find_operator_sequence(
            op, _check_pow2, LayerType.ReduceMean, _check_rsqrt
        )
        if pat is not None:
            pow2, reducemean, rsqrt = pat
            return pow2, reducemean, None, rsqrt

        pat = find_operator_sequence(
            op, LayerType.Pow, LayerType.ReduceMean, _check_epsilon_add, _check_rsqrt
        )
        return pat

    @rsqrt.transform
    def rsqrt(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        pow2, reducemean, epsilon_add, rsqrt = self.matched_pattern
        inact = pow2.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)

        if epsilon_add is not None:
            eps = epsilon_add.get_tensor(epsilon_add.options.constant).value
            eps = float(eps.reshape(-1)[0])
            builder.remove_connectivity_and_invalidate(
                pow2, reducemean, epsilon_add, rsqrt
            )
        else:
            eps = None
            builder.remove_connectivity_and_invalidate(pow2, reducemean, rsqrt)

        new_outact = builder.make_reduce_rms(
            new_inact,
            reduce_axes=reducemean.options.reduce_axes,
            keep_dims=reducemean.options.keep_dims,
            epsilon=eps,
        )
        new_outact = builder.make_div(1, new_outact)
        old_outact = rsqrt.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        return builder.build()

    @pattern
    def sqrt_shape_fix(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, _check_pow2, LayerType.ReduceMean, _check_epsilon_add, "R", _check_sqrt
        )
        if pat is not None:
            _, _, _, reshape, sqrt = pat
            return reshape, sqrt
        return None

    @sqrt_shape_fix.transform
    def sqrt_shape_fix(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        reshape, sqrt = self.matched_pattern
        reshape_inact = reshape.inacts[0]
        new_inact = builder.copy_activationspec(reshape_inact, add_input_map=True)
        new_outact = builder.with_new_input_and_options(sqrt, new_inact)
        old_outact = sqrt.outacts[0]
        if old_outact.src_shape != new_outact.src_shape:
            new_outact = builder.make_reshape(new_outact, old_outact.src_shape)
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reshape, sqrt)
        return builder.build()

    @pattern
    def sqrt(self, op: Operator, **kwargs):
        """
        pow(2)-reducemean-pow(0.5)
        pow(2)-reducemean-sqrt
        pow(2)-reducemean-addconst(near 0)-sqrt
        pow(2)-reducemean-addconst(near 0)-pow(0.5)

        pow(2)-reducemean-addconst(near 0)-[reshape]sqrt
        """
        pat = find_operator_sequence(op, _check_pow2, LayerType.ReduceMean, _check_sqrt)
        if pat is not None:
            pow2, reducemean, sqrt = pat
            return pow2, reducemean, None, sqrt
        pat = find_operator_sequence(
            op, LayerType.Pow, LayerType.ReduceMean, _check_epsilon_add, _check_sqrt
        )
        return pat

    @sqrt.transform
    def sqrt(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        pow2, reducemean, epsilon_add, sqrt = self.matched_pattern
        inact = pow2.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        if epsilon_add is not None:
            eps = epsilon_add.get_tensor(epsilon_add.options.constant).value
            eps = float(eps.reshape(-1)[0])
            builder.remove_connectivity_and_invalidate(
                pow2, reducemean, epsilon_add, sqrt
            )
        else:
            eps = None
            builder.remove_connectivity_and_invalidate(pow2, reducemean, sqrt)
        new_outact = builder.make_reduce_rms(
            new_inact,
            reduce_axes=reducemean.options.reduce_axes,
            keep_dims=reducemean.options.keep_dims,
            epsilon=eps,
        )
        old_outact = sqrt.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        return builder.build()


@OperatorFusingRuleSet.register
class RMSNormalization(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        (1,32,192)-|-reduce_rms-divconst(1)-mulconst-|-multiply->(1,32,192)
                   |---------------------------------|

        (1,32,192)-|-subconst-reduce_rms-divconst(1)-mulconst-|-multiply->(1,32,192)
                   |-------------------------------------------|
        """
        if op.layertype != LayerType.Multiply:
            return None
        mul = op

        def f(left_inact, right_inact):
            pat = find_operator_sequence(
                left_inact.producer_op,
                LayerType.ReduceRMS,
                LayerType.DivConstant,
                LayerType.MultiplyConstant,
            )
            if pat is None:
                return None
            reducerms, divconst, scale = pat
            reducerms_inact = reducerms.inacts[0]
            dim = reducerms_inact.src_dim
            if reducerms.options.reduce_axes not in ((-1,), (dim - 1,)):
                return None

            c = reducerms_inact.src_shape[-1]
            divconst_val = divconst.get_tensor(divconst.options.constant).value
            if not (
                divconst.options.is_const_first
                and (divconst_val.size == 1 or divconst_val.shape == (c,))
                and divconst_val.reshape(-1)[0] == 1
            ):
                return None

            if reducerms_inact.name == right_inact.name:
                return None, reducerms, divconst, scale
            reduce_pop = reducerms_inact.producer_op
            if not reduce_pop.valid:
                return None
            if reduce_pop.layertype in (
                LayerType.SubConstant,
                LayerType.AddingConstant,
            ):
                center = reduce_pop
                subconst_inact = center.inacts[0]
                if subconst_inact.name != right_inact.name:
                    return None
                subconst_val = center.get_tensor(center.options.constant).value
                if subconst_val.size == 1 or subconst_val.shape == (c,):
                    return center, reducerms, divconst, scale
            return None

        inact0, inact1 = mul.inacts
        pat = f(inact0, inact1)
        if pat is None:
            pat = f(inact1, inact0)
        if pat is None:
            return None
        center, reducerms, divconst, scale = pat

        return center, reducerms, divconst, scale, mul

    @case0.transform
    def case0(self, *args, **kwargs):
        center, reducerms, divconst, mulconst, mul = self.matched_pattern
        builder = OpTransformResultV2Builder()

        if center is None:
            inact = reducerms.inacts[0]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            center_val = None
        else:
            inact = center.inacts[0]
            new_inact = builder.copy_activationspec(inact, add_input_map=True)
            center_val = center.get_tensor(center.options.constant).value
            if center.layertype == LayerType.AddingConstant:
                center_val = -center_val
        c = new_inact.src_shape[-1]
        if center_val is not None:
            center_val = _broadcast_const_to_vec(center_val, c)
        scale = mulconst.get_tensor(mulconst.options.constant).value
        if scale is not None:
            scale = _broadcast_const_to_vec(scale, c)

        if reducerms.options.epsilon is not None:
            epsilon = reducerms.options.epsilon
        else:
            epsilon = numpy.finfo(numpy.float32).eps

        new_outact = builder.make_rmsnorm(
            new_inact,
            epsilon=epsilon,
            rms_center=center_val,
            scale=scale,
        )
        old_outact = mul.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        if center is None:
            builder.remove_connectivity_and_invalidate(
                reducerms, divconst, mulconst, mul
            )
        else:
            builder.remove_connectivity_and_invalidate(
                center, reducerms, divconst, mulconst, mul
            )
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        """
        (1,x,c)-reshape->(1,1,x,c)-|-reduce_rms-divconst(is_constant True, value 1)
        ->reshape->(1,x,1)->multiply(1,x,c)->reshape->(1,1,x,c)->mulconst(scale)
        """

        pat = find_operator_sequence(
            op,
            LayerType.Multiply,
            "R[1ab->11ab]",
            LayerType.MultiplyConstant,
            strict_search=True,
        )
        if pat is None:
            return None
        mul, reshape_tail, mulconst = pat

        def _match_branch(norm_inact, x_inact):
            reshape_back = norm_inact.producer_op
            if reshape_back is None or reshape_back.layertype != LayerType.Reshape:
                return None
            pat = find_operator_sequence(
                reshape_back,
                "R[1ab->11ab]",
                LayerType.ReduceRMS,
                LayerType.DivConstant,
                "R[11x1->1x1]",
                strict_search=True,
            )
            if pat is None:
                return None
            reshape_head, reducerms, divconst, reshape_back = pat

            reducerms_inact = reducerms.inacts[0]
            dim = reducerms_inact.src_dim
            if reducerms.options.reduce_axes not in ((-1,), (dim - 1,)):
                return None
            if not reducerms.options.keep_dims:
                return None

            c = reducerms_inact.src_shape[-1]
            divconst_val = divconst.get_tensor(divconst.options.constant).value
            if not (
                divconst.options.is_const_first
                and (divconst_val.size == 1 or divconst_val.shape == (c,))
                and divconst_val.reshape(-1)[0] == 1
            ):
                return None

            reshape_head_inact = reshape_head.inacts[0]
            if reshape_head_inact.name != x_inact.name:
                return None

            return reshape_head, reducerms, divconst, reshape_back

        left_inact, right_inact = mul.inacts
        pat = _match_branch(left_inact, right_inact)
        if pat is None:
            pat = _match_branch(right_inact, left_inact)
        if pat is None:
            return None
        reshape_head, reducerms, divconst, reshape_back = pat
        return (
            reshape_head,
            reducerms,
            divconst,
            reshape_back,
            mul,
            reshape_tail,
            mulconst,
        )

    @case1.transform
    def case1(self, *args, **kwargs):
        (
            reshape_head,
            reducerms,
            divconst,
            reshape_back,
            mul,
            reshape_tail,
            mulconst,
        ) = self.matched_pattern
        builder = OpTransformResultV2Builder()

        outact = mulconst.outacts[0]
        inact = reshape_head.inacts[0]
        normalized_shape = outact.src_shape[-1:]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)

        if reducerms.options.epsilon is not None:
            epsilon = reducerms.options.epsilon
        else:
            epsilon = numpy.finfo(numpy.float32).eps

        new_outact = builder.make_rmsnorm(
            new_inact,
            epsilon=epsilon,
            scale=mulconst.get_tensor(mulconst.options.constant).value,
            normalized_shape=normalized_shape,
        )
        old_outact = mulconst.outacts[0]
        builder.add_output_map(new_outact, old_outact)

        builder.add_invalidate_ops(*self.matched_pattern)
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        """
        reduce_rms-divconst(is_constant True, value 1)->multiply(1,1,x,c)->mulconst(scale)
        """
        pat = find_operator_sequence(
            op,
            LayerType.Multiply,
            LayerType.MultiplyConstant,
            strict_search=True,
        )
        if pat is None:
            return None
        mul, mulconst = pat

        def _match_branch(norm_inact, x_inact):
            pat = find_operator_sequence(
                norm_inact.producer_op,
                LayerType.ReduceRMS,
                LayerType.DivConstant,
                strict_search=True,
            )
            if pat is None:
                return None
            reducerms, divconst = pat

            reducerms_inact = reducerms.inacts[0]
            dim = reducerms_inact.src_dim
            if reducerms.options.reduce_axes not in ((-1,), (dim - 1,)):
                return None
            if not reducerms.options.keep_dims:
                return None

            c = reducerms_inact.src_shape[-1]
            divconst_val = divconst.get_tensor(divconst.options.constant).value
            if not (
                divconst.options.is_const_first
                and (divconst_val.size == 1 or divconst_val.shape == (c,))
                and divconst_val.reshape(-1)[0] == 1
            ):
                return None

            if reducerms_inact.name != x_inact.name:
                return None

            return reducerms, divconst

        left_inact, right_inact = mul.inacts
        pat = _match_branch(left_inact, right_inact)
        if pat is None:
            pat = _match_branch(right_inact, left_inact)
        if pat is None:
            return None
        reducerms, divconst = pat
        return reducerms, divconst, mul, mulconst

    @case2.transform
    def case2(self, *args, **kwargs):
        reducerms, divconst, mul, mulconst = self.matched_pattern
        builder = OpTransformResultV2Builder()

        inact = reducerms.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)

        if reducerms.options.epsilon is not None:
            epsilon = reducerms.options.epsilon
        else:
            epsilon = numpy.finfo(numpy.float32).eps

        new_outact = builder.make_rmsnorm(
            new_inact,
            epsilon=epsilon,
            scale=mulconst.get_tensor(mulconst.options.constant).value,
        )
        old_outact = mulconst.outacts[0]
        builder.add_output_map(new_outact, old_outact)

        builder.add_invalidate_ops(*self.matched_pattern)
        return builder.build()


@OperatorFusingRuleSet.register
class LayerNormalization(TransformRule):

    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        last axis.
        mean_centering - reducerms - div - scale
        """
        div = scale = bias = None
        pat = find_operator_sequence(
            op,
            LayerType.Div,
            LayerType.MultiplyConstant,
            LayerType.AddingConstant,
            strict_search=True,
        )
        if pat is not None:
            div, scale, bias = pat
        else:
            pat = find_operator_sequence(
                op, LayerType.Div, LayerType.MultiplyConstant, strict_search=True
            )
            if pat is None:
                return None
            else:
                div, scale = pat

        left_inact, right_inact = div.inacts
        pat = find_operator_sequence(
            right_inact.producer_op, LayerType.MeanCentering, LayerType.ReduceRMS
        )
        if pat is None:
            return None
        mean_center, reduce_rms = pat
        mean_center_outact = mean_center.outacts[0]
        if mean_center_outact.name != left_inact.name:
            return None
        if not reduce_rms.options.keep_dims:
            return None

        rank = mean_center.inacts[0].src_dim
        div_outact = div.outacts[0]

        for num_axes in (1, 2):
            axes = set(rank - x - 1 for x in range(num_axes))
            mc_ax = set(x + rank if x < 0 else x for x in mean_center.options.axes)
            rms_ax = set(
                x + rank if x < 0 else x for x in reduce_rms.options.reduce_axes
            )
            if not (mc_ax == rms_ax == axes):
                continue
            normalized_shape = tuple(map(int, div_outact.src_shape[-num_axes:]))
            scale_value = scale.get_tensor(scale.options.constant).value
            if not (normalized_shape == scale_value.shape or scale_value.size == 1):
                continue
            if bias is None:
                return mean_center, reduce_rms, div, scale, None
            else:
                bias_value = bias.get_tensor(bias.options.constant).value
                if normalized_shape == bias_value.shape or bias_value.size == 1:
                    return mean_center, reduce_rms, div, scale, bias
                else:
                    return mean_center, reduce_rms, div, scale, None
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        mean_center, reduce_rms, div, scale, bias = self.matched_pattern

        num_axes = len(reduce_rms.options.reduce_axes)

        div_outact = div.outacts[0]

        inact = mean_center.inacts[0]
        normalized_shape = tuple(map(int, div_outact.src_shape[-num_axes:]))
        epsilon = reduce_rms.options.epsilon
        if epsilon is None:
            epsilon = 1e-5  # torch default

        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        scale_val = scale.get_tensor(scale.options.constant).value
        if scale_val.shape != normalized_shape:
            scale_val = numpy.broadcast_to(scale_val, normalized_shape)

        if bias is not None:
            bias_val = bias.get_tensor(bias.options.constant).value
            if bias_val.shape != normalized_shape:
                bias_val = numpy.broadcast_to(bias_val, normalized_shape)
            builder.remove_connectivity_and_invalidate(div, scale, bias)
            old_outact = bias.outacts[0]
        else:
            bias_val = numpy.zeros(normalized_shape, dtype=numpy.float32)
            builder.remove_connectivity_and_invalidate(div, scale)
            old_outact = scale.outacts[0]

        new_outact = builder.make_layernorm(
            new_inact,
            normalized_shape=normalized_shape,
            epsilon=epsilon,
            scale=scale_val,
            bias=bias_val,
        )

        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(mean_center, reduce_rms, div)
        return builder.build()

    @pattern
    def layernorm_bias_fuse(self, op: Operator, **kwargs):
        """when bias is not fused"""
        pat = find_operator_sequence(
            op, LayerType.LayerNormalization, LayerType.AddingConstant
        )
        if pat is not None:
            layernorm, addconst = pat
            shape_ = layernorm.outacts[0].src_shape[-1:]
            const_val = addconst.get_tensor(addconst.options.constant).value
            if (
                layernorm.options.normalized_shape == shape_
                and const_val.shape == shape_
                or const_val.size == 1
            ):
                return layernorm, addconst
        return None

    @layernorm_bias_fuse.transform
    def layernorm_bias_fuse(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        layernorm, addconst = self.matched_pattern

        old_inact = layernorm.inacts[0]
        new_inact = builder.copy_activationspec(old_inact, add_input_map=True)
        if layernorm.options.bias != -1:
            bias = layernorm.get_tensor(layernorm.options.bias).value
        else:
            bias = numpy.zeros(layernorm.options.normalized_shape, dtype=numpy.float32)
        new_bias = bias + addconst.get_tensor(addconst.options.constant).value

        new_outact = builder.with_new_input_and_options(
            layernorm, new_inact, bias=new_bias
        )
        old_outact = addconst.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(layernorm, addconst)

        return builder.build()

    @pattern
    def layernorm_scale_fuse(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.LayerNormalization, LayerType.MultiplyConstant
        )
        if pat is not None:
            layernorm, mulconst = pat
            shape_ = layernorm.outacts[0].src_shape[-1:]
            const_val = mulconst.get_tensor(mulconst.options.constant).value
            if (
                layernorm.options.normalized_shape == shape_
                and const_val.shape == shape_
                or const_val.size == 1
            ):
                return layernorm, mulconst
        return None

    @layernorm_scale_fuse.transform
    def layernorm_scale_fuse(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        layernorm, mulconst = self.matched_pattern
        old_inact = layernorm.inacts[0]
        new_inact = builder.copy_activationspec(old_inact, add_input_map=True)

        const_val = mulconst.get_tensor(mulconst.options.constant).value
        scale = layernorm.get_tensor(layernorm.options.scale).value
        new_scale = const_val * scale
        if layernorm.options.bias != -1:
            bias = layernorm.get_tensor(layernorm.options.bias).value
            new_bias = bias * const_val
        else:
            new_bias = None
        new_outact = builder.with_new_input_and_options(
            layernorm, new_inact, scale=new_scale, bias=new_bias
        )
        old_outact = mulconst.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(layernorm, mulconst)
        return builder.build()


@OperatorFusingRuleSet.register
class L2Normalization(TransformRule):
    @staticmethod
    def _check_same_input(div, single_input_op):
        left_inact = div.inacts[0] # a left activation of div is the same as the input of the single_input_op
        return left_inact.name == single_input_op.inacts[0].name

    @staticmethod
    def _check_reduce_l2(reduceL2):
        return reduceL2.layertype == LayerType.ReduceL2 and reduceL2.options.keep_dims

    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Div:
            return None
        div = op
        left_inact = div.inacts[0]
        right_inact = div.inacts[1]
        pat = find_operator_sequence(
            right_inact.producer_op, LayerType.ReduceL2, LayerType.Clip
        )
        if pat is None:
            return None
        reduceL2, clip = pat
        if left_inact.name != reduceL2.inacts[0].name:
            return None
        if not reduceL2.options.keep_dims:
            return None
        if clip.options.clip_max_value is not None:
            return None
        if clip.options.clip_min_value is None:
            return None
        return reduceL2, clip, div

    @case0.transform
    def case0(self, *args, **kwargs):
        reduceL2, clip, div = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reduceL2.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        epsilon = clip.options.clip_min_value
        new_outact = builder.make_l2normalization(
            new_inact, norm_axis=reduceL2.options.reduce_axes, epsilon=epsilon
        )
        old_outact = div.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reduceL2, clip, div)
        return builder.build()

    @pattern
    def case1(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Div:
            return None
        div = op
        left_inact = div.inacts[0]
        right_inact = div.inacts[1]
        pat = find_operator_sequence(
            right_inact.producer_op,
            LayerType.ReduceL2,
            LayerType.Clip,
            LayerType.Expand,
        )
        if pat is None:
            return None
        reduceL2, clip, expand = pat
        if left_inact.name != reduceL2.inacts[0].name:
            return None
        if not reduceL2.options.keep_dims:
            return None
        if clip.options.clip_max_value is not None:
            return None
        if clip.options.clip_min_value is None:
            return None
        expand_inact = expand.inacts[0]
        expand_outact = expand.outacts[0]
        dim = int(expand_outact.src_dim)
        target_axes = tuple(
            x + dim if x < 0 else x for x in reduceL2.options.reduce_axes
        )
        for i, (iss, oss) in enumerate(
            zip(expand_inact.src_shape, expand_outact.src_shape)
        ):
            if i in target_axes:
                if iss == oss == 1 or iss < oss:
                    continue
                else:
                    return None
            else:
                if iss != oss:
                    return None
        return reduceL2, clip, expand, div

    @case1.transform
    def case1(self, *args, **kwargs):
        reduceL2, clip, expand, div = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reduceL2.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        epsilon = clip.options.clip_min_value
        new_outact = builder.make_l2normalization(
            new_inact, norm_axis=reduceL2.options.reduce_axes, epsilon=epsilon
        )
        old_outact = div.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reduceL2, clip, expand, div)
        return builder.build()

    @pattern
    def case2(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op,
            LayerType.ReduceL2,
            LayerType.Div,
            strict_search=True,
            direction="fwd",
        )
        if pat is None:
            return None
        reduceL2, div = pat
        if not self._check_reduce_l2(reduceL2):
            return None
        if not self._check_same_input(div, reduceL2):
            return None
        return reduceL2, div

    @case2.transform
    def case2(self, *args, **kwargs):
        reduceL2, div = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reduceL2.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_l2normalization(
            new_inact, norm_axis=reduceL2.options.reduce_axes
        )
        old_outact = div.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.add_invalidate_ops(reduceL2, div)
        return builder.build()

    @pattern
    def case3(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op,
            LayerType.ReduceL2,
            lambda x: _check_epsilon_add(x, atol=1e-4),
            LayerType.Div,
            strict_search=True,
            direction="fwd",
        )
        if pat is None:
            return None
        reduceL2, epsilon_add, div = pat
        if not self._check_reduce_l2(reduceL2):
            return None
        if not self._check_same_input(div, reduceL2):
            return None
        return reduceL2, epsilon_add, div

    @case3.transform
    def case3(self, *args, **kwargs):
        reduceL2, epsilon_add, div = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reduceL2.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        epsilon = float(epsilon_add.get_tensor(epsilon_add.options.constant).value.reshape(-1)[0])
        new_outact = builder.make_l2normalization(
            new_inact, norm_axis=reduceL2.options.reduce_axes, epsilon=epsilon
        )
        old_outact = div.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.add_invalidate_ops(reduceL2, epsilon_add, div)
        return builder.build()


@OperatorFusingRuleSet.register
class GlobalResponseNormalization(TransformRule):

    @pattern
    def case0(self, op: Operator, **kwargs):
        """
        todo: fill here. see convnextv2_base
        """

        pat = find_operator_sequence(
            op,
            LayerType.Multiply,
            LayerType.MultiplyConstant,
            LayerType.AddingConstant,
            strict_search=True,
        )
        if pat is None:
            return None
        mul, mul_scale, add_bias = pat

        for i in range(2):
            inact = mul.inacts[i]
            if inact.src_dim != 4:
                return None
            if inact.producer_op.layertype != LayerType.Div:
                continue
            div = inact.producer_op
            ref_inact = mul.inacts[(i + 1) % 2]
            left_inact = div.inacts[0]
            right_inact = div.inacts[1]
            if not (left_inact.src_dim == right_inact.src_dim == 4):
                continue
            pat = find_operator_sequence(
                right_inact.producer_op,
                LayerType.ReduceL2,
                LayerType.ReduceMean,
                LayerType.AddingConstant,
            )
            if pat is None:
                continue
            reduceL2, reducemean, add_eps = pat
            if reduceL2.inacts[0].name != ref_inact.name:
                return None
            if reducemean.inacts[0].name != left_inact.name:
                return None
            axes_set = [
                ({2, 3}, {1}),
                ({1, 2}, {3}),
            ]

            def _reduce_check(reduce_op, ax_to_check):
                ax = set(x + 4 if x < 0 else x for x in reduce_op.options.reduce_axes)
                return ax == ax_to_check and reduce_op.options.keep_dims

            for ax_hw, ax_c in axes_set:
                if not (
                    _reduce_check(reduceL2, ax_hw) and _reduce_check(reducemean, ax_c)
                ):
                    continue
                add_const_outact = add_bias.outacts[0]
                if 1 == len(add_const_outact.consumer_ops):
                    add = add_bias.outacts[0].consumer_ops[0]
                    if add.layertype == LayerType.Adding:
                        for inact in add.inacts:
                            if inact.name == add_const_outact.name:
                                continue
                            if inact.name == reduceL2.inacts[0].name:
                                return (
                                    reduceL2,
                                    reducemean,
                                    add_eps,
                                    div,
                                    mul,
                                    mul_scale,
                                    add_bias,
                                    add,
                                )
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        reduceL2, reducemean, add_eps, div, mul, mul_scale, add_bias, add = (
            self.matched_pattern
        )
        builder = OpTransformResultV2Builder()
        inact = reduceL2.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        is_channel_first = reduceL2.options.reduce_axes == (2, 3)
        if is_channel_first:
            new_inact = builder.make_transpose(new_inact, (0, 2, 3, 1))
        eps = float(add_eps.get_tensor(add_eps.options.constant).value)
        scale = mul_scale.get_tensor(mul_scale.options.constant).value
        bias = add_bias.get_tensor(add_bias.options.constant).value
        new_outact = builder.make_global_response_normalization(
            new_inact, scale=scale, bias=bias, epsilon=eps
        )
        if is_channel_first:
            new_outact = builder.make_transpose(new_outact, (0, 3, 1, 2))
        old_outact = add.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reduceL2, div, mul)
        builder.remove_connectivity_and_invalidate(reduceL2, reducemean, add_eps, div)
        builder.remove_connectivity_and_invalidate(mul, mul_scale, add_bias, add)
        return builder.build()


# @OperatorFusingRuleSet.register
class SumNormalization(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        if op.layertype != LayerType.Div:
            return None
        div = op
        left_inact = div.inacts[0]
        right_inact = div.inacts[1]
        if right_inact.producer_op.layertype != LayerType.ReduceSum:
            return None
        reduce_sum = right_inact.producer_op
        reduce_sum_inact = reduce_sum.inacts[0]
        if reduce_sum_inact.name != left_inact.name:
            return None
        if reduce_sum.options.keep_dims:
            return reduce_sum, div
        return None

    @case0.transform
    def case0(self, *args, **kwargs):
        reduce_sum, div = self.matched_pattern
        builder = OpTransformResultV2Builder()
        inact = reduce_sum.inacts[0]
        new_inact = builder.copy_activationspec(inact, add_input_map=True)
        new_outact = builder.make_sumnormalization(
            new_inact, norm_axis=reduce_sum.options.reduce_axes
        )
        old_outact = div.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(reduce_sum, div)
        return builder.build()
