from .inputconst import InputConstantFoldingRuleSet


__all__ = ["InputConstantFoldingRuleSet"]
