import operator

import numpy

import mblt.computation.activation_functions as actfunc_eval
import mblt.computation.normalization as norm_eval
from mblt import LayerType
from mblt.core import RuleSet, pattern, Operator, TransformRule
from mblt.subgraph.util.pattern_util import (
    is_biop_wrapper,
    find_operator_sequence,
    is_biop_const,
)
from mblt.transform.transform_result import OpTransformResultV2Builder

InputConstantFoldingRuleSet = RuleSet("InputConstantFoldingRuleSet")

__all__ = ["InputConstantFoldingRuleSet"]


@InputConstantFoldingRuleSet.register
class InputConstBiopConstant(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.InputConstant, is_biop_const)
        if pat is None:
            return None
        iconst, xconst = pat
        return iconst, xconst

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        iconst, xconst = self.matched_pattern
        const_value = iconst.get_tensor(iconst.options.constant).value
        map = {
            LayerType.AddingConstant: operator.add,
            LayerType.MultiplyConstant: operator.mul,
            LayerType.SubConstant: operator.sub,
            LayerType.DivConstant: operator.truediv,
        }
        biop_ = map[xconst.layertype]

        xconst_const_value = xconst.get_tensor(xconst.options.constant).value
        if xconst.options.is_const_first:
            new_const_value = biop_(xconst_const_value, const_value)
        else:
            new_const_value = biop_(const_value, xconst_const_value)
        new_outact = builder.make_inputconst(new_const_value, xconst.name)
        old_outact = xconst.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(iconst, xconst)
        return builder.build()


@InputConstantFoldingRuleSet.register
class InputConstAndOp(TransformRule):

    @pattern
    def case_biop(self, iconst: Operator, *args, **kwargs):
        # const-biop
        if iconst.layertype == LayerType.InputConstant:
            outact = iconst.outacts[0]
            for cop in outact.consumer_ops:
                if is_biop_wrapper(cop):
                    return iconst
        return None

    @case_biop.transform
    def case_biop(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        iconst = self.matched_pattern
        const_value = iconst.get_tensor(iconst.options.constant).value
        outact = iconst.outacts[0]
        cop_copy = [x for x in outact.consumer_ops]
        for biop in cop_copy:
            if not is_biop_wrapper(biop):
                continue
            left_inact, right_inact = tuple(biop.inacts)
            if left_inact.name == outact.name:
                new_left_inact = const_value
                new_right_inact = builder.copy_activationspec(
                    right_inact, add_input_map=True
                )
            elif right_inact.name == outact.name:
                new_left_inact = builder.copy_activationspec(
                    left_inact, add_input_map=True
                )
                new_right_inact = const_value
            else:
                raise NotImplementedError("code should not reach here!")
            opkind = biop.layertype.name[:3].lower()
            new_outact = builder.make_biop(
                new_left_inact, new_right_inact, opkind=opkind
            )
            old_outact = biop.outacts[0]
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(iconst, biop)
        return builder.build()

    @pattern
    def case_reshape(self, op: Operator, *args, **kwargs):
        return find_operator_sequence(op, LayerType.InputConstant, "R")

    @case_reshape.transform
    def case_reshape(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        iconst, _ = self.matched_pattern
        const_value = iconst.get_tensor(iconst.options.constant).value
        outact = iconst.outacts[0]
        cop_copy = [x for x in outact.consumer_ops]
        for reshape in cop_copy:
            if reshape.layertype != LayerType.Reshape:
                continue
            reshape_in_shape = tuple(map(int, reshape.inacts[0].src_shape))
            old_outact = reshape.outacts[0]
            reshape_out_shape = tuple(map(int, old_outact.src_shape))
            new_const_value = const_value + numpy.zeros(
                reshape_in_shape, dtype=const_value.dtype
            )
            new_const_value = numpy.reshape(new_const_value, reshape_out_shape)
            new_outact = builder.make_inputconst(new_const_value, iconst.name)
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(iconst, reshape)
        return builder.build()

    @pattern
    def case_transpose(self, op: Operator, *args, **kwargs):
        return find_operator_sequence(op, LayerType.InputConstant, "T")

    @case_transpose.transform
    def case_transpose(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        iconst, _ = self.matched_pattern
        const_value = iconst.get_tensor(iconst.options.constant).value
        outact = iconst.outacts[0]
        cop_copy = [x for x in outact.consumer_ops]
        for transpose in cop_copy:
            if transpose.layertype != LayerType.Transpose:
                continue
            transpose_in_shape = tuple(map(int, transpose.inacts[0].src_shape))
            old_outact = transpose.outacts[0]
            new_const_value = const_value + numpy.zeros(
                transpose_in_shape, dtype=const_value.dtype
            )
            new_const_value = numpy.transpose(
                new_const_value, transpose.options.transpose_axes
            )
            new_outact = builder.make_inputconst(new_const_value, iconst.name)
            builder.add_output_map(new_outact, old_outact)
            builder.remove_connectivity_and_invalidate(iconst, transpose)
        return builder.build()

    @pattern
    def case_matmul(self, iconst: Operator, *args, **kwargs):
        if iconst.layertype == LayerType.InputConstant:
            outact = iconst.outacts[0]
            for matmul in outact.consumer_ops:
                if matmul.layertype == LayerType.MatMul:
                    if matmul.options.repeat[0] != -1:
                        continue
                    left_inact, right_inact = matmul.inacts
                    iconst_outact = iconst.outacts[0]
                    if not left_inact.src_shape[-1].dynamic:
                        if iconst_outact.name == right_inact.name:
                            if 4 == left_inact.src_dim == right_inact.src_dim:
                                ts = iconst.get_tensor(iconst.options.constant)
                                ts_shape = ts.shape
                                pre_dim = len(ts_shape) - 2
                                if (
                                    2 <= len(ts_shape) <= 4
                                    and ts_shape[:-2] == (1,) * pre_dim
                                ):
                                    return iconst, matmul
        return None

    @case_matmul.transform
    def case_matmul(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        iconst, matmul = self.matched_pattern
        const_value = iconst.get_tensor(iconst.options.constant).value
        outact = iconst.outacts[0]
        left_inact, right_inact = matmul.inacts
        in_ch = int(left_inact.src_shape[-1])
        out_ch = int(right_inact.src_shape[-1])
        conv_weight = numpy.reshape(const_value, (in_ch, out_ch, 1, 1))
        conv_weight = numpy.transpose(conv_weight, (1, 0, 2, 3))
        new_inact = builder.copy_activationspec(left_inact, add_input_map=True)
        new_outact = builder.make_conv2d(
            new_inact, in_channels=in_ch, out_channels=out_ch, weight=conv_weight
        )
        old_outact = matmul.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(iconst, matmul)
        return builder.build()


@InputConstantFoldingRuleSet.register
class InputConstActFunction(TransformRule):
    _implemented = {
        LayerType.Abs,
        LayerType.Celu,
        LayerType.Clip,
        LayerType.Relu,
        LayerType.Sigmoid,
        LayerType.Tanh,
        LayerType.Softplus,
        LayerType.Sqrt,
    }

    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.InputConstant, "actfn")
        if pat is None:
            return None
        iconst, actfn = pat
        if actfn.layertype not in self._implemented:
            return None
        return iconst, actfn

    @case0.transform
    def case0(self, *args, **kwargs):
        iconst, actfn = self.matched_pattern
        builder = OpTransformResultV2Builder()
        iconst_value = iconst.get_tensor(iconst.options.constant).value

        if actfn.layertype == LayerType.Abs:
            new_const_val = actfunc_eval.abs(iconst_value)
        elif actfn.layertype == LayerType.Celu:
            new_const_val = actfunc_eval.celu(iconst_value, actfn.options.alpha)
        elif actfn.layertype == LayerType.Clip:
            new_const_val = actfunc_eval.clip(
                iconst_value, actfn.options.clip_min_value, actfn.options.clip_max_value
            )
        elif actfn.layertype == LayerType.Sigmoid:
            new_const_val = actfunc_eval.sigmoid(iconst_value, actfn.options.alpha)
        elif actfn.layertype == LayerType.Relu:
            new_const_val = actfunc_eval.relu(iconst_value)
        elif actfn.layertype == LayerType.Tanh:
            new_const_val = actfunc_eval.tanh(iconst_value)
        elif actfn.layertype == LayerType.Softplus:
            beta = actfn.options.beta
            threshold = actfn.options.threshold
            new_const_val = actfunc_eval.softplus(iconst_value, beta, threshold)
        elif actfn.layertype == LayerType.Sqrt:
            new_const_val = actfunc_eval.sqrt(iconst_value)
        else:
            raise NotImplementedError("code should not reach here!")
        new_outact = builder.make_inputconst(new_const_val, actfn.name)
        old_outact = actfn.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(iconst, actfn)
        return builder.build()


@InputConstantFoldingRuleSet.register
class InputConstNormalization(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(
            op, LayerType.InputConstant, LayerType.L2Normalization
        )
        if pat is None:
            return None
        iconst, norm = pat
        return iconst, norm

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        iconst, norm = self.matched_pattern
        const_value = iconst.get_tensor(iconst.options.constant).value
        eps = norm.get_tensor(norm.options.epsilon).value
        new_const_value = norm_eval.normalize(
            const_value, p=2.0, axis=norm.options.norm_axis, eps=eps
        )
        new_outact = builder.make_inputconst(new_const_value, norm.name)
        old_outact = norm.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(iconst, norm)
        return builder.build()


@InputConstantFoldingRuleSet.register
class InputConstConvolution(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.InputConstant, "C")
        if pat is None:
            return None
        iconst, conv = pat
        return iconst, conv

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        iconst, conv = self.matched_pattern
        const_value = iconst.get_tensor(iconst.options.constant).value

        from mblt.computation.convolution import numpy_conv2d

        weight = conv.get_tensor(conv.options.weight).value
        if conv.options.bias != -1:
            bias = conv.get_tensor(conv.options.bias).value
        else:
            bias = None
            # h_pad_begin, w_pad_begin, h_pad_end, w_pad_end = padding
            # n,h,w,c, NPU's north/south padding is inverted
        paddings = (
            conv.options.south_padding,
            conv.options.west_padding,
            conv.options.north_padding,
            conv.options.east_padding,
        )

        out = numpy_conv2d(
            const_value.transpose((0, 3, 1, 2)),
            weight=weight,
            bias=bias,
            stride=(conv.options.h_stride, conv.options.w_stride),
            dilation=(conv.options.h_dilation, conv.options.w_dilation),
            padding=paddings,
            groups=conv.options.group_number,
        )
        out = out.transpose((0, 2, 3, 1))
        new_outact = builder.make_inputconst(out, conv.name)
        old_outact = conv.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(iconst, conv)
        return builder.build()


@InputConstantFoldingRuleSet.register
class InputConstrSlice(TransformRule):
    @pattern
    def case0(self, op: Operator, **kwargs):
        pat = find_operator_sequence(op, LayerType.InputConstant, "S")
        if pat is None:
            return None
        iconst, slice_ = pat
        return iconst, slice_

    @case0.transform
    def case0(self, *args, **kwargs):
        builder = OpTransformResultV2Builder()
        iconst, slice_ = self.matched_pattern
        const_value = iconst.get_tensor(iconst.options.constant).value
        outact = iconst.outacts[0]
        sel = [slice(None)] * const_value.ndim
        for i in range(len(slice_.options.axis)):
            ax = slice_.options.axis[i]
            s = slice_.options.start[i]
            e = slice_.options.end[i]
            if slice_.options.step is not None:
                step = slice_.options.step[i]
            else:
                step = 1
            sel[int(ax)] = slice(s, e, step)
        out = const_value[tuple(sel)]
        new_outact = builder.make_inputconst(out, slice_.name)
        old_outact = slice_.outacts[0]
        builder.add_output_map(new_outact, old_outact)
        builder.remove_connectivity_and_invalidate(iconst, slice_)

        return builder.build()
