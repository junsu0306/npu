import copy
import time
from typing import Callable

from mblt.core import SubGraph
from mblt.logger import get_logger
from mblt.subgraph.dataformat import set_dataformat
from mblt.transform.graph_transform import OperatorGraphTransform, OptState
from .ruleset.dataflow import (
    DataFlowDirectRuleSet,
    SelectorRuleSet,
    GatherScatterRuleSet,
    BatchnormRuleSet,
    DataFlowRuleSet,
)
from .ruleset.dataflow.dataformat_canonicalize import DataFormatCanonicalizationRuleSet
from .ruleset.dataflow_post import (
    RemoveIntermediateRuleSet,
    HeaderViewRuleSet,
    PostLLMRuleSet,
    IndexedItemSelectorRuleSet,
    PostShapeFixRuleSet,
    SliceReinterpretRuleSet,
    ReplaceMaskedFillRuleSet,
    PostAttentionBlockRuleSet,
    ChannelFactorSliceRuleSet,
    SequentialNodeRuleSet,
)
from .ruleset.operator_folding import InputConstantFoldingRuleSet
from .ruleset.operator_fusing import OperatorFusingRuleSet
from .ruleset.serialization import SerializationRuleSet
from .ruleset.shape_normalize import ShapeNormalizeDirect, ShapeNormalizeContextual

LOGGER = get_logger(__name__)

# const folding.
_LEVEL_1_RULES = []
_LEVEL_1_RULES += InputConstantFoldingRuleSet.get_all_rules()
_LEVEL_1_RULES += GatherScatterRuleSet.get_all_rules()
_LEVEL_1_RULES += DataFlowDirectRuleSet.get(["RemoveIdentity"])

# basic op fusing.(activation functions, normalizations, ...)
# we don't include everything here to make fusing activation functions/norms stable.
_LEVEL_2_RULES = []
_LEVEL_2_RULES += InputConstantFoldingRuleSet.get_all_rules()
_LEVEL_2_RULES += OperatorFusingRuleSet.get_all_rules()
_LEVEL_2_RULES += DataFlowDirectRuleSet.get(["RemoveIdentity"])

# Normalize shapes/strides to make tensors rank-4 consistent where reasonable.
_LEVEL_3_RULES = copy.deepcopy(_LEVEL_2_RULES)
_LEVEL_3_RULES += ShapeNormalizeDirect.get_all_rules()
_LEVEL_3_RULES += DataFlowDirectRuleSet.get_all_rules()


_ALL_DATAFLOW_RULES = DataFormatCanonicalizationRuleSet.get_all_rules()
_ALL_DATAFLOW_RULES += DataFlowDirectRuleSet.get_all_rules()
_ALL_DATAFLOW_RULES += DataFlowRuleSet.get_all_rules()
_ALL_DATAFLOW_RULES += SelectorRuleSet.get_all_rules()

# contextual shapes/strides optimizations.
_LEVEL_4_RULES = copy.deepcopy(_LEVEL_3_RULES)
_LEVEL_4_RULES += ShapeNormalizeContextual.get_all_rules()
_LEVEL_4_RULES += _ALL_DATAFLOW_RULES
_LEVEL_4_RULES += BatchnormRuleSet.get(["ConvolutionBatchnorm", "ConcatenateBatchnorm"])

# post proc such as headerview
# we replace batchnorm to affine transforms here because we perfer conv2d-batchnorm fuse over biopconst-conv fuse.
_LEVEL_5_RULES = copy.deepcopy(_LEVEL_4_RULES)
_LEVEL_5_RULES += BatchnormRuleSet.get("BatchnormToAffine")
_LEVEL_5_RULES += HeaderViewRuleSet.get_all_rules()

# fixme: 여기 selector 적용하는 로직을 순서대로 재구성해야 할 것 같음.
_LEVEL_6_RULES = copy.deepcopy(_LEVEL_5_RULES)
_LEVEL_6_RULES += ChannelFactorSliceRuleSet.get_all_rules()
_LEVEL_6_RULES += IndexedItemSelectorRuleSet.get_all_rules()
_LEVEL_6_RULES += SliceReinterpretRuleSet.get_all_rules()
_LEVEL_6_RULES += ReplaceMaskedFillRuleSet.get_all_rules()


from .ruleset.dataflow.slice_ import ChannelSplit, MakeChannelFactorSlice

# 여기부터는 channel_split하지 않음.
_DATAFLOW_RULES_EXCEPT_INTERM_OPS = [
    rule
    for rule in _ALL_DATAFLOW_RULES
    if not isinstance(rule, (ChannelSplit, MakeChannelFactorSlice))
]
_DATAFLOW_RULES_EXCEPT_INTERM_OPS += ShapeNormalizeContextual.get_all_rules()


# 남은 indexer는 실제로 여기서 없어짐.
_LEVEL_7_RULES = []
_LEVEL_7_RULES += RemoveIntermediateRuleSet.get_all_rules()
_LEVEL_7_RULES += InputConstantFoldingRuleSet.get_all_rules()
_LEVEL_7_RULES += _DATAFLOW_RULES_EXCEPT_INTERM_OPS

_LEVEL_8_RULES = []
_LEVEL_8_RULES += InputConstantFoldingRuleSet.get_all_rules()
_LEVEL_8_RULES += PostShapeFixRuleSet.get_all_rules()
_LEVEL_8_RULES += PostAttentionBlockRuleSet.get_all_rules()
_LEVEL_8_RULES += PostLLMRuleSet.get_all_rules()
_LEVEL_8_RULES += SequentialNodeRuleSet.get_all_rules()
_LEVEL_8_RULES += _DATAFLOW_RULES_EXCEPT_INTERM_OPS


RULES_FOR_SERIALIZATION = []
RULES_FOR_SERIALIZATION += SerializationRuleSet.get_all_rules()
RULES_FOR_SERIALIZATION += DataFlowDirectRuleSet.get_all_rules()
# Used by qbcompiler transform.

STAGED_RULES = [
    _LEVEL_1_RULES,
    _LEVEL_2_RULES,
    _LEVEL_3_RULES,
    _LEVEL_4_RULES,
    _LEVEL_5_RULES,
    _LEVEL_6_RULES,
    _LEVEL_7_RULES,
    _LEVEL_8_RULES,
    RULES_FOR_SERIALIZATION,
]


DATAFORMAT_CANONICALIZATION = DataFormatCanonicalizationRuleSet.get_all_rules()
DATAFORMAT_CANONICALIZATION += DataFlowDirectRuleSet.get(["RemoveIdentity"])


def _build_transform_deadline(
    compilation_mode: str | None, transform_timeout_sec: float | None
):
    if compilation_mode == "release" and transform_timeout_sec is not None:
        return time.monotonic() + transform_timeout_sec
    return None


def _is_transform_timeout(transform_deadline_s: float | None) -> bool:
    return transform_deadline_s is not None and time.monotonic() >= transform_deadline_s


def perform_basic_transform(
    subgraph: SubGraph,
    exclude_op_condition: Callable = None,
    optimize_level=999,
    debug: bool = False,
    stop_after_stage_and_cnt=None,
    compilation_mode: str | None = None,
    transform_timeout_sec: float | None = None,
) -> tuple[bool, bool]:
    if exclude_op_condition is not None:
        for op in subgraph.operators:
            op.exclude_from_transform = exclude_op_condition(op)
    LOGGER.info(f"optimize_level={optimize_level}.")

    changed = False
    timed_out = False

    if stop_after_stage_and_cnt is not None:
        last_stage, last_cnt = stop_after_stage_and_cnt
        opt_state = OptState(last_stage=last_stage, last_cnt=last_cnt)
    else:
        opt_state = OptState()
    transform_deadline_s = _build_transform_deadline(
        compilation_mode, transform_timeout_sec
    )

    msg = "================ [OPTIMIZE stage={stage_no}, num_ops={num_ops}] ================"
    for i, rules in enumerate(STAGED_RULES[:optimize_level]):
        if compilation_mode == "release" and _is_transform_timeout(
            transform_deadline_s
        ):
            timed_out = True
            LOGGER.warning(
                f"release mode: transform timeout reached before stage={i + 1}, "
                f"stopping remaining optimization stages."
            )
            break
        stage_no = i + 1
        opt_state.stage = stage_no
        opt_state.cnt = 0
        changed = True
        LOGGER.info(msg.format(stage_no=stage_no, num_ops=len(subgraph.operators)))
        while changed:
            if compilation_mode == "release" and _is_transform_timeout(
                transform_deadline_s
            ):
                timed_out = True
                LOGGER.warning(
                    f"release mode: transform timeout reached in stage={stage_no}, "
                    f"stopping remaining iterations."
                )
                changed = False
                break
            changed = False
            if stage_no >= 3:
                transform = OperatorGraphTransform(DATAFORMAT_CANONICALIZATION)
                changed |= transform.process(
                    subgraph,
                    debug=debug,
                    opt_state=opt_state,
                    compilation_mode=compilation_mode,
                    transform_deadline_s=transform_deadline_s,
                )
                if compilation_mode == "release" and _is_transform_timeout(
                    transform_deadline_s
                ):
                    timed_out = True
                    LOGGER.warning(
                        f"release mode: transform timeout reached after "
                        f"dataformat canonicalization in stage={stage_no}, "
                        f"stopping remaining work in this stage."
                    )
                    subgraph.strip_unused_operators()
                    break
            if not opt_state.is_stop():
                transform = OperatorGraphTransform(rules)
                changed |= transform.process(
                    subgraph,
                    debug=debug,
                    opt_state=opt_state,
                    compilation_mode=compilation_mode,
                    transform_deadline_s=transform_deadline_s,
                )
                if compilation_mode == "release" and _is_transform_timeout(
                    transform_deadline_s
                ):
                    timed_out = True
                    LOGGER.warning(
                        f"release mode: transform timeout reached after "
                        f"rule transform in stage={stage_no}, "
                        f"stopping remaining work in this stage."
                    )
                    subgraph.strip_unused_operators()
                    break
            subgraph.strip_unused_operators()
            if opt_state.is_stop():
                break
        if opt_state.stage_to_stop is not None:
            if stage_no >= opt_state.stage_to_stop:
                break
    subgraph.finalize()
    set_dataformat(subgraph)

    return changed, timed_out
