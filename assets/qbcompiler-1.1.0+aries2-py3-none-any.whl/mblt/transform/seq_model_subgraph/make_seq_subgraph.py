from mblt.core import Operator, ActivationSpec
from mblt.subgraph import MbltSubGraphBuilder


class MakeSeqSubgraph:
    def __init__(self):
        self.builder = None

    def _make_inputs(self, op: Operator, input_mask: str):
        inputs = {}
        for inact, mask in zip(op.inacts, input_mask):
            if mask == "i":  # to seqlen=1
                src_shape = list(inact.src_shape)
                src_shape[2] = 1
                src_shape = tuple(src_shape)
            else:
                src_shape = inact.src_shape
            new_inact = ActivationSpec(
                name=inact.name,
                dtype=inact.dtype,
                src_shape=src_shape,
                dataformat=inact.dataformat,
            )
            self.builder.add_activation(new_inact)
            self.builder.make_input(new_inact)
            inputs[mask] = new_inact
        return inputs

    def _get_direction_sel(self, op):
        if op.options.direction in ("forward", "reverse", "backward"):
            return 0
        raise ValueError(f"Invalid direction: {op.options.direction}")

    def make_rnn_sg(self, op, *args, **kwargs):
        direction_sel = self._get_direction_sel(op)
        hidden_size = int(op.options.hidden_size)
        input_mask = op.options.input_mask
        act_f = op.options.activations
        subgraph_name = op.options.subgraph
        W = op.get_tensor(op.options.W).value
        R = op.get_tensor(op.options.R).value

        if op.options.B != -1:
            B = op.get_tensor(op.options.B).value
            WB = B[direction_sel, :hidden_size]
            RB = B[direction_sel, hidden_size:]
        else:
            WB = RB = None

        self.builder = MbltSubGraphBuilder()
        inputs = self._make_inputs(op, input_mask)

        Xt = inputs.get("i", None)
        input_s = inputs.get("s", None)
        Ht_1 = inputs.get("h", None)
        hidden_state_name = op.options.hidden_state_name

        """
        Ht = f(Xt*(Wi^T) + Ht-1*(Ri^T) + Wbi + Rbi)

        input_x: (batch, 1, seq_len, input_size)
        initial_h: [batch, 1, num_directions, hidden_size]
        W: [num_directions, hidden_size, input_size]
        R: [num_directions, hidden_size, hidden_size]
        B: [num_directions, 2*hidden_size] 

        zrh order
        """

        b, _, seq_len, input_size = Xt.src_shape
        input_size = int(input_size)

        W = W[direction_sel]
        X_gate = self.builder.make_conv2d(
            Xt,
            in_channels=input_size,
            out_channels=hidden_size,
            weight=W.reshape((hidden_size, input_size, 1, 1)),
            bias=WB,
        )

        R = R[direction_sel]
        H_gate = self.builder.make_conv2d(
            Ht_1,
            in_channels=hidden_size,
            out_channels=hidden_size,
            weight=R.reshape((hidden_size, hidden_size, 1, 1)),
            bias=RB,
        )
        Ht = self.builder.make_add(X_gate, H_gate)
        Ht = self.builder.make_act_func(Ht, kind=act_f)
        self.builder.make_output(Ht, orig_name=hidden_state_name)
        rnn_sg = self.builder.build(name=subgraph_name)
        rnn_sg.finalize()

        expected_input_names = [x.name for x in op.inacts]
        new_inputs = []
        for name in expected_input_names:
            for i in rnn_sg.inputs:
                if rnn_sg.activations[i].name == name:
                    new_inputs.append(i)
                    break
        rnn_sg.inputs = new_inputs

        for op in rnn_sg.operators:
            op.unsupported = False
        return rnn_sg

    def make_gru_sg(self, op, *args, **kwargs):
        direction_sel = self._get_direction_sel(op)
        hidden_size = int(op.options.hidden_size)
        input_mask = op.options.input_mask
        linear_before_reset = op.options.linear_before_reset
        act_f, act_g = op.options.activations
        subgraph_name = op.options.subgraph
        W = op.get_tensor(op.options.W).value
        R = op.get_tensor(op.options.R).value

        if op.options.B != -1:
            B = op.get_tensor(op.options.B).value
            WB = B[direction_sel, : 3 * hidden_size]
            RB = B[direction_sel, 3 * hidden_size :]
        else:
            WB = RB = None

        self.builder = MbltSubGraphBuilder()
        inputs = self._make_inputs(op, input_mask)

        Xt = inputs.get("i", None)
        input_s = inputs.get("s", None)
        Ht_1 = inputs.get("h", None)
        hidden_state_name = op.options.hidden_state_name

        """
        zt = f(Xt*(Wz^T) + Ht-1*(Rz^T) + Wbz + Rbz)
        rt = f(Xt*(Wr^T) + Ht-1*(Rr^T) + Wbr + Rbr)
        ht = g(Xt*(Wh^T) + (rt (.) Ht-1)*(Rh^T) + Rbh + Wbh) # default, when linear_before_reset = 0
        ht = g(Xt*(Wh^T) + (rt (.) (Ht-1*(Rh^T) + Rbh)) + Wbh) # when linear_before_reset != 0
        Ht = (1 - zt) (.) ht + zt (.) Ht-1

        input_x: (batch, 1, seq_len, input_size)
        initial_h: [batch, 1, num_directions, hidden_size]
        W: [num_directions, 3*hidden_size, input_size]
        R: [num_directions, 3*hidden_size, hidden_size]
        B: [num_directions, 6*hidden_size] 

        zrh order
        """

        b, _, seq_len, input_size = Xt.src_shape
        input_size = int(input_size)

        W_zr = W[direction_sel, : 2 * hidden_size]
        W_h = W[direction_sel, 2 * hidden_size :]
        WB_zr = WB_h = None
        if WB is not None:
            WB_zr = WB[: 2 * hidden_size]
            WB_h = WB[2 * hidden_size :]
        X_zr_gate = self.builder.make_conv2d(
            Xt,
            in_channels=input_size,
            out_channels=2 * hidden_size,
            weight=W_zr.reshape((2 * hidden_size, input_size, 1, 1)),
            bias=WB_zr,
        )
        X_h_gate = self.builder.make_conv2d(
            Xt,
            in_channels=input_size,
            out_channels=hidden_size,
            weight=W_h.reshape((hidden_size, input_size, 1, 1)),
            bias=WB_h,
        )

        R_zr = R[direction_sel, : 2 * hidden_size]
        R_h = R[direction_sel, 2 * hidden_size :]
        RB_zr = RB_h = None
        if RB is not None:
            RB_zr = RB[: 2 * hidden_size]
            RB_h = RB[2 * hidden_size :]
        H_zr_gate = self.builder.make_conv2d(
            Ht_1,
            in_channels=hidden_size,
            out_channels=2 * hidden_size,
            weight=R_zr.reshape((2 * hidden_size, hidden_size, 1, 1)),
            bias=RB_zr,
        )

        zr_gate = self.builder.make_add(X_zr_gate, H_zr_gate)
        zr_gate = self.builder.make_act_func(zr_gate, kind=act_f)
        zt = self.builder.make_slice(zr_gate, axis=(3,), start=(0,), end=(hidden_size,))
        rt = self.builder.make_slice(
            zr_gate, axis=(3,), start=(hidden_size,), end=(2 * hidden_size,)
        )
        if linear_before_reset:  # linear->reset
            ht = self.builder.make_conv2d(
                Ht_1,
                in_channels=hidden_size,
                out_channels=hidden_size,
                weight=R_h.reshape((hidden_size, hidden_size, 1, 1)),
                bias=RB_h,
            )
            ht = self.builder.make_mul(rt, ht)
        else:  # reset->linear
            ht = self.builder.make_mul(rt, Ht_1)
            ht = self.builder.make_conv2d(
                ht,
                in_channels=hidden_size,
                out_channels=hidden_size,
                weight=R_h.reshape((hidden_size, hidden_size, 1, 1)),
                bias=RB_h,
            )
        ht = self.builder.make_add(X_h_gate, ht)
        ht = self.builder.make_act_func(ht, kind=act_g)
        Ht = self.builder.make_mul(zt, self.builder.make_sub(Ht_1, ht))
        Ht = self.builder.make_add(ht, Ht, opname=hidden_state_name)
        self.builder.make_output(Ht, orig_name=hidden_state_name)
        gru_sg = self.builder.build(name=subgraph_name)
        gru_sg.finalize()

        expected_input_names = [x.name for x in op.inacts]
        new_inputs = []
        for name in expected_input_names:
            for i in gru_sg.inputs:
                if gru_sg.activations[i].name == name:
                    new_inputs.append(i)
                    break
        gru_sg.inputs = new_inputs

        for op in gru_sg.operators:
            op.unsupported = False
        return gru_sg

    def make_lstm_sg(self, op, *args, **kwargs):
        direction_sel = self._get_direction_sel(op)
        hidden_size = int(op.options.hidden_size)
        input_mask = op.options.input_mask

        act_f, act_g, act_h = op.options.activations
        subgraph_name = op.options.subgraph

        W = op.get_tensor(op.options.W).value
        R = op.get_tensor(op.options.R).value

        if op.options.B != -1:
            B = op.get_tensor(op.options.B).value
            WB = B[direction_sel, : 4 * hidden_size]
            RB = B[direction_sel, 4 * hidden_size :]
        else:
            WB = RB = None

        if op.options.P != -1:
            P = op.get_tensor(op.options.P).value
        else:
            P = None

        self.builder = MbltSubGraphBuilder()
        inputs = self._make_inputs(op, input_mask)

        Xt = inputs.get("i")
        input_s = inputs.get("s", None)
        Ht_1 = inputs.get("h")
        Ct_1 = inputs.get("c")
        hidden_state_name = op.options.hidden_state_name
        cell_state_name = op.options.cell_state_name

        """
        it = f(Xt*(Wi^T) + Ht-1*(Ri^T) + Pi (.) Ct-1 + Wbi + Rbi)
        ft = f(Xt*(Wf^T) + Ht-1*(Rf^T) + Pf (.) Ct-1 + Wbf + Rbf)
        ct = g(Xt*(Wc^T) + Ht-1*(Rc^T) + Wbc + Rbc)
        Ct = ft (.) Ct-1 + it (.) ct
        ot = f(Xt*(Wo^T) + Ht-1*(Ro^T) + Po (.) Ct + Wbo + Rbo)
        Ht = ot (.) h(Ct)

        input_x: (batch, 1, seq_len, input_size)
        initial_h: [batch, 1, num_directions, hidden_size]
        initial_c: [batch, 1,num_directions, hidden_size]
        W: [num_directions, 4*hidden_size, input_size]
        R: [num_directions, 4*hidden_size, hidden_size]
        B: [num_directions, 8*hidden_size]
        P: [num_directions, 3*hidden_size]

        iofc order
        """

        b, _, seq_len, input_size = Xt.src_shape
        input_size = int(input_size)

        # iof gate
        if P is None:  # no peephole
            W_iof = W[direction_sel, : 3 * hidden_size]
            W_c = W[direction_sel, 3 * hidden_size :]

            WB_iof = WB_c = None
            if WB is not None:
                WB_iof = WB[: 3 * hidden_size]
                WB_c = WB[3 * hidden_size :]
            X_iof_gate = self.builder.make_conv2d(
                Xt,
                in_channels=input_size,
                out_channels=3 * hidden_size,
                weight=W_iof.reshape((3 * hidden_size, input_size, 1, 1)),
                bias=WB_iof,
            )
            X_c_gate = self.builder.make_conv2d(
                Xt,
                in_channels=input_size,
                out_channels=hidden_size,
                weight=W_c.reshape((hidden_size, input_size, 1, 1)),
                bias=WB_c,
            )

            R_iof = R[direction_sel, : 3 * hidden_size]
            R_c = R[direction_sel, 3 * hidden_size :]
            RB_iof = RB_c = None
            if RB is not None:
                RB_iof = RB[: 3 * hidden_size]
                RB_c = RB[3 * hidden_size :]
            H_iof_gate = self.builder.make_conv2d(
                Ht_1,
                in_channels=hidden_size,
                out_channels=3 * hidden_size,
                weight=R_iof.reshape((3 * hidden_size, hidden_size, 1, 1)),
                bias=RB_iof,
            )
            H_c_gate = self.builder.make_conv2d(
                Ht_1,
                in_channels=hidden_size,
                out_channels=hidden_size,
                weight=R_c.reshape((hidden_size, hidden_size, 1, 1)),
                bias=RB_c,
            )
            iof_gate = self.builder.make_add(X_iof_gate, H_iof_gate)
            iof_gate = self.builder.make_act_func(iof_gate, kind=act_f)
            it = self.builder.make_slice(
                iof_gate, axis=(3,), start=(0,), end=(hidden_size,)
            )
            ot = self.builder.make_slice(
                iof_gate, axis=(3,), start=(hidden_size,), end=(2 * hidden_size,)
            )
            ft = self.builder.make_slice(
                iof_gate, axis=(3,), start=(2 * hidden_size,), end=(3 * hidden_size,)
            )
            ct = self.builder.make_add(X_c_gate, H_c_gate)
            ct = self.builder.make_act_func(ct, kind=act_g)
            Ct = self.builder.make_add(
                self.builder.make_mul(ft, Ct_1),
                self.builder.make_mul(it, ct),
                opname=cell_state_name,
            )

            Ht = self.builder.make_mul(
                ot, self.builder.make_act_func(Ct, kind=act_h), opname=hidden_state_name
            )

            self.builder.make_output(Ht, orig_name=hidden_state_name)
            self.builder.make_output(Ct, orig_name=cell_state_name)

            lstm_sg = self.builder.build(name=subgraph_name)
            lstm_sg.finalize()
            # fixme: finalize()과정에서 inputs/outputs 순서가 stable하지 않음.

            expected_input_names = [x.name for x in op.inacts]
            new_inputs = []
            for name in expected_input_names:
                for i in lstm_sg.inputs:
                    if lstm_sg.activations[i].name == name:
                        new_inputs.append(i)
                        break
            lstm_sg.inputs = new_inputs

            expected_output_names = [hidden_state_name, cell_state_name]
            new_outputs = []
            for name in expected_output_names:
                for o in lstm_sg.outputs:
                    if lstm_sg.activations[o].name == name:
                        new_outputs.append(o)
                        break
            lstm_sg.outputs = new_outputs
            for op in lstm_sg.operators:
                op.unsupported = False
            return lstm_sg
        else:
            raise NotImplementedError("LSTM with peephole is not supported yet")
