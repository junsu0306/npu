from collections import deque
from mblt.core import SubGraph, DataFormat
from mblt.operator.opkind import BASIC_NHWC_OPS, NPU_STRIDE_PRESERVING
from mblt.subgraph.util.pattern_util import npu_stride_preserving_reshape


def set_dataformat(subgraph: SubGraph):
    queue = deque()
    visited_ops = set()

    # 초기 seed: BASIC_NHWC_OPS
    for op in subgraph.operators:
        if op.layertype in BASIC_NHWC_OPS:
            for outact in op.outacts:
                outact.dataformat = DataFormat.NHWC
            queue.append(op)
            visited_ops.add(op)

    while queue:
        curr_op = queue.popleft()

        # 현재 연산자의 출력 activation을 소모하는 다음 연산자들을 확인
        for outact in curr_op.outacts:
            for next_op in outact.consumer_ops:
                if next_op in visited_ops:
                    continue

                # 전파 조건 확인
                # 입력 중 하나라도 NHWC이고, 해당 연산자가 전파 가능한 경우
                if any(inact.dataformat == DataFormat.NHWC for inact in next_op.inacts):
                    if _is_nhwc_propagatable(next_op):
                        for next_outact in next_op.outacts:
                            next_outact.dataformat = DataFormat.NHWC
                        queue.append(next_op)
                        visited_ops.add(next_op)


def _is_nhwc_propagatable(op) -> bool:
    """
    Determine if NHWC format should be propagated through this operator.
    The user mentioned they will write the specific conditions.
    """
    return op.layertype in NPU_STRIDE_PRESERVING or npu_stride_preserving_reshape(op)
