import math
from typing import Callable, List, Any, Optional, Tuple, Union, Set

from mblt.core import LayerType, Operator
from mblt.operator.opkind import (
    ACTIVATION_FUNCTIONS,
    BIOP_ARITHMETIC,
    BIOP_ARITHMETIC_CONST,
    BASIC_NHWC_OPS,
    NORMALIZATIONS,
    NPU_STRIDE_PRESERVING,
    REDUCE_OPS,
    CONV_LIKE_OPS,
)
from .reshape_check import reshape_check


def is_reduce(op: Optional[Operator]) -> bool:
    return op is not None and op.layertype in REDUCE_OPS


def is_conv(op: Optional[Operator]) -> bool:
    return op is not None and op.layertype == LayerType.Convolution


def is_reshape(op: Optional[Operator]) -> bool:
    return op is not None and op.layertype == LayerType.Reshape


def is_slice(op: Optional[Operator]) -> bool:
    return op is not None and op.layertype == LayerType.Slice


def is_matmul(op: Optional[Operator]) -> bool:
    return op is not None and op.layertype == LayerType.MatMul


def is_transpose(op: Optional[Operator], axes=None) -> bool:
    if op is None or not op.valid:
        return False
    if axes is None:
        return op.layertype == LayerType.Transpose

    return op.layertype == LayerType.Transpose and op.options.transpose_axes == axes


def is_conv_type(op: Optional[Operator]) -> bool:
    return op.layertype in CONV_LIKE_OPS


def get_layertype(x: Union[LayerType, Operator]) -> LayerType:
    """
    Extracts the LayerType from the input.

    Args:
        x: Either a LayerType enum value or an Operator object.

    Returns:
        The LayerType enum value.
    """
    return x if isinstance(x, LayerType) else x.layertype


def is_actfunc_type(x: Union[LayerType, Operator, None]) -> bool:
    """
    Checks whether the input represents an activation function layer type.

    This function supports both LayerType enum values and Operator objects.
    It checks if the layer type is one of the common activation functions.

    Args:
        x: Either a LayerType enum value, an Operator object, or None.

    Returns:
        True if the input represents an activation function type, False otherwise.
    """
    if x is None:
        return False
    lt = x if isinstance(x, LayerType) else x.layertype
    return lt in ACTIVATION_FUNCTIONS and lt != LayerType.Pow


def is_supported_shape_preserving_op(x: Operator | LayerType) -> bool:
    if x is None:
        return False
    lt = x if isinstance(x, LayerType) else x.layertype
    return lt in NPU_STRIDE_PRESERVING


def is_norm_with_last_dim_normalized_shape(op: Operator) -> bool:
    if op.layertype not in NORMALIZATIONS:
        return False
    normalized_shape = getattr(op.options, "normalized_shape", None)
    if normalized_shape is None or len(normalized_shape) != 1:
        return False
    inact = op.inacts[0]
    if inact.src_dim != 4:
        return False
    return normalized_shape[0] == int(inact.src_shape[-1])


def _is_biop(x: Union[LayerType, Operator, None]) -> bool:
    """
    Checks whether the input represents a binary operation layer type.

    Binary operations include: Adding, Multiply, Div, and Sub.

    Args:
        x: Either a LayerType enum value, an Operator object, or None.

    Returns:
        True if the input represents a binary operation type, False otherwise.
    """
    if x is None:
        return False
    lt = x if isinstance(x, LayerType) else x.layertype
    return lt in BIOP_ARITHMETIC


def is_biop_wrapper(op):
    if op is None or not op.valid:
        return False
    if _is_biop(op):
        for act in op.inacts:
            if not (
                act.producer_op.valid
                and not getattr(act.producer_op, "exclude_from_transform", False)
            ):
                return False
        return True
    return False


def is_biop_const(x: Union[LayerType, Operator, None]) -> bool:
    if x is None:
        return False
    lt = x if isinstance(x, LayerType) else x.layertype
    return lt in BIOP_ARITHMETIC_CONST


_MISSING = object()


def _op_check_fn(
    op: Optional[Operator], layertype: LayerType, **options_to_check
) -> bool:
    """
    Checks whether an operator matches the specified layer type and options.

    This is a generic helper function that validates if an operator has a specific
    layer type and if its options match the provided keyword arguments.

    Args:
        op: The operator to check, or None.
        layertype: The expected LayerType.
        **options_to_check: Keyword arguments representing option names and their expected values.

    Returns:
        True if the operator is not None, has the specified layer type, and all
        specified options match; False otherwise.
    """
    if op is None or op.layertype != layertype:
        return False
    opts = op.options
    missing = _MISSING
    for k, v in options_to_check.items():
        if getattr(opts, k, missing) != v:
            return False
    return True


def is_linear_conv(op: Optional[Operator]) -> bool:
    """
    Checks whether an operator is a convolution that is effectively equivalent to a linear layer.

    A convolution is considered equivalent to a linear layer when it has:
    - 1x1 kernel size
    - 1x1 stride
    - 1x1 dilation
    - No padding (all padding values are 0)
    - group_number = 1 (not a grouped/depthwise convolution)
    - channel_last = True

    Args:
        op: The operator to check, or None.

    Returns:
        True if the operator is a convolution equivalent to a linear layer, False otherwise.
    """
    return _op_check_fn(
        op,
        layertype=LayerType.Convolution,
        h_kernel=1,
        w_kernel=1,
        h_stride=1,
        w_stride=1,
        h_dilation=1,
        w_dilation=1,
        east_padding=0,
        west_padding=0,
        north_padding=0,
        south_padding=0,
        group_number=1,
        channel_last=True,
    )


def conv_compare(conv0: Optional[Operator], conv1: Operator) -> bool:
    """
    Compares two convolution operators to check if they have identical configuration.

    This function checks if conv0 has the same layer type and convolution parameters
    (channels, kernel size, stride, dilation, padding, etc.) as conv1.

    Args:
        conv0: The first convolution operator to compare, or None.
        conv1: The second convolution operator to use as reference.

    Returns:
        True if conv0 has the same configuration as conv1, False otherwise.
    """

    return _op_check_fn(
        conv0,
        layertype=conv1.layertype,
        in_channels=conv1.options.in_channels,
        out_channels=conv1.options.out_channels,
        group_number=conv1.options.group_number,
        h_kernel=conv1.options.h_kernel,
        w_kernel=conv1.options.w_kernel,
        h_stride=conv1.options.h_stride,
        w_stride=conv1.options.w_stride,
        h_dilation=conv1.options.h_dilation,
        w_dilation=conv1.options.w_dilation,
        east_padding=conv1.options.east_padding,
        west_padding=conv1.options.west_padding,
        north_padding=conv1.options.north_padding,
        south_padding=conv1.options.south_padding,
        channel_last=conv1.options.channel_last,
    )


def is_concatenate_with_axis(*axes: int) -> Callable[[Operator], bool]:
    """
    Returns a function that checks whether an operator is a Concatenate with one of the specified axes.

    If multiple axes are provided, the returned function returns True if the operator's axis
    matches any of them.

    Example:
        check = is_concatenate_with_axis(3)
        if check(op):
            print("Concatenate along axis 3.")

        check = is_concatenate_with_axis(-1, 3)
        if check(op):
            print("Concatenate along axis -1 or 3.")

    """
    axes_set = set(axes)

    def check_fn(op: Operator) -> bool:
        # Avoid generator reuse issues and reduce overhead per call
        return (
            op is not None
            and op.layertype == LayerType.Concatenate
            and op.options.axis in axes_set
        )

    return check_fn


def _is_transpose_with_axes(*transpose_axes: int) -> Callable[[Operator], bool]:
    """
    Returns a function that checks whether an operator is a Transpose with the specified axes.
    Example:
        check = is_transpose_with_axes(0, 3, 1, 2)
        check(op)
    """
    axes_tuple = tuple(transpose_axes)

    def check_fn(op: Operator) -> bool:
        return (
            op is not None
            and op.layertype == LayerType.Transpose
            and op.options.transpose_axes == axes_tuple
        )

    return check_fn


def is_reshape_with_expr(expr):
    def chech_fn(op: Operator):
        if op is None or op.layertype != LayerType.Reshape:
            return False
        return reshape_check(expr, op.inacts[0].src_shape, op.outacts[0].src_shape)

    return chech_fn


def is_slice_with_axis(axis, last_slice=False):
    def chech_fn(op: Operator):
        if op is None or op.layertype != LayerType.Slice or len(op.options.axis) != 1:
            return False
        op_axis = op.options.axis[0]
        if op_axis < 0:
            op_axis += op.inacts[0].src_dim

        if last_slice:
            return (
                op_axis == axis
                and op.options.start[0] == -1
                and op.options.end[0] >= 2147483647
            )
        else:
            return op_axis == axis

    return chech_fn


def _parse_layertype_str(shorthand: str):
    pos = 0
    while pos < len(shorthand):
        char = shorthand[pos]
        if char == "C":
            yield is_conv
            pos += 1
        elif char == "L":
            yield is_linear_conv
            pos += 1
        elif char == "M":
            if pos + 1 < len(shorthand) and shorthand[pos + 1] == "m":
                yield is_matmul
                pos += 2
            else:
                raise ValueError(f"Unsupported layertype character: {char}")
        elif char == "R":
            if pos + 1 < len(shorthand) and shorthand[pos + 1] == "[":
                end = shorthand.find("]", pos + 2)
                if end == -1:
                    raise ValueError(
                        f"Missing closing ']' for Reshape expr in {shorthand}"
                    )
                expr = shorthand[pos + 2 : end]
                yield is_reshape_with_expr(expr)
                pos = end + 1
            else:
                yield is_reshape
                pos += 1
        elif char == "S":
            if pos + 1 < len(shorthand) and shorthand[pos + 1] == "[":
                end = shorthand.find("]", pos + 2)
                if end == -1:
                    raise ValueError(
                        f"Missing closing ']' for Slice expr in {shorthand}"
                    )
                expr = shorthand[pos + 2 : end]
                last_slice = expr.endswith("L")
                axis_str = expr[:-1] if last_slice else expr
                if len(axis_str) == 1 and axis_str.isdigit():
                    yield is_slice_with_axis(int(axis_str), last_slice=last_slice)
                pos = end + 1
            else:
                yield is_slice
                pos += 1
        elif char == "T":
            pos += 1
            axes = []
            while pos < len(shorthand) and shorthand[pos].isdigit():
                axes.append(int(shorthand[pos]))
                pos += 1
            if axes:
                yield _is_transpose_with_axes(*axes)
            else:
                yield is_transpose
        elif char == "a":
            if shorthand.startswith("actfn", pos):
                yield is_actfunc_type
                pos += 5
        elif char == "b":
            if shorthand.startswith("biop", pos):
                yield _is_biop
                pos += 4
        else:
            raise ValueError(f"Unsupported layertype character: {char} in {shorthand}")


def parse_layer_sequence(seq: List[Union[str, Callable, LayerType]]) -> List[Any]:
    """
    Parses a sequence of layer types with support for shorthand notation.

    This function supports shorthand notation for layer types, which simplifies
    the specification of commonly used layer type patterns.

    Args:
        seq: A list containing strings (shorthand notation), callable functions,
             or LayerType enum values.

    Returns:
        A list of parsed layer specifications (LayerType enums or callable functions).

    Raises:
        ValueError: If an unsupported shorthand character is encountered.
        TypeError: If an element in the sequence is not a string, callable, or LayerType.

    Example:
        - The string "RTC" is parsed as:
              [LayerType.Reshape, LayerType.Transpose, LayerType.Convolution]
        - The string "T0231" is parsed as:
              (LayerType.Transpose, (0, 2, 3, 1))

        If `seq` is provided as a mixed type sequence like:
            [func1, "CT0231R", func2, "SR"]
        it is interpreted as:
            [
              func1,
              LayerType.Convolution,
              (LayerType.Transpose, (0, 2, 3, 1)),
              LayerType.Reshape,
              func2,
              LayerType.Slice,
              LayerType.Reshape
            ]

    Supported shorthand notations:
        "actfn" -> is_act_func_type (activation function checker)
        "biop"  -> is_biop (binary operation checker: Adding, Multiply, Div, Sub)
        "C"     -> Convolution
        "L"     -> Linear (1x1 convolution equivalent to linear layer)
        "Mm"    -> MatMul
        "R"     -> Reshape
        "S"     -> Slice ("S[n]": axis=n, "S[nL]": axis=n with start=-1, end>=2147483647)
        "T"     -> Transpose (supports transpose_axes, e.g., "T0231")
    """

    result: List[Any] = []
    i = 0
    while i < len(seq):
        elem = seq[i]
        if callable(elem) or isinstance(elem, LayerType):
            result.append(elem)
            i += 1
        elif isinstance(elem, str):
            parts: List[str] = []
            while i < len(seq) and isinstance(seq[i], str):
                parts.append(seq[i])
                i += 1
            acc = "".join(parts).replace(" ", "")
            if acc:
                result.extend(_parse_layertype_str(acc))
        else:
            raise TypeError(f"Unsupported element in sequence: {elem}")
    return result


def find_operator_sequence(
    op_ref: Optional[Operator],
    *layer_types: Union[LayerType, str, Callable],
    strict_search: bool = False,
    direction: str = "bwd",
) -> Optional[Tuple[Operator, ...]]:
    """
    Finds a sequence of operators in the subgraph that matches the given layer types.

    The search starts from the last operator and traverses backward through the subgraph,
    matching operators against the provided layer type patterns. This approach is efficient
    as it leverages subgraph connectivity information.

    Args:
        op_ref: The last (or first) operator in the sequence to match (starting point for backward (or forward) search.
        *layer_types: Variable-length argument list of layer types to match. Each element can be:
                      - A LayerType enum value
                      - A string with shorthand notation (see parse_layer_sequence)
                      - A callable function that takes an Operator and returns a boolean
        strict_search: If True, ensures that each operator in the sequence (except the last)
                      has exactly one consumer. This guarantees a linear chain of operators.
                      Default is False.
        direction: The direction of the search. Can be "fwd" for forward search or "bwd" for backward search.

    Returns:
        A tuple of Operator objects in forward order if a matching sequence is found,
        or None if no match is found.

    Raises:
        NotImplementedError: If a pattern type is not supported.

    Notes:
        - All operators in the sequence must have a single input (except the first operator).
        - The function stops searching if it encounters an operator with multiple inputs.
        - Invalid operators will cause the search to terminate early.
        - In strict mode, the search ensures a linear chain without branching.
    """
    if direction == "fwd":
        return _find_operator_sequence_forward(
            op_ref, *layer_types, strict_search=strict_search
        )
    if not isinstance(op_ref, Operator):
        raise TypeError(f"op_last must be an Operator instance, got={type(op_ref)}")
    if not op_ref.valid:
        return None
    if getattr(op_ref, "_is_connection_op", False):
        return None
    layer_types = parse_layer_sequence(layer_types)

    op_sequence: List[Operator] = []
    current_op = op_ref
    sg = op_ref.subgraph
    activations = sg.activations

    needed = len(layer_types)
    for pattern in reversed(layer_types):
        if current_op is None or not current_op.valid:
            break

        lt = current_op.layertype
        if isinstance(pattern, LayerType):
            if lt != pattern:
                break
        elif callable(pattern):
            if not pattern(current_op):
                break
        else:
            raise NotImplementedError(f"Unsupported pattern type: {type(pattern)}")
        if any(
            getattr(inact.producer_op, "_is_connection_op", False)
            for inact in current_op.inacts
        ):
            break
        op_sequence.append(current_op)

        if len(op_sequence) == needed:
            break

        inputs = current_op.options.inputs
        if not inputs or len(inputs) > 1:
            # Need exactly one input to continue a linear chain backward
            break

        act = activations[inputs[0]]
        prod = act.producer_op
        if prod is None or not prod.valid:
            break

        if strict_search:
            # Ensure the producer's output is consumed by exactly one op
            outs = prod.options.outputs
            if not outs:
                break
            if len(activations[outs[0]].consumer_ops) != 1:
                current_op = None
                break  # early break

        current_op = prod

    if len(op_sequence) == needed:
        return tuple(reversed(op_sequence))
    return None


def _find_operator_sequence_forward(
    op_first: Optional[Operator],
    *layer_types: Union[LayerType, str, Callable],
    strict_search: bool = True,
) -> Optional[Tuple[Operator, ...]]:
    if not isinstance(op_first, Operator):
        raise TypeError(f"op_last must be an Operator instance, got={type(op_first)}")
    if not op_first.valid:
        return None
    if getattr(op_first, "_is_connection_op", False):
        return None

    layer_types = parse_layer_sequence(layer_types)

    def _match_pattern(current_op: Operator, pattern) -> bool:
        lt = current_op.layertype
        if isinstance(pattern, LayerType):
            return lt == pattern
        if callable(pattern):
            return pattern(current_op)
        raise NotImplementedError(f"Unsupported pattern type: {type(pattern)}")

    if strict_search:
        op_sequence: List[Operator] = []
        current_op = op_first
        needed = len(layer_types)
        for pattern in layer_types:
            if current_op is None or not current_op.valid:
                break
            if not _match_pattern(current_op, pattern):
                break
            op_sequence.append(current_op)
            outact = current_op.outacts[0]
            if 1 != len(outact.consumer_ops):
                break
            current_op = outact.consumer_ops[0]

        if len(op_sequence) == needed:
            return tuple(op_sequence)
        return None

    visited: Set[Tuple[int, int]] = set()

    def _dfs(current_op: Optional[Operator], pattern_idx: int) -> Optional[Tuple[Operator, ...]]:
        if current_op is None or not current_op.valid:
            return None
        if getattr(current_op, "_is_connection_op", False):
            return None
        state = (id(current_op), pattern_idx)
        if state in visited:
            return None
        visited.add(state)

        if not _match_pattern(current_op, layer_types[pattern_idx]):
            return None

        if pattern_idx == len(layer_types) - 1:
            return (current_op,)

        outact = current_op.outacts[0]
        for next_op in outact.consumer_ops:
            if getattr(next_op, "_is_connection_op", False):
                continue
            sub_path = _dfs(next_op, pattern_idx + 1)
            if sub_path is not None:
                return (current_op,) + sub_path
        return None

    return _dfs(op_first, 0)


def is_prev_op_basic_npu_op_pattern(x: Operator) -> bool:
    """
    pattern check like:
        npu_op / npu_op + actfn
    """
    if x is None:
        return False
    lt = x.layertype
    if is_actfunc_type(lt):
        prev_lt = x.inacts[0].producer_op.layertype
        return prev_lt in BASIC_NHWC_OPS
    return lt in BASIC_NHWC_OPS


def npu_stride_preserving_reshape(op: Operator):
    return is_reshape_with_expr("1hwc->11(hw)c")(op) or is_reshape_with_expr(
        "11(hw)c->1hwc"
    )(op)


def is_reduce_with_keep_dims(op: Operator):
    return op.layertype in REDUCE_OPS and op.options.keep_dims


def is_basic_npu_op(x: Operator) -> bool:
    if x is None:
        return False
    lt = getattr(x, "layertype", x)
    return lt in BASIC_NHWC_OPS and lt != LayerType.MatMul


def check_input_npu_stride(last_op: Operator, max_depth=6, except_fn=None):
    depth = 0
    curr_op = last_op

    while depth < max_depth:
        if curr_op is None:
            return False
        if not curr_op.valid:
            return False
        if getattr(curr_op, "exclude_from_transform", False):
            return False
        if callable(except_fn) and except_fn(curr_op):
            return False
        if is_prev_op_basic_npu_op_pattern(curr_op):
            return True
        if (
            curr_op.layertype in NPU_STRIDE_PRESERVING
            or npu_stride_preserving_reshape(curr_op)
            or is_reduce_with_keep_dims(curr_op)
        ):
            if len(curr_op.inacts) == 1:
                curr_op = curr_op.inacts[0].producer_op
            else:
                for inact in curr_op.inacts:
                    response = check_input_npu_stride(
                        inact.producer_op, max_depth - depth
                    )
                    if response:
                        return True
                return False
        else:
            return False
        depth += 1
    return False


def check_output_npu_stride(start_op: Operator, max_depth=6):
    depth = 0
    curr_op = start_op
    while depth < max_depth:
        if curr_op is None:
            return False
        if curr_op.layertype in BASIC_NHWC_OPS:
            return True
        if (
            curr_op.layertype in NPU_STRIDE_PRESERVING
            or npu_stride_preserving_reshape(curr_op)
            or is_reduce_with_keep_dims(curr_op)
        ):
            if not curr_op.outacts[0].consumer_ops:
                return False
            curr_op = curr_op.outacts[0].consumer_ops[0]
            depth += 1
        else:
            return False
    return False


def get_channel_axes(in_shape, out_shape, include_ones=True) -> Tuple[int] | None:
    if 4 != len(in_shape):
        return None
    n, h, w, c = in_shape
    out_shape = tuple(map(int, out_shape))
    ans = None
    for i in range(len(out_shape) - 1, -1, -1):
        acc = math.prod(out_shape[i:])
        if acc > c:
            return None
        if acc == c:
            ans = i
            break
    if ans is None:
        return None
    if include_ones:
        while ans > 0:
            if out_shape[ans - 1] == 1:
                ans -= 1
            else:
                break
    return tuple(range(ans, len(out_shape)))


def is_reducidle_reshapes(reshape0, reshape1):
    # fixme: generalize
    act0 = reshape0.inacts[0]
    act1 = reshape1.inacts[0]
    act2 = reshape1.outacts[0]
    if act0.src_dim == act1.src_dim == 4 and act2.src_dim < 4:
        return False

    def get_effective_shape(act):
        def gen():
            for s in act.src_shape:
                if s != 1 or getattr(s, "dynamic", False):
                    yield int(s)

        return tuple(gen())

    if act1.src_dim == 4 and (act0.src_dim < 4 or act2.src_dim < 4):
        return False

    if (
        get_effective_shape(act0) == get_effective_shape(act2)
        or get_effective_shape(act0) == get_effective_shape(act1)
        or get_effective_shape(act1) == get_effective_shape(act2)
    ):
        return True
    if act0.src_dim == act2.src_dim == 4 and all(not x.dynamic for x in act0.src_shape):
        return True
    if reshape_check("n(ab)(cd)e->nabcde", act0.src_shape, act2.src_shape):
        return True
    if reshape_check("1ab(cde)->abcde", act0.src_shape, act2.src_shape):
        return True
    return False


def is_shape_irrelevant_single_op(op: Operator) -> bool:
    is_ok = False
    if op.layertype in (LayerType.LayerNormalization, LayerType.RmsNormalization):
        c = int(op.inacts[0].src_shape[-1])
        is_ok = op.options.normalized_shape == (c,)
    elif is_actfunc_type(op):
        is_ok = True
    elif is_linear_conv(op):
        is_ok = True
    elif op.layertype in (LayerType.AddingConstant, LayerType.MultiplyConstant):
        inact = op.inacts[0]
        outact = op.outacts[0]
        is_ok = inact.src_shape == outact.src_shape
    return is_ok


def is_spatial_shape_irrelevant_single_op(op: Operator) -> bool:
    if is_shape_irrelevant_single_op(op):
        inact = op.inacts[0]
        outact = op.outacts[0]
        return (
            4 == inact.src_dim == outact.src_dim
            and (inact.src_shape[1:3] == outact.src_shape[1:3])
            and inact.src_shape[0] == outact.src_shape[0] == 1
        )

    return False


def get_shape_irrelevant_single_op_sequence_until(
    last_op: Operator, max_depth=8
) -> List[Operator]:
    depth = 0
    curr_op = last_op
    sequence = []

    while depth < max_depth:
        if (
            curr_op is None
            or not curr_op.valid
            or getattr(curr_op, "exclude_from_transform", False)
        ):
            return []
        if 1 == len(
            curr_op.inacts[0].consumer_ops
        ) and is_spatial_shape_irrelevant_single_op(curr_op):
            sequence.append(curr_op)
            curr_op = curr_op.inacts[0].producer_op
            depth += 1
        else:
            return list(reversed(sequence))
    return []


def check_forward_direction_until_output_strict(
    op_begin: Operator, allowable_layer_types: Set[LayerType], max_depth=6
) -> List[Operator] | None:
    curr = op_begin
    lst = []
    for depth in range(max_depth):
        if curr is None or not curr.valid:
            return None
        lst.append(curr)
        if curr.layertype == LayerType.Output:
            return lst
        if curr.layertype not in allowable_layer_types and depth != 0:
            return None
        if len(curr.outacts) != 1 or len(curr.outacts[0].consumer_ops) != 1:
            return None
        curr = curr.outacts[0].consumer_ops[0]
    return None
