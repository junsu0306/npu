from __future__ import annotations

import dataclasses
from typing import List, Any, Optional, Tuple, Dict, Set, Sequence

import numpy

from mblt.core import (
    ActivationSpec,
    TensorSpec,
    TensorIndex,
    LayerType,
    ArrayWrapper,
    Operator,
    SubGraph,
)
from mblt.core._optionsimpl import OptionsRegistry as LayerOptionsRegistry
from mblt.operator.opkind import (
    BIOP_ARITHMETIC,
    BIOP_ARITHMETIC_CONST,
    ACTIVATION_FUNCTIONS,
)
from mblt.operator.utils import broadcast_shape
from .util.pattern_util import is_actfunc_type

__all__ = ["MbltSubGraphBuilder"]

_BIOP_MAP = {v.name.lower()[:3]: v for v in BIOP_ARITHMETIC}
_BIOP_CONST_MAP = {v.name.lower()[:3]: v for v in BIOP_ARITHMETIC_CONST}
_ACTFUNC_MAP = {v.name.lower(): v for v in ACTIVATION_FUNCTIONS}
_ACTFUNC_MAP["softmax"] = LayerType.Softmax


def _get_unique_name(name: str, pool: Set[str] | Dict[str, Any]):
    new_name = name
    i = 0
    while new_name in pool:
        new_name = name + "_" + str(i)
        i += 1
    return new_name


def _reduce_constant_for_broadcast(input_shape, output_shape, const, epsilon=None):
    if len(const.shape) > len(input_shape):
        return None
    if len(const.shape) < len(input_shape):
        new_shape = (1,) * (len(input_shape) - len(const.shape)) + tuple(const.shape)
        const = numpy.reshape(const, new_shape)
    const_shape = const.shape
    reduce_axes = []
    for ax in range(len(const_shape)):
        target = numpy.take(const, [0], axis=ax)
        # if epsilon is None:
        #     is_equal = numpy.all(const == target)
        # else:
        # is_equal = numpy.allclose(const, target, atol=epsilon, rtol=0)
        is_equal = numpy.allclose(const, target)
        if is_equal:
            reduce_axes.append(ax)

    best_shape = list(const_shape)
    for ax in reduce_axes:
        trial = tuple(1 if idx == ax else x for idx, x in enumerate(best_shape))
        broadcastable = all(
            max(ishape, trial[i]) == output_shape[i]
            for i, ishape in enumerate(input_shape)
        )
        if broadcastable:
            best_shape[ax] = 1
    if tuple(best_shape) == const_shape:
        return const, tuple(best_shape)
    reduced = const
    for ax in range(const.ndim):
        if best_shape[ax] == 1 and const_shape[ax] != 1:
            reduced = numpy.take(reduced, [0], axis=ax)
    return reduced, tuple(best_shape)


def _reduce_const_shape(input_shape, const, epsilon=None):
    output_shape = broadcast_shape(input_shape, const.shape)
    reduced = _reduce_constant_for_broadcast(
        tuple(map(int, input_shape)),
        tuple(map(int, output_shape)),
        const,
        epsilon=epsilon,
    )
    if reduced is not None:
        const = reduced[0]
    const_rank = const.ndim
    if const.shape[: const_rank - 1] == (1,) * (const_rank - 1):
        const = const.reshape(-1)
    return const


class MbltSubGraphBuilder:
    """provides context for subgraph creation."""

    _activation_cls = ActivationSpec
    _op_cls = Operator

    def __init__(self):
        self._operators: List[Operator] = []
        self._activations: List[ActivationSpec] = []
        self._tensors: List[TensorSpec] = []
        self._act_to_idx: Dict[str, int] = {}
        self._tensor_to_idx: Dict[str, int] = {}
        self._inputs = []
        self._outputs = []

    @property
    def activations(self):
        return self._activations

    @property
    def tensors(self):
        return self._tensors

    @property
    def operators(self):
        return self._operators

    def update_internal_connectivity(self):
        for act in self._activations:
            act.consumer_ops.clear()
        for op in self._operators:
            for oidx in op.options.outputs:
                self._activations[oidx].producer_op = op
            if op.layertype == LayerType.Input:
                continue
            for iidx in op.options.inputs:
                self._activations[iidx].consumer_ops.append(op)

    def build(self, name: str = "", unsupported=True, stateful=False) -> SubGraph:
        sg = SubGraph(
            name=name,
            operators=self._operators,
            inputs=self._inputs,
            outputs=self._outputs,
            tensors=self._tensors,
            activations=self._activations,
            unsupported=unsupported,
            stateful=stateful,
        )
        for op in self._operators:
            op.set_subgraph(sg)
            op.unsupported = unsupported

        sg.update_connectivity()
        sg.remove_dangling_activations()
        sg.update_graph_in_out()
        return sg

    def add_activation(self, act) -> int:
        """returns the index of an added activation."""
        act_idx = len(self._activations)
        act.name = _get_unique_name(act.name, self._act_to_idx)
        self._activations.append(act)
        self._act_to_idx[act.name] = act_idx
        return act_idx

    def _add_weight(self, weight: numpy.ndarray, weight_name):
        """returns the index of an added tensor."""
        weight_name = _get_unique_name(weight_name, self._tensor_to_idx)
        tensor_idx = len(self._tensors)
        if isinstance(weight, (float, int)):
            weight = numpy.array(weight)

        if isinstance(weight, ArrayWrapper):
            pass
        elif isinstance(weight, numpy.ndarray):
            weight = ArrayWrapper(weight)
        else:
            NotImplementedError(f"add_weight not implemented for type={type(weight)}")
        tensor = TensorSpec(
            name=weight_name, dtype=weight.dtype, shape=tuple(weight.shape)
        )
        tensor.set_value(weight)
        self._tensors.append(tensor)
        self._tensor_to_idx[tensor.name] = tensor_idx
        return tensor_idx

    def _make_single_output(
        self,
        inputs,
        opname="",
        layertype=None,
        default_opname="",
        **kwargs,
    ):
        assert layertype is not None
        if not opname:
            opname = default_opname + str(len(self._operators))

        options_cls = LayerOptionsRegistry.getcls(layertype)

        tensor_index_fields = [
            f.name
            for f in dataclasses.fields(options_cls)
            if f.type.__name__ == "TensorIndex"
        ]

        kw = {}
        for k, v in kwargs.items():
            if k in tensor_index_fields:
                if v is not None:
                    kw[k] = self._add_weight(v, f"{opname}.{k}")
            else:
                kw[k] = v

        if not isinstance(inputs, (tuple, list)):
            inputs = (inputs,)
        kw["inputs"] = tuple(self.get_activation_index(a) for a in inputs)
        kw["outputs"] = (-1,)  # will be filled later
        options = options_cls(**kw)
        op = self._op_cls(options=options)
        # we seed this sometimes. for instance, Expand
        call_kwargs = {}
        for k in tensor_index_fields:
            if k in kw:
                call_kwargs[k] = self._tensors[kw[k]]
        output = op(*inputs, **call_kwargs)
        if isinstance(output, tuple):
            output = output[0]
        output.name = opname
        output.producer_op = op
        output_idx = self.add_activation(output)
        op.options.outputs = (output_idx,)
        self._operators.append(op)
        return output

    def _make_multiple_output(
        self,
        inputs,
        num_outputs: int,
        opname="",
        layertype=None,
        default_opname="",
        **kwargs,
    ):
        assert layertype is not None
        if not opname:
            opname = default_opname + str(len(self._operators))

        options_cls = LayerOptionsRegistry.getcls(layertype)

        tensor_index_fields = [
            f.name
            for f in dataclasses.fields(options_cls)
            if f.type.__name__ == "TensorIndex"
        ]

        kw = {}
        for k, v in kwargs.items():
            if k in tensor_index_fields:
                if v is not None:
                    kw[k] = self._add_weight(v, f"{opname}.{k}")
            else:
                kw[k] = v

        if not isinstance(inputs, (tuple, list)):
            inputs = (inputs,)
        kw["inputs"] = tuple(self.get_activation_index(a) for a in inputs)
        kw["outputs"] = (-1,) * num_outputs  # will be filled later
        options = options_cls(**kw)
        op = self._op_cls(options=options)
        call_kwargs = {}
        for k in tensor_index_fields:
            if k in kw:
                call_kwargs[k] = self._tensors[kw[k]]
        outputs = op(*inputs, **call_kwargs)
        outputs[0].name = opname
        output_indices = []
        for output in outputs:
            output.producer_op = op
            output_indices.append(self.add_activation(output))
        op.options.outputs = tuple(output_indices)
        self._operators.append(op)
        return outputs

    def make_matmul(
        self, left: ActivationSpec, right: ActivationSpec, repeat=(-1, -1), opname=""
    ):
        if not opname:
            opname = left.name + "/matmul"
        return self._make_single_output(
            (left, right),
            opname=opname,
            layertype=LayerType.MatMul,
            repeat=repeat,
        )

    def make_conv2d(
        self,
        x: ActivationSpec,
        in_channels,
        out_channels,
        h_kernel=1,
        w_kernel=1,
        h_stride=1,
        w_stride=1,
        h_dilation=1,
        w_dilation=1,
        west_padding=0,
        east_padding=0,
        north_padding=0,
        south_padding=0,
        padding_list=None,
        group_number=1,
        weight=None,
        bias=None,
        opname="",
    ):
        assert x.src_dim == 4, f"expected dim=4, but got {x.src_shape}"
        assert weight.shape == (
            out_channels,
            in_channels // group_number,
            h_kernel,
            w_kernel,
        ), f"weight shape mismatch: {weight.shape} != {(out_channels, in_channels // group_number, h_kernel, w_kernel)}"

        if not opname:
            opname = x.name + "/conv2d"
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.Convolution,
            in_channels=in_channels,
            out_channels=out_channels,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            h_stride=h_stride,
            w_stride=w_stride,
            h_dilation=h_dilation,
            w_dilation=w_dilation,
            west_padding=west_padding,
            east_padding=east_padding,
            north_padding=north_padding,
            south_padding=south_padding,
            padding_list=tuple() if not padding_list else padding_list,
            group_number=group_number,
            weight=weight,
            bias=bias,
        )

    def make_conv3d(
        self,
        x: ActivationSpec,
        in_channels,
        out_channels,
        h_kernel=1,
        w_kernel=1,
        d_kernel=1,
        h_stride=1,
        w_stride=1,
        d_stride=1,
        h_dilation=1,
        w_dilation=1,
        d_dilation=1,
        west_padding=0,
        east_padding=0,
        north_padding=0,
        south_padding=0,
        front_padding=0,
        back_padding=0,
        padding_list=None,
        group_number=1,
        weight=None,
        bias=None,
        channel_last=True,
        opname="",
    ):
        assert x.src_dim == 5, f"expected dim=5, but got {x.src_shape}"
        assert (
            weight is not None and weight.ndim == 5
        ), "weight shape mismatch: expected 5d conv3d weight"

        if not opname:
            opname = x.name + "/conv3d"
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.Convolution3d,
            in_channels=in_channels,
            out_channels=out_channels,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            d_kernel=d_kernel,
            h_stride=h_stride,
            w_stride=w_stride,
            d_stride=d_stride,
            h_dilation=h_dilation,
            w_dilation=w_dilation,
            d_dilation=d_dilation,
            west_padding=west_padding,
            east_padding=east_padding,
            north_padding=north_padding,
            south_padding=south_padding,
            front_padding=front_padding,
            back_padding=back_padding,
            padding_list=tuple() if not padding_list else padding_list,
            group_number=group_number,
            weight=weight,
            bias=bias,
            channel_last=channel_last,
        )

    def make_conv1d(
        self,
        x: ActivationSpec,
        in_channels,
        out_channels,
        kernel=1,
        stride=1,
        dilation=1,
        front_padding=0,
        end_padding=0,
        padding_list=None,
        group_number=1,
        weight=None,
        bias=None,
        opname="",
    ):
        assert x.src_dim == 3, f"expected dim=3, but got {x.src_shape}"
        assert weight.shape == (out_channels, in_channels // group_number, kernel)

        if not opname:
            opname = x.name + "/conv1d"

        n, seq_len, c = x.src_shape
        new_x = self.make_reshape(x, (n, 1, seq_len, c))
        assert weight.ndim == 3
        weight = numpy.expand_dims(weight, axis=2)
        outact = self._make_single_output(
            new_x,
            opname=opname,
            layertype=LayerType.Convolution,
            in_channels=in_channels,
            out_channels=out_channels,
            h_kernel=1,
            w_kernel=kernel,
            h_stride=1,
            w_stride=stride,
            h_dilation=1,
            w_dilation=dilation,
            west_padding=front_padding,
            east_padding=end_padding,
            north_padding=0,
            south_padding=0,
            padding_list=tuple() if not padding_list else padding_list,
            group_number=group_number,
            weight=weight,
            bias=bias,
        )
        n, h, seq_len, c = outact.src_shape
        assert h == 1, f"conv1d output assertion failed: h={h}"
        outact = self.make_reshape(outact, (n, seq_len, c))
        return outact

    def make_group_conv2d(
        self,
        x: ActivationSpec,
        in_channels,
        out_channels,
        h_kernel=1,
        w_kernel=1,
        h_stride=1,
        w_stride=1,
        h_dilation=1,
        w_dilation=1,
        west_padding=0,
        east_padding=0,
        north_padding=0,
        south_padding=0,
        padding_list=None,
        group_number=None,
        weight=None,
        bias=None,
        opname="",
    ):
        assert x.src_dim == 4, f"expected dim=4, but got {x.src_shape}"
        assert weight.shape == (
            out_channels,
            in_channels // group_number,
            h_kernel,
            w_kernel,
        )
        if not opname:
            opname = x.name + "/dconv2d"
        if padding_list is None:
            padding_list = tuple()
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.GroupConvolution,
            in_channels=in_channels,
            out_channels=out_channels,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            h_stride=h_stride,
            w_stride=w_stride,
            h_dilation=h_dilation,
            w_dilation=w_dilation,
            west_padding=west_padding,
            east_padding=east_padding,
            north_padding=north_padding,
            south_padding=south_padding,
            padding_list=padding_list,
            group_number=group_number,
            weight=weight,
            bias=bias,
        )

    def make_depthwise_conv2d(
        self,
        x: ActivationSpec,
        in_channels,
        out_channels,
        h_kernel=1,
        w_kernel=1,
        h_stride=1,
        w_stride=1,
        h_dilation=1,
        w_dilation=1,
        west_padding=0,
        east_padding=0,
        north_padding=0,
        south_padding=0,
        padding_list=None,
        group_number=None,
        weight=None,
        bias=None,
        opname="",
    ):
        assert x.src_dim == 4, f"expected dim=4, but got {x.src_shape}"
        assert weight.shape == (out_channels, 1, h_kernel, w_kernel)

        if not opname:
            opname = x.name + "/dconv2d"
        if padding_list is None:
            padding_list = tuple()
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.DepthwiseConvolution,
            in_channels=in_channels,
            out_channels=out_channels,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            h_stride=h_stride,
            w_stride=w_stride,
            h_dilation=h_dilation,
            w_dilation=w_dilation,
            west_padding=west_padding,
            east_padding=east_padding,
            north_padding=north_padding,
            south_padding=south_padding,
            padding_list=padding_list,
            group_number=int(in_channels),
            weight=weight,
            bias=bias,
        )

    def make_transposeconv2d(
        self,
        x: ActivationSpec,
        in_channels,
        out_channels,
        h_kernel=1,
        w_kernel=1,
        h_stride=1,
        w_stride=1,
        h_dilation=1,
        w_dilation=1,
        west_padding=0,
        east_padding=0,
        north_padding=0,
        south_padding=0,
        padding_list=None,
        group_number=1,
        weight=None,
        bias=None,
        og_padding_list=None,
        og_out_padding_list=None,
        opname="",
    ):
        assert x.src_dim == 4, f"expected dim=4, but got {x.src_shape}"
        assert weight.shape == (
            out_channels,
            in_channels // group_number,
            h_kernel,
            w_kernel,
        )
        if og_padding_list is None:
            og_padding_list = tuple()
        if og_out_padding_list is None:
            og_out_padding_list = tuple()
        if padding_list is None:
            padding_list = tuple()

        if not opname:
            opname = x.name + "/tconv2d"
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.TransposeConvolution,
            in_channels=in_channels,
            out_channels=out_channels,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            h_stride=h_stride,
            w_stride=w_stride,
            h_dilation=h_dilation,
            w_dilation=w_dilation,
            west_padding=west_padding,
            east_padding=east_padding,
            north_padding=north_padding,
            south_padding=south_padding,
            padding_list=padding_list,
            group_number=group_number,
            weight=weight,
            bias=bias,
            og_padding_list=og_padding_list,
            og_out_padding_list=og_out_padding_list,
        )

    def make_act_func(self, x: ActivationSpec, kind, opname="", **kwargs):
        if kind not in _ACTFUNC_MAP:
            raise NotImplementedError(f"{kind} is not implemented.")
        if not opname:
            opname = x.name + "/" + kind
        return self._make_single_output(
            x, layertype=_ACTFUNC_MAP[kind], opname=opname, **kwargs
        )

    def make_abs(self, x: ActivationSpec, opname=""):
        return self.make_act_func(x, "abs", opname=opname)

    def make_clip(
        self, x: ActivationSpec, clip_min_value=None, clip_max_value=None, opname=""
    ):
        return self.make_act_func(
            x,
            kind="clip",
            clip_min_value=clip_min_value,
            clip_max_value=clip_max_value,
            opname=opname,
        )

    def make_sigmoid(self, x: ActivationSpec, alpha=1.0, opname=""):
        return self.make_act_func(x, "sigmoid", alpha=alpha, opname=opname)

    def make_hardsigmoid(self, x: ActivationSpec, alpha=None, beta=None, opname=""):
        return self.make_act_func(
            x, "hardsigmoid", alpha=alpha, beta=beta, opname=opname
        )

    def make_hardshrink(self, x: ActivationSpec, lambd=0.5, opname=""):
        return self.make_act_func(x, "hardshrink", lambd=lambd, opname=opname)

    def make_relu6(self, x: ActivationSpec, opname=""):
        return self.make_clip(x, 0.0, 6.0, opname)

    def make_softplus(self, x: ActivationSpec, beta=1.0, threshold=2.0, opname=""):
        if not opname:
            opname = x.name + "/softplus"
        return self.make_act_func(
            x, "softplus", beta=beta, threshold=threshold, opname=opname
        )

    def make_softsign(self, x: ActivationSpec, opname=""):
        if not opname:
            opname = x.name + "/softsign"
        return self.make_act_func(x, "softsign", opname=opname)

    def make_celu(self, x: ActivationSpec, alpha=1.0, opname=""):
        return self.make_act_func(x, "celu", alpha=alpha, opname=opname)

    def make_selu(self, x: ActivationSpec, opname=""):
        return self.make_act_func(x, "selu", opname=opname)

    def make_mish(self, x: ActivationSpec, opname=""):
        return self.make_act_func(x, "mish", opname=opname)

    def make_tanh(self, x: ActivationSpec, opname=""):
        return self.make_act_func(x, "tanh", opname=opname)

    def make_exp(self, x: ActivationSpec, opname=""):
        return self.make_act_func(x, "exp", opname=opname)

    def make_swish(self, x: ActivationSpec, opname=""):
        return self.make_act_func(x, "swish", opname=opname)

    def make_hardswish(self, x: ActivationSpec, opname=""):
        return self.make_act_func(x, "hardswish", opname=opname)

    def make_elu(self, x: ActivationSpec, leaky_alpha=1.0, opname=""):
        return self.make_act_func(x, "elu", leaky_alpha=leaky_alpha, opname=opname)

    def make_gelu(self, x: ActivationSpec, approximate=False, opname=""):
        return self.make_act_func(x, "gelu", approximate=approximate, opname=opname)

    def make_relu(self, x: ActivationSpec, opname=""):
        return self.make_act_func(x, "relu", opname=opname)

    def make_prelu(self, x: ActivationSpec, leaky_alpha, opname=""):
        return self.make_act_func(x, "prelu", leaky_alpha=leaky_alpha, opname=opname)

    def make_hardtanh(self, x: ActivationSpec, opname="", **kwargs):
        return self.make_act_func(x, "hardtanh", opname=opname, **kwargs)

    def make_log(self, x: ActivationSpec, opname=""):
        return self.make_act_func(x, "log", opname=opname)

    def make_logsigmoid(self, x: ActivationSpec, opname=""):
        return self.make_act_func(x, "logsigmoid", opname=opname)

    def make_leaky_relu(self, x: ActivationSpec, leaky_alpha=0.01, opname=""):
        return self.make_act_func(
            x, "leakyrelu", leaky_alpha=leaky_alpha, opname=opname
        )

    def _is_activation_type(self, x):
        return isinstance(x, self._activation_cls)

    def make_biop(
        self,
        left: ActivationSpec | Any,
        right: ActivationSpec | Any,
        opkind: str,
        opname="",
        epsilon=None,
    ):
        if not opname:
            opname = opkind
        if self._is_activation_type(left) and self._is_activation_type(right):
            return self._make_single_output(
                (left, right), opname=opname, layertype=_BIOP_MAP[opkind]
            )
        elif self._is_activation_type(left):
            if isinstance(right, (int, float)):
                right = numpy.array(right)
            reduced_const = _reduce_const_shape(
                left.src_shape, const=right, epsilon=epsilon
            )
            return self._make_single_output(
                left,
                opname=opname,
                layertype=_BIOP_CONST_MAP[opkind],
                constant=reduced_const,
                is_const_first=False,
                shape=right.shape,
            )
        elif self._is_activation_type(right):
            if isinstance(left, (int, float)):
                left = numpy.array(left)
            reduced_const = _reduce_const_shape(
                right.src_shape, const=left, epsilon=epsilon
            )
            return self._make_single_output(
                right,
                opname=opname,
                layertype=_BIOP_CONST_MAP[opkind],
                constant=reduced_const,
                is_const_first=True,
                shape=left.shape,
            )
        else:
            raise NotImplementedError(
                f"{type(left)} and {type(right)} are not implemented."
            )

    def make_add(self, left: Any, right: Any, opname="", epsilon=None):
        return self.make_biop(left, right, opkind="add", opname=opname, epsilon=epsilon)

    def make_sub(self, left: Any, right: Any, opname="", epsilon=None):
        return self.make_biop(left, right, opkind="sub", opname=opname, epsilon=epsilon)

    def make_div(self, left: Any, right: Any, opname="", epsilon=None):
        return self.make_biop(left, right, opkind="div", opname=opname, epsilon=epsilon)

    def make_mul(self, left: Any, right: Any, opname="", epsilon=None):
        return self.make_biop(left, right, opkind="mul", opname=opname, epsilon=epsilon)

    def make_concatenate(self, inputs, axis: int, opname="", **kwargs):
        if not opname:
            opname = inputs[0].name + "/concat"
        return self._make_single_output(
            inputs,
            opname=opname,
            layertype=LayerType.Concatenate,
            axis=axis,
        )

    def make_identity(self, x, opname=""):
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.Identity,
            default_opname="identity",
        )

    def make_output(self, x, orig_name: str = ""):
        # we do not make new activation for this op
        act_idx = self.get_activation_index(x)
        options_cls = LayerOptionsRegistry.getcls(LayerType.Output)
        op = self._op_cls(
            name=x.name,
            options=options_cls(
                inputs=(act_idx,), outputs=(act_idx,), orig_name=orig_name
            ),
        )
        self._operators.append(op)
        self._outputs.append(act_idx)
        return x

    def get_activation_index(self, x: ActivationSpec):
        if x.name not in self._act_to_idx:
            raise ValueError(
                f"activation with name={x.name} does not exists in this subgraph builder."
            )
        return self._act_to_idx[x.name]

    def make_input(self, x: ActivationSpec, orig_name: str = ""):
        # we do not make new activation for this op
        act_idx = self.get_activation_index(x)
        options_cls = LayerOptionsRegistry.getcls(LayerType.Input)
        op = self._op_cls(
            name=x.name,
            options=options_cls(
                inputs=(act_idx,), outputs=(act_idx,), orig_name=orig_name
            ),
        )
        self._operators.append(op)
        x.producer_op = op
        self._inputs.append(act_idx)
        return x

    def make_batchnorm(
        self,
        x: ActivationSpec,
        gamma,
        beta,
        moving_mean,
        moving_var,
        epsilon,
        opname="",
    ):
        if not opname:
            opname = x.name + "/batchnorm2d"
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.Batchnorm,
            gamma=gamma,
            beta=beta,
            moving_mean=moving_mean,
            moving_var=moving_var,
            epsilon=epsilon,
        )

    def make_instancenorm(
        self,
        x: ActivationSpec,
        epsilon,
        scale,
        bias,
        num_groups=-1,
        group_order=-1,
        opname="",
    ):
        if not opname:
            opname = x.name + "/instancenorm"
        return self._make_single_output(
            x,
            layertype=LayerType.InstanceNormalization,
            opname=opname,
            epsilon=epsilon,
            scale=scale,
            bias=bias,
            num_groups=num_groups,
            group_order=group_order,
        )

    def make_reduce_rms(
        self, x: ActivationSpec, reduce_axes, keep_dims, epsilon=None, opname=""
    ):
        if not opname:
            opname = x.name + "/reducerms"
        return self._make_single_output(
            x,
            layertype=LayerType.ReduceRMS,
            opname=opname,
            reduce_axes=reduce_axes,
            keep_dims=keep_dims,
            epsilon=epsilon,
        )

    def make_mean_centering(self, x: ActivationSpec, axes, opname=""):
        if not opname:
            opname = x.name + "/centering"
        return self._make_single_output(
            x,
            layertype=LayerType.MeanCentering,
            opname=opname,
            axes=axes,
        )

    def make_rmsnorm(
        self,
        x: ActivationSpec,
        epsilon,
        scale,
        rms_center=None,
        normalized_shape: Optional[Tuple] = None,
        opname="",
    ):
        if not opname:
            opname = x.name + "/rmsnorm"
        if normalized_shape is None:
            normalized_shape = (x.src_shape[-1],)
        epsilon = numpy.array(epsilon)
        return self._make_single_output(
            x,
            layertype=LayerType.RmsNormalization,
            opname=opname,
            epsilon=epsilon,
            scale=scale,
            rms_center=rms_center,
            normalized_shape=normalized_shape,
        )

    def make_groupnorm(
        self,
        x: ActivationSpec,
        num_groups,
        scale=None,
        bias=None,
        epsilon=None,
        opname="",
    ):
        if not opname:
            opname = x.name + "/groupnorm"
        return self._make_single_output(
            x,
            layertype=LayerType.GroupNormalization,
            opname=opname,
            num_groups=num_groups,
            scale=scale,
            bias=bias,
            epsilon=epsilon,
        )

    def make_l1normalization(
        self, x: ActivationSpec, norm_axis, epsilon=None, opname=""
    ):
        if not opname:
            opname = x.name + "/l1norm"
        return self._make_single_output(
            x,
            layertype=LayerType.L1Normalization,
            opname=opname,
            norm_axis=norm_axis,
        )

    def make_l2normalization(
        self, x: ActivationSpec, norm_axis, epsilon=None, opname=""
    ):
        if not opname:
            opname = x.name + "/l2norm"
        if epsilon is None:
            epsilon = 1e-12
        return self._make_single_output(
            x,
            layertype=LayerType.L2Normalization,
            opname=opname,
            norm_axis=norm_axis,
            epsilon=epsilon,
        )

    def make_global_response_normalization(
        self, x: ActivationSpec, scale=None, bias=None, epsilon: float = 1e-6, opname=""
    ):
        if not opname:
            opname = x.name + "/global_response_norm"
        csize = x.src_shape[-1]
        if scale is None:
            scale = numpy.ones(csize, dtype="float32")
        if bias is None:
            bias = numpy.zeros(csize, dtype="float32")
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.GlobalResponseNormalization,
            scale=scale,
            bias=bias,
            epsilon=epsilon,
        )

    def make_sumnormalization(
        self, x: ActivationSpec, norm_axis, epsilon=None, opname=""
    ):
        if not opname:
            opname = x.name + "/sumnorm"
        return self._make_single_output(
            x,
            layertype=LayerType.SumNormalization,
            opname=opname,
            norm_axis=norm_axis,
            epsilon=epsilon,
        )

    def make_layernorm(
        self,
        x: ActivationSpec,
        normalized_shape,
        epsilon,
        scale,
        bias=None,
        opname="",
    ):
        if not opname:
            opname = x.name + "/layernorm"
        if normalized_shape is None:
            normalized_shape = (x.src_shape[-1],)
        return self._make_single_output(
            x,
            layertype=LayerType.LayerNormalization,
            opname=opname,
            epsilon=epsilon,
            scale=scale,
            normalized_shape=normalized_shape,
            bias=bias,
        )

    def make_pow(self, input, exponent, opname=""):
        if not opname:
            opname = input.name + "/pow"
        return self._make_single_output(
            input,
            opname=opname,
            layertype=LayerType.Pow,
            exponent=exponent,
        )

    def make_rsqrt(self, input, opname=""):
        if not opname:
            opname = input.name + "/rsqrt"
        return self._make_single_output(
            input,
            opname=opname,
            layertype=LayerType.Rsqrt,
        )

    def make_pad(
        self,
        x: ActivationSpec,
        pad_mode: str,
        west_padding=0,
        east_padding=0,
        north_padding=0,
        south_padding=0,
        constant=0.0,
        padding_list=tuple(),
        opname="",
    ):
        # this is a supported 2d pad operation
        if not opname:
            opname = x.name + "/pad"
        assert x.src_dim == 4, f"expected dim=4, but got {x.src_shape}"

        return self._make_single_output(
            x,
            layertype=LayerType.Pad,
            opname=opname,
            pad_mode=pad_mode,
            west_padding=west_padding,
            east_padding=east_padding,
            north_padding=north_padding,
            south_padding=south_padding,
            constant=constant,
            padding_list=padding_list,
            channel_last=True,
        )

    def make_pad_generic(
        self,
        x: ActivationSpec,
        pad_mode: str,
        padding_list: List = None,
        constant: float = 0.0,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/pad"
        assert padding_list is not None, "padding_list must be provided"
        assert x.src_dim * 2 == len(
            padding_list
        ), f"input dim={x.src_dim}, padding_list={padding_list}"
        if pad_mode == "constant" and numpy.isinf(constant):
            if constant > 0:
                pad_mode = "inf"
            else:
                pad_mode = "-inf"
            constant = 0.0
        return self._make_single_output(
            x,
            layertype=LayerType.PadGeneric,
            opname=opname,
            pad_mode=pad_mode,
            constant=constant,
            padding_list=padding_list,
        )

    def _make_pooling(
        self,
        x: ActivationSpec,
        h_kernel: int,
        w_kernel: int,
        h_stride: int,
        w_stride: int,
        west_padding: int,
        east_padding: int,
        north_padding: int,
        south_padding: int,
        pool_type: str,
        pad_mode: str,
        h_dilation: int,
        w_dilation: int,
        padding_list=None,
        is_ceil_mode=False,
        is_include_pad=False,
        opname: str = "",
    ):

        if not opname:
            opname = x.name + "/pooling"

        if padding_list is None:
            padding_list = tuple()

        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.Pooling,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            h_stride=h_stride,
            w_stride=w_stride,
            west_padding=west_padding,
            east_padding=east_padding,
            north_padding=north_padding,
            south_padding=south_padding,
            pool_type=pool_type,
            pad_mode=pad_mode,
            h_dilation=h_dilation,
            w_dilation=w_dilation,
            padding_list=padding_list,
            is_ceil_mode=is_ceil_mode,
            is_include_pad=is_include_pad,
        )

    def make_global_avgpool(self, x: ActivationSpec, opname=""):
        if not opname:
            opname = x.name + "/global_avgpool"
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.GlobalAveragePooling,
        )

    def make_avgpool(
        self,
        x: ActivationSpec,
        h_kernel: int,
        w_kernel: int,
        h_stride: int,
        w_stride: int,
        west_padding: int,
        east_padding: int,
        north_padding: int,
        south_padding: int,
        pad_mode: str = "constant",
        h_dilation=1,
        w_dilation=1,
        padding_list=None,
        is_ceil_mode=False,
        is_include_pad=False,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/avgpool"
        return self._make_pooling(
            x,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            w_stride=w_stride,
            h_stride=h_stride,
            west_padding=west_padding,
            east_padding=east_padding,
            north_padding=north_padding,
            south_padding=south_padding,
            pool_type="AvgPool",
            pad_mode=pad_mode,
            h_dilation=h_dilation,
            w_dilation=w_dilation,
            padding_list=padding_list,
            is_ceil_mode=is_ceil_mode,
            is_include_pad=is_include_pad,
            opname=opname,
        )

    def make_maxpool(
        self,
        x: ActivationSpec,
        h_kernel: int,
        w_kernel: int,
        h_stride: int,
        w_stride: int,
        west_padding: int,
        east_padding: int,
        north_padding: int,
        south_padding: int,
        pad_mode: str,
        h_dilation=1,
        w_dilation=1,
        padding_list=None,
        is_ceil_mode=False,
        is_include_pad=False,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/maxpool"
        return self._make_pooling(
            x,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            h_stride=h_stride,
            w_stride=w_stride,
            west_padding=west_padding,
            east_padding=east_padding,
            north_padding=north_padding,
            south_padding=south_padding,
            pool_type="MaxPool",
            pad_mode=pad_mode,
            h_dilation=h_dilation,
            w_dilation=w_dilation,
            padding_list=padding_list,
            is_ceil_mode=is_ceil_mode,
            is_include_pad=is_include_pad,
            opname=opname,
        )

    def make_reduce_max(
        self,
        x: ActivationSpec,
        reduce_axes,
        keep_dims,
        noop_with_empty_axes=0,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/reducemax"
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.ReduceMax,
            reduce_axes=reduce_axes,
            keep_dims=keep_dims,
            noop_with_empty_axes=noop_with_empty_axes,
        )

    def make_reduce_min(
        self,
        x: ActivationSpec,
        reduce_axes,
        keep_dims,
        noop_with_empty_axes=0,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/reducemin"
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.ReduceMin,
            reduce_axes=reduce_axes,
            keep_dims=keep_dims,
            noop_with_empty_axes=noop_with_empty_axes,
        )

    def make_reduce_sum(
        self,
        x: ActivationSpec,
        reduce_axes,
        keep_dims,
        noop_with_empty_axes=0,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/reducesum"
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.ReduceSum,
            reduce_axes=reduce_axes,
            keep_dims=keep_dims,
            noop_with_empty_axes=noop_with_empty_axes,
        )

    def make_reduce_mean(
        self,
        x: ActivationSpec,
        reduce_axes,
        keep_dims,
        noop_with_empty_axes=0,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/reducemean"
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.ReduceMean,
            reduce_axes=reduce_axes,
            keep_dims=keep_dims,
            noop_with_empty_axes=noop_with_empty_axes,
        )

    def make_reduce_prod(
        self,
        x: ActivationSpec,
        reduce_axes,
        keep_dims,
        noop_with_empty_axes=0,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/reduceprod"
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.ReduceProd,
            reduce_axes=reduce_axes,
            keep_dims=keep_dims,
            noop_with_empty_axes=noop_with_empty_axes,
        )

    def make_reduce_l2(
        self,
        x: ActivationSpec,
        reduce_axes,
        keep_dims,
        noop_with_empty_axes=0,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/reducel2"
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.ReduceL2,
            reduce_axes=reduce_axes,
            keep_dims=keep_dims,
            noop_with_empty_axes=noop_with_empty_axes,
        )

    def make_neg(self, x: ActivationSpec, opname=""):
        if not opname:
            opname = x.name + "/neg"
        return self._make_single_output(x, opname=opname, layertype=LayerType.Neg)

    def make_reshape(self, x, new_shape=None, opname="", **kwargs):
        if not opname:
            opname = x.name + "/reshape"

        if not isinstance(new_shape, ActivationSpec):
            return self._make_single_output(
                x,
                opname=opname,
                layertype=LayerType.Reshape,
                new_shape=new_shape,
            )
        else:
            return self._make_single_output(
                (x, new_shape),
                opname=opname,
                layertype=LayerType.ReshapeV2,
                allowzero=0,
            )

    def make_resize(
        self,
        x: ActivationSpec,
        sizes,
        resize_type,
        resize_mode=None,
        transform_mode="half_pixel",
        roi=None,
        nearest_mode="round_prefer_floor",
        antialias=None,
        scales=None,
        cubic_coeff_a=None,
        exclude_outside=None,
        extrapolation_value=None,
        axes=None,
        keep_aspect_ratio_policy=None,
        opname="",
    ):
        if not opname:
            opname = x.name + "/resize"

        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.Resize,
            resize_type=resize_type,
            transform_mode=transform_mode,
            nearest_mode=nearest_mode,
            antialias=antialias,
            scales=scales,
            sizes=sizes,
            resize_mode=resize_mode,
            roi=roi,
            cubic_coeff_a=cubic_coeff_a,
            exclude_outside=exclude_outside,
            extrapolation_value=extrapolation_value,
            axes=axes,
            keep_aspect_ratio_policy=keep_aspect_ratio_policy,
        )

    def make_softmax(self, x: ActivationSpec, axis=-1, beta=1, opname=""):
        if not opname:
            opname = x.name + "/softmax"
        return self._make_single_output(
            x, opname=opname, layertype=LayerType.Softmax, axis=axis, beta=beta
        )

    def make_softshrink(self, x: ActivationSpec, lambd=0.5, opname=""):
        if not opname:
            opname = x.name + "/softshrink"
        return self._make_single_output(
            x, opname=opname, layertype=LayerType.Softshrink, lambd=lambd
        )

    def make_logsoftmax(self, x: ActivationSpec, axis=-1, opname=""):
        if not opname:
            opname = x.name + "/logsoftmax"
        return self._make_single_output(
            x, opname=opname, layertype=LayerType.LogSoftmax, axis=axis
        )

    def make_transpose(
        self,
        x,
        transpose_axes,
        opname="",
    ):
        if not opname:
            opname = x.name + "/transpose"
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.Transpose,
            transpose_axes=transpose_axes,
        )

    def make_slice(
        self,
        x: ActivationSpec,
        axis: Tuple[int, ...],
        start: Tuple[int, ...],
        end: Tuple[int, ...],
        step: Tuple[int, ...] | None = None,
        opname="",
    ):
        if not opname:
            opname = x.name + "/slice"

        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.Slice,
            axis=axis,
            start=start,
            end=end,
            step=step,
        )

    def new_activation(self, name, dtype, src_shape) -> Tuple[ActivationSpec, int]:
        outact = self._activation_cls(name=name, dtype=dtype, src_shape=src_shape)
        outact_idx = self.add_activation(outact)
        return outact, outact_idx

    def make_inputconst(self, constant, opname=""):
        if not opname:
            opname = "const" + str(len(self._operators))
        if not isinstance(constant, numpy.ndarray):
            constant = numpy.array(constant)
        shape = tuple(constant.shape)
        dtype = constant.dtype.name
        return self._make_single_output(
            [],
            opname=opname,
            layertype=LayerType.InputConstant,
            constant=constant,
            shape=shape,
            dtype=dtype,
        )

    def make_headerview(
        self, x: ActivationSpec, num_heads: int, batch_order: int = 0, opname=""
    ):
        if not opname:
            opname = x.name + "/headerview"
        assert num_heads > 0, f"num_heads={num_heads}"
        n, h, w, c = x.src_shape
        view_shape = tuple(map(int, (n, h * num_heads, w, c // num_heads)))
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.HeaderView,
            num_heads=num_heads,
            batch_order=batch_order,
            view_shape=view_shape,
        )

    def make_headerview_revert(
        self,
        x: ActivationSpec,
        revert_shape=None,
        num_heads: int = -1,
        batch_order: int = 0,
        opname="",
    ):
        if not opname:
            opname = x.name + "/headerviewrevert"
        if revert_shape is None:
            assert num_heads > 0, f"num_heads > 0 got num_heads={num_heads}"
            n, h, w, c = x.src_shape
            src_shape = (n, h // num_heads, w, c * num_heads)
        else:
            src_shape = revert_shape
            n, h, w, c = x.src_shape
            num_heads = int(revert_shape[-1]) // int(c)
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.HeaderViewRevert,
            revert_shape=src_shape,
            num_heads=num_heads,
            batch_order=batch_order,
        )

    def make_expand(self, x: ActivationSpec, constant, is_const_first=False, opname=""):
        if not opname:
            opname = x.name + "/expand"
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.Expand,
            constant=constant,
            is_const_first=is_const_first,
        )

    def make_einsum(self, x: ActivationSpec, equation: str, opname=""):
        if not opname:
            opname = x.name + "/einsum"
        return self._make_single_output(
            x, opname=opname, layertype=LayerType.Einsum, equation=equation
        )

    def make_gather(
        self, x: ActivationSpec, indices: ActivationSpec, axis: int = 0, opname=""
    ):
        if not opname:
            opname = x.name + "/gather"
        return self._make_single_output(
            (x, indices), opname=opname, layertype=LayerType.Gather, axis=axis
        )

    def make_gather_elements(
        self, x: ActivationSpec, indices: ActivationSpec, axis: int = 0, opname=""
    ):
        if not opname:
            opname = x.name + "/gather_elements"
        return self._make_single_output(
            (x, indices), opname=opname, layertype=LayerType.GatherElements, axis=axis
        )

    def make_scatternd(self, x: ActivationSpec, indices, updates, opname=""):
        if not opname:
            opname = x.name + "/scatternd"
        if isinstance(indices, ActivationSpec) and isinstance(updates, ActivationSpec):
            return self._make_single_output(
                (x, indices, updates), opname=opname, layertype=LayerType.ScatterND
            )
        raise NotImplementedError

    def make_ordered_patchify(
        self,
        x: ActivationSpec,
        h_kernel: int,
        w_kernel: int,
        order: int = 0,
        opname: str = "",
    ):
        if not opname:
            opname = x.name + "/ordered_patchify"
        n, h, w, c = x.src_shape
        h_kernel = int(h_kernel)
        w_kernel = int(w_kernel)
        h_grid = int(h) // h_kernel
        w_grid = int(w) // w_kernel
        if order == 0:
            src_shape = (n, h_grid * w_grid, h_kernel * w_kernel, c)
        elif order == 1:
            src_shape = (n, h_kernel * w_kernel, h_grid * w_grid, c)
        elif order == 2:
            src_shape = (n, h_grid * w_grid, h_kernel * w_kernel, c)
        else:
            raise NotImplementedError("order must be 0, 1 or 2")
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.OrderedPatchify,
            h_kernel=h_kernel,
            w_kernel=w_kernel,
            order=order,
        )

    def make_attention_mask(
        self,
        x: ActivationSpec,
        past_seqlen=0,
        is_sliding=False,
        sliding_window=1024,
        mask_type="causal_mask",
        opname="",
    ):
        if not opname:
            opname = x.name + "/attn_mask "

        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.StatefulAttentionMaskWrapper,
            past_seqlen=past_seqlen,
            is_sliding=is_sliding,
            sliding_window=sliding_window,
            mask_type=mask_type,
        )

    def make_rope(
        self,
        x: ActivationSpec,
        cos: ActivationSpec,
        sin: ActivationSpec,
        rope_type: int = 0,
        seq_len: int = 0,
        rotary_emb_dim: int = 0,
        opname="",
    ):
        if not opname:
            opname = x.name + "/rope"

        return self._make_single_output(
            (x, cos, sin),
            opname=opname,
            layertype=LayerType.StatefulRoPEWrapper,
            rope_type=rope_type,
            seqlen=seq_len,
            rotary_emb_dim=rotary_emb_dim,
        )

    def make_kv_cache(
        self,
        x: ActivationSpec,
        cache_name: str,
        past_seqlen: int = 0,
        is_sliding: bool = False,
        sliding_window: int = 1024,
        max_cache_len: int = 8192,
        opname="",
    ):
        if not opname:
            opname = x.name + "/attn_mask "

        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.StatefulKVCacheWrapper,
            cache_name=cache_name,
            past_seqlen=past_seqlen,
            is_sliding=is_sliding,
            sliding_window=sliding_window,
            max_cache_len=max_cache_len,
        )

    def make_indexed_item_selector(
        self,
        x: ActivationSpec,
        axis: int,
        index=None,
        start: Optional[int] = None,
        end: Optional[int] = None,
        step: Optional[int] = None,
        repeat: Optional[int] = None,
        opname="",
        **kwargs,
    ):
        if not opname:
            opname = x.name + "/idxsel"
        # check if it is slice type.
        if index is not None and len(index) > 1:
            _start = int(index[0])
            _end = int(index[-1]) + 1
            _step = int(index[1] - index[0])
            if (
                _step > 0
                and _start < _end
                and numpy.array_equal(numpy.arange(_start, _end, _step), index)
            ):
                start = _start
                end = _end
                step = _step
                index = None

        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.IndexedItemSelector,
            axis=axis,
            index=index,
            start=start,
            end=end,
            step=step,
            repeat=repeat,
        )

    def make_rotate_half(self, x, type: int = 0, opname=""):
        if not opname:
            opname = x.name + "/rothalf"
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.RotateHalf,
            type=type,
        )

    def make_sin(self, x, opname=""):
        return self._make_single_output(x, opname=opname, layertype=LayerType.Sin)

    def make_cos(self, x, opname=""):
        return self._make_single_output(x, opname=opname, layertype=LayerType.Cos)

    def make_cast(self, x, dtype: str, opname=""):
        return self._make_single_output(
            x, opname=opname, layertype=LayerType.Cast, dtype=dtype
        )

    def make_topk_indices(
        self,
        x,
        axis: int,
        k: int,
        largest: bool = True,
        sorted: bool = True,
        opname="",
    ):
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.TopKIndices,
            axis=axis,
            k=k,
            largest=largest,
            sorted=sorted,
        )

    def make_topk_values(
        self,
        x,
        axis: int,
        k: int,
        largest: bool = True,
        sorted: bool = True,
        opname="",
    ):
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.TopKValues,
            axis=axis,
            k=k,
            largest=largest,
            sorted=sorted,
        )

    def make_stateful_rnn_wrapper(
        self,
        X,
        sequence_length=None,
        init_hidden_state=None,
        W=None,
        R=None,
        B=None,
        activation_alpha: Optional[Sequence[float]] = None,
        activation_beta: Optional[Sequence[float]] = None,
        activations: Optional[Sequence[str]] = None,
        clip: float = None,
        output_mask: str = "",
        hidden_size: int = "",
        hidden_state_name: str = "",
        subgraph: str = "",
        direction: str = "forward",
        batch_first: bool = True,
        opname="",
        **kwargs,
    ):
        assert bool(subgraph), f"subgraph must be provided, got {subgraph}"
        assert direction in (
            "forward",
            "backward",
            "bidirectional",
        ), f"unsupported direction, got {direction}"

        opname = subgraph
        inputs = []
        input_mask = ""
        for imask, item in zip("ish", (X, sequence_length, init_hidden_state)):
            if item is not None:
                input_mask += imask
                inputs.append(item)

        outputs = self._make_multiple_output(
            inputs,
            num_outputs=2,
            opname=opname,
            layertype=LayerType.StatefulRNNWrapper,
            W=W,
            R=R,
            B=B,
            activation_alpha=activation_alpha,
            activation_beta=activation_beta,
            activations=activations,
            clip=clip,
            input_mask=input_mask,
            output_mask=output_mask,
            hidden_size=hidden_size,
            hidden_state_name=hidden_state_name,
            direction=direction,
            batch_first=batch_first,
            subgraph=subgraph,
        )
        return outputs

    def make_stateful_gru_wrapper(
        self,
        X,
        sequence_length=None,
        init_hidden_state=None,
        W=None,
        R=None,
        B=None,
        activation_alpha: Optional[Sequence[float]] = None,
        activation_beta: Optional[Sequence[float]] = None,
        activations: Optional[Sequence[str]] = None,
        clip: float = None,
        output_mask: str = "",
        hidden_size: int = "",
        hidden_state_name: str = "",
        linear_before_reset: bool = False,
        subgraph: str = "",
        direction: str = "forward",
        batch_first: bool = True,
        opname="",
        **kwargs,
    ):
        assert bool(subgraph), f"subgraph must be provided, got {subgraph}"
        assert direction in (
            "forward",
            "backward",
            "bidirectional",
        ), f"unsupported direction, got {direction}"

        opname = subgraph
        inputs = []
        input_mask = ""
        for imask, item in zip("ish", (X, sequence_length, init_hidden_state)):
            if item is not None:
                input_mask += imask
                inputs.append(item)

        outputs = self._make_multiple_output(
            inputs,
            num_outputs=2,
            opname=opname,
            layertype=LayerType.StatefulGRUWrapper,
            W=W,
            R=R,
            B=B,
            activation_alpha=activation_alpha,
            activation_beta=activation_beta,
            activations=activations,
            clip=clip,
            input_mask=input_mask,
            output_mask=output_mask,
            hidden_size=hidden_size,
            linear_before_reset=linear_before_reset,
            hidden_state_name=hidden_state_name,
            direction=direction,
            batch_first=batch_first,
            subgraph=subgraph,
        )
        return outputs

    def make_stateful_lstm_wrapper(
        self,
        X,
        sequence_length=None,
        init_hidden_state=None,
        init_cell_state=None,
        W=None,
        R=None,
        B=None,
        P=None,
        activation_alpha: Optional[Sequence[float]] = None,
        activation_beta: Optional[Sequence[float]] = None,
        activations: Optional[Sequence[str]] = None,
        clip: float = None,
        output_mask: str = "",
        hidden_size: int = "",
        input_forget: bool = False,
        hidden_state_name: str = "",
        cell_state_name: str = "",
        subgraph: str = "",
        direction: str = "forward",
        batch_first: bool = True,
        opname="",
        **kwargs,
    ):
        assert bool(subgraph), f"subgraph must be provided, got {subgraph}"
        assert direction in (
            "forward",
            "backward",
            "bidirectional",
        ), f"unsupported direction, got {direction}"

        opname = subgraph
        inputs = []
        input_mask = ""
        for imask, item in zip(
            "ishc", (X, sequence_length, init_hidden_state, init_cell_state)
        ):
            if item is not None:
                input_mask += imask
                inputs.append(item)

        outputs = self._make_multiple_output(
            inputs,
            num_outputs=3,
            opname=opname,
            layertype=LayerType.StatefulLSTMWrapper,
            W=W,
            R=R,
            B=B,
            P=P,
            activation_alpha=activation_alpha,
            activation_beta=activation_beta,
            activations=activations,
            clip=clip,
            input_mask=input_mask,
            output_mask=output_mask,
            hidden_size=hidden_size,
            input_forget=input_forget,
            hidden_state_name=hidden_state_name,
            cell_state_name=cell_state_name,
            direction=direction,
            batch_first=batch_first,
            subgraph=subgraph,
        )
        return outputs

    def make_where(self, condition, x, y, opname=""):
        return self._make_single_output(
            (condition, x, y), opname=opname, layertype=LayerType.Where
        )

    def make_tensor_cmp(self, x, y, kind="eq", opname=""):
        return self._make_single_output(
            (x, y), opname=opname, layertype=LayerType.TensorCmp, kind=kind
        )

    def make_staggered_padding(
        self, x, axis=3, reverse=False, window_size=-1, opname=""
    ):
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.StaggeredPadding,
            axis=axis,
            reverse=reverse,
            window_size=window_size,
        )

    def make_masked_fill(self, x, mask, value: float, opname=""):
        return self._make_single_output(
            (x, mask),
            opname=opname,
            layertype=LayerType.MaskedFill,
            value=value,
        )

    def make_channel_factor_slice(
        self,
        x,
        factor_shape: Tuple[int, ...],
        axis: int,
        start: int,
        end: int,
        step: int,
        opname="",
    ):
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.ChannelFactorSlice,
            factor_shape=factor_shape,
            axis=axis,
            start=start,
            end=end,
            step=step,
        )

    def make_subgraph_call(
        self,
        inputs: Tuple[ActivationSpec, ...],
        outputs: Tuple[ActivationSpec, ...],
        kind: str,
        subgraph: str,
        scope: str = "",
        opname="",
    ):
        """
        The subgraph call replaces existing nodes with a subgraph_call, so it does not create new outputs.
        'sugraph' refers to the name of the subgraph to be replaced by the subgraph_call.
        'kind' indicates the type of subgraph_call. Currently, only 'call' is supported.
        'opname' represents the name of the subgraph_call. The default value is set to the 'sugraph' name.
        """
        if not opname:
            opname = outputs[0].name
        if not scope:
            scope = subgraph
        if not subgraph:
            raise NotImplementedError("subgraph_call requires sugraph name.")
        options_cls = LayerOptionsRegistry.getcls(LayerType.SubgraphCall)
        input_indices = tuple(self.get_activation_index(a) for a in inputs)
        output_indices = tuple(self.get_activation_index(a) for a in outputs)
        op = Operator(
            name=opname,
            options=options_cls(
                inputs=input_indices,
                outputs=output_indices,
                kind=kind,
                sugraph=subgraph,
                scope=scope,
            ),
        )
        self._operators.append(op)
        for oact in outputs:
            oact.producer = op
        return tuple(outputs)

    def make_stateful_cached_stack(
        self, x, axis: int, cache_len: int, cache_name: str, opname=""
    ):
        if not opname:
            opname = x.name + "/cachedstack"
        return self._make_single_output(
            x,
            opname=opname,
            layertype=LayerType.StatefulCachedStack,
            axis=axis,
            cache_len=cache_len,
            cache_name=cache_name,
        )

    def with_new_input_and_options(self, old_op: Operator, *new_inact, **options):
        kw = dataclasses.asdict(old_op.options)
        kw.pop("inputs", None)
        kw.pop("outputs", None)
        kw.pop("channel_last", None)
        for k, v in kw.items():
            if isinstance(v, TensorIndex):
                if v != -1:
                    kw[k] = old_op.get_tensor(v).value
                else:
                    kw[k] = None
        kw.update(options)
        if len(new_inact) == 1:
            new_inact = new_inact[0]

        if old_op.layertype == LayerType.Transpose:
            return self.make_transpose(new_inact, **kw)
        if old_op.layertype == LayerType.Reshape:
            return self.make_reshape(new_inact, **kw)
        if old_op.layertype == LayerType.Concatenate:
            return self.make_concatenate(new_inact, **kw)
        if old_op.layertype == LayerType.StatefulRNNWrapper:
            input_mask = kw.pop("input_mask", None)
            if input_mask is None:
                assert len(new_inact) == 3
                return self.make_stateful_rnn_wrapper(*new_inact, **kw)
            else:
                new_inacts = {"i": None, "s": None, "h": None}
                for imask, new_inact in zip(input_mask, new_inact):
                    new_inacts[imask] = new_inact
                new_inacts = [new_inacts[imask] for imask in "ish"]
                return self.make_stateful_rnn_wrapper(*new_inacts, **kw)
        if old_op.layertype == LayerType.StatefulGRUWrapper:
            input_mask = kw.pop("input_mask", None)
            if input_mask is None:
                assert len(new_inact) == 3
                return self.make_stateful_gru_wrapper(*new_inact, **kw)
            else:
                new_inacts = {"i": None, "s": None, "h": None}
                for imask, new_inact in zip(input_mask, new_inact):
                    new_inacts[imask] = new_inact
                new_inacts = [new_inacts[imask] for imask in "ish"]
                return self.make_stateful_gru_wrapper(*new_inacts, **kw)
        if old_op.layertype == LayerType.StatefulLSTMWrapper:
            input_mask = kw.pop("input_mask", None)
            if input_mask is None:
                assert len(new_inact) == 4
                return self.make_stateful_lstm_wrapper(*new_inact, **kw)
            else:
                new_inacts = {"i": None, "s": None, "h": None, "c": None}
                for imask, new_inact in zip(input_mask, new_inact):
                    new_inacts[imask] = new_inact
                new_inacts = [new_inacts[imask] for imask in "ishc"]
                return self.make_stateful_lstm_wrapper(*new_inacts, **kw)
        if old_op.layertype == LayerType.MatMul:
            kw.pop("constant")
            kw.pop("is_const_first")
            return self.make_matmul(left=new_inact[0], right=new_inact[1], **kw)
        if old_op.layertype == LayerType.Where:
            return self.make_where(
                condition=new_inact[0], x=new_inact[1], y=new_inact[2], **kw
            )
        if old_op.layertype in (
            LayerType.MultiplyConstant,
            LayerType.AddingConstant,
            LayerType.DivConstant,
            LayerType.SubConstant,
        ):
            left = new_inact
            right = kw.pop("constant", None)
            if right is None:
                right = old_op.get_tensor(old_op.options.constant).value
            if old_op.options.is_const_first:
                left, right = right, left
            opkind = old_op.layertype.name[:3].lower()
            return self.make_biop(left, right, opkind=opkind)
        if old_op.layertype in (
            LayerType.Adding,
            LayerType.Multiply,
            LayerType.Div,
            LayerType.Sub,
        ):
            left, right = new_inact
            opkind = old_op.layertype.name.lower()[:3]
            return self.make_biop(left, right, opkind=opkind, **kw)
        if is_actfunc_type(old_op.layertype):
            return self.make_act_func(new_inact, old_op.layertype.name.lower(), **kw)
        if old_op.layertype == LayerType.ChannelFactorSlice:
            return self.make_channel_factor_slice(new_inact, **kw)
        if old_op.layertype == LayerType.Convolution3d:
            return self.make_conv3d(new_inact, **kw)
        if old_op.layertype in (LayerType.Convolution, LayerType.GroupConvolution):
            return self.make_conv2d(new_inact, **kw)
        if old_op.layertype == LayerType.DepthwiseConvolution:
            return self.make_depthwise_conv2d(new_inact, **kw)
        if old_op.layertype == LayerType.TransposeConvolution:
            return self.make_transposeconv2d(new_inact, **kw)
        if old_op.layertype == LayerType.LayerNormalization:
            return self.make_layernorm(new_inact, **kw)
        if old_op.layertype == LayerType.Pow:
            return self.make_pow(new_inact, **kw)
        if old_op.layertype == LayerType.L2Normalization:
            return self.make_l2normalization(new_inact, **kw)
        if old_op.layertype == LayerType.L1Normalization:
            return self.make_l1normalization(new_inact, **kw)
        if old_op.layertype == LayerType.SumNormalization:
            return self.make_sumnormalization(new_inact, **kw)
        if old_op.layertype == LayerType.RmsNormalization:
            return self.make_rmsnorm(new_inact, **kw)
        if old_op.layertype == LayerType.Resize:
            return self.make_resize(new_inact, **kw)
        if old_op.layertype == LayerType.Expand:
            return self.make_expand(new_inact, **kw)
        if old_op.layertype == LayerType.Slice:
            return self.make_slice(new_inact, **kw)
        if old_op.layertype == LayerType.InstanceNormalization:
            return self.make_instancenorm(new_inact, **kw)
        if old_op.layertype == LayerType.ReduceMean:
            return self.make_reduce_mean(new_inact, **kw)
        if old_op.layertype == LayerType.ReduceMax:
            return self.make_reduce_max(new_inact, **kw)
        if old_op.layertype == LayerType.ReduceMin:
            return self.make_reduce_min(new_inact, **kw)
        if old_op.layertype == LayerType.ReduceSum:
            return self.make_reduce_sum(new_inact, **kw)
        if old_op.layertype == LayerType.ReduceProd:
            return self.make_reduce_prod(new_inact, **kw)
        if old_op.layertype == LayerType.ReduceL2:
            return self.make_reduce_l2(new_inact, **kw)
        if old_op.layertype == LayerType.ReduceRMS:
            return self.make_reduce_rms(new_inact, **kw)
        if old_op.layertype == LayerType.Pooling:
            return self._make_pooling(new_inact, **kw)
        if old_op.layertype == LayerType.GlobalAveragePooling:
            return self.make_global_avgpool(new_inact, **kw)
        if old_op.layertype == LayerType.Batchnorm:
            return self.make_batchnorm(new_inact, **kw)
        if old_op.layertype == LayerType.Softmax:
            return self.make_softmax(new_inact, **kw)
        if old_op.layertype == LayerType.HeaderView:
            kw.pop("view_shape")
            return self.make_headerview(new_inact, **kw)
        if old_op.layertype == LayerType.HeaderViewRevert:
            kw.pop("revert_shape")
            return self.make_headerview_revert(new_inact, **kw)
        if old_op.layertype == LayerType.PadGeneric:
            return self.make_pad_generic(new_inact, **kw)
        if old_op.layertype == LayerType.OrderedPatchify:
            return self.make_ordered_patchify(new_inact, **kw)
        if old_op.layertype == LayerType.IndexedItemSelector:
            return self.make_indexed_item_selector(new_inact, **kw)
        if old_op.layertype == LayerType.Cast:
            return self.make_cast(new_inact, **kw)
        if old_op.layertype == LayerType.MaskedFill:
            return self.make_masked_fill(x=new_inact[0], mask=new_inact[1], **kw)
        if old_op.layertype == LayerType.Identity:
            return self.make_identity(new_inact, **kw)
        if old_op.layertype == LayerType.TopKValues:
            return self.make_topk_values(new_inact, **kw)
        if old_op.layertype == LayerType.TopKIndices:
            return self.make_topk_indices(new_inact, **kw)
        raise NotImplementedError(f"with_new_input: {old_op.layertype}")
